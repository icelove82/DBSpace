create PROCEDURE        "SP_UI_CM_01_POP_28_Q2" (
        pResult OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN pResult FOR 
      SELECT  C.ID				AS LOCAT_MST_ID
             ,B.COMN_CD_NM		AS LOCAT_TP_NM
             ,C.LOCAT_LV

			FROM         TB_AD_COMN_GRP A 
              INNER JOIN TB_AD_COMN_CODE B
                ON A.ID = B.SRC_ID
              INNER JOIN TB_CM_LOC_MST C
                ON B.ID = C.LOCAT_TP_ID

		    WHERE 
			  A.GRP_CD = 'LOC_TP';

END;

/

