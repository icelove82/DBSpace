create PROCEDURE        "SP_UI_CM_01_POP_07_S" (
	 P_ID                       IN VARCHAR2 := ''
	,P_PARENT_ATTR_CONVN_NM	    IN VARCHAR2 := ''
	,P_HRCY_YN	                IN VARCHAR2 := ''
    ,P_ROOT_LV_YN		        IN VARCHAR2 := ''
    ,P_ACTV_YN	                IN VARCHAR2 := ''
    ,P_USER_ID	                IN VARCHAR2 := ''
    ,P_WRK_TYPE	                IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG         OUT VARCHAR2 
    ,P_RT_MSG                   OUT VARCHAR2
    
)
IS

    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';
    P_CONF_ID VARCHAR2(32) := '';
    P_ITEM_SCOPE_MST_ID VARCHAR2(32) := '';

BEGIN
IF P_WRK_TYPE = 'SAVE'
THEN

    SELECT ID INTO P_CONF_ID FROM TB_CM_CONFIGURATION WHERE CONF_KEY='007';
    SELECT ITEM_SCOPE_MST_ID INTO P_ITEM_SCOPE_MST_ID FROM(SELECT ROWNUM, ITEM_SCOPE_MST_ID FROM TB_CM_ITEM_ATTRIBUTE_LEVEL) WHERE ROWNUM = 1;

        IF P_HRCY_YN = 'Y' 
        THEN
            P_ERR_MSG := 'MSG_5009'; --'Parent Attribute？？ Root Level？？ ？？？y？ ？？？？？？ ？？ ？？？？？？？.'
                IF (NVL(P_PARENT_ATTR_CONVN_NM,'') != '' AND  P_ROOT_LV_YN = 'Y') THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
                END IF;
            P_ERR_MSG := 'MSG_5010'; --'Item Hierarchy？？？？ Parent Attribute？？ ？？？？？？？？？？？.'
                IF (NVL(P_PARENT_ATTR_CONVN_NM,'') = '' AND  P_ROOT_LV_YN = 'N') THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
                END IF;
        END IF;
        IF P_HRCY_YN = 'N' 
        THEN
            P_ERR_MSG := 'MSG_5011'; --'Parent Attribute ？？？？？？ ？？？？？？？ Hierarchy ？？？？？？ ？？？？？？？.'
                IF (NVL(P_PARENT_ATTR_CONVN_NM,'') != '' OR  P_ROOT_LV_YN = 'Y') THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
                END IF;
        END IF;

    MERGE INTO TB_CM_ITEM_ATTRIBUTE_LEVEL B 
			USING (SELECT P_ID AS ID FROM DUAL) A
					ON  (B.ID = A.ID)

			WHEN MATCHED THEN

				UPDATE 
				   SET 
					   ACTV_YN	        = P_ACTV_YN
					 , HRCY_YN	        = P_HRCY_YN
					 , PARENT_ATTR_ID   = P_PARENT_ATTR_CONVN_NM
					 , ROOT_LV_YN       = P_ROOT_LV_YN
					 , MODIFY_BY	    = P_USER_ID
					 , MODIFY_DTTM	    = SYSDATE

		    WHEN NOT MATCHED THEN			
			INSERT (
				--？？？？？？
				ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
				 --？？？？？？？？
				, ITEM_SCOPE_MST_ID
				, CONF_ID
				, PARENT_ATTR_ID
				, HRCY_YN
				, ROOT_LV_YN
				, ACTV_YN
				)
			VALUES 
		  	    (
				 --？？？？？？
				TO_SINGLE_BYTE(SYS_GUID()), P_USER_ID, SYSDATE(), P_USER_ID, SYSDATE()
				 --？？？？？？？？
				, P_ITEM_SCOPE_MST_ID
				, P_CONF_ID
				, P_PARENT_ATTR_CONVN_NM
				, P_HRCY_YN
				, P_ROOT_LV_YN
				, P_ACTV_YN

			);

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';  --？？？？ ？？？？？？？？.


ELSIF P_WRK_TYPE = 'DELETE'
THEN

    DELETE FROM TB_CM_ITEM_ATTRIBUTE_LEVEL
		WHERE ID = P_ID;

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0002';


END IF;

        EXCEPTION
        WHEN OTHERS THEN
            P_RT_ROLLBACK_FLAG := 'false';
            IF(SQLCODE = -20012)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF; 

END;

/

