create PROCEDURE "SP_COMM_SRH_ITEM_Q" (
     P_ITEM_CD      IN VARCHAR2 :=''
    ,P_ITEM_NM      IN VARCHAR2 :=''
    ,P_ITEM_TP_ID   IN VARCHAR2 :=''
    ,P_ITEM_DESCRIP IN VARCHAR2 :=''
    ,pResult OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN pResult FOR
        SELECT A.ID			AS ITEM_MST_ID
           ,A.ITEM_CD		AS ITEM_CD
           ,A.ITEM_NM		AS ITEM_NM
           ,A.DESCRIP		AS ITEM_DESCRIP
           ,A.ITEM_TP_ID	AS ITEM_TP_ID
           ,B.CONVN_NM		AS ITEM_TP_NM
           ,A.UOM_ID		AS ITEM_UOM_ID
           ,C.UOM_NM		AS ITEM_UOM_NM
           ,A.DEL_YN		
       FROM TB_CM_ITEM_MST A
			INNER JOIN TB_CM_ITEM_TYPE B
				ON (A.ITEM_TP_ID = B.ID)
			LEFT OUTER JOIN TB_CM_UOM C
				ON (A.UOM_ID = C.ID)
      WHERE 1=1
        AND A.ITEM_CD   LIKE '%'||P_ITEM_CD||'%'
        AND NVL(A.ITEM_NM,' ')   LIKE '%'||P_ITEM_NM||'%'
        AND NVL(A.DESCRIP,' ')   LIKE '%'||P_ITEM_DESCRIP||'%' 
        AND A.ITEM_TP_ID =  CASE WHEN P_ITEM_TP_ID = 'ALL' THEN A.ITEM_TP_ID
								 ELSE P_ITEM_TP_ID
							 END
      ORDER BY A.ITEM_CD;

END;

/

