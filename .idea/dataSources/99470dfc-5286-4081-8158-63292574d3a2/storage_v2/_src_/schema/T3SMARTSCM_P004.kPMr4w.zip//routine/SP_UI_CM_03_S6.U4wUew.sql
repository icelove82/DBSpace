create PROCEDURE SP_UI_CM_03_S6 (
    P_ID                IN CHAR :='',
    P_RT_ROLLBACK_FLAG  OUT VARCHAR2,
    P_RT_MSG            OUT VARCHAR2
)
IS
    P_ERR_STATUS    NUMBER := 0;
    P_ERR_MSG       VARCHAR2(4000) :='';
    ITEM_CNT        VARCHAR2(100) :='';

BEGIN
    
    DELETE FROM TB_CM_ITEM_CLASS_DTL 
    WHERE ITEM_CLASS_ID = P_ID;

    DELETE FROM TB_CM_ITEM_CLASS_MST
    WHERE ID = P_ID;
    
    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0002';

EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN 
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;
      ELSE
          RAISE;
      END IF;
END;

/

