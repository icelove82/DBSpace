create PROCEDURE SP_UI_CM_12_POP_S2 (
     P_DMND_SHPP_MGMT_MST_ID	IN CHAR := NULL,
     P_DMND_SHPP_MGMT_DTL_ID	IN CHAR := NULL,
	 P_ACTV_YN					IN CHAR := NULL,
     P_VEHICL_TP_ID             IN CHAR := NULL,
	 P_PRIORT					IN VARCHAR2 := NULL,
	 P_LOAD_UOM_ID				IN CHAR := NULL,
	 P_TRANSP_LOTSIZE			IN NUMBER := NULL,
	 P_USER_ID					IN VARCHAR2 :='',
     P_RT_ROLLBACK_FLAG         OUT VARCHAR2,
     P_RT_MSG                   OUT VARCHAR2
)
IS
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG    VARCHAR2(4000) :='';
    V_LOAD_UOM	 VARCHAR2(100) := '';

BEGIN
    IF P_VEHICL_TP_ID IS NOT NULL THEN
        SELECT	NVL(MAX(UPPER(B.COMN_CD)), '') INTO V_LOAD_UOM
        FROM	TB_AD_COMN_GRP A
                INNER JOIN TB_AD_COMN_CODE B
                ON A.ID = B.SRC_ID
        WHERE	1=1
        AND		A.GRP_CD = 'LOAD_UOM_TYPE'
        AND		B.ID = P_LOAD_UOM_ID;
    
        MERGE INTO TB_CM_DMND_SHPP_MAP_DTL TARGET
        USING
        (
            SELECT	P_DMND_SHPP_MGMT_DTL_ID		    AS ID,
                    P_DMND_SHPP_MGMT_MST_ID		    AS DMND_SHPP_MGMT_MST_ID,
                    P_ACTV_YN						AS ACTV_YN,
                    P_VEHICL_TP_ID					AS VEHICL_TP_ID,
                    P_PRIORT						AS PRIORT,
                    P_LOAD_UOM_ID					AS LOAD_UOM_ID,
                    P_TRANSP_LOTSIZE				AS TRANSP_LOTSIZE,
                    D.UOM_QTY						AS UOM_QTY,
                    D.UOM_QTY / D.UOM_PER_PACKING	AS PACKING_QTY,
                    D.PACKING_TP_CD_ID				AS PACKING_TP_ID,
                    (D.UOM_QTY / D.UOM_PER_PACKING) / D.PACKING_PER_PALLET	AS PALLET_QTY,
                    D.PALLET_TP_ID					AS PALLET_TP_ID,
                    P_USER_ID						AS USER_ID
            FROM	TB_CM_DMND_SHPP_MAP_MST A
                    INNER JOIN
                    (SELECT * FROM TB_CM_SITE_ITEM WHERE BOM_ITEM_TP_ID = (SELECT ID FROM TB_AD_COMN_CODE WHERE COMN_CD = 'FINAL_PRODUCT_GR_ITEM')) C
                    ON (A.LOCAT_MGMT_ID = C.LOCAT_MGMT_ID AND A.ITEM_MST_ID = C.ITEM_MST_ID)
                    LEFT OUTER JOIN
                    (
                    SELECT	A.LOCAT_ITEM_ID,
                            A.PACKING_TP_CD_ID,
                            A.UOM_PER_PACKING,
                            A.PALLET_TP_ID,
                            A.PACKING_PER_PALLET,
                            CASE WHEN V_LOAD_UOM = 'UOM'	  THEN P_TRANSP_LOTSIZE
                                 WHEN V_LOAD_UOM = 'PACKING' THEN A.UOM_PER_PACKING * P_TRANSP_LOTSIZE
                                 WHEN V_LOAD_UOM = 'PALLET'  THEN A.UOM_PER_PACKING * A.PACKING_PER_PALLET * P_TRANSP_LOTSIZE
                                 ELSE 0
                            END AS UOM_QTY
                    FROM	TB_CM_SITE_PACKING A
                    WHERE	ACTV_YN = 'Y'
                    ) D
                    ON C.ID = D.LOCAT_ITEM_ID
            WHERE	A.ID = P_DMND_SHPP_MGMT_MST_ID
            
        ) SOURCE
        ON (TARGET.ID = SOURCE.ID)
        WHEN MATCHED THEN
            UPDATE
            SET		PRIORT			= SOURCE.PRIORT,
                    LOAD_UOM_ID		= SOURCE.LOAD_UOM_ID,
                    TRANSP_LOTSIZE	= SOURCE.TRANSP_LOTSIZE,
                    UOM_QTY			= SOURCE.UOM_QTY,
                    PACKING_QTY		= SOURCE.PACKING_QTY,
                    PACKING_TP_ID	= SOURCE.PACKING_TP_ID,
                    PALLET_QTY		= SOURCE.PALLET_QTY,
                    PALLET_TP_ID	= SOURCE.PALLET_TP_ID,
                    ACTV_YN			= SOURCE.ACTV_YN,
                    MODIFY_BY		= SOURCE.USER_ID,
                    MODIFY_DTTM		= SYSDATE
    
        WHEN NOT MATCHED THEN
            INSERT	(
                    ID,
                    DMND_SHPP_MGMT_MST_ID,
                    VEHICL_TP_ID,
                    PRIORT,
                    LOAD_UOM_ID,
                    TRANSP_LOTSIZE,
                    UOM_QTY,
                    PACKING_QTY,
                    PACKING_TP_ID,
                    PALLET_QTY,
                    PALLET_TP_ID,
                    ACTV_YN,
                    CREATE_BY,
                    CREATE_DTTM
                    )
            VALUES	(
                    TO_SINGLE_BYTE(SYS_GUID()),
                    SOURCE.DMND_SHPP_MGMT_MST_ID,
                    SOURCE.VEHICL_TP_ID,
                    SOURCE.PRIORT,
                    SOURCE.LOAD_UOM_ID,
                    SOURCE.TRANSP_LOTSIZE,
                    SOURCE.UOM_QTY,
                    SOURCE.PACKING_QTY,
                    SOURCE.PACKING_TP_ID,
                    SOURCE.PALLET_QTY,
                    SOURCE.PALLET_TP_ID,
                    SOURCE.ACTV_YN,
                    SOURCE.USER_ID,
                    SYSDATE
                    );    
    END IF;

	P_RT_ROLLBACK_FLAG := 'true';
	P_RT_MSG := 'MSG_0001';
                    
EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;   
      ELSE
          RAISE;
      END IF; 
END;

/

