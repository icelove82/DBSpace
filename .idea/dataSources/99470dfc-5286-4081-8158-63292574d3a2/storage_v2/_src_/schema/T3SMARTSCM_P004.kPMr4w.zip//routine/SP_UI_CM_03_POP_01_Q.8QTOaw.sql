create PROCEDURE "SP_UI_CM_03_POP_01_Q" (
    P_CONF_KEY          IN VARCHAR2:='' ,
    P_VIEW_ID           IN VARCHAR2:='' ,
    P_ITEM_LV_ID        IN VARCHAR2:='' ,
    P_ITEM_CLASS        IN VARCHAR2:='' ,
    P_ITEM_CLASS_DTL_ID IN CHAR:= '',
    pResult OUT SYS_REFCURSOR
)
IS
    P_MAX_INT NUMBER := 0;
BEGIN
	
	IF P_CONF_KEY ='001' /* SITE ITEM */
	THEN
		OPEN pResult FOR	
        SELECT B.ITEM_SCOPE_NM  AS ITEM_LV_NM
             , A.ITEM_CLASS_VAL 
             , A.DESCRIP
             , P_VIEW_ID       AS VIEW_ID
          FROM TB_CM_ITEM_CLASS_MST A 
            INNER JOIN TB_CM_ITEM_SCOPE_MST B
              ON A.ITEM_SCOPE_MST_ID = B.ID
         WHERE 
             A.ID LIKE '%'||P_ITEM_LV_ID||'%';
	
	ELSIF P_CONF_KEY ='002' /* ITEM_ATTRIBUTE */
	THEN
		OPEN pResult FOR	
        SELECT ID
              ,CONF_ID
              ,ATTR_NM
              ,CONVN_NM
              ,ACTV_YN
              ,CAST(SUBSTR(ATTR_NM, INSTR(ATTR_NM,'_')+1, LENGTH(ATTR_NM)) AS INT) AS SEQ
              ,CREATE_BY
              ,CREATE_DTTM
              ,MODIFY_BY
              ,MODIFY_DTTM
          FROM TB_CM_ITEM_ATTRIBUTE
          ORDER BY ATTR_NM ASC;
	
	ELSIF P_CONF_KEY ='003' /* @P_ITEM_CLASS */
	THEN
		OPEN pResult FOR	
        SELECT ATTRS
             , VAL
          FROM
        (SELECT DISTINCT 
               CASE WHEN A.ATTR_01 IS NOT NULL THEN NVL(B.ATTR_01, ' ') END AS ATTR_01
             , CASE WHEN A.ATTR_02 IS NOT NULL THEN NVL(B.ATTR_02, ' ') END AS ATTR_02
             , CASE WHEN A.ATTR_03 IS NOT NULL THEN NVL(B.ATTR_03, ' ') END AS ATTR_03
             , CASE WHEN A.ATTR_04 IS NOT NULL THEN NVL(B.ATTR_04, ' ') END AS ATTR_04
             , CASE WHEN A.ATTR_05 IS NOT NULL THEN NVL(B.ATTR_05, ' ') END AS ATTR_05
             , CASE WHEN A.ATTR_06 IS NOT NULL THEN NVL(B.ATTR_06, ' ') END AS ATTR_06
             , CASE WHEN A.ATTR_07 IS NOT NULL THEN NVL(B.ATTR_07, ' ') END AS ATTR_07
             , CASE WHEN A.ATTR_08 IS NOT NULL THEN NVL(B.ATTR_08, ' ') END AS ATTR_08
             , CASE WHEN A.ATTR_09 IS NOT NULL THEN NVL(B.ATTR_09, ' ') END AS ATTR_09
             , CASE WHEN A.ATTR_10 IS NOT NULL THEN NVL(B.ATTR_10, ' ') END AS ATTR_10
             , CASE WHEN A.ATTR_11 IS NOT NULL THEN NVL(B.ATTR_11, ' ') END AS ATTR_11
             , CASE WHEN A.ATTR_12 IS NOT NULL THEN NVL(B.ATTR_12, ' ') END AS ATTR_12
             , CASE WHEN A.ATTR_13 IS NOT NULL THEN NVL(B.ATTR_13, ' ') END AS ATTR_13
             , CASE WHEN A.ATTR_14 IS NOT NULL THEN NVL(B.ATTR_14, ' ') END AS ATTR_14
             , CASE WHEN A.ATTR_15 IS NOT NULL THEN NVL(B.ATTR_15, ' ') END AS ATTR_15
             , CASE WHEN A.ATTR_16 IS NOT NULL THEN NVL(B.ATTR_16, ' ') END AS ATTR_16
             , CASE WHEN A.ATTR_17 IS NOT NULL THEN NVL(B.ATTR_17, ' ') END AS ATTR_17
             , CASE WHEN A.ATTR_18 IS NOT NULL THEN NVL(B.ATTR_18, ' ') END AS ATTR_18
             , CASE WHEN A.ATTR_19 IS NOT NULL THEN NVL(B.ATTR_19, ' ') END AS ATTR_19
             , CASE WHEN A.ATTR_20 IS NOT NULL THEN NVL(B.ATTR_20, ' ') END AS ATTR_20
          FROM TB_CM_ITEM_CLASS_MST A
             , TB_CM_ITEM_CLASS_DTL B
         WHERE A.ID = B.ITEM_CLASS_ID
           AND B.ID = P_ITEM_CLASS_DTL_ID) B UNPIVOT (VAL FOR ATTRS IN ( ATTR_01
                                                                        ,ATTR_02
                                                                        ,ATTR_03
                                                                        ,ATTR_04
                                                                        ,ATTR_05
                                                                        ,ATTR_06
                                                                        ,ATTR_07
                                                                        ,ATTR_08
                                                                        ,ATTR_09
                                                                        ,ATTR_10
                                                                        ,ATTR_11
                                                                        ,ATTR_12
                                                                        ,ATTR_13
                                                                        ,ATTR_14
                                                                        ,ATTR_15
                                                                        ,ATTR_16
                                                                        ,ATTR_17
                                                                        ,ATTR_18
                                                                        ,ATTR_19
                                                                        ,ATTR_20)) UnPVT;
	
	
	ELSIF P_CONF_KEY ='004' /* ITEM_ATTRIBUTE CANDIDATE */
	THEN
		OPEN pResult FOR	
        SELECT ID
              ,ATTR_NM
              ,CONVN_NM
         FROM TB_CM_ITEM_ATTRIBUTE
          UNION
        SELECT NULL		AS ID
              ,ATTR_NM	AS ATTR_NM			
              ,''			AS CONVN_NM
         FROM TB_CM_ITEM_ATTRIBUTE;
               
    ELSIF P_CONF_KEY ='005'
	THEN
		OPEN pResult FOR	
        SELECT ATTRS
             , VAL_ID
          FROM
        (SELECT DISTINCT 
               A.ATTR_01
             , A.ATTR_02
             , A.ATTR_03
             , A.ATTR_04
             , A.ATTR_05
             , A.ATTR_06
             , A.ATTR_07
             , A.ATTR_08
             , A.ATTR_09
             , A.ATTR_10
             , A.ATTR_11
             , A.ATTR_12
             , A.ATTR_13
             , A.ATTR_14
             , A.ATTR_15
             , A.ATTR_16
             , A.ATTR_17
             , A.ATTR_18
             , A.ATTR_19
             , A.ATTR_20
          FROM TB_CM_ITEM_CLASS_MST A
         WHERE 1=1
           AND A.ITEM_CLASS_VAL = P_ITEM_CLASS) B UNPIVOT (VAL_ID FOR ATTRS IN (ATTR_01
                                                                                ,ATTR_02
                                                                                ,ATTR_03
                                                                                ,ATTR_04
                                                                                ,ATTR_05
                                                                                ,ATTR_06
                                                                                ,ATTR_07
                                                                                ,ATTR_08
                                                                                ,ATTR_09
                                                                                ,ATTR_10
                                                                                ,ATTR_11
                                                                                ,ATTR_12
                                                                                ,ATTR_13
                                                                                ,ATTR_14
                                                                                ,ATTR_15
                                                                                ,ATTR_16
                                                                                ,ATTR_17
                                                                                ,ATTR_18
                                                                                ,ATTR_19
                                                                                ,ATTR_20)) UnPVT;
    ELSIF P_CONF_KEY = '006'
    THEN
        SELECT 
            NVL(MAX(TO_NUMBER(SUBSTR(A.ITEM_GRP, -4))), 0)+1 INTO P_MAX_INT
        FROM TB_CM_ITEM_CLASS_DTL A
            ,TB_CM_ITEM_CLASS_MST B
        WHERE 1=1
        AND A.ITEM_CLASS_ID = B.ID
        AND B.ITEM_CLASS_VAL = P_ITEM_CLASS;
        
        OPEN pResult FOR
        SELECT 'Item Group - ' || LPAD(P_MAX_INT, 4, '0') AS ITEM_GRP_NM
          FROM DUAL;
	END IF;   

END;

/

