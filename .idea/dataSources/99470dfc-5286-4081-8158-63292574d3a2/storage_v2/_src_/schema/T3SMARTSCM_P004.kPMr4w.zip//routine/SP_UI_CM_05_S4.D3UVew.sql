create PROCEDURE SP_UI_CM_05_S4 (
    P_WRK_TYPE              IN VARCHAR2 := ''
   ,P_BOM_PRIOD_RATE_ID     IN CHAR := ''
   ,P_PRDUCT_BOM_DTL_ID     IN CHAR := ''
   ,P_STRT_DTTM             IN DATE := NULL
   ,P_END_DTTM              IN DATE := NULL
   ,P_BOM_RATE              IN NUMBER := NULL
   ,P_USER_ID			    IN VARCHAR2 := ''
   ,P_RT_ROLLBACK_FLAG	    OUT VARCHAR2
   ,P_RT_MSG			    OUT VARCHAR2
)
IS
    P_ERR_STATUS       NUMBER := 0;
    P_ERR_MSG          VARCHAR2(4000) := '';

BEGIN
	P_ERR_MSG := 'MSG_0006';
    IF P_PRDUCT_BOM_DTL_ID IS NULL THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;
    IF P_STRT_DTTM IS NULL THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;
    IF P_END_DTTM IS NULL THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;

	P_ERR_MSG := 'MSG_0007';
	IF P_STRT_DTTM > P_END_DTTM THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;

	P_ERR_MSG := 'MSG_0008';
    IF P_BOM_RATE IS NOT NULL AND P_BOM_RATE < 0 THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;

	IF P_WRK_TYPE = 'SAVE' THEN
        MERGE INTO TB_CM_GLB_BOM_PRIOD_RATE TARGET
        USING
        (
            SELECT	P_BOM_PRIOD_RATE_ID	AS BOM_PRIOD_RATE_ID,
                    P_PRDUCT_BOM_DTL_ID	AS PRDUCT_BOM_DTL_ID,
                    P_STRT_DTTM			AS STRT_DTTM,
                    P_END_DTTM			AS END_DTTM,
                    P_BOM_RATE			AS BOM_RATE
            FROM    DUAL
        ) SOURCE
        ON (TARGET.ID = SOURCE.BOM_PRIOD_RATE_ID)
        WHEN MATCHED THEN 
            UPDATE	
            SET		TARGET.STRT_DTTM		= SOURCE.STRT_DTTM,
                    TARGET.END_DTTM			= SOURCE.END_DTTM,
                    TARGET.BOM_RATE			= SOURCE.BOM_RATE,
                    TARGET.MODIFY_BY		= P_USER_ID,
                    TARGET.MODIFY_DTTM		= SYSDATE

        WHEN NOT MATCHED THEN
            INSERT
            (
                ID,
                GLOBAL_PRDUCT_BOM_DTL_ID,
                STRT_DTTM,
                END_DTTM,
                BOM_RATE,
                CREATE_BY,
                CREATE_DTTM
            )
            VALUES
            (
                TO_SINGLE_BYTE(SYS_GUID()),
                SOURCE.PRDUCT_BOM_DTL_ID,
                SOURCE.STRT_DTTM,
                SOURCE.END_DTTM,
                SOURCE.BOM_RATE,
                P_USER_ID,
                SYSDATE
            );

        P_RT_MSG := 'MSG_0001';

	ELSIF P_WRK_TYPE = 'DELETE' THEN
        DELETE
        FROM	TB_CM_GLB_BOM_PRIOD_RATE
        WHERE	ID = P_BOM_PRIOD_RATE_ID;

        P_RT_MSG := 'MSG_0002';
    END IF;

    P_RT_ROLLBACK_FLAG := 'true';

EXCEPTION
WHEN OTHERS THEN
    P_RT_ROLLBACK_FLAG := 'false';
    IF(SQLCODE = -20012)
      THEN
          P_RT_MSG := P_ERR_MSG;
      ELSE
          P_RT_MSG := SQLERRM;
      END IF;
END;

/

