create FUNCTION "FN_DP_TEMP_SALES_REPORT" (
									  	 P_BUCK			    CHAR :=''
									    ,P_STRT_DATE	    DATE := ''
										,P_END_DATE	  	DATE := ''
										,P_USER_ID		    VARCHAR2 := 'admin' /* ？α？？？ USER (？？？) */
                                        ,P_PLAN_TP_ID    CHAR :=''
                                        ,p_ITEM_CD                VARCHAR2 :=''
                                        ,p_ACCT_CD                VARCHAR2 :=''
                                        ,P_ITEM_LV_CD             VARCHAR2 :=''                                        
                                        ,P_ACCT_LV_CD             VARCHAR2 :=''
																  )
-- 2018.12.19 / ？？？？？？ / key ？？？？ code？？ ？？？？？？？？ ？？？？
RETURN DP_TEMP_SALES_REPORT                           
IS 
        C_DP_TEMP_SALES_REPORT DP_TEMP_SALES_REPORT := DP_TEMP_SALES_REPORT();
        /* DIMENSION ？？？ ？？？？ */
        V_DIMENSION_01_ACTV_YN           CHAR(1)	;					   
		V_DIMENSION_02_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_03_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_04_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_05_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_06_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_07_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_08_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_09_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_10_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_11_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_12_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_13_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_14_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_15_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_16_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_17_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_18_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_19_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_20_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_21_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_22_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_23_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_24_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_25_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_26_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_27_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_28_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_29_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_30_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_31_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_32_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_33_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_34_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_35_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_36_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_37_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_38_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_39_ACTV_YN           CHAR(1) 	;
		V_DIMENSION_40_ACTV_YN           CHAR(1) 	;

		V_SO_STATUS_OPEN_ID			     CHAR(32)	;
		V_SO_STATUS_SHIPPED_ID		     CHAR(32)  ;
        V_VER_ID                         VARCHAR2(100);
        V_AUTH_TP_ID                     CHAR(32) ;
        V_LAST_ITEM_LV                 INT;
        V_LAST_ACCT_LV                 INT;

		 V_SEARCH_LV_SEQ	 INT            := NULL;
         V_SEARCH_LV_SEQ_02  INT            := NULL;
         V_ITEM_CHECK        INT  := NULL;
         V_ACCT_CHECK        INT  := NULL;
         V_ITEM_LV_CHECK     INT  := NULL;
         V_ACCT_LV_CHECK        INT  := NULL;  

CURSOR C_DATA_IMPORT IS 
      SELECT TP_DP_TEMP_SALES_REPORT 
          (--MES.ITEM_CD          AS ITEM 
              DAT        => M.BUCKET_START_DATE  
            -----------------------
            -- DIMENSION:   LEVEL ？？？？ ？？？？？？ ？？？ ？？
            ----------------------- 
        -- ITEM 
		, DIMENSION_01 => CASE WHEN V_DIMENSION_01_ACTV_YN = 'Y' THEN ITEM_LVL01_CD			 ELSE NULL END 
		, DIMENSION_02 => CASE WHEN V_DIMENSION_02_ACTV_YN = 'Y' THEN ITEM_LVL01_NM			 ELSE NULL END 
		, DIMENSION_03 => CASE WHEN V_DIMENSION_03_ACTV_YN = 'Y' THEN ITEM_LVL02_CD			 ELSE NULL END 
		, DIMENSION_04 => CASE WHEN V_DIMENSION_04_ACTV_YN = 'Y' THEN ITEM_LVL02_NM			 ELSE NULL END 
		, DIMENSION_05 => CASE WHEN V_DIMENSION_05_ACTV_YN = 'Y' THEN ITEM_LVL03_CD			 ELSE NULL END 
		, DIMENSION_06 => CASE WHEN V_DIMENSION_06_ACTV_YN = 'Y' THEN ITEM_LVL03_NM			 ELSE NULL END 
		, DIMENSION_07 => CASE WHEN V_DIMENSION_07_ACTV_YN = 'Y' THEN ITEM_LVL04_CD			 ELSE NULL END 
		, DIMENSION_08 => CASE WHEN V_DIMENSION_08_ACTV_YN = 'Y' THEN ITEM_LVL04_NM			 ELSE NULL END 
		, DIMENSION_09 => CASE WHEN V_DIMENSION_09_ACTV_YN = 'Y' THEN ITEM_LVL05_CD			 ELSE NULL END 
		, DIMENSION_10 => CASE WHEN V_DIMENSION_10_ACTV_YN = 'Y' THEN ITEM_LVL05_NM			 ELSE NULL END 
		, DIMENSION_11 => CASE WHEN V_DIMENSION_11_ACTV_YN = 'Y' THEN ITEM_LVL06_CD			 ELSE NULL END 
		, DIMENSION_12 => CASE WHEN V_DIMENSION_12_ACTV_YN = 'Y' THEN ITEM_LVL06_NM			 ELSE NULL END 
		, DIMENSION_13 => CASE WHEN V_DIMENSION_13_ACTV_YN = 'Y' THEN ITEM_LVL07_CD			 ELSE NULL END 
		, DIMENSION_14 => CASE WHEN V_DIMENSION_14_ACTV_YN = 'Y' THEN ITEM_LVL07_NM			 ELSE NULL END 
		, DIMENSION_15 => CASE WHEN V_DIMENSION_15_ACTV_YN = 'Y' THEN ITEM_LVL08_CD			 ELSE NULL END 
		, DIMENSION_16 => CASE WHEN V_DIMENSION_16_ACTV_YN = 'Y' THEN ITEM_LVL08_NM			 ELSE NULL END 
		, DIMENSION_17 => CASE WHEN V_DIMENSION_17_ACTV_YN = 'Y' THEN ITEM_LVL09_CD			 ELSE NULL END 
		, DIMENSION_18 => CASE WHEN V_DIMENSION_18_ACTV_YN = 'Y' THEN ITEM_LVL09_NM			 ELSE NULL END 
		, DIMENSION_19 => CASE WHEN V_DIMENSION_19_ACTV_YN = 'Y' THEN ITEM_LVL10_CD			 ELSE NULL END 
		, DIMENSION_20 => CASE WHEN V_DIMENSION_20_ACTV_YN = 'Y' THEN ITEM_LVL10_NM			 ELSE NULL END 

        -- ACCOUNT
		, DIMENSION_21 => CASE WHEN V_DIMENSION_21_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_CD       ELSE NULL END 
		, DIMENSION_22 => CASE WHEN V_DIMENSION_22_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_NM       ELSE NULL END 
		, DIMENSION_23 => CASE WHEN V_DIMENSION_23_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_CD       ELSE NULL END 
		, DIMENSION_24 => CASE WHEN V_DIMENSION_24_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_NM	     ELSE NULL END 
		, DIMENSION_25 => CASE WHEN V_DIMENSION_25_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_CD       ELSE NULL END 
		, DIMENSION_26 => CASE WHEN V_DIMENSION_26_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_NM       ELSE NULL END 
		, DIMENSION_27 => CASE WHEN V_DIMENSION_27_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_CD       ELSE NULL END 
		, DIMENSION_28 => CASE WHEN V_DIMENSION_28_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_NM       ELSE NULL END 
		, DIMENSION_29 => CASE WHEN V_DIMENSION_29_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_CD       ELSE NULL END 
		, DIMENSION_30 => CASE WHEN V_DIMENSION_30_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_NM       ELSE NULL END 
		, DIMENSION_31 => CASE WHEN V_DIMENSION_31_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_CD       ELSE NULL END 
		, DIMENSION_32 => CASE WHEN V_DIMENSION_32_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_NM       ELSE NULL END         
		, DIMENSION_33 => CASE WHEN V_DIMENSION_33_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_CD       ELSE NULL END 
		, DIMENSION_34 => CASE WHEN V_DIMENSION_34_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_NM       ELSE NULL END 
		, DIMENSION_35 => CASE WHEN V_DIMENSION_35_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_CD       ELSE NULL END 
		, DIMENSION_36 => CASE WHEN V_DIMENSION_36_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_NM       ELSE NULL END 
		, DIMENSION_37 => CASE WHEN V_DIMENSION_37_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_CD       ELSE NULL END  
		, DIMENSION_38 => CASE WHEN V_DIMENSION_38_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_NM       ELSE NULL END 
		, DIMENSION_39 => CASE WHEN V_DIMENSION_39_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_CD       ELSE NULL END 
		, DIMENSION_40 => CASE WHEN V_DIMENSION_40_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_NM       ELSE NULL END 
        , ITEM => CASE V_LAST_ITEM_LV WHEN 1             THEN  ITEM_LVL01_CD
                              WHEN 2             THEN  ITEM_LVL01_CD
                              WHEN 3             THEN  ITEM_LVL02_CD
                              WHEN 4             THEN  ITEM_LVL02_CD
                              WHEN 5             THEN  ITEM_LVL03_CD
                              WHEN 6             THEN  ITEM_LVL03_CD
                              WHEN 7             THEN  ITEM_LVL04_CD
                              WHEN 8             THEN  ITEM_LVL04_CD
                              WHEN 9             THEN  ITEM_LVL05_CD
                              WHEN 10            THEN  ITEM_LVL05_CD
                              WHEN 11            THEN  ITEM_LVL06_CD
                              WHEN 12            THEN  ITEM_LVL06_CD
                              WHEN 13            THEN  ITEM_LVL07_CD
                              WHEN 14            THEN  ITEM_LVL07_CD
                              WHEN 15            THEN  ITEM_LVL08_CD
                              WHEN 16            THEN  ITEM_LVL08_CD
                              WHEN 17            THEN  ITEM_LVL09_CD
                              WHEN 18            THEN  ITEM_LVL09_CD
                              WHEN 19            THEN  ITEM_LVL10_CD
                              WHEN 20            THEN  ITEM_LVL10_CD
							  END	

        , ACCOUNT => CASE V_LAST_ACCT_LV WHEN 21            THEN  ACCOUNT_LVL01_CD
                              WHEN 22            THEN  ACCOUNT_LVL01_CD 
                              WHEN 23            THEN  ACCOUNT_LVL02_CD
                              WHEN 24            THEN  ACCOUNT_LVL02_CD
                              WHEN 25            THEN  ACCOUNT_LVL03_CD
                              WHEN 26            THEN  ACCOUNT_LVL03_CD
                              WHEN 27            THEN  ACCOUNT_LVL04_CD
                              WHEN 28            THEN  ACCOUNT_LVL04_CD
                              WHEN 29            THEN  ACCOUNT_LVL05_CD
                              WHEN 30            THEN  ACCOUNT_LVL05_CD
                              WHEN 31            THEN  ACCOUNT_LVL06_CD
                              WHEN 32            THEN  ACCOUNT_LVL06_CD
                              WHEN 33            THEN  ACCOUNT_LVL07_CD
                              WHEN 34            THEN  ACCOUNT_LVL07_CD
                              WHEN 35            THEN  ACCOUNT_LVL08_CD
                              WHEN 36            THEN  ACCOUNT_LVL08_CD
                              WHEN 37            THEN  ACCOUNT_LVL09_CD
                              WHEN 38            THEN  ACCOUNT_LVL09_CD
                              WHEN 39            THEN  ACCOUNT_LVL10_CD
                              WHEN 40            THEN  ACCOUNT_LVL10_CD
							  END
           -- MEASURE
           ,   MEASURE_01		 => SUM( TB_CM_ACTUAL_SALES_MEASURE.OPEN_QTY )									  
           ,   MEASURE_02		 => SUM( TB_CM_ACTUAL_SALES_MEASURE.OPEN_AMT )									  
           ,   MEASURE_03		 => SUM( TB_CM_ACTUAL_SALES_MEASURE.SHIPPED_QTY ) 								  
           ,   MEASURE_04		 => SUM( TB_CM_ACTUAL_SALES_MEASURE.SHIPPED_AMT )								  
           ,   MEASURE_05		 => SUM( TB_CM_ACTUAL_SALES_MEASURE.QTY ) 										  
           ,   MEASURE_06		 => SUM( TB_CM_ACTUAL_SALES_MEASURE.AMT )										  
       )
       FROM           TABLE(FN_DP_TEMP_REPORT_MAIN_TABLE(P_BUCK 
                                                   , P_STRT_DATE
                                                   , P_END_DATE
                                                   , CASE WHEN V_ITEM_CHECK = 0    THEN NULL ELSE P_ITEM_CD    END
                                                   , CASE WHEN V_ACCT_CHECK =0     THEN NULL ELSE P_ACCT_CD    END
                                                   , CASE WHEN V_ITEM_LV_CHECK = 0 THEN NULL ELSE P_ITEM_LV_CD END
                                                   , CASE WHEN V_ACCT_LV_CHECK = 0 THEN NULL ELSE P_ACCT_LV_CD END
                                                   , V_SEARCH_LV_SEQ
                                                   , V_SEARCH_LV_SEQ_02
                                                   , P_PLAN_TP_ID
                                                   , P_USER_ID)) M          
--        FROM       TABLE(FN_DP_TEMP_REPORT_MAIN_TABLE(P_BUCK, P_STRT_DATE, P_END_DATE, V_VER_ID, P_USER_ID)) M  				
				LEFT OUTER JOIN (

								SELECT  ID,
										ITEM_MST_ID,
										ACCOUNT_ID,
										BASE_DATE,
										SO_STATUS_ID,
										CASE WHEN SO_STATUS_ID =  V_SO_STATUS_OPEN_ID  THEN QTY		   ELSE NULL END  AS OPEN_QTY,
										CASE WHEN SO_STATUS_ID =  V_SO_STATUS_OPEN_ID  THEN AMT		   ELSE NULL END  AS OPEN_AMT,
										CASE WHEN SO_STATUS_ID =  V_SO_STATUS_SHIPPED_ID  THEN QTY	   ELSE NULL END  AS SHIPPED_QTY,
										CASE WHEN SO_STATUS_ID =  V_SO_STATUS_SHIPPED_ID  THEN AMT	   ELSE NULL END  AS SHIPPED_AMT,
										NVL(QTY,0) AS QTY,
										NVL(AMT,0) AS AMT,
										CURCY_CD_ID
								FROM TB_CM_ACTUAL_SALES 

                                ) TB_CM_ACTUAL_SALES_MEASURE
											   ON M.ITEM_ID = TB_CM_ACTUAL_SALES_MEASURE.ITEM_MST_ID 
												  AND M.ACCOUNT_ID = TB_CM_ACTUAL_SALES_MEASURE.ACCOUNT_ID
												  AND TB_CM_ACTUAL_SALES_MEASURE.BASE_DATE BETWEEN 
													  M.BUCKET_START_DATE AND 
													  M.BUCKET_END_DATE 
				/*
               -------------------------------------- 
               --  MEASURE 1 OPEN_QTY 
               -------------------------------------- 
               LEFT OUTER JOIN TB_CM_ACTUAL_SALES AS T_OPEN_QTY
                                   ON M.ITEM_ID = T_OPEN_QTY.ITEM_MST_ID 
									  AND M.ACCOUNT_ID = T_OPEN_QTY.ACCOUNT_ID
                                      AND T_OPEN_QTY.SO_STATUS_ID = (
												SELECT ID
												FROM TB_CM_COMM_CONFIG
												WHERE CONF_GRP_CD = 'DP_SO_STATUS'
													AND CONF_CD = 'OPEN'
													) 
									  AND T_OPEN_QTY.BASE_DATE BETWEEN 
                                          M.BUCKET_START_DATE AND 
                                          M.BUCKET_END_DATE 

--				 UNION ALL 
               -------------------------------------- 
               --  MEASURE 2 OPEN_AMT 
               -------------------------------------- 
              LEFT OUTER JOIN TB_CM_ACTUAL_SALES AS T_OPEN_AMT
                        ON M.ITEM_ID = T_OPEN_AMT.ITEM_MST_ID 
							AND M.ACCOUNT_ID = T_OPEN_AMT.ACCOUNT_ID
                            AND T_OPEN_AMT.SO_STATUS_ID = (
									SELECT ID
									FROM TB_CM_COMM_CONFIG
									WHERE CONF_GRP_CD = 'DP_SO_STATUS'
										AND CONF_CD = 'OPEN'
										)
							AND T_OPEN_AMT.BASE_DATE BETWEEN 
                                M.BUCKET_START_DATE AND 
                                M.BUCKET_END_DATE 

--             UNION ALL 
			   -------------------------------------- 
               --  MEASURE 3 SHIPPED_QTY 
               -------------------------------------- 
				LEFT OUTER JOIN TB_CM_ACTUAL_SALES AS T_SHIPPED_QTY
							ON M.ITEM_ID = T_SHIPPED_QTY.ITEM_MST_ID 
								AND M.ACCOUNT_ID = T_SHIPPED_QTY.ACCOUNT_ID
								AND T_SHIPPED_QTY.SO_STATUS_ID = (
										SELECT ID
										FROM TB_CM_COMM_CONFIG
										WHERE CONF_GRP_CD = 'DP_SO_STATUS'
											AND CONF_CD = 'SHIP'
											)
								AND T_SHIPPED_QTY.BASE_DATE BETWEEN 
									M.BUCKET_START_DATE AND 
									M.BUCKET_END_DATE 

--               UNION ALL 

               -------------------------------------- 
               --  MEASURE 4 SHIPPED_AMT 
               -------------------------------------- 
                LEFT OUTER JOIN TB_CM_ACTUAL_SALES AS T_SHIPPED_AMT 
                            ON M.ITEM_ID = T_SHIPPED_AMT.ITEM_MST_ID 
							    AND M.ACCOUNT_ID = T_SHIPPED_AMT.ACCOUNT_ID
                                AND T_SHIPPED_AMT.SO_STATUS_ID = (
										SELECT ID
										FROM TB_CM_COMM_CONFIG
										WHERE CONF_GRP_CD = 'DP_SO_STATUS'
											AND CONF_CD = 'SHIP'
											)
								AND T_SHIPPED_AMT.BASE_DATE BETWEEN 
                                    M.BUCKET_START_DATE AND 
                                    M.BUCKET_END_DATE 

									*/

GROUP BY 	  
          M.BUCKET_START_DATE
		, CASE WHEN V_DIMENSION_01_ACTV_YN = 'Y' THEN ITEM_LVL01_CD	    ELSE NULL END 
		, CASE WHEN V_DIMENSION_02_ACTV_YN = 'Y' THEN ITEM_LVL01_NM       ELSE NULL END
		, CASE WHEN V_DIMENSION_03_ACTV_YN = 'Y' THEN ITEM_LVL02_CD	    ELSE NULL END 
		, CASE WHEN V_DIMENSION_04_ACTV_YN = 'Y' THEN ITEM_LVL02_NM       ELSE NULL END 
		, CASE WHEN V_DIMENSION_05_ACTV_YN = 'Y' THEN ITEM_LVL03_CD       ELSE NULL END
		, CASE WHEN V_DIMENSION_06_ACTV_YN = 'Y' THEN ITEM_LVL03_NM       ELSE NULL END 
		, CASE WHEN V_DIMENSION_07_ACTV_YN = 'Y' THEN ITEM_LVL04_CD       ELSE NULL END
		, CASE WHEN V_DIMENSION_08_ACTV_YN = 'Y' THEN ITEM_LVL04_NM       ELSE NULL END
		, CASE WHEN V_DIMENSION_09_ACTV_YN = 'Y' THEN ITEM_LVL05_CD       ELSE NULL END
		, CASE WHEN V_DIMENSION_10_ACTV_YN = 'Y' THEN ITEM_LVL05_NM       ELSE NULL END
		, CASE WHEN V_DIMENSION_11_ACTV_YN = 'Y' THEN ITEM_LVL06_CD       ELSE NULL END
		, CASE WHEN V_DIMENSION_12_ACTV_YN = 'Y' THEN ITEM_LVL06_NM       ELSE NULL END
		, CASE WHEN V_DIMENSION_13_ACTV_YN = 'Y' THEN ITEM_LVL07_CD       ELSE NULL END
		, CASE WHEN V_DIMENSION_14_ACTV_YN = 'Y' THEN ITEM_LVL07_NM       ELSE NULL END
		, CASE WHEN V_DIMENSION_15_ACTV_YN = 'Y' THEN ITEM_LVL08_CD       ELSE NULL END
		, CASE WHEN V_DIMENSION_16_ACTV_YN = 'Y' THEN ITEM_LVL08_NM       ELSE NULL END
		, CASE WHEN V_DIMENSION_17_ACTV_YN = 'Y' THEN ITEM_LVL09_CD       ELSE NULL END
		, CASE WHEN V_DIMENSION_18_ACTV_YN = 'Y' THEN ITEM_LVL09_NM       ELSE NULL END
		, CASE WHEN V_DIMENSION_19_ACTV_YN = 'Y' THEN ITEM_LVL10_CD       ELSE NULL END
		, CASE WHEN V_DIMENSION_20_ACTV_YN = 'Y' THEN ITEM_LVL10_NM       ELSE NULL END

        -- ACCOUNT
		, CASE WHEN V_DIMENSION_21_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_CD       ELSE NULL END 
		, CASE WHEN V_DIMENSION_22_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_NM       ELSE NULL END 
		, CASE WHEN V_DIMENSION_23_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_CD       ELSE NULL END 
		, CASE WHEN V_DIMENSION_24_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_NM	    ELSE NULL END 
		, CASE WHEN V_DIMENSION_25_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_CD       ELSE NULL END
		, CASE WHEN V_DIMENSION_26_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_NM       ELSE NULL END 
		, CASE WHEN V_DIMENSION_27_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_CD       ELSE NULL END 
		, CASE WHEN V_DIMENSION_28_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_NM       ELSE NULL END 
		, CASE WHEN V_DIMENSION_29_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_CD       ELSE NULL END 
		, CASE WHEN V_DIMENSION_30_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_NM	    ELSE NULL END 
		, CASE WHEN V_DIMENSION_31_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_CD       ELSE NULL END
		, CASE WHEN V_DIMENSION_32_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_NM       ELSE NULL END 
		, CASE WHEN V_DIMENSION_33_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_CD       ELSE NULL END 
		, CASE WHEN V_DIMENSION_34_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_NM       ELSE NULL END 
		, CASE WHEN V_DIMENSION_35_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_CD       ELSE NULL END 
		, CASE WHEN V_DIMENSION_36_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_NM	    ELSE NULL END 
		, CASE WHEN V_DIMENSION_37_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_CD       ELSE NULL END
		, CASE WHEN V_DIMENSION_38_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_NM       ELSE NULL END 
		, CASE WHEN V_DIMENSION_39_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_CD       ELSE NULL END
		, CASE WHEN V_DIMENSION_40_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_NM       ELSE NULL END 
        , CASE V_LAST_ITEM_LV WHEN 1             THEN  ITEM_LVL01_CD
                              WHEN 2             THEN  ITEM_LVL01_CD
                              WHEN 3             THEN  ITEM_LVL02_CD
                              WHEN 4             THEN  ITEM_LVL02_CD
                              WHEN 5             THEN  ITEM_LVL03_CD
                              WHEN 6             THEN  ITEM_LVL03_CD
                              WHEN 7             THEN  ITEM_LVL04_CD
                              WHEN 8             THEN  ITEM_LVL04_CD
                              WHEN 9             THEN  ITEM_LVL05_CD
                              WHEN 10            THEN  ITEM_LVL05_CD
                              WHEN 11            THEN  ITEM_LVL06_CD
                              WHEN 12            THEN  ITEM_LVL06_CD
                              WHEN 13            THEN  ITEM_LVL07_CD
                              WHEN 14            THEN  ITEM_LVL07_CD
                              WHEN 15            THEN  ITEM_LVL08_CD
                              WHEN 16            THEN  ITEM_LVL08_CD
                              WHEN 17            THEN  ITEM_LVL09_CD
                              WHEN 18            THEN  ITEM_LVL09_CD
                              WHEN 19            THEN  ITEM_LVL10_CD
                              WHEN 20            THEN  ITEM_LVL10_CD
							  END	

        , CASE V_LAST_ACCT_LV WHEN 21            THEN  ACCOUNT_LVL01_CD
                              WHEN 22            THEN  ACCOUNT_LVL01_CD
                              WHEN 23            THEN  ACCOUNT_LVL02_CD
                              WHEN 24            THEN  ACCOUNT_LVL02_CD
                              WHEN 25            THEN  ACCOUNT_LVL03_CD
                              WHEN 26            THEN  ACCOUNT_LVL03_CD
                              WHEN 27            THEN  ACCOUNT_LVL04_CD
                              WHEN 28            THEN  ACCOUNT_LVL04_CD
                              WHEN 29            THEN  ACCOUNT_LVL05_CD
                              WHEN 30            THEN  ACCOUNT_LVL05_CD
                              WHEN 31            THEN  ACCOUNT_LVL06_CD
                              WHEN 32            THEN  ACCOUNT_LVL06_CD
                              WHEN 33            THEN  ACCOUNT_LVL07_CD
                              WHEN 34            THEN  ACCOUNT_LVL07_CD
                              WHEN 35            THEN  ACCOUNT_LVL08_CD
                              WHEN 36            THEN  ACCOUNT_LVL08_CD
                              WHEN 37            THEN  ACCOUNT_LVL09_CD
                              WHEN 38            THEN  ACCOUNT_LVL09_CD
                              WHEN 39            THEN  ACCOUNT_LVL10_CD
                              WHEN 40            THEN  ACCOUNT_LVL10_CD
                END
		;





BEGIN 
---------------------------------------------------------------------------------
    -- ？？？？？？？？？ DIMENSION ？？？？？ ？？？？ ？？？？ ？？ ？？？？？？？？
    ---- 20？？？？？？ DIMENSION？？ ？？？？ ？？？？？？？ ？？？？？？ ？？ (？？？？？？)
---------------------------------------------------------------------------------
SELECT   MAX(CASE WHEN FLD_CD = 'DIMENSION_01' THEN ACTV_YN ELSE NULL END) 
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_02' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_03' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_04' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_05' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_06' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_07' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_08' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_09' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_10' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_11' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_12' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_13' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_14' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_15' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_16' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_17' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_18' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_19' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_20' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_21' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_22' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_23' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_24' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_25' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_26' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_27' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_28' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_29' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_30' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_31' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_32' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_33' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_34' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_35' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_36' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_37' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_38' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_39' THEN ACTV_YN ELSE NULL END)
       , MAX(CASE WHEN FLD_CD = 'DIMENSION_40' THEN ACTV_YN ELSE NULL END)
	   INTO
		 V_DIMENSION_01_ACTV_YN 
	   , V_DIMENSION_02_ACTV_YN 
	   , V_DIMENSION_03_ACTV_YN 
	   , V_DIMENSION_04_ACTV_YN 
	   , V_DIMENSION_05_ACTV_YN 
	   , V_DIMENSION_06_ACTV_YN 
	   , V_DIMENSION_07_ACTV_YN 
	   , V_DIMENSION_08_ACTV_YN 
	   , V_DIMENSION_09_ACTV_YN 
	   , V_DIMENSION_10_ACTV_YN 
	   , V_DIMENSION_11_ACTV_YN 
	   , V_DIMENSION_12_ACTV_YN 
	   , V_DIMENSION_13_ACTV_YN 
	   , V_DIMENSION_14_ACTV_YN 
	   , V_DIMENSION_15_ACTV_YN 
	   , V_DIMENSION_16_ACTV_YN 
	   , V_DIMENSION_17_ACTV_YN 
	   , V_DIMENSION_18_ACTV_YN 
	   , V_DIMENSION_19_ACTV_YN 
	   , V_DIMENSION_20_ACTV_YN 
       -- ACCOUNT
	   , V_DIMENSION_21_ACTV_YN 
	   , V_DIMENSION_22_ACTV_YN 
	   , V_DIMENSION_23_ACTV_YN 
	   , V_DIMENSION_24_ACTV_YN 
	   , V_DIMENSION_25_ACTV_YN 
	   , V_DIMENSION_26_ACTV_YN 
	   , V_DIMENSION_27_ACTV_YN 
	   , V_DIMENSION_28_ACTV_YN 
	   , V_DIMENSION_29_ACTV_YN 
	   , V_DIMENSION_30_ACTV_YN 
	   , V_DIMENSION_31_ACTV_YN 
	   , V_DIMENSION_32_ACTV_YN 
	   , V_DIMENSION_33_ACTV_YN 
	   , V_DIMENSION_34_ACTV_YN 
	   , V_DIMENSION_35_ACTV_YN 
	   , V_DIMENSION_36_ACTV_YN 
	   , V_DIMENSION_37_ACTV_YN 
	   , V_DIMENSION_38_ACTV_YN 
	   , V_DIMENSION_39_ACTV_YN 
	   , V_DIMENSION_40_ACTV_YN 
FROM ( 
--		SELECT	 A.UI_ID
--				,A.GRID_ID
--				,A.AUTH_TP
--				,A.FIELD_ID
--				,A.FIELD_VAL
--				,A.FIELD_NM
--				,A.DIM_MEASURE_TP
--				,A.PIVOT_ITEM_CD
--				,A.SEQ AS SEQ_1, B.SEQ AS SEQ_2
--				, NVL(B.DATA_KEY_YN,NVL(A.DATA_KEY_YN,'N'))  AS DATA_KEY_YN 
--				, NVL(B.ACTV_YN,NVL(A.ACTV_YN,'N'))			 AS ACTV_YN -- MODIFY BY MHY 
--				, ROW_NUMBER() OVER( ORDER BY A.FIELD_ID)   AS ROW_NUM 
--		FROM	PERSONAL_MGMT_DTL_TP_02 A 
--				LEFT OUTER JOIN PERSONAL_TP_02 B 
--							ON	A.UI_ID		= B.UI_ID
--							AND A.GRID_ID	= B.GRID_ID
--							AND A.AUTH_TP	= B.AUTH_TP
--							AND	A.FIELD_ID	= B.FIELD_ID
--							AND B.USER_ID	= P_USER_ID
--		WHERE   A.UI_ID		= 'UI_DP_28'
--		AND     A.PIVOT_ITEM_CD = 'GROUP-COLUMNS'
--		AND		A.AUTH_TP	= 'COMMON'
--		AND		A.GRID_ID	= 'RST_CPT_01'


--        SELECT B.VIEW_CD
--             , B.GRID_CD
--             , A.FLD_CD
--             , A.FLD_APPLY_CD
--             , A.DIM_MEASURE_TP
--             , A.CROSSTAB_ITEM_CD
--             , A.FLD_SEQ AS SEQ_1
--             , NVL(A.DATA_KEY_YN,'N')  AS DATA_KEY_YN 
--             , NVL(A.APPLY_YN,'N')			 AS ACTV_YN -- MODIFY BY MHY 
--             , ROW_NUMBER() OVER( ORDER BY A.FLD_CD)   AS ROW_NUM 
--          FROM tb_ad_user_pref A
--         INNER JOIN TB_AD_USER_PREF_MST B ON A.USER_PREF_MST_ID = B.ID
--         WHERE B.VIEW_CD = 'UI_DP_28'
--           AND A.CROSSTAB_ITEM_CD='GROUP-COLUMNS'
--           AND B.GRID_CD = 'RST_CPT_01'
--           AND A.USER_ID = (SELECT ID FROM TB_AD_USER WHERE USERNAME=p_USER_ID)


        SELECT	 m.VIEW_CD
                ,m.GRID_CD
                ,A.FLD_CD
                ,A.REFER_VALUE
                ,A.FLD_APPLY_CD
                ,A.DIM_MEASURE_TP
                ,A.CROSSTAB_ITEM_CD
                ,A.FLD_SEQ AS SEQ_1, B.FLD_SEQ AS SEQ_2
                , COALESCE(B.DATA_KEY_YN,COALESCE(A.DATA_KEY_YN,'N'))  AS DATA_KEY_YN 
                , COALESCE(B.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N'))			 AS ACTV_YN 
                , ROW_NUMBER() OVER( ORDER BY A.FLD_CD)   AS ROW_NUM 
        FROM	TB_AD_USER_PREF_DTL A 
                inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = 'UI_DP_28'  AND m.GRID_CD	= 'RST_CPT_01'
                inner join TB_AD_GROUP g on g.ID = A.GRP_ID 
                inner join TB_AD_USER u on u.USERNAME = p_USER_ID
                inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
                LEFT OUTER JOIN TB_AD_USER_PREF B 
                            ON	m.id = B.USER_PREF_MST_ID	AND A.GRP_ID	= B.GRP_ID	AND	A.FLD_CD	= B.FLD_CD	AND B.USER_ID	= u.ID
        WHERE    A.CROSSTAB_ITEM_CD = 'GROUP-COLUMNS'





       )
GROUP BY  CROSSTAB_ITEM_CD
;
---- =========================================
-- ？？？？？ ITEM & ACCOUNT LV ？？？？
---- =========================================
--    SELECT TO_NUMBER(SUBSTR(MAX(FIELD_ID), 11,2))        INTO V_LAST_ITEM_LV
--      FROM PERSONAL_TP_02
--     WHERE 1=1
--       AND UI_ID = 'UI_DP_28'
--       AND GRID_ID = 'RST_CPT_01'
--       AND AUTH_TP = 'COMMON'
--       AND ACTV_YN = 'Y'
--       AND DIM_MEASURE_TP = 'DIMENSION'
--       AND SUBSTR(FIELD_ID, 11,2) BETWEEN 1 AND 20
--      ;

      SELECT TO_NUMBER(SUBSTR(MAX(FLD_CD), 11,2)) INTO V_LAST_ITEM_LV
        FROM TB_AD_USER_PREF_DTL A
       INNER JOIN TB_AD_USER_PREF_MST B ON A.USER_PREF_MST_ID = B.ID
       WHERE 1=1
         AND B.VIEW_CD = 'UI_DP_28'
         AND B.GRID_CD = 'RST_CPT_01'
         AND A.APPLY_YN='Y'
         AND A.DIM_MEASURE_TP = 'DIMENSION'
         AND SUBSTR(FLD_CD, 11,2) BETWEEN 1 AND 20
       ;

--    SELECT TO_NUMBER(SUBSTR(MAX(FIELD_ID), 11,2))        INTO V_LAST_ACCT_LV
--      FROM PERSONAL_TP_02
--     WHERE 1=1
--       AND UI_ID = 'UI_DP_28'
--       AND GRID_ID = 'RST_CPT_01'
--       AND AUTH_TP = 'COMMON'
--       AND ACTV_YN = 'Y'
--       AND DIM_MEASURE_TP = 'DIMENSION'
--       AND SUBSTR(FIELD_ID, 11,2) BETWEEN 21 AND 40
--       ;
      SELECT TO_NUMBER(SUBSTR(MAX(FLD_CD), 11,2)) INTO V_LAST_ACCT_LV
        FROM TB_AD_USER_PREF_DTL A
       INNER JOIN TB_AD_USER_PREF_MST B ON A.USER_PREF_MST_ID = B.ID
       WHERE 1=1
         AND B.VIEW_CD = 'UI_DP_28'
         AND B.GRID_CD = 'RST_CPT_01'
         AND A.APPLY_YN='Y'
         AND A.DIM_MEASURE_TP = 'DIMENSION'
         AND SUBSTR(FLD_CD, 11,2) BETWEEN 21 AND 40
       ;
---- =========================================
-- VERSION ID
---- =========================================
         SELECT MAX(A.ID) KEEP(DENSE_RANK FIRST ORDER BY A.VER_ID DESC)
              , MAX(B.CL_LV_MGMT_ID) KEEP(DENSE_RANK FIRST ORDER BY A.VER_ID DESC)          
           INTO V_VER_ID, V_AUTH_TP_ID
           FROM TB_DP_CONTROL_BOARD_VER_MST A 
                INNER JOIN
                TB_DP_CONTROL_BOARD_VER_DTL B
             ON(A.ID = B.CONBD_VER_MST_ID)
          WHERE 1=1
            AND A.PLAN_TP_ID = P_PLAN_TP_ID
            AND B.CL_STATUS_ID = (
                                    SELECT ID 
                                      FROM TB_CM_COMM_CONFIG
                                    WHERE CONF_CD  = 'CLOSE' 
                                      AND CONF_GRP_CD = 'DP_CL_STATUS' --ID = '29DDA85D473247DB92FED4ECBE08329D'
                                  )     
            AND B.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_gRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
--                SELECT  MAX(A.ID) KEEP(DENSE_RANK FIRST ORDER BY A.VER_ID DESC), MAX(B.AUTH_TP_ID) KEEP(DENSE_RANK FIRST ORDER BY A.VER_ID DESC) INTO V_VER_ID, V_AUTH_TP_ID
--                  FROM TB_DP_CONTROL_BOARD_VER_MST A 
--                       INNER JOIN
--                       TB_DP_ENTRY B
--                    ON(A.ID = B.VER_ID )
--                 WHERE A.PLAN_TP_ID = P_PLAN_TP_ID
                ;
----  ========================================
--  CODE   SETTING 
----   =======================================


			SELECT ID INTO V_SO_STATUS_OPEN_ID
			FROM TB_CM_COMM_CONFIG 
			WHERE CONF_GRP_CD = 'DP_SO_STATUS'
			AND CONF_CD = 'OPEN'
			;

			SELECT ID INTO V_SO_STATUS_SHIPPED_ID
			FROM TB_CM_COMM_CONFIG 
			WHERE CONF_GRP_CD = 'DP_SO_STATUS'
			AND CONF_CD = 'SHIP'
			;

----------------------------------------------------------------------------------
    -- item level ？？？ ITEM CODE？？ ？？？？？？？ ？？？？？ Validation
----------------------------------------------------------------------------------
--V_ITEM_CHECK

IF(P_ITEM_LV_CD IS NOT NULL OR P_ITEM_CD IS NOT NULL)
    THEN
    -- ITEM_LV_CD, ITEM_CD Validation
    SELECT COUNT(*) INTO V_ITEM_CHECK 
      FROM TB_CM_ITEM_MST
     WHERE 1=1 
       AND REGEXP_LIKE (UPPER(ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
       AND NVL(DEL_YN,'N') = 'N'
       AND DP_PLAN_YN = 'Y'
     ;
    SELECT COUNT(*) INTO V_ITEM_LV_CHECK 
      FROM TB_CM_ITEM_LEVEL_MGMT
     WHERE 1=1 
       AND ITEM_LV_CD = P_ITEM_LV_CD
       AND NVL(DEL_YN,'N') = 'N'   
    ;
    IF(V_ITEM_CHECK !=0)    
        THEN    -- ITEM ？？？？？？ ？？？？？？ SEQ ？？？？？？
             SELECT MAX(SEARCH_LV_SEQ)+1 INTO V_SEARCH_LV_SEQ
                FROM(        SELECT  DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ
                          FROM TB_CM_ITEM_LEVEL_MGMT IL
                               INNER JOIN
                               TB_CM_LEVEL_MGMT LV
                            ON(IL.LV_MGMT_ID = LV.ID)
                         WHERE 1=1
                           AND NVL(IL.DEL_YN,'N') = 'N'
                           AND NVL(LV.DEL_YN,'N') = 'N'   
                    )A       
                    ;
     ELSIF(V_ITEM_LV_CHECK != 0) -- account level ？？？？？？ SEQ ？？？？？？
        THEN
        SELECT SEARCH_LV_SEQ INTO V_SEARCH_LV_SEQ
        FROM(
            SELECT  IL.ITEM_LV_CD
                  , DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ
              FROM TB_CM_ITEM_LEVEL_MGMT IL
                   INNER JOIN
                   TB_CM_LEVEL_MGMT LV
                ON(IL.LV_MGMT_ID = LV.ID)
             WHERE 1=1
               AND NVL(IL.DEL_YN,'N') = 'N'
               AND NVL(LV.DEL_YN,'N') = 'N'   
               ) A
        WHERE A.ITEM_LV_CD = P_ITEM_LV_CD
                ;
--        ELSE
--                V_ERR_MSG := 'MSG_0020';     
--                 RAISE_APPLICATION_ERROR(-20001, V_ERR_MSG);            
        END IF;
--        SELECT  										   
--             CASE WHEN V_DIMENSION_01_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 1  THEN  1	    
--    --			  WHEN V_DIMENSION_02_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 1  THEN  1     
--                  WHEN V_DIMENSION_03_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 2  THEN  1	    
--    --			  WHEN V_DIMENSION_04_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 2  THEN  1     
--                  WHEN V_DIMENSION_05_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 3  THEN  1     
--    --			  WHEN V_DIMENSION_06_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 3  THEN  1     
--                  WHEN V_DIMENSION_07_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 4  THEN  1     
--    --			  WHEN V_DIMENSION_08_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 4  THEN  1     
--                  WHEN V_DIMENSION_09_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 5  THEN  1	    
--    --			  WHEN V_DIMENSION_10_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 5  THEN  1     
--                  WHEN V_DIMENSION_11_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 6  THEN  1     
--    --			  WHEN V_DIMENSION_12_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 6  THEN  1     
--                  WHEN V_DIMENSION_13_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 7  THEN  1     
--    --			  WHEN V_DIMENSION_14_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 7  THEN  1     
--                  WHEN V_DIMENSION_15_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 8  THEN  1     
--    --			  WHEN V_DIMENSION_16_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 8  THEN  1     
--                  WHEN V_DIMENSION_17_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 9  THEN  1     
--    --			  WHEN V_DIMENSION_18_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 9  THEN  1     
--                  WHEN V_DIMENSION_19_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 10 THEN  1     
--    --			  WHEN V_DIMENSION_20_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ = 10 THEN  1     
--             ELSE 0
--             END INTO V_ERR_STATUS
--        FROM DUAL
--        ;
--        IF(V_ERR_STATUS=1)
--            THEN
--                V_ERR_MSG := '？？？？？ account level ？？ ？？？？ ？？？？ ？？？？？？？.';     
--                 RAISE_APPLICATION_ERROR(-20001, V_ERR_MSG);
--        END IF;
END IF;
----------------------------------------------------------------------------------
    -- ACCOUNT LEVEL ？？？ ACCOUNT CODE？？ ？？？？？？？ ？？？？？ Validation
----------------------------------------------------------------------------------
IF(P_ACCT_LV_CD IS NOT NULL OR P_ACCT_CD IS NOT NULL)
    THEN
    -- ACCT_LV_CD, ACCT_CD Validation
    SELECT COUNT(*) INTO V_ACCT_CHECK 
      FROM TB_DP_ACCOUNT_MST
     WHERE 1=1
       AND REGEXP_LIKE (UPPER(ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
       AND NVL(DEL_YN,'N') = 'N'
       AND ACTV_YN = 'Y'
     ;
    SELECT COUNT(*) INTO V_ACCT_LV_CHECK 
      FROM TB_DP_SALES_LEVEL_MGMT
     WHERE 1=1
       AND SALES_LV_CD = P_ACCT_LV_CD
        AND NVL(DEL_YN,'N') = 'N'   
    ;    
    IF(V_ACCT_CHECK != 0)    
        THEN    -- ACCOUNT ？？？？？？ ？？？？？？ SEQ ？？？？？？
             SELECT MAX(SEARCH_LV_SEQ)+1 INTO V_SEARCH_LV_SEQ_02
                FROM(        SELECT  DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ
                          FROM TB_DP_SALES_LEVEL_MGMT SL
                               INNER JOIN
                               TB_CM_LEVEL_MGMT LV
                            ON(SL.LV_MGMT_ID = LV.ID)
                         WHERE 1=1
                           AND NVL(SL.DEL_YN,'N') = 'N'
                           AND NVL(LV.DEL_YN,'N') = 'N'   
                    )A       
                    ;
    ELSIF(V_ACCT_LV_CHECK != 0) -- ACCOUNT LEVEL ？？？？？？ SEQ ？？？？？？
        THEN
            SELECT SEARCH_LV_SEQ_02 INTO V_SEARCH_LV_SEQ_02
            FROM (
            SELECT SL.SALES_LV_CD
                  , DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ_02
              FROM TB_DP_SALES_LEVEL_MGMT SL
                   INNER JOIN
                   TB_CM_LEVEL_MGMT LV
                ON(SL.LV_MGMT_ID = LV.ID)
             WHERE 1=1
               AND NVL(SL.DEL_YN,'N') = 'N'
               AND NVL(LV.DEL_YN,'N') = 'N'   
               ) A
            WHERE A.SALES_LV_CD = P_ACCT_LV_CD
                ;
--        ELSE 
--                V_ERR_MSG := 'MSG_0020';     
--                 RAISE_APPLICATION_ERROR(-20001, V_ERR_MSG);           
        END IF;
--        SELECT  										   
--             CASE WHEN V_DIMENSION_21_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 1  THEN  1	    
--    --			  WHEN V_DIMENSION_22_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 1  THEN  1     
--                  WHEN V_DIMENSION_23_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 2  THEN  1	    
--    --			  WHEN V_DIMENSION_24_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 2  THEN  1     
--                  WHEN V_DIMENSION_25_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 3  THEN  1     
--    --			  WHEN V_DIMENSION_26_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 3  THEN  1     
--                  WHEN V_DIMENSION_27_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 4  THEN  1     
--    --			  WHEN V_DIMENSION_28_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 4  THEN  1     
--                  WHEN V_DIMENSION_29_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 5  THEN  1	    
--    --			  WHEN V_DIMENSION_30_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 5  THEN  1     
--                  WHEN V_DIMENSION_31_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 6  THEN  1     
--    --			  WHEN V_DIMENSION_32_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 6  THEN  1     
--                  WHEN V_DIMENSION_33_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 7  THEN  1     
--    --			  WHEN V_DIMENSION_34_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 7  THEN  1     
--                  WHEN V_DIMENSION_35_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 8  THEN  1     
--    --			  WHEN V_DIMENSION_36_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 8  THEN  1     
--                  WHEN V_DIMENSION_37_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 9  THEN  1     
--    --			  WHEN V_DIMENSION_38_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 9  THEN  1     
--                  WHEN V_DIMENSION_39_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 10 THEN  1     
--    --			  WHEN V_DIMENSION_40_ACTV_YN = 'N' AND V_SEARCH_LV_SEQ_02 = 10 THEN  1     
--             ELSE 0
--             END INTO V_ERR_STATUS
--        FROM DUAL
--        ;
--        IF(V_ERR_STATUS=1)
--            THEN
--                V_ERR_MSG := '？？？？？ account level ？？ ？？？？？？？？ ？？？？？？？.';     
--                 RAISE_APPLICATION_ERROR(-20001, V_ERR_MSG);
--        END IF;
END IF;     
----  ========================================
-- ITEM * MEASURE   SETTING 
----   =======================================

	OPEN C_DATA_IMPORT;
	FETCH C_DATA_IMPORT BULK COLLECT INTO C_DP_TEMP_SALES_REPORT;
	CLOSE C_DATA_IMPORT;
RETURN C_DP_TEMP_SALES_REPORT;

END;
/

