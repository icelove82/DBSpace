create PROCEDURE "SP_UI_CM_08_POP_01_Q" (
    P_CONF_KEY              IN VARCHAR2 := '',
    P_SHPP_LEADTIME_DTL_ID  IN VARCHAR2 := '',
    pResult                 OUT SYS_REFCURSOR
)
IS
BEGIN

    IF P_CONF_KEY = 'DAILY' /* SCHEDULE - DAILY */
    THEN
        OPEN pResult FOR 
            SELECT A.MON_YN
                 , A.TUE_YN
                 , A.WED_YN
                 , A.THU_YN
                 , A.FRI_YN
                 , A.SAT_YN
                 , A.SUN_YN
                 , A.ACTV_YN
              FROM TB_CM_SHIP_LT_DAILY_SCH A 
             WHERE A.SHPP_LEADTIME_DTL_ID = P_SHPP_LEADTIME_DTL_ID;
    
    ELSIF P_CONF_KEY = 'MONTHLY' /* SCHEDULE - MONTHLY */
    THEN
        OPEN pResult FOR 
        WITH DOM (DD) AS (
            SELECT 1 AS DD FROM DUAL
        ), DAY_OF_MONTH (DD) AS (
            SELECT DD FROM DOM
            UNION ALL
            SELECT (DD + 1) FROM DAY_OF_MONTH 
            WHERE DD <= 30
        )
        SELECT CASE WHEN B.DD IS NULL THEN A.DD ELSE B.DD END AS DD,
               CASE WHEN B.ACTV_YN IS NULL THEN A.ACTV_YN ELSE B.ACTV_YN END AS ACTV_YN
          FROM (
               SELECT TO_CHAR(DD) AS DD
                    , 'N' AS ACTV_YN
                 FROM DAY_OF_MONTH
               ) A
               LEFT OUTER JOIN 
               (
                SELECT RTRIM(A.DD) AS DD
                     , ACTV_YN
                  FROM TB_CM_SHIP_LT_MONTHLY_SCH A
                 WHERE A.SHPP_LEADTIME_DTL_ID = P_SHPP_LEADTIME_DTL_ID
               ) B
               ON A.DD = B.DD;
    
    ELSIF P_CONF_KEY = 'EXCEPT_DAILY' /* EXCEPTION - DAILY */
    THEN
        OPEN pResult FOR 
            SELECT A.ID
                 , A.STRT_DATE
                 , A.END_DATE
                 , A.MON_YN
                 , A.TUE_YN
                 , A.WED_YN
                 , A.THU_YN
                 , A.FRI_YN
                 , A.SAT_YN
                 , A.SUN_YN
                 , A.ACTV_YN
              FROM TB_CM_SHIP_LT_EXCEPTION_SCH A 
             WHERE A.SHPP_LEADTIME_DTL_ID = P_SHPP_LEADTIME_DTL_ID
               AND A.TRANSFER_DD IS NULL;
    
    ELSIF P_CONF_KEY = 'EXCEPT_MONTHLY' /* EXCEPTION - MONTHLY */
    THEN
        OPEN pResult FOR 
            SELECT A.ID
                 , A.STRT_DATE
                 , A.END_DATE
                 , A.TRANSFER_DD
                 , A.ACTV_YN
              FROM TB_CM_SHIP_LT_EXCEPTION_SCH A
             WHERE A.SHPP_LEADTIME_DTL_ID = P_SHPP_LEADTIME_DTL_ID
               AND A.TRANSFER_DD IS NOT NULL;
    
    ELSIF P_CONF_KEY = 'HOLIDAY' /* HOLIDAY */
    THEN
        OPEN pResult FOR
            SELECT A.ID 
                 , A.SHPP_LEADTIME_DTL_ID
                 , A.CALENDAR_ID
                 , A.CALENDAR_DESCRIP       AS CALENDAR_DESC
                 , A.STRT_DATE
                 , A.END_DATE
                 , A.CYCL_TP_ID             AS CYCLE_TYPE
                 , A.ACTV_YN
              FROM TB_CM_HOLIDAY A
             WHERE A.SHPP_LEADTIME_DTL_ID = P_SHPP_LEADTIME_DTL_ID;

    END IF;

END;

/

