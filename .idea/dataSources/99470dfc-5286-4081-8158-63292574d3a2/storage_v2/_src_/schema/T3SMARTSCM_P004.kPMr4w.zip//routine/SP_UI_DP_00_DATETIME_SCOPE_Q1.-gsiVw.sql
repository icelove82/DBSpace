create PROCEDURE "SP_UI_DP_00_DATETIME_SCOPE_Q1" (
									 P_UI_ID				IN VARCHAR2 :=''
									,P_TIME_UOM_CD			IN VARCHAR2 :=''	/* DATEADD 함수의 TYPE 으로 */
									,P_FROM_DATETIME_VAL	IN INT	    :=NULL	/*오늘날짜 기준으로 시간단위체크해서 몇을 감(가)산 할지 계산 */
									,P_TO_DATETIME_VAL		IN INT		:=NULL	/*오늘날짜 기준으로 시간단위체크해서 몇을 감(가)산 할지 계산 */			
                                    , pRESULT               OUT SYS_REFCURSOR                                    
								   ) IS 
/*****************************************************************************
Title : SP_UI_DP_00_DATETIME_SCOPE_Q1
최초 작성자 : 김소희
최초 생성일 : 2018.04.19
？
설명  
 - DP 날짜/시간 조회 범위 값 설정 (FROM_DATE, TO_DATE)
？
History (수정일자 / 수정자 / 수정내용)
- 2018.04.19 / 김소희 / 최초 작성
- 2018.07.19 / 김소희 / version 정보를 갖고올 경우 추가
？
*****************************************************************************/
    V_VER_CNT   INT :=0;
    P_ERR_STATUS  INT :=0;
BEGIN
        /* VERSION 정보 없을 경우 */
        SELECT COUNT(*) INTO V_VER_CNT
          FROM TB_DP_CONTROL_BOARD_VER_MST
         ;
        /* P_TIME_UOM_CD, FROM_DATETIME_VAL, P_TO_DATETIME_VAL 이 없을 경우 */
--        SELECT COUNT(ATTR_01) INTO P_ERR_STATUS
--          FROM TB_CM_COMM_CONFIG
--         WHERE 1=1
--         AND CONF_GRP_CD = 'DP_POLICY'
--         AND CONF_CD = 'BUCKET'
--         ;
--         IF(P_ERR_STATUS !=0 AND P_TIME_UOM_CD = NULL)
--            THEN
--                SELECT CASE ATTR_01 WHEN 'PW' THEN 'W' ELSE ATTR_01 END INTO P_TIME_UOM_CD
--                  FROM TB_CM_COMM_CONFIG
--                 WHERE 1=1
--                 AND CONF_GRP_CD = 'DP_POLICY'
--                 AND CONF_CD = 'BUCKET'
--                 ;
--            END IF;
--        SELECT COUNT(ATTR_01) INTO P_ERR_STATUS
--          FROM TB_CM_COMM_CONFIG
--         WHERE 1=1
--         AND CONF_GRP_CD = 'DP_POLICY'
--         AND CONF_CD = 'HORIZON'
--         ;       
--         IF(P_ERR_STATUS !=0 AND P_FROM_DATETIME_VAL IS NULL)
--            THEN         
--                SELECT ATTR_01 INTO P_FROM_DATETIME_VAL
--                  FROM TB_CM_COMM_CONFIG
--                 WHERE 1=1
--                 AND CONF_GRP_CD = 'DP_POLICY'
--                 AND CONF_CD = 'HORIZON'
--                 ;
--         END IF;

		/* 화면별 날짜값 세팅 */
		IF(P_UI_ID = 'UI_ZN_05')
			THEN
                OPEN pRESULT
                FOR
				SELECT  P_FROM_DATETIME_VAL+ SYSDATE		AS FROM_DATE
					  , P_TO_DATETIME_VAL  + SYSDATE		AS TO_DATE
				FROM DUAL;                   
        ELSIF(P_UI_ID = 'UI_DP_07')
            THEN
                OPEN pRESULT
                FOR                        
                SELECT MAX(DECODE(RW,1,BASE_DATE)) AS TO_DATE
                     , NVL(MAX(DECODE(RW,2,BASE_DATE))+1,MAX(BASE_DATE)) AS FROM_DATE
                  FROM (
                        SELECT BASE_DATE, ROW_NUMBER() OVER (ORDER BY BASE_DATE desc) AS RW
                          FROM TB_DP_EXCHANGE_RATE
                         GROUP BY BASE_DATE    
                        ) A 
                 WHERE RW <= 2 
                 ;
        ELSIF(P_UI_ID = 'UI_DP_21')
            THEN
                OPEN pRESULT
                FOR            
                SELECT MAX(DECODE(RW,1,BASE_DATE)) AS TO_DATE
                     , NVL(MAX(DECODE(RW,2,BASE_DATE))+1,MAX(BASE_DATE))  AS FROM_DATE
                  FROM (
                        SELECT BASE_DATE, ROW_NUMBER() OVER (ORDER BY BASE_DATE desc) AS RW
                          FROM TB_DP_UNIT_PRICE   
                        GROUP BY BASE_DATE    
                        ) A 
                 WHERE RW <= 2 
                 ;            
        /* VERSION 정보를 불러오고 싶을 경우 */
        ELSIF(P_UI_ID = 'VERSION' AND V_VER_CNT != 0)
            THEN
                OPEN pRESULT
                FOR
                SELECT  FROM_DATE
                      , TO_DATE
                  FROM (
                        SELECT FROM_DATE, TO_DATE, ROW_NUMBER () OVER( ORDER BY VER_ID DESC ) AS ROWN
                          FROM TB_DP_CONTROL_BOARD_VER_MST
                         WHERE PLAN_TP_ID = (SELECT ID
                                               FROM TB_CM_COMM_CONFIG
                                              WHERE CONF_GRP_CD = 'DP_PLAN_TYPE'
                                                AND DEFAT_VAL = 'Y'
                                              )
                      ) A
                WHERE ROWN = 1
                ;                
		/* 시간 단위 따져서 DATETIME 범위 계산 */
		ELSE			
                OPEN pRESULT
                FOR
				SELECT CASE UPPER(P_TIME_UOM_CD)
							WHEN 'YEAR'   THEN ADD_MONTHS( SYSDATE, P_FROM_DATETIME_VAL*12)
							WHEN 'MONTH'  THEN ADD_MONTHS(SYSDATE, P_FROM_DATETIME_VAL)
							WHEN 'WEEK'   THEN P_FROM_DATETIME_VAL*7		+ SYSDATE
							WHEN 'DAY'    THEN P_FROM_DATETIME_VAL			+ SYSDATE
							WHEN 'HOUR'   THEN P_FROM_DATETIME_VAL/24		+ SYSDATE
							WHEN 'MINUTE' THEN P_FROM_DATETIME_VAL/24/60	+ SYSDATE
							WHEN 'SECOND' THEN P_FROM_DATETIME_VAL/24/60/60	+ SYSDATE
						END AS FROM_DATE
					  ,CASE UPPER(P_TIME_UOM_CD)
							WHEN 'YEAR'   THEN ADD_MONTHS(SYSDATE, P_TO_DATETIME_VAL*12) 
							WHEN 'MONTH'  THEN ADD_MONTHS(SYSDATE, P_TO_DATETIME_VAL) 
							WHEN 'WEEK'   THEN P_TO_DATETIME_VAL*7			+ SYSDATE 
							WHEN 'DAY'    THEN P_TO_DATETIME_VAL			+ SYSDATE 
							WHEN 'HOUR'   THEN P_TO_DATETIME_VAL/24			+ SYSDATE 
							WHEN 'MINUTE' THEN P_TO_DATETIME_VAL/24/60		+ SYSDATE 
							WHEN 'SECOND' THEN P_TO_DATETIME_VAL/24/60/60	+ SYSDATE 
						END AS TO_DATE				 
				FROM DUAL;
			END IF;	
END;

/

