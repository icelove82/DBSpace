create PACKAGE BODY                 PKG_SMP_O_RESULT IS
PRAGMA SERIALLY_REUSABLE;
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved.
**************************************************************************
* Name    : PKG_SMP_O_RESULT
* Purpose :  MP RESULT 정보 생성.
* Notes   :
* 1. Line 운영계획 결과 집계 
*  - TB_SMP_RS_LINE_PROD
* 2. RTF Report 결과 집계 
*  - TB_SMP_RS_RTF
* 3. 자재소요계획 결과 집계 
*  - TB_SMP_RS_RM_CONSUME_P1
*  - TB_SMP_RS_RM_CONSUME_P2
*  - TB_SMP_RS_RM_CONSUME_V
***************************************************************************
* History :
* 2020-02-27 JMS Created
**************************************************************************/ 

-----------------------------
-- Public type declarations -
-----------------------------

---------------------------------
-- Public constant declarations -
---------------------------------

---------------------------------
-- Public variable declarations -
---------------------------------
  G_nLOG_SEQ      NUMBER;
  G_sPROGRAM_ID   VARCHAR2(50); --:= DBMS_UTILITY.FORMAT_CALL_STACK;
  G_sSTEP_SEQ     VARCHAR2(50);
  G_sSTEP_DESC    VARCHAR2(2000);
  G_sVERSION_ID   VARCHAR2(50);
  G_sUSER_ID      VARCHAR2(50);
  G_nSQL_CNT      NUMBER;
  G_sLOGMSG       VARCHAR2(4000);
---------------------------------
-- Public function declarations -
---------------------------------

----------------------------------
-- Public procedure declarations -
----------------------------------

PROCEDURE SP_GET_RESULT_LINE_PROD (
  P_sENGINE_ID       IN  VARCHAR2
, P_sVERSION_ID      IN  VARCHAR2
, P_sPDB_VERSION_ID  IN  VARCHAR2
, P_sROLLING_FLAG    IN  VARCHAR2
, P_sBASE_YEAR       IN  VARCHAR2
, P_sBASE_MONTH      IN  VARCHAR2
, O_FLAG             OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_GET_RESULT_LINE_PROD
* Purpose : Global Line 운영 계획 결과집계
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-27 JMS Created
**************************************************************************/
IS
---------------------------------
-- Private variable declarations -
---------------------------------
 
BEGIN
  O_FLAG := 'S';
  G_sPROGRAM_ID := 'PKG_SMP_O_RESULT' ||'.'|| 'SP_GET_RESULT_LINE_PROD';
  G_sVERSION_ID := P_sVERSION_ID;
 
    
    G_sSTEP_SEQ := '1.0';
    G_sSTEP_DESC := 'DELETE Data : Same Version Result';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
      DELETE FROM TB_SMP_RS_LINE_PROD
      WHERE VERSION_ID = P_sVERSION_ID
      ;
    
      DELETE FROM TB_SMP_RS_LINE_PROD_SEMI
      WHERE VERSION_ID = P_sVERSION_ID
      ;
     
  --PKG_SMP_LOGGER.stepDEBUG (G_nLOG_SEQ, sTEST_STR, G_sVERSION_ID, G_sUSER_ID);
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '2.0';
    G_sSTEP_DESC := 'CREATE Data : TB_SMP_RS_LINE_PROD_SEMI - Fix';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
    PKG_SMP_LOGGER.stepDEBUG (G_nLOG_SEQ, P_sPDB_VERSION_ID, G_sVERSION_ID, G_sUSER_ID);
    
        INSERT INTO TB_SMP_RS_LINE_PROD_SEMI
        ( VERSION_ID, SITE_CD, LINE_CD, PGM_D_CD, DEMAND_ID, PLAN_YEAR, PLAN_MONTH
        , OEM_CD, CELL_CD, ITEM_CD
        , LINE_CAPA_MIN, MIN_PER_QTY
        , QTY, FORM_QTY, JC_CAPA_MIN, JC_CNT
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM, UPDATE_USER_ID
        )
        SELECT P_sVERSION_ID AS VERSION_ID
             , FIX.SITE_CD, FIX.LINE_CD
             , 'FIX_PGM_' || LPAD(TO_CHAR(FIX.PGM_SEQ), 3, '0') AS PGM_D_CD
             , 'FIX_DMD_ID_' || LPAD(TO_CHAR(FIX.DMD_SEQ), 3, '0') AS DEMAND_ID
             , FIX.PLAN_YEAR, FIX.PLAN_MONTH
             , FIX.OEM_CD, FIX.CELL_CD, FIX.ITEM_CD
             , CPA.T_CAPA_MIN       AS LINE_CAPA_MIN
             , RES.PROCESS_CAPACITY AS MIN_PER_QTY
             , FIX.QTY, FIX.FORM_QTY, FIX.JC_CAPA_MIN, FIX.JC_CNT
             , SYSDATE, 'SYSTEM', NULL, NULL
          FROM (
                SELECT FIX.SITE_CD, FIX.ITEM_CD, FIX.LINE_CD
                     , DENSE_RANK() OVER (PARTITION BY FIX.SITE_CD, FIX.LINE_CD, FIX.ITEM_CD ORDER BY FIX.PLAN_MONTH) AS PGM_SEQ
                     , ROW_NUMBER() OVER (ORDER BY FIX.SITE_CD, FIX.LINE_CD, FIX.ITEM_CD, FIX.PLAN_MONTH) AS DMD_SEQ
                     , FIX.PLAN_YEAR, FIX.PLAN_MONTH
                     , FIX.OEM_CD, FIX.CELL_CD, FIX.QTY, FIX.FORM_QTY, FIX.JC_CAPA_MIN, FIX.JC_CNT 
                  FROM TB_SMP_FIXED_PROD FIX
                     , TB_SMP_SITE_MST   STM
                     , (-- 조립 확정 계획만 가져온다.
                        SELECT ITM.ITEM_CD
                          FROM TB_SMP_ITEM_MST ITM
                             , (
                                SELECT PNM.PN_CD
                                  FROM TB_SMP_ITEM_BASE_INFO PNM
                                     , ( --조립 Item Code 에 해당하는 소재단위 구분 정보
                                        SELECT ATTR_02
                                          FROM TB_CM_COMM_CONFIG 
                                         WHERE CONF_GRP_CD = 'ITEM_ROUTE_MAP'
                                           AND ACTV_YN = 'Y'
                                           AND USE_YN = 'Y'
                                          AND ATTR_01 = 'BAS'
                                       ) CFG
                                 WHERE PNM.ATTR_01 = CFG.ATTR_02
                               ) PNM
                         WHERE ITM.PN_CD = PNM.PN_CD
                       ) ITM
                 WHERE FIX.SITE_CD = STM.SITE_CD
                   AND FIX.PLAN_MONTH >= P_sBASE_MONTH
                   AND FIX.PLAN_MONTH <  TO_CHAR(ADD_MONTHS(TO_DATE(P_sBASE_MONTH, 'YYYYMM'), STM.MP_FIXED_MM_VAL), 'YYYYMM')
                   AND FIX.ITEM_CD = ITM.ITEM_CD
               ) FIX
             , (
                SELECT DISTINCT BOR.SITE_CD, BOR.ITEM_CD, BOR.LINE_CD, BOR.PROCESS_CAPACITY
                  FROM TB_SMP_WK_BOR BOR
                     --, (
                     --   SELECT CONF_CD AS ROUTE_CD, CONF_NM AS ROUTE_NM, PRIORT AS SEQ
                     --     FROM TB_CM_COMM_CONFIG
                     --    WHERE CONF_GRP_CD = 'ROUTE'
                     --      AND NVL(ACTV_YN, 'N') = 'Y'
                     --      AND NVL(USE_YN, 'N') = 'Y'
                     --      AND ATTR_04 = 'A' -- 조립인 공정만.
                     --  ) ROU
                     , (-- 해당 Item 만 집계
                        SELECT ITM.ITEM_CD
                          FROM TB_SMP_ITEM_MST ITM
                             , (
                                SELECT PNM.PN_CD
                                  FROM TB_SMP_ITEM_BASE_INFO PNM
                                     , (
                                        SELECT ATTR_02
                                          FROM TB_CM_COMM_CONFIG 
                                         WHERE CONF_GRP_CD = 'ITEM_ROUTE_MAP'
                                           AND ACTV_YN = 'Y'
                                           AND USE_YN = 'Y'
                                           AND ATTR_01 = 'BAS'
                                       ) CFG
                                 WHERE PNM.ATTR_01 = CFG.ATTR_02
                               ) PNM
                         WHERE ITM.PN_CD = PNM.PN_CD
                       ) ITM
                 WHERE BOR.VERSION_ID = P_sVERSION_ID --'AIS_TEST01_V1' 
                   --AND BOR.ROUTE_CD = ROU.ROUTE_CD
                   AND BOR.ITEM_CD = ITM.ITEM_CD
               ) RES
             , TB_SMP_LINE_CAPA CPA
         WHERE FIX.SITE_CD = RES.SITE_CD
           AND FIX.ITEM_CD = RES.ITEM_CD
           AND FIX.LINE_CD = RES.LINE_CD
           AND FIX.SITE_CD = CPA.SITE_CD
           AND FIX.LINE_CD = CPA.LINE_CD
           AND FIX.PLAN_MONTH = CPA.BASE_MONTH
        ;
     
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
 
    G_sSTEP_SEQ := '3.0';
    G_sSTEP_DESC := 'CREATE Data : TB_SMP_RS_LINE_PROD_SEMI - Plan';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
    PKG_SMP_LOGGER.stepDEBUG (G_nLOG_SEQ, P_sPDB_VERSION_ID, G_sVERSION_ID, G_sUSER_ID);
 
        INSERT INTO TB_SMP_RS_LINE_PROD_SEMI
        ( VERSION_ID, SITE_CD, LINE_CD, PGM_D_CD, DEMAND_ID, PLAN_YEAR, PLAN_MONTH
        , OEM_CD, CELL_CD, ITEM_CD
        , LINE_CAPA_MIN, MIN_PER_QTY
        , QTY, FORM_QTY, JC_CAPA_MIN, JC_CNT
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM, UPDATE_USER_ID
        )
        SELECT P_sVERSION_ID AS VERSION_ID --'AIS_TEST01_V1' 
             , RST.SITE_CD
             , RST.LINE_CD
             , RST.PGM_D_CD
             , RST.SALESORDER_ID
             , RST.PLAN_YEAR
             , RST.PLAN_MONTH
             , RST.OEM_CD
             , RST.CELL_CD
             , RST.ITEM_CD
             , CASE WHEN RST.BUCKET_UNIT = 'M'
                    THEN MAX(RST.LINE_CAPA_MIN)
                    ELSE SUM(RST.LINE_CAPA_MIN)
                    END AS LINE_CAPA_MIN             
             , MAX(RST.MIN_PER_QTY) AS MIN_PER_QTY
             , SUM(RST.OUTPUT_QTY) AS QTY
             , SUM(RST.OUTPUT_QTY) AS FORM_QTY             
             , CASE WHEN MAX(RST.MIN_PER_QTY) > SUM(RST.JC_CAPA_MIN)
                    THEN 0
                    ELSE SUM(RST.JC_CAPA_MIN) 
                     END AS JC_CAPA_MIN --20200422 1개 생산 Capa 보다 J/C 시간이 작은 경우엔 J/C 가 발생하지 않았다고 보고 예외처리 한다.
             , CASE WHEN SUM(RST.JC_CAPA_MIN) > 0
                    THEN 
                         CASE WHEN MAX(RST.MIN_PER_QTY) > SUM(RST.JC_CAPA_MIN)
                              THEN 0
                              ELSE 1
                              END
                    ELSE 0
                    END AS JC_CNT
             --, SUM(RST.JC_CNT) AS JC_CNT
             --, SUM(RST.OUTPUT_QTY) * MAX(RST.MIN_PER_QTY) AS CALC
             , SYSDATE, 'SYSTEM', NULL, NULL
          FROM (
                SELECT RES.SITE_CD
                     , RST.RESOURCE_ID AS LINE_CD
                     , DMD.PGM_D_CD
                     , RST.SALESORDER_ID
                     , TO_CHAR(RST.START_DATE, 'YYYY') AS PLAN_YEAR
                     , CASE WHEN P_sROLLING_FLAG = 'Y'
                                THEN 
                                     CASE WHEN TO_CHAR(RST.START_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 4)
                                          THEN TO_CHAR(RST.START_DATE, 'YYYYMM')        -- ex: 202003
                                          ELSE TO_CHAR(RST.START_DATE, 'YYYY') || '12'  -- ex: 202012
                                          END
                                ELSE 
                                     CASE WHEN TO_CHAR(RST.START_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 3)
                                          THEN TO_CHAR(RST.START_DATE, 'YYYYMM')
                                          ELSE TO_CHAR(RST.START_DATE, 'YYYY') || '12'
                                          END
                                END AS PLAN_MONTH
                     , CASE WHEN 'N' = 'Y'
                                THEN 
                                     CASE WHEN TO_CHAR(RST.START_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 4)
                                          THEN 'M'
                                          ELSE 'Y'
                                          END
                                ELSE 
                                     CASE WHEN TO_CHAR(RST.START_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 3)
                                          THEN 'M'
                                          ELSE 'Y'
                                          END
                                END AS BUCKET_UNIT
                     , DMD.OEM_CD, DMD.CELL_CD, RES.ITEM_CD
                     , RES.PROCESS_CAPACITY
                     , RST.CAPACITY AS LINE_CAPA_MIN --, RST.SETUP_CAPACITY 보류
                     , RES.PROCESS_CAPACITY AS MIN_PER_QTY
                     , RST.USED_CAPACITY
                     --, RST.CAPACITY / RES.PROCESS_CAPACITY AS LINE_CAPA_QTY                     
                     , RST.USED_CAPACITY / RES.PROCESS_CAPACITY AS OUTPUT_QTY
                     --, RST.OUTPUT_QTY
                     --, RST.JC_CNT
                     , RST.JC_CAPA_MIN
                  FROM (
                        SELECT RST.VERSION_ID, RST.RESOURCE_ID
                             --, NVL(RST.SALESORDER_ID, ORD.SALESORDER_ID) AS SALESORDER_ID
                             , RST.SALESORDER_ID
                             , RST.ROUTE_ID
                             , RST.START_DATE
                             --, RST.END_DATE
                             , RST.USED_CAPACITY
                             --, RST.OUTPUT_QTY
                             --, NVL(ORD.CONSUMPTION_QTY, RST.OUTPUT_QTY) AS OUTPUT_QTY
                             --, CASE WHEN RST.SETUP_CAPACITY > 0 THEN 1 ELSE 0 END AS JC_CNT
                             --, CASE WHEN RST.SETUP_CAPACITY > 0 AND RST.USED_CAPACITY > 0
                             --       THEN 1
                             --       ELSE 0
                             --       END AS JC_CNT
                             , RST.SETUP_CAPACITY AS JC_CAPA_MIN
                             --, RST.OUTPUT_QTY
                             , CAP.CAPACITY
                          FROM RESULT_RESOURCE_PLAN RST
                             , RESULT_ACTIVITY DMD
                             , RESOURCE_CAPACITY CAP
                             --, (
                             --   SELECT VERSION_ID
                             --        , CONSUMPTION_ACTIVITY_ID
                             --        , PRODUCTION_ACTIVITY_ID
                             --        , PRODUCTION_PO_ID  AS PLANNEDORDER_ID
                             --        , CONSUMPTION_SO_ID AS SALESORDER_ID
                             --        , CONSUMPTION_QTY   AS CONSUMPTION_QTY
                             --     FROM RESULT_ORDER_CONNECTION
                             --    WHERE VERSION_ID = P_sPDB_VERSION_ID --'AIS01_20.02.27.18.26.27'
                             --      AND PRODUCTION_PO_ID LIKE 'PLO%'
                             --      AND CONSUMPTION_SO_ID IS NOT NULL
                             --  ) ORD
                         WHERE RST.VERSION_ID = P_sPDB_VERSION_ID --'AIS01_20.02.27.18.26.27'
                           AND DMD.ROUTE_ID IS NOT NULL
                           AND DMD.QTY > 0
                           --AND RST.OUTPUT_QTY > 0
                           AND RST.VERSION_ID = DMD.VERSION_ID 
                           AND RST.ROUTE_ACTIVITY_ID = DMD.ACTIVITY_ID
                           AND RST.RESOURCE_ID       = DMD.RESOURCE_ID
                           AND CAP.ENGINE_ID   = P_sENGINE_ID --'AIS_TEST01'
                           AND RST.RESOURCE_ID = CAP.RESOURCE_ID 
                           AND RST.START_DATE >= CAP.START_DATE
                           AND RST.START_DATE <  CAP.END_DATE
                           --AND RST.VERSION_ID  = ORD.VERSION_ID(+)
                           --AND RST.INVENTORY_ACTIVITY_ID = ORD.PRODUCTION_ACTIVITY_ID(+)
                      ) RST
                    , ( 
                       SELECT DISTINCT DMD.DEMAND_ID AS SALESORDER_ID
                            , DMD.PGM_D_CD
                            , DMD.OEM_CD 
                            , DMD.CELL_CD
                         FROM TB_SMP_WK_DEMAND DMD
                        WHERE VERSION_ID   = P_sVERSION_ID --'AIS_TEST01_V1'
                          AND USE_FLAG = 'Y'
                      ) DMD
                    , (
                       SELECT DISTINCT BOR.ROUTE_ID, BOR.SITE_CD, BOR.ITEM_CD, BOR.LINE_CD, BOR.PROCESS_CAPACITY
                         FROM TB_SMP_WK_BOR BOR
                            --, (
                            --   SELECT CONF_CD AS ROUTE_CD, CONF_NM AS ROUTE_NM, PRIORT AS SEQ
                            --     FROM TB_CM_COMM_CONFIG
                            --    WHERE CONF_GRP_CD = 'ROUTE'
                            --      AND NVL(ACTV_YN, 'N') = 'Y'
                            --      AND NVL(USE_YN, 'N') = 'Y'
                            --      AND ATTR_04 = 'A' -- 조립인 공정만.
                            --  ) ROU
                            , (-- 해당 Item 만 집계
                               SELECT ITM.ITEM_CD
                                 FROM TB_SMP_ITEM_MST ITM
                                    , (
                                       SELECT PNM.PN_CD
                                         FROM TB_SMP_ITEM_BASE_INFO PNM
                                            , (
                                               SELECT ATTR_02
                                                 FROM TB_CM_COMM_CONFIG 
                                                WHERE CONF_GRP_CD = 'ITEM_ROUTE_MAP'
                                                  AND ACTV_YN = 'Y'
                                                  AND USE_YN = 'Y'
                                                  AND ATTR_01 = 'BAS'
                                              ) CFG
                                        WHERE PNM.ATTR_01 = CFG.ATTR_02
                                      ) PNM
                                WHERE ITM.PN_CD = PNM.PN_CD
                              ) ITM
                        WHERE BOR.VERSION_ID = P_sVERSION_ID --'AIS_TEST01_V1' 
                          --AND BOR.ROUTE_CD = ROU.ROUTE_CD
                          AND BOR.ITEM_CD = ITM.ITEM_CD
                      ) RES
                WHERE RST.SALESORDER_ID = DMD.SALESORDER_ID
                  AND RST.ROUTE_ID      = RES.ROUTE_ID
                  AND RST.RESOURCE_ID   = RES.LINE_CD
               ) RST
         GROUP BY RST.SITE_CD, RST.LINE_CD, RST.PGM_D_CD, RST.SALESORDER_ID, RST.PLAN_YEAR, RST.PLAN_MONTH, RST.OEM_CD, RST.CELL_CD, RST.ITEM_CD, RST.BUCKET_UNIT
        ;
      
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    COMMIT;
  
    G_sSTEP_SEQ := '4.0';
    G_sSTEP_DESC := 'CREATE Data : TB_SMP_RS_LINE_PROD';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
        INSERT INTO TB_SMP_RS_LINE_PROD
        ( VERSION_ID, SITE_CD, LINE_CD, PLAN_YEAR, PLAN_MONTH
        , OEM_CD, CELL_CD, ITEM_CD
        , LINE_CAPA_MIN, MIN_PER_QTY
        , QTY, FORM_QTY
        , ADJ_QTY, ADJ_FORM_QTY
        , JC_CNT, JC_CAPA_MIN 
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM, UPDATE_USER_ID
        )    
        SELECT VERSION_ID, SITE_CD, LINE_CD, PLAN_YEAR, PLAN_MONTH
             , OEM_CD, CELL_CD, ITEM_CD
             , MAX(LINE_CAPA_MIN), MAX(MIN_PER_QTY)
             , SUM(QTY), SUM(FORM_QTY)
             , SUM(QTY), SUM(FORM_QTY)
             , SUM(JC_CNT), SUM(JC_CAPA_MIN)
             , SYSDATE, 'SYSTEM', NULL, NULL
          FROM TB_SMP_RS_LINE_PROD_SEMI
         WHERE VERSION_ID = P_sVERSION_ID
         GROUP BY VERSION_ID, SITE_CD, LINE_CD, PLAN_YEAR, PLAN_MONTH, OEM_CD, CELL_CD, ITEM_CD
        ;

    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
    
  
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_FLAG := 'F';
    G_sLOGMSG   := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
    G_sLOGMSG   := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG, G_sVERSION_ID);

END;

PROCEDURE SP_GET_RESULT_RTF (
  P_sENGINE_ID       IN  VARCHAR2
, P_sVERSION_ID      IN  VARCHAR2
, P_sPDB_VERSION_ID  IN  VARCHAR2
, P_sROLLING_FLAG    IN  VARCHAR2
, P_sBASE_YEAR       IN  VARCHAR2
, P_sBASE_MONTH      IN  VARCHAR2
, O_FLAG             OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_GET_RESULT_RTF
* Purpose : RTF Report 결과집계
* Notes   : MEASURE_CD / MEASURE_NM
*           DEMAND     / Demand
*           RTF        / RTF
*           SHORT      / Shortage
*           BOH        / BOH
*           EOH        / EOH
*           ARRV       / Arrival
*           DEPT       / Departure
**************************************************************************
* History :
* 2020-02-27 JMS Created
**************************************************************************/
IS
---------------------------------
-- Private variable declarations -
---------------------------------
  P_sBOH_CUTOFF_DT VARCHAR(8);

BEGIN
  O_FLAG := 'S';
  G_sPROGRAM_ID := 'PKG_SMP_O_RESULT' ||'.'|| 'SP_GET_RESULT_RTF';
  G_sVERSION_ID := P_sVERSION_ID;
 
    
    G_sSTEP_SEQ := '1.0';
    G_sSTEP_DESC := 'Set Variable';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
       
        -- BOH 최신 Cutoff Date 확인
        SELECT MAX(CUTOFF_DATE)
          INTO P_sBOH_CUTOFF_DT
          FROM TB_SMP_VMI_BOH
         --WHERE CUTOFF_DATE >= ADD_MONTHS(SYSDATE, -3) --3개월 이전 Data 까지만 우선 검색
        ;
       
    --PKG_SMP_LOGGER.stepDEBUG (G_nLOG_SEQ, sTEST_STR, G_sVERSION_ID, G_sUSER_ID);
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
   
    G_sSTEP_SEQ := '2.0';
    G_sSTEP_DESC := 'DELETE Data : Same Version Result';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
        DELETE FROM TB_SMP_RS_RTF_SEMI
        WHERE VERSION_ID = P_sVERSION_ID
        ;
  
        DELETE FROM TB_SMP_RS_RTF
        WHERE VERSION_ID = P_sVERSION_ID
        ;
     
    --PKG_SMP_LOGGER.stepDEBUG (G_nLOG_SEQ, sTEST_STR, G_sVERSION_ID, G_sUSER_ID);
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
 
    G_sSTEP_SEQ := '3.0';
    G_sSTEP_DESC := 'CREATE Data : SP_GET_RESULT_RTF - Semi / DEMAND';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
    
        INSERT INTO TB_SMP_RS_RTF_SEMI
        ( VERSION_ID, OEM_CD, PGM_D_CD, DEMAND_ID, CELL_CD, SITE_CD, MEASURE_CD, PLAN_YEAR, PLAN_MONTH, QTY
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM, UPDATE_USER_ID
        )
        SELECT DMD.VERSION_ID 
             , DMD.OEM_CD
             , DMD.PGM_D_CD 
             , DMD.DEMAND_ID 
             , DMD.CELL_CD 
             , 'XXX' AS SITE_CD
             , 'DEMAND' AS MEASURE_CD
             , DMD.PLAN_YEAR
             , DMD.PLAN_MONTH
             , SUM(DMD.QTY) AS QTY
             , SYSDATE, 'SYSTEM', NULL, NULL
          FROM (
                SELECT DMD.VERSION_ID 
                     , DMD.OEM_CD
                     , DMD.PGM_D_CD 
                     , DMD.DEMAND_ID 
                     , DMD.CELL_CD
                     , TO_CHAR(DMD.DUE_DATE, 'YYYY') AS PLAN_YEAR
                     --, TO_CHAR(DMD.DUE_DATE, 'YYYYMM') AS PLAN_MONTH
                     , CASE WHEN P_sROLLING_FLAG = 'Y'
                            THEN 
                                 CASE WHEN TO_CHAR(DMD.DUE_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 4)
                                      THEN TO_CHAR(DMD.DUE_DATE, 'YYYYMM')        -- ex: 202003
                                      ELSE TO_CHAR(DMD.DUE_DATE, 'YYYY') || '12'  -- ex: 202012
                                      END
                            ELSE 
                                 CASE WHEN TO_CHAR(DMD.DUE_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 3)
                                      THEN TO_CHAR(DMD.DUE_DATE, 'YYYYMM')
                                      ELSE TO_CHAR(DMD.DUE_DATE, 'YYYY') || '12'
                                      END
                            END AS PLAN_MONTH
                     , DMD.QTY
                  FROM TB_SMP_WK_DEMAND DMD
                 WHERE DMD.VERSION_ID = P_sVERSION_ID --'AIS_TEST01_V1'
                   AND DMD.USE_FLAG = 'Y'
               ) DMD
         GROUP BY DMD.VERSION_ID, DMD.OEM_CD, DMD.PGM_D_CD, DMD.DEMAND_ID, DMD.CELL_CD, DMD.PLAN_YEAR, DMD.PLAN_MONTH
        ;
        
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
    
    G_sSTEP_SEQ := '4.0';
    G_sSTEP_DESC := 'CREATE Data : SP_GET_RESULT_RTF - Semi / RTF - Prod.';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
    
        INSERT INTO TB_SMP_RS_RTF_SEMI
        ( VERSION_ID, OEM_CD, PGM_D_CD, DEMAND_ID, CELL_CD, SITE_CD, MEASURE_CD, PLAN_YEAR, PLAN_MONTH, QTY
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM, UPDATE_USER_ID
        )
        WITH WT_RTF_RESULT
          AS (
              SELECT RST.VERSION_ID
                   , RST.SALESORDER_ID
                   , LOC.LOCATION_ID
                   , RST.DUE_DATE
                   , SUM(LOC.QTY) AS QTY
                FROM RESULT_SALESORDER RST
                   , (
                      SELECT RST.VERSION_ID, RST.SALESORDER_ID, RST.PLANNEDORDER_ID, ROU.SITE_CD AS LOCATION_ID, RST.QTY
                        FROM RESULT_ACTIVITY RST
                           , ROUTE ROU
                       WHERE RST.VERSION_ID = P_sPDB_VERSION_ID
                         --AND INV.ENGINE_ID = 'MP'
                         AND ROU.ENGINE_ID = P_sENGINE_ID
                         AND ROU.ROUTE_GRP_ID = 'BOD'
                         AND RST.ROUTE_ID  = ROU.ROUTE_ID
                     ) LOC                             
               WHERE RST.VERSION_ID = P_sPDB_VERSION_ID --'AIS01_20.02.27.18.26.27'
                 AND RST.VERSION_ID = LOC.VERSION_ID
                 AND RST.SALESORDER_ID = LOC.SALESORDER_ID
                 AND RST.PLANNEDORDER_ID = LOC.PLANNEDORDER_ID
               GROUP BY RST.VERSION_ID, RST.SALESORDER_ID, LOC.LOCATION_ID, RST.DUE_DATE
             )
        SELECT P_sVERSION_ID AS VERSION_ID
             , RST.OEM_CD
             , RST.PGM_D_CD 
             , RST.DEMAND_ID
             , RST.CELL_CD 
             , RST.SITE_CD
             , 'RTF' AS MEASURE_CD
             , RST.PLAN_YEAR
             , RST.PLAN_MONTH
             , SUM(RST.QTY) AS QTY
             , SYSDATE, 'SYSTEM', NULL, NULL
          FROM (
                SELECT DMD.OEM_CD
                     , DMD.PGM_D_CD 
                     , RST.SALESORDER_ID AS DEMAND_ID
                     , DMD.CELL_CD 
                     , RST.LOCATION_ID AS SITE_CD
                     , TO_CHAR(RST.DUE_DATE, 'YYYY') AS PLAN_YEAR
                     --, TO_CHAR(RST.DUE_DATE, 'YYYYMM') AS PLAN_MONTH
                     , CASE WHEN P_sROLLING_FLAG = 'Y'
                            THEN 
                                 CASE WHEN TO_CHAR(RST.DUE_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 4)
                                      THEN TO_CHAR(RST.DUE_DATE, 'YYYYMM')        -- ex: 202003
                                      ELSE TO_CHAR(RST.DUE_DATE, 'YYYY') || '12'  -- ex: 202012
                                      END
                            ELSE 
                                 CASE WHEN TO_CHAR(RST.DUE_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 3)
                                      THEN TO_CHAR(RST.DUE_DATE, 'YYYYMM')
                                      ELSE TO_CHAR(RST.DUE_DATE, 'YYYY') || '12'
                                      END
                            END AS PLAN_MONTH
                     , RST.QTY
                  FROM WT_RTF_RESULT RST 
                     , TB_SMP_WK_DEMAND DMD
                 WHERE 1=1
                   AND DMD.VERSION_ID = P_sVERSION_ID --'AIS_TEST01_V1'
                   AND DMD.USE_FLAG = 'Y'
                   AND RST.SALESORDER_ID = DMD.DEMAND_ID
               ) RST
         GROUP BY RST.OEM_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.CELL_CD, RST.SITE_CD, RST.PLAN_YEAR, RST.PLAN_MONTH
        ;
        
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '5.0';
    G_sSTEP_DESC := 'CREATE Data : SP_GET_RESULT_RTF - Semi / RTF - Stock';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
        MERGE INTO TB_SMP_RS_RTF_SEMI RST
        USING (
                WITH WT_RTF_RESULT
                AS (
                    SELECT RST.VERSION_ID
                         , RST.SALESORDER_ID
                         , LOC.LOCATION_ID
                         , RST.DUE_DATE
                         , SUM(LOC.QTY) AS QTY
                      FROM RESULT_SALESORDER RST
                         , (
                            SELECT RST.VERSION_ID, RST.ACTIVITY_ID, RST.SALESORDER_ID, RST.PLANNEDORDER_ID, VMI.SITE_CD AS LOCATION_ID, ABS(RST.QTY) AS QTY 
                              FROM RESULT_ACTIVITY RST
                                 , (
                                    SELECT STP.VERSION_ID, STP.CONSUMPTION_ACTIVITY_ID AS ACTIVITY_ID, STP.SALESORDER_ID, STP.INVENTORY_ID, STK.SITE_CD, INV.LOCATION_ID
                                      FROM RESULT_STOCK_PLAN STP
                                         , STOCK STK
                                         , INVENTORY INV
                                     WHERE STP.VERSION_ID = P_sPDB_VERSION_ID
                                       --AND STP.ITEM_ID = 'CH0200S001A'
                                       --AND STP.SALESORDER_ID = 'Daimler-003_202003(2)'
                                       AND STK.ENGINE_ID = P_sENGINE_ID
                                       AND INV.ENGINE_ID = P_sENGINE_ID
                                       AND STP.STOCK_ID = STK.STOCK_ID
                                       AND STP.INVENTORY_ID = INV.INVENTORY_ID
                                       AND STK.SITE_CD <> INV.LOCATION_ID --Inventory 의 Location 과 Stock 의 Site 가 다른경우는 VMI 창고 재고 이다.
                                   ) VMI
                             WHERE RST.VERSION_ID = P_sPDB_VERSION_ID
                               --AND RST.SALESORDER_ID = 'BAIC-002_202004(1)'
                               AND RST.VERSION_ID = VMI.VERSION_ID
                               AND RST.ACTIVITY_ID = VMI.ACTIVITY_ID
                           ) LOC                             
                     WHERE RST.VERSION_ID = P_sPDB_VERSION_ID --'AIS01_20.02.27.18.26.27'
                       AND RST.VERSION_ID = LOC.VERSION_ID
                       AND RST.SALESORDER_ID = LOC.SALESORDER_ID
                       AND RSt.DELIVERY_ACTIVITY_ID = LOC.ACTIVITY_ID
                       --AND RST.PLANNEDORDER_ID = LOC.PLANNEDORDER_ID
                     GROUP BY RST.VERSION_ID, RST.SALESORDER_ID, LOC.LOCATION_ID, RST.DUE_DATE
                   )
              SELECT P_sVERSION_ID AS VERSION_ID
                   , RST.OEM_CD
                   , RST.PGM_D_CD 
                   , RST.DEMAND_ID
                   , RST.CELL_CD 
                   , RST.SITE_CD
                   , 'RTF' AS MEASURE_CD
                   , RST.PLAN_YEAR
                   , RST.PLAN_MONTH
                   , SUM(RST.QTY) AS QTY
                FROM (
                      SELECT DMD.OEM_CD
                           , DMD.PGM_D_CD 
                           , RST.SALESORDER_ID AS DEMAND_ID
                           , DMD.CELL_CD 
                           , RST.LOCATION_ID AS SITE_CD
                           , TO_CHAR(RST.DUE_DATE, 'YYYY') AS PLAN_YEAR
                           --, TO_CHAR(RST.DUE_DATE, 'YYYYMM') AS PLAN_MONTH
                           , CASE WHEN P_sROLLING_FLAG = 'Y'
                                  THEN 
                                       CASE WHEN TO_CHAR(RST.DUE_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 4)
                                            THEN TO_CHAR(RST.DUE_DATE, 'YYYYMM')        -- ex: 202003
                                            ELSE TO_CHAR(RST.DUE_DATE, 'YYYY') || '12'  -- ex: 202012
                                            END
                                  ELSE 
                                       CASE WHEN TO_CHAR(RST.DUE_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 3)
                                            THEN TO_CHAR(RST.DUE_DATE, 'YYYYMM')
                                            ELSE TO_CHAR(RST.DUE_DATE, 'YYYY') || '12'
                                            END
                                  END AS PLAN_MONTH
                           , RST.QTY
                        FROM WT_RTF_RESULT RST 
                           , TB_SMP_WK_DEMAND DMD
                       WHERE 1=1
                         AND DMD.VERSION_ID = P_sVERSION_ID --'AIS_TEST01_V1'
                         AND DMD.USE_FLAG = 'Y'
                         AND RST.SALESORDER_ID = DMD.DEMAND_ID
                     ) RST
               GROUP BY RST.OEM_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.CELL_CD, RST.SITE_CD, RST.PLAN_YEAR, RST.PLAN_MONTH
              ) RTF
         ON (RST.VERSION_ID = RTF.VERSION_ID
         AND RST.OEM_CD     = RTF.OEM_CD
         AND RST.PGM_D_CD   = RTF.PGM_D_CD
         AND RST.DEMAND_ID  = RTF.DEMAND_ID
         AND RST.CELL_CD    = RTF.CELL_CD
         AND RST.SITE_CD    = RTF.SITE_CD
         AND RST.MEASURE_CD = RTF.MEASURE_CD
         AND RST.PLAN_YEAR  = RTF.PLAN_YEAR
         AND RST.PLAN_MONTH = RTF.PLAN_MONTH)
         WHEN MATCHED THEN
         UPDATE 
            SET RST.QTY = RST.QTY + RTF.QTY
              , RST.UPDATE_DTTM = SYSDATE
              , RST.UPDATE_USER_ID = 'SYSTEM'
         WHEN NOT MATCHED THEN
         INSERT ( RST.VERSION_ID, RST.OEM_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.CELL_CD, RST.SITE_CD, RST.MEASURE_CD, RST.PLAN_YEAR, RST.PLAN_MONTH, RST.QTY
                , RST.REG_DTTM, RST.REG_USER_ID, RST.UPDATE_DTTM, RST.UPDATE_USER_ID)
         VALUES ( RTF.VERSION_ID, RTF.OEM_CD, RTF.PGM_D_CD, RTF.DEMAND_ID, RTF.CELL_CD, RTF.SITE_CD, RTF.MEASURE_CD, RTF.PLAN_YEAR, RTF.PLAN_MONTH, RTF.QTY
                , SYSDATE, 'SYSTEM', NULL, NULL)
        ;
        
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
    
        
    G_sSTEP_SEQ := '6.0';
    G_sSTEP_DESC := 'CREATE Data : SP_GET_RESULT_RTF - Semi / SHORT';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
    
        INSERT INTO TB_SMP_RS_RTF_SEMI
        ( VERSION_ID, OEM_CD, PGM_D_CD, DEMAND_ID, CELL_CD, SITE_CD, MEASURE_CD, PLAN_YEAR, PLAN_MONTH, QTY
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM, UPDATE_USER_ID
        )
        SELECT P_sVERSION_ID AS VERSION_ID
             , DMD.OEM_CD
             , DMD.PGM_D_CD 
             , DMD.DEMAND_ID
             , DMD.CELL_CD 
             , 'XXX' AS SITE_CD
             , 'SHORT' AS MEASURE_CD
             , DMD.PLAN_YEAR
             , DMD.PLAN_MONTH
             , SUM(DMD.QTY) AS QTY
             , SYSDATE, 'SYSTEM', NULL, NULL
          FROM (
                SELECT DMD.OEM_CD
                     , DMD.PGM_D_CD 
                     , DMD.DEMAND_ID
                     , DMD.CELL_CD 
                     , TO_CHAR(DMD.DUE_DATE, 'YYYY') AS PLAN_YEAR
                     --, TO_CHAR(DMD.DUE_DATE, 'YYYYMM') AS PLAN_MONTH
                     , CASE WHEN P_sROLLING_FLAG = 'Y'
                            THEN 
                                 CASE WHEN TO_CHAR(DMD.DUE_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 4)
                                      THEN TO_CHAR(DMD.DUE_DATE, 'YYYYMM')        -- ex: 202003
                                      ELSE TO_CHAR(DMD.DUE_DATE, 'YYYY') || '12'  -- ex: 202012
                                      END
                            ELSE 
                                 CASE WHEN TO_CHAR(DMD.DUE_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 3)
                                      THEN TO_CHAR(DMD.DUE_DATE, 'YYYYMM')
                                      ELSE TO_CHAR(DMD.DUE_DATE, 'YYYY') || '12'
                                      END
                            END AS PLAN_MONTH
                     , RST.QTY
                  FROM TB_SMP_WK_DEMAND DMD
                     , (
                        --SELECT RST.SALESORDER_ID
                        --  FROM RESULT_PLAN_PROBLEM RST
                        -- WHERE RST.VERSION_ID = P_sPDB_VERSION_ID --'AIS01_20.02.27.18.26.27'
                        --   AND RST.PROBLEM_TYPE = 'SHORT'
                        SELECT RST.SALESORDER_ID, MAX(RST.REQUEST_QTY) - SUM(RST.DELIVERY_QTY) AS QTY
                          FROM RESULT_SALESORDER RST
                         WHERE RST.VERSION_ID = P_sPDB_VERSION_ID
                         GROUP BY RST.SALESORDER_ID
                       ) RST 
                 WHERE 1=1
                   AND DMD.VERSION_ID = P_sVERSION_ID --'AIS_TEST01_V1'
                   AND DMD.USE_FLAG = 'Y'
                   AND RST.QTY > 0
                   AND DMD.DEMAND_ID = RST.SALESORDER_ID
               ) DMD
         GROUP BY DMD.OEM_CD, DMD.PGM_D_CD, DMD.DEMAND_ID, DMD.CELL_CD, DMD.PLAN_YEAR, DMD.PLAN_MONTH
        ;
        
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
    
    
    G_sSTEP_SEQ := '7.0';
    G_sSTEP_DESC := 'CREATE Data : SP_GET_RESULT_RTF - Semi / DEPT';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
    
        INSERT INTO TB_SMP_RS_RTF_SEMI
        ( VERSION_ID, OEM_CD, PGM_D_CD, DEMAND_ID, CELL_CD, SITE_CD, MEASURE_CD, PLAN_YEAR, PLAN_MONTH, QTY
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM, UPDATE_USER_ID
        )
        SELECT P_sVERSION_ID AS VERSION_ID
             , RST.OEM_CD
             , RST.PGM_D_CD 
             , RST.DEMAND_ID
             , RST.CELL_CD 
             , RST.SITE_CD
             , 'DEPT' AS MEASURE_CD
             , RST.PLAN_YEAR
             , RST.PLAN_MONTH
             , SUM(RST.QTY) AS QTY
             , SYSDATE, 'SYSTEM', NULL, NULL
          FROM (
                SELECT DMD.OEM_CD
                     , DMD.PGM_D_CD 
                     , RST.SALESORDER_ID AS DEMAND_ID
                     , DMD.CELL_CD 
                     , RST.SITE_CD
                     , TO_CHAR(RST.DEPATURE_DATE, 'YYYY') AS PLAN_YEAR
                     --, TO_CHAR(RST.DEPATURE_DATE, 'YYYYMM') AS PLAN_MONTH
                     , CASE WHEN P_sROLLING_FLAG = 'Y'
                            THEN 
                                 CASE WHEN TO_CHAR(RST.DEPATURE_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 4)
                                      THEN TO_CHAR(RST.DEPATURE_DATE, 'YYYYMM')        -- ex: 202003
                                      ELSE TO_CHAR(RST.DEPATURE_DATE, 'YYYY') || '12'  -- ex: 202012
                                      END
                            ELSE 
                                 CASE WHEN TO_CHAR(RST.DEPATURE_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 3)
                                      THEN TO_CHAR(RST.DEPATURE_DATE, 'YYYYMM')
                                      ELSE TO_CHAR(RST.DEPATURE_DATE, 'YYYY') || '12'
                                      END
                            END AS PLAN_MONTH
                     , RST.QTY
                  FROM (
                        SELECT RST.SALESORDER_ID, RST.ROUTE_ID, RST.RESOURCE_ID
                             , RST.START_DATE AS DEPATURE_DATE
                             --, RST.END_DATE AS ARRIVAL_DATE
                             --, ADD_MONTHS(TO_DATE(TO_CHAR(RST.END_DATE, 'YYYYMM'), 'YYYYMM'), (-1)*BOD.LEAD_TIME)   AS DEPATURE_DATE
                             , BOD.SITE_CD
                             , RST.QTY
                             , BOD.LEAD_TIME
                          FROM RESULT_ACTIVITY RST
                             , TB_SMP_WK_BOR BOD
                         WHERE RST.VERSION_ID = P_sPDB_VERSION_ID
                           AND BOD.VERSION_ID = P_sVERSION_ID
                           AND BOD.ROUTE_CD = 'BOD'
                           --AND RST.SALESORDER_ID = 'PGM01-PK01_202004'
                           AND RST.ROUTE_ID = BOD.ROUTE_ID 
                           AND RST.RESOURCE_ID = BOD.LINE_CD
                       ) RST 
                     , TB_SMP_WK_DEMAND DMD
                 WHERE 1=1
                   AND DMD.VERSION_ID = P_sVERSION_ID --'AIS_TEST01_V1'
                   AND DMD.USE_FLAG = 'Y'
                   AND RST.SALESORDER_ID = DMD.DEMAND_ID
               ) RST
         GROUP BY RST.OEM_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.CELL_CD, RST.SITE_CD, RST.PLAN_YEAR, RST.PLAN_MONTH
        ;
          
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
    
    
    G_sSTEP_SEQ := '8.0';
    G_sSTEP_DESC := 'CREATE Data : SP_GET_RESULT_RTF - Semi / ARRV';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
    
        INSERT INTO TB_SMP_RS_RTF_SEMI
        ( VERSION_ID, OEM_CD, PGM_D_CD, DEMAND_ID, CELL_CD, SITE_CD, MEASURE_CD, PLAN_YEAR, PLAN_MONTH, QTY
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM, UPDATE_USER_ID
        )
        SELECT P_sVERSION_ID AS VERSION_ID
             , RST.OEM_CD
             , RST.PGM_D_CD 
             , RST.DEMAND_ID
             , RST.CELL_CD 
             , RST.SITE_CD
             , 'ARRV' AS MEASURE_CD
             , RST.PLAN_YEAR
             , RST.PLAN_MONTH
             , SUM(RST.QTY) AS QTY
             , SYSDATE, 'SYSTEM', NULL, NULL
          FROM (
                SELECT DMD.OEM_CD
                     , DMD.PGM_D_CD 
                     , RST.SALESORDER_ID AS DEMAND_ID
                     , DMD.CELL_CD 
                     , RST.SITE_CD
                     , TO_CHAR(RST.ARRIVAL_DATE, 'YYYY') AS PLAN_YEAR
                     --, TO_CHAR(RST.ARRIVAL_DATE, 'YYYYMM') AS PLAN_MONTH
                     , CASE WHEN P_sROLLING_FLAG = 'Y'
                            THEN 
                                 CASE WHEN TO_CHAR(RST.ARRIVAL_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 4)
                                      THEN TO_CHAR(RST.ARRIVAL_DATE, 'YYYYMM')        -- ex: 202003
                                      ELSE TO_CHAR(RST.ARRIVAL_DATE, 'YYYY') || '12'  -- ex: 202012
                                      END
                            ELSE 
                                 CASE WHEN TO_CHAR(RST.ARRIVAL_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 3)
                                      THEN TO_CHAR(RST.ARRIVAL_DATE, 'YYYYMM')
                                      ELSE TO_CHAR(RST.ARRIVAL_DATE, 'YYYY') || '12'
                                      END
                            END AS PLAN_MONTH
                     , RST.QTY
                  FROM (
                        SELECT RST.SALESORDER_ID, RST.ROUTE_ID, RST.RESOURCE_ID
                             --, RST.START_DATE AS DEPATURE_DATE
                             , RST.END_DATE   AS ARRIVAL_DATE
                             , BOD.SITE_CD
                             , RST.QTY
                             , BOD.LEAD_TIME
                          FROM RESULT_ACTIVITY RST
                             , TB_SMP_WK_BOR BOD
                         WHERE RST.VERSION_ID = P_sPDB_VERSION_ID
                           AND BOD.VERSION_ID = P_sVERSION_ID
                           AND BOD.ROUTE_CD = 'BOD'
                           --AND RST.SALESORDER_ID = 'PGM01-PK01_202004'
                           AND RST.ROUTE_ID = BOD.ROUTE_ID 
                           AND RST.RESOURCE_ID = BOD.LINE_CD
                       ) RST 
                     , TB_SMP_WK_DEMAND DMD
                 WHERE 1=1
                   AND DMD.VERSION_ID = P_sVERSION_ID --'AIS_TEST01_V1'
                   AND DMD.USE_FLAG = 'Y'
                   AND RST.SALESORDER_ID = DMD.DEMAND_ID
               ) RST
         GROUP BY RST.OEM_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.CELL_CD, RST.SITE_CD, RST.PLAN_YEAR, RST.PLAN_MONTH
        ;
       
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
    
    G_sSTEP_SEQ := '9.0';
    G_sSTEP_DESC := 'CREATE Data : SP_GET_RESULT_RTF / Semi -> Main';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
    
        INSERT INTO TB_SMP_RS_RTF
        ( VERSION_ID, OEM_CD, PGM_D_CD, CELL_CD, SITE_CD, MEASURE_CD, PLAN_YEAR, PLAN_MONTH, QTY
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM, UPDATE_USER_ID
        )
        SELECT VERSION_ID, OEM_CD, PGM_D_CD, CELL_CD, SITE_CD, MEASURE_CD, PLAN_YEAR, PLAN_MONTH, SUM(QTY) AS QTY
             , SYSDATE, 'SYSTEM', NULL, NULL
          FROM TB_SMP_RS_RTF_SEMI
         WHERE VERSION_ID = P_sVERSION_ID
         GROUP BY VERSION_ID, OEM_CD, PGM_D_CD, CELL_CD, SITE_CD, MEASURE_CD, PLAN_YEAR, PLAN_MONTH
        ;
  
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);    
    
    G_sSTEP_SEQ := '10.0';
    G_sSTEP_DESC := 'CREATE Data : SP_GET_RESULT_RTF / BOH and EOH';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);        
        
        INSERT INTO TB_SMP_RS_RTF
        ( VERSION_ID, OEM_CD, PGM_D_CD, CELL_CD, SITE_CD, MEASURE_CD, PLAN_YEAR, PLAN_MONTH, QTY
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM, UPDATE_USER_ID
        )
        WITH WT_BALANCE_STD 
          AS (
              SELECT STD.VERSION_ID, STD.OEM_CD, STD.PGM_D_CD, STD.CELL_CD, STD.SITE_CD
                   , CAL.PLAN_YEAR, CAL.PLAN_MONTH
                FROM (
                      SELECT RST.VERSION_ID, RST.OEM_CD, RST.PGM_D_CD, RST.CELL_CD, RST.SITE_CD
                        FROM TB_SMP_RS_RTF RST
                       WHERE RST.VERSION_ID = P_sVERSION_ID
                         AND RST.MEASURE_CD IN ('ARRV', 'RTF')
                       GROUP BY RST.VERSION_ID, RST.OEM_CD, RST.PGM_D_CD, RST.CELL_CD, RST.SITE_CD
                     ) STD
                   , (
                      SELECT DISTINCT CAL.YYYY AS PLAN_YEAR
                           , CASE WHEN P_sROLLING_FLAG = 'Y'
                                  THEN 
                                       CASE WHEN CAL.YYYY <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 4)
                                            THEN CAL.YYYYMM        -- ex: 202003
                                            ELSE CAL.YYYY|| '12'  -- ex: 202012
                                            END
                                  ELSE 
                                       CASE WHEN CAL.YYYY <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 3)
                                            THEN CAL.YYYYMM
                                            ELSE CAL.YYYY || '12'
                                            END
                                  END AS PLAN_MONTH
                        FROM TB_CM_CALENDAR CAL
                       WHERE CAL.YYYYMM >= P_sBASE_MONTH
                         AND CAL.YYYYMM <= CASE WHEN P_sROLLING_FLAG = 'Y'
                                                THEN TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 4 + 6)
                                                ELSE TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 3 + 6)
                                                END
                     ) CAL
             )
           , WT_EOH_CALC_STD
          AS (
              SELECT STD.VERSION_ID, STD.OEM_CD, STD.PGM_D_CD, STD.CELL_CD, STD.SITE_CD
                   , STD.PLAN_YEAR, STD.PLAN_MONTH
                   , NVL(BOH.BOH_QTY, 0) AS BOH_QTY
                   , NVL(RST.ARRV_QTY, 0) AS ARRV_QTY
                   , NVL(RST.RTF_QTY, 0) AS RTF_QTY
                FROM WT_BALANCE_STD STD
                   , (
                      SELECT SITE_CD, PGM_D_CD, P_sBASE_YEAR AS PLAN_YEAR, P_sBASE_MONTH AS PLAN_MONTH, STOCK_QTY AS BOH_QTY
                        FROM TB_SMP_VMI_BOH
                       WHERE CUTOFF_DATE = P_sBOH_CUTOFF_DT
                     ) BOH
                   , (
                      SELECT VERSION_ID, OEM_CD, PGM_D_CD, CELL_CD, SITE_CD
                           , PLAN_YEAR, PLAN_MONTH
                           , MAX(CASE WHEN MEASURE_CD  = 'ARRV' THEN QTY ELSE 0 END) AS ARRV_QTY
                           , MAX(CASE WHEN MEASURE_CD  = 'RTF'  THEN QTY ELSE 0 END) AS RTF_QTY
                        FROM TB_SMP_RS_RTF
                       WHERE VERSION_ID = P_sVERSION_ID
                         AND MEASURE_CD IN ('ARRV', 'RTF')
                       GROUP BY VERSION_ID, OEM_CD, PGM_D_CD, CELL_CD, SITE_CD
                              , PLAN_YEAR, PLAN_MONTH
                     ) RST
               WHERE STD.SITE_CD    = BOH.SITE_CD(+)
                 AND STD.PGM_D_CD   = BOH.PGM_D_CD(+)
                 AND STD.PLAN_YEAR  = BOH.PLAN_YEAR(+)
                 AND STD.PLAN_MONTH = BOH.PLAN_MONTH(+)
                 --------------------------------------
                 AND STD.VERSION_ID = RST.VERSION_ID(+)
                 AND STD.OEM_CD     = RST.OEM_CD(+)
                 AND STD.PGM_D_CD   = RST.PGM_D_CD(+)
                 AND STD.CELL_CD    = RST.CELL_CD(+)
                 AND STD.SITE_CD    = RST.SITE_CD(+)
                 AND STD.PLAN_YEAR  = RST.PLAN_YEAR(+)
                 AND STD.PLAN_MONTH = RST.PLAN_MONTH(+)
             )
        SELECT RST.VERSION_ID, RST.OEM_CD, RST.PGM_D_CD, RST.CELL_CD, RST.SITE_CD
             , RST.MEASURE_CD
             , RST.PLAN_YEAR
             , RST.PLAN_MONTH
             , RST.QTY
             , SYSDATE, 'SYSTEM', NULL, NULL
          FROM (
                SELECT *
                  FROM (
                        SELECT RST.VERSION_ID, RST.OEM_CD, RST.PGM_D_CD, RST.CELL_CD, RST.SITE_CD
                             , RST.PLAN_YEAR, RST.PLAN_MONTH
                             , LAG(RST.EOH, 1, RST.BOH) OVER (PARTITION BY RST.VERSION_ID, RST.OEM_CD, RST.PGM_D_CD, RST.CELL_CD, RST.SITE_CD ORDER BY RST.PLAN_YEAR, RST.PLAN_MONTH) AS BOH
                             , RST.EOH
                          FROM (
                                SELECT RST.VERSION_ID, RST.OEM_CD, RST.PGM_D_CD, RST.CELL_CD, RST.SITE_CD
                                     , RST.PLAN_YEAR, RST.PLAN_MONTH
                                     , RST.BOH_QTY AS BOH
                                     , RST.EOH_QTY
                                       + (-1)*MIN(CASE WHEN RST.EOH_QTY < 0 THEN RST.EOH_QTY ELSE 0 END) OVER (PARTITION BY RST.VERSION_ID, RST.OEM_CD, RST.PGM_D_CD, RST.CELL_CD, RST.SITE_CD ORDER BY RST.PLAN_YEAR, RST.PLAN_MONTH) AS EOH
                                  FROM (
                                        SELECT STD.VERSION_ID, STD.OEM_CD, STD.PGM_D_CD, STD.CELL_CD, STD.SITE_CD
                                             , STD.PLAN_YEAR, STD.PLAN_MONTH
                                             , DENSE_RANK() OVER (PARTITION BY STD.VERSION_ID, STD.OEM_CD, STD.PGM_D_CD, STD.CELL_CD, STD.SITE_CD ORDER BY STD.PLAN_YEAR, STD.PLAN_MONTH) AS MM_RNK
                                             , STD.BOH_QTY AS BOH_QTY
                                             , SUM(STD.BOH_QTY ) OVER (PARTITION BY STD.VERSION_ID, STD.OEM_CD, STD.PGM_D_CD, STD.CELL_CD, STD.SITE_CD ORDER BY STD.PLAN_YEAR, STD.PLAN_MONTH)
                                               + SUM(STD.ARRV_QTY) OVER (PARTITION BY STD.VERSION_ID, STD.OEM_CD, STD.PGM_D_CD, STD.CELL_CD, STD.SITE_CD ORDER BY STD.PLAN_YEAR, STD.PLAN_MONTH)
                                               - SUM(STD.RTF_QTY ) OVER (PARTITION BY STD.VERSION_ID, STD.OEM_CD, STD.PGM_D_CD, STD.CELL_CD, STD.SITE_CD ORDER BY STD.PLAN_YEAR, STD.PLAN_MONTH) AS EOH_QTY
                                          FROM WT_EOH_CALC_STD STD 
                                       ) RST
                               ) RST
                       ) RST
                       UNPIVOT (QTY FOR MEASURE_CD IN (BOH, EOH))
               ) RST
        ;
      
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '11.0';
    G_sSTEP_DESC := 'CREATE Data : SP_GET_RESULT_RTF / All Measure';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
    MERGE INTO TB_SMP_RS_RTF RST
    USING (
           SELECT RST.VERSION_ID, RST.OEM_CD, RST.PGM_D_CD, RST.CELL_CD
                , MIN(CASE WHEN MEA.CONF_CD = 'DEMAND' THEN 'XXX'
                           WHEN MEA.CONF_CD = 'SHORT'  THEN 'XXX'
                           ELSE RST.SITE_CD
                           END) AS SITE_CD
                , p_sBASE_YEAR  AS PLAN_YEAR
                , P_sBASE_MONTH AS PLAN_MONTH
                , MEA.CONF_CD AS MEASURE_CD
                , NULL AS QTY
             FROM (
                   SELECT VERSION_ID, OEM_CD, PGM_D_CD, CELL_CD, SITE_CD
                     FROM TB_SMP_RS_RTF
                    WHERE VERSION_ID = P_sVERSION_ID
                    GROUP BY VERSION_ID, OEM_CD, PGM_D_CD, CELL_CD, SITE_CD
                  ) RST
                , (
                   SELECT CONF_CD
                     FROM TB_CM_COMM_CONFIG
                    WHERE CONF_GRP_CD = 'RTF_MEASURE'
                      AND ACTV_YN = 'Y'
                      AND USE_YN = 'Y'
                  ) MEA
          GROUP BY RST.VERSION_ID, RST.OEM_CD, RST.PGM_D_CD, RST.CELL_CD, MEA.CONF_CD
         ) MEA
    ON (RST.VERSION_ID = MEA.VERSION_ID
    AND RST.OEM_CD     = MEA.OEM_CD
    AND RST.PGM_D_CD   = MEA.PGM_D_CD
    AND RST.CELL_CD    = MEA.CELL_CD
    AND RST.SITE_CD    = MEA.SITE_CD
    AND RST.PLAN_YEAR  = MEA.PLAN_YEAR
    AND RST.PLAN_MONTH = MEA.PLAN_MONTH
    AND RST.MEASURE_CD = MEA.MEASURE_CD)
    WHEN NOT MATCHED THEN
    INSERT ( RST.VERSION_ID, RST.OEM_CD, RST.PGM_D_CD, RST.CELL_CD, RST.SITE_CD, RST.MEASURE_CD, RST.PLAN_YEAR, RST.PLAN_MONTH, RST.QTY
           , RST.REG_DTTM, RST.REG_USER_ID, RST.UPDATE_DTTM, RST.UPDATE_USER_ID)
    VALUES ( MEA.VERSION_ID, MEA.OEM_CD, MEA.PGM_D_CD, MEA.CELL_CD, MEA.SITE_CD, MEA.MEASURE_CD, MEA.PLAN_YEAR, MEA.PLAN_MONTH, MEA.QTY
           , SYSDATE, 'SYSTEM', NULL, NULL)
    ;
  
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_FLAG := 'F';
    G_sLOGMSG   := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
    G_sLOGMSG   := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG, G_sVERSION_ID);

END;

PROCEDURE SP_GET_RESULT_CONSUME (
  P_sENGINE_ID       IN  VARCHAR2
, P_sVERSION_ID      IN  VARCHAR2
, P_sPDB_VERSION_ID  IN  VARCHAR2
, P_sROLLING_FLAG    IN  VARCHAR2
, P_sBASE_YEAR       IN  VARCHAR2
, P_sBASE_MONTH      IN  VARCHAR2
, O_FLAG             OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_GET_RESULT_CONSUME
* Purpose : 자재 소요계획  및 공급 Capa 집계
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-27 JMS Created
**************************************************************************/
IS
---------------------------------
-- Private variable declarations -
---------------------------------
  P_sBOH_CUTOFF_DT    VARCHAR(8);
  P_sINTRAN_CUTOFF_DT VARCHAR(8);
 
BEGIN
  O_FLAG := 'S';
  G_sPROGRAM_ID := 'PKG_SMP_O_RESULT' ||'.'|| 'SP_GET_RESULT_CONSUME';
  G_sVERSION_ID := P_sVERSION_ID;
    
/*이 품목은 원래 전극 capa 사용하는 품목인데  오후 03:37
자재 소요량 산출할때 이 품목은 제외하고 산출해야 함
이 품목 소요량을 가지고 나중에 전극 소요 capa산출할때  사용해야 함  
 * SELECT sim.ITEM_CD
               FROM TB_SMP_ITEM_MST       SIM 
                   ,TB_SMP_ITEM_BASE_INFO IBI
                   ,TB_CM_COMM_CONFIG     CCC
                   ,TB_CM_CONFIGURATION   CFG    
              WHERE SIM.PN_CD             = IBI.PN_CD   
                AND IBI.ATTR_01           = CCC.ATTR_02 
                AND CCC.CONF_GRP_CD       = 'ITEM_ROUTE_MAP'
                AND CCC.USE_YN            = 'Y'
                AND CCC.CONF_ID           = CFG.ID
                AND CFG.MODULE_CD         = 'SMP'
                AND CFG.ACTV_YN           = 'Y'    
                AND CCC.CONF_CD           = 'ELECTRODE'
 * */
    
    G_sSTEP_SEQ := '1.0';
    G_sSTEP_DESC := 'Set Variable';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
       
        -- BOH 최신 Cutoff Date 확인
        SELECT MAX(CUTOFF_DATE)
          INTO P_sBOH_CUTOFF_DT
          FROM TB_SMP_BOH
         WHERE CUTOFF_DATE >= ADD_MONTHS(SYSDATE, -3) --3개월 이전 Data 까지만 우선 검색
        ;
        
        -- Intransit 최신 Cutoff Date 확인
        SELECT MAX(CUTOFF_DATE)
          INTO P_sINTRAN_CUTOFF_DT
          FROM TB_SMP_VENDOR_INTRANSIT
         WHERE CUTOFF_DATE >= ADD_MONTHS(SYSDATE, -3) --3개월 이전 Data 까지만 우선 검색
        ;
       
    --PKG_SMP_LOGGER.stepDEBUG (G_nLOG_SEQ, sTEST_STR, G_sVERSION_ID, G_sUSER_ID);
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
    
    G_sSTEP_SEQ := '2.0';
    G_sSTEP_DESC := 'DELETE Data : Same Version Result - P1';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
        DELETE FROM TB_SMP_RS_RM_CONSUME_P1
        WHERE VERSION_ID = P_sVERSION_ID
        ;
     
    --PKG_SMP_LOGGER.stepDEBUG (G_nLOG_SEQ, sTEST_STR, G_sVERSION_ID, G_sUSER_ID);
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '3.0';
    G_sSTEP_DESC := 'CREATE Data : TB_SMP_RS_RM_CONSUME_P1';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
    PKG_SMP_LOGGER.stepDEBUG (G_nLOG_SEQ, P_sPDB_VERSION_ID, P_sVERSION_ID, P_sENGINE_ID, P_sBASE_MONTH);
 
        INSERT INTO TB_SMP_RS_RM_CONSUME_P1
        ( VERSION_ID, SITE_CD, PGM_D_CD, DEMAND_ID, ITEM_CD, PLAN_YEAR, PLAN_MONTH
        , QTY
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM, UPDATE_USER_ID
        )
        SELECT P_sVERSION_ID AS VERSION_ID
             , RST.SITE_CD
             , RST.PGM_D_CD 
             , RST.DEMAND_ID
             , RST.ITEM_CD
             , RST.PLAN_YEAR
             , RST.PLAN_MONTH
             , SUM(RST.QTY) AS QTY
             , SYSDATE, 'SYSTEM', NULL, NULL
          FROM (
                SELECT RST.SITE_CD
                     , DMD.PGM_D_CD 
                     , RST.SALESORDER_ID AS DEMAND_ID
                     , RST.ITEM_CD
                     , TO_CHAR(RST.START_DATE, 'YYYY') AS PLAN_YEAR
                     , TO_CHAR(RST.START_DATE, 'YYYYMM') AS PLAN_MONTH
                     --, CASE WHEN P_sROLLING_FLAG = 'Y'
                     --       THEN 
                     --            CASE WHEN TO_CHAR(RST.START_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 4)
                     --                 THEN TO_CHAR(RST.START_DATE, 'YYYYMM')        -- ex: 202003
                     --                 ELSE TO_CHAR(RST.START_DATE, 'YYYY') || '12'  -- ex: 202012
                     --                 END
                     --       ELSE 
                     --            CASE WHEN TO_CHAR(RST.START_DATE, 'YYYY') <= TO_CHAR(TO_NUMBER(P_sBASE_YEAR) + 3)
                     --                 THEN TO_CHAR(RST.START_DATE, 'YYYYMM')
                     --                 ELSE TO_CHAR(RST.START_DATE, 'YYYY') || '12'
                     --                 END
                     --       END AS PLAN_MONTH -- 자재소요량은 월버켓으로만 보여준다. 
                     , RST.QTY
                  FROM (
                        SELECT RST.SALESORDER_ID
                             , RES.LOCATION_ID AS SITE_CD
                             , RST.ITEM_ID     AS ITEM_CD
                             , RST.START_DATE
                             , SUM(RST.OUTPUT_QTY) AS QTY
                          FROM RESULT_RESOURCE_PLAN RST
                             , RESOURCES RES
                         WHERE RST.VERSION_ID = P_sPDB_VERSION_ID
                           AND RES.ENGINE_ID  = P_sENGINE_ID
                           AND RST.RESOURCE_ID = RES.RESOURCE_ID
                           AND RST.START_DATE >= TO_DATE(P_sBASE_MONTH, 'YYYYMM')
                           --AND RST.START_DATE < ADD_MONTHS(TO_DATE(P_sBASE_MONTH, 'YYYYMM'), 2 + 2 + 1)
                         GROUP BY RST.SALESORDER_ID, RES.LOCATION_ID, RST.ITEM_ID, RST.START_DATE
                       ) RST 
                     , TB_SMP_WK_DEMAND DMD
                 WHERE 1=1
                   AND DMD.VERSION_ID = P_sVERSION_ID --'AIS_TEST01_V1'
                   AND DMD.USE_FLAG = 'Y'
                   AND RST.SALESORDER_ID = DMD.DEMAND_ID
               ) RST
         GROUP BY RST.SITE_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.ITEM_CD, RST.PLAN_YEAR, RST.PLAN_MONTH
         ;
  
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '4.0';
    G_sSTEP_DESC := 'DELETE Data : Same Version Result - P2';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
      
        DELETE FROM TB_SMP_RS_RM_CONSUME_P2
        WHERE VERSION_ID = P_sVERSION_ID
        ;
     
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '5.0';
    G_sSTEP_DESC := 'CREATE Data : TB_SMP_RS_RM_CONSUME_P2';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
 
        INSERT INTO TB_SMP_RS_RM_CONSUME_P2
        ( VERSION_ID, SITE_CD, PGM_D_CD, DEMAND_ID, VENDOR_CD, P_SITE_CD, ITEM_CD, PLAN_YEAR, PLAN_MONTH
        , NET_STOCK_QTY, ORG_QTY, QTY
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM, UPDATE_USER_ID
        )
        SELECT RST.VERSION_ID, RST.SITE_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.VENDOR_CD, RST.P_SITE_CD             
             , RST.ITEM_CD
             , RST.PLAN_YEAR, RST.PLAN_MONTH
             , 0 AS NET_STOCK_QTY
             , SUM(RST.QTY) AS ORG_QTY
             , SUM(RST.QTY) AS QTY
             , SYSDATE, 'SYSTEM', NULL, NULL
          FROM (
                SELECT RST.VERSION_ID, RST.SITE_CD, RST.PGM_D_CD, RST.DEMAND_ID, VIM.VENDOR_CD, VIM.P_SITE_CD             
                     , BOM.C_ITEM_CD AS ITEM_CD
                     , RST.PLAN_YEAR, RST.PLAN_MONTH
                     , RST.QTY * (BOM.C_UNIT_QTY / BOM.P_UNIT_QTY) AS QTY
                  FROM TB_SMP_RS_RM_CONSUME_P1 RST
                     , TB_SMP_WK_BOM BOM
                     --, ( -- 임시
                     --   SELECT P_sVERSION_ID AS VERSION_ID, BOM.SITE_CD, BOM.P_ITEM_CD, BOM.P_UNIT_QTY, BOM.C_ITEM_CD, BOM.C_UNIT_QTY
                     --        , ITM.ITEM_TYPE_CD AS C_ITEM_TYPE_CD
                     --     FROM TB_SMP_BOM BOM
                     --        , TB_SMP_ITEM_MST ITM
                     --    WHERE BOM.BOM_TYPE_CD = 'M'
                     --      AND BOM.C_ITEM_CD = ITM.ITEM_CD
                     --  ) BOM 
                     , TB_SMP_SITE_MST STM
                     , VW_SMP_VNDR_SITE_ITEM_MAP VIM -- Vendor-Site-Item Mapping view
                 WHERE RST.VERSION_ID = P_sVERSION_ID --P_sVERSION_ID
                   AND BOM.C_ITEM_TYPE_CD = 'RM'
                   AND RST.VERSION_ID = BOM.VERSION_ID
                   AND RST.SITE_CD    = BOM.SITE_CD
                   AND RST.ITEM_CD    = BOM.P_ITEM_CD
                   AND RST.SITE_CD    = STM.SITE_CD
                   -- 생산 SITE 에서 취급하는 자재는 두개이상의 Vendor 에서 가져오지 않는 기준정보임으로 가능한 Join.
                   AND BOM.SITE_CD    = VIM.SITE_CD 
                   AND BOM.C_ITEM_CD  = VIM.ITEM_CD
               ) RST
         GROUP BY RST.VERSION_ID, RST.SITE_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.VENDOR_CD, RST.P_SITE_CD
                , RST.ITEM_CD
                , RST.PLAN_YEAR, RST.PLAN_MONTH
        ;      
  
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '6.0';
    G_sSTEP_DESC := 'UPDATE Data : TB_SMP_RS_RM_CONSUME_P2 : Netting Raw Mat. BOH';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
         MERGE INTO TB_SMP_RS_RM_CONSUME_P2 RST
         USING (
                SELECT RST.VERSION_ID, RST.SITE_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_YEAR, RST.PLAN_MONTH
                     , RST.QTY - CASE WHEN RST.ACC_QTY - RST.BOH < 0
                                      THEN 0
                                      ELSE 
                                           CASE WHEN RST.ACC_QTY - RST.BOH >= RST.QTY
                                                THEN RST.QTY
                                                ELSE RST.ACC_QTY - RST.BOH
                                                END
                                      END AS NET_STOCK_QTY
                     , CASE WHEN RST.ACC_QTY - RST.BOH < 0
                            THEN 0
                            ELSE 
                                 CASE WHEN RST.ACC_QTY - RST.BOH >= RST.QTY
                                      THEN RST.QTY
                                      ELSE RST.ACC_QTY - RST.BOH
                                      END
                            END AS CHG_QTY
                  FROM (
                        SELECT RST.VERSION_ID, RST.SITE_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_YEAR, RST.PLAN_MONTH
                             , RST.QTY
                             , SUM(RST.QTY) OVER (PARTITION BY RST.VERSION_ID, RST.SITE_CD, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD
                                                      ORDER BY RST.PLAN_YEAR, RST.PLAN_MONTH, RST.PRIOIRTY) AS ACC_QTY
                             , NVL(BOH.QTY, 0) AS BOH
                          FROM (
                                SELECT RST.VERSION_ID, RST.SITE_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_YEAR, RST.PLAN_MONTH
                                     , SUM(RST.ORG_QTY) AS QTY
                                     , MAX(DMD.PRIORITY) AS PRIOIRTY
                                  FROM TB_SMP_RS_RM_CONSUME_P2 RST
                                     , TB_SMP_WK_DEMAND DMD
                                 WHERE RST.VERSION_ID = P_sVERSION_ID
                                   AND DMD.USE_FLAG = 'Y'
                                   AND RST.VERSION_ID = DMD.VERSION_ID
                                   AND RST.DEMAND_ID  = DMD.DEMAND_ID
                                 GROUP BY RST.VERSION_ID, RST.SITE_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_YEAR, RST.PLAN_MONTH
                               ) RST
                             , (
                                SELECT SLM.SITE_CD, BOH.ITEM_CD, SUM(BOH.STOCK_QTY) AS QTY
                                  FROM TB_SMP_BOH BOH
                                     , TB_SMP_SL_MST SLM
                                 WHERE BOH.CUTOFF_DATE = P_sBOH_CUTOFF_DT
                                   AND BOH.PLANT_CD    = SLM.PLANT_CD
                                   AND BOH.SL_CD       = SLM.SL_CD
                                 GROUP BY SLM.SITE_CD, BOH.ITEM_CD
                               ) BOH
                         WHERE RST.SITE_CD = BOH.SITE_CD(+)
                           AND RST.ITEM_CD = BOH.ITEM_CD(+)
                       ) RST
                 WHERE RST.QTY <> CASE WHEN RST.ACC_QTY - RST.BOH < 0
                                       THEN 0
                                       ELSE 
                                            CASE WHEN RST.ACC_QTY - RST.BOH >= RST.QTY
                                                 THEN RST.QTY
                                                 ELSE RST.ACC_QTY - RST.BOH
                                                 END
                                       END -- Netting 되지 않은 항목은 제외.
               ) NET
            ON (RST.VERSION_ID = NET.VERSION_ID
            AND RST.SITE_CD    = NET.SITE_CD
            AND RST.PGM_D_CD   = NET.PGM_D_CD
            AND RST.DEMAND_ID  = NET.DEMAND_ID
            AND RST.VENDOR_CD  = NET.VENDOR_CD
            AND RST.P_SITE_CD  = NET.P_SITE_CD
            AND RST.ITEM_CD    = NET.ITEM_CD
            AND RST.PLAN_YEAR  = NET.PLAN_YEAR
            AND RST.PLAN_MONTH = NET.PLAN_MONTH)
           WHEN MATCHED THEN
         UPDATE 
            SET RST.NET_STOCK_QTY = NET.NET_STOCK_QTY
              , RST.QTY           = NET.CHG_QTY
        ;
      
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '7.0';
    G_sSTEP_DESC := 'UPDATE Data : TB_SMP_RS_RM_CONSUME_P2  : Netting Raw Mat. Intransit';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
        
         MERGE INTO TB_SMP_RS_RM_CONSUME_P2 RST
         USING (
                SELECT RST.VERSION_ID, RST.SITE_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_YEAR, RST.PLAN_MONTH
                     , SUM(RST.QTY - RST.CHG_QTY) AS NET_STOCK_QTY
                     , MAX(RST.QTY) - SUM(RST.QTY - RST.CHG_QTY) AS CHG_QTY
                  FROM (
                        SELECT RST.VERSION_ID, RST.SITE_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_YEAR, RST.PLAN_MONTH
                             , RST.ETA_MONTH
                             , RST.QTY
                             , RST.INTRAN_QTY
                             , CASE WHEN RST.ACC_QTY - RST.INTRAN_QTY < 0
                                    THEN 0
                                    ELSE 
                                         CASE WHEN RST.ACC_QTY - RST.INTRAN_QTY >= RST.QTY
                                              THEN RST.QTY
                                              ELSE RST.ACC_QTY - RST.INTRAN_QTY
                                              END
                                    END AS CHG_QTY
                          FROM (
                                SELECT RST.VERSION_ID, RST.SITE_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_YEAR, RST.PLAN_MONTH
                                     , RST.QTY
                                     , SUM(RST.QTY) OVER (PARTITION BY RST.VERSION_ID, RST.SITE_CD, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, ITR.ETA_MONTH
                                                              ORDER BY RST.PLAN_YEAR, RST.PLAN_MONTH, RST.PRIOIRTY) AS ACC_QTY
                                     , ITR.ETA_MONTH
                                     , NVL(ITR.QTY, 0) AS INTRAN_QTY
                                  FROM (
                                        SELECT RST.VERSION_ID, RST.SITE_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_YEAR, RST.PLAN_MONTH
                                             , SUM(RST.ORG_QTY) AS QTY
                                             , MAX(DMD.PRIORITY) AS PRIOIRTY
                                          FROM TB_SMP_RS_RM_CONSUME_P2 RST
                                             , TB_SMP_WK_DEMAND DMD
                                         WHERE RST.VERSION_ID = P_sVERSION_ID
                                           AND DMD.USE_FLAG = 'Y'
                                           AND RST.VERSION_ID = DMD.VERSION_ID
                                           AND RST.DEMAND_ID = DMD.DEMAND_ID
                                         GROUP BY RST.VERSION_ID, RST.SITE_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_YEAR, RST.PLAN_MONTH
                                       ) RST
                                     , (
                                        SELECT ITR.VENDOR_CD, ITR.P_SITE_CD, ITR.ITEM_CD, ITR.SITE_CD, ITR.ETA_MONTH, ITR.STOCK_QTY AS QTY
                                          FROM TB_SMP_VENDOR_INTRANSIT ITR
                                         WHERE ITR.CUTOFF_DATE = P_sINTRAN_CUTOFF_DT
                                       ) ITR
                                 WHERE 1=1
                                   AND RST.VENDOR_CD = ITR.VENDOR_CD
                                   AND RST.P_SITE_CD = ITR.P_SITE_CD
                                   AND RST.ITEM_CD = ITR.ITEM_CD
                                   AND RST.PLAN_MONTH >= ITR.ETA_MONTH           
                               ) RST
                       ) RST
                 WHERE RST.QTY <> RST.CHG_QTY
                 GROUP BY RST.VERSION_ID, RST.SITE_CD, RST.PGM_D_CD, RST.DEMAND_ID, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_YEAR, RST.PLAN_MONTH
               ) NET
            ON (RST.VERSION_ID = NET.VERSION_ID
            AND RST.SITE_CD    = NET.SITE_CD
            AND RST.PGM_D_CD   = NET.PGM_D_CD
            AND RST.DEMAND_ID  = NET.DEMAND_ID
            AND RST.VENDOR_CD  = NET.VENDOR_CD
            AND RST.P_SITE_CD  = NET.P_SITE_CD
            AND RST.ITEM_CD    = NET.ITEM_CD
            AND RST.PLAN_YEAR  = NET.PLAN_YEAR
            AND RST.PLAN_MONTH = NET.PLAN_MONTH)
           WHEN MATCHED THEN
         UPDATE 
            SET RST.NET_STOCK_QTY = RST.NET_STOCK_QTY + NET.NET_STOCK_QTY
              , RST.QTY           = NET.CHG_QTY
        ;
           
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);  
  
    G_sSTEP_SEQ := '8.0';
    G_sSTEP_DESC := 'DELETE Data : Same Version Result - P3';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
     
        DELETE FROM TB_SMP_RS_RM_CONSUME_P3
        WHERE VERSION_ID = P_sVERSION_ID
        ;
     
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '9.0';
    G_sSTEP_DESC := 'CREATE Data : TB_SMP_RS_RM_CONSUME_P3';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
 
        INSERT INTO TB_SMP_RS_RM_CONSUME_P3
        ( VERSION_ID, SITE_CD, VENDOR_CD, P_SITE_CD, ITEM_CD, CELL_CD, PLAN_YEAR, PLAN_MONTH
        , LEAD_TIME, QTY
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM, UPDATE_USER_ID
        )
        SELECT RST.VERSION_ID, RST.SITE_CD, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.CELL_CD
             , TO_CHAR(ADD_MONTHS(RST.PLAN_MONTH, (-1)*RST.LEAD_TIME), 'YYYY')   AS PLAN_YEAR
             , TO_CHAR(ADD_MONTHS(RST.PLAN_MONTH, (-1)*RST.LEAD_TIME), 'YYYYMM') AS PLAN_MONTH
             --, TO_CHAR(RST.PLAN_MONTH, 'YYYYMM') AS ORG_PLAN_MONTH
             , LEAD_TIME
             , ROUND(QTY) AS QTY
             , SYSDATE, 'SYSTEM', NULL, NULL
          FROM (
                SELECT RST.VERSION_ID, RST.SITE_CD, VIM.VENDOR_CD, VIM.P_SITE_CD, RST.CONTINENT_CD
                     , RST.ITEM_CD, RST.CELL_CD
                     , TO_DATE(RST.PLAN_MONTH, 'YYYYMM') AS PLAN_MONTH
                     , 1 + CASE WHEN VND.CONTINENT_CD = RST.CONTINENT_CD -- Vendor 생산지와 생산법인의 대륙이 같으면 1달 다르면 2달
                                THEN 1
                                ELSE 2 END AS LEAD_TIME -- 선행입고 LT (1달 ) + 대륙간 LT(동일대륙 : 1달, 다른대륙 : 2달)
                     , RST.QTY
                  FROM (
                        SELECT RST.VERSION_ID, RST.SITE_CD, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, PGM.CELL_CD
                             , RST.PLAN_YEAR, RST.PLAN_MONTH
                             , STM.CONTINENT_CD
                             , SUM(RST.QTY) AS QTY
                          FROM TB_SMP_RS_RM_CONSUME_P2 RST
                             , TB_SMP_SITE_MST STM
                             , TB_SMP_DEMAND_PGM_MST PGM
                         WHERE RST.VERSION_ID = P_sVERSION_ID --P_sVERSION_ID
                           AND RST.SITE_CD    = STM.SITE_CD
                           AND RST.PGM_D_CD   = PGM.PGM_D_CD
                         GROUP BY RST.VERSION_ID, RST.SITE_CD, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, PGM.CELL_CD
                                , RST.PLAN_YEAR, RST.PLAN_MONTH, STM.CONTINENT_CD
                       ) RST
                     , VW_SMP_VNDR_SITE_ITEM_MAP VIM -- Vendor-Site-Item Mapping view VIM
                     , TB_SMP_VENDOR_MST         VND
                 WHERE RST.SITE_CD = VIM.SITE_CD
                   AND RST.ITEM_CD = VIM.ITEM_CD
                   AND VIM.VENDOR_CD = VND.VENDOR_CD
                   AND VIM.P_SITE_CD = VND.P_SITE_CD 
               ) RST
         ;
  
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '10.0';
    G_sSTEP_DESC := 'DELETE Data : Same Version Result - V';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
      
        DELETE FROM TB_SMP_RS_RM_CONSUME_V
        WHERE VERSION_ID = P_sVERSION_ID
        ;
     
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '11.0';
    G_sSTEP_DESC := 'CREATE Data : Distruibute Vendor Supply Capa';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
 
        INSERT INTO TB_SMP_RS_RM_CONSUME_V
        ( VERSION_ID, SITE_CD, VENDOR_CD, P_SITE_CD, ITEM_CD
        , PLAN_YEAR, PLAN_MONTH 
        , LEAD_TIME, QTY, CAPA_QTY, VENDOR_CAPA_QTY
        , REG_DTTM, REG_USER_ID
        )
        WITH WT_SMP_RS_RM_CONSUME_P3
          AS (
              SELECT VERSION_ID, SITE_CD, VENDOR_CD, P_SITE_CD, CELL_CD, ITEM_CD
                   , PLAN_YEAR, PLAN_MONTH
                   , LEAD_TIME, QTY
                FROM TB_SMP_RS_RM_CONSUME_P3
               UNION ALL
              SELECT DISTINCT
                     VERSION_ID
                   , 'ZZZ' AS SITE_CD
                   , VENDOR_CD
                   , P_SITE_CD
                   , CELL_CD
                   , ITEM_CD
                   , PLAN_YEAR
                   , PLAN_MONTH
                   , 9999
                   , 0
                FROM TB_SMP_RS_RM_CONSUME_P3
             )
        SELECT RST.VERSION_ID, RST.SITE_CD, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD
             , RST.PLAN_YEAR, RST.PLAN_MONTH
             , RST.LEAD_TIME
             , RST.QTY   --자재소요수량
             , ROUND(RST.ACT_CAPA * RST.ALOC_RATE) AS ALOC_CAPA --CAPA 할당량
             , RST.ORG_CAPA AS VENDOR_CAPA_QTY
             , SYSDATE
             , 'SYSTEM'
          FROM (
                       SELECT DISTINCT
                              RST.VERSION_ID, RST.SITE_CD, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD
                            , RST.PLAN_YEAR, RST.PLAN_MONTH
                            , RST.LEAD_TIME, RST.QTY
                            , RST.LT_SUM_QTY, RST.ACUM_QTY, RST.CAL
                            , CASE WHEN RST.SITE_CD = 'ZZZ' --CAPA 잔량 데이터는 SITE_CD = 'ZZZ'로 표기
                                   THEN 
                                        CASE WHEN RST.CAL < 0
                                             THEN 0
                                             ELSE RST.CAL
                                             END
                                   ELSE 
                                        CASE WHEN RST.CAL >= 0
                                             THEN RST.LT_SUM_QTY
                                             ELSE 
                                                  CASE WHEN RST.LT_SUM_QTY >  ABS(RST.CAL)
                                                       THEN RST.LT_SUM_QTY + RST.CAL
                                                       ELSE 0
                                                       END
                                             END
                                   END AS ACT_CAPA
                            , RST.ALOC_RATE
                            , RST.ORG_CAPA
                         FROM (
                                      SELECT DISTINCT RST.VERSION_ID 
                                           , RST.SITE_CD
                                           , RST.VENDOR_CD
                                           , RST.P_SITE_CD
                                           , RST.ITEM_CD
                                           , RST.PLAN_YEAR
                                           , RST.PLAN_MONTH
                                           , RST.LEAD_TIME
                                           , SUM(RST.QTY) OVER (PARTITION BY RST.SITE_CD, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_MONTH) AS QTY  -- 하나의 ITEM이 여러개의 CELL에 들어가기 때문에 SUM
                                           , SUM(RST.QTY) OVER (PARTITION BY RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_MONTH, RST.LEAD_TIME ) AS LT_SUM_QTY
                                           , SUM(RST.QTY) OVER (PARTITION BY RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_MONTH ORDER BY RST.LEAD_TIME) AS ACUM_QTY
                                           , CASE WHEN RST.SITE_CD = 'ZZZ' THEN 1 
                                                  ELSE SUM(RST.QTY) OVER (PARTITION BY RST.SITE_CD, RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_MONTH)
                                                       / NVL(NULLIF((SUM(RST.QTY) OVER(PARTITION BY RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_MONTH, RST.LEAD_TIME )),0),1)
                                                  END AS ALOC_RATE
                                           , NVL(VCP.QTY, 0) AS ORG_CAPA
                                           , NVL(VCP.QTY, 0) - SUM(RST.QTY) OVER (PARTITION BY RST.VENDOR_CD, RST.P_SITE_CD, RST.ITEM_CD, RST.PLAN_MONTH ORDER BY RST.LEAD_TIME) AS CAL 
                                        FROM WT_SMP_RS_RM_CONSUME_P3 RST
                                           , TB_SMP_VENDOR_CAPA VCP
                                       WHERE RST.VERSION_ID = P_sVERSION_ID
                                         AND RST.VENDOR_CD = VCP.VENDOR_CD(+)
                                         AND RST.P_SITE_CD = VCP.P_SITE_CD(+)
                                         AND RST.ITEM_CD   = VCP.ITEM_CD(+)
                                         AND RST.PLAN_MONTH = VCP.BASE_MONTH(+)
                              ) RST
               ) RST
         WHERE ROUND(RST.ACT_CAPA * RST.ALOC_RATE) > 0
        --ORDER BY A.ITEM_CD, A.VENDOR_CD, A.P_SITE_CD, A.PLAN_MONTH, A.SITE_CD
        ;
  
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
    
  
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_FLAG := 'F';
    G_sLOGMSG   := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
    G_sLOGMSG   := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG, G_sVERSION_ID);

END;

PROCEDURE SP_GET_RESULT_PROBLEM (
  P_sENGINE_ID       IN  VARCHAR2
, P_sVERSION_ID      IN  VARCHAR2
, P_sPDB_VERSION_ID  IN  VARCHAR2
, P_sROLLING_FLAG    IN  VARCHAR2
, P_sBASE_YEAR       IN  VARCHAR2
, P_sBASE_MONTH      IN  VARCHAR2
, O_FLAG             OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_GET_RESULT_PROBLEM
* Purpose : Plan Problem 집계
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-04-09 JMS Created
**************************************************************************/
IS
---------------------------------
-- Private variable declarations -
---------------------------------
 
BEGIN
  O_FLAG := 'S';
  G_sPROGRAM_ID := 'PKG_SMP_O_RESULT' ||'.'|| 'SP_GET_RESULT_PROBLEM';
  G_sVERSION_ID := P_sVERSION_ID;
 
    
    G_sSTEP_SEQ := '1.0';
    G_sSTEP_DESC := 'DELETE Data : Same Version Result';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
      DELETE FROM TB_SMP_RS_PLAN_PROBLEM
      WHERE VERSION_ID = P_sVERSION_ID
      ;
    
  --PKG_SMP_LOGGER.stepDEBUG (G_nLOG_SEQ, sTEST_STR, G_sVERSION_ID, G_sUSER_ID);
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '2.0';
    G_sSTEP_DESC := 'Problem : 기준정보 - 라인인증 정보 없음';
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
        INSERT INTO TB_SMP_RS_PLAN_PROBLEM
        ( VERSION_ID, PGM_D_CD, DEMAND_ID, PLAN_YEAR, PLAN_MONTH, OEM_CD, CELL_CD, ISSUE_TYPE, SITE_CD, ITEM_CD, LINE_CD, DESCRIPTION, ISSUE_QTY, DEMAND_QTY
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM , UPDATE_USER_ID 
        )
        SELECT P_sVERSION_ID AS VERSION_ID
             , PGM.PGM_D_CD, RSP.SALESORDER_ID 
             , TO_CHAR(WKS.DUE_DATE , 'YYYY') AS PLAN_YEAR
             , TO_CHAR(WKS.DUE_DATE , 'YYYYMM') AS PLAN_MONTH
             , PGM.OEM_CD
             , PGM.CELL_CD 
             , '기준정보 - 라인인증 정보 없음' AS ISSUE_TYPE
             , NULL AS SITE_CD
             , PGM.ITEM_CD 
             , NULL AS LINE_CD
             , RSP.DESCRIPTION 
             , RSP.PROBLEM_VALUE 
             , WKS.QTY
             , SYSDATE, 'SYSTEM' AS REG_USER, NULL, NULL
          FROM RESULT_PLAN_PROBLEM RSP
             , TB_SMP_DEMAND_PGM_MST PGM
             , TB_SMP_WK_DEMAND WKS
         WHERE RSP.VERSION_ID = P_sPDB_VERSION_ID --'AIS01_20.02.27.18.26.27' 
           AND WKS.VERSION_ID = P_sVERSION_ID
           AND RSP.DESCRIPTION  LIKE '%데이터 문제%'
           AND RSP.PROBLEM_TYPE = 'SHORT'
           AND RSP.CUSTOMER_ID  = PGM.PGM_D_CD
           AND RSP.SALESORDER_ID  = WKS.DEMAND_ID
           --AND RSP.SALESORDER_ID  = 'ESS-003_202101(2)'
           AND RSP.CUSTOMER_ID IN (
                                   SELECT PGM_D_CD
                                     FROM TB_SMP_DATA_VALIDATION
                                    WHERE  VALID_TYPE_CD  = 'VALID_08'
                                  )
        ;

    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '3.0';
    G_sSTEP_DESC := 'Problem : 기준정보 - BOM 문제';  
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
        INSERT INTO TB_SMP_RS_PLAN_PROBLEM
        ( VERSION_ID, PGM_D_CD, DEMAND_ID, PLAN_YEAR, PLAN_MONTH, OEM_CD, CELL_CD, ISSUE_TYPE, SITE_CD, ITEM_CD, LINE_CD, DESCRIPTION, ISSUE_QTY, DEMAND_QTY 
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM , UPDATE_USER_ID 
        )
        SELECT P_sVERSION_ID AS VERSION_ID
             , PGM.PGM_D_CD, RSP.SALESORDER_ID 
             , TO_CHAR(WKS.DUE_DATE , 'YYYY') AS PLAN_YEAR
             , TO_CHAR(WKS.DUE_DATE , 'YYYYMM') AS PLAN_MONTH
             , PGM.OEM_CD
             , PGM.CELL_CD 
             , '기준정보 - BOM' AS ISSUE_TYPE
             , NULL AS SITE_CD 
             , PGM.ITEM_CD 
             , NULL AS LINE_CD
             , RSP.DESCRIPTION 
             , RSP.PROBLEM_VALUE 
             , WKS.QTY
             , SYSDATE, 'SYSTEM' AS REG_USER, NULL, NULL
          FROM RESULT_PLAN_PROBLEM RSP
             , TB_SMP_DEMAND_PGM_MST PGM
             , TB_SMP_WK_DEMAND WKS
         WHERE RSP.VERSION_ID = P_sPDB_VERSION_ID --'AIS01_20.02.27.18.26.27' 
           AND WKS.VERSION_ID  = P_sVERSION_ID
           AND RSP.DESCRIPTION  LIKE '%데이터 문제%'
           AND RSP.PROBLEM_TYPE = 'SHORT'
           AND RSP.CUSTOMER_ID  = PGM.PGM_D_CD
           AND RSP.SALESORDER_ID  = WKS.DEMAND_ID
           --AND RSP.SALESORDER_ID  = 'ESS-003_202101(2)'
           AND RSP.CUSTOMER_ID IN (
                                   SELECT PGM_D_CD
                                     FROM TB_SMP_DATA_VALIDATION
                                    WHERE VALID_TYPE_CD = 'VALID_07'
                                  )
        ;

    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '4.0';
    G_sSTEP_DESC := 'Problem : CAPA 부족(L/T)';   
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
        INSERT INTO TB_SMP_RS_PLAN_PROBLEM
        ( VERSION_ID, PGM_D_CD, DEMAND_ID, PLAN_YEAR, PLAN_MONTH, OEM_CD, CELL_CD, ISSUE_TYPE, SITE_CD, ITEM_CD, LINE_CD, DESCRIPTION, ISSUE_QTY, DEMAND_QTY
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM , UPDATE_USER_ID 
        )
        SELECT P_sVERSION_ID AS VERSION_ID
             , PGM.PGM_D_CD, RSP.SALESORDER_ID 
             , TO_CHAR(WKS.DUE_DATE , 'YYYY') AS PLAN_YEAR
             , TO_CHAR(WKS.DUE_DATE , 'YYYYMM') AS PLAN_MONTH
             , PGM.OEM_CD
             , PGM.CELL_CD 
             , 'CAPA 부족(L/T)' AS ISSUE_TYPE
             , SUBSTR(NODE_ID, 1, 4) AS SITE_CD 
             , PGM.ITEM_CD 
             , NODE_ID AS LINE_cD
             , RSP.DESCRIPTION 
             , RSP.PROBLEM_VALUE
             , WKS.QTY
             , SYSDATE, 'SYSTEM' AS REG_USER, NULL, NULL
          FROM RESULT_PLAN_PROBLEM RSP
             , TB_SMP_DEMAND_PGM_MST PGM
             , TB_SMP_WK_DEMAND WKS
         WHERE RSP.VERSION_ID = P_sPDB_VERSION_ID --'AIS01_20.02.27.18.26.27' 
           AND WKS.VERSION_ID  = P_sVERSION_ID
           AND RSP.DESCRIPTION  LIKE '%데이터 문제(리드타임%'
           AND RSP.PROBLEM_TYPE = 'SHORT'
           AND RSP.CUSTOMER_ID  = PGM.PGM_D_CD
           AND RSP.SALESORDER_ID  = WKS.DEMAND_ID
        ;

    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '5.0';
    G_sSTEP_DESC := 'Problem : CAPA 부족';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
        INSERT INTO TB_SMP_RS_PLAN_PROBLEM
        ( VERSION_ID, PGM_D_CD, DEMAND_ID, PLAN_YEAR, PLAN_MONTH, OEM_CD, CELL_CD, ISSUE_TYPE, SITE_CD, ITEM_CD, LINE_CD, DESCRIPTION, ISSUE_QTY, DEMAND_QTY
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM , UPDATE_USER_ID 
        )
        SELECT P_sVERSION_ID AS VERSION_ID
             , PGM.PGM_D_CD, RSP.SALESORDER_ID 
             , TO_CHAR(WKS.DUE_DATE , 'YYYY') AS PLAN_YEAR
             , TO_CHAR(WKS.DUE_DATE , 'YYYYMM') AS PLAN_MONTH
             , PGM.OEM_CD , PGM.CELL_CD 
             , 'CAPA 부족' AS ISSUE_TYPE
             , SUBSTR(NODE_ID, 1, 4) AS SITE_CD 
             , PGM.ITEM_CD 
             , NODE_ID AS LINE_cD
             , RSP.DESCRIPTION 
             , RSP.PROBLEM_VALUE
             , WKS.QTY
             , SYSDATE, 'SYSTEM' AS REG_USER, NULL, NULL
          FROM RESULT_PLAN_PROBLEM RSP
             , TB_SMP_DEMAND_PGM_MST PGM
             , TB_SMP_WK_DEMAND WKS
         WHERE RSP.VERSION_ID = P_sPDB_VERSION_ID --'AIS01_20.02.27.18.26.27' 
           AND WKS.VERSION_ID  = P_sVERSION_ID
           AND RSP.DESCRIPTION  LIKE '%자원능력 부족%'
           AND RSP.PROBLEM_TYPE = 'SHORT'
           AND RSP.CUSTOMER_ID  = PGM.PGM_D_CD
           AND RSP.SALESORDER_ID  = WKS.DEMAND_ID
        ;

    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
    G_sSTEP_SEQ := '6.0';
    G_sSTEP_DESC := 'Problem : 자재 부족';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAM_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
        INSERT INTO TB_SMP_RS_PLAN_PROBLEM
        ( VERSION_ID, PGM_D_CD, DEMAND_ID, PLAN_YEAR, PLAN_MONTH, OEM_CD, CELL_CD, ISSUE_TYPE, SITE_CD, ITEM_CD, LINE_CD, DESCRIPTION, ISSUE_QTY, DEMAND_QTY
        , REG_DTTM, REG_USER_ID, UPDATE_DTTM , UPDATE_USER_ID 
        )
        SELECT P_sVERSION_ID AS VERSION_ID
             , PGM.PGM_D_CD, RSP.SALESORDER_ID 
             , TO_CHAR(WKS.DUE_DATE , 'YYYY') AS PLAN_YEAR
             , TO_CHAR(WKS.DUE_DATE , 'YYYYMM') AS PLAN_MONTH
             , PGM.OEM_CD , PGM.CELL_CD 
             , '자재 부족' AS ISSUE_TYPE
             , SUBSTR(RSP.NODE_ID, INSTR(RSP.NODE_ID, '@')+1, 4) AS SITE_CD
             , SUBSTR(RSP.NODE_ID, 1, INSTR(RSP.NODE_ID, '@')-1) AS ITEM_CD 
             , NULL AS LINE_CD
             , RSP.DESCRIPTION 
             , RSP.PROBLEM_VALUE
             , WKS.QTY
             , SYSDATE, 'SYSTEM' AS REG_USER, NULL, NULL
          FROM RESULT_PLAN_PROBLEM RSP
             , TB_SMP_DEMAND_PGM_MST PGM
             , TB_SMP_WK_DEMAND WKS
         WHERE RSP.VERSION_ID = P_sPDB_VERSION_ID --'AIS01_20.02.27.18.26.27' 
           AND WKS.VERSION_ID  = P_sVERSION_ID
           AND RSP.DESCRIPTION  LIKE '%자재 부족%'
           AND RSP.PROBLEM_TYPE = 'SHORT'
           AND RSP.CUSTOMER_ID  = PGM.PGM_D_CD
           AND RSP.SALESORDER_ID  = WKS.DEMAND_ID
        ;

    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
    
  
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_FLAG := 'F';
    G_sLOGMSG   := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
    G_sLOGMSG   := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG, G_sVERSION_ID);

END;

END PKG_SMP_O_RESULT;
/

