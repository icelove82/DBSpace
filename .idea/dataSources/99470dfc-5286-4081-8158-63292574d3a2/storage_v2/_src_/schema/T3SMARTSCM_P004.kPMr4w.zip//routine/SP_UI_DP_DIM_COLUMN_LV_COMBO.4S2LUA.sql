create PROCEDURE "SP_UI_DP_DIM_COLUMN_LV_COMBO" 
(
      p_ID		VARCHAR2		--Dimension type Id
    , pRESULT   OUT SYS_REFCURSOR
)
IS 

/*****************************************************************************
Title : SP_UI_DP_DIM_COLUMN_LV_COMBO
최초 작성자 : 이고은
최초 생성일 : 2017.08.16
 
설명 
 - SP_UI_DP_DIM_COLUMN_LV_COMBO
  
History (수정일자 / 수정자 / 수정내용)
- 2017.08.16 / 이고은 / 최초 작성
- 2019.04.25 / 김소희 / DEL_YN Null처리 
- 2020.12.23 / 민경훈 / MSSQL -> ORACLE
*****************************************************************************/

v_LV_MGMT_TP	VARCHAR2(50);
v_LEAF_YN		CHAR(1);

BEGIN

    SELECT	GRP.CONF_CD
          , LV.LEAF_YN
            INTO
            v_LV_MGMT_TP
          , v_LEAF_YN
    FROM	TB_CM_CONFIGURATION CON 
            INNER JOIN TB_CM_COMM_CONFIG GRP  ON CON.ID = GRP.CONF_ID AND CON.CONF_NM = GRP.CONF_GRP_CD
            INNER JOIN TB_CM_LEVEL_MGMT LV	 ON GRP.ID = LV.LV_TP_ID 
    WHERE	CON.MODULE_CD		= 'DP'
    AND		GRP.CONF_GRP_CD		= 'DP_LV_TP'
    AND		GRP.ACTV_YN			= 'Y'
    AND		LV.ACTV_YN			= 'Y'
    AND		COALESCE(LV.DEL_YN,'N')	= 'N'
    AND		LV.ID				=  p_ID	
    ;

--    SELECT 
--    a.name as table_name,
--    b.name as column_name
--    from .sys.tables a
--    inner join sys.syscolumns b on a.object_id=b.id
--    where	 a.name like '%' || 'TB_DP_ACCOUNT_MST' || '%'
--    ;

    OPEN pRESULT FOR
    SELECT TABLE_NAME
         , COLUMN_NAME
      FROM ALL_TAB_COLUMNS
     WHERE 1=1
       AND OWNER = (SELECT USER FROM DUAL) -- T3SMARTSCM_DEV
       AND TABLE_NAME LIKE '%' || 'TB_DP_ACCOUNT_MST' || '%' 
    ;
END;

/

