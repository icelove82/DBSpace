create PROCEDURE "SP_UI_DP_17_S1" (
    p_ID			     IN  VARCHAR2	  := ''         
  , p_MEASURE_CD	     IN  VARCHAR      := ''         
  , p_MEASURE_NM	     IN  VARCHAR      := ''         
  , p_DESCRIP			 IN  VARCHAR2	  := ''      
  , p_TBL_NM			 IN  VARCHAR	  := ''      
  , p_COL_NM			 IN  VARCHAR	  := ''      
  , p_MEASURE_VAL_TP_ID	 IN  VARCHAR2	  := ''      
  , p_SYSTEM_YN			 IN  VARCHAR2	  := ''  
  , p_BF_YN				 IN  VARCHAR2	  := ''     
  , p_DP_YN				 IN  VARCHAR2	  := ''     
  , p_SRP_YN			 IN  VARCHAR2	  := ''    
  , p_CAL_YN			 IN  VARCHAR2	  := ''   
  , p_USER_ID		     IN  VARCHAR2	  := ''   
  , P_RT_ROLLBACK_FLAG   OUT VARCHAR2 
  , P_RT_MSG             OUT VARCHAR2 
) 
IS
	P_ERR_STATUS INT := 0;
    P_ERR_MSG VARCHAR2(4000) :='';
    V_MEASURE_VAL_TP_ID CHAR(32);

-- BEGIN TRY
-- IF (p_SYSTEM_YN = '1' OR p_SYSTEM_YN	= 't') SET p_SYSTEM_YN	='Y' ELSE SET p_SYSTEM_YN	='N'	
-- IF (p_BF_YN	 = '1' OR p_BF_YN		= 't') SET p_BF_YN		='Y' ELSE SET p_BF_YN		='N'	
-- IF (p_DP_YN	 = '1' OR p_DP_YN		= 't') SET p_DP_YN		='Y' ELSE SET p_DP_YN		='N'	
-- IF (p_SRP_YN	 = '1' OR p_SRP_YN		= 't') SET p_SRP_YN	='Y' ELSE SET p_SRP_YN		='N'
-- IF (p_CAL_YN	 = '1' OR p_CAL_YN		= 't') SET p_CAL_YN	='Y' ELSE SET p_CAL_YN		='N'
BEGIN 
	  -- ？?ν？? ?？？

    IF COALESCE(p_MEASURE_CD, '') = '' THEN
        P_ERR_MSG := 'Measure Code is empty';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

    IF P_MEASURE_VAL_TP_ID IS NULL THEN
        SELECT ID INTO V_MEASURE_VAL_TP_ID
          FROM TB_CM_COMM_CONFIG
         WHERE CONF_GRP_CD = 'DP_MS_VAL_TP' AND CONF_CD = 'QTY' AND ACTV_YN = 'Y';
    ELSE
        V_MEASURE_VAL_TP_ID := P_MEASURE_VAL_TP_ID;
    END IF;

	IF (p_SYSTEM_YN = 'Y')
	THEN

    	MERGE INTO TB_DP_MEASURE_MST TAR
    	USING (
            SELECT p_ID                 AS ID
                 , p_MEASURE_CD         AS MEASURE_CD
                 , p_MEASURE_NM         AS MEASURE_NM
                 , p_DESCRIP            AS DESCRIP             
                 , p_TBL_NM             AS TBL_NM              
                 , p_COL_NM             AS COL_NM              
                 , V_MEASURE_VAL_TP_ID  AS MEASURE_VAL_TP_ID   
                 , p_SYSTEM_YN          AS SYSTEM_YN           
                 , p_BF_YN              AS BF_YN               
                 , p_DP_YN              AS DP_YN               
                 , p_SRP_YN             AS SRP_YN  
                 , p_CAL_YN             AS CAL_YN  
                 , p_USER_ID            AS USER_ID             
              FROM dual 
        ) SRC
        ON (TAR.ID = SRC.ID)
        WHEN MATCHED THEN
            UPDATE
               SET TAR.DESCRIP              = SRC.DESCRIP
                 , TAR.SYSTEM_YN            = SRC.SYSTEM_YN
                 , TAR.BF_YN                = SRC.BF_YN
                 , TAR.DP_YN                = SRC.DP_YN
                 , TAR.SRP_YN               = SRC.SRP_YN
                 , TAR.MODIFY_BY            = SRC.USER_ID
                 , TAR.MODIFY_DTTM          = SYSDATE
		WHEN NOT MATCHED THEN
            INSERT (
                ID                 
              , MEASURE_CD         
              , MEASURE_NM         
              , DESCRIP                
              , TBL_NM             
              , COL_NM             
              , MEASURE_VAL_TP_ID  
              , SYSTEM_YN          
              , BF_YN              
              , DP_YN              
              , SRP_YN 
              , CAL_YN 
              , DEL_YN     
              , CREATE_BY
              , CREATE_DTTM
            ) 
            VALUES (
                TO_SINGLE_BYTE(SYS_GUID()) 
              , SRC.MEASURE_CD         
              , SRC.MEASURE_NM         
              , SRC.DESCRIP            
              , SRC.TBL_NM             
              , SRC.COL_NM             
              , SRC.MEASURE_VAL_TP_ID  
              , SRC.SYSTEM_YN          
              , SRC.BF_YN              
              , SRC.DP_YN              
              , SRC.SRP_YN 
              , SRC.CAL_YN
              , 'N'                
              , SRC.USER_ID       
              , SYSDATE      
            )
        ;
	ELSE 

				MERGE INTO TB_DP_MEASURE_MST TAR
				USING ( 
						SELECT
						 p_ID						AS 	ID					
						,p_MEASURE_CD				AS 	MEASURE_CD			
						,p_MEASURE_NM				AS 	MEASURE_NM			
						,p_DESCRIP					AS 	DESCRIP				
						,p_TBL_NM					AS 	TBL_NM				
						,p_COL_NM					AS 	COL_NM				
						,V_MEASURE_VAL_TP_ID		AS 	MEASURE_VAL_TP_ID	
						,p_SYSTEM_YN               AS 	SYSTEM_YN			
						,p_BF_YN 	             	AS 	BF_YN				
						,p_DP_YN		            AS 	DP_YN				
						,p_SRP_YN	             	AS	SRP_YN	
						,p_CAL_YN	            	AS	CAL_YN	
						,p_USER_ID					AS	USER_ID				
					  FROM dual ) SRC
				ON	  (TAR.ID			= SRC.ID)	
				WHEN MATCHED THEN
					 UPDATE 
					   SET   TAR.MEASURE_CD			= SRC.MEASURE_CD			
							,TAR.MEASURE_NM			= SRC.MEASURE_NM								  
							,TAR.DESCRIP			= SRC.DESCRIP									  			  
							,TAR.TBL_NM				= SRC.TBL_NM				
							,TAR.COL_NM				= SRC.COL_NM											  	
							,TAR.MEASURE_VAL_TP_ID	= SRC.MEASURE_VAL_TP_ID	  
							,TAR.SYSTEM_YN			= SRC.SYSTEM_YN			
							,TAR.BF_YN				= SRC.BF_YN				
							,TAR.DP_YN				= SRC.DP_YN				
							,TAR.SRP_YN				= SRC.SRP_YN		
							,TAR.CAL_YN				= SRC.CAL_YN		
							,TAR.MODIFY_BY			= SRC.USER_ID
							,TAR.MODIFY_DTTM		= SYSDATE   
				WHEN NOT MATCHED THEN 
					 INSERT (
							 ID					
							,MEASURE_CD			
							,MEASURE_NM			
							,DESCRIP				
							,TBL_NM				
							,COL_NM				
							,MEASURE_VAL_TP_ID	
							,SYSTEM_YN			
							,BF_YN				
							,DP_YN				
							,SRP_YN	
							,CAL_YN	
							,DEL_YN		
							,CREATE_BY
							,CREATE_DTTM
							) 
					 VALUES (
							TO_SINGLE_BYTE(SYS_GUID()) 
							,SRC.MEASURE_CD			
							,SRC.MEASURE_NM			
							,SRC.DESCRIP			
							,SRC.TBL_NM				
							,SRC.COL_NM				
							,SRC.MEASURE_VAL_TP_ID	
							,SRC.SYSTEM_YN			
							,SRC.BF_YN				
							,SRC.DP_YN				
							,SRC.SRP_YN	
							,SRC.CAL_YN
							,'N'				
							,SRC.USER_ID       
							,SYSDATE      
 							)
				;

    END IF;


    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';  --???？？????？？
       /* ???？o?? ============================================================================*/

EXCEPTION WHEN OTHERS THEN  -- ?？? ???？？? ?？? ???？?？ : e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;   						
END;

/

