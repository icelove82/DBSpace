create PROCEDURE                 SP_SMP_PLAN_RESULT_COPY (
    P_MP_VERSION_ID   	IN VARCHAR2,
    P_USER_ID		  	IN VARCHAR2,
    P_RT_ROLLBACK_FLAG 	OUT VARCHAR2,
    P_RT_MSG           	OUT VARCHAR2  
)
IS
	P_ERR_STATUS INT := 0;
	P_ERR_MSG VARCHAR2(4000):='';
BEGIN
	
	SELECT COUNT(*) INTO P_ERR_STATUS
       FROM TB_SMP_VER_MST
      WHERE 1=1
        AND VERSION_ID = P_MP_VERSION_ID
        AND EXE_USER_ID != P_USER_ID;
       
	 P_RT_ROLLBACK_FLAG := 'true';
     P_RT_MSG := 'MSG_0001';
     EXCEPTION
     	WHEN OTHERS THEN
     		IF(SQLCODE = -20001)
     			THEN
     				P_RT_ROLLBACK_FLAG := 'false';
     				P_RT_MSG := P_ERR_MSG;
     			ELSE
	                --SP_COMM_RAISE_ERR();              
	                RAISE;
	       END IF;
END;

/

