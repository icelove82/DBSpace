create PROCEDURE "SP_COMM_RAISE_ERR" 

IS        
BEGIN
    RAISE_APPLICATION_ERROR(-20013, '----------[Error Line : '||
        SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,INSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, ',',1,1)+1, 10) 
        ||'], [Message : '||SQLERRM||']----------');
END
;

/

