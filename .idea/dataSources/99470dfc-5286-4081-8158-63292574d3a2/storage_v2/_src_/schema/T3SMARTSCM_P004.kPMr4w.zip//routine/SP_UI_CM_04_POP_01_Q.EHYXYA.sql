create PROCEDURE SP_UI_CM_04_POP_01_Q (
        P_CONF_KEY          IN VARCHAR2 := '' ,
        P_VIEW_ID           IN VARCHAR2 := '' ,
        P_ITEM_CD           IN VARCHAR2 := '' ,
        P_ITEM_NM           IN VARCHAR2 := '' ,
        P_DESCRIP           IN VARCHAR2 := '' ,
        P_ITEM_LV           IN VARCHAR2 := '' ,
        P_ITEM_TP           IN VARCHAR2 := '' ,
        pResult OUT SYS_REFCURSOR
)
IS
BEGIN

    IF P_CONF_KEY ='001' /* SITE ITEM */
    THEN
        OPEN pResult FOR
            SELECT DISTINCT
			   B.ID				AS ITEM_MST_ID
			 , B.ITEM_CD
			 , B.ITEM_NM
			 , B.DESCRIP
			 , C.ID             AS ITEM_SCOPE_ID
			 , C.ITEM_SCOPE_NM  AS ITEM_LV_NM
             , D.ID             AS ITEM_TP_ID
			 , D.CONVN_NM	    AS ITEM_TP
			 , P_VIEW_ID		AS VIEW_ID
		  FROM 
		       TB_CM_ITEM_MST B 
			 , TB_CM_ITEM_SCOPE_MST C 
			 , TB_CM_ITEM_TYPE D 
		 WHERE 1=1
		   AND B.ITEM_TP_ID = D.ID
		   AND B.ITEM_CD LIKE '%'||LTRIM(RTRIM(P_ITEM_CD))||'%'
           AND B.ITEM_NM LIKE '%'||LTRIM(RTRIM(P_ITEM_NM))||'%'
           AND (NVL(B.DESCRIP, '') LIKE '%'||LTRIM(RTRIM(P_DESCRIP))||'%' OR P_DESCRIP IS NULL)
           AND C.ID LIKE '%'||P_ITEM_LV||'%'
           AND ITEM_TP_ID = CASE WHEN UPPER(P_ITEM_TP)='ALL' THEN ITEM_TP_ID
                             ELSE UPPER(P_ITEM_TP)
                             END;
    
    ELSIF P_CONF_KEY ='002' /* CURRENCY */
    THEN
        OPEN pResult FOR
            SELECT D.ID
                 , COMN_CD
                 , COMN_CD_NM
                 , P_VIEW_ID    AS VIEW_ID
              FROM TB_AD_COMN_CODE D
                INNER JOIN TB_AD_COMN_GRP E  		
                  ON D.SRC_ID = E.ID 
             WHERE 
                E.GRP_CD = 'CURRENCY';
    
    END IF;  

END;

/

