create PROCEDURE                SP_UI_CM_VER_CONFIRM (
    P_USER_ID        	IN VARCHAR2	    := NULL,
 	P_VER_ID			IN VARCHAR2		:= '',
	P_RT_ROLLBACK_FLAG	OUT VARCHAR2,
	P_RT_MSG			OUT VARCHAR2
)
IS
    P_ERR_STATUS 	NUMBER 			:= 0;
    P_ERR_MSG  		VARCHAR2(4000) 	:= '';
    
	P_TMP			VARCHAR2(100)	:= '';
BEGIN

	SELECT 	USER_ID INTO P_TMP
	FROM 	USERS
	WHERE 	1=1
	AND 	USER_ID = P_USER_ID
	;
	P_ERR_MSG := 'MSG_0009';
    IF NVL(P_TMP , '') =  '' THEN
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
	
	SELECT 	VER_ID INTO P_TMP
	FROM 	TB_CM_VER_MST
	WHERE 	1=1
	AND 	VER_ID = P_VER_ID
	;
	P_ERR_MSG := 'MSG_5105';
    IF NVL(P_TMP , '') =  '' THEN
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;

	/* To-do : Check Plan Status
	IF (NOT EXISTS(SELECT VER_ID FROM TB_CM_VER_MST WHERE VER_ID = @p_VER_ID AND PLAN_STATUS = 'READY')) THEN
		P_ERR_MSG := 'MSG_5105';
		RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
	END IF;
	*/
		
	/* To-do : Check Already Release
	IF (NOT EXISTS(SELECT VER_ID FROM TB_CM_VER_MST WHERE VER_ID = @p_VER_ID AND PLAN_STATUS = 'READY')) THEN
		P_ERR_MSG := 'MSG_5105';
		RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
	END IF;
	*/
	
	------------------------------------------------------
	-- Call custom procedure in this point
	------------------------------------------------------

	UPDATE 	TB_CM_VER_MST
	SET 	CONFRM_YN		= 'Y'
		  , CONFRM_BY 		= P_USER_ID
		  , CONFRM_DTTM 	= SYSDATE
	WHERE 	1=1
	AND 	VER_ID 			= P_VER_ID
	;

	P_RT_ROLLBACK_FLAG 	:= 'true';
    P_RT_MSG 			:= 'MSG_0001';

EXCEPTION
WHEN OTHERS THEN
    P_RT_ROLLBACK_FLAG := 'false';
    IF(SQLCODE = -20012)
      THEN
          P_RT_MSG := P_ERR_MSG;
      ELSE
          P_RT_MSG := SQLERRM;
      END IF;

END;

/

