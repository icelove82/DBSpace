create PACKAGE BODY                 PKG_SMP_I_MASTER
IS
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved. 
**************************************************************************
* Name    : PKG_SMP_I_MASTER
* Purpose : MP Static 정보 생성. 
* Notes   :
* 
<MASTER VALIDATIN 추가 항목> 
  1. BOM 없는 경우. 이건 좀 생각해 봐야할 듯합니다. FLO 상으로는 계획이 풀릴수도 있는 상황이라  : 조립 BOM이 없는 경우
  2. LINE 인증정보가 없는 경우 (수주확정건), 수주추진은 단/양, 폭이 일치하는 경우가 없는 경우  : CELL MASTE <-> LINE MASTER
  3. PGM MSTER ERP 코드가 없는 경우.
* 
**************************************************************************
* History :
* 2020-02-17 AIS Created  
**************************************************************************/
PRAGMA SERIALLY_REUSABLE;
-----------------------------
-- Public type declarations -
-----------------------------

---------------------------------
-- Public constant declarations -
---------------------------------

---------------------------------
-- Public variable declarations -
---------------------------------
  G_nLOG_SEQ      NUMBER;
  G_sPKG_ID       NVARCHAR2(1000) := 'PKG_SMP_I_MASTER';-- DBMS_UTILITY.FORMAT_CALL_STACK;
  G_sPROGRAMN_ID  NVARCHAR2(1000) ;
  G_sSTEP_SEQ     NVARCHAR2(50);
  G_sSTEP_DESC    NVARCHAR2(50);
  --G_sVERSION_ID   NVARCHAR2(50);
  G_sUSER_ID      NVARCHAR2(50);
  G_nSQL_CNT      NUMBER(20);
  G_sLOGMSG       VARCHAR2(4000);
---------------------------------
-- Public function declarations -
---------------------------------

----------------------------------
-- Public procedure declarations -
----------------------------------
 
PROCEDURE SP_SET_PLAN_OPTION (
  P_sENGINE_ID   IN  VARCHAR2
, P_sVERSION_ID  IN  VARCHAR2  
, P_sBASE_MONTH  IN  VARCHAR2
, P_sPLAN_DESC   IN  VARCHAR2
, O_tPLAN_OPTION IN OUT TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_PLAN_OPTION
* Purpose : Plan Option 생성 
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic] 
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
IS  
  USR_EXCEPT            EXCEPTION;
BEGIN  
  O_sFLAG := 'S';

  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_PLAN_OPTION';

  --*Set General----------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Set General Plan Option';   
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID); 
 
  O_tPLAN_OPTION.VERSION_ID    :=  P_sVERSION_ID   ;
  O_tPLAN_OPTION.BASE_MONTH    :=  P_sBASE_MONTH   ;
  O_tPLAN_OPTION.ENGINE_ID     :=  P_sENGINE_ID    ;
  O_tPLAN_OPTION.PLAN_DESC     :=  P_sPLAN_DESC    ;

  --*아래 옵션은 UI에서 관리하지 않으나 향후 변경시 사용하기 위하여 Option으로 관리함.
  O_tPLAN_OPTION.APPLY_SVC_LEVEL_YN   := 'Y';
  O_tPLAN_OPTION.USED_BOM_TYPE        := 'PLAN_BOM';
  O_tPLAN_OPTION.USED_STOCK_YN        := 'Y'; --재고 반영 여부
  O_tPLAN_OPTION.USED_FIXED_PLAN_YN   := 'Y'; --확정 계획 반영 여부
  O_tPLAN_OPTION.USED_DYNAMIC_RATE_YN := 'Y';

  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, 4);
  ------------------------------------------------------------------------------------------------------

  --*Init. Working Plan Option--------------------------------------------------------------------------
  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Get Route Info.';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);  
  SELECT NVL(MAX(DECODE(ATTR_04, 'E', CONF_CD)), 'BEL')
        ,NVL(MAX(DECODE(ATTR_04, 'A', CONF_CD)), 'BAS')
        ,'BOD'
    INTO O_tPLAN_OPTION.ELEC_ROUTE_CD
        ,O_tPLAN_OPTION.ASSY_ROUTE_CD 
        ,O_tPLAN_OPTION.BOD_ROUTE_CD 
    FROM TB_CM_COMM_CONFIG    CCC
        ,TB_CM_CONFIGURATION  CFG
   WHERE CCC.CONF_GRP_CD      = 'ROUTE'
     AND CCC.USE_YN           = 'Y'
     AND CCC.ACTV_YN          = 'Y'
     AND CCC.CONF_ID          = CFG.ID(+)
     AND CFG.MODULE_CD(+)     = 'SMP'
     AND CFG.ACTV_YN  (+)     = 'Y' 
  ;  
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
    
  --*Get Variable Bucket---------------------------------------------------------------------------------
  G_sSTEP_SEQ := '3.0';   
  G_sSTEP_DESC := 'Get Variable Bucket'; 
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);    
  SELECT CASE WHEN BUCKET_1_UNIT IN ('월', '개월') THEN TO_NUMBER(BUCKET_1)
              WHEN BUCKET_1_UNIT IN ('년')        THEN TO_NUMBER(BUCKET_1) * 12     
         END  
        ,CASE WHEN BUCKET_2_UNIT IN ('월', '개월') THEN TO_NUMBER(BUCKET_2)
              WHEN BUCKET_2_UNIT IN ('년')        THEN TO_NUMBER(BUCKET_2) * 12     
         END
        ,CASE WHEN BUCKET_3_UNIT IN ('월', '개월') THEN TO_NUMBER(BUCKET_3)
              WHEN BUCKET_3_UNIT IN ('년')        THEN TO_NUMBER(BUCKET_3) * 12     
         END         
    INTO O_tPLAN_OPTION.BUCKET_1_MONTH_VAL
        ,O_tPLAN_OPTION.BUCKET_2_MONTH_VAL
        ,O_tPLAN_OPTION.BUCKET_3_MONTH_VAL
    FROM (
          SELECT MAX(DECODE(CONF_CD, 'FIRST_BUCKET' , ATTR_01)) BUCKET_1
                ,MAX(DECODE(CONF_CD, 'SECOND_BUCKET', ATTR_01)) BUCKET_2
                ,MAX(DECODE(CONF_CD, 'THIRD_BUCKET' , ATTR_01)) BUCKET_3
                ,MAX(DECODE(CONF_CD, 'FIRST_BUCKET' , ATTR_02)) BUCKET_1_UNIT
                ,MAX(DECODE(CONF_CD, 'SECOND_BUCKET', ATTR_02)) BUCKET_2_UNIT
                ,MAX(DECODE(CONF_CD, 'THIRD_BUCKET' , ATTR_02)) BUCKET_3_UNIT                
            FROM TB_CM_COMM_CONFIG   CCC
                ,TB_CM_CONFIGURATION CFG
           WHERE CCC.CONF_GRP_CD     = 'VARIABLE_BUCKET'
             AND CCC.USE_YN          = 'Y'
             AND CCC.ACTV_YN         = 'Y'
             AND CCC.CONF_ID         = CFG.ID(+)
             AND CFG.MODULE_CD(+)    = 'SMP'
             AND CFG.ACTV_YN  (+)    = 'Y'           
         ) M
  ;  
--*[V2 AIS]**************************************************************************************
  O_tPLAN_OPTION.BUCKET_1_MONTH_VAL := 6;
  O_tPLAN_OPTION.BUCKET_2_MONTH_VAL := 54;
--*[V2 AIS]**************************************************************************************

  IF O_tPLAN_OPTION.BUCKET_1_MONTH_VAL IS NULL THEN
    G_sLOGMSG := 'Not defined First Bucket Info.';
    RAISE USR_EXCEPT;
  END IF;
 
  IF O_tPLAN_OPTION.BUCKET_2_MONTH_VAL IS NULL THEN
    G_sLOGMSG := 'Not defined Second Bucket Info.';
    RAISE USR_EXCEPT;
  END IF;

  IF O_tPLAN_OPTION.BUCKET_3_MONTH_VAL IS NULL THEN
    G_sLOGMSG := 'Not defined Third Bucket Info.';
    RAISE USR_EXCEPT;
  END IF;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);  
  ------------------------------------------------------------------------------------------------------
  
  --*Get Variable Plan Month----------------------------------------------------------------------------
  G_sSTEP_SEQ := '4.0';   
  G_sSTEP_DESC := 'Get Variable Plan Month';   
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID); 
  SELECT --MAX(DECODE(CONF_CD, 'FIXED_PLAN_MONTH'      , ATTR_01)) --법인별로 관리로 삭제
         MAX(DECODE(CONF_CD, 'MAT_CONSTRAINT_MONTH'  , ATTR_01))
        ,MAX(DECODE(CONF_CD, 'PLAN_PST_MONTH'        , ATTR_01))
        ,MAX(DECODE(CONF_CD, 'ROLLING_HORIZON_MONTH' , ATTR_01))   
    INTO O_tPLAN_OPTION.MAT_CONSTRAINT_MONTH
        ,O_tPLAN_OPTION.PLAN_PST_MONTH 
        ,O_tPLAN_OPTION.ROLLING_HORIZON_MONTH
    FROM TB_CM_COMM_CONFIG   CCC
        ,TB_CM_CONFIGURATION CFG
   WHERE CCC.CONF_GRP_CD     = 'PLAN_MONTH'
     AND CCC.USE_YN          = 'Y'
     AND CCC.ACTV_YN         = 'Y'
     AND CCC.CONF_ID         = CFG.ID(+)
     AND CFG.MODULE_CD(+)    = 'SMP'
     AND CFG.ACTV_YN  (+)    = 'Y'       
  ;

  IF O_tPLAN_OPTION.MAT_CONSTRAINT_MONTH  IS NULL THEN
    G_sLOGMSG := 'Not defined Constraint Months Info.';
    PKG_SMP_LOGGER.stepDEBUG (G_nLOG_SEQ, G_sLOGMSG, P_sVERSION_ID, G_sUSER_ID);
    --RAISE USR_EXCEPT;
  END IF;

  IF O_tPLAN_OPTION.PLAN_PST_MONTH        IS NULL THEN
    G_sLOGMSG := 'Not exists Config.[PLAN_MONTH][PLAN_PST_MONTH]';
    PKG_SMP_LOGGER.stepDEBUG (G_nLOG_SEQ, G_sLOGMSG, P_sVERSION_ID, G_sUSER_ID);
    --RAISE USR_EXCEPT;
  END IF;

  IF O_tPLAN_OPTION.ROLLING_HORIZON_MONTH IS NULL THEN
    G_sLOGMSG := 'Not exists Config.[PLAN_MONTH][ROLLING_HORIZON_MONTH]';
    RAISE USR_EXCEPT;
  END IF;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------  
    
  --*Set General----------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '5.0';   
  G_sSTEP_DESC := 'Set Cal. Value';   
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID); 
  
  O_tPLAN_OPTION.START_DATE          := TO_DATE(P_sBASE_MONTH || '01' , 'YYYYMMDD');

  -- 계획 시작월이 ROLLING 기준월에 도달하면 월 버켓구간은 1년 추가됨.
  IF TO_CHAR(O_tPLAN_OPTION.START_DATE ,'MM') >= O_tPLAN_OPTION.ROLLING_HORIZON_MONTH THEN 
    O_tPLAN_OPTION.BUCKET_2_MONTH_VAL := O_tPLAN_OPTION.BUCKET_2_MONTH_VAL + 12;
  END IF;

--*[V2 AIS]**************************************************************************************
  --O_tPLAN_OPTION.BUCKET_2_START_DATE := ADD_MONTHS(O_tPLAN_OPTION.START_DATE, O_tPLAN_OPTION.BUCKET_1_MONTH_VAL);
  SELECT MIN(DAT)
  INTO   O_tPLAN_OPTION.BUCKET_2_START_DATE
  FROM   TB_CM_CALENDAR 
  WHERE  DAT  >= ADD_MONTHS(O_tPLAN_OPTION.START_DATE, O_tPLAN_OPTION.BUCKET_1_MONTH_VAL) 
  AND    DOW   = 1 --월요일
  ;
--*[V2 AIS]**************************************************************************************

  
  O_tPLAN_OPTION.BUCKET_3_START_DATE := TO_DATE( TO_CHAR( 
                                                         ADD_MONTHS(O_tPLAN_OPTION.START_DATE, O_tPLAN_OPTION.BUCKET_2_MONTH_VAL)
                                                        ,'YYYY' ) || '0101'
                                                ,'YYYYMMDD' );
  
  
  O_tPLAN_OPTION.END_DATE            := ADD_MONTHS(O_tPLAN_OPTION.BUCKET_3_START_DATE, O_tPLAN_OPTION.BUCKET_3_MONTH_VAL ) - 1/24/60/60;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, 4);
  ------------------------------------------------------------------------------------------------------  

  
  --*Init. Working Plan Option--------------------------------------------------------------------------
  G_sSTEP_SEQ := '6.0';   
  G_sSTEP_DESC := 'Get Cutoff date';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);  
  SELECT MAX(SDI.CUTOFF_DATE)
    INTO O_tPLAN_OPTION.CUTOFF_DATE
    FROM TB_SMP_DEMAND_INFO SDI
   WHERE SDI.CUTOFF_DATE    <= TO_CHAR(O_tPLAN_OPTION.START_DATE, 'YYYYMMDD')
  ;
  O_tPLAN_OPTION.CUTOFF_DATE      := '20200101';
  IF O_tPLAN_OPTION.CUTOFF_DATE IS NULL THEN
    G_sLOGMSG := 'Not exists Demand.[TB_SMP_DEMAND_INFO][CUTOFF_DATE]';
    RAISE USR_EXCEPT;
  END IF;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------  
  
  --*Plan Constraints Option----------------------------------------------------------------------------
  G_sSTEP_SEQ := '7.0';   
  G_sSTEP_DESC := 'Get Plan Constraints Option';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);  
  BEGIN
    SELECT NVL(CCC.ATTR_02, 'N') AS CONSTRAINT_ELEC_YN
          ,NVL(CCC.ATTR_03, 'N') AS CONSTRAINT_MAT_YN
      INTO O_tPLAN_OPTION.CONSTRAINT_ELEC_YN
          ,O_tPLAN_OPTION.CONSTRAINT_MAT_YN
      FROM TB_CM_COMM_CONFIG     CCC
          ,TB_CM_CONFIGURATION   CFG    
     WHERE CCC.CONF_GRP_CD       = 'PLAN_STEP_CFG'
       AND CCC.USE_YN            = 'Y'
       AND CCC.CONF_ID           = CFG.ID
       AND CFG.MODULE_CD         = 'SMP'
       AND CFG.ACTV_YN           = 'Y'   
       AND CCC.ATTR_01           = (SELECT V.PLAN_TYPE FROM TB_SMP_VER_MST V WHERE V.VERSION_ID = P_sVERSION_ID) --'MP1'
    ;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      O_tPLAN_OPTION.CONSTRAINT_ELEC_YN := 'N'; --전극CAPA 제약   
      O_tPLAN_OPTION.CONSTRAINT_MAT_YN  := 'N';    
  END;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------        
  
  --*Get Plan Verion Option----------------------------------------------------------------------------
  G_sSTEP_SEQ := '8.0';   
  G_sSTEP_DESC := 'Get Plan Plan Ver. Option';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);  
  BEGIN
    SELECT NVL(V.P_PGM_APPLY_YN, 'N')
      INTO O_tPLAN_OPTION.PROGRESS_ORDER_YN--수주추진 포함여부
      FROM TB_SMP_VER_MST        V    
     WHERE V.VERSION_ID          = P_sVERSION_ID
    ;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      G_sLOGMSG := 'Not exists Plan Version';
      RAISE USR_EXCEPT;
  END;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------   

  --*Get Material Balance Version-----------------------------------------------------------------------
  IF O_tPLAN_OPTION.CONSTRAINT_MAT_YN = 'Y' THEN
    G_sSTEP_SEQ := '9.0';   
    G_sSTEP_DESC := 'Get Mat. Balance Version';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);  
    BEGIN
      SELECT VERSION_ID
        INTO O_tPLAN_OPTION.REF_VERSION_ID 
        FROM (           
              SELECT VERSION_ID, ROW_NUMBER() OVER (ORDER BY CONFIRM_DTTM DESC, VERSION_ID DESC) RNK
                --INTO O_tPLAN_OPTION.REF_VERSION_ID 
                FROM TB_SMP_VER_MST
               WHERE BASE_MONTH      = O_tPLAN_OPTION.BASE_MONTH 
--[AIS_TOD] 최종 승인된것 조건 추가해야 함. 현재는 테스트를 위해 풀어놓음
                 --AND CONFIRM_DTTM IS NOT NULL
                 AND PLAN_TYPE IN (
                      SELECT CCC.ATTR_01 AS PLAN_TYPE
                        FROM TB_CM_COMM_CONFIG     CCC
                            ,TB_CM_CONFIGURATION   CFG    
                       WHERE CCC.CONF_GRP_CD       = 'PLAN_STEP_CFG'
                         AND CCC.USE_YN            = 'Y'
                         AND CCC.CONF_ID           = CFG.ID
                         AND CFG.MODULE_CD         = 'SMP'
                         AND CFG.ACTV_YN           = 'Y' 
                         AND CCC.CONF_CD           = 'MP1')
                 AND STATUS_CD      = 'C'             
             )
         WHERE RNK = 1
      ;  
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        G_sLOGMSG := 'Not exists Plan Version';
        RAISE USR_EXCEPT;
    END;
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  END IF;
  ------------------------------------------------------------------------------------------------------  
    
  --*Init. Working Plan Option--------------------------------------------------------------------------
  G_sSTEP_SEQ := '10.0';   
  G_sSTEP_DESC := 'Init. Working Plan Option';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);  
  DELETE FROM TB_SMP_WK_PLAN_OPTION
  WHERE VERSION_ID = P_sVERSION_ID
  ;  
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------

  --*Set Plan Option Working Table----------------------------------------------------------------------
  G_sSTEP_SEQ := '11.0';    
  G_sSTEP_DESC := 'Set Plan Option Working Table'; 
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID); 
  INSERT INTO TB_SMP_WK_PLAN_OPTION(VERSION_ID, CONFIG_ID, CONFIG_VALUE)
  SELECT O_tPLAN_OPTION.VERSION_ID, CD, VAL
    FROM ( 
          SELECT 'BASE_MONTH'             AS CD , O_tPLAN_OPTION.BASE_MONTH                                 AS VAL FROM DUAL UNION ALL
          SELECT 'ENGINE_ID'              AS CD , O_tPLAN_OPTION.ENGINE_ID                                  AS VAL FROM DUAL UNION ALL
          SELECT 'START_DATE'             AS CD , TO_CHAR(O_tPLAN_OPTION.START_DATE , 'YYYY-MM-DD')         AS VAL FROM DUAL UNION ALL
          SELECT 'END_DATE'               AS CD , TO_CHAR(O_tPLAN_OPTION.END_DATE   , 'YYYY-MM-DD')         AS VAL FROM DUAL UNION ALL
          SELECT 'PLAN_PST_MONTH'         AS CD , TO_CHAR(O_tPLAN_OPTION.PLAN_PST_MONTH        )            AS VAL FROM DUAL UNION ALL
          SELECT 'ROLLING_HORIZON_MONTH'  AS CD , TO_CHAR(O_tPLAN_OPTION.ROLLING_HORIZON_MONTH )            AS VAL FROM DUAL UNION ALL
          SELECT 'MAT_CONSTRAINT_MONTH'   AS CD , TO_CHAR(O_tPLAN_OPTION.MAT_CONSTRAINT_MONTH  )            AS VAL FROM DUAL UNION ALL
          SELECT 'BUCKET_1_MONTH_VAL'     AS CD , TO_CHAR(O_tPLAN_OPTION.BUCKET_1_MONTH_VAL)                AS VAL FROM DUAL UNION ALL
          SELECT 'BUCKET_2_MONTH_VAL'     AS CD , TO_CHAR(O_tPLAN_OPTION.BUCKET_2_MONTH_VAL)                AS VAL FROM DUAL UNION ALL
          SELECT 'BUCKET_3_MONTH_VAL'     AS CD , TO_CHAR(O_tPLAN_OPTION.BUCKET_3_MONTH_VAL)                AS VAL FROM DUAL UNION ALL
          SELECT 'BUCKET_2_START_DATE'    AS CD , TO_CHAR(O_tPLAN_OPTION.BUCKET_2_START_DATE, 'YYYY-MM-DD') AS VAL FROM DUAL UNION ALL
          SELECT 'BUCKET_3_START_DATE'    AS CD , TO_CHAR(O_tPLAN_OPTION.BUCKET_3_START_DATE, 'YYYY-MM-DD') AS VAL FROM DUAL UNION ALL
          SELECT 'PLAN_DESC'              AS CD , O_tPLAN_OPTION.PLAN_DESC                                  AS VAL FROM DUAL UNION ALL
          SELECT 'REF_VERSION_ID'         AS CD , O_tPLAN_OPTION.REF_VERSION_ID                             AS VAL FROM DUAL UNION ALL
          SELECT 'ELEC_ROUTE_CD'          AS CD , O_tPLAN_OPTION.ELEC_ROUTE_CD                              AS VAL FROM DUAL UNION ALL
          SELECT 'ASSY_ROUTE_CD'          AS CD , O_tPLAN_OPTION.ASSY_ROUTE_CD                              AS VAL FROM DUAL UNION ALL
          SELECT 'BOD_ROUTE_CD'           AS CD , O_tPLAN_OPTION.BOD_ROUTE_CD                               AS VAL FROM DUAL UNION ALL
          SELECT 'CUTOFF_DATE'            AS CD , O_tPLAN_OPTION.CUTOFF_DATE                                AS VAL FROM DUAL UNION ALL
          SELECT 'APPLY_SVC_LEVEL_YN'     AS CD , O_tPLAN_OPTION.APPLY_SVC_LEVEL_YN                         AS VAL FROM DUAL UNION ALL
          SELECT 'CONSTRAINT_ELEC_YN'     AS CD , O_tPLAN_OPTION.CONSTRAINT_ELEC_YN                         AS VAL FROM DUAL UNION ALL
          SELECT 'PROGRESS_ORDER_YN'      AS CD , O_tPLAN_OPTION.PROGRESS_ORDER_YN                          AS VAL FROM DUAL UNION ALL
          SELECT 'CONSTRAINT_MAT_YN'      AS CD , O_tPLAN_OPTION.CONSTRAINT_MAT_YN                          AS VAL FROM DUAL UNION ALL          
          SELECT 'USED_BOM_TYPE'          AS CD , O_tPLAN_OPTION.USED_BOM_TYPE                              AS VAL FROM DUAL UNION ALL
          SELECT 'USED_STOCK_YN'          AS CD , O_tPLAN_OPTION.USED_STOCK_YN                              AS VAL FROM DUAL UNION ALL
          SELECT 'USED_FIXED_PLAN_YN'     AS CD , O_tPLAN_OPTION.USED_FIXED_PLAN_YN                         AS VAL FROM DUAL UNION ALL
          SELECT 'USED_DYNAMIC_RATE_YN'   AS CD , O_tPLAN_OPTION.USED_DYNAMIC_RATE_YN                       AS VAL FROM DUAL          
          )
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
 
EXCEPTION
  WHEN USR_EXCEPT THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);     
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);    
END;

PROCEDURE SP_SET_WORK_DEMAND (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_WORK_DEMAND
* Purpose : Working Demand 생성
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
* 
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
IS  
  USR_EXCEPT                EXCEPTION;
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_WORK_DEMAND';

  --*Init. Working Demand-------------------------------------------------------------------------------
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Init. Working Demand';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  DELETE FROM TB_SMP_WK_DEMAND
  WHERE VERSION_ID = P_tPLAN_OPTION.VERSION_ID
  ;  
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --*Set Working Demand---------------------------------------------------------------------------------
  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Set Working Demand';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);    
  INSERT INTO TB_SMP_WK_DEMAND (
         VERSION_ID    
        ,DEMAND_ID     
        ,INVENTORY_ID  
        ,QTY           
        ,DUE_DATE  
        ,BASE_MONTH        
        ,PST           
        ,PRIORITY  
        ,DEMAND_TYPE   
        ,DEMAND_BUCKET_TYPE
        ,COLOR         
        ,PGM_D_CD      
        ,PGM_STATUS_CD
        ,T_CONTINENT_CD
        ,ITEM_CD       
        ,CELL_CD
        ,CELL_ITEM_CD
        ,OEM_CD
        ,POLAR_DIRECTION_CD
        ,WIDTH_TYPE_CD        
        ,USE_FLAG
        ,REG_DTTM
        ,REG_USER_ID)
  SELECT P_tPLAN_OPTION.VERSION_ID 
        ,DEMAND_ID
        ,INVENTORY_ID
        ,QTY  
        ,DUE_DATE
        ,BASE_MONTH        
        ,PST  
        ,PRIORITY        
        ,DEMAND_TYPE
        ,CASE WHEN DUE_DATE < P_tPLAN_OPTION.BUCKET_2_START_DATE THEN 'DAY'
              WHEN DUE_DATE < P_tPLAN_OPTION.BUCKET_3_START_DATE THEN 'MONTH'
              ELSE                                                    'YEAR'
         END AS DEMAND_BUCKET_TYPE
        --,COLOR_RNK        
        --,CASE WHEN M.COLOR_RNK > 25 THEN tCOLOR(0) ELSE tCOLOR(1) END 
        ,CASE COLOR_RNK WHEN  1 THEN '#FF0000'   
                        WHEN  2 THEN '#800000'   
                        WHEN  3 THEN '#A0522D'   
                        WHEN  4 THEN '#CD5C5C'   
                        WHEN  5 THEN '#FF7F50'   
                        WHEN  6 THEN '#F4A460'   
                        WHEN  7 THEN '#FFA500'   
                        WHEN  8 THEN '#D2BF8C'   
                        WHEN  9 THEN '#DEB887'   
                        WHEN 10 THEN '#0000FF'   
                        WHEN 11 THEN '#6A5ACD'   
                        WHEN 12 THEN '#9932CC'   
                        WHEN 13 THEN '#FFFF00'   
                        WHEN 14 THEN '#7CFC00'   
                        WHEN 15 THEN '#32CD32'   
                        WHEN 16 THEN '#556B2F'   
                        WHEN 17 THEN '#3CB371'   
                        WHEN 18 THEN '#98FB98'   
                        WHEN 19 THEN '#008080'   
                        WHEN 20 THEN '#E6E6FA'   
                        WHEN 21 THEN '#FF1493'   
                        WHEN 22 THEN '#E0FFFF'   
                        WHEN 23 THEN '#2F4F4F'   
                        WHEN 24 THEN '#FFFFF0'   
                        WHEN 25 THEN '#4B0082'
                                ELSE '#808080' 
         END                                                    AS COLOR          
        ,PGM_D_CD  
        ,PGM_STATUS_CD
        ,T_CONTINENT_CD
        ,ITEM_CD 
        ,CELL_CD  
        ,CELL_ITEM_CD
        ,OEM_CD
        ,POLAR_DIRECTION_CD
        ,WIDTH_TYPE_CD        
        ,'Y'                                                    AS USE_FLAG
        ,SYSDATE                                                AS REG_DTTM 
        ,G_sUSER_ID                                             AS REG_USER_ID 
    FROM (
          SELECT /*+ USE_HASH(DIN, DPM, SCM) INDEX(DPM PK_TB_SMP_DEMAND_PGM_MST)*/
                 DIN.DEMAND_ID
        --[AIS_TODO]   품목이 없으면 어떻게 처리할지      
                ,NVL(DPM.ITEM_CD, DPM.PGM_D_CD)   || '@' || DPM.OEM_TO_SITE_CD
                                                                        AS INVENTORY_ID
        --[AIS_TODO] 소수점이 있는데 ???
                ,DIN.DEMAND_QTY                                         AS QTY   
                ,LAST_DAY(TO_DATE(DIN.BASE_MONTH || '01', 'YYYYMMDD')) + 1 - (1/24/60/60)  
                                                                        AS DUE_DATE
                ,DIN.BASE_MONTH                                                                                    
                ,NULL                                                   AS PST  --SO PST는 없음( 조립PST 사용 )
                ,TO_NUMBER(RPAD( DECODE(DPM.PGM_STATUS_CD, 'C', '1', '9')  --1자리 = 1:수주확정  , 9:수주진행 
                                  || DIN.BASE_MONTH                        --2~7 = DEMAND 년월
                                  || DIN.SVC_LEVEL_PRIORITY                --8자리 = 1:서비스레벨(내), 9:서비스레벨(외)
                                ,15 , '0'
                               )   
                          )         
                    + RANK() OVER ( PARTITION BY DPM.PGM_STATUS_CD, DIN.BASE_MONTH ORDER BY DIN.PGM_D_CD ) --9~15 
                                                                       AS PRIORITY
/*
MERGE INTO SKIPDB.SALESORDER TAR
USING(
      SELECT ROW_NUMBER() OVER (PARTITION BY P0, P1, P2, P3 ORDER BY PRIORITY) P4
            ,M.*
      FROM  (
            SELECT '1' P0
                 , FLOOR(MONTHS_BETWEEN(TO_DATE(TO_CHAR(DUE_DATE, 'YYYYMM'), 'YYYYMM'), TO_DATE('202004','YYYYMM')) / 6)  P1
                 , CASE WHEN SALESORDER_ID LIKE '%(1)' THEN '1' ELSE '2' END P2
                 , TO_CHAR(DUE_DATE, 'YYYYMM') P3
                 , X.*
                 , X.ROWID ROW_ID
            FROM   SKIPDB.SALESORDER X
            WHERE  ENGINE_ID = 'MP'
            --AND    PRIORITY LIKE '1%'
            ORDER BY DUE_DATE, PRIORITY
            ) M
       ) SRC
ON (SRC.ROW_ID = TAR.ROWID)
WHEN MATCHED THEN
UPDATE 
   SET TAR.DESCRIPTION = TAR.PRIORITY
      ,TAR.PRIORITY    = P0 || P1 || P2|| P3 || LPAD(P4, 4, '0')
 */                                                                       
                                                                       
--[AIS_TOD]                                                                       
                ,NULL                                                   AS DEMAND_TYPE
                ,DENSE_RANK() OVER ( ORDER BY SCM.WIDTH_VAL, SCM.LENGTH_VAL, SCM.THICKNESS_VAL)
                                                                        AS COLOR_RNK          
                ,DIN.PGM_D_CD 
                ,DPM.PGM_STATUS_CD
                ,DPM.OEM_TO_SITE_CD                                     AS T_CONTINENT_CD
        --[AIS_TODO]   품목이 없으면 어떻게 처리할지      
                ,NVL(DPM.ITEM_CD, DPM.PGM_D_CD)                         AS ITEM_CD
                ,DPM.CELL_CD  
                ,SCM.ITEM_CD                                            AS CELL_ITEM_CD
                ,DPM.OEM_CD
                ,SCM.POLAR_DIRECTION_CD
                ,SCM.WIDTH_TYPE_CD
            FROM ( 
                  SELECT D.PGM_D_CD || '_' || D.BASE_MONTH || '(1)' AS DEMAND_ID
                        ,'1'                                        AS SVC_LEVEL_PRIORITY  --100000000
                        ,DECODE(P_tPLAN_OPTION.APPLY_SVC_LEVEL_YN, 'Y', D.SVC_UNDR_QTY, D.QTY) -- 서비스레벨 비적용시 전체 DEMAND를 대상으로 함.                      
                                                                    AS DEMAND_QTY
                        ,D.*
                    FROM TB_SMP_DEMAND_INFO     D
                   WHERE D.CUTOFF_DATE          = P_tPLAN_OPTION.CUTOFF_DATE
                     AND NVL(D.SVC_UNDR_QTY, 0) > 0
                     AND D.BASE_MONTH          >= P_tPLAN_OPTION.BASE_MONTH
                     AND D.BASE_MONTH          <= TO_CHAR(P_tPLAN_OPTION.END_DATE, 'YYYYMMDD')                         
                  UNION ALL   
                  SELECT D.PGM_D_CD || '_' || D.BASE_MONTH || '(2)' AS DEMAND_ID
                        ,'9'                                        AS SVC_LEVEL_PRIORITY --900000000
                        ,D.SVC_OVER_QTY                             AS DEMAND_QTY
                        ,D.*
                    FROM TB_SMP_DEMAND_INFO     D
                   WHERE D.CUTOFF_DATE          = P_tPLAN_OPTION.CUTOFF_DATE
                     AND NVL(D.SVC_OVER_QTY, 0) > 0
                     AND D.BASE_MONTH          >= P_tPLAN_OPTION.BASE_MONTH
                     AND D.BASE_MONTH          <= TO_CHAR(P_tPLAN_OPTION.END_DATE, 'YYYYMMDD')   
                     AND P_tPLAN_OPTION.APPLY_SVC_LEVEL_YN = 'Y'
                 ) DIN
                ,TB_SMP_DEMAND_PGM_MST    DPM
                ,TB_SMP_CELL_MST          SCM
           WHERE DIN.CUTOFF_DATE          = P_tPLAN_OPTION.CUTOFF_DATE
             AND DIN.PGM_D_CD             = DPM.PGM_D_CD 
             AND DPM.CELL_CD              = SCM.CELL_CD    
             AND ( --* 수주 추진 포함여부 체크
                  (P_tPLAN_OPTION.PROGRESS_ORDER_YN = 'Y' )
                  OR 
                  (P_tPLAN_OPTION.PROGRESS_ORDER_YN = 'N' AND DPM.PGM_STATUS_CD = 'C')
                 ) 
        ) MST
  ;   
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------

  --*Set Assy Route PST---------------------------------------------------------------------------------
  G_sSTEP_SEQ := '3.0';   
  G_sSTEP_DESC := 'Set Working Demand Assy PST';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  UPDATE TB_SMP_WK_DEMAND   SWD
     SET SWD.ASSY_ROUTE_PST 
         = 
         CASE SWD.DEMAND_BUCKET_TYPE WHEN 'YEAR'   THEN 
              ADD_MONTHS( TO_DATE(SUBSTR(SWD.BASE_MONTH,1,4) || '0101', 'YYYYMMDD'),  -12) -- 년 BUCKET에 존재하는 물량은 PST를 1년으로 함.
         ELSE 
              ADD_MONTHS( TO_DATE(SWD.BASE_MONTH || '01', 'YYYYMMDD'), -1 * P_tPLAN_OPTION.PLAN_PST_MONTH)
         END
   WHERE VERSION_ID         = P_tPLAN_OPTION.VERSION_ID
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --*Set Elec. Route PST--------------------------------------------------------------------------------
  G_sSTEP_SEQ := '4.0';   
  G_sSTEP_DESC := 'Set Working Demand Elec. PST';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  UPDATE TB_SMP_WK_DEMAND   SWD
     SET SWD.ELEC_ROUTE_PST 
         = 
         CASE SWD.DEMAND_BUCKET_TYPE WHEN 'DAY'   THEN SWD.ASSY_ROUTE_PST - 15
                                     WHEN 'MONTH' THEN ADD_MONTHS(SWD.ASSY_ROUTE_PST, -1)
                                     ELSE              SWD.ASSY_ROUTE_PST
         END
   WHERE VERSION_ID         = P_tPLAN_OPTION.VERSION_ID
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_sFLAG   := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

PROCEDURE SP_SET_WORK_FIXED_ORD (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_WORK_FIXED_ORD
* Purpose : Working Fixed Order 생성
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
* 
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
IS  
  USR_EXCEPT                EXCEPTION;
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_WORK_FIXED_ORD';

  --*Init. Working Demand-------------------------------------------------------------------------------
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Init. Working Fixed Order';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  DELETE FROM TB_SMP_WK_FIXED_PROD
  WHERE VERSION_ID = P_tPLAN_OPTION.VERSION_ID
  ;  
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT); 
  ------------------------------------------------------------------------------------------------------
  
  --*Set Working Demand---------------------------------------------------------------------------------
  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Set Working Fixed Order';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);    
  INSERT INTO TB_SMP_WK_FIXED_PROD (
         VERSION_ID      
        ,FIXED_ORDER_ID  
        ,SITE_CD         
        ,ITEM_CD         
        ,LINE_CD         
        --,PGM_D_CD        
        ,PLAN_MONTH      
        ,OEM_CD          
        ,CELL_CD         
        ,QTY             
        ,REG_DTTM        
        ,REG_USER_ID     )
  SELECT P_tPLAN_OPTION.VERSION_ID AS VERSION_ID      
        ,'PLO_H_' || LPAD(ROW_NUMBER() OVER (ORDER BY SFP.PLAN_MONTH, SFP.ITEM_CD), 4, '0')  AS FIXED_ORDER_ID
        ,SFP.SITE_CD         
        ,SFP.ITEM_CD         
        ,SFP.LINE_CD         
        --,SFP.PGM_D_CD        
        ,SFP.PLAN_MONTH      
        ,SFP.OEM_CD          
        ,SFP.CELL_CD         
        ,SFP.QTY             
        ,SYSDATE       REG_DTTM       
        ,G_sUSER_ID    REG_USER_ID     
    FROM TB_SMP_FIXED_PROD SFP
        ,TB_SMP_SITE_MST   SSM
   WHERE SFP.SITE_CD       = SSM.SITE_CD
     AND SFP.PLAN_MONTH   >= P_tPLAN_OPTION.BASE_MONTH
     AND SFP.PLAN_MONTH   <  TO_CHAR( ADD_MONTHS(TO_DATE(P_tPLAN_OPTION.BASE_MONTH, 'YYYYMM'), SSM.MP_FIXED_MM_VAL), 'YYYYMM')
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_sFLAG   := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

PROCEDURE SP_SET_WORK_BOM (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_WORK_BOM
* Purpose : Working BOM 생성
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_WORK_BOM';

  --*Init. Working BOM----------------------------------------------------------------------------------
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Init. Working BOM';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);    
  DELETE FROM TB_SMP_WK_BOM
  WHERE VERSION_ID = P_tPLAN_OPTION.VERSION_ID
  ;  
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --*Set Working BOM------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Set Working BOM';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);      
  IF P_tPLAN_OPTION.USED_BOM_TYPE = 'PLAN_BOM' THEN
    INSERT INTO TB_SMP_WK_BOM(
           VERSION_ID
          ,SITE_CD     
          ,P_ITEM_CD   
          ,C_ITEM_CD   
          ,P_UNIT_QTY  
          ,P_UOM       
          ,C_UNIT_QTY  
          ,C_UOM       
          ,P_ITEM_TYPE_CD
          ,C_ITEM_TYPE_CD
          ,CONTINENT_CD
          ,P_ROUTE_CD
          ,C_ROUTE_CD
          ,P_INVENTORY_ID
          ,C_INVENTORY_ID
          ,ROUTE_ID  
          ,T_CONTINENT_CD
          ,LEAD_TIME
          ,ELEC_CAL_HIS)  
    WITH W_1BOM AS (  
      --*1. PACK부터 전극 자품모까지만 생성
      SELECT  SB.SITE_CD  -- 20200423 장문석K 추가
             ,SB.P_ITEM_CD 
             ,SB.C_ITEM_CD 
             ,SB.P_UNIT_QTY 
             ,SB.P_UOM 
             ,SB.C_UNIT_QTY 
             ,SB.C_UOM 
             ,NULL           AS ELEC_CAL_HIS
        FROM TB_SMP_BOM SB
       WHERE 1=1  
         --+ 조립 품목 BOM에서 제외(모품목)----------------------------------------------------
         AND NOT EXISTS (
             SELECT 1
               FROM TB_SMP_ITEM_MST       SIM 
                   ,TB_SMP_ITEM_BASE_INFO IBI
                   ,TB_CM_COMM_CONFIG     CCC
                   ,TB_CM_CONFIGURATION   CFG    
              WHERE SIM.PN_CD             = IBI.PN_CD    
                AND IBI.ATTR_01           = CCC.ATTR_02  
                AND CCC.CONF_GRP_CD       = 'ITEM_ROUTE_MAP'
                AND CCC.USE_YN            = 'Y'
                AND CCC.CONF_ID           = CFG.ID(+)
                AND CFG.MODULE_CD         = 'SMP'
                AND CFG.ACTV_YN           = 'Y' 
                AND CCC.ATTR_01           = P_tPLAN_OPTION.ASSY_ROUTE_CD
                AND SIM.ITEM_CD           = SB.P_ITEM_CD)           
         --+ 전극 품목 BOM에서 제외(모품목)----------------------------------------------------
         AND NOT EXISTS (  
             SELECT 1
               FROM TB_SMP_ITEM_MST       SIM 
                   ,TB_SMP_ITEM_BASE_INFO IBI
                   ,TB_CM_COMM_CONFIG     CCC
                   ,TB_CM_CONFIGURATION   CFG    
              WHERE SIM.PN_CD             = IBI.PN_CD   
                AND IBI.ATTR_01           = CCC.CONF_CD
                AND CCC.CONF_GRP_CD       = 'ITEM_ELETRODE_GRP'
                AND CCC.USE_YN            = 'Y'
                AND CCC.CONF_ID           = CFG.ID
                AND CFG.MODULE_CD         = 'SMP'
                AND CFG.ACTV_YN           = 'Y'   
                AND SIM.ITEM_CD           = SB.P_ITEM_CD)     
         --+ 전극 품목 BOM에서 제외(자품목)----------------------------------------------------
         AND NOT EXISTS (  
             SELECT 1
               FROM TB_SMP_ITEM_MST       SIM 
                   ,TB_SMP_ITEM_BASE_INFO IBI
                   ,TB_CM_COMM_CONFIG     CCC
                   ,TB_CM_CONFIGURATION   CFG    
              WHERE SIM.PN_CD             = IBI.PN_CD   
                AND IBI.ATTR_01           = CCC.CONF_CD
                AND CCC.CONF_GRP_CD       = 'ITEM_ELETRODE_GRP'
                AND CCC.USE_YN            = 'Y'
                AND CCC.CONF_ID           = CFG.ID
                AND CFG.MODULE_CD         = 'SMP'
                AND CFG.ACTV_YN           = 'Y'   
                AND SIM.ITEM_CD           = SB.C_ITEM_CD)
         ---------------------------------------------------------------------+--
      --* 조립 아래 전극 CAPA 반제품
      UNION ALL 
      SELECT  SB.SITE_CD  -- 20200423 장문석K 추가
             ,SB.P_ITEM_CD 
             ,SB.C_ITEM_CD 
             ,SB.P_UNIT_QTY 
             ,SB.P_UOM 
             ,SB.C_UNIT_QTY 
             ,SB.C_UOM 
             ,NULL           AS ELEC_CAL_HIS
        FROM TB_SMP_BOM SB
       WHERE 1=1  
         --AND P_ITEM_CD LIKE 'A%'
         AND EXISTS (
             SELECT 1
               FROM TB_SMP_ITEM_MST I
              WHERE I.ITEM_CD       = SB.P_ITEM_CD
             )
         --+ 조립 품목 BOM(모품목)----------------------------------------------------
         AND EXISTS (
             SELECT 1
               FROM TB_SMP_ITEM_MST       SIM 
                   ,TB_SMP_ITEM_BASE_INFO IBI
                   ,TB_CM_COMM_CONFIG     CCC
                   ,TB_CM_CONFIGURATION   CFG    
              WHERE SIM.PN_CD             = IBI.PN_CD    
                AND IBI.ATTR_01           = CCC.ATTR_02  
                AND CCC.CONF_GRP_CD       = 'ITEM_ROUTE_MAP'
                AND CCC.USE_YN            = 'Y'
                AND CCC.CONF_ID           = CFG.ID(+)
                AND CFG.MODULE_CD         = 'SMP'
                AND CFG.ACTV_YN           = 'Y' 
                AND CCC.ATTR_01           = P_tPLAN_OPTION.ASSY_ROUTE_CD 
                AND SIM.ITEM_CD           = SB.P_ITEM_CD)                        
         --+ CAPA용 전극 반제품(자품목)----------------------------------------------------
         AND EXISTS (             
             SELECT 1
               FROM TB_SMP_ITEM_MST       SIM 
                   ,TB_SMP_ITEM_BASE_INFO IBI
                   ,TB_CM_COMM_CONFIG     CCC
                   ,TB_CM_CONFIGURATION   CFG    
              WHERE SIM.PN_CD             = IBI.PN_CD   
                AND IBI.ATTR_01           = CCC.ATTR_02 
                AND CCC.CONF_GRP_CD       = 'ITEM_ROUTE_MAP'
                AND CCC.USE_YN            = 'Y'
                AND CCC.CONF_ID           = CFG.ID
                AND CFG.MODULE_CD         = 'SMP'
                AND CFG.ACTV_YN           = 'Y'    
                AND CCC.CONF_CD           = 'ELECTRODE'
                AND SIM.ITEM_CD           = SB.C_ITEM_CD)     
      --*3. 조립품목에 전극 자재는 모두 생성          
      UNION ALL
      --조립이하 자재를 조립 품목에 합치기
      SELECT  SB.SITE_CD  -- 20200423 장문석K 추가
             ,CELL_ITEM_CD    P_ITEM_CD 
             ,SB.C_ITEM_CD 
             ,SB.P_UNIT_QTY 
             ,SB.P_UOM 
             ,SUM(REQ_QTY)    C_UNIT_QTY 
             ,REGEXP_REPLACE( LISTAGG(SB.C_UOM, ',') WITHIN GROUP (ORDER BY SB.C_UOM), '([^,]+)(,\1)+', '\1') C_UOM
             ,LISTAGG(SB.ITEM_PATH || ' (' || CAL_EXP || ')', '+') WITHIN GROUP(ORDER BY SB.ITEM_PATH)  AS ELEC_CAL_HIS
        FROM ( 
              SELECT LEVEL                                  AS BOM_LEVEL
                    ,DECODE(CONNECT_BY_ISLEAF, 1, 'Y', 'N') AS END_YN
                    ,SYS_CONNECT_BY_PATH(B.C_ITEM_CD, '*')  AS ITEM_PATH
                    ,CONNECT_BY_ROOT  B.P_ITEM_CD           AS CELL_ITEM_CD
                    ,CONNECT_BY_ROOT  B.P_UOM               AS P_UOM
                    ,1                                      AS P_UNIT_QTY
                    ,B.C_UNIT_QTY              
                    ,B.C_UOM
                    ,SUBSTR(SYS_CONNECT_BY_PATH(B.C_UNIT_QTY/B.P_UNIT_QTY, '*'), 2) AS CAL_EXP
                    ,XMLQUERY(SUBSTR(SYS_CONNECT_BY_PATH(B.C_UNIT_QTY/B.P_UNIT_QTY, '*'), 2) RETURNING CONTENT).GETNUMBERVAL() AS REQ_QTY              
                    ,B.SITE_CD
                    ,B.P_ITEM_CD
                    ,b.C_ITEM_CD
                FROM TB_SMP_BOM    B
               WHERE 1=1                   
               START WITH B.P_ITEM_CD IN (
                     SELECT SIM.ITEM_CD
                       FROM TB_SMP_ITEM_MST       SIM 
                           ,TB_SMP_ITEM_BASE_INFO IBI
                           ,TB_CM_COMM_CONFIG     CCC
                           ,TB_CM_CONFIGURATION   CFG    
                      WHERE SIM.PN_CD             = IBI.PN_CD   (+)
                        AND IBI.ATTR_01           = CCC.ATTR_02 (+)
                        AND CCC.CONF_GRP_CD(+)    = 'ITEM_ROUTE_MAP'
                        AND CCC.USE_YN     (+)    = 'Y'
                        AND CCC.CONF_ID           = CFG.ID(+)
                        AND CFG.MODULE_CD(+)      = 'SMP'
                        AND CFG.ACTV_YN  (+)      = 'Y' 
                        AND CCC.ATTR_01           =  P_tPLAN_OPTION.ASSY_ROUTE_CD  )
              CONNECT BY NOCYCLE B.P_ITEM_CD  = PRIOR B.C_ITEM_CD 
                             AND B.SITE_CD    = PRIOR B.SITE_CD
             ) SB
       WHERE 1=1 
         AND EXISTS (
             SELECT 1
               FROM TB_SMP_ITEM_MST  SIM
              WHERE SIM.ITEM_CD      = SB.C_ITEM_CD
                AND SIM.ITEM_TYPE_CD = 'RM')       
         /* [4/13] 모든 자재 소요량 산출을 위해 주석 처리 
         AND EXISTS (
             SELECT 1
               FROM TB_SMP_VENDOR_CAPA SVC
              WHERE SVC.ITEM_CD        = SB.C_ITEM_CD) 
         */ 
       GROUP BY SB.SITE_CD  -- 20200423 장문석K 추가
            ,CELL_ITEM_CD 
            ,SB.C_ITEM_CD 
            ,SB.P_UNIT_QTY 
            ,SB.P_UOM
    )  
    SELECT P_tPLAN_OPTION.VERSION_ID
          ,SITE_CD     
          ,P_ITEM_CD   
          ,C_ITEM_CD   
          ,P_UNIT_QTY  
          ,P_UOM       
          ,C_UNIT_QTY  
          ,C_UOM    
          ,P_ITEM_TYPE_CD
          ,C_ITEM_TYPE_CD
          ,CONTINENT_CD
          ,P_ROUTE_CD
          ,C_ROUTE_CD
          ,P_ITEM_CD || '@' || SITE_CD               AS P_INVENTORY_ID
          ,C_ITEM_CD || '@' || SITE_CD               AS C_INVENTORY_ID
          ,CASE WHEN P_ROUTE_CD IS NULL THEN 'RT_' ||                      P_ITEM_CD || '@' || SITE_CD
                ELSE                         'RT_' || P_ROUTE_CD || '_' || P_ITEM_CD || '@' || SITE_CD
           END                                       AS ROUTE_ID
          ,CONTINENT_CD                              AS T_CONTINENT_CD
          ,0                                         AS LEAD_TIME
          ,ELEC_CAL_HIS
      FROM (
            SELECT  SSM.CONTINENT_CD AS CONTINENT_CD
                   ,SSM.SITE_CD      AS SITE_CD
                   ,SB.P_ITEM_CD 
                   ,SB.C_ITEM_CD 
                   ,SB.P_UNIT_QTY 
                   ,SB.P_UOM 
                   ,SB.C_UNIT_QTY 
                   ,SB.C_UOM 
                   ,IMP.ITEM_TYPE_CD AS P_ITEM_TYPE_CD
                   ,IMC.ITEM_TYPE_CD AS C_ITEM_TYPE_CD
                   ,IMP.ROUTE_CD     AS P_ROUTE_CD
                   ,IMC.ROUTE_CD     AS C_ROUTE_CD  
                   ,SB.ELEC_CAL_HIS
              FROM W_1BOM                SB
                  ,TB_SMP_SITE_MST       SSM
                  --P_ITEM JOIN
                  ,(SELECT SIM.ITEM_CD
                          ,SIM.ITEM_TYPE_CD
                          ,CCC.ATTR_01           ROUTE_CD
                      FROM TB_SMP_ITEM_MST       SIM 
                          ,TB_SMP_ITEM_BASE_INFO IBI
                          ,TB_CM_COMM_CONFIG     CCC
                          ,TB_CM_CONFIGURATION   CFG    
                     WHERE SIM.PN_CD             = IBI.PN_CD   (+)
                       AND IBI.ATTR_01           = CCC.ATTR_02 (+)
                       AND CCC.CONF_GRP_CD(+)    = 'ITEM_ROUTE_MAP'
                       AND CCC.USE_YN     (+)    = 'Y'
                       AND CCC.CONF_ID           = CFG.ID(+)
                       AND CFG.MODULE_CD(+)      = 'SMP'
                       AND CFG.ACTV_YN  (+)      = 'Y'  ) IMP  
                  --C_ITEM JOIN
                  ,(SELECT SIM.ITEM_CD
                          ,SIM.ITEM_TYPE_CD
                          ,CCC.ATTR_01           ROUTE_CD
                      FROM TB_SMP_ITEM_MST       SIM 
                          ,TB_SMP_ITEM_BASE_INFO IBI
                          ,TB_CM_COMM_CONFIG     CCC
                          ,TB_CM_CONFIGURATION   CFG    
                     WHERE SIM.PN_CD             = IBI.PN_CD   (+)
                       AND IBI.ATTR_01           = CCC.ATTR_02 (+)
                       AND CCC.CONF_GRP_CD(+)    = 'ITEM_ROUTE_MAP'
                       AND CCC.USE_YN     (+)    = 'Y'
                       AND CCC.CONF_ID           = CFG.ID(+)
                       AND CFG.MODULE_CD(+)      = 'SMP'
                       AND CFG.ACTV_YN  (+)      = 'Y'  ) IMC
             WHERE 1=1
  -->[AIS_TODO] 1개의 BOM으로 모든 사이트 사용으로 변경            
               AND  SB.SITE_CD        = SSM.SITE_CD
               --P_ITEM JOIN
               AND SB.P_ITEM_CD      = IMP.ITEM_CD
               --C_ITEM JOIN
               AND SB.C_ITEM_CD      = IMC.ITEM_CD 
               AND SB.C_UNIT_QTY     > 0
               AND SSM.CONTINENT_CD  IS NOT NULL  
               AND SSM.USE_YN        = 'Y'
           ) M 
     /* [4/13] 모든 자재 소요량 산출을 위해 주석 처리       
     WHERE ( M.C_ITEM_TYPE_CD IN ('FERT', 'HALB')
             OR 
             EXISTS (SELECT 1
                       FROM TB_SMP_VENDOR_CAPA SVC
                      WHERE SVC.ITEM_CD        = M.C_ITEM_CD)
           )
     */
    ;
  ELSIF P_tPLAN_OPTION.USED_BOM_TYPE = 'MFG_BOM' THEN
    INSERT INTO TB_SMP_WK_BOM(
           VERSION_ID
          ,SITE_CD     
          ,P_ITEM_CD   
          ,C_ITEM_CD   
          ,P_UNIT_QTY  
          ,P_UOM       
          ,C_UNIT_QTY  
          ,C_UOM       
          ,P_ITEM_TYPE_CD
          ,C_ITEM_TYPE_CD
          ,CONTINENT_CD
          ,P_ROUTE_CD
          ,C_ROUTE_CD
          ,P_INVENTORY_ID
          ,C_INVENTORY_ID
          ,ROUTE_ID  
          ,T_CONTINENT_CD
          ,LEAD_TIME)
    SELECT P_tPLAN_OPTION.VERSION_ID
          ,SITE_CD     
          ,P_ITEM_CD   
          ,C_ITEM_CD   
          ,P_UNIT_QTY  
          ,P_UOM       
          ,C_UNIT_QTY  
          ,C_UOM    
          ,P_ITEM_TYPE_CD
          ,C_ITEM_TYPE_CD
          ,CONTINENT_CD
          ,P_ROUTE_CD
          ,C_ROUTE_CD
          ,P_ITEM_CD || '@' || SITE_CD               AS P_INVENTORY_ID
          ,C_ITEM_CD || '@' || SITE_CD               AS C_INVENTORY_ID
          ,CASE WHEN P_ROUTE_CD IS NULL THEN 'RT_' ||                      P_ITEM_CD || '@' || SITE_CD
                ELSE                         'RT_' || P_ROUTE_CD || '_' || P_ITEM_CD || '@' || SITE_CD
           END                                       AS ROUTE_ID
          ,CONTINENT_CD                              AS T_CONTINENT_CD
          ,0                                         AS LEAD_TIME
      FROM (
            SELECT  SSM.CONTINENT_CD AS CONTINENT_CD
                   ,SSM.SITE_CD      AS SITE_CD
                   ,SB.P_ITEM_CD 
                   ,SB.C_ITEM_CD 
                   ,SB.P_UNIT_QTY 
                   ,SB.P_UOM 
                   ,SB.C_UNIT_QTY 
                   ,SB.C_UOM 
                   ,IMP.ITEM_TYPE_CD AS P_ITEM_TYPE_CD
                   ,IMC.ITEM_TYPE_CD AS C_ITEM_TYPE_CD
                   ,IMP.ROUTE_CD     AS P_ROUTE_CD
                   ,IMC.ROUTE_CD     AS C_ROUTE_CD                  
              FROM TB_SMP_BOM            SB
                  ,TB_SMP_SITE_MST       SSM
                  --P_ITEM JOIN
                  ,(SELECT SIM.ITEM_CD
                          ,SIM.ITEM_TYPE_CD
                          ,CCC.ATTR_01           ROUTE_CD
                      FROM TB_SMP_ITEM_MST       SIM 
                          ,TB_SMP_ITEM_BASE_INFO IBI
                          ,TB_CM_COMM_CONFIG     CCC
                          ,TB_CM_CONFIGURATION   CFG    
                     WHERE SIM.PN_CD             = IBI.PN_CD   (+)
                       AND IBI.ATTR_01           = CCC.ATTR_02 (+)
                       AND CCC.CONF_GRP_CD(+)    = 'ITEM_ROUTE_MAP'
                       AND CCC.USE_YN     (+)    = 'Y'
                       AND CCC.CONF_ID           = CFG.ID(+)
                       AND CFG.MODULE_CD(+)      = 'SMP'
                       AND CFG.ACTV_YN  (+)      = 'Y'  ) IMP  
                  --C_ITEM JOIN
                  ,(SELECT SIM.ITEM_CD
                          ,SIM.ITEM_TYPE_CD
                          ,CCC.ATTR_01           ROUTE_CD
                      FROM TB_SMP_ITEM_MST       SIM 
                          ,TB_SMP_ITEM_BASE_INFO IBI
                          ,TB_CM_COMM_CONFIG     CCC
                          ,TB_CM_CONFIGURATION   CFG    
                     WHERE SIM.PN_CD             = IBI.PN_CD   (+)
                       AND IBI.ATTR_01           = CCC.ATTR_02 (+)
                       AND CCC.CONF_GRP_CD(+)    = 'ITEM_ROUTE_MAP'
                       AND CCC.USE_YN     (+)    = 'Y'
                       AND CCC.CONF_ID           = CFG.ID(+)
                       AND CFG.MODULE_CD(+)      = 'SMP'
                       AND CFG.ACTV_YN  (+)      = 'Y'  ) IMC
             WHERE 1=1
  -->[AIS_TODO] 1개의 BOM으로 모든 사이트 사용으로 변경            
             --AND  SB.SITE_CD        = SSM.SITE_CD
             --P_ITEM JOIN
             AND   SB.P_ITEM_CD      = IMP.ITEM_CD
             --C_ITEM JOIN
             AND   SB.C_ITEM_CD      = IMC.ITEM_CD 
             AND   SB.C_UNIT_QTY     > 0
             AND   SSM.CONTINENT_CD  IS NOT NULL  
             AND   SSM.USE_YN        = 'Y'
           ) M 
     WHERE --M.C_ROUTE_CD IS NOT NULL
           M.C_ITEM_TYPE_CD IN ('FERT', 'HALB')
        OR EXISTS(
            SELECT 1
              FROM TB_SMP_VENDOR_CAPA SVC
             WHERE SVC.ITEM_CD        = M.C_ITEM_CD)
    ;       
  END IF;

  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);       
  ------------------------------------------------------------------------------------------------------

  --* Update Cell CD at Assy Item-----------------------------------------------------------------------
  G_sSTEP_SEQ := '3.1';   
  G_sSTEP_DESC := 'Update Cell Item CD at Elec. Item';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  UPDATE TB_SMP_WK_BOM BOM
     SET BOM.P_CELL_CD = (SELECT SCM.CELL_CD
                            FROM TB_SMP_CELL_MST SCM
                           WHERE SCM.ITEM_CD     = BOM.P_ITEM_CD
                         )
   WHERE BOM.VERSION_ID = P_tPLAN_OPTION.VERSION_ID
     AND BOM.P_ROUTE_CD = P_tPLAN_OPTION.ASSY_ROUTE_CD
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT); 
  ------------------------------------------------------------------------------------------------------
  
  --* Update Cell Item CD at Electrode Item-------------------------------------------------------------
      -- Cell품목 아래의 전극 품목을 찾아 Cell품목코드를 Update시킴 ( 전극품목코드에 Cell품목코드를 찾아 Update) --> 
      --> 전극공정 BOR.PROCESS_CAPA 처리시 Cell품목정보가 필요함.
  G_sSTEP_SEQ := '3.2';   
  G_sSTEP_DESC := 'Update Cell Item CD at Elec. Item';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  MERGE INTO TB_SMP_WK_BOM TAR
  USING (
          SELECT VERSION_ID--LEVEL, CONNECT_BY_ISLEAF, SYS_CONNECT_BY_PATH(B.P_ITEM_CD, '*') 
                ,CONNECT_BY_ROOT  B.P_ITEM_CD AS CELL_ITEM_CD
                ,B.SITE_CD
                ,B.C_ITEM_CD                  AS BEL_ITEM_CD
                ,B.C_ROUTE_CD
            FROM TB_SMP_WK_BOM    B
           WHERE 1=1 
             AND B.VERSION_ID     = P_tPLAN_OPTION.VERSION_ID
             AND B.C_ROUTE_CD     = P_tPLAN_OPTION.ELEC_ROUTE_CD -- 'BEL'
          START WITH B.VERSION_ID = P_tPLAN_OPTION.VERSION_ID 
                 AND B.P_ROUTE_CD = P_tPLAN_OPTION.ASSY_ROUTE_CD -- 'BAS'
          CONNECT BY NOCYCLE B.P_ITEM_CD  = PRIOR B.C_ITEM_CD 
                         AND B.SITE_CD    = PRIOR B.SITE_CD
                         AND B.VERSION_ID = PRIOR B.VERSION_ID
        ) SRC
  ON (    TAR.VERSION_ID = SRC.VERSION_ID
      AND TAR.SITE_CD    = SRC.SITE_CD
      AND TAR.P_ITEM_CD  = SRC.BEL_ITEM_CD --모품콕 전극코드에 CELL코드 UPDATE처리
      )
  WHEN MATCHED THEN
  UPDATE
     SET TAR.REF_CELL_ITEM_CD = SRC.CELL_ITEM_CD
        ,TAR.UPDATE_DTTM      = SYSDATE
        ,TAR.UPDATE_USER_ID   = 'CELL_FIND'
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);  
  ------------------------------------------------------------------------------------------------------

  --*Set Working BOM (Dummy) : Not exists Child item ---------------------------------------------------
  G_sSTEP_SEQ := '4.0';   
  G_sSTEP_DESC := 'Set Working BOM (Dummy)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);
  INSERT INTO TB_SMP_WK_BOM(
         VERSION_ID
        ,SITE_CD     
        ,P_ITEM_CD   
        ,C_ITEM_CD   
        ,P_UNIT_QTY  
        ,P_UOM       
        ,C_UNIT_QTY  
        ,C_UOM       
        ,P_ITEM_TYPE_CD
        ,C_ITEM_TYPE_CD
        ,CONTINENT_CD
        ,P_ROUTE_CD
        ,C_ROUTE_CD
        ,P_INVENTORY_ID
        ,C_INVENTORY_ID
        ,ROUTE_ID  
        ,T_CONTINENT_CD
        ,LEAD_TIME)
  SELECT DISTINCT
         P_tPLAN_OPTION.VERSION_ID
        ,SITE_CD     
        ,C_ITEM_CD      AS P_ITEM_CD
        ,'DUMMY'        AS C_ITEM_CD   
        ,1              AS P_UNIT_QTY  
        ,'EA'           AS P_UOM       
        ,1              AS C_UNIT_QTY  
        ,'EA'           AS C_UOM    
        ,C_ITEM_TYPE_CD AS P_ITEM_TYPE_CD
        ,'RM'           AS C_ITEM_TYPE_CD
        ,CONTINENT_CD   AS CONTINENT_CD
        ,C_ROUTE_CD     AS P_ROUTE_CD
        ,NULL           AS C_ROUTE_CD
        ,C_INVENTORY_ID AS P_INVENTORY_ID
        ,'DUMMY@' || SITE_CD                                            AS C_INVENTORY_ID
        ,CASE WHEN C_ROUTE_CD IS NULL THEN 'RT_' ||                      C_ITEM_CD || '@' || SITE_CD
              ELSE                         'RT_' || C_ROUTE_CD || '_' || C_ITEM_CD || '@' || SITE_CD      
         END                                                            AS ROUTE_ID
        ,CONTINENT_CD                                                   AS T_CONTINENT_CD
        ,0                                                              AS LEAD_TIME
    FROM TB_SMP_WK_BOM P
   WHERE VERSION_ID    = P_tPLAN_OPTION.VERSION_ID
     --AND C_ROUTE_CD    IS NOT NULL  -- 제품/반제품 공정
     AND C_ITEM_TYPE_CD IN ('FERT', 'HALB')
     AND NOT EXISTS ( --CHILD 품목이 없는 놈
         SELECT 1
           FROM TB_SMP_WK_BOM C 
          WHERE C.VERSION_ID  = P.VERSION_ID
            AND C.P_ITEM_CD   = P.C_ITEM_CD
         )
     --+ CAPA용 전극 반제품(자품목)은 제외 시킴.----------------------------------------------------
     AND NOT EXISTS (             
         SELECT 1
           FROM TB_SMP_ITEM_MST       SIM 
               ,TB_SMP_ITEM_BASE_INFO IBI
               ,TB_CM_COMM_CONFIG     CCC
               ,TB_CM_CONFIGURATION   CFG    
          WHERE SIM.PN_CD             = IBI.PN_CD   
            AND IBI.ATTR_01           = CCC.ATTR_02 
            AND CCC.CONF_GRP_CD       = 'ITEM_ROUTE_MAP'
            AND CCC.USE_YN            = 'Y'
            AND CCC.CONF_ID           = CFG.ID
            AND CFG.MODULE_CD         = 'SMP'
            AND CFG.ACTV_YN           = 'Y'    
            AND CCC.CONF_CD           = 'ELECTRODE'
            AND SIM.ITEM_CD           = P.C_ITEM_CD)           
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);       
  ------------------------------------------------------------------------------------------------------

     
  --*Set Working BOM (BOD)------------------------------------------------------------------------------
  G_sSTEP_SEQ := '5.0';   
  G_sSTEP_DESC := 'Set Working BOM (BOD)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);     
  INSERT INTO TB_SMP_WK_BOM(
         VERSION_ID
        ,SITE_CD     
        ,P_ITEM_CD   
        ,C_ITEM_CD   
        ,P_UNIT_QTY  
        ,P_UOM       
        ,C_UNIT_QTY  
        ,C_UOM       
        ,P_ITEM_TYPE_CD
        ,C_ITEM_TYPE_CD      
        ,CONTINENT_CD
        ,P_ROUTE_CD
        ,C_ROUTE_CD
        ,P_INVENTORY_ID
        ,C_INVENTORY_ID
        ,ROUTE_ID  
        ,T_CONTINENT_CD
        ,LEAD_TIME
        ,USE_FLAG)  
  SELECT DISTINCT
         P_tPLAN_OPTION.VERSION_ID
        ,SWB.SITE_CD
        ,SWB.P_ITEM_CD                              AS P_ITEM_CD
        ,SWB.P_ITEM_CD                              AS C_ITEM_CD
        ,1                                          AS P_UNIT_QTY
        ,SWB.P_UOM                                  AS P_UOM
        ,1                                          AS C_UNIT_QTY
        ,SWB.P_UOM                                  AS C_UOM
        ,SWB.P_ITEM_TYPE_CD                         AS P_ITEM_TYPE_CD
        ,SWB.P_ITEM_TYPE_CD                         AS C_ITEM_TYPE_CD
        ,SWB.CONTINENT_CD                           AS CONTINENT_CD
        ,P_tPLAN_OPTION.BOD_ROUTE_CD                AS P_OUTE_CD
        ,SWB.P_ROUTE_CD                             AS C_ROUTE_CD
        ,SWB.P_ITEM_CD || '@' || SBM.T_CONTINENT_CD AS P_INVENTORY_ID  
        ,SWB.P_INVENTORY_ID                         AS C_INVENTORY_ID
        ,'RT_' || SWB.P_INVENTORY_ID ||  '_' || SBM.T_CONTINENT_CD AS ROUTE_ID
        ,SBM.T_CONTINENT_CD
        ,ROUND( NVL(SBM.DELIVERY_LT, 0) + NVL(SBM.FORMATION_LT, 0) )  AS LEAD_TIME
        ,'N'                                        AS USE_FLAG
    FROM TB_SMP_WK_BOM      SWB
        ,TB_SMP_BOD_MST     SBM
   WHERE SWB.VERSION_ID     = P_tPLAN_OPTION.VERSION_ID
     AND SWB.CONTINENT_CD   = SBM.F_CONTINENT_CD   -- TO를 넣으면 안됨. 
     AND EXISTS ( -- DEMAND에 존재하는 품목은 BOD 등록 
         SELECT 1
           FROM TB_SMP_DEMAND_PGM_MST DPM
               ,TB_SMP_DEMAND_INFO    DPI
          WHERE DPM.PGM_D_CD          = DPI.PGM_D_CD
            AND NVL(DPI.QTY, 0)       > 0
            AND DPM.ITEM_CD           = SWB.P_ITEM_CD
         )       
  ;   
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT); 
  ------------------------------------------------------------------------------------------------------
  
  --* 조립라인 인증이 없는 BOD BOM      ----------------------------------------------------------------------
  G_sSTEP_SEQ := '6.0';   
  G_sSTEP_DESC := 'Set exists Assy. Line Certi.';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);   
  UPDATE TB_SMP_WK_BOM      SWB 
     SET SWB.USE_FLAG       = 'Y'
   WHERE SWB.VERSION_ID     = P_tPLAN_OPTION.VERSION_ID
     AND SWB.P_ROUTE_CD     = P_tPLAN_OPTION.BOD_ROUTE_CD-- 'BOD'
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_DEMAND_PGM_MST DPM
               ,TB_SMP_ASSY_CERF_MST  ACM
          WHERE DPM.CELL_CD           = ACM.CELL_CD
            AND ACM.SITE_CD           = SWB.SITE_CD
            AND DPM.ITEM_CD           = SWB.P_ITEM_CD
            )              
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT); 
  ------------------------------------------------------------------------------------------------------
  
  --* 수주 추진건은 스펙이 잋치하면 BOM생성 대상임-------------------------------------------------------------------
  IF P_tPLAN_OPTION.PROGRESS_ORDER_YN = 'Y' THEN
    G_sSTEP_SEQ := '7.0';   
    G_sSTEP_DESC := 'Set exists Same Spec.';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);   
    UPDATE TB_SMP_WK_BOM      SWB 
       SET SWB.USE_FLAG       = 'Y'
     WHERE SWB.VERSION_ID     = P_tPLAN_OPTION.VERSION_ID
       AND SWB.P_ROUTE_CD     = P_tPLAN_OPTION.BOD_ROUTE_CD-- 'BOD'
       --* 수주 추진건은 스펙이 잋치하면 BOM생성 대상임
       AND EXISTS (--수주추진건중, CELL품목 스펙 = 라인 스펙 인 것.
           SELECT 1--ITM.*, SLM.LINE_CD
             FROM (
                   SELECT DISTINCT
                          DPM.ITEM_CD
                         ,SCM.ITEM_CD             AS CELL_ITEM_CD
                         ,SCM.POLAR_DIRECTION_CD
                         ,SCM.WIDTH_TYPE_CD
                     FROM TB_SMP_DEMAND_PGM_MST DPM
                         ,TB_SMP_CELL_MST       SCM     
                    WHERE DPM.CELL_CD           = SCM.CELL_CD  
                      AND DPM.ITEM_CD           IS NOT NULL
                      AND DPM.PGM_STATUS_CD     = 'P' --수주추진
                  ) ITM
                 ,TB_SMP_LINE_MST         SLM
            WHERE ITM.POLAR_DIRECTION_CD  = SLM.POLAR_DIRECTION_CD
              AND ITM.WIDTH_TYPE_CD       = SLM.WIDTH_TYPE_CD
              AND SLM.ROUTE_CD            = P_tPLAN_OPTION.ASSY_ROUTE_CD -- 'BAS'
              AND ITM.ITEM_CD             = SWB.P_ITEM_CD  
              AND SLM.SITE_CD             = SWB.SITE_CD
           )             
    ;
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT); 
  END IF;
  ------------------------------------------------------------------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_sFLAG   := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

PROCEDURE SP_SET_WORK_BOR (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_WORK_BOR
* Purpose : Working BOR 생성 
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_WORK_BOR';

  --*Init. Working BOR----------------------------------------------------------------------------------
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Init. Working BOR';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);       
  DELETE FROM TB_SMP_WK_BOR
  WHERE VERSION_ID = P_tPLAN_OPTION.VERSION_ID
  ;  
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --*Set Working BOR(BAS)-------------------------------------------------------------------------------
  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Set Working BOR(BAS)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);         
  INSERT INTO TB_SMP_WK_BOR(
         VERSION_ID
        ,ROUTE_ID 
        ,LINE_CD
        ,ITEM_CD
        ,EFFICIENCY
        ,PROCESS_CAPACITY
        ,CONTINENT_CD 
        ,SITE_CD 
        ,ROUTE_CD 
        ,BUILDING_NO 
        ,LINE_NO 
        ,CELL_CD
        ,VALID_START_DATE
        ,VALID_FINISH_DATE
        ,FULL_JC_1ST_VAL 
        ,FULL_JC_2ND_VAL 
        ,SEMI_JC_1ST_VAL 
        ,SEMI_JC_2ND_VAL 
        ,CERTIF_MONTH
        ,CERTIF_YN      
        ,POLAR_DIRECTION_CD
        ,WIDTH_TYPE_CD        
        )
  WITH W_SRC AS (
            SELECT DISTINCT  
                  SWB.VERSION_ID
                 ,SWB.ROUTE_ID 
                 ,SLM.LINE_CD                               
                 ,SWB.P_ITEM_CD                             
                 ,SWB.CONTINENT_CD 
                 ,SLM.SITE_CD 
                 ,SLM.ROUTE_CD 
                 ,SLM.BUILDING_NO 
                 ,SLM.LINE_NO 
                 ,SWB.P_CELL_CD                             
                 ,VALID_START_DATE
                 ,VALID_FINISH_DATE
                 ,SSM.FULL_JC_1ST_VAL 
                 ,SSM.FULL_JC_2ND_VAL 
                 ,SSM.SEMI_JC_1ST_VAL 
                 ,SSM.SEMI_JC_2ND_VAL 
                 ,SLM.POLAR_DIRECTION_CD
                 ,SLM.WIDTH_TYPE_CD                    
             FROM TB_SMP_WK_BOM        SWB
                 ,TB_SMP_LINE_MST      SLM
                 ,TB_SMP_SITE_MST      SSM
            WHERE SWB.VERSION_ID       = P_tPLAN_OPTION.VERSION_ID
              AND SWB.USE_FLAG         = 'Y'
              AND SWB.SITE_CD          = SLM.SITE_CD 
              AND SWB.P_ROUTE_CD       = SLM.ROUTE_CD 
              AND SLM.SITE_CD          = SSM.SITE_CD
              AND SLM.USE_YN           = 'Y'
              AND SLM.ROUTE_CD         = P_tPLAN_OPTION.ASSY_ROUTE_CD -- 'BAS'  
  )        
  SELECT P_tPLAN_OPTION.VERSION_ID
        ,ROUTE_ID 
        ,RESOURCE_ID
        ,ITEM_CD
        ,EFFICIENCY
        ,DECODE(PPM_VAL, 0, 0, 1/PPM_VAL) AS PROCESS_CAPACITY
        ,CONTINENT_CD 
        ,SITE_CD 
        ,ROUTE_CD 
        ,BUILDING_NO 
        ,LINE_NO 
        ,CELL_CD
        ,VALID_START_DATE
        ,VALID_FINISH_DATE
        ,FULL_JC_1ST_VAL 
        ,FULL_JC_2ND_VAL 
        ,SEMI_JC_1ST_VAL 
        ,SEMI_JC_2ND_VAL   
        ,CERTIF_MONTH
        ,CERTIF_YN       
        ,POLAR_DIRECTION_CD
        ,WIDTH_TYPE_CD            
    FROM ( 
          SELECT DISTINCT  
                 SRC.ROUTE_ID 
                ,SRC.LINE_CD                              AS RESOURCE_ID
                ,SRC.P_ITEM_CD                            AS ITEM_CD
                ,1                                        AS EFFICIENCY
                ,NVL(ACM.PPM_VAL
                    ,
                     (SELECT MAX(ACM.PPM_VAL)  --라인 인증이 없을 경우 (확정구간 오더중 라인 없는 경우)
                       FROM  TB_SMP_ASSY_CERF_MST  ACM 
                      WHERE  ACM.SITE_CD           = SRC.SITE_CD
                        AND  ACM.LINE_CD           = SRC.LINE_CD
                     )                    
                    )                                     AS PPM_VAL                 
                ,SRC.CONTINENT_CD 
                ,SRC.SITE_CD 
                ,SRC.ROUTE_CD 
                ,SRC.BUILDING_NO 
                ,SRC.LINE_NO 
                ,SRC.P_CELL_CD                            AS CELL_CD
                ,ACM.CERTIF_MONTH                         AS CERTIF_MONTH
                ,DECODE(ACM.CERTIF_MONTH, NULL, 'N', 'Y') AS CERTIF_YN                
                ,SRC.VALID_START_DATE
                ,SRC.VALID_FINISH_DATE
                ,SRC.FULL_JC_1ST_VAL * 24 * 60            AS FULL_JC_1ST_VAL
                ,SRC.FULL_JC_2ND_VAL * 24 * 60            AS FULL_JC_2ND_VAL
                ,SRC.SEMI_JC_1ST_VAL * 24 * 60            AS SEMI_JC_1ST_VAL
                ,SRC.SEMI_JC_2ND_VAL * 24 * 60            AS SEMI_JC_2ND_VAL
                ,SRC.POLAR_DIRECTION_CD
                ,SRC.WIDTH_TYPE_CD                    
            FROM W_SRC                SRC
                ,TB_SMP_ASSY_CERF_MST ACM
           WHERE SRC.SITE_CD          = ACM.SITE_CD (+)
             AND SRC.LINE_CD          = ACM.LINE_CD (+)
             AND SRC.P_CELL_CD        = ACM.CELL_CD (+)
             AND ( EXISTS ( --수주 추진건, 스펙이 일치하는 경우만 등록
                           SELECT 1--ITM.*, SLM.LINE_CD
                             FROM (
                                   SELECT DISTINCT
                                          DPM.ITEM_CD
                                         ,SCM.ITEM_CD             AS CELL_ITEM_CD
                                         ,SCM.POLAR_DIRECTION_CD
                                         ,SCM.WIDTH_TYPE_CD
                                     FROM TB_SMP_DEMAND_PGM_MST DPM
                                         ,TB_SMP_CELL_MST       SCM     
                                    WHERE DPM.CELL_CD           = SCM.CELL_CD  
                                      AND DPM.ITEM_CD           IS NOT NULL
                                      AND DPM.PGM_STATUS_CD     = 'P' --수주추진
                                      AND P_tPLAN_OPTION.PROGRESS_ORDER_YN = 'Y' -- '추주추진' = 'Y'
                                  ) ITM
                                 ,TB_SMP_LINE_MST         LIN
                            WHERE ITM.POLAR_DIRECTION_CD  = LIN.POLAR_DIRECTION_CD
                              AND ITM.WIDTH_TYPE_CD       = LIN.WIDTH_TYPE_CD
                              AND LIN.ROUTE_CD            = P_tPLAN_OPTION.ASSY_ROUTE_CD -- 'BAS'
                              AND ITM.CELL_ITEM_CD        = SRC.P_ITEM_CD  
                              AND LIN.LINE_CD             = SRC.LINE_CD
                          )
                   OR 
                   ACM.CERTIF_MONTH  IS NOT NULL
                   OR 
                   EXISTS (
                           SELECT 1 -- 확정구간 계획
                             FROM TB_SMP_WK_FIXED_PROD SFP
                            WHERE SFP.VERSION_ID    = SRC.VERSION_ID
                              AND SFP.SITE_CD       = SRC.SITE_CD
                              AND SFP.ITEM_CD       = SRC.P_ITEM_CD
                              AND SFP.LINE_CD       = SRC.LINE_CD
                          )
                 )     
          )
  ;    
/*        
  SELECT P_tPLAN_OPTION.VERSION_ID
        ,ROUTE_ID 
        ,RESOURCE_ID
        ,ITEM_CD
        ,EFFICIENCY
        ,DECODE(PPM_VAL, 0, 0, 1/PPM_VAL) AS PROCESS_CAPACITY
        ,CONTINENT_CD 
        ,SITE_CD 
        ,ROUTE_CD 
        ,BUILDING_NO 
        ,LINE_NO 
        ,CELL_CD
        ,VALID_START_DATE
        ,VALID_FINISH_DATE
        ,FULL_JC_1ST_VAL 
        ,FULL_JC_2ND_VAL 
        ,SEMI_JC_1ST_VAL 
        ,SEMI_JC_2ND_VAL   
        ,CERTIF_MONTH
        ,CERTIF_YN       
        ,POLAR_DIRECTION_CD
        ,WIDTH_TYPE_CD            
    FROM ( 
          SELECT DISTINCT  
                 SWB.ROUTE_ID 
                ,SLM.LINE_CD                              AS RESOURCE_ID
                ,SWB.P_ITEM_CD                            AS ITEM_CD
                ,1                                        AS EFFICIENCY
                ,NVL(ACM.PPM_VAL
                    ,
                     (SELECT MAX(ACM.PPM_VAL)  --라인 인증이 없을 경우 (확정구간 오더중 라인 없는 경우)
                       FROM  TB_SMP_ASSY_CERF_MST  ACM 
                      WHERE  ACM.SITE_CD           = SLM.SITE_CD
                        AND  ACM.LINE_CD           = SLM.LINE_CD
                     )                    
                    )                                     AS PPM_VAL                 
                ,SWB.CONTINENT_CD 
                ,SLM.SITE_CD 
                ,SLM.ROUTE_CD 
                ,SLM.BUILDING_NO 
                ,SLM.LINE_NO 
                ,SWB.P_CELL_CD                            AS CELL_CD
                ,ACM.CERTIF_MONTH                         AS CERTIF_MONTH
                ,DECODE(ACM.CERTIF_MONTH, NULL, 'N', 'Y') AS CERTIF_YN                
                ,VALID_START_DATE
                ,VALID_FINISH_DATE
                ,SSM.FULL_JC_1ST_VAL * 24 * 60            AS FULL_JC_1ST_VAL
                ,SSM.FULL_JC_2ND_VAL * 24 * 60            AS FULL_JC_2ND_VAL
                ,SSM.SEMI_JC_1ST_VAL * 24 * 60            AS SEMI_JC_1ST_VAL
                ,SSM.SEMI_JC_2ND_VAL * 24 * 60            AS SEMI_JC_2ND_VAL
                ,SLM.POLAR_DIRECTION_CD
                ,SLM.WIDTH_TYPE_CD                    
            FROM TB_SMP_WK_BOM        SWB
                ,TB_SMP_LINE_MST      SLM
                ,TB_SMP_SITE_MST      SSM
                ,TB_SMP_ASSY_CERF_MST ACM
           WHERE SWB.VERSION_ID       = P_tPLAN_OPTION.VERSION_ID
             AND SWB.USE_FLAG         = 'Y'
             AND SWB.SITE_CD          = SLM.SITE_CD 
             AND SWB.P_ROUTE_CD       = SLM.ROUTE_CD 
             AND SLM.SITE_CD          = SSM.SITE_CD
             AND SLM.USE_YN           = 'Y'
             AND SLM.ROUTE_CD         = P_tPLAN_OPTION.ASSY_ROUTE_CD -- 'BAS'
             AND SWB.SITE_CD          = ACM.SITE_CD (+)
             AND SLM.LINE_CD          = ACM.LINE_CD (+)
             AND SWB.P_CELL_CD        = ACM.CELL_CD (+)
             AND ( EXISTS ( --수주 추진건, 스펙이 일치하는 경우만 등록
                           SELECT 1--ITM.*, SLM.LINE_CD
                             FROM (
                                   SELECT DISTINCT
                                          DPM.ITEM_CD
                                         ,SCM.ITEM_CD             AS CELL_ITEM_CD
                                         ,SCM.POLAR_DIRECTION_CD
                                         ,SCM.WIDTH_TYPE_CD
                                     FROM TB_SMP_DEMAND_PGM_MST DPM
                                         ,TB_SMP_CELL_MST       SCM     
                                    WHERE DPM.CELL_CD           = SCM.CELL_CD  
                                      AND DPM.ITEM_CD           IS NOT NULL
                                      AND DPM.PGM_STATUS_CD     = 'P' --수주추진
                                      AND P_tPLAN_OPTION.PROGRESS_ORDER_YN = 'Y' -- '추주추진' = 'Y'
                                  ) ITM
                                 ,TB_SMP_LINE_MST         LIN
                            WHERE ITM.POLAR_DIRECTION_CD  = LIN.POLAR_DIRECTION_CD
                              AND ITM.WIDTH_TYPE_CD       = LIN.WIDTH_TYPE_CD
                              AND LIN.ROUTE_CD            = P_tPLAN_OPTION.ASSY_ROUTE_CD -- 'BAS'
                              AND ITM.CELL_ITEM_CD        = SWB.P_ITEM_CD  
                              AND LIN.LINE_CD             = SLM.LINE_CD
                          )
                   OR 
                   ACM.CERTIF_MONTH  IS NOT NULL
                   OR 
                   EXISTS (
                           SELECT 1 -- 확정구간 계획
                             FROM TB_SMP_WK_FIXED_PROD SFP
                            WHERE SFP.VERSION_ID    = SWB.VERSION_ID
                              AND SFP.SITE_CD       = SWB.SITE_CD
                              AND SFP.ITEM_CD       = SWB.P_ITEM_CD
                              AND SFP.LINE_CD       = SLM.LINE_CD
                          )
                 )             
          )
  ;
*/ 
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --*Set Working BOR(BEL)-------------------------------------------------------------------------------
  G_sSTEP_SEQ := '3.0';   
  G_sSTEP_DESC := 'Set Working BOR(BEL)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);
  INSERT INTO TB_SMP_WK_BOR(
         VERSION_ID
        ,ROUTE_ID 
        ,LINE_CD
        ,ITEM_CD
        ,EFFICIENCY
        ,PROCESS_CAPACITY
        ,CONTINENT_CD 
        ,SITE_CD 
        ,ROUTE_CD 
        ,BUILDING_NO 
        ,LINE_NO 
        ,VALID_START_DATE
        ,VALID_FINISH_DATE
        )
  SELECT P_tPLAN_OPTION.VERSION_ID
        ,ROUTE_ID 
        ,RESOURCE_ID
        ,ITEM_CD
        ,EFFICIENCY
        ,1 / ( (COT_SPEED_VAL * LANE_QTY) * DECODE(WIDTH_TYPE_CD, 'WIDE', 2, 1) ) AS PROCESS_CAPACITY
        ,CONTINENT_CD 
        ,SITE_CD 
        ,ROUTE_CD 
        ,BUILDING_NO 
        ,LINE_NO 
        ,VALID_START_DATE
        ,VALID_FINISH_DATE
    FROM ( 
          SELECT DISTINCT  
                 SWB.ROUTE_ID 
                ,SLM.LINE_CD      AS RESOURCE_ID
                ,SWB.P_ITEM_CD    AS ITEM_CD
                ,1                AS EFFICIENCY
                ,SWB.REF_CELL_ITEM_CD
                ,(SELECT SCM.ELEC_LANE_VAL 
                    FROM TB_SMP_CELL_MST  SCM 
                   WHERE SCM.ITEM_CD      = SWB.REF_CELL_ITEM_CD)     AS LANE_QTY --전극 LANE수
                ,SLM.COT_SPEED_VAL       -- 전극코팅속도(m/min)                                 
                ,SLM.WIDTH_TYPE_CD       -- 폭크기 (광폭, WIDE이면  X2)
                ,SWB.CONTINENT_CD 
                ,SLM.SITE_CD 
                ,SLM.ROUTE_CD 
                ,SLM.BUILDING_NO 
                ,SLM.LINE_NO 
                ,VALID_START_DATE
                ,VALID_FINISH_DATE
            FROM TB_SMP_WK_BOM   SWB
                ,TB_SMP_LINE_MST SLM
                ,TB_SMP_SITE_MST SSM
           WHERE SWB.VERSION_ID  = P_tPLAN_OPTION.VERSION_ID
             AND SWB.USE_FLAG    = 'Y'
             AND SWB.SITE_CD     = SLM.SITE_CD 
             AND SWB.P_ROUTE_CD  = SLM.ROUTE_CD 
             AND SLM.SITE_CD     = SSM.SITE_CD
             AND SLM.USE_YN      = 'Y'
             AND SWB.P_ROUTE_CD  = P_tPLAN_OPTION.ELEC_ROUTE_CD --'BEL'
          )
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --*Set Working BOR(BEL)-무한 계획 사용용-------------------------------------------------------------------
  IF P_tPLAN_OPTION.CONSTRAINT_ELEC_YN = 'N' THEN 
    G_sSTEP_SEQ := '4.0';   
    G_sSTEP_DESC := 'Set Working BOR(BEL)-Infinite Dummy';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
    INSERT INTO TB_SMP_WK_BOR(
           VERSION_ID
          ,ROUTE_ID 
          ,LINE_CD
          ,ITEM_CD
          ,EFFICIENCY
          ,PROCESS_CAPACITY 
          ,CONTINENT_CD 
          ,SITE_CD 
          ,ROUTE_CD 
          ,LEAD_TIME
          ,BUILDING_NO
          )          
    SELECT DISTINCT
           P_tPLAN_OPTION.VERSION_ID                    AS VERSION_ID
          ,SWB.ROUTE_ID
          ,SWB.SITE_CD || '-' || 'BEL' || '-DUMMY'      AS LINE_CD
          ,SWB.ITEM_CD
          ,1                                            AS EFFICIENCY
          ,SWB.PROCESS_CAPACITY                         AS PROCESS_CAPACITY
          ,SWB.CONTINENT_CD                            
          ,SWB.SITE_CD                                 
          ,SWB.ROUTE_CD                              
          ,NULL LEAD_TIME                              
          ,'DUMMY'                                      AS BUILDING_NO
      FROM (
            SELECT ROUTE_ID 
                  ,SITE_CD
                  ,ITEM_CD
                  ,PROCESS_CAPACITY
                  ,CONTINENT_CD                            
                  ,ROUTE_CD                              
                  ,ROW_NUMBER() OVER ( PARTITION BY ROUTE_ID ORDER BY NVL(PROCESS_CAPACITY, 0) DESC, LINE_CD) RNK
              FROM TB_SMP_WK_BOR
             WHERE VERSION_ID     = P_tPLAN_OPTION.VERSION_ID
               AND ROUTE_CD       = P_tPLAN_OPTION.ELEC_ROUTE_CD --'BEL'
               AND LINE_CD NOT LIKE '%DUMMY%'      
           ) SWB
     WHERE RNK = 1 -- PROCESS CAPA. 제일 큰 값을 DUMMY로 등록
    ; 
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  END IF;
  ------------------------------------------------------------------------------------------------------
  
  --*Set Working BOR (BOD)------------------------------------------------------------------------------
  G_sSTEP_SEQ := '5.0';   
  G_sSTEP_DESC := 'Set Working BOR (BOD)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);           
  INSERT INTO TB_SMP_WK_BOR(
         VERSION_ID
        ,ROUTE_ID 
        ,LINE_CD
        ,ITEM_CD
        ,EFFICIENCY
        ,PROCESS_CAPACITY 
        ,CONTINENT_CD 
        ,SITE_CD 
        ,ROUTE_CD 
        ,LEAD_TIME
        )  
  SELECT DISTINCT
         P_tPLAN_OPTION.VERSION_ID
        ,SWB.ROUTE_ID 
        ,SWB.SITE_CD || '-' || SWB.T_CONTINENT_CD || '@' || SWB.SITE_CD  AS LINE_CD --RSOURCE_ID
        ,SWB.P_ITEM_CD
        ,1                 AS EFFICIENCY
        ,0                 AS PROCESS_CAPACITY      
        ,SWB.CONTINENT_CD 
        ,SWB.SITE_CD
        ,SWB.P_ROUTE_CD    AS ROUE_CD        
        ,SWB.LEAD_TIME     AS LEAD_TIME_WEEKS       
    FROM TB_SMP_WK_BOM   SWB
   WHERE SWB.VERSION_ID  = P_tPLAN_OPTION.VERSION_ID
     AND SWB.P_ROUTE_CD  = P_tPLAN_OPTION.BOD_ROUTE_CD --'BOD'
     AND SWB.USE_FLAG    = 'Y'
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --*Set Job Change Info.-------------------------------------------------------------------------------
  G_sSTEP_SEQ := '5.0';   
  G_sSTEP_DESC := 'Set Job Change Info.';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);           
  UPDATE TB_SMP_WK_BOR SWB
     SET (SWB.WIDTH_VAL, SWB.LENGTH_VAL, SWB.THICKNESS_VAL) =
         (SELECT SCM.WIDTH_VAL, SCM.LENGTH_VAL, SCM.THICKNESS_VAL 
            FROM TB_SMP_CELL_MST SCM
           WHERE SCM.ITEM_CD     = SWB.ITEM_CD)
   WHERE SWB.VERSION_ID = P_tPLAN_OPTION.VERSION_ID
     AND SWB.ROUTE_CD   = P_tPLAN_OPTION.ASSY_ROUTE_CD -- 'BAS'
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_sFLAG   := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

PROCEDURE SP_VERIFY_DATA (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_VERIFY_DATA
* Purpose : Working Demand 생성
* Notes   : VERIFY_DATE IN (NO_ITEM_CD, NO_CERF, DATE_CERF, DATE_LINE) --> 무조건 SHORT발생건으로 계획대상에서 제외 필요함
*           [Special Logic]
* 
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
IS  
  USR_EXCEPT                EXCEPTION;
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_VERIFY_DATA';
  --*-- CELL정보 누락--------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Not exists Item Code at [TB_SMP_DEMAND_PGM_MST]';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  UPDATE TB_SMP_WK_DEMAND SWD 
     SET SWD.VERIFY_DATA  = SWD.VERIFY_DATA || '*NO_ITEM_CD'
-->[AIS_TODO]     
       -- ,SWD.USE_FLAG     = 'N'
   WHERE VERSION_ID       = P_tPLAN_OPTION.VERSION_ID
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_DEMAND_PGM_MST DPM
          WHERE DPM.PGM_D_CD          = SWD.PGM_D_CD
            AND DPM.ITEM_CD           IS NULL
         )
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --*-- CELL정보 누락--------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Not exists CELL at [TB_SMP_DEMAND_PGM_MST]';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  UPDATE TB_SMP_WK_DEMAND SWD 
     SET SWD.VERIFY_DATA  = SWD.VERIFY_DATA || '*NO_CELL'
   WHERE VERSION_ID       = P_tPLAN_OPTION.VERSION_ID
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_DEMAND_PGM_MST DPM
          WHERE DPM.PGM_D_CD          = SWD.PGM_D_CD
            AND DPM.CELL_CD           IS NULL
         )
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --*-- 라인 인증 정보 없음-----------------------------------------------------------------------------------
  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Not exists Certi. at [TB_SMP_ASSY_CERF_MST]';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  UPDATE TB_SMP_WK_DEMAND SWD 
     SET SWD.VERIFY_DATA  = SWD.VERIFY_DATA || '*NO_CERF'
   WHERE VERSION_ID       = P_tPLAN_OPTION.VERSION_ID
     AND NOT EXISTS (
         SELECT 1
           FROM TB_SMP_ASSY_CERF_MST  ACM
          WHERE ACM.CELL_CD           = SWD.CELL_CD
            AND ACM.CERTIF_MONTH      IS NOT NULL
         )
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --*-- 라인 인증 기간을 만족하는 정보 없음.-----------------------------------------------------------------------
  G_sSTEP_SEQ := '3.0';   
  G_sSTEP_DESC := 'Not exists Certi.Month at [TB_SMP_DEMAND_PGM_MST]';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  UPDATE TB_SMP_WK_DEMAND SWD 
     SET SWD.VERIFY_DATA  = SWD.VERIFY_DATA || '*DATE_CERF'
   WHERE VERSION_ID       = P_tPLAN_OPTION.VERSION_ID
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_ASSY_CERF_MST  ACM
          WHERE ACM.CELL_CD           = SWD.CELL_CD
            AND ACM.CERTIF_MONTH      IS NOT NULL
         )
     AND NOT EXISTS (
         SELECT 1
           FROM TB_SMP_ASSY_CERF_MST  ACM
          WHERE ACM.CELL_CD           = SWD.CELL_CD
            AND ACM.CERTIF_MONTH     <= TO_CHAR(SWD.DUE_DATE, 'YYYYMM')
            AND ACM.CERTIF_MONTH      IS NOT NULL
         )     
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --*-- 라인 유효일자.--------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '4.0';   
  G_sSTEP_DESC := 'Not exists Line Vaild Date at [TB_SMP_LINE_MST]';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  UPDATE TB_SMP_WK_DEMAND SWD 
     SET SWD.VERIFY_DATA  = SWD.VERIFY_DATA || '*DATE_LINE'
   WHERE VERSION_ID       = P_tPLAN_OPTION.VERSION_ID
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_ASSY_CERF_MST  ACM
          WHERE ACM.CELL_CD           = SWD.CELL_CD
            AND ACM.CERTIF_MONTH     <= TO_CHAR(SWD.DUE_DATE, 'YYYYMM')
            AND ACM.CERTIF_MONTH      IS NOT NULL
         )       
     AND NOT EXISTS (
         SELECT 1
           FROM TB_SMP_ASSY_CERF_MST  ACM
               ,TB_SMP_LINE_MST       SLM
          WHERE ACM.SITE_CD           = SLM.SITE_CD
            AND ACM.LINE_CD           = SLM.LINE_CD
            AND ACM.CERTIF_MONTH      IS NOT NULL
            AND ACM.CELL_CD           = SWD.CELL_CD
            AND ACM.CERTIF_MONTH     <= TO_CHAR(SWD.DUE_DATE, 'YYYYMM')
            AND TO_CHAR(SWD.DUE_DATE, 'YYYYMMDD') BETWEEN SLM.VALID_START_DATE AND SLM.VALID_FINISH_DATE
         )     
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
 
  --*-- L/T를 만족하지 못함.---------------------------------------------------------------------------------
  G_sSTEP_SEQ := '5.0';   
  G_sSTEP_DESC := 'Lead Time problem [TB_SMP_BOD_MST]';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  UPDATE TB_SMP_WK_DEMAND SWD 
     SET SWD.VERIFY_DATA  = SWD.VERIFY_DATA || '*LT'
   WHERE VERSION_ID       = P_tPLAN_OPTION.VERSION_ID
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_ASSY_CERF_MST  ACM
          WHERE ACM.CELL_CD           = SWD.CELL_CD
            AND ACM.CERTIF_MONTH     <= TO_CHAR(SWD.DUE_DATE, 'YYYYMM')
            AND ACM.CERTIF_MONTH      IS NOT NULL
         )    
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_ASSY_CERF_MST  ACM
               ,TB_SMP_LINE_MST       SLM
          WHERE ACM.SITE_CD           = SLM.SITE_CD
            AND ACM.LINE_CD           = SLM.LINE_CD
            AND ACM.CERTIF_MONTH      IS NOT NULL
            AND ACM.CELL_CD           = SWD.CELL_CD
            AND ACM.CERTIF_MONTH     <= TO_CHAR(SWD.DUE_DATE, 'YYYYMM')
            AND TO_CHAR(SWD.DUE_DATE, 'YYYYMMDD') BETWEEN SLM.VALID_START_DATE AND SLM.VALID_FINISH_DATE
         )          
     AND NOT EXISTS (
         SELECT 1
           FROM TB_SMP_DEMAND_PGM_MST DPM
               ,TB_SMP_ASSY_CERF_MST  ACM
               ,TB_SMP_SITE_MST       SSM
               ,TB_SMP_BOD_MST        SBM
               ,TB_SMP_LINE_MST       SLM
          WHERE DPM.CELL_CD           = ACM.CELL_CD
            AND ACM.SITE_CD           = SSM.SITE_CD
            ANd SSM.CONTINENT_CD      = SBM.F_CONTINENT_CD
            AND DPM.OEM_TO_SITE_CD    = SBM.T_CONTINENT_CD  
            AND DPM.PGM_D_CD          = SWD.PGM_D_CD 
            AND ACM.SITE_CD           = SLM.SITE_CD
            AND ACM.LINE_CD           = SLM.LINE_CD
--[AIS_TODO] 재고, 계획오더 올리면 이조건 변경해야 함.            
            AND TO_CHAR(ADD_MONTHS(SWD.DUE_DATE, -1 * (SBM.DELIVERY_LT + SBM.FORMATION_LT)), 'YYYYMMDD') BETWEEN SLM.VALID_START_DATE AND SLM.VALID_FINISH_DATE
            AND TO_CHAR(ADD_MONTHS(SWD.DUE_DATE, -1 * (SBM.DELIVERY_LT + SBM.FORMATION_LT)), 'YYYYMM')   >= ACM.CERTIF_MONTH
            AND         ADD_MONTHS(SWD.DUE_DATE, -1 * (SBM.DELIVERY_LT + SBM.FORMATION_LT))              >= ADD_MONTHS(P_tPLAN_OPTION.START_DATE,  SSM.MP_FIXED_MM_VAL) --계획 시작일  
         )    
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
/* 조립이 없는 DEMAND
WITH W_BOM AS ( 
  SELECT VERSION_ID
        ,LEVEL, CONNECT_BY_ISLEAF, SYS_CONNECT_BY_PATH(B.P_ITEM_CD, '*') 
        ,CONNECT_BY_ROOT  B.P_INVENTORY_ID AS TOP_INVENTORY_ID
        ,B.SITE_CD
        ,B.P_ITEM_CD
        ,B.C_ITEM_CD                
        ,B.C_ROUTE_CD
    FROM TB_SMP_WK_BOM    B
   WHERE 1=1
     AND B.VERSION_ID     = 'MP01_20200318001'-- P_tPLAN_OPTION.VERSION_ID
     AND B.C_ROUTE_CD     = 'BAS'
  START WITH B.VERSION_ID = 'MP01_20200318001' --P_tPLAN_OPTION.VERSION_ID 
         --AND B.P_ROUTE_CD = P_tPLAN_OPTION.ASSY_ROUTE_CD -- 'BAS'
         AND B.P_INVENTORY_ID            --= 'CE0530S001A@AS'--'SE00089002A@AS'
                              IN (SELECT SWD.INVENTORY_ID
                                    FROM TB_SMP_WK_DEMAND SWD
                                   WHERE SWD.VERSION_ID   = 'MP01_20200318001'
                                    --AND SWD.INVENTORY_ID = 'CE0530S001A@AS'--'SE00089002A@AS'
                                 )
  CONNECT BY NOCYCLE B.P_ITEM_CD  = PRIOR B.C_ITEM_CD 
                 AND B.SITE_CD    = PRIOR B.SITE_CD
                 AND B.VERSION_ID = PRIOR B.VERSION_ID
                 AND PRIOR B.USE_FLAG = 'Y'
)
SELECT *
  FROM TB_SMP_WK_DEMAND SWD   
 WHERE SWD.VERSION_ID   = 'MP01_20200318001'
   AND NOT EXISTS (
       SELECT 1
         FROM W_BOM B
        WHERE 1=1
          AND B.TOP_INVENTORY_ID = SWD.INVENTORY_ID
       )
*/
       
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_sFLAG   := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;
END PKG_SMP_I_MASTER;
/

