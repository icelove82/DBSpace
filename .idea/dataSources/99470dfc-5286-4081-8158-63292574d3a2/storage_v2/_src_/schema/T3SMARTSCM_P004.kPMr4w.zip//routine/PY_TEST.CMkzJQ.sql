create PROCEDURE                 "PY_TEST" (
          T_NAME                   VARCHAR2      := ''         
          ,T_AGE              INT     := '' 
          , pRESULT               OUT SYS_REFCURSOR
) 
IS
BEGIN
OPEN pRESULT
FOR
	  SELECT TEST_NAME
            , TEST_ADDR
         FROM PYTHON_TEST
        WHERE TEST_NAME LIKE '%' || T_NAME || '%'
          AND TEST_AGE < T_AGE;
END;

/

