create PROCEDURE                 SP_SMP_EXE_INBOUND(
 P_sENGINE_ID      IN     VARCHAR2
,P_sVERSION_ID     IN     VARCHAR2
,P_sBASE_MONTH     IN     VARCHAR2
,P_sPLAN_DESC      IN     VARCHAR2
,O_sFLAG           OUT    VARCHAR2 
,O_sMSG            OUT    VARCHAR2
,P_sRUNNER         IN     VARCHAR2 DEFAULT 'MP_RUNNER' -- 'MP_TESTER'--
,P_sPGM_RUN_VER    IN     VARCHAR2 DEFAULT '2020.04.03 17:30'
)
IS 
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved.
**************************************************************************
* Name    : SP_SMP_EXE_INBOUND
* Purpose : MP Inbound Procedure.
* Notes   :
* <호출>
   PKG_SMP_I_MASTER        기준정보(BOM, BOR), Demand 관련 정보 선행 작업( 필요시 Working Table 사용)
   PKG_SMP_I_STATIC        기준정보, Master성 테이블
   PKG_SMP_I_DYNAMIC       주문, 실적 정보
   PKG_SMP_I_CONSTRAINT    제약 ( 요구 사항 중심 )
**************************************************************************
* History :
* 2020-02-21 AIS Created
**************************************************************************/
  USER_EXCEPTION  EXCEPTION;

  --> Default로 위 2개 버전(COMPILE vs RUN)이 일치 모든 프로그램 실행, 만약 특정 부분 프로그램 테스트시 running 버번을 달리하여 실행
  G_sPGM_COMPILE_VER  VARCHAR2(50) := '2020.04.03_17:30';

  G_nLOG_SEQ      NUMBER;
  G_sPROGRAMN_ID  NVARCHAR2(50) := 'SP_SMP_EXE_INBOUND';-- DBMS_UTILITY.FORMAT_CALL_STACK;
  G_sSTEP_SEQ     NVARCHAR2(50);
  G_sSTEP_DESC    NVARCHAR2(50);
  --G_sVERSION_ID   NVARCHAR2(50);
  G_sUSER_ID      NVARCHAR2(50);
  G_nSQL_CNT      NUMBER(20);
  G_sLOGMSG       VARCHAR2(4000);

  G_tPLAN_OPTION  TP_SMP_PLAN_OPTION := TP_SMP_PLAN_OPTION();

  G_nLOG_END_SEQ  NUMBER;
  /*Exception Local Procedure*/
  PROCEDURE RAISE_EXCEPTION(sFLAG VARCHAR2, sMSG VARCHAR2)
  IS
  BEGIN
    IF sFLAG = 'F' THEN
      G_sLOGMSG := sMSG;
      RAISE USER_EXCEPTION;
    END IF;
  END;
BEGIN

  /* 임시로 서버에 반영된 Control Board Test용 임. */
  -------------------------------------------------------------------------------------------------
/*  IF P_sRUNNER = 'MP_TESTER' THEN
    SP_SMP_EXE_INBOUND_TEST(
     P_sENGINE_ID      => P_sENGINE_ID
    ,P_sVERSION_ID     => P_sVERSION_ID
    ,P_sBASE_MONTH     => P_sBASE_MONTH
    ,P_sPLAN_DESC      => P_sPLAN_DESC
    ,O_sFLAG           => O_sFLAG
    ,O_sMSG            => O_sMSG
    ,P_sRUNNER         => P_sRUNNER
    )  ;
    RETURN;
  END IF;*/
  -------------------------------------------------------------------------------------------------

  G_sSTEP_SEQ := '0.0';
  G_sSTEP_DESC := 'SP_SMP_EXE_INBOUND (Start)';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_END_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);

  G_tPLAN_OPTION.PGM_COMPILE_VER := G_sPGM_COMPILE_VER;
  G_tPLAN_OPTION.PGM_RUNNING_VER := P_sPGM_RUN_VER;

  G_sSTEP_SEQ := '1.0';
  G_sSTEP_DESC := 'Inbound Start';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);
  UPDATE TB_SMP_VER_MST
     SET STATUS_CD  = 'S'
       , EXE_DTTM   = SYSDATE
   WHERE VERSION_ID = P_sVERSION_ID
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);


  /*PDB Table Init.*/ 
  G_sSTEP_SEQ := '2.0';
  G_sSTEP_DESC := 'Init. PDB';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);
  T3SUPPLYNET_P004.SP_SMP_INIT_I_PDB(P_sENGINE_ID, NULL);
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);

  /*SET MASTER DATA*/
 BEGIN
    G_sSTEP_SEQ := '3.0';
    G_sSTEP_DESC := '[INBOUND] SET MAST DATA';
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);

    PKG_SMP_LOGGER.stepDebug (G_nLOG_SEQ, 'SP_SET_PLAN_OPTION', 'S');
    PKG_SMP_I_MASTER.SP_SET_PLAN_OPTION (
      P_sENGINE_ID   => P_sENGINE_ID
    , P_sVERSION_ID  => P_sVERSION_ID
    , P_sBASE_MONTH  => P_sBASE_MONTH
    , P_sPLAN_DESC   => P_sPLAN_DESC
    , O_tPLAN_OPTION => G_tPLAN_OPTION
    , O_sFLAG        => O_sFLAG
    );
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set Plan Option');

    PKG_SMP_LOGGER.stepDebug (G_nLOG_SEQ, 'SP_SET_WORK_DEMAND', 'S');
    PKG_SMP_I_MASTER.SP_SET_WORK_DEMAND         (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set Demand');

    PKG_SMP_LOGGER.stepDebug (G_nLOG_SEQ, 'SP_SET_WORK_FIXED_ORD', 'S');
    PKG_SMP_I_MASTER.SP_SET_WORK_FIXED_ORD      (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set Fixed Order');

    PKG_SMP_I_MASTER.SP_SET_WORK_BOM            (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Work BOM');

    PKG_SMP_I_MASTER.SP_SET_WORK_BOR            (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Work BOR');

    PKG_SMP_I_MASTER.SP_VERIFY_DATA             (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Verify Data');

    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
    COMMIT;
  END;

  /*SET STATIC DATA*/
  BEGIN
    G_sSTEP_SEQ := '4.0';
    G_sSTEP_DESC := '[INBOUND] SET STATIC DATA';
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);

    PKG_SMP_I_STATIC.SP_SET_ORG                (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set Organization');

    PKG_SMP_I_STATIC.SP_SET_CALENDAR           (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set Plan Horizon');

    PKG_SMP_I_STATIC.SP_SET_RES_AVAIL          (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set Resource Available');

    PKG_SMP_I_STATIC.SP_SET_ITEM               (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set Item/Inventory');

    PKG_SMP_I_STATIC.SP_SET_BOM                (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set BOM');

    PKG_SMP_I_STATIC.SP_SET_BOR                (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set BOR');

    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
    COMMIT;
  END;

  /*SET DYNAMIC DATA */
  BEGIN
    G_sSTEP_SEQ := '5.0';
    G_sSTEP_DESC := '[INBOUND] SET DYNAMIC DATA';
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);

    IF NVL(G_tPLAN_OPTION.USED_STOCK_YN, 'Y') = 'Y' THEN --재고 반영 여부
      PKG_SMP_I_DYNAMIC.SP_SET_STOCK           (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
      RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set Stock');
    END IF;

    PKG_SMP_I_DYNAMIC.SP_SET_SO                (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set Sales Order');

    IF NVL(G_tPLAN_OPTION.USED_FIXED_PLAN_YN, 'Y') = 'Y' THEN --확정 계획 반영 여부
      PKG_SMP_I_DYNAMIC.SP_SET_FIXED_ZONE      (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
      RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set Fixed Zone');
    END IF;

    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
    COMMIT;
  END;

  /*SET CONSTRAINTS DATA*/
  BEGIN
    G_sSTEP_SEQ := '6.0';
    G_sSTEP_DESC := '[INBOUND] SET CONSTRAINTS DATA';
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);

    PKG_SMP_I_CONSTRAINT.SP_SET_LINE_CAPA      (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set Line Capacity');

    PKG_SMP_I_CONSTRAINT.SP_SET_LINE_MAP       (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set Line Mapping');

    PKG_SMP_I_CONSTRAINT.SP_SET_BOD_PRIORITY   (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set BOD Priority');

    PKG_SMP_I_CONSTRAINT.SP_SET_BAS_PRIORITY   (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set BAS Priority');

    PKG_SMP_I_CONSTRAINT.SP_SET_BAS_CERTI      (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set BAS Certification');

    PKG_SMP_I_CONSTRAINT.SP_SET_BAS_JCT        (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set BAS Job change time');

    PKG_SMP_I_CONSTRAINT.SP_SET_BEL_PST        (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set BEL PST');

    PKG_SMP_I_CONSTRAINT.SP_SET_STOCK_CAPA     (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set Vendor Capa.');

    PKG_SMP_I_CONSTRAINT.SP_SET_DYNAMIC_RATE   (P_tPLAN_OPTION => G_tPLAN_OPTION, O_sFLAG => O_sFLAG);
    RAISE_EXCEPTION(O_sFLAG, '[ERROR]Set Dynamic rate'); 
   
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
    COMMIT;
  END;

  DECLARE 
    sPLAN_TYPE VARCHAR2(10);
    sPLAN_DESC CONFIG.OPTION1%TYPE; 
  BEGIN
    IF G_tPLAN_OPTION.CONSTRAINT_MAT_YN = 'Y' THEN
      sPLAN_TYPE := 'FCFM';
    ELSE
      sPLAN_TYPE := 'FCIM';
    END IF;

    G_sSTEP_SEQ := '7.0';
    G_sSTEP_DESC := '[CONFIG] Init. Config.';
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);
    --*모든 엔진 실행 모드 = N 처리
    UPDATE CONFIG 
       SET OPTION2       = 'N'
     WHERE CONFIG_ID     = P_sRUNNER;
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);

    G_sSTEP_SEQ := '8.0';
    G_sSTEP_DESC := '[CONFIG] Set Config.';
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);
    --*모든 엔진 실행 모드 = N 처리
    --*현재 처리할 건만 Y 처리
    sPLAN_DESC := 'OP2=현재실행중FLAG, OP3=VERSION_ID, OP4=PLAN_TYPE(FCFM, FCIM)';
    MERGE INTO CONFIG TAR
    USING (SELECT P_sENGINE_ID  AS ENGINE_ID
                 ,P_sVERSION_ID AS VERSION_ID
                 ,P_sRUNNER     AS RUNNER
             FROM DUAL
          ) SRC
    ON (    TAR.ENGINE_ID = SRC.ENGINE_ID
        AND TAR.CONFIG_ID = SRC.RUNNER )
    WHEN MATCHED     THEN
      UPDATE
         SET TAR.OPTION1 = sPLAN_DESC
            ,TAR.OPTION2 = 'Y' -- 실행 상태로 변경 (엔진에서 이 flag가 있는 놈으로 처리함, query_load, non_stop.py)
            ,TAR.OPTION3 = SRC.VERSION_ID
            ,TAR.OPTION4 = sPLAN_TYPE
            --이하 참조 정보
            ,TAR.OPTION5 = P_sENGINE_ID
            ,TAR.OPTION6 = P_sVERSION_ID
            ,TAR.OPTION7 = P_sRUNNER
            ,TAR.OPTION8 = TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')
    WHEN NOT MATCHED THEN
      INSERT (ENGINE_ID    , CONFIG_ID , OPTION1   , OPTION2, OPTION3       , OPTION4   )
      VALUES (SRC.ENGINE_ID, SRC.RUNNER, sPLAN_DESC, 'Y'    , SRC.VERSION_ID, sPLAN_TYPE)
    ;
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  END;

  G_sSTEP_SEQ := '9.0';
  G_sSTEP_DESC := 'Inbound End';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);
  UPDATE TB_SMP_VER_MST
     SET STATUS_CD  = 'I'
       , EXE_DTTM   = SYSDATE
   WHERE VERSION_ID = P_sVERSION_ID
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);

  PKG_SMP_LOGGER.stepFINISH (G_nLOG_END_SEQ, SQL%ROWCOUNT);

  COMMIT;
  
EXCEPTION
  WHEN USER_EXCEPTION THEN
    ROLLBACK;
    UPDATE TB_SMP_VER_MST
       SET STATUS_CD  = 'E'
         , EXE_DTTM   = SYSDATE
     WHERE VERSION_ID = P_sVERSION_ID
    ;
    COMMIT;
    O_sFLAG    := 'F';
    O_sMSG     := G_sLOGMSG;
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);
  WHEN OTHERS     THEN
    ROLLBACK;
    UPDATE TB_SMP_VER_MST
       SET STATUS_CD  = 'E'
         , EXE_DTTM   = SYSDATE
     WHERE VERSION_ID = P_sVERSION_ID
    ;
    COMMIT;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    O_sMSG     := G_sLOGMSG;
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);
END;
/

