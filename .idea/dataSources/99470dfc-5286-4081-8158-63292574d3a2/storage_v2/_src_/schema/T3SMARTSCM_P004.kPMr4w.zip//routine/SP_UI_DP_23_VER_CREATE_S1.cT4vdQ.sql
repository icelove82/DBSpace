create PROCEDURE                 SP_UI_DP_23_VER_CREATE_S1(
     p_VER_ID           VARCHAR2
    ,p_VER_BUCKET		VARCHAR2
    ,p_VER_HORIZON		VARCHAR2
    ,p_VER_FROM_DATE    DATE
    ,p_VER_TO_DATE      DATE
    ,p_VER_DTF			VARCHAR2
    ,p_VER_DTF_DATE     DATE
    ,p_VER_STAT_BUCKET	VARCHAR2
    ,p_VER_DESCRIP      VARCHAR2
    ,p_PARTIAL_BUCKET	VARCHAR2
    ,p_PARTIAL_HORIZON	VARCHAR2
    ,p_PARTIAL_DATE		DATE
    ,p_PARTIAL_BUCKET2	VARCHAR2
    ,p_PARTIAL_HORIZON2	VARCHAR2
    ,p_PARTIAL_DATE2	DATE
    ,p_PLAN_TP			CHAR
    ,p_PRICE_TYPE		VARCHAR2
    ,p_CURRENCY_TYPE	VARCHAR2
    ,p_USER_ID			VARCHAR2
    ,p_RT_ROLLBACK_FLAG	OUT VARCHAR2
    ,p_RT_MSG           OUT VARCHAR2
) 
IS

/*****************************************************************************
Title : SP_DP_VER_CREATE_S1
최초 작성자 : 이고은
최초 생성일 : 2017.07.10
?
설명 
 - DP VERSION CREATE
?
History (수정일자 / 수정자 / 수정내용)
- 2017.07.10 / 이고은 / 최초 작성
- 2020.12.23 / 민경훈 / MSSQL -> ORACLE
- 2021.05.31 / 김용수 / DTF 값 과 BASE_YM 값 수정 로직 추가
*****************************************************************************/

p_ERR_STATUS       INT := 0;
p_ERR_MSG          VARCHAR2(4000):='';
v_PARTIAL_HORIZON2 INT;
v_FROM_DATE		   DATE ;
v_DTF              INT := 0;
v_BASE_YM          VARCHAR2(6);
BEGIN 

	-- 김용수 추가 	: 해당연동의 1/1일
    SELECT  TO_DATE(TO_CHAR(p_VER_FROM_DATE,'YYYY')||'0101','YYYYMMDD')    
      INTO  V_FROM_DATE
      FROM  DUAL
    ;


    IF(P_PARTIAL_HORIZON2 IN ('false','N',' ', 'N') )
        THEN
           v_PARTIAL_HORIZON2 := NULL;
    END IF
    ;
    --버전 DATA 저장
    INSERT INTO TB_DP_CONTROL_BOARD_VER_MST
               (ID
               ,VER_ID
               ,MODULE_ID
               ,BUKT
               ,HORIZ
               ,FROM_DATE
               ,TO_DATE
               ,DTF
               ,DTF_DATE
               ,DESCRIP
               ,CREATE_BY
               ,CREATE_DTTM
               ,VER_S_BUCKET
               ,VER_S_HORIZON
               ,VER_S_HORIZON_DATE
               ,VER_S_BUCKET2
               ,VER_S_HORIZON2
               ,VER_S_HORIZON_DATE2
               ,PLAN_TP_ID
               ,PRICE_TP_ID
               ,CURCY_TP_ID
               ,BASE_YM 
               )
         VALUES
                (TO_SINGLE_BYTE(SYS_GUID())
               ,p_VER_ID
               ,'DP'
               ,p_VER_BUCKET
               ,p_VER_HORIZON
               ,V_FROM_DATE           -- 해당연도의 1/1일로 설정
               ,p_VER_TO_DATE
               ,p_VER_DTF
               ,p_VER_DTF_DATE
               ,p_VER_DESCRIP
               ,p_USER_ID
               ,SYSDATE
               ,p_PARTIAL_BUCKET
               ,p_PARTIAL_HORIZON      
               ,p_PARTIAL_DATE  
               ,p_PARTIAL_BUCKET2
               ,v_PARTIAL_HORIZON2
               ,p_PARTIAL_DATE2  
               ,p_PLAN_TP
               ,p_PRICE_TYPE
               ,p_CURRENCY_TYPE
               ,TO_CHAR(SYSDATE ,'YYYYMM')
               )
    ;    


	/***********************************************************************************************************************
		-- DTF 값 수정 로직 추가 : DTF DATE에 해당하는 월 값을 그대로 설정(1/1일 일때만) 0으로 설정
	************************************************************************************************************************/ 

    SELECT    CASE WHEN TO_CHAR(p_VER_DTF_DATE,'MMDD') = '0101' THEN 0 ELSE TO_NUMBER(TO_CHAR(p_VER_DTF_DATE,'MM')) END DTF
            , CASE WHEN TO_CHAR(p_VER_DTF_DATE,'MMDD') = '0101' THEN TO_CHAR(p_VER_DTF_DATE,'YYYYMM') ELSE TO_CHAR(p_VER_DTF_DATE + 1,'YYYYMM') END BASE_YM
      INTO    v_DTF
            , v_BASE_YM
      FROM    DUAL
    ;  

    UPDATE    TB_DP_CONTROL_BOARD_VER_MST
       SET    DTF     = v_DTF
            , BASE_YM = v_BASE_YM
     WHERE VER_ID =  p_VER_ID
    ; 

    -- 직전 버전 ORDER TABLE 복사
    INSERT INTO TB_SDP_ACCOUNT_ORDER T
    (
      T.VER_ID, T.ACCOUNT_ID, SHORT_ORDER, MID_ORDER, LONG_ORDER, CREATE_BY, CREATE_DTTM
    )
    SELECT    p_VER_ID VER_ID, A.ID ACCOUNT_ID, B.SHORT_ORDER, B.MID_ORDER, B.LONG_ORDER, p_USER_ID, SYSDATE 
      FROM    TB_DP_ACCOUNT_MST A
      JOIN    
            (
              SELECT    *
                FROM    TB_SDP_ACCOUNT_ORDER 
               WHERE    VER_ID = (SELECT MAX(VER_ID) FROM TB_DP_CONTROL_BOARD_VER_MST WHERE VER_ID <> p_VER_ID)
            ) B ON B.ACCOUNT_ID = A.ID 
     WHERE    A.ACTV_YN = 'Y' 
       AND    A.DEL_YN <> 'Y'
    ; 

	/***********************************************************************************************************************
		-- DTF 값 수정 로직 추가 END
	************************************************************************************************************************/ 


	p_RT_ROLLBACK_FLAG := 'true';
	p_RT_MSG := 'MSG_0001' ; --저장 되었습니다.

    EXCEPTION WHEN OTHERS THEN  --  e_products_invalid    
      IF(SQLCODE = -20001)
      THEN
          P_RT_MSG := sqlerrm;   
          p_RT_ROLLBACK_FLAG :='false';
      ELSE
        --SP_COMM_RAISE_ERR();              
        RAISE;
      END IF; 


END;
/

