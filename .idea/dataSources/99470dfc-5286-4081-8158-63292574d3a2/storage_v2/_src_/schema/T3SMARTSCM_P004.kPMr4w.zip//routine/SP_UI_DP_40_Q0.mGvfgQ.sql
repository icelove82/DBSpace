create PROCEDURE "SP_UI_DP_40_Q0" (  
               P_PLAN_TP_ID    IN     CHAR
              ,P_BUKT_CD       IN     VARCHAR2 
              ,pRESULT         OUT SYS_REFCURSOR 
)IS
/***************************************************
    ？？？？？？ ？？？？ ？？？ Version ？？？？ ？？？
    ？？？？？ : ？？？？？？    
    ？？？？？ : 2018.10.23~31
        - ？？？？ ？？？？？ VERSION ？？？？？？ ？？？？
        - BUKET？？ MONTH？？ ？？？？, ？？？ ？？￥？？ ？？ u°？？&？？？？？？？？
    (ex) ？？？？ ？？？ : 2018.05.02 ~ 2018.09.05
         ？？？？ ？？？ : 2018.08.05 ~ 2019.01.04
         ---------> 2018.05.01 ~ 2018.09.31        
****************************************************/
BEGIN
    OPEN pRESULT
    FOR
SELECT A.*
FROM (
    SELECT 
           VR.ID AS CD
         , VER_ID AS CD_NM
         , RANK() OVER (ORDER BY VER_ID DESC) AS ROWN
         , CASE P_BUKT_CD WHEN 'MONTH' THEN ADD_MONTHS((LAST_DAY (TRUNC (VR.FROM_DATE))+1),-1) ELSE FROM_DATE END AS FROM_DATE
         , CASE P_BUKT_CD WHEN 'MONTH' THEN LAST_DAY (TRUNC (VR.TO_DATE)) ELSE VR.TO_DATE END AS TO_DATE
      FROM TB_DP_CONTROL_BOARD_VER_MST VR
           INNER JOIN
           TB_DP_CONTROL_BOARD_VER_DTL DT   
        ON VR.ID = DT.CONBD_VER_MST_ID
    WHERE 1=1
      AND VR.PLAN_TP_ID = P_PLAN_TP_ID
      AND DT.CL_STATUS_ID = ( SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE' )
) A
WHERE ROWN <=10
ORDER BY A.CD_NM DESC    
    ;


END
;

/

