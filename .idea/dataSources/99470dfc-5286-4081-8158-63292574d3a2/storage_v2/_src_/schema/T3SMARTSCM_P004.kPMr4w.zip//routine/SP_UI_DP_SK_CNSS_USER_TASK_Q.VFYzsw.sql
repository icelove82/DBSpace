create PROCEDURE                 "SP_UI_DP_SK_CNSS_USER_TASK_Q" (
	    P_TASK_CATEGORY	    VARCHAR2 -- = 'ALL' 'CLOSE'
	  , P_EMP_NO			VARCHAR2 -- = 'GOC'
	  , P_AUTH_TP			VARCHAR2 -- = 'GOC'
	  , P_VER_CD			VARCHAR2 -- = 'DPM-20200427-003-00'	  
      , pRESULT       OUT SYS_REFCURSOR
)
IS 
/******************************************************************************************
	Check a User's Task Status of Conensus version

	Description
	- CNT : a number of approval
	- If CNT is 0, Status is true.
	- 理쒖쥌 Close瑜� �빐�룄, close瑜� �븳踰� �뜑 紐삵븯吏�留�, �떎瑜� 泥섎━�뒗 媛��뒫�븳 �긽�깭

	History (Date / Writer / Comment)
	- 2021.05.14 / Kim sohee / draft 
******************************************************************************************/
        P_CL_STATUS_CNT	INT ;
        P_FINAL_CLOSE_CNT	INT := 0;
        P_DP_VER_ID         CHAR(32);
        LEAF_YN             CHAR(1);
        P_AUTH_TP_ID        CHAR(32);
        V_ERR_STATUS        INT;
BEGIN
        SELECT COUNT(ID) INTO V_ERR_STATUS
          FROM TB_CM_LEVEL_MGMT
         WHERE SALES_LV_YN = 'Y'
           AND LV_CD = P_AUTH_TP    
           ;
    IF (V_ERR_STATUS > 0)
        THEN
            SELECT ID, LEAF_YN INTO P_AUTH_TP_ID, LEAF_YN   -- SALESMAN LEVEL CHECK
              FROM TB_CM_LEVEL_MGMT
             WHERE SALES_LV_YN = 'Y'
               AND LV_CD = P_AUTH_TP
              ;
        END IF;             
            SELECT COUNT(M.ID) INTO V_ERR_STATUS
              FROM TB_SDP_CONSENSUS_VER_MST C
                   INNER JOIN 
                   TB_DP_CONTROL_BOARD_VER_MST M
                ON C.DP_VER_CD = M.VER_ID 
             WHERE C_VER_CD = P_VER_CD 
             ;        
        IF (V_ERR_STATUS > 0)
            THEN
            SELECT M.ID INTO P_DP_VER_ID
              FROM TB_SDP_CONSENSUS_VER_MST C
                   INNER JOIN 
                   TB_DP_CONTROL_BOARD_VER_MST M
                ON C.DP_VER_CD = M.VER_ID 
             WHERE C_VER_CD = P_VER_CD 
             ;
             END IF
             ;
			-- (2) 理쒖쥌 Close瑜� �뻽�뒗吏� �븞�뻽�뒗吏� : �씠 寃쎌슦, �떎瑜� Status�룄 diable �긽�깭濡� 蹂�寃�
			SELECT COUNT(1) INTO P_FINAL_CLOSE_CNT
			  FROM TB_SDP_CONSENSUS_VER_MST CD				 
			 WHERE STATUS = 'CLOSE'
			   AND C_VER_CD = P_VER_CD 		
			 ;
			-- Close 媛��뒫�븳 �긽�깭�씤吏� �븘�땶吏� �뙋�떒
			-- (1) 理쒖긽�쐞 愿�由ъ옄�쓽 媛��옣 理쒓렐 泥섎━ �긽�깭媛� �듅�씤�씤吏� �븘�땶吏�
			WITH GOC
			AS (
                SELECT   MIN(EP.USERNAME) KEEP (DENSE_RANK FIRST ORDER BY CL.SEQ ASC)	AS USER_ID
						,MIN(CL.LV_CD	) KEEP (DENSE_RANK FIRST ORDER BY CL.SEQ ASC)	AS AUTH_TP
				  FROM TB_DP_SALES_AUTH_MAP SA
					   INNER JOIN
					   TB_DP_SALES_LEVEL_MGMT SL
					ON SA.SALES_LV_ID = SL.ID
                   AND SL.ACTV_YN = 'Y'
				   AND COALESCE(SL.DEL_YN,'N') = 'N'
					   INNER JOIN
					   TB_CM_LEVEL_MGMT CL
					ON SL.LV_MGMT_ID = CL.ID
                   AND CL.ACTV_YN = 'Y'
				   AND COALESCE(CL.DEL_YN,'N') = 'N'
					   INNER JOIN 
					   TB_DP_CONTROL_BOARD_VER_DTL VD
					ON VD.CONBD_VER_MST_ID = P_DP_VER_ID
				   AND CL.ID = VD.LV_MGMT_ID
					   INNER JOIN
					   TB_AD_USER EP
					ON EP.ID = SA.EMP_ID
				)
			SELECT COUNT(STATUS)  INTO P_CL_STATUS_CNT
			  FROM (
					SELECT NVL(ST.STATUS, 'READY') AS STATUS, ROW_NUMBER() OVER (PARTITION BY GC.USER_ID ORDER BY ST.STATUS_DATE DESC) AS RW
					  FROM GOC  GC
						   LEFT OUTER JOIN 
						   TB_DP_PROCESS_STATUS_LOG ST
						ON ST.OPERATOR_ID = GC.USER_ID
					   AND ST.AUTH_TYPE = GC.AUTH_TP 
					   AND VER_CD = P_VER_CD
					) A
			 WHERE A.RW = 1
			   AND  STATUS != 'APPROVAL'
			  ;


--			SELECT P_FINAL_CLOSE_CNT, P_CL_STATUS_CNT;
          OPEN pRESULT
            FOR
			WITH STA_CONF
			AS (SELECT AC.CONF_CD						AS APPROVAL
					 , IT.CONF_CD	 					AS INPUT	
					 , NVL(CC.CONF_CD, AC.CONF_CD)	    AS "CANCEL"
				  FROM TB_DP_CONTROL_BOARD_VER_MST CB
					   INNER JOIN
					   TB_DP_CONTROL_BOARD_VER_DTL CD
					ON CB.ID = CD.CONBD_VER_MST_ID
				   AND CB.ID = P_DP_VER_ID 
					   INNER JOIN
					   TB_CM_LEVEL_MGMT LV
					ON CD.LV_MGMT_ID = LV.ID 
				   AND LV.LV_CD = P_AUTH_TP
					   LEFT OUTER JOIN
					   TB_CM_COMM_CONFIG AC
					ON CD.APPV_CONST_ID = AC.ID
					   LEFT OUTER JOIN
					   TB_CM_COMM_CONFIG IT
					ON CD.INPUT_TP_ID = IT.ID 
					   LEFT OUTER JOIN
					   TB_CM_COMM_CONFIG CC
					ON CD.CANC_CONST_ID = CC.ID
--				 WHERE CB.PLAN_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01 = 'M') 
			), EMP_INFO
			AS (SELECT DESC_ROLE_CD		AS AUTH_TP
					 , DESC_CD			AS EMP_NO
					,  'D'				AS LV
				FROM TB_DPD_USER_HIER_CLOSURE
					   INNER JOIN 
					   TB_DP_CONTROL_BOARD_VER_DTL VD
					ON VD.CONBD_VER_MST_ID = P_DP_VER_ID
				   AND DESC_ROLE_ID = VD.LV_MGMT_ID
				WHERE ANCS_CD = P_EMP_NO
				  AND ANCS_ROLE_CD = P_AUTH_TP 
				  AND ANCS_CD != DESC_CD
                  AND CASE WHEN LEAF_YN = 'Y' THEN MAIN_LV_YN ELSE 'Y' END = 'Y'                  
				UNION
				SELECT ANCS_ROLE_CD		AS AUTH_TP
					 , ANCS_CD			AS EMP_NO
					 , 'A'				AS LV 
				FROM TB_DPD_USER_HIER_CLOSURE
					   INNER JOIN 
					   TB_DP_CONTROL_BOARD_VER_DTL VD
					ON VD.CONBD_VER_MST_ID = P_DP_VER_ID
				   AND ANCS_ROLE_ID = VD.LV_MGMT_ID
				WHERE DESC_CD = P_EMP_NO
				  AND DESC_ROLE_CD = P_AUTH_TP 
				  AND DESC_CD != ANCS_CD
                  AND CASE WHEN LEAF_YN = 'Y' THEN MAIN_LV_YN ELSE 'Y' END = 'Y'
				UNION
				SELECT P_AUTH_TP
					 , P_EMP_NO
					 , 'S'
                  FROM DUAL
			), M
			AS (SELECT AUTH_TP
					 , EMP_NO
					 , STATUS
					 , STATUS_DATE
					 , LV 
					 , CASE WHEN LV  = 'A'  AND STATUS  = 'APPROVAL'	  THEN 'N'							-- PR	-- NT
							WHEN LV  = 'D'  AND STATUS != 'APPROVAL'	  THEN 'N' 							-- PR
							WHEN LV  = 'S'  AND STATUS  = 'APPROVAL'      THEN 'N'							-- PR	-- NT
							WHEN STATUS = 'CLOSE'						  THEN 'N'
							ELSE 'Y' END	AS APPV_YN
					 , CASE WHEN LV  = 'A'  AND STATUS  IN ('PROCESS', 'APPROVAL') THEN 'N'				-- PR
							WHEN LV  = 'D'  AND STATUS != 'APPROVAL'	  THEN 'N'							-- PR
							WHEN LV  = 'S'  AND STATUS  = 'APPROVAL'      THEN 'N'							-- PR		
							WHEN STATUS = 'CLOSE'						  THEN 'N'
							ELSE 'Y' END	AS INPT_YN
					 , CASE WHEN LV  = 'A'  AND STATUS  = 'APPROVAL'	  THEN 'N'							-- NT
							WHEN LV  = 'S'  AND STATUS != 'APPROVAL'    THEN 'N'							-- NT
							WHEN STATUS = 'CLOSE'						  THEN 'N'
							ELSE 'Y' END	AS CANC_YN	
				 FROM (SELECT EP.AUTH_TP
							 , EP.EMP_NO
							 , NVL(PS.STATUS, 'READY') AS STATUS
							 , ROW_NUMBER () OVER (PARTITION BY EP.EMP_NO, EP.AUTH_TP ORDER BY PS.STATUS_DATE DESC) AS RW
							 , PS.STATUS_DATE
							 , EP.LV
						  FROM EMP_INFO  EP
			  				   LEFT OUTER JOIN
			  				   TB_DP_PROCESS_STATUS_LOG PS
		   					ON PS.AUTH_TYPE = EP.AUTH_TP
						   AND PS.OPERATOR_ID = EP.EMP_NO
						   AND VER_CD = P_VER_CD
					  ) A  
				WHERE RW = 1
				)  

				 SELECT TASK, P_FINAL_CLOSE_CNT+COUNT(M.STATUS)		AS CNT
				   FROM M
						RIGHT OUTER JOIN
						STA_CONF C
						UNPIVOT (CONF_CD FOR TASK IN (APPROVAL
													  ,INPUT	
			 			 							  ,"CANCEL"
												   )) UP
				  ON CASE UP.CONF_CD  
							WHEN 'PR'	THEN 'A,D,S'
							WHEN 'NT'	THEN 'A,S'
							-- WHEN NM  THEN NULL
 						END LIKE '%'||LV||'%'
					AND CASE TASK 
							WHEN 'APPROVAL' THEN APPV_YN
							WHEN 'INPUT'	 THEN INPT_YN
							WHEN 'CANCEL' THEN CANC_YN
						 END = 'N'	  
				  WHERE (TASK = P_TASK_CATEGORY OR P_TASK_CATEGORY = 'ALL')
				GROUP BY TASK 
				UNION
				SELECT 'CLOSE' 
					 , P_FINAL_CLOSE_CNT+P_CL_STATUS_CNT
                 FROM DUAL 
				 WHERE ('CLOSE' = P_TASK_CATEGORY OR P_TASK_CATEGORY = 'ALL')	-- �뼐�뒗 �뵲濡� �뜥以섎룄 �릺湲� �븯寃좊꽕
                ;
--         END IF
 --        ;
END
;

/

