create PROCEDURE "SP_UI_DP_22_1_S0" (    
    P_WORK_CD               VARCHAR2 
  , P_PLAN_TP_ID            CHAR  
  , P_MS_VAL_TP_CD          VARCHAR2
  , P_INIT_VAL_TP_ID        CHAR
  , P_INIT_VAL_ID           CHAR
  , P_RT_ROLLBACK_FLAG  OUT VARCHAR2 
  , P_RT_MSG            OUT VARCHAR2 
) IS 

    P_ERR_STATUS            INT             := 0;
    P_ERR_MSG               VARCHAR2(4000)  := '';
    P_CONBD_MST_ID          CHAR(32);
    P_INIT_VAL_TP_CD        VARCHAR2(30);
    P_INIT_FIXED_LV_MGMT_ID CHAR(32)        := NULL;
    P_INIT_MEASURE_ID       CHAR(32)        := NULL;

BEGIN
    SELECT ID
      INTO P_CONBD_MST_ID
      FROM TB_DP_CONTROL_BOARD_MST
     WHERE WORK_CD = P_WORK_CD
       AND PLAN_TP_ID = P_PLAN_TP_ID;

    SELECT CONF_CD
      INTO P_INIT_VAL_TP_CD 
      FROM TB_CM_COMM_CONFIG
     WHERE ID = P_INIT_VAL_TP_ID;

    IF(P_INIT_VAL_TP_CD = 'MS') THEN
        P_INIT_MEASURE_ID := P_INIT_VAL_ID;
    ELSIF (P_INIT_VAL_TP_CD = 'PR') THEN
        P_INIT_FIXED_LV_MGMT_ID := P_INIT_VAL_ID;
    END IF;

    MERGE INTO TB_DP_CONTROL_BOARD_MST_INIT TGT
    USING (
        SELECT P_CONBD_MST_ID   AS CONBD_MST_ID
             , P_MS_VAL_TP_CD   AS MS_VAL_TP_CD
          FROM DUAL
    ) SRC 
    ON (    TGT.CONBD_MST_ID = SRC.CONBD_MST_ID
        AND TGT.MS_VAL_TP_CD = SRC.MS_VAL_TP_CD
    )
    WHEN NOT MATCHED THEN
    INSERT (
        ID  
      , CONBD_MST_ID    
      , MS_VAL_TP_CD    
      , INIT_VAL_TP_ID  
      , INIT_FIXED_LV_MGMT_ID   
      , INIT_MEASURE_ID  
     )
     VALUES( 
        TO_SINGLE_BYTE(SYS_GUID()) 
      , SRC.CONBD_MST_ID
      , SRC.MS_VAL_TP_CD
      , P_INIT_VAL_TP_ID
      , P_INIT_FIXED_LV_MGMT_ID
      , P_INIT_MEASURE_ID
     )
     WHEN MATCHED THEN
     UPDATE  
        SET INIT_VAL_TP_ID = P_INIT_VAL_TP_ID
          , INIT_MEASURE_ID = P_INIT_MEASURE_ID
          , INIT_FIXED_LV_MGMT_ID = P_INIT_FIXED_LV_MGMT_ID
    ;

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';  --저장 되었습니다.

EXCEPTION WHEN OTHERS THEN
    IF (SQLCODE = -20001) THEN 
        P_ERR_MSG := SQLERRM;
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;

    ELSE 
        RAISE;
    END IF;
--              EXEC SP_COMM_RAISE_ERR
END;

/

