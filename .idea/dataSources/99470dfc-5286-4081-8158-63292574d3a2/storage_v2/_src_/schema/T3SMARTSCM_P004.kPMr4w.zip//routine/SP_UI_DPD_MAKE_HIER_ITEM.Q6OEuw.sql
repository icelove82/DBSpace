create PROCEDURE "SP_UI_DPD_MAKE_HIER_ITEM" 
IS          
/******************************************************************************************
	-- Create table 
	-- 2020.12.09 / kim sohee / oracle conveting
********************************************************************************************/
v_depth       INT := 1;
 v_max_depth    INT; 
 v_lv_cnt       INT;
 P_CHECK INT ;
BEGIN
/***************************************************************************************************************************
    -- Create Table and Index
    -- TABLE 재생성과 data변경을 프로시저에서 동시에 할 수는 없다.
    -- 프로시저 안에서 table을 만들려면 사용자에 권한이 부여돼야 한다.
****************************************************************************************************************************/
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIER_CLOSURE_01' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIER_CLOSURE_01 ON TB_DPD_ITEM_HIER_CLOSURE (ANCESTER_ID)'; 
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIER_CLOSURE_02' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIER_CLOSURE_02 ON TB_DPD_ITEM_HIER_CLOSURE (ANCESTER_CD)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIER_CLOSURE_03' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIER_CLOSURE_03 ON TB_DPD_ITEM_HIER_CLOSURE (DESCENDANT_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIER_CLOSURE_04' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIER_CLOSURE_04 ON TB_DPD_ITEM_HIER_CLOSURE (DESCENDANT_CD)';
    END IF;
/* TB_DPD_ITEM_HIERARCHY2 */
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'PK_TB_DPD_ITEM_HIERACHY2' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN    -- PK
        EXECUTE IMMEDIATE  'ALTER TABLE TB_DPD_ITEM_HIERACHY2 ADD CONSTRAINT PK_TB_DPD_ITEM_HIERACHY2 PRIMARY KEY (ITEM_ID)';        
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'UK_TB_DPD_ITEM_HIERACHY2' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN    -- UK
        EXECUTE IMMEDIATE  'CREATE UNIQUE INDEX UK_TB_DPD_ITEM_HIERACHY2 ON TB_DPD_ITEM_HIERACHY2 (ITEM_CD)';                
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_01' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_01 ON TB_DPD_ITEM_HIERACHY2 (LVL01_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_02' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_02 ON TB_DPD_ITEM_HIERACHY2 (LVL02_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_03' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_03 ON TB_DPD_ITEM_HIERACHY2 (LVL03_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_04' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_04 ON TB_DPD_ITEM_HIERACHY2 (LVL04_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_05' AND OWNER = (SELECT USER FROM DUAL);
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_05 ON TB_DPD_ITEM_HIERACHY2 (LVL05_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_06' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_06 ON TB_DPD_ITEM_HIERACHY2 (LVL06_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_07' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_07 ON TB_DPD_ITEM_HIERACHY2 (LVL07_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_08' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_08 ON TB_DPD_ITEM_HIERACHY2 (LVL08_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_09' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_09 ON TB_DPD_ITEM_HIERACHY2 (LVL09_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_10' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_10 ON TB_DPD_ITEM_HIERACHY2 (LVL10_ID)';
    END IF;
/************************************************************************************************************************************************************************************************************
	-- Main Query
************************************************************************************************************************************************************************************************************/ 
	SELECT COUNT(SEQ)
		 , SUM(LV_CNT) 
         INTO v_max_depth, v_lv_cnt
	  FROM (
			SELECT CL.SEQ, COUNT(IL.SEQ) AS LV_CNT
			  FROM TB_CM_LEVEL_MGMT CL
				   INNER JOIN 
				   TB_CM_ITEM_LEVEL_MGMT IL 
				ON CL.ID = IL.LV_MGMT_ID
			 WHERE NVL(CL.ACCOUNT_LV_YN ,'N') = 'N'
			   AND NVL(CL.SALES_LV_YN   ,'N') = 'N'
			   AND NVL(CL.DEL_YN	    ,'N') = 'N' 
			   AND CL.ACTV_YN = 'Y'
			   AND NVL(IL.DEL_YN	    ,'N') = 'N' 
			   AND IL.ACTV_YN = 'Y'
		--	   AND IL.LEAF_YN = 'N'
		  GROUP BY CL.SEQ
		) A
        ;
	delete from TB_DPD_ITEM_HIER_CLOSURE;


    insert into TB_DPD_ITEM_HIER_CLOSURE 
		 ( ancester_id
		 , ancester_cd
--		 , ancester_seq
		 , descendant_id
		 , descendant_cd
--		 , descendant_seq
		 , depth_num 
		 , leaf_yn 
 		  )
	with ITEM_hier as
	(select IL.id					as descendant_id 
		  , IL.ITEM_LV_CD			as descendant_cd
--		  , DENSE_RANK() OVER (ORDER BY CL.SEQ, IL.SEQ)+1	AS descendant_seq  
		  , IL.parent_ITEM_lv_id	as ancester_id
		  , p.ITEM_LV_CD			as ancester_cd 
		  , 'N'						AS LEAF_YN 
--		  , DENSE_RANK() OVER (ORDER BY PL.SEQ, P.SEQ)	AS ancester_seq  
	   from tb_cm_item_level_mgmt  IL
		    LEFT OUTER JOIN
			tb_cm_item_level_mgmt p 
		 ON IL.PARENT_ITEM_LV_ID=p.ID 
		and IL.ACTV_YN = 'Y' 
			INNER JOIN 
			TB_CM_LEVEL_MGMT CL
		 ON IL.LV_MGMT_ID = CL.ID 
		AND NVL(CL.DEL_YN,'N') = 'N'
		AND CL.ACTV_YN = 'Y'
	    and IL.actv_yn = 'Y'
	    and NVL(IL.del_yn,'N') = 'N'
			LEFT OUTER JOIN 
			TB_CM_LEVEL_MGMT PL
		 ON P.LV_MGMT_ID = PL.ID 
		AND NVL(PL.DEL_YN,'N') = 'N'
		AND PL.ACTV_YN = 'Y'
	    and P.actv_yn = 'Y'
	    and NVL(P.del_yn,'N') = 'N'
	 union all 
	 select I.id							as descendant_id
		  , ITEM_CD						as descendant_cd
--		  , v_lv_cnt+1						AS descendant_seq  
		  , I.parent_ITEM_lv_id			as ancester_id
		  , p.ITEM_LV_CD					as ancester_cd 
		  , 'Y'								AS LEAF_YN 
--		  , v_lv_cnt-DENSE_RANK() OVER (ORDER BY P.SEQ DESC)+1	AS ancester_seq  
	   from tb_cm_item_mst i
	 	    INNER JOIN
	        tb_cm_item_level_mgmt p 
		 ON i.PARENT_ITEM_LV_ID=p.ID 
--			INNER JOIN 
--			TB_CM_LEVEL_MGMT PL
--		 ON P.LV_MGMT_ID = PL.ID 
--		AND NVL(PL.DEL_YN,'N') = 'N'
--		AND PL.ACTV_YN = 'Y'
--	    and P.actv_yn = 'Y'
--	    and NVL(P.del_yn,'N') = 'N'						
	  WHERE 1=1
	    and P.ACTV_YN = 'Y' 
	)
	select descendant_id
		 , descendant_cd
--		 , descendant_seq
		 , descendant_id
		 , descendant_cd
--		 , descendant_seq
		 , 0				as depth_num  
		 , LEAF_YN				as leaf_yn
	   from ITEM_hier
	  where descendant_id is not null	   
	   ;

	while v_depth <= v_max_depth
	LOOP
       insert into TB_DPD_ITEM_HIER_CLOSURE 
			 ( ancester_id
			 , ancester_cd
--			 , ancester_seq
			 , descendant_id
			 , descendant_cd
--			 , descendant_seq
			 , depth_num
			 , leaf_yn  
			  )
		with ITEM_hier as
		(
			select IL.id					as descendant_id 
				 , IL.ITEM_LV_CD		as descendant_cd
--				 , DENSE_RANK() OVER (ORDER BY CL.SEQ, IL.SEQ)	AS ancester_seq 
				 , IL.parent_ITEM_lv_id as ancester_id
--				 , p.ITEM_LV_CD		as ancester_cd 
				 , 'N'					AS LEAF_YN
		   from tb_cm_item_level_mgmt IL
				INNER JOIN 
				TB_CM_LEVEL_MGMT CL
			 ON IL.LV_MGMT_ID = CL.ID 
			AND NVL(CL.DEL_YN,'N') = 'N'
			AND CL.ACTV_YN = 'Y'
		  where IL.actv_yn = 'Y'
		    and NVL(IL.del_yn,'N') = 'N'
			union all 
			select I.id					 as descendant_id
				 , ITEM_CD			 as descendant_cd
--				 , v_lv_cnt+1 SEQ 
				 , I.parent_ITEM_lv_id  as ancester_id
--				 , l.ITEM_LV_CD		 as ancester_cd
				 , 'Y'					 AS LEAF_YN
		   from tb_cm_item_mst	I		 
		  where parent_item_lv_id is not null
		)
		select c.ancester_id
			 , c.ancester_cd
--			 , c.ancester_seq
			 , h.descendant_id
			 , h.descendant_cd
--			 , h.ancester_seq
			 , v_depth 	
			 , H.LEAF_YN
		from TB_DPD_ITEM_HIER_CLOSURE c 
			  inner join 
			  ITEM_hier h 
		  on (c.descendant_id = h.ancester_id
		 and  c.depth_num = v_depth-1) 
			 ;

		v_depth := v_depth+1
        ;
	END LOOP; 
 

merge into TB_DPD_ITEM_HIERACHY2 H
using(   select M.id          AS N_ITEM_ID
                    ,U.UOM_CD      AS N_UOM
                    ,M.RTS      AS N_RTS
                    ,M.EOS      AS N_EOS
                    ,T.ITEM_TP  AS N_ITEM_TP
                    ,M.DESCRIP  AS N_DESCRIP
                  , M.ATTR_01     AS  N_ATTR_01
                  , M.ATTR_02     AS  N_ATTR_02 
                  , M.ATTR_03     AS  N_ATTR_03
                  , M.ATTR_04     AS  N_ATTR_04
                  , M.ATTR_05     AS  N_ATTR_05
                  , M.ATTR_06     AS  N_ATTR_06
                  , M.ATTR_07     AS  N_ATTR_07 
                  , M.ATTR_08     AS  N_ATTR_08
                  , M.ATTR_09     AS  N_ATTR_09
                  , M.ATTR_10     AS  N_ATTR_10
                  , M.ATTR_11     AS  N_ATTR_11
                  , M.ATTR_12     AS  N_ATTR_12
                  , M.ATTR_13     AS  N_ATTR_13
                  , M.ATTR_14     AS  N_ATTR_14
                  , M.ATTR_15     AS  N_ATTR_15
                  , M.ATTR_16     AS  N_ATTR_16
                  , M.ATTR_17     AS  N_ATTR_17
                  , M.ATTR_18     AS  N_ATTR_18
                  , M.ATTR_19     AS  N_ATTR_19
                  , M.ATTR_20     AS  N_ATTR_20 
         from TB_CM_ITEM_MST M 
			 left outer join TB_CM_UOM u on u.ID = m.UOM_ID
			 left outer join TB_CM_ITEM_TYPE t on t.ID = m.ITEM_TP_ID
			 WHERE  DP_PLAN_YN ='Y' and (m.DEL_YN='N' or m.DEL_YN is null) 	
         ) M
on ( H.ITEM_ID = M.N_ITEM_ID  )
when matched then
update set 
UOM = N_UOM
         ,RTS = N_RTS 
         ,EOS = N_EOS
         ,ITEM_TP = N_ITEM_TP
         ,DESCRIP = N_DESCRIP,
        ATTR_01=N_ATTR_01,
        ATTR_02=N_ATTR_02,
        ATTR_03=N_ATTR_03,
        ATTR_04=N_ATTR_04,
        ATTR_05=N_ATTR_05,
        ATTR_06=N_ATTR_06,
        ATTR_07=N_ATTR_07,
        ATTR_08=N_ATTR_08,
        ATTR_09=N_ATTR_09,
        ATTR_10=N_ATTR_10,
        ATTR_11=N_ATTR_11,
        ATTR_12=N_ATTR_12,
        ATTR_13=N_ATTR_13,
        ATTR_14=N_ATTR_14,
        ATTR_15=N_ATTR_15,
        ATTR_16=N_ATTR_16,
        ATTR_17=N_ATTR_17,
        ATTR_18=N_ATTR_18,
        ATTR_19=N_ATTR_19,
        ATTR_20=N_ATTR_20
       ;
/*
update  
( 
			SELECT   H.LVL01_ID
                    ,H.LVL01_CD
                    ,H.LVL01_NM
                    ,H.LVL02_ID
                    ,H.LVL02_CD
                    ,H.LVL02_NM
                    ,H.LVL03_ID
                    ,H.LVL03_CD
                    ,H.LVL03_NM
                    ,H.LVL04_ID
                    ,H.LVL04_CD
                    ,H.LVL04_NM
                    ,H.LVL05_ID
                    ,H.LVL05_CD
                    ,H.LVL05_NM
                    ,H.LVL06_ID
                    ,H.LVL06_CD
                    ,H.LVL06_NM
                    ,H.LVL07_ID
                    ,H.LVL07_CD
                    ,H.LVL07_NM
                    ,H.LVL08_ID
                    ,H.LVL08_CD
                    ,H.LVL08_NM
                    ,H.LVL09_ID
                    ,H.LVL09_CD
                    ,H.LVL09_NM
                    ,H.LVL10_ID
                    ,H.LVL10_CD
                    ,H.LVL10_NM
                    ,H.ITEM_ID
                    ,H.ITEM_CD
                    ,H.ITEM_NM
                    ,H.UOM
                    ,H.RTS
                    ,H.EOS
                    ,H.ITEM_TP
                    ,H.DESCRIP
                    ,H.ATTR_01
                    ,H.ATTR_02
                    ,H.ATTR_03
                    ,H.ATTR_04
                    ,H.ATTR_05
                    ,H.ATTR_06
                    ,H.ATTR_07
                    ,H.ATTR_08
                    ,H.ATTR_09
                    ,H.ATTR_10
                    ,H.ATTR_11
                    ,H.ATTR_12
                    ,H.ATTR_13
                    ,H.ATTR_14
                    ,H.ATTR_15
                    ,H.ATTR_16
                    ,H.ATTR_17
                    ,H.ATTR_18
                    ,H.ATTR_19
                    ,H.ATTR_20                    
                  , M.id          AS N_ITEM_ID
                    ,U.UOM_CD      AS N_UOM
                    ,M.RTS      AS N_RTS
                    ,M.EOS      AS N_EOS
                    ,T.ITEM_TP  AS N_ITEM_TP
                    ,M.DESCRIP  AS N_DESCRIP
                  , M.ATTR_01     AS  N_ATTR_01
                  , M.ATTR_02     AS  N_ATTR_02 
                  , M.ATTR_03     AS  N_ATTR_03
                  , M.ATTR_04     AS  N_ATTR_04
                  , M.ATTR_05     AS  N_ATTR_05
                  , M.ATTR_06     AS  N_ATTR_06
                  , M.ATTR_07     AS  N_ATTR_07 
                  , M.ATTR_08     AS  N_ATTR_08
                  , M.ATTR_09     AS  N_ATTR_09
                  , M.ATTR_10     AS  N_ATTR_10
                  , M.ATTR_11     AS  N_ATTR_11
                  , M.ATTR_12     AS  N_ATTR_12
                  , M.ATTR_13     AS  N_ATTR_13
                  , M.ATTR_14     AS  N_ATTR_14
                  , M.ATTR_15     AS  N_ATTR_15
                  , M.ATTR_16     AS  N_ATTR_16
                  , M.ATTR_17     AS  N_ATTR_17
                  , M.ATTR_18     AS  N_ATTR_18
                  , M.ATTR_19     AS  N_ATTR_19
                  , M.ATTR_20     AS  N_ATTR_20
			FROM TB_DPD_ITEM_HIERACHY2 H
                 INNER JOIN
                 TB_CM_ITEM_MST M 
               ON H.ITEM_ID = M.ID 
			 left outer join TB_CM_UOM u on u.ID = m.UOM_ID
			 left outer join TB_CM_ITEM_TYPE t on t.ID = m.ITEM_TP_ID
			 WHERE  DP_PLAN_YN ='Y' and (m.DEL_YN='N' or m.DEL_YN is null) 			
)
   set    UOM = N_UOM
         ,RTS = N_RTS 
         ,EOS = N_EOS
         ,ITEM_TP = N_ITEM_TP
         ,DESCRIP = N_DESCRIP,
        ATTR_01=N_ATTR_01,
        ATTR_02=N_ATTR_02,
        ATTR_03=N_ATTR_03,
        ATTR_04=N_ATTR_04,
        ATTR_05=N_ATTR_05,
        ATTR_06=N_ATTR_06,
        ATTR_07=N_ATTR_07,
        ATTR_08=N_ATTR_08,
        ATTR_09=N_ATTR_09,
        ATTR_10=N_ATTR_10,
        ATTR_11=N_ATTR_11,
        ATTR_12=N_ATTR_12,
        ATTR_13=N_ATTR_13,
        ATTR_14=N_ATTR_14,
        ATTR_15=N_ATTR_15,
        ATTR_16=N_ATTR_16,
        ATTR_17=N_ATTR_17,
        ATTR_18=N_ATTR_18,
        ATTR_19=N_ATTR_19,
        ATTR_20=N_ATTR_20
       ;

*/

END
;
/

