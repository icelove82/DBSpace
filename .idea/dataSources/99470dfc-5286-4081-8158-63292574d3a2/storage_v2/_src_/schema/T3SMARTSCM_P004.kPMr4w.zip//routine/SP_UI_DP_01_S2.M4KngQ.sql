create PROCEDURE                "SP_UI_DP_01_S2" (
    P_ID                IN VARCHAR2        
  , P_CONF_ID           IN VARCHAR2    
  , P_CONF_GRP_CD       IN VARCHAR2       := NULL
  , P_CONF_CD           IN VARCHAR2       := NULL
  , P_LANG_CONF_NM      IN VARCHAR2       := NULL
  , P_CONF_NM           IN VARCHAR2       := NULL
  , P_DEFAT_VAL         IN VARCHAR2       := NULL
  , P_ACTV_YN           IN VARCHAR2       := NULL
  , P_PRIORT            IN VARCHAR2       := NULL
  , P_USE_YN            IN VARCHAR2       := NULL
  , P_LANG_DESCRIP      IN VARCHAR2       := NULL
  , P_DESCRIP           IN VARCHAR2       := NULL
  , P_ATTR_01           IN VARCHAR2       := NULL
  , P_ATTR_02           IN VARCHAR2       := NULL
  , P_ATTR_03           IN VARCHAR2       := NULL
  , P_ATTR_04           IN VARCHAR2       := NULL 
  , P_ATTR_05           IN VARCHAR2       := NULL
  , P_ATTR_06           IN VARCHAR2       := NULL
  , P_ATTR_07           IN VARCHAR2       := NULL
  , P_ATTR_08           IN VARCHAR2       := NULL
  , P_ATTR_09           IN VARCHAR2       := NULL
  , P_ATTR_10           IN VARCHAR2       := NULL    
  , P_USER_ID           IN VARCHAR2     
  , P_RT_ROLLBACK_FLAG  OUT VARCHAR2     
  , P_RT_MSG            OUT VARCHAR2      
) IS 
    P_ERR_STATUS INT := 0;
    P_ERR_MSG VARCHAR2(4000):='';                               
    V_ORG_CONF_CD        VARCHAR2(50) := '';
    V_CONF_CNT        INT := 0;
    P_DOW INT;
    p_MIN_DATE DATE;
	p_MIN_CNT  INT;
BEGIN
/*****************************************************************************************************************************************************************
    -- History (date / writer / comment)
    -- 2021.02.05 / kim sohee / value type validation bug fix 
    -- 2021.04.29 / 김소희 / DP WK 계산방식 변경
****************************************************************************************************************************************************************/
    P_RT_ROLLBACK_FLAG := 'true';
/********** Validation ************************************************************************************************************************************************/                        
    IF(P_CONF_CD IS NULL OR P_CONF_GRP_CD IS NULL) THEN
        P_ERR_MSG := 'MSG_0006';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);              
    END IF; 

    SELECT COUNT(*) INTO P_ERR_STATUS
      FROM TB_CM_COMM_CONFIG
     WHERE 1=1
       AND CONF_CD = P_CONF_CD
       AND CONF_GRP_CD = P_CONF_GRP_CD
       AND ID != P_ID
    ;

    IF(P_ERR_STATUS > 0) THEN
        P_ERR_MSG := 'MSG_0005';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);               
    END IF;

    IF(P_CONF_GRP_CD = 'DP_STD_WEEK') THEN
        SELECT count(*) INTO P_ERR_STATUS
          FROM DUAL
         WHERE P_CONF_CD IN ('Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat')
        ;

        IF(P_ERR_STATUS = 0) THEN
            P_ERR_MSG := 'MSG_5109';
            RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
        END IF;

-- Calendar DP_WK calculation 2021.04.29
/*
SELECT  MIN(DAT) INTO p_MIN_DATE 
 FROM TB_CM_CALENDAR 
WHERE DOW_NM = UPPER(P_CONF_CD)
;	 
 SELECT COUNT(DAT) INTO p_MIN_CNT
   FROM TB_CM_CALENDAR
  WHERE DAT < p_MIN_DATE
 ;

 UPDATE TB_CM_CALENDAR
   SET DP_WK = 1
 WHERE DAT < p_MIN_DATE
 ;

 MERGE INTO TB_CM_CALENDAR TGT
   USING (
                SELECT DAT
                     , CASE WHEN p_MIN_CNT>0 THEN 2 ELSE 1 END + ROUND((ROW_NUMBER() OVER( ORDER BY DAT ASC)-1)/7,0)    AS DP_WK 
                 FROM TB_CM_CALENDAR          
                WHERE DAT >= p_MIN_DATE      
         ) SRC
ON (TGT.DAT = SRC.DAT)
WHEN MATCHED THEN
UPDATE SET TGT.DP_WK = SRC.DP_WK
  ;
  */
-- Calendar DP_WK calculation 2021.06.23
        P_DOW := CASE UPPER(P_CONF_CD) 
					WHEN 'SUN' THEN 1
					WHEN 'SAT' THEN 2
					WHEN 'FRI' THEN 3
					WHEN 'THU' THEN 3+10
					WHEN 'WED' THEN 2+10
					WHEN 'TUE' THEN 1+10
					ELSE 0	--'MON'
				END
				;

	IF (P_DOW = 0)
		THEN 
			-- MON
			INSERT INTO TEMP_ISO_CAL (YYYY, DP_WK, MM, DAT) 
			  SELECT YYYY, TO_CHAR(DAT,'IW'), MM, DAT 
			    FROM TB_CM_CALENDAR  
                ;
	ELSIF (P_DOW < 10)
		THEN
			-- LEAD ( SUN /SAT /FRI)
			INSERT INTO TEMP_ISO_CAL (YYYY, DP_WK, MM, DAT) 
			  SELECT YYYY, LEAD(TO_CHAR(DAT,'IW'), P_DOW) OVER (ORDER BY DAT ASC), MM, DAT 
			    FROM TB_CM_CALENDAR  
                ;
	ELSE 
			-- LAG (TUE /WED /THU)
			P_DOW := P_DOW-10;
			INSERT INTO TEMP_ISO_CAL (YYYY, DP_WK, MM, DAT) 
			  SELECT YYYY, LAG(TO_CHAR(DAT,'IW'), P_DOW) OVER (ORDER BY DAT ASC), MM, DAT 
			    FROM TB_CM_CALENDAR  
				;			
		END IF
		;
	-- DP_WK : year + ISO week	 
	-- Set last year : first week of year 
	-- Set next year : last week of year 

        MERGE INTO TB_CM_CALENDAR 
          USING (
                SELECT CAST (CAST(YYYY AS INT) + ( CASE WHEN MM = 1 AND DP_WK IN ('52', '53') THEN -1
                              WHEN MM = 12 AND DP_WK = '01' THEN 1
                              ELSE 0 
                         END ) AS CHAR(4)) AS YYYY
                     , DP_WK
                     , DAT 
                  FROM TEMP_ISO_CAL          
                ) M
          ON ( TB_CM_CALENDAR.DAT = M.DAT )
        WHEN MATCHED THEN 
		UPDATE 
		   SET DP_WK = M.YYYY || LPAD(M.DP_WK , 2, '0') 
		   ;			

	DELETE FROM TEMP_ISO_CAL;

/*
        UPDATE TB_AD_USER_PREF_OPT
           SET OPT_VALUE = 'BASE.' || (UPPER(P_CONF_CD))
         WHERE EXISTS (
               SELECT *
                 FROM TB_AD_USER_PREF_MST m 
                WHERE m.ID = USER_PREF_MST_ID
                  AND SUBSTR(m.VIEW_CD, 1, 5) = 'UI_DP'
                  AND OPT_TP = 'type'
        );
*/        
        UPDATE TB_AD_USER_PREF_OPT
           SET OPT_VALUE = 'BASE.' || (UPPER(P_CONF_CD))
         WHERE EXISTS (
               SELECT *
                 FROM TB_AD_USER_PREF_MST m 
                WHERE m.ID = USER_PREF_MST_ID
                  AND SUBSTR(m.VIEW_CD, 1, 5) = 'UI_DP'
                  AND OPT_TP = 'type'
        );
    END IF;
/******** Main Procedure ***********************************************************************************************************************************************/                        
    SELECT COUNT(CONF_CD)INTO V_CONF_CNT
      FROM TB_CM_COMM_CONFIG 
     WHERE 1=1
       AND ID = P_ID;

    IF (V_CONF_CNT != 0) THEN

        SELECT CONF_CD INTO V_ORG_CONF_CD
          FROM TB_CM_COMM_CONFIG
         WHERE 1=1
           AND ID = P_ID;

        IF(P_CONF_CD != V_ORG_CONF_CD) THEN
    		SELECT COUNT(*) INTO P_ERR_STATUS
    		  FROM TB_AD_LANG_PACK
    		 WHERE LANG_KEY = 'CF_'||UPPER(P_CONF_GRP_CD)||'_'||UPPER(P_CONF_CD);

            IF(P_ERR_STATUS >0) THEN
                DELETE FROM TB_AD_LANG_PACK 
                 WHERE LANG_KEY = 'CF_' || UPPER(P_CONF_GRP_CD) || '_' || UPPER(V_ORG_CONF_CD);
				DELETE FROM TB_AD_LANG_PACK 
                 WHERE LANG_KEY = 'CF_' || UPPER(P_CONF_GRP_CD) || '_' || UPPER(V_ORG_CONF_CD) || '_DESCRIP';
            ELSE
                UPDATE TB_AD_LANG_PACK
                   SET LANG_KEY = 'CF_' || UPPER(P_CONF_GRP_CD) || '_' || UPPER(P_CONF_CD)
                 WHERE LANG_KEY = 'CF_' || UPPER(P_CONF_GRP_CD) || '_' || UPPER(V_ORG_CONF_CD)
                ;
                UPDATE TB_AD_LANG_PACK
                   SET LANG_KEY = 'CF_' || UPPER(P_CONF_GRP_CD) || '_' || UPPER(P_CONF_CD) || '_DESCRIP'
                 WHERE LANG_KEY = 'CF_' || UPPER(P_CONF_GRP_CD) || '_' || UPPER(V_ORG_CONF_CD) || '_DESCRIP'
                ;

            END IF;
        END IF;
    END IF;

    MERGE INTO TB_CM_COMM_CONFIG TGT        
    USING (SELECT
                 P_ID                    AS ID            
                ,P_CONF_ID               AS CONF_ID        
                ,P_CONF_GRP_CD           AS CONF_GRP_CD    
                ,P_CONF_CD               AS CONF_CD        
                ,'CF_'||UPPER(P_CONF_GRP_CD)
                 ||'_'||UPPER(P_CONF_CD) AS CONF_NM
                ,P_DEFAT_VAL             AS DEFAT_VAL    
                ,P_ACTV_YN               AS ACTV_YN        
                ,TO_NUMBER(P_PRIORT)     AS PRIORT        
                ,P_USE_YN                AS USE_YN    
                ,'CF_'||UPPER(P_CONF_GRP_CD)
                 ||'_'||UPPER(P_CONF_CD)
                 ||'_DESCRIP'            AS DESCRIP
                ,P_ATTR_01               AS ATTR_01        
                ,P_ATTR_02               AS ATTR_02        
                ,P_ATTR_03               AS ATTR_03        
                ,P_ATTR_04               AS ATTR_04        
                ,P_ATTR_05               AS ATTR_05        
                ,P_ATTR_06               AS ATTR_06        
                ,P_ATTR_07               AS ATTR_07        
                ,P_ATTR_08               AS ATTR_08        
                ,P_ATTR_09               AS ATTR_09        
                ,P_ATTR_10               AS ATTR_10        
                ,P_USER_ID               AS USER_ID
            FROM dual
          ) SRC
     ON (TGT.ID = SRC.ID)
     WHEN MATCHED THEN
         UPDATE SET      
             TGT.CONF_CD     = SRC.CONF_CD                
            ,TGT.CONF_NM     = SRC.CONF_NM            
            ,TGT.DEFAT_VAL   = SRC.DEFAT_VAL    
            ,TGT.ACTV_YN     = SRC.ACTV_YN            
            ,TGT.PRIORT      = SRC.PRIORT        
            ,TGT.USE_YN      = SRC.USE_YN        
            ,TGT.DESCRIP     = SRC.DESCRIP            
            ,TGT.ATTR_01     = SRC.ATTR_01            
            ,TGT.ATTR_02     = SRC.ATTR_02            
            ,TGT.ATTR_03     = SRC.ATTR_03            
            ,TGT.ATTR_04     = SRC.ATTR_04            
            ,TGT.ATTR_05     = SRC.ATTR_05            
            ,TGT.ATTR_06     = SRC.ATTR_06            
            ,TGT.ATTR_07     = SRC.ATTR_07            
            ,TGT.ATTR_08     = SRC.ATTR_08            
            ,TGT.ATTR_09     = SRC.ATTR_09            
            ,TGT.ATTR_10     = SRC.ATTR_10            
            ,TGT.MODIFY_BY   = SRC.USER_ID
            ,TGT.MODIFY_DTTM = SYSDATE                             
    WHEN NOT MATCHED THEN
        INSERT (
             ID            
            ,CONF_ID        
            ,CONF_GRP_CD    
            ,CONF_CD        
            ,CONF_NM        
            ,DEFAT_VAL        
            ,ACTV_YN        
            ,PRIORT            
            ,USE_YN        
            ,DESCRIP        
            ,ATTR_01        
            ,ATTR_02        
            ,ATTR_03        
            ,ATTR_04        
            ,ATTR_05        
            ,ATTR_06        
            ,ATTR_07        
            ,ATTR_08        
            ,ATTR_09        
            ,ATTR_10        
            ,CREATE_BY        
            ,CREATE_DTTM    
            ,MODIFY_BY        
            ,MODIFY_DTTM    
        )
        VALUES (
             TO_SINGLE_BYTE(SYS_GUID())             
            ,SRC.CONF_ID            
            ,SRC.CONF_GRP_CD        
            ,SRC.CONF_CD            
            ,SRC.CONF_NM            
            ,SRC.DEFAT_VAL        
            ,SRC.ACTV_YN            
            ,SRC.PRIORT          
            ,SRC.USE_YN            
            ,SRC.DESCRIP    
            ,SRC.ATTR_01    
            ,SRC.ATTR_02    
            ,SRC.ATTR_03    
            ,SRC.ATTR_04    
            ,SRC.ATTR_05    
            ,SRC.ATTR_06    
            ,SRC.ATTR_07    
            ,SRC.ATTR_08    
            ,SRC.ATTR_09    
            ,SRC.ATTR_10    
            ,SRC.USER_ID    
            ,SYSDATE
            ,NULL
            ,NULL                     
        )
    ;    

	IF(P_CONF_GRP_CD = 'DP_MS_VAL_TP')
	THEN
        SELECT COUNT(CNT)  INTO P_ERR_STATUS
          FROM (
        SELECT COUNT(CONF_CD) AS CNT
          FROM TB_CM_COMM_CONFIG 
         WHERE CONF_GRP_CD = 'DP_MS_VAL_TP'
           AND ACTV_YN = 'Y'
           AND USE_YN = 'Y'
           AND REPLACE(CONF_CD,'QTY','AMT') IN ( SELECT CONF_CD 
                                                   FROM TB_CM_COMM_CONFIG 
                                                  WHERE CONF_GRP_CD = 'DP_MS_VAL_TP'
                                                    AND CONF_CD LIKE 'AMT%'
                                                    AND ACTV_YN = 'Y' 
                                                    AND USE_YN = 'Y'
                                               )
         GROUP BY REPLACE(CONF_CD,'QTY','AMT')    
            ) A           
        ;

		IF P_ERR_STATUS = 1 THEN
			P_ERR_MSG := 'A pair of quantity codes must also be activated.';
			RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);       	
		END IF;
	END IF;
/********************************************************************
	-- Measure Setting Data Handling
*********************************************************************/
    IF (COALESCE(P_ACTV_YN, 'N') = 'N' OR COALESCE(P_USE_YN, 'N') = 'N') AND P_CONF_GRP_CD = 'DP_MS_VAL_TP'
    THEN
        DELETE 
          FROM TB_DP_MEASURE_SETTING
         WHERE MEASURE_VAL_TP_ID = ( SELECT ID 
									   FROM TB_CM_COMM_CONFIG 
									  WHERE CONF_CD = P_CONF_CD 
									    AND CONF_GRP_CD = 'DP_MS_VAL_TP'
								   )
        ;
	END IF;
/********************************************************************
	-- LANG PACK
*********************************************************************/    
    -- 3) TB_AD_LANG_PACK INSERT
        -- (1) CONF_CD
        MERGE INTO TB_AD_LANG_PACK TGT        
        USING ( SELECT 'CF_'||UPPER(P_CONF_GRP_CD)||'_'||UPPER(P_CONF_CD)    AS LANG_KEY
                     , P_CONF_NM                                             AS LANG_VALUE
                     , 'en'                                                  AS LANG_CD -- Config Langpack default locale : en
                  FROM DUAL
              ) SRC
           ON (TGT.LANG_KEY = SRC.LANG_KEY AND TGT.LANG_CD = SRC.LANG_CD)
         WHEN NOT MATCHED THEN
            INSERT (
                LANG_CD
              , LANG_KEY
              , LANG_VALUE    
            )
            VALUES(                
                SRC.LANG_CD
              , SRC.LANG_KEY
              , SRC.LANG_VALUE     
            )
        ;
        -- (2) DESCRIP
        MERGE INTO TB_AD_LANG_PACK TGT        
        USING ( SELECT 'CF_'||UPPER(P_CONF_GRP_CD)||'_'||UPPER(P_CONF_CD)||'_DESCRIP'    AS LANG_KEY
                     , NVL(P_DESCRIP,' ')                                                AS LANG_VALUE
                     , 'en'                                                              AS LANG_CD
                  FROM DUAL
              ) SRC
           ON (TGT.LANG_KEY = SRC.LANG_KEY AND TGT.LANG_CD = SRC.LANG_CD)
         WHEN NOT MATCHED THEN
            INSERT (
                LANG_CD
              , LANG_KEY
              , LANG_VALUE    
            )
            VALUES(                
                SRC.LANG_CD
              , SRC.LANG_KEY
              , SRC.LANG_VALUE     
            )
        ;

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';

EXCEPTION WHEN OTHERS THEN
    IF(SQLCODE = -20001)
    THEN
        P_ERR_MSG := SQLERRM;
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
--    SP_COMM_RAISE_ERR();              
       RAISE;
    END IF;
END;
/

