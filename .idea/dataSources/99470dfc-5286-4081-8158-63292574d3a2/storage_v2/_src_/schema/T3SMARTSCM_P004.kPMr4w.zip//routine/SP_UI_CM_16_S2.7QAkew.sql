create PROCEDURE SP_UI_CM_16_S2 (
     P_ID							IN VARCHAR2 :=''
    ,P_PLAN_SNRIO_MGMT_MST_ID       IN CHAR :=''  
    ,P_STEP							IN NUMBER := NULL
    ,P_PROCESS_DESCRIP				IN VARCHAR2 := NULL
    ,P_PROCESS_TP_ID				IN CHAR := NULL
    ,P_CONFRM_MTD_ID				IN CHAR := NULL
    ,P_LOWR_DMND_CREATE_YN			IN VARCHAR2 :=NULL
    ,P_UI_ID_01						IN VARCHAR2 := NULL
    ,P_UI_ID_02						IN VARCHAR2 := NULL	
    ,P_UI_ID_03						IN VARCHAR2 := NULL
    ,P_UI_ID_04						IN VARCHAR2 := NULL
    ,P_UI_ID_05						IN VARCHAR2 := NULL
    ,P_PROC							IN VARCHAR2 := NULL
    ,P_CNFRM_PLAN_SNR_MGMT_DTL_ID	IN CHAR :=NULL
    ,P_PLAN_POLICY_MGMT_ID			IN CHAR := NULL
    ,P_ACTV_YN						IN VARCHAR2 := NULL
    ,P_MODULE_ID				    IN VARCHAR2 := NULL
    ,P_USER_ID						IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG				OUT VARCHAR2
    ,P_RT_MSG						OUT VARCHAR2
)
IS
    P_SET_ID CHAR(32) :='';
    P_TEMP_STEP CHAR(10) :='';
    P_PP_NAME VARCHAR2(30) :='';
    P_MODULE_NM VARCHAR2(30) :='';
    P_IM_SNRIO_PLAN_TP_NM VARCHAR2(30) :='';
    P_UI_ID_01_TEMP VARCHAR2(100) := P_UI_ID_01;
    P_UI_ID_02_TEMP VARCHAR2(100) := P_UI_ID_02;
    P_UI_ID_03_TEMP VARCHAR2(100) := P_UI_ID_03;
    P_UI_ID_04_TEMP VARCHAR2(100) := P_UI_ID_04;
    P_UI_ID_05_TEMP VARCHAR2(100) := P_UI_ID_05;
    P_ERR_STATUS INT := 0;
    P_ERR_MSG VARCHAR2(4000) := '';

BEGIN
    P_RT_ROLLBACK_FLAG := 'true';
    
    IF P_ID IS NULL
    THEN
       P_ERR_MSG := 'MSG_0005';
       
       SELECT COUNT(*) INTO P_ERR_STATUS
         FROM TB_CM_PLAN_SNRIO_MGMT_MST A
              INNER JOIN 
              TB_CM_PLAN_SNRIO_MGMT_DTL B 
           ON (A.ID = B.PLAN_SNRIO_MGMT_MST_ID)
        WHERE 1=1
          AND B.STEP = P_STEP
          AND A.MODULE_ID = P_MODULE_ID
          AND A.ID = P_PLAN_SNRIO_MGMT_MST_ID;
          
       IF P_ERR_STATUS > 0 THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
       END IF;
    END IF;

    IF LENGTH(LTRIM(RTRIM(P_UI_ID_01))) !=32	THEN	SELECT UI_ID INTO P_UI_ID_01_TEMP FROM UI_MGMT WHERE UI_NM = P_UI_ID_01_TEMP; END IF;
    IF LENGTH(LTRIM(RTRIM(P_UI_ID_02))) !=32	THEN	SELECT UI_ID INTO P_UI_ID_02_TEMP FROM UI_MGMT WHERE UI_NM = P_UI_ID_02_TEMP; END IF;
    IF LENGTH(LTRIM(RTRIM(P_UI_ID_03))) !=32	THEN	SELECT UI_ID INTO P_UI_ID_03_TEMP FROM UI_MGMT WHERE UI_NM = P_UI_ID_03_TEMP; END IF;
    IF LENGTH(LTRIM(RTRIM(P_UI_ID_04))) !=32	THEN	SELECT UI_ID INTO P_UI_ID_04_TEMP FROM UI_MGMT WHERE UI_NM = P_UI_ID_04_TEMP; END IF;
    IF LENGTH(LTRIM(RTRIM(P_UI_ID_05))) !=32	THEN	SELECT UI_ID INTO P_UI_ID_05_TEMP FROM UI_MGMT WHERE UI_NM = P_UI_ID_05_TEMP; END IF;

    P_SET_ID := TO_SINGLE_BYTE(SYS_GUID());

    SELECT  B.COMN_CD  INTO P_MODULE_NM
      FROM  TB_CM_PLAN_SNRIO_MGMT_MST A
            INNER JOIN TB_AD_COMN_CODE B
            ON A.MODULE_ID = B.ID
     WHERE 1=1
       AND A.ID = P_PLAN_SNRIO_MGMT_MST_ID;

	  MERGE INTO TB_CM_PLAN_SNRIO_MGMT_DTL A
	  USING (
             SELECT  P_ID                           AS ID
       	            ,P_SET_ID  						AS SET_ID  
                    ,P_PLAN_SNRIO_MGMT_MST_ID		AS PLAN_SNRIO_MGMT_MST_ID
                    ,P_STEP							AS STEP
                    ,P_PROCESS_DESCRIP				AS PROCESS_DESCRIP
                    ,P_PROCESS_TP_ID				AS PROCESS_TP_ID
                    ,P_CONFRM_MTD_ID				AS CONFRM_MTD_ID
                    ,P_LOWR_DMND_CREATE_YN		    AS LOWR_DMND_CREATE_YN
                    ,P_UI_ID_01_TEMP				AS UI_ID_01
                    ,P_UI_ID_02_TEMP				AS UI_ID_02
                    ,P_UI_ID_03_TEMP				AS UI_ID_03
                    ,P_UI_ID_04_TEMP				AS UI_ID_04
                    ,P_UI_ID_05_TEMP				AS UI_ID_05
                    ,P_PROC							AS PROC_NM
                    ,P_CNFRM_PLAN_SNR_MGMT_DTL_ID	AS CONFRM_PLAN_SNRIO_MGMT_DTL_ID
                    ,P_PLAN_POLICY_MGMT_ID			AS PLAN_POLICY_MGMT_ID
                    ,P_ACTV_YN						AS ACTV_YN
             	     ,P_USER_ID						AS CREATE_BY
             	     ,SYSDATE                       AS CREATE_DTTM           
             	     ,P_USER_ID                     AS MODIFY_BY
             	     ,SYSDATE                       AS MODIFY_DTTM
                     FROM DUAL
	        ) B
	  ON (A.ID = B.ID)
	  WHEN MATCHED THEN 
	  UPDATE 
	     SET  A.PLAN_SNRIO_MGMT_MST_ID			= B.PLAN_SNRIO_MGMT_MST_ID			
             ,A.STEP							= B.STEP							
             ,A.PROCESS_DESCRIP					= B.PROCESS_DESCRIP					
             ,A.PROCESS_TP_ID					= B.PROCESS_TP_ID					
             ,A.CONFRM_MTD_ID					= B.CONFRM_MTD_ID					
             ,A.LOWR_DMND_CREATE_YN				= B.LOWR_DMND_CREATE_YN				
             ,A.UI_ID_01						= B.UI_ID_01							
             ,A.UI_ID_02						= B.UI_ID_02
             ,A.UI_ID_03						= B.UI_ID_03
             ,A.UI_ID_04						= B.UI_ID_04
             ,A.UI_ID_05						= B.UI_ID_05
             ,A."PROC"							= B.PROC_NM							
             ,A.CONFRM_PLAN_SNRIO_MGMT_DTL_ID	= B.CONFRM_PLAN_SNRIO_MGMT_DTL_ID	
             ,A.PLAN_POLICY_MGMT_ID				= B.PLAN_POLICY_MGMT_ID	
             ,A.ACTV_YN				            = B.ACTV_YN	
	  WHEN NOT MATCHED THEN 
	  INSERT   						
      (
	    ID
       ,PLAN_SNRIO_MGMT_MST_ID
       ,STEP
       ,PROCESS_DESCRIP
       ,PROCESS_TP_ID
       ,CONFRM_MTD_ID
       ,LOWR_DMND_CREATE_YN
       ,UI_ID_01
       ,UI_ID_02
       ,UI_ID_03
       ,UI_ID_04
       ,UI_ID_05
       ,"PROC"
       ,CONFRM_PLAN_SNRIO_MGMT_DTL_ID
       ,PLAN_POLICY_MGMT_ID
       ,ACTV_YN
       ,CREATE_BY
       ,CREATE_DTTM
       ,MODIFY_BY
       ,MODIFY_DTTM
      )
	  VALUES
	  (
        B.SET_ID
	   ,B.PLAN_SNRIO_MGMT_MST_ID			
       ,B.STEP							
       ,B.PROCESS_DESCRIP					
       ,B.PROCESS_TP_ID					
       ,B.CONFRM_MTD_ID					
       ,B.LOWR_DMND_CREATE_YN				
       ,B.UI_ID_01							
       ,B.UI_ID_02							
       ,B.UI_ID_03							
       ,B.UI_ID_04							
       ,B.UI_ID_05							
       ,B.PROC_NM							
       ,B.CONFRM_PLAN_SNRIO_MGMT_DTL_ID	
       ,B.PLAN_POLICY_MGMT_ID
	   ,B.ACTV_YN		  
       ,B.CREATE_BY
       ,B.CREATE_DTTM       
       ,B.MODIFY_BY
       ,B.MODIFY_DTTM	
	  );

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';
    
EXCEPTION
    WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;   
      ELSE
        RAISE;
      END IF;

END;

/

