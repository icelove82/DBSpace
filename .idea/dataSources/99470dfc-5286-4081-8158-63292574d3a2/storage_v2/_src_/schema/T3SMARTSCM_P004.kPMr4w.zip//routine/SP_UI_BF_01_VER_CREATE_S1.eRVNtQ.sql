create PROCEDURE        "SP_UI_BF_01_VER_CREATE_S1" (
                      P_VER_CD               VARCHAR2	:= ''
                    , P_ENGINE_TYPE_CD       VARCHAR2	:= ''
                    , P_INPUT_HORIZON        VARCHAR2	:= ''
                    , P_TARGET_HORIZON       VARCHAR2	:= ''
                    , P_INPUT_BUCKET         VARCHAR2	:= ''
                    , P_TARGET_BUCKET        VARCHAR2	:= ''
                    , P_INPUT_FROM_DATE      DATE
                    , P_TARGET_FROM_DATE     DATE
                    , P_INPUT_TO_DATE        DATE
                    , P_TARGET_TO_DATE       DATE
                    , P_BF_DIST_RULE         VARCHAR2	:= ''
                    , P_DESCRIP              VARCHAR2	:= ''
                    , P_USER_ID              VARCHAR2	:= ''
                    , P_RT_ROLLBACK_FLAG     out VARCHAR2
                    , P_RT_MSG               out VARCHAR2
) 
IS
		P_ERR_STATUS INT := 0;
        P_ERR_MSG VARCHAR2(4000):='';
        V_VER_MST_ID VARCHAR2(32) :='';
BEGIN 

INSERT INTO TB_BF_CONTROL_BOARD_VER_MST
           (VER_CD
		  , ENGINE_TYPE_CD
		  , INPUT_HORIZON
		  , TARGET_HORIZON
		  , INPUT_BUCKET
		  , TARGET_BUCKET
		  , INPUT_FROM_DATE
		  , TARGET_FROM_DATE
		  , INPUT_TO_DATE
		  , TARGET_TO_DATE
		  , BF_DIST_RULE
		  , DESCRIP
          , CREATE_BY
          , CREATE_DTTM
		  , STATUS
           )
     VALUES(
			  P_VER_CD
			, P_ENGINE_TYPE_CD
			, P_INPUT_HORIZON
			, P_TARGET_HORIZON
			, P_INPUT_BUCKET
			, P_TARGET_BUCKET
			, P_INPUT_FROM_DATE
			, P_TARGET_FROM_DATE
               , ADD_MONTHS(P_INPUT_TO_DATE,1)-1
               , ADD_MONTHS(P_TARGET_TO_DATE,1)-1
			, P_BF_DIST_RULE
			, P_DESCRIP
			, P_USER_ID
			, SYSDATE
			, 'READY'
           );

	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';

       EXCEPTION
        WHEN OTHERS THEN  -- 
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF; 

END;

/

