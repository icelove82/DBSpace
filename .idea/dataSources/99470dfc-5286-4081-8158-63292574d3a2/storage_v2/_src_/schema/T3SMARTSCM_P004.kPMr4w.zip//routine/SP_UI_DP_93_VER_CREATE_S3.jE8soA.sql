create PROCEDURE                 "SP_UI_DP_93_VER_CREATE_S3" (
 P_VER_CD                   VARCHAR2 
,P_PLAN_TP_ID               CHAR 
,pRESULT        OUT SYS_REFCURSOR
)
IS 
P_VER_ID               CHAR(32);
P_FROM_DATE        DATE ;
P_TO_DATE            DATE ;
P_Y_BUKT         VARCHAR2(50);
P_Y_FROM_DATE    DATE ;
P_Y_TO_DATE      DATE ;
P_Y_PLAN_TP_ID   CHAR(32);
P_SM_DATE            DATE ;        
P_ORA_STR        VARCHAR2(4000);           
-- For Loop 
P_STR             VARCHAR2(4000); 
p_SELECT_STR    NVARCHAR2(4000);
P_VAL_CNT       INT ;
P_BASE_YM       VARCHAR2(8);
P_PREV_VER_ID   VARCHAR2(32);
BEGIN 
/***********************************************************************************************************
    -- History ( date / writer / comment )
    -- 2021.05.03 / kimsohee/ SK Inovation custom : One version data Seperate Monthly & Yealy plan
    -- 2021.06.25 / 源��슜�닔 / TB_DP_ENTRY_Y �뀒�씠釉� �엯�젰 �닔�젙, 寃쎌쁺怨꾪쉷 �닔由쎌떆 怨꾪쉷�뿰�룄 1�뀈 �뒛�뼱�궇 �븣 �씠�쟾 媛� 蹂듭궗 濡쒖쭅 異붽�
    -- 2021.10.21 / 諛뺤삦二� / TB_DP_ENTRY_Y �깮�꽦 �떆 踰꾩폆�뿉 留욊쾶 �깮�꽦�씠 �릺吏� �븡�뒗 �삤瑜섍� 諛쒖깮�븯�뿬 泥섎━
************************************************************************************************************/
    -- Make Function : #VER_INFO_DTL => TABLE(FN_DP_TEMP_VER_INFO_DTL (P_VER_ID)) , #VER_INFO_INIT => TABLE(FN_DP_TEMP_VER_INFO_INIT (P_VER_ID)), #IAC => TABLE(FN_DP_TEMP_ITEM_ACCT_ROLE_DATE (P_VER_ID))
    -- Mkae Temp table : #PR => FN_DP_TEMP_PR_VER , #RT => TEMP_DP_RT
/************************************************************************************************************
    -- Get Version Config
************************************************************************************************************/
     SELECT   ID 
            , FROM_DATE        
            , VER_S_HORIZON_DATE2 - 1/24
            , VER_S_HORIZON_DATE2
            , TO_DATE
            , VER_S_BUCKET2
            , BASE_YM
        INTO  P_VER_ID      
            , P_FROM_DATE   
            , P_TO_DATE     
            , P_Y_FROM_DATE
            , P_Y_TO_DATE
            , P_Y_BUKT
            , P_BASE_YM
       FROM TB_DP_CONTROL_BOARD_VER_MST 
      WHERE VER_ID = P_VER_CD 
       ;


    --------------- 1. Get Versison Detail Info (Initial value type by authority type)


    SELECT ID INTO P_Y_PLAN_TP_ID
      FROM TB_CM_COMM_CONFIG
     WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' 
       AND ATTR_01 = 'Y'
--       AND ACTV_YN = 'Y'
       ;

/**************************************************************************************************************************************
    -- Close �븯吏� �븡�� �씠�쟾 踰꾩쟾 �젙由�
*************************************************************************************************************************************/
/*
    DELETE FROM TB_DP_ENTRY
    WHERE VER_ID 
      IN (SELECT CONBD_VER_MST_ID
      FROM TB_DP_CONTROL_BOARD_VER_DTL D
     WHERE D.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_cD = 'DP_WK_TP' AND CONF_CD = 'CL')
      AND D.CL_STATUS_ID != (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
      AND PLAN_TP_ID = P_PLAN_TP_ID
      AND CONBD_VER_MST_ID != P_VER_ID)
    ;  
    DELETE FROM TB_DP_CONTROL_BOARD_VER_DTL
    WHERE CONBD_VER_MST_ID IN (
    SELECT CONBD_VER_MST_ID
      FROM TB_DP_CONTROL_BOARD_VER_DTL D
     WHERE D.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_cD = 'DP_WK_TP' AND CONF_CD = 'CL')
      AND D.CL_STATUS_ID != (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
      AND PLAN_TP_ID = P_PLAN_TP_ID
      AND CONBD_VER_MST_ID != P_VER_ID
      )
    ; 
    DELETE FROM TB_DP_CONTROL_BOARD_VER_MST
    WHERE ID IN (
    SELECT CONBD_VER_MST_ID
      FROM TB_DP_CONTROL_BOARD_VER_DTL D
     WHERE D.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_cD = 'DP_WK_TP' AND CONF_CD = 'CL')
      AND D.CL_STATUS_ID != (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
      AND PLAN_TP_ID = P_PLAN_TP_ID
      AND CONBD_VER_MST_ID != P_VER_ID
      )
    ;
*/
/************************************************************************************************************
    -- Initial Value
************************************************************************************************************/
    SP_UI_DP_93_VER_CREATE_S3_01 (P_VER_ID, P_PLAN_TP_ID, pRESULT);   
    SP_UI_DP_93_VER_CREATE_S3_02 (P_VER_ID, P_FROM_DATE, P_TO_DATE, NULL, pRESULT);  --P_PLAN_TP_ID, 


--    OPEN pRESULT     FOR     SELECT * FROM TEMP_DP_RT;

     SELECT TO_DATE(CASE WHEN EXTRACT(MONTH FROM SYSDATE)>=PP.POLICY_VAL 
                    THEN TO_CHAR(EXTRACT(YEAR FROM SYSDATE))
                    ELSE TO_CHAR(EXTRACT(YEAR FROM SYSDATE)-1) 
             END ||'-'||PP.POLICY_VAL||'-01')
             INTO P_SM_DATE 
       FROM TB_DP_PLAN_POLICY  PP
            INNER JOIN 
            TB_CM_COMM_CONFIG CC
         ON PP.POLICY_ID = CC.ID 
      WHERE PLAN_TP_ID = P_PLAN_TP_ID
        AND CC.CONF_CD = 'SM'
        ;
/************************************************************************************************************
    -- Result : Monthly Plan    
************************************************************************************************************/
INSERT INTO TB_DP_ENTRY
         (    ID
            , VER_ID
            , AUTH_TP_ID
--          , EMP_ID
            , ITEM_MST_ID
            , ACCOUNT_ID
--          , SALES_LV_ID
            , BASE_DATE
            , QTY
            , AMT
            , CREATE_BY
            , CREATE_DTTM
            , PLAN_TP_ID
            , QTY_1
            , AMT_1
            , QTY_2
            , AMT_2
            , QTY_3
            , AMT_3      
            , QTY_A
            , AMT_A 
         )
    WITH UNIT_PRICE
    AS (
        SELECT  ITEM_MST_ID
               ,ACCOUNT_ID
               ,BASE_DATE   AS STRT_DATE 
               ,coalesce(-1+LEAD(BASE_DATE) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID ORDER BY  BASE_DATE ), P_TO_DATE)    AS END_DATE  
               ,UTPIC
          FROM TB_DP_UNIT_PRICE UP
               INNER JOIN
               TABLE(FN_DP_TEMP_VER_INFO_DTL (P_VER_ID)) VD
            ON UP.PRICE_TP_ID = VD.PRICE_TP_ID 
           AND UP.BASE_DATE <= P_TO_DATE  
    ), ENTRY_HIS
    AS (   SELECT  SUM(QTY)         AS QTY
                 , SUM(AMT)         AS AMT
                 , ITEM_MST_ID
                 , ACCOUNT_ID
              FROM TB_DP_ENTRY_HISTORY 
             WHERE BASE_dATE BETWEEN P_SM_DATE AND (P_FROM_DATE-1)
        GROUP BY ITEM_MST_ID, ACCOUNT_ID
    )

         SELECT TO_SINGLE_BYTE(SYS_GUID())                  AS ID
              , P_VER_ID                                        AS VER_ID 
              , MN.ROLE_ID 
              , MN.ITEM_ID  
              , MN.ACCT_ID  
              , MN.BASE_DATE 
              , coalesce(RT.QTY , 0)                        AS QTY 
              , NULL                                        AS AMT
              , 'system'
              , SYSDATE
              , P_PLAN_TP_ID 
              , RT.QTY_1-- coalesce(RT.QTY_1,0)
              , NULL  
              , RT.QTY_2 -- coalesce(RT.QTY_2,0)
              , NULL 
              , RT.QTY_3-- coalesce(RT.QTY_3,0)
              , NULL 
              , EH.QTY
              , EH.AMT 
           FROM TABLE(FN_DP_TEMP_ITEM_ACCT_ROLE_DATE (P_VER_ID, P_PLAN_TP_ID)) MN
--              INNER JOIN
--              UNIT_PRICE UP
--           ON IA.ITEM_ID = UP.ITEM_MST_ID 
--          AND IA.ACCT_ID = UP.ACCOUNT_ID
--          AND CAL.STRT_DT BETWEEN UP.STRT_DATE AND UP.END_DATE
                LEFT OUTER JOIN 
                TEMP_DP_RT      RT 
             ON MN.ITEM_ID = RT.ITEM_MST_ID 
            AND MN.ACCT_ID = RT.ACCOUNT_ID 
            AND RT.BASE_DATE = MN.BASE_DATE  
            AND RT.AUTH_TP_ID = MN.ROLE_ID  
                LEFT OUTER JOIN
                ENTRY_HIS EH 
            ON  MN.ITEM_ID = EH.ITEM_MST_ID
           AND  MN.ACCT_ID = EH.ACCOUNT_ID
           ;                
/************************************************************************************************************
    -- Result : Yearly Plan (custom)
************************************************************************************************************/
    DELETE FROM TEMP_DP_RT;

    SP_UI_DP_93_VER_CREATE_S3_01 (P_VER_ID, P_Y_PLAN_TP_ID, pRESULT);  
    SP_UI_DP_93_VER_CREATE_S3_02 (P_VER_ID, P_Y_FROM_DATE, P_Y_TO_DATE, P_Y_BUKT, pRESULT);  --P_PLAN_TP_ID, 


INSERT INTO TB_DP_ENTRY_Y
         (    ID
            , VER_ID
            , AUTH_TP_ID
--          , EMP_ID
            , ITEM_MST_ID
            , ACCOUNT_ID
--          , SALES_LV_ID
            , BASE_DATE
            , QTY
            , AMT
            , CREATE_BY
            , CREATE_DTTM
            , PLAN_TP_ID
            , QTY_1
            , AMT_1
            , QTY_2
            , AMT_2
            , QTY_3
            , AMT_3      
            , QTY_A
            , AMT_A 
         )
    WITH UNIT_PRICE
    AS (
        SELECT  ITEM_MST_ID
               ,ACCOUNT_ID
               ,BASE_DATE   AS STRT_DATE 
               ,coalesce(-1+LEAD(BASE_DATE) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID ORDER BY  BASE_DATE ), P_Y_TO_DATE)  AS END_DATE  
               ,UTPIC
          FROM TB_DP_UNIT_PRICE UP
               INNER JOIN
               TABLE(FN_DP_TEMP_VER_INFO_DTL (P_VER_ID)) VD
            ON UP.PRICE_TP_ID = VD.PRICE_TP_ID 
           AND UP.BASE_DATE <= P_Y_TO_DATE  
    ), ENTRY_HIS
    AS (   SELECT  SUM(QTY)         AS QTY
                 , SUM(AMT)         AS AMT
                 , ITEM_MST_ID
                 , ACCOUNT_ID
              FROM TB_DP_ENTRY_HISTORY 
             WHERE BASE_dATE BETWEEN P_SM_DATE AND (P_TO_DATE) -- => P_Y_FROM_DATE-1
        GROUP BY ITEM_MST_ID, ACCOUNT_ID
    )

         SELECT TO_SINGLE_BYTE(SYS_GUID())                  AS ID
              , P_VER_ID                                        AS VER_ID 
              , MN.ROLE_ID 
              , MN.ITEM_ID  
              , MN.ACCT_ID  
              , MN.BASE_DATE 
              , coalesce(RT.QTY , 0)                        AS QTY 
              , NULL                                        AS AMT
              , 'system'
              , SYSDATE
              , P_PLAN_TP_ID    -- �씠寃� 留욎쓣源�?
              , RT.QTY_1-- coalesce(RT.QTY_1,0)
              , NULL  
              , RT.QTY_2 -- coalesce(RT.QTY_2,0)
              , NULL 
              , RT.QTY_3-- coalesce(RT.QTY_3,0)
              , NULL 
              , EH.QTY
              , EH.AMT 
           FROM TABLE(FN_DP_TEMP_ITEM_ACCT_ROLE_DATE (P_VER_ID, P_Y_PLAN_TP_ID)) MN
--              INNER JOIN
--              UNIT_PRICE UP
--           ON IA.ITEM_ID = UP.ITEM_MST_ID 
--          AND IA.ACCT_ID = UP.ACCOUNT_ID
--          AND CAL.STRT_DT BETWEEN UP.STRT_DATE AND UP.END_DATE
                LEFT OUTER JOIN 
                TEMP_DP_RT      RT 
             ON MN.ITEM_ID = RT.ITEM_MST_ID 
            AND MN.ACCT_ID = RT.ACCOUNT_ID 
            AND RT.BASE_DATE = MN.BASE_DATE  
            AND RT.AUTH_TP_ID = MN.ROLE_ID  
                LEFT OUTER JOIN
                ENTRY_HIS EH 
            ON  MN.ITEM_ID = EH.ITEM_MST_ID
           AND  MN.ACCT_ID = EH.ACCOUNT_ID
           ;                

    DELETE FROM TEMP_DP_RT;

/****************************************************************************************************************
TB_DP_ENTRY_Y �엯�젰 濡쒖쭅 異붽�
*****************************************************************************************************************/
    -- 吏곸쟾 踰꾩쟾 李얘린 : DPS踰꾩쟾(�떆裕щ젅�씠�뀡 踰꾩쟾�씤 寃쎌슦) �룞�씪�븳 湲곗��뀈�썡�뿉�꽌 李얠쓬, DPM踰꾩쟾�� 吏곸쟾�썡 湲곗��뀈�썡�뿉�꽌 李얠쓬
    IF SUBSTR(P_VER_CD,1,3) = 'DPS' THEN

      SELECT ID
        INTO P_PREV_VER_ID
        FROM TB_DP_CONTROL_BOARD_VER_MST
       WHERE VER_ID = (SELECT MAX(VER_ID) FROM TB_DP_CONTROL_BOARD_VER_MST WHERE BASE_YM = P_BASE_YM AND VER_ID LIKE 'DPM%' )  -- �쁽湲곗��뿰�썡怨� 媛숈� 留덉�留� DPM 踰꾩쟾 李얘린
      ;

    ELSE

      SELECT ID
        INTO P_PREV_VER_ID
        FROM TB_DP_CONTROL_BOARD_VER_MST
       WHERE VER_ID = (SELECT MAX(VER_ID) FROM TB_DP_CONTROL_BOARD_VER_MST WHERE BASE_YM = TO_CHAR(ADD_MONTHS(TO_DATE(P_BASE_YM||'01','YYYYMMDD'), -1),'YYYYMM') AND VER_ID LIKE 'DPM%' )  -- �쁽湲곗��뿰�썡蹂대떎 1媛쒖썡�쟾 
      ;

    END IF;

/* --2021.10.21 吏곸쟾踰꾩쟾 �븿�닔 �닔�젙�븿�뿉 �뵲�씪 �븘�옒 custom 荑쇰━�뒗 二쇱꽍泥섎━
INSERT INTO TB_DP_ENTRY_Y
         (    ID
            , VER_ID
      , PLAN_TP_ID
            , AUTH_TP_ID
            , ITEM_MST_ID
            , ACCOUNT_ID
            , BASE_DATE
      , QTY
      , QTY_1
            , CREATE_BY
            , CREATE_DTTM
         )
SELECT    TO_SINGLE_BYTE(SYS_GUID()) AS ID
        , P_VER_ID                   AS VER_ID
        , A.PLAN_TP_ID
        , A.AUTH_TP_ID
        , A.ITEM_MST_ID
        , A.ACCOUNT_ID
        , A.BASE_DATE
        , CASE WHEN B.LV_CD = 'SALESMAN' THEN A.QTY ELSE 0 END       AS QTY
        , CASE WHEN B.LV_CD = 'SALESMAN' THEN A.QTY_1 ELSE 0 END     AS QTY_1
        , 'system'
        , SYSDATE
  FROM    TB_DP_ENTRY_Y A
  JOIN    TB_CM_LEVEL_MGMT B ON B.ID = A.AUTH_TP_ID AND B.LV_CD IN ('SCM','SALESMAN')
 WHERE    A.VER_ID = P_PREV_VER_ID
; 
*/

    --  寃쎌쁺怨꾪쉷�쑝濡� 1�뀈怨꾪쉷�씠 異붽��맆 �븣 �썡 援ш컙�� �씠�쟾踰꾩쟾�쓽 TB_DP_ENTRY_Y�뿉�꽌 媛믪쓣 蹂듭궗�븿

    MERGE INTO TB_DP_ENTRY T
    USING
    (
    WITH TEMP_YEAR AS
    (
    SELECT    ACCOUNT_ID, AUTH_TP_ID, BASE_DATE, QTY, QTY_1
            , CEIL(QTY / 12)         AS D_QTY
            , CEIL(QTY_1 / 12)         AS D_QTY_1
      FROM    TB_DP_ENTRY_Y
     WHERE    VER_ID = P_PREV_VER_ID
       AND    AUTH_TP_ID = (SELECT ID FROM TB_CM_LEVEL_MGMT WHERE LV_CD = 'SALESMAN')
    ), TEMP_DIV_MONTH AS
    (
    SELECT    ACCOUNT_ID
            , AUTH_TP_ID
            , ADD_MONTHS(A.BASE_DATE, LVL) BASE_DATE
            , CASE WHEN QTY - SUM(D_QTY) OVER(PARTITION BY ACCOUNT_ID, BASE_DATE ORDER BY ADD_MONTHS(A.BASE_DATE, LVL)) < 0 
                   THEN QTY - SUM(D_QTY) OVER(PARTITION BY ACCOUNT_ID, BASE_DATE ORDER BY ADD_MONTHS(A.BASE_DATE, LVL)) + D_QTY
              ELSE D_QTY
              END QTY
            , CASE WHEN QTY_1 - SUM(D_QTY_1) OVER(PARTITION BY ACCOUNT_ID, BASE_DATE ORDER BY ADD_MONTHS(A.BASE_DATE, LVL)) < 0 
                   THEN QTY_1 - SUM(D_QTY_1) OVER(PARTITION BY ACCOUNT_ID, BASE_DATE ORDER BY ADD_MONTHS(A.BASE_DATE, LVL)) + D_QTY_1
              ELSE D_QTY_1
              END QTY_1
    FROM    TEMP_YEAR A
          , (
            SELECT     LEVEL - 1 AS LVL
              FROM     DUAL
            CONNECT BY LEVEL <= 12
            ) B
    )
    SELECT    A.ID, A.ACCOUNT_ID, A.AUTH_TP_ID, A.BASE_DATE
            , C.QTY
            , C.QTY_1
      FROM    TB_DP_ENTRY A
      JOIN    TB_DP_CONTROL_BOARD_VER_MST B ON B.ID = A.VER_ID
      JOIN    TEMP_DIV_MONTH C ON C.ACCOUNT_ID = A.ACCOUNT_ID AND C.AUTH_TP_ID = A.AUTH_TP_ID AND C.BASE_DATE = A.BASE_DATE
     WHERE    B.VER_ID = P_VER_CD
       AND    A.AUTH_TP_ID = (SELECT ID FROM TB_CM_LEVEL_MGMT WHERE LV_CD = 'SALESMAN')
       AND    SUBSTR(B.BASE_YM,5,2) = (SELECT LPAD(ATTR_01,2,'0') FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_BASE' AND CONF_CD = 'CHANGE_MON')
       AND    B.VER_S_HORIZON_DATE <= A.BASE_DATE
       AND    B.VER_S_HORIZON_DATE2 > A.BASE_DATE
    ) S
    ON (
      T.ID = S.ID
    )
    WHEN MATCHED THEN
      UPDATE
         SET    T.QTY   = S.QTY
              , T.QTY_1 = S.QTY_1
    ;  


END
;
/

