create PROCEDURE "SP_UI_DP_00_POP_ITEM_LV_HIER" (
	p_ITEM_LV    IN VARCHAR2 := '' -- ID
  , p_ITEM_LV_CD IN VARCHAR2 := ''
  , p_ITEM_LV_NM IN VARCHAR2 := ''
  , pRESULT      OUT SYS_REFCURSOR
) IS 


BEGIN
/*
    ?？？？？? ?？？?? ?？???? ???？？??？ ？?ν？?
    - ?？?????？?？? ???？？?? ??.
    - USED UI : UI_DP_08_ITEM_LV_HIERARCHY_POPUP
*/
    OPEN pRESULT          
    FOR 
    SELECT IL.ID
         , IL.ITEM_LV_CD
         , IL.ITEM_LV_NM
         , IL.LV_MGMT_ID
         , LM.LV_NM
         , IL.PARENT_ITEM_LV_ID
         , IL2.ITEM_LV_CD        AS  PARENT_ITEM_LV_CD
         , IL2.ITEM_LV_NM        AS  PARENT_ITEM_LV_NM
         , IL.SEQ
         , IL.ACTV_YN
      FROM TB_CM_CONFIGURATION A
         , TB_CM_COMM_CONFIG B
         , TB_CM_LEVEL_MGMT LM
         , TB_CM_ITEM_LEVEL_MGMT IL
      LEFT OUTER JOIN TB_CM_ITEM_LEVEL_MGMT IL2 ON IL.PARENT_ITEM_LV_ID = IL2.ID AND COALESCE(IL2.DEL_YN, 'N') = 'N' AND IL2.ACTV_YN = 'Y'
     WHERE A.MODULE_CD = 'DP'
       AND A.ID = B.CONF_ID
       AND B.CONF_GRP_CD = 'DP_LV_TP'
       AND B.CONF_CD = 'I'
       AND B.ID = LM.LV_TP_ID
       AND LM.ID = IL.LV_MGMT_ID
       AND COALESCE(LM.DEL_YN, 'N') = 'N'
       AND LM.ACTV_YN = 'Y'
       AND COALESCE(IL.DEL_YN, 'N') = 'N'
       AND IL.ACTV_YN = 'Y'
       AND IL.LV_MGMT_ID = P_ITEM_LV
       AND IL.ITEM_LV_CD LIKE '%' || P_ITEM_LV_CD || '%'
       AND IL.ITEM_LV_NM LIKE '%' || P_ITEM_LV_NM || '%'
     ;
END;

/

