create procedure "SP_UI_BF_02_Q1" 
(
     P_ENGINE_TP_CD IN VARCHAR2 := NULL,
     pRESULT            OUT SYS_REFCURSOR  
)IS
BEGIN

--------------------------------------------------------------------------------------------------------
    -- Main Procedure
--------------------------------------------------------------------------------------------------------
    OPEN pRESULT          
    FOR     
    SELECT   ID
            ,ENGINE_TYPE_CD
            ,POLICY_CD
            ,POLICY_NM
            ,POLICY_VAL
            ,DESCRIP
            ,CREATE_BY
            ,CREATE_DTTM
            ,MODIFY_BY
            ,MODIFY_DTTM 
     FROM TB_BF_PLAN_POLICY BP      
    WHERE ENGINE_TYPE_CD = P_ENGINE_TP_CD
       OR P_ENGINE_TP_CD IS NULL
      ;
END
;

/

