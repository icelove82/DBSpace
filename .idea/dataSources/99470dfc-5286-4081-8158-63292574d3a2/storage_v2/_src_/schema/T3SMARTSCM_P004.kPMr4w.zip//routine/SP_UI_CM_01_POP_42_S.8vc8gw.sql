create PROCEDURE        "SP_UI_CM_01_POP_42_S" (
	 P_ID                   IN VARCHAR2 := ''
    ,P_ITEM_TP              IN VARCHAR2 := ''
    ,P_CONVN_NM             IN VARCHAR2 := ''
    ,P_ITEM_TP_CD           IN VARCHAR2 := ''
    ,P_ACTV_YN              IN VARCHAR2 := ''
    ,P_USER_ID	            IN VARCHAR2 := ''
    ,P_WRK_TYPE	            IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG     OUT VARCHAR2 
    ,P_RT_MSG               OUT VARCHAR2
    
)
IS

    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';

BEGIN
IF P_WRK_TYPE = 'SAVE'
THEN

        P_ERR_MSG := 'MSG_0005'; --'？？？？ ？？ ？？？？？？ ？？？？？？？ ？？？ ？？？？？？？？.'
		   SELECT COUNT(*) INTO P_ERR_STATUS
			 FROM TB_CM_ITEM_TYPE A
			WHERE 1=1
			  AND A.ID <> P_ID
			  AND A.ITEM_TP = P_ITEM_TP;
		   IF P_ERR_STATUS > 0 THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
           END IF;

        P_ERR_MSG := 'MSG_0005'; --'？？？？ ？？ ？？？？？？ ？？？？？？？ ？？？ ？？？？？？？？.'
		   SELECT COUNT(*) INTO P_ERR_STATUS
			 FROM TB_CM_ITEM_TYPE A
			WHERE 1=1
			  AND A.ID <> P_ID
			  AND A.CONVN_NM = P_CONVN_NM;
		   IF P_ERR_STATUS > 0 THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
           END IF;

        P_ERR_MSG := 'MSG_0006'; --'？？？ ？？？ ？？？？ ？？μ？？？ ？？？？？？？.'
            IF NVL(P_ITEM_TP,'') ='' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;

        P_ERR_MSG := 'MSG_0006'; --'？？？ ？？？ ？？？？ ？？μ？？？ ？？？？？？？.'
            IF NVL(P_CONVN_NM,'') ='' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;

    MERGE INTO TB_CM_ITEM_TYPE B 
		USING (SELECT P_ID AS ID FROM DUAL) A
				ON     (B.ID = A.ID)
		WHEN MATCHED THEN
			UPDATE 
			SET	 
				  ITEM_TP		= P_ITEM_TP
				, CONVN_NM		= P_CONVN_NM
				, ITEM_TP_CD_ID = P_ITEM_TP_CD
				, ACTV_YN		= P_ACTV_YN
				, MODIFY_BY		= P_USER_ID
				, MODIFY_DTTM	= SYSDATE()
		WHEN NOT MATCHED THEN
			INSERT (
				-- ？？？？？？
				ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
				-- ？？？？？？？？
				, ITEM_TP
				, ACTV_YN
				, CONVN_NM
				, ITEM_TP_CD_ID
				)
			VALUES 
		  	    (
				-- ？？？？？？
				TO_SINGLE_BYTE(SYS_GUID()), P_USER_ID, SYSDATE(), P_USER_ID, SYSDATE()
				-- ？？？？？？？？
				,P_ITEM_TP
				,P_ACTV_YN
				,P_CONVN_NM
				,P_ITEM_TP_CD
			);

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';  --？？？？ ？？？？？？？？.

ELSIF P_WRK_TYPE = 'DELETE'
THEN

    DELETE FROM TB_CM_ITEM_TYPE
		WHERE ID = P_ID;

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0002';

END IF;

        EXCEPTION
        WHEN OTHERS THEN
            P_RT_ROLLBACK_FLAG := 'false';
            IF(SQLCODE = -20012)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF; 

END;

/

