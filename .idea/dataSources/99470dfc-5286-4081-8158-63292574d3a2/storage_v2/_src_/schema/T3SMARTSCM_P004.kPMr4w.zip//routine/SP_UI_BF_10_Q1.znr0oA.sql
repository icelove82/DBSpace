create procedure "SP_UI_BF_10_Q1" 
(
    P_VER_ID           IN  VARCHAR2
   ,pRESULT            OUT SYS_REFCURSOR  
)IS
/************************************************************
     ？？？？？ : ？？？？？？
     ？？？？？ : 2019.02.12
     ？？？？ : BF ？？？？ ？？？

     History (？？？？？？ / ？？？？？？ / ？？？？ ？？？？)
     > 2019.02.12 / ？？？？？？ / ？？？ ？？？
************************************************************/
BEGIN
--------------------------------------------------------------------------------------------------------
    -- Version Info
--------------------------------------------------------------------------------------------------------
--SELECT HORIZON, DESCRIP, BUCKET, BF_DIST_RULE, STATUS, FORECAST, DISTRIBUTION
--  FROM TB_BF_CONTROL_BOARD_VER_MST
-- WHERE VER_ID = P_VER_ID
--------------------------------------------------------------------------------------------------------
    -- Main Procedure
--------------------------------------------------------------------------------------------------------
    OPEN pRESULT          
    FOR     
    SELECT   ID
            ,VER_CD
--            ,CASE WHEN ACCOUNT_CD IS NULL THEN SALES_LV_CD ELSE ACCOUNT_CD END AS SALES_LV_CD
--            ,CASE WHEN ITEM_CD IS NULL THEN ITEM_LV_CD ELSE ITEM_CD END AS ITEM_LV_CD
            ,SALES_LV_CD
            ,ITEM_LV_CD
            ,BASE_DATE
            ,QTY
            ,NULL AS MIN_QTY
            ,NULL AS MAX_QTY
            ,CREATE_BY
            ,CREATE_DTTM
            ,MODIFY_BY
            ,MODIFY_DTTM    
      FROM TB_BF_RESULT ET
     WHERE VER_CD = P_VER_ID
       AND ITEM_LV_CD IS NOT NULL
       AND SALES_LV_CD IS NOT NULL
      ;
END
;

/

