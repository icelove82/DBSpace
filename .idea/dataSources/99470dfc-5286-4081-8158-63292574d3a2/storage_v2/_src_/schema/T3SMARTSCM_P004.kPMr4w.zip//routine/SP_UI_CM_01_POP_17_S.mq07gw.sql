create PROCEDURE        "SP_UI_CM_01_POP_17_S" (
	 P_ID                   IN VARCHAR2 := ''
    ,P_ACTV_YN		        IN VARCHAR2 := ''
	,P_EFFICY   	        IN NUMBER := ''
    ,P_USER_ID	            IN VARCHAR2 := ''
    ,P_WRK_TYPE	            IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG     OUT VARCHAR2 
    ,P_RT_MSG               OUT VARCHAR2
    
)
IS

    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';

BEGIN
IF P_WRK_TYPE = 'SAVE'
THEN

        P_ERR_MSG := 'MSG_0006'; --'？?? ?？？???？?？μ？? ?？？??？？'
            IF NVL(P_EFFICY,'') ='' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;

        P_ERR_MSG := 'MSG_0012'; -- '?？?? ?????? ?？？???？?？μ？????？？'
            IF (P_EFFICY < 0 OR P_EFFICY > 100) THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;


    MERGE INTO TB_CM_COMM_CONFIG B 
			USING (SELECT P_ID AS ID FROM DUAL) A
					ON     (B.ID = P_ID)

			WHEN MATCHED THEN

				UPDATE 
				   SET B.ACTV_YN	= P_ACTV_YN
					 , B.CONF_CD	= P_EFFICY
					 , B.CONF_NM	= P_EFFICY
					 , B.DESCRIP	= CONCAT(P_EFFICY,'%') 
					 , MODIFY_BY	= P_USER_ID
					 , MODIFY_DTTM	= SYSDATE();

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';  --???？？????？？
END IF;

        EXCEPTION
        WHEN OTHERS THEN
            P_RT_ROLLBACK_FLAG := 'false';
            IF(SQLCODE = -20012)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF; 

END;

/

