create PROCEDURE "SP_UI_DP_DS_01_S1" 
(
         P_ID           IN  VARCHAR2   :=''
        ,P_USER_ID      IN  VARCHAR2   :=''
        ,P_EMP_NO       IN  VARCHAR2   :=''
        ,P_EMP_NM       IN  VARCHAR2   :=''
        ,P_ACTV_YN      IN  VARCHAR2   :=''
        ,P_P_USER_ID      IN  VARCHAR2   :=''
		,P_RT_ROLLBACK_FLAG	    OUT VARCHAR2   
		,P_RT_MSG				OUT VARCHAR2 
)IS
/*****************************************************************************
    ?λ？???？ EMPLOYEE SAVE 
*****************************************************************************/
		P_ERR_STATUS INT := 0;
        P_ERR_MSG VARCHAR2(4000) :='';
BEGIN
    MERGE INTO TB_DP_EMPLOYEE TARGET
    USING (
			SELECT
		             P_ID      			AS ID      
                    ,P_USER_ID          AS USER_ID
					,P_EMP_NO  			AS EMP_NO  
					,P_EMP_NM  			AS EMP_NM  
					,NVL(P_ACTV_YN,'N') AS ACTV_YN 
					,P_P_USER_ID		AS P_USER_ID 
			  FROM DUAL
           ) SOURCE
	  ON (TARGET.ID = SOURCE.ID)
	WHEN MATCHED THEN
		UPDATE
   		   SET    TARGET.USER_ID        = SOURCE.USER_ID
				, TARGET.EMP_NO			= SOURCE.EMP_NO
				, TARGET.EMP_NM			= SOURCE.EMP_NM
				, TARGET.ACTV_YN		= SOURCE.ACTV_YN
				, TARGET.MODIFY_BY		= SOURCE.P_USER_ID
				, TARGET.MODIFY_DTTM	= SYSDATE
	WHEN NOT MATCHED THEN
		INSERT (
				  ID
				, USER_ID
				, EMP_NO
				, EMP_NM
				, ACTV_YN
				, CREATE_BY
				, CREATE_DTTM
				, MODIFY_BY
				, MODIFY_DTTM
			    ) 
		VALUES(
				  SOURCE.ID
				, SOURCE.USER_ID
				, SOURCE.EMP_NO
				, SOURCE.EMP_NM
				, SOURCE.ACTV_YN
				, SOURCE.P_USER_ID
				, SYSDATE
				, NULL
				, NULL
				);

	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  --???？？????？？
       /* ???？o?? ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN  -- ?？? ???？？? ?？? ???？?？ : e_products_invalid       
              IF(SQLCODE = -20001)
              THEN 
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;  

END;


/

