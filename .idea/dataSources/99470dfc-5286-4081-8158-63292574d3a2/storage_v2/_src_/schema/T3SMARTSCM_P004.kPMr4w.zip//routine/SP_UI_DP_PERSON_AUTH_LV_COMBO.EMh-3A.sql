create PROCEDURE "SP_UI_DP_PERSON_AUTH_LV_COMBO" (
    pREULST OUT SYS_REFCURSOR
)IS 

/*****************************************************************************
Title : SP_UI_DP_PERSONALIZATION_AUTH_LV_COMBO
최초 작성자 : 이고은
최초 생성일 : 2017.08.22
 
설명 
 -  Sales Hierarchy Level + Common code

History (수정일자 / 수정자 / 수정내용)
- 2017.08.22 / 이고은 / 최초 작성
- 2019.04.23 / 김소희 / DEL_YN에 NULL처리 
- 2020.12.23 / 민경훈 / MSSQL -> ORACLE
*****************************************************************************/

v_SEQ INT;

BEGIN


    SELECT MAX(LV.SEQ)+1 INTO v_SEQ
      FROM TB_CM_CONFIGURATION CON 
     INNER JOIN TB_CM_COMM_CONFIG GRP ON CON.ID = GRP.CONF_ID AND CON.CONF_NM = GRP.CONF_CD
     INNER JOIN TB_CM_LEVEL_MGMT LV   ON GRP.ID = LV.LV_TP_ID
     WHERE CON.MODULE_CD = 'DP'
       AND GRP.CONF_GRP_CD = 'DP_LV_TP'
       AND GRP.ACTV_YN = 'Y'
       AND GRP.CONF_CD = 'S'
       AND LV.ACTV_YN = 'Y'
       AND COALESCE(LV.DEL_YN,'N') = 'N'
       AND LV.SALES_LV_YN = 'Y'
      ;

    OPEN pREULST FOR
    SELECT ID 
         , CD_NM
         , CD
         , SEQ 
         , GRP_CD
      FROM ( 
            SELECT 'COMMON'			AS ID 
                  ,'COMMON'		    AS CD
                  ,'Common'			AS CD_NM		
                  , v_SEQ            AS SEQ 
                  ,'COMMON'			AS GRP_CD
              FROM DUAL
            UNION ALL 
            SELECT	 LV.ID				AS ID
                    ,LV.LV_CD			AS CD
                    ,LV.LV_NM			AS CD_NM
                    ,LV.SEQ	            AS SEQ 
                    ,'DISTINCT'			AS GRP_CD
            FROM	TB_CM_CONFIGURATION CON 
                    INNER JOIN TB_CM_COMM_CONFIG GRP  ON CON.ID = GRP.CONF_ID AND CON.CONF_NM = GRP.CONF_GRP_CD
                    INNER JOIN TB_CM_LEVEL_MGMT LV	ON GRP.ID = LV.LV_TP_ID 
            WHERE	CON.MODULE_CD		= 'DP'
            AND		GRP.CONF_GRP_CD		= 'DP_LV_TP'
            AND		GRP.ACTV_YN			= 'Y'
            AND		GRP.CONF_CD			= 'S'
            AND		LV.ACTV_YN			= 'Y'
            AND		COALESCE(LV.DEL_YN,'N') = 'N'
            AND		LV.SALES_LV_YN		= 'Y'
            AND     LV.ID IN ( SELECT LV_MGMT_ID FROM TB_DP_CONTROL_BOARD_MST WHERE DEL_YN = 'N')
         ) A
    ORDER BY A.SEQ 
    ;

END	;

/

