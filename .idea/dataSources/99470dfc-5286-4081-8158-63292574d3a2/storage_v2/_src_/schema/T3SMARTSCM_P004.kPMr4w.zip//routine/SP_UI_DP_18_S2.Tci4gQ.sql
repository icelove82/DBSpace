create PROCEDURE "SP_UI_DP_18_S2" (
									   p_ID					CHAR			:= ''         
									  ,p_DIM_SETTING_ID		CHAR			:= ''         
									  ,p_TBL_NM				VARCHAR2		:= ''      
									  ,p_COL_ID_NM			VARCHAR2		:= ''      
									  ,p_COL_NM				VARCHAR2		:= ''   
									  ,p_USER_ID			VARCHAR2		:= ''  
									  ,P_RT_ROLLBACK_FLAG	OUT	VARCHAR2 
									  ,P_RT_MSG				OUT	VARCHAR2 
                                      
	  								   ) 
IS
       P_ERR_STATUS INT  := 0;
        P_ERR_MSG VARCHAR2(4000) :='';
BEGIN 


	  --?？?？?？?？?？?？?？VAILDATION?？?？?？?？?？?？?？?？

	  --DECLARE	v_VALID_CNT	INT

	  --IF	CONVERT(INT,p_ID) = 0	
	  --BEGIN

		 -- SELECT	v_VALID_CNT = COUNT(*)
		 -- FROM		TB_DP_CONTROL_BOARD_MST WITH (NOLOCK)
		 -- WHERE		MODULE_ID	= 	p_MODULE_ID
		 -- AND		WORK_CD		=	p_WORK_CD
		 -- AND		SEQ			=	p_SEQ
		 -- AND		DEL_YN		=	'N'


		 -- IF	v_VALID_CNT >0
		 -- BEGIN 
			--	RETURN;
		 -- END

	  --END

	  --?？?？?？?？?？?？?？?？?？?？?？?？?？?？?？?？?？?？
	  -- ？?ν？? ?？？

	  --？?？？APPING ?????? ?????？？？?? ?？？ 
	  IF p_TBL_NM = ''
	  THEN

		  DELETE FROM TB_DP_DIM_SETTING_MAP
		  WHERE	ID = p_ID;

	  END IF;


				MERGE INTO TB_DP_DIM_SETTING_MAP TARGET
				USING ( 
						SELECT
						 p_ID						AS ID
						,p_DIM_SETTING_ID			AS DIM_SETTING_ID			
						,p_TBL_NM					AS TBL_NM					
						,p_COL_ID_NM				AS COL_ID_NM			
						,p_COL_NM					AS COL_NM								
						,p_USER_ID					AS USER_ID	
                        FROM DUAL
					  ) SOURCE
				ON	  (TARGET.ID			= SOURCE.ID)	
				WHEN MATCHED THEN
					 UPDATE 
					   SET   TARGET.TBL_NM				= SOURCE.TBL_NM						  			  
							,TARGET.COL_ID_NM			= SOURCE.COL_ID_NM	
							,TARGET.COL_NM				= SOURCE.COL_NM								  	
							,TARGET.MODIFY_BY			= SOURCE.USER_ID       
							,TARGET.MODIFY_DTTM			= SYSDATE       
				WHEN NOT MATCHED THEN 
					 INSERT (
							 ID			
							,DIM_SETTING_ID	
							,TBL_NM			
							,COL_ID_NM		
							,COL_NM		
							,CREATE_BY
							,CREATE_DTTM
							) 
					 VALUES (
							  TO_SINGLE_BYTE(SYS_GUID())
							,SOURCE.DIM_SETTING_ID		
							,SOURCE.TBL_NM	
							,SOURCE.COL_ID_NM	
							,SOURCE.COL_NM	
							,SOURCE.USER_ID       
							,SYSDATE     
 							) 
							;    

	  -- ？?ν？? ???？

        P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  --???？？????？？
       /* ???？o?? ============================================================================*/               
       EXCEPTION
        WHEN OTHERS THEN  -- ?？? ???？？? ?？? ???？?？ : e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;    

   END;


/

