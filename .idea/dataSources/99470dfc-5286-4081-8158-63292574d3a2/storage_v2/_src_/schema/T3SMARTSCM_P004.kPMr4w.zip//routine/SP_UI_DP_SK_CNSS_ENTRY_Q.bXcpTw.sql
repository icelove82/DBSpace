create PROCEDURE                 "SP_UI_DP_SK_CNSS_ENTRY_Q" 
(
     P_C_VER_CD     VARCHAR2 -- New Version ID
    ,P_USER_ID      VARCHAR2
    ,P_AUTH_TP_ID   VARCHAR2
	,P_CELL_CD      VARCHAR2
    ,P_ORDER_STAT   VARCHAR2
    ,P_PGM_CD       VARCHAR2
    ,PRESULT        OUT SYS_REFCURSOR
) IS
/************************************************************************************************
    Consensus Version Load

    History (date / writer / comment)
    - 2021.05.13 / Kimsohee / Draft
    - 2021.07.08 / Kimsohee / add ATTR_10 
    - 2021.06.02 / 김용수 / 일자 가지고 오는 로직 변경
    - 2021.11.22 / Kimsohee /USE_YN by version status
*************************************************************************************************/ 
    P_STRT_DATE DATE ;
    P_IF_CNT    INT;
    P_CONFIRM_YN    VARCHAR2(1);
BEGIN 

/*  기존 로직은 막음
        SELECT COUNT(D.FROM_DATE) INTO P_IF_CNT
          FROM TB_SDP_CONSENSUS_VER_MST C
               INNER JOIN
               TB_DP_CONTROL_BOARD_VER_MST D 
            ON C.DP_VER_CD = D.VER_ID 
         WHERE C_VER_CD = P_C_VER_CD 
         ;
        IF (P_IF_CNT > 0)
        THEN
            SELECT D.FROM_DATE INTO P_STRT_DATE
              FROM TB_SDP_CONSENSUS_VER_MST C
                   INNER JOIN
                   TB_DP_CONTROL_BOARD_VER_MST D 
                ON C.DP_VER_CD = D.VER_ID 
             WHERE C_VER_CD = P_C_VER_CD 
             ;
        END IF
        ;
*/
		-- 시작일자 가지고 오는 부분 변경
        SELECT COUNT(C.FROM_DATE) INTO P_IF_CNT
          FROM TB_SDP_CONSENSUS_VER_MST C
         WHERE C_VER_CD = P_C_VER_CD 
         ;
        IF (P_IF_CNT > 0)
        THEN
            SELECT C.FROM_DATE   
                ,  C.CONFIRM_YN    INTO P_STRT_DATE, P_CONFIRM_YN 
              FROM TB_SDP_CONSENSUS_VER_MST C
             WHERE C_VER_CD = P_C_VER_CD 
             ;
        END IF
        ;


		OPEN 
    PRESULT FOR         
	WITH  
	USERS_INFO 
	AS (-- 나와 내 하위 사용자 정보 찾기 
		SELECT DESC_ID				AS EMP_ID 
			 , DESC_CD				AS EMP_CD 
			 , DESC_ROLE_ID 		AS ROLE_ID 
			 , DESC_ROLE_CD 		AS ROLE_CD 
			 , USER_ACCT_YN 
		  FROM TB_DPD_USER_HIER_CLOSURE	US -- 내 매핑 정보가 있으면 내 하위 사용자 매핑 정보는 안본다.		  
		 WHERE ANCS_ROLE_ID = P_AUTH_TP_ID
		   AND ANCS_CD		= P_USER_ID 	
		   AND MAPPING_SELF_YN = 'Y'	
	), SALES_HIER 
	AS ( 
		SELECT * FROM TB_DPD_SALES_HIER_CLOSURE WHERE LEAF_YN = 'Y' AND CASE WHEN P_CONFIRM_YN = 'Y' THEN 'Y' ELSE USE_YN END = 'Y'
	), ITEM_HIER 
	AS ( 
		SELECT * FROM TB_DPD_ITEM_HIER_CLOSURE WHERE LEAF_YN = 'Y' 
	), ITEM 
		AS (  SELECT CASE WHEN CL.LEAF_YN = 'Y' THEN IM.ITEM_MST_ID ELSE IM.ITEM_LV_ID END	AS ID 
						     , CL.LEAF_YN 
							 , US.ROLE_ID 
							 , US.EMP_ID 
					FROM TB_DP_USER_ITEM_MAP IM  
						  INNER JOIN 
						  USERS_INFO US ON (IM.EMP_ID = US.EMP_ID AND IM.AUTH_TP_ID = US.ROLE_ID AND US.USER_ACCT_YN = 'Y') 
						  INNER JOIN  
						  TB_CM_LEVEL_MGMT CL ON (IM.LV_MGMT_ID = CL.ID AND CL.ACTV_YN = 'Y' AND CL.DEL_YN = 'N') 
				   WHERE IM.ACTV_YN = 'Y'   
		), ACCT 
		AS (-- 내 매핑 ACCT 찾기 
				SELECT CASE WHEN CL.LEAF_YN = 'Y' THEN AM.ACCOUNT_ID ELSE AM.SALES_LV_ID END	AS ID 
					 , US.ROLE_ID 
					 , US.EMP_ID 
					 , CL.LEAF_YN 
				  FROM TB_DP_USER_ACCOUNT_MAP AM  
			           INNER JOIN 
					   USERS_INFO US 
					ON AM.EMP_ID = US.EMP_ID    AND AM.AUTH_TP_ID = US.ROLE_ID  AND US.USER_ACCT_YN = 'Y' 
					   INNER JOIN 
					   TB_CM_LEVEL_MGMT CL 
					ON AM.LV_MGMT_ID = CL.ID    AND CL.ACTV_YN = 'Y'   AND COALESCE(CL.DEL_YN, 'N') = 'N' 
				 WHERE AM.ACTV_YN = 'Y'	  
	), EX
	AS (
	SELECT EX.ITEM_MST_ID 
		 , EX.ACCOUNT_ID
		 , US.ROLE_ID
		 , US.EMP_ID
	  FROM TB_DP_USER_ITEM_ACCOUNT_EXCLUD EX
		   INNER JOIN
		   USERS_INFO US
		ON EX.EMP_ID = US.EMP_ID
	   AND EX.AUTH_TP_ID = US.ROLE_ID
	   AND US.USER_ACCT_YN = 'Y' 
	), IA_LEAF 
		AS (   
		   SELECT  ACCT.ROLE_ID 
		         , ACCT.EMP_ID  
				 , CASE WHEN ITEM.LEAF_YN = 'Y' THEN ITEM.ID ELSE IH.DESCENDANT_ID END		AS ITEM_ID 
				 , CASE WHEN ACCT.LEAF_YN = 'Y' THEN ACCT.ID ELSE SH.DESCENDANT_ID END		AS ACCT_ID 
		  	FROM ACCT		
				   INNER JOIN 
	     			ITEM	 
				ON ACCT.ROLE_ID = ITEM.ROLE_ID 
			   AND ACCT.EMP_ID  = ITEM.EMP_ID 
				   INNER JOIN  
				   ITEM_HIER IH ON ( ITEM.ID = IH.ANCESTER_ID ) 
				   INNER JOIN 
				   SALES_HIER SH ON ACCT.ID = SH.ANCESTER_ID 
			 MINUS 
			 SELECT ROLE_ID 
				  , EMP_ID 
				  , ITEM_MST_ID 
				  , ACCOUNT_ID 
			   FROM EX 
		), ITEM_ACCT 
		AS (SELECT DISTINCT  
			       ACCT_ID  
				  ,ITEM_ID  
			  FROM IA_LEAF -- WHERE 1=1 
--		    UNION 
--			SELECT DISTINCT  
--				   ACCOUNT_ID 
--				 , ITEM_MST_ID 
--			  FROM TB_DP_USER_ITEM_ACCOUNT_MAP UIAM	 
--				   INNER JOIN 
--				   USERS_INFO USIF 
--			    ON UIAM.EMP_ID = USIF.EMP_ID    AND UIAM.AUTH_TP_ID = USIF.ROLE_ID AND USIF.USER_ACCT_YN =  'N' 
	) , AH
    AS (
    SELECT *
      FROM TB_DPD_ACCOUNT_HIERACHY2
     WHERE 1=1
       AND (P_CELL_CD IS NULL OR ATTR_01 = P_CELL_CD)
       AND (P_ORDER_STAT IS NULL OR ATTR_03 = P_ORDER_STAT)
       AND ATTR_17 LIKE '%'|| P_PGM_CD ||'%'
    )
    SELECT C.BASE_DATE AS "DATE"
          ,C.C_VER_CD
          ,P_USER_ID AS USER_ID
          ,P_AUTH_TP_ID AS AUTH_TP_ID
          ,C.QTY      -- 수량 (현 R Consensus F'cst) : A
          ,C.QTY_1    -- 수량 (현 R RTF) : B
          ,C.QTY_2    -- 수량 (RTF Target) : C
          ,C.QTY_3    -- 수량 (Consensus Plan) : G
          ,C.QTY_2 - C.QTY   AS QTY_4 -- 차이 : C-A : QTY_2-QTY
          ,C.QTY_5    -- BOH
--          ,F.QTY_5 - SUM(C.QTY_2) OVER (PARTITION BY M.ACCT_ID ORDER BY C.BASE_DATE ASC) + SUM(C.QTY_6) OVER (PARTITION BY M.ACCT_ID ORDER BY C.BASE_DATE ASC) +C.QTY_2 - C.QTY_6   AS QTY_5 -- BOH : 지난주 H (QTY_7)
          ,C.QTY_6    -- 가용재고 : E  
          ,C.QTY_7    -- EOH : D+E-C
--          ,F.QTY_5 - SUM(C.QTY_2) OVER (PARTITION BY M.ACCT_ID ORDER BY C.BASE_DATE ASC) + SUM(C.QTY_6) OVER (PARTITION BY M.ACCT_ID ORDER BY C.BASE_DATE ASC) AS QTY_7    -- EOH : QTY_5 + QTY_6 - QTY_2  / BOH + 가용재고 - 입력수량 (RTF Target)
          ,C.QTY_8    -- 수량 (전R 연동계획)
          ,C.QTY_9    -- 수량 (경영계획)
          ,C.QTY_3 - C.QTY   AS QTY_10   -- 차이 : G-A : QTY3-QTY
          ,C.QTY_11
          ,C.QTY_12
          ,C.QTY_13
          ,C.QTY_14
          ,C.QTY_15  
          /* Hierarchy */       
          ,AH.LVL01_ID  AS LVL01_ID
          ,AH.LVL01_CD  AS LVL01_CD
          ,AH.LVL01_NM  AS LVL01_NM
          ,AH.LVL02_ID  AS LVL02_ID
          ,AH.LVL02_CD  AS LVL02_CD
          ,AH.LVL02_NM  AS LVL02_NM
          ,AH.LVL03_ID  AS LVL03_ID
          ,AH.LVL03_CD  AS LVL03_CD
          ,AH.LVL03_NM  AS LVL03_NM
          ,AH.LVL04_ID  AS LVL04_ID
          ,AH.LVL04_CD  AS LVL04_CD
          ,AH.LVL04_NM  AS LVL04_NM
          ,AH.LVL05_ID  AS LVL05_ID
          ,AH.LVL05_CD  AS LVL05_CD
          ,AH.LVL05_NM  AS LVL05_NM
          ,AH.LVL06_ID  AS LVL06_ID
          ,AH.LVL06_CD  AS LVL06_CD
          ,AH.LVL06_NM  AS LVL06_NM
          ,AH.LVL07_ID  AS LVL07_ID
          ,AH.LVL07_CD  AS LVL07_CD
          ,AH.LVL07_NM  AS LVL07_NM
          ,AH.LVL08_ID  AS LVL08_ID
          ,AH.LVL08_CD  AS LVL08_CD
          ,AH.LVL08_NM  AS LVL08_NM
          ,AH.LVL09_ID  AS LVL09_ID
          ,AH.LVL09_CD  AS LVL09_CD
          ,AH.LVL09_NM  AS LVL09_NM
          ,AH.LVL10_ID  AS LVL10_ID
          ,AH.LVL10_CD  AS LVL10_CD
          ,AH.LVL10_NM  AS LVL10_NM 
          ,AH.ACCOUNT_ID
          ,AH.ACCOUNT_CD
          ,AH.ACCOUNT_NM
          ,AH.ATTR_01	AS ATTR_01
          ,AH.ATTR_02   AS ATTR_02
          ,AH.ATTR_10   AS ATTR_10
          ,AH.ATTR_17   AS ATTR_17

--          ,AH.CURCY_CD
--          ,AH.CURCY_NM
--          ,AH.CURCY_ID
--          ,AH.SOLD_CUSTOMER_CD
--          ,AH.SOLD_CUSTOMER_NM
--          ,AH.SHIP_CUSTOMER_CD
--          ,AH.SHIP_CUSTOMER_NM
--          ,AH.BILL_CUSTOMER_CD
--          ,AH.BILL_CUSTOMER_NM
--          ,AH.INCOTERMS
--          ,AH.CHANNEL_NM
--          ,AH.COUNTRY_CD
--          ,AH.COUNTRY_NM
--          ,AH.VMI_YN
--          ,AH.ATTR_03   AS ACCT_ATTR_03             
      FROM ITEM_ACCT M
           INNER JOIN
           TB_SDP_CONSENSUS_ENTRY C
        ON C.C_VER_CD = P_C_VER_CD
       AND M.ITEM_ID = C.ITEM_MST_ID
       AND M.ACCT_ID = C.ACCOUNT_ID       
--           INNER JOIN
--           TB_SDP_CONSENSUS_ENTRY F
--        ON F.C_VER_CD = P_C_VER_CD
--       AND F.BASE_DATE = P_STRT_DATE
--       AND M.ITEM_ID = F.ITEM_MST_ID
--       AND M.ACCT_ID = F.ACCOUNT_ID              
           INNER JOIN
           AH
        ON M.ACCT_ID = AH.ACCOUNT_ID 

ORDER BY ACCOUNT_CD, C.BASE_DATE          
    ;




END
;
/

