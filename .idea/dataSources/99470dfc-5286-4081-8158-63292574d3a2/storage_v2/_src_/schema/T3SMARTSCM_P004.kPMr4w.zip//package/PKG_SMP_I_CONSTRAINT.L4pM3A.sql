create PACKAGE                 PKG_SMP_I_CONSTRAINT
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved. 
**************************************************************************
* Name    : PKG_SMP_I_CONSTRAINT
* Purpose : MP Static 정보 생성.
* Notes   :
**************************************************************************
* History :
* 2020-02-17 HGD Created
**************************************************************************/
IS
PRAGMA SERIALLY_REUSABLE;

PROCEDURE SP_SET_LINE_CAPA (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_LINE_MAP (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_BOD_PRIORITY (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_BAS_PRIORITY ( -- SP_SET_LINE_PRIORITY(
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_BAS_CERTI (-- SP_SET_LINE_CERTI (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_BAS_JCT ( -- SP_SET_JCT (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_BEL_PST (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_STOCK_CAPA (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_DYNAMIC_RATE (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);
END PKG_SMP_I_CONSTRAINT;
/

