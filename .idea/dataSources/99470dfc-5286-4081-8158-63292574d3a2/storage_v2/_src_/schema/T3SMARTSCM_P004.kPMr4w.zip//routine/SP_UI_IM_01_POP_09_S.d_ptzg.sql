create PROCEDURE SP_UI_IM_01_POP_09_S (
	 P_ID						IN VARCHAR2 := ''
	,P_MGMT_NM					IN VARCHAR2 := ''
	,P_SEQ	                    IN NUMBER
	,P_ACTV_YN					IN VARCHAR2 := 'Y'
    ,P_SEGMT_DIM_CD             IN VARCHAR2 := ''
	,P_USER_ID					IN VARCHAR2 := ''
    ,P_WRK_TYPE					IN VARCHAR2 := ''
	,P_RT_ROLLBACK_FLAG         OUT VARCHAR2
	,P_RT_MSG                   OUT VARCHAR2
)
IS
    P_ERR_STATUS        INT := 0;
    P_ERR_MSG           VARCHAR2(4000) := '';
    V_SGMT_DIM_MST_ID   CHAR(32);
    
BEGIN
    IF P_WRK_TYPE = 'SAVE'
    THEN	
        SELECT ID INTO V_SGMT_DIM_MST_ID FROM TB_IM_SEGMT_DIM_MST WHERE SEGMT_DIM_CD = P_SEGMT_DIM_CD;
    
        P_ERR_MSG := 'MSG_0006';
           IF NVL(P_MGMT_NM,'') ='' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
           END IF;
    
        P_ERR_MSG := 'MSG_0005';
           SELECT COUNT(*) INTO P_ERR_STATUS
             FROM TB_IM_SEGMT_DIM_DTL A
            WHERE 1=1
              AND A.ID <> P_ID
              AND A.MGMT_NM = P_MGMT_NM
              AND A.INV_MGMT_SEGMT_DIM_MST_ID = V_SGMT_DIM_MST_ID;
           IF P_ERR_STATUS > 0 THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
           END IF;    

        MERGE INTO TB_IM_SEGMT_DIM_DTL B 
        USING (SELECT P_ID AS ID FROM DUAL) A
        ON    (B.ID = A.ID)
        WHEN MATCHED THEN
            UPDATE 
               SET ACTV_YN		= P_ACTV_YN
                 , MGMT_NM		= P_MGMT_NM
                 , VAL			= P_MGMT_NM
                 , SEQ			= P_SEQ
                 , MODIFY_BY	= P_USER_ID
                 , MODIFY_DTTM	= SYSDATE()
        WHEN NOT MATCHED THEN
            INSERT (
                -- 필수항목
                ID, INV_MGMT_SEGMT_DIM_MST_ID, CREATE_BY, CREATE_DTTM
                -- 테이블항목
				,MGMT_NM
				,VAL
				,SEQ
				,ACTV_YN
                )
            VALUES
                (
                -- 필수항목
                TO_SINGLE_BYTE(SYS_GUID()), V_SGMT_DIM_MST_ID, P_USER_ID, SYSDATE()
                -- 테이블항목
				,P_MGMT_NM
				,P_MGMT_NM
				,P_SEQ
				,P_ACTV_YN
                );
                
        P_RT_MSG := 'MSG_0001';

    ELSIF P_WRK_TYPE = 'DELETE'
    THEN
        DELETE FROM TB_IM_SEGMT_DIM_DTL 
        WHERE ID = P_ID;
        
        P_RT_MSG := 'MSG_0001';
    END IF;
    
    P_RT_ROLLBACK_FLAG := 'true';

	EXCEPTION
        WHEN OTHERS THEN
            P_RT_ROLLBACK_FLAG := 'false';
            IF(SQLCODE = -20012)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF;
END;

/

