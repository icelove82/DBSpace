create PROCEDURE                 "SP_UI_DP_CURRENCY_COMBO" 
(
	p_VER_ID    VARCHAR2
  , pRESULT     OUT SYS_REFCURSOR
)
IS 

/*****************************************************************************
Title : SP_UI_DP_CURRENCY_COMBO
理쒖큹 �옉�꽦�옄 : �씠怨좎�
理쒖큹 �깮�꽦�씪 : 2017.07.31
혻
�꽕紐� 
 - SP_UI_DP_CURRENCY_COMBO
 혻
History (�닔�젙�씪�옄 / �닔�젙�옄 / �닔�젙�궡�슜)
- 2017.07.31 / �씠怨좎� / 理쒖큹 �옉�꽦
- 2019.06.19 / 源��냼�씗 / DEL_YN 異붽�혻
- 2020.12.23 / 誘쇨꼍�썕 / MSSQL -> ORACLE
*****************************************************************************/

BEGIN

    OPEN pRESULT FOR
    SELECT 'LOCAL' AS CD
         , 'Local Currency' AS CD_NM 
         , '0' AS ID
      FROM DUAL
    UNION ALL
    SELECT	B.COMN_CD AS CD, TO_CHAR(B.COMN_CD_NM) AS CD_NM, B.ID 
      FROM	TB_AD_COMN_GRP A 
            INNER JOIN 
            TB_AD_COMN_CODE B  
         ON A.ID = B.SRC_ID
            INNER JOIN 
            (     SELECT DISTINCT(TO_CURCY_CD_ID) AS TO_CURCY_CD_ID
                    FROM TB_DP_EXCHANGE_RATE 
                   WHERE CURCY_TP_ID =(SELECT CURCY_TP_ID  FROM TB_DP_CONTROL_BOARD_VER_MST WHERE VER_ID = p_VER_ID)
                    ) C
            ON B.ID = C.TO_CURCY_CD_ID
    WHERE	A.GRP_CD = 'CURRENCY'
      AND   COALESCE(A.DEL_YN, 'N') = 'N'
      AND   COALESCE(B.DEL_YN, 'N') = 'N'
    ;

END;

/

