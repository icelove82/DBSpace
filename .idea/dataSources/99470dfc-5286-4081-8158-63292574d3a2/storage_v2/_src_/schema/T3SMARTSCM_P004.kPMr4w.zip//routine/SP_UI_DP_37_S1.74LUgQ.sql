create PROCEDURE "SP_UI_DP_37_S1" (
									   p_ID                 IN VARCHAR2      := ''      
									  ,p_EMP_NO				IN VARCHAR2      := ''      
                                      ,p_AUTH_TP_ID         IN VARCHAR2      := ''         
                                      ,p_ACCOUNT_ID         IN VARCHAR2      := ''         
									  ,p_ACCOUNT_CD			IN VARCHAR2      := ''   
									  ,p_ITEM_MST_ID        IN VARCHAR2      := ''   
									  ,p_ITEM_CD		    IN VARCHAR2      := ''      
									  ,p_USER_ID            IN VARCHAR2      := ''  
									  ,P_RT_ROLLBACK_FLAG   OUT VARCHAR2   
									  ,P_RT_MSG             OUT VARCHAR2 
									  --,P_OUTPUT_MSG          VARCHAR2 OUTPUT    
				                   ) 
AS
/************************************************************
    History ( Date  / Writer / Comment )
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID
*********************************************************/
		-- Paremeter ？?? 
		 V_ERR_TYPE                 VARCHAR2(50)      := NULL  ;  
		 V_EMP_ID                   VARCHAR2(32)      := NULL ;   
         V_ACCOUNT_ID               CHAR(32) := P_ACCOUNT_ID;
         V_ITEM_MST_ID              CHAR(32) := P_ITEM_MST_ID;
         P_ERR_STATUS INT := 0;
         P_ERR_MSG VARCHAR2(4000) :='';

BEGIN 


-- EMPLOYEE ?? ??？?？? ?？? ?？
SELECT COUNT(USER_ID) INTO P_ERR_STATUS 
 FROM TB_DP_EMPLOYEE 
WHERE USER_ID = P_EMP_NO;
IF (P_EMP_NO IS NULL OR P_ERR_STATUS = 0)
	THEN
	   P_ERR_MSG := 'MSG_0014'; 
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);	
END IF;
SELECT COUNT(ID) INTO P_ERR_STATUS
       FROM TB_DP_ACCOUNT_MST 
      WHERE ACCOUNT_CD = P_ACCOUNT_CD
      ;
IF(V_ACCOUNT_ID IS NULL 
AND P_ERR_STATUS > 0)
then
	SELECT ID INTO V_ACCOUNT_ID 
	  FROM TB_DP_ACCOUNT_MST 
	 WHERE ACCOUNT_CD = p_ACCOUNT_CD
     ;
END IF
;
SELECT COUNT(ID) INTO P_ERR_STATUS
       FROM TB_cM_ITEM_MST 
      WHERE ITEM_CD = p_ITEM_CD
      ;
IF(V_ITEM_MST_ID IS NULL 
AND P_ERR_STATUS > 0)
THEN
	SELECT ID INTO V_ITEM_MST_ID 
	  FROM TB_cM_ITEM_MST 
	 WHERE ITEM_CD = p_ITEM_CD
     ;
END IF
;


-- Account + Item ?？1???？???? 1?？ User?? ?？？ ?? ?？？ ?？??？???？？? ?？？?？ msg
SELECT COUNT(1) INTO P_ERR_STATUS 
 FROM TB_DP_USER_ITEM_ACCOUNT_MAP UI 
WHERE UI.ACCOUNT_ID = V_ACCOUNT_ID 
  AND UI.ITEM_MST_ID = V_ITEM_MST_ID 
  AND UI.AUTH_TP_ID = P_AUTH_TP_ID 
  AND ID != P_ID;
IF (P_ERR_STATUS >=1)
THEN
	   P_ERR_MSG := 'MSG_0013' ;
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
END IF;
-- Account u？
IF (V_ACCOUNT_ID IS NULL)
THEN
	   P_ERR_MSG := 'MSG_0015' ;
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);	
END IF;
-- item u？
IF (V_ITEM_MST_ID IS NULL)
THEN
	   P_ERR_MSG := 'MSG_0017' ;
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);	
END IF;




                -- EMP_ID Setting 
 				SELECT ID INTO V_EMP_ID  
				  FROM TB_AD_USER
				WHERE USERNAME = P_EMP_NO
				;

				MERGE INTO TB_DP_USER_ITEM_ACCOUNT_EXCLUD  TGT   
				USING ( 
						SELECT  p_ID             AS ID 
						       ,p_AUTH_TP_ID     AS  AUTH_TP_ID
							   ,V_ACCOUNT_ID     AS  ACCOUNT_ID
							   ,V_ITEM_MST_ID    AS  ITEM_MST_ID
							   ,V_EMP_ID		 AS  EMP_ID
							   ,p_USER_ID   AS  USER_ID
					  FROM dual ) SRC
				ON      (TGT.ID = SRC.ID) 
				WHEN MATCHED THEN
					 UPDATE 
					   SET   TGT.MODIFY_BY   = SRC.USER_ID
					        ,TGT.ACCOUNT_ID  = SRC.ACCOUNT_ID
							,TGT.ITEM_MST_ID = SRC.ITEM_MST_ID 
							,TGT.MODIFY_DTTM = SYSDATE()       
				WHEN NOT MATCHED THEN 
					 INSERT (
					            ID 
							  , AUTH_TP_ID
							  , ACCOUNT_ID
							  , ITEM_MST_ID
							  , EMP_ID
							  , CREATE_BY
							  , CREATE_DTTM
							) 
					 VALUES (
					             TO_SINGLE_BYTE(SYS_GUID())  
							  , SRC.AUTH_TP_ID
							  , SRC.ACCOUNT_ID
							  , SRC.ITEM_MST_ID
							  , SRC.EMP_ID
							  , SRC.USER_ID 
							  , SYSDATE()            
 							) 
							;    	


	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  
       /* ???？o?? ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN   
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := SQLERRM;
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;     

END;

/

