create PROCEDURE "SP_DP_SRP_DELETE_OLD_DATA" 
(   
     p_DATE IN DATE := '' -- ？？？？？？ ？？？？？？ ？？？？ ？？￥ ？？？
)IS
BEGIN 
     DELETE FROM TB_SRP_ENTRY
           WHERE VER_ID IN ( 
                    SELECT ID 
                     FROM TB_SRP_CNTRL_BOARD_VER_MST
                    WHERE DP_CONBD_VER_MST_ID IN (
                                                  SELECT ID
                                                    FROM TB_DP_CONTROL_BOARD_VER_MST
                                                   WHERE TO_CHAR(CREATE_DTTM,'YY/MM/DD') < TO_CHAR(p_DATE,'YY/MM/DD')
                                                  )
                           )
     ;
     DELETE FROM TB_SRP_CNTRL_BOARD_VER_MST
           WHERE DP_CONBD_VER_MST_ID IN (
                                             SELECT ID
                                               FROM TB_DP_CONTROL_BOARD_VER_MST
                                              WHERE TO_CHAR(CREATE_DTTM,'YY/MM/DD') < TO_CHAR(p_DATE,'YY/MM/DD')
                                         )
     ;

     DELETE FROM TB_DP_CONTROL_BOARD_VER_DTL
           WHERE CONBD_VER_MST_ID IN (
                                        SELECT ID
                                          FROM TB_DP_CONTROL_BOARD_VER_MST
                                         WHERE TO_CHAR(CREATE_DTTM,'YY/MM/DD') < TO_CHAR(p_DATE,'YY/MM/DD')
                                     )
     ;
     DELETE FROM TB_DP_ENTRY
           WHERE VER_ID IN (
                                   SELECT ID
                                     FROM TB_DP_CONTROL_BOARD_VER_MST
                                    WHERE TO_CHAR(CREATE_DTTM,'YY/MM/DD') < TO_CHAR(p_DATE,'YY/MM/DD')
                            )
     ;
     DELETE FROM TB_DP_CONTROL_BOARD_VER_MST
           WHERE TO_CHAR(CREATE_DTTM,'YY/MM/DD') < TO_CHAR(p_DATE,'YY/MM/DD')
     ;

     commit;

END;
/

