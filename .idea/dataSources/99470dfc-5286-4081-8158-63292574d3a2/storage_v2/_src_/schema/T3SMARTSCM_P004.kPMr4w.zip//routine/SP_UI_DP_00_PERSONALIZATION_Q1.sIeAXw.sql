create PROCEDURE "SP_UI_DP_00_PERSONALIZATION_Q1" (
    p_UI_ID     IN VARCHAR2 := ''
  , p_GRP_CD   IN VARCHAR2 := ''
  , p_GRID_ID   IN VARCHAR2 := '' 
  , p_USER_ID   IN VARCHAR2 := ''
  , pRESULT     OUT SYS_REFCURSOR
)
IS 
/*
    Entry???? ?？
*/
BEGIN
    IF P_UI_ID IN ('UI_DP_25_CHART', 'UI_DP_26_CHART') AND P_GRID_ID= 'RST_CRT_01' THEN
        OPEN pRESULT
        FOR
        WITH
        PSNZ AS (
            SELECT M.VIEW_CD AS UI_ID
                 , M.GRID_CD AS GRID_ID
                 , G.GRP_CD AS AUTH_TP
                 , A.FLD_CD AS FIELD_ID
                 , A.REFER_VALUE AS FIELD_VAL
                 , A.FLD_APPLY_CD AS FIELD_NM
                 , A.DIM_MEASURE_TP
                 , A.CROSSTAB_ITEM_CD AS PIVOT_ITEM_CD
                 , A.FLD_SEQ AS SEQ_1
                 , B.FLD_SEQ AS SEQ_2
                 , COALESCE(B.DATA_KEY_YN, COALESCE(A.DATA_KEY_YN, 'N')) AS DATA_KEY_YN
                 , COALESCE(B.FLD_ACTIVE_YN, COALESCE(A.FLD_ACTIVE_YN, 'N')) AS ACTV_YN
                 , COALESCE(B.CROSSTAB_YN, COALESCE(A.CROSSTAB_YN, 'N')) AS PIVOT_APPY_YN
              FROM TB_AD_USER_PREF_DTL A
             INNER JOIN TB_AD_USER_PREF_MST M   ON M.ID = A.USER_PREF_MST_ID    AND M.VIEW_CD = P_UI_ID
             INNER JOIN TB_AD_GROUP G           ON G.ID = A.GRP_ID              AND G.GRP_CD  = P_GRP_CD
             INNER JOIN TB_AD_USER U            ON U.USERNAME = P_USER_ID
              LEFT OUTER JOIN TB_AD_USER_PREF B
                ON M.ID = B.USER_PREF_MST_ID
               AND A.GRP_ID = B.GRP_ID
               AND A.FLD_CD = B.FLD_CD
               AND B.USER_ID = U.ID
        )
        SELECT A.UI_ID
             , REPLACE(A.GRID_ID, 'CPT', 'CRT') GRID_ID
             , A.AUTH_TP
             , A.FIELD_ID
             , A.FIELD_VAL
             , A.FIELD_NM
             , A.DIM_MEASURE_TP
             , A.ACTV_YN
             , A.DATA_KEY_YN
             , A.SEQ_2
             , A.SEQ_1
          FROM PSNZ A
         WHERE (A.DATA_KEY_YN = 'Y' OR A.PIVOT_APPY_YN = 'Y')
           AND A.PIVOT_ITEM_CD IN ('GROUP-COLUMNS', 'GROUP-ROWS', 'GROUP-HORIZONTAL-VALUES')
           AND A.GRID_ID = REPLACE(P_GRID_ID, 'CRT', 'CPT')
        UNION
        SELECT A.UI_ID
             , A.GRID_ID
             , A.AUTH_TP
             , A.FIELD_ID
             , A.FIELD_VAL
             , A.FIELD_NM
             , A.DIM_MEASURE_TP
             , A.ACTV_YN
             , A.DATA_KEY_YN
             , A.SEQ_2
             , A.SEQ_1
          FROM PSNZ A
         WHERE (A.DATA_KEY_YN = 'Y' OR A.PIVOT_APPY_YN = 'Y')
           AND A.PIVOT_ITEM_CD = 'GROUP-VERTICAL-VALUES'
           AND A.GRID_ID = P_GRID_ID
         ORDER BY DIM_MEASURE_TP, SEQ_2, SEQ_1
        ;
    ELSE
        OPEN pRESULT
        FOR
        SELECT A.VIEW_CD AS UI_ID
             , A.GRID_CD AS GRID_ID
             , A.AUTH_TP
             , A.FLD_CD AS FIELD_ID
             , A.REFER_VALUE AS FIELD_VAL
             , A.FLD_APPLY_CD AS FIELD_NM
             , A.DIM_MEASURE_TP
             , A.ACTV_YN
             , A.DATA_KEY_YN
          FROM (
            SELECT M.VIEW_CD
                 , M.GRID_CD
                 , G.GRP_CD AS AUTH_TP
                 , A.FLD_CD
                 , A.REFER_VALUE
                 , A.FLD_APPLY_CD
                 , A.DIM_MEASURE_TP
                 , A.CROSSTAB_ITEM_CD
                 , A.FLD_SEQ AS SEQ_1
                 , B.FLD_SEQ AS SEQ_2
                 , COALESCE(B.DATA_KEY_YN, COALESCE(A.DATA_KEY_YN, 'N')) AS DATA_KEY_YN
                 , COALESCE(B.FLD_ACTIVE_YN, COALESCE(A.FLD_ACTIVE_YN, 'N')) AS ACTV_YN
                 , COALESCE(B.CROSSTAB_YN, COALESCE(A.CROSSTAB_YN, 'N')) AS CROSSTAB_YN
              FROM TB_AD_USER_PREF_DTL A
             INNER JOIN TB_AD_USER_PREF_MST M
                ON M.ID = A.USER_PREF_MST_ID
               AND M.VIEW_CD = P_UI_ID
               AND M.GRID_CD = P_GRID_ID
             INNER JOIN TB_AD_GROUP G ON G.ID = A.GRP_ID AND G.GRP_CD  = P_GRP_CD
             INNER JOIN TB_AD_USER  U ON U.USERNAME = P_USER_ID
              LEFT OUTER JOIN TB_AD_USER_PREF B
                ON M.ID = B.USER_PREF_MST_ID
               AND A.GRP_ID = B.GRP_ID
               AND A.FLD_CD = B.FLD_CD
               AND B.USER_ID = U.ID
          ) A
         WHERE (A.DATA_KEY_YN = 'Y' OR A.CROSSTAB_YN = 'Y')
           AND A.CROSSTAB_ITEM_CD IN ('GROUP-COLUMNS', 'GROUP-ROWS', 'GROUP-VERTICAL-VALUES', 'GROUP-HORIZONTAL-VALUES')
         ORDER BY A.DIM_MEASURE_TP, A.SEQ_2, A.SEQ_1
        ;

    END IF;
END;

/

