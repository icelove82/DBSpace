create PROCEDURE                SP_UI_DP_07_S1 (     
									   p_FROM_CURCY_CD       IN VARCHAR2      := ''         
									  ,p_TO_CURCY_CD         IN VARCHAR2      := ''
									  ,p_BASE_DATE           IN DATE          := NULL
									  ,p_EXCHANGE_RATE       IN DECIMAL       := 0
									  ,p_UNIT_UOM_VAL        IN DECIMAL       := 0
                                      ,p_CURCY_TP_CD         IN VARCHAR2      := ''
                                      ,p_USER_ID             IN VARCHAR2      := ''
									  ,P_RT_ROLLBACK_FLAG    OUT VARCHAR2   
									  ,P_RT_MSG              OUT VARCHAR2  									        
	  								   ) 
IS
        P_ERR_MSG VARCHAR2(4000):='';
        p_FROM_CURCY_CD_ID VARCHAR2(4000):='';
        p_TO_CURCY_CD_ID VARCHAR2(4000):='';
        p_CURCY_TP_ID VARCHAR2(100):='';
BEGIN

    BEGIN
        SELECT ID INTO p_FROM_CURCY_CD_ID 
          FROM TB_AD_COMN_CODE 
          WHERE 1=1
            AND COMN_CD = p_FROM_CURCY_CD
            AND NVL(DEL_YN, 'N') = 'N'
            AND USE_YN = 'Y'
          ;
        SELECT ID INTO p_TO_CURCY_CD_ID 
          FROM TB_AD_COMN_CODE 
          WHERE 1=1
            AND COMN_CD = p_TO_CURCY_CD
            AND NVL(DEL_YN,'N') = 'N'
            AND USE_YN = 'Y'            
            ;

        SELECT ID INTO p_CURCY_TP_ID FROM TB_CM_COMM_CONFIG 
        WHERE CONF_CD = p_CURCY_TP_CD AND CONF_GRP_CD = 'DP_CURRENCY_TYPE';    

    EXCEPTION
    WHEN NO_DATA_FOUND  THEN
          P_ERR_MSG := 'MSG_0006';
    WHEN OTHERS THEN    
        RAISE;
    END;

-------------- VALIDATION ------------------------------------------------- 
     IF (p_FROM_CURCY_CD_ID IS NULL)
        THEN
          P_ERR_MSG := 'MSG_0006';  
          RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); -- RAISERROR (P_ERR_MSG,12, 1);                       
        END IF;

     IF (p_TO_CURCY_CD_ID IS NULL)
        THEN
          P_ERR_MSG := 'MSG_0006';   
          RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); -- RAISERROR (P_ERR_MSG,12, 1);                       
        END IF;   

     IF (p_BASE_DATE IS NULL)
        THEN
          P_ERR_MSG := 'MSG_0006';   
          RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); -- RAISERROR (P_ERR_MSG,12, 1);                       
        END IF; 

     IF (p_EXCHANGE_RATE IS NULL)
        THEN
          P_ERR_MSG := 'MSG_0006';  
          RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); -- RAISERROR (P_ERR_MSG,12, 1);                       
        END IF;

     IF (p_CURCY_TP_ID IS NULL)
        THEN
          P_ERR_MSG := 'MSG_0006';  
          RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); -- RAISERROR (P_ERR_MSG,12, 1);                       
        END IF;

     IF (p_FROM_CURCY_CD_ID = p_TO_CURCY_CD_ID)
        THEN
          P_ERR_MSG := 'MSG_5100';  
          RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); -- RAISERROR (P_ERR_MSG,12, 1);                    
        END IF;
------------------------------------------------------------------------------------------------            
    MERGE INTO TB_DP_EXCHANGE_RATE TGT
        USING ( 
                SELECT  
                 p_FROM_CURCY_CD_ID       AS  FROM_CURCY_CD_ID     
                ,p_TO_CURCY_CD_ID         AS  TO_CURCY_CD_ID       
                ,p_BASE_DATE              AS  BASE_DATE            
                ,p_EXCHANGE_RATE          AS  EXCHANGE_RATE        
                ,p_UNIT_UOM_VAL           AS  UNIT_UOM_VAL         
                ,p_USER_ID                AS  USER_ID
                ,P_CURCY_TP_ID            AS CURCY_TP_ID
              FROM dual ) SRC 
        ON ( TGT.FROM_CURCY_CD_ID = SRC.FROM_CURCY_CD_ID 
        AND TGT.TO_CURCY_CD_ID     = SRC.TO_CURCY_CD_ID 
        AND TGT.BASE_DATE              = SRC.BASE_DATE 
        AND TGT.CURCY_TP_ID            = SRC.CURCY_TP_ID)
        WHEN MATCHED THEN
             UPDATE 
               SET        
                     TGT.EXCHANGE_RATE       	= SRC.EXCHANGE_RATE   
                    ,TGT.UNIT_UOM_VAL    		= SRC.UNIT_UOM_VAL    
                    ,TGT.MODIFY_BY              = SRC.USER_ID       
                    ,TGT.MODIFY_DTTM            = SYSDATE
        WHEN NOT MATCHED THEN 
             INSERT (
                     ID               
                    ,FROM_CURCY_CD_ID
                    ,TO_CURCY_CD_ID  
                    ,BASE_DATE       
                    ,EXCHANGE_RATE   
                    ,UNIT_UOM_VAL
                    ,CURCY_TP_ID
                    ,CREATE_BY
                    ,CREATE_DTTM                            
                    ) 
             VALUES (
                     TO_SINGLE_BYTE(SYS_GUID())
                    ,SRC.FROM_CURCY_CD_ID   
                    ,SRC.TO_CURCY_CD_ID     
                    ,SRC.BASE_DATE          
                    ,SRC.EXCHANGE_RATE      
                    ,SRC.UNIT_UOM_VAL    
                    ,SRC.CURCY_TP_ID
                    ,SRC.USER_ID 
                    ,SYSDATE   
                    );    

	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  
       /*  ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN  
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF; 
 END;
/

