create PROCEDURE "SP_UI_DP_15_Q1" (
    p_EMP_CD        IN VARCHAR2 := ''
  , p_AUTH_TP_ID	IN VARCHAR2 := ''
  , p_ITEM_CD       IN VARCHAR2 := ''
  , p_ITEM_NM       IN VARCHAR2 := ''
  , p_ACCT_CD       IN VARCHAR2 := ''
  , p_ACCT_NM       IN VARCHAR2 := ''
  , pRESULT         OUT SYS_REFCURSOR
  
) IS 

/*
    History (수정일 / 수정자 / 수정 내용)
    - 2019.02.26 / 김소희 / item, account가 활성화된 매핑값만 보이기
    - 2019.09.26 / 김소희 / UOM_NM 추가 
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 
************************************************************************/
BEGIN
        OPEN pRESULT
        FOR
        SELECT  IA.ID
			  , IA.AUTH_TP_ID
			  , LM.LV_CD AS AUTH_TP_CD
			  , LM.LV_NM AS AUTH_TP_NM
			  , IA.ACCOUNT_ID
			  , AM.ACCOUNT_CD
			  , AM.ACCOUNT_NM 
			  , IA.ITEM_MST_ID
			  , IM.ITEM_CD
			  , IM.ITEM_NM 
			  , UM.UOM_CD 
              , UM.UOM_NM
			  , IA.EMP_ID
              , DE.USERNAME AS USER_ID
			  , DE.USERNAME AS EMP_NO
			  , DE.DISPLAY_NAME AS EMP_NM 
			  , IA.CREATE_BY
			  , IA.CREATE_DTTM
			  , IA.MODIFY_BY
			  , IA.MODIFY_DTTM
                 --, IM.UOM_ID AS UOM_CD
			  , CASE WHEN IM.DEL_YN = 'Y' OR NVL(IM.DP_PLAN_YN,'N') = 'N' THEN 'N' ELSE 'Y' END AS ITEM_PLAN_YN
			  , CASE WHEN AM.DEL_YN = 'Y' OR NVL(AM.ACTV_YN,'N') = 'N'    THEN 'N' ELSE 'Y' END AS ACCT_PLAN_YN	  
		  FROM   TB_DP_USER_ITEM_ACCOUNT_MAP IA
			     INNER JOIN
                 TB_DP_ACCOUNT_MST AM 
              ON IA.ACCOUNT_ID = AM.ID
             AND AM.DEL_YN != 'Y'
             AND AM.ACTV_YN = 'Y'
                 INNER JOIN
			     TB_CM_ITEM_MST IM 
              ON IA.ITEM_MST_ID = IM.ID
             AND IM.DEL_YN != 'Y'
             AND IM.DP_PLAN_YN = 'Y'
                 INNER JOIN
			     TB_CM_LEVEL_MGMT LM
              ON IA.AUTH_TP_ID = LM.ID
                 INNER JOIN
			     TB_AD_USER  DE
              ON IA.EMP_ID = DE.ID
                 INNER JOIN
                 TB_CM_UOM UM
              ON UM.ID = IM.UOM_ID
		WHERE 1=1
		  AND DE.USERNAME = p_EMP_CD --'admin'
		  -- AUTH_TP_ID
		  AND IA.AUTH_TP_ID LIKE   '%' || p_AUTH_TP_ID || '%'
              AND  (  REGEXP_LIKE (UPPER(AM.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  p_ACCT_CD IS NULL
                    )
               AND  ( REGEXP_LIKE (UPPER(IM.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  P_ITEM_CD IS NULL
                    )
              AND   ( REGEXP_LIKE (UPPER(AM.ACCOUNT_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ACCT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  P_ACCT_NM IS NULL
                    )
               AND  ( REGEXP_LIKE (UPPER(IM.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  P_ITEM_NM IS NULL
                    )

         ORDER BY AM.ACCOUNT_CD, IM.ITEM_CD
;

END
;
/

