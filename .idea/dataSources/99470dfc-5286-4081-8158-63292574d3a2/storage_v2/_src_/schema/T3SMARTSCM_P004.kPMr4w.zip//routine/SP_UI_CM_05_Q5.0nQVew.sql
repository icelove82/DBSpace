create PROCEDURE "SP_UI_CM_05_Q5" (
    P_LOCAT_TP          IN VARCHAR2 := '',
    P_LOCAT_LV          IN VARCHAR2 := '',
    P_LOCAT_CD          IN VARCHAR2 := '',
    P_LOCAT_NM          IN VARCHAR2 := '',
    P_ITEM_CD           IN VARCHAR2 := '',
    P_ITEM_DESCRIP      IN VARCHAR2 := '',
    C_ITEM_CD           IN VARCHAR2 := '',
    C_ITEM_DESCRIP      IN VARCHAR2 := '',
    C_ACTV_YN           IN CHAR := '',
    pResult OUT SYS_REFCURSOR
)
IS
BEGIN

    OPEN pResult FOR
    SELECT
            C.LOCAT_TP,
            C.LOCAT_LV,
            C.LOCAT_CD,
            C.LOCAT_NM,
            A.BOM_LV,
            C.ITEM_CD,
            C.ITEM_NM,
            C.DESCRIP,
            C.ITEM_TP,
            C.BOM_TP                AS BOM_ITEM_TYPE,
            A.BOM_VER_ID            AS P_BOM_VER_ID,
            B.BOM_LV                AS P_BOM_LV,
            D.ITEM_CD               AS P_ITEM_CD,
            D.ITEM_NM               AS P_ITEM_NM,
            D.DESCRIP               AS P_DESCRIP,
            D.ITEM_TP               AS P_ITEM_TP,
            D.BOM_TP                AS P_BOM_ITEM_TYPE,
            B.BASE_QTY              AS P_BASE_QTY,
            D.UOM_NM                AS P_UOM_NM,
            A.CONSUME_QTY           AS C_CONSUME_QTY,
            C.UOM_NM                AS C_UOM_NM,
            A.BASE_BOM_RATE         AS C_BASE_BOM_RATE,
            E.COMN_CD_NM            AS C_ALT_GROUP,
			F.COMN_CD_NM            AS C_ALT_POLICY,
            A.PRIORT                AS C_PRIORT,
            A.PRDUCT_YN             AS C_PRDUCT_YN,
            A.CREATE_BY,
            A.CREATE_DTTM,
            A.MODIFY_BY,
            A.MODIFY_DTTM
    FROM    TB_CM_GLOBAL_BOM_DTL A
			LEFT OUTER JOIN TB_AD_COMN_CODE E
            ON (A.ALT_GRP_ID = E.ID)
			LEFT OUTER JOIN TB_AD_COMN_CODE F
            ON (A.ALT_POLICY_ID = F.ID),
            TB_CM_GLOBAL_BOM_MST B,
            (
            SELECT  A.ID, E.SEQ, E.COMN_CD_NM AS LOCAT_TP, D.LOCAT_LV, C.LOCAT_CD, C.LOCAT_NM,
                    F.ITEM_CD, F.ITEM_NM, F.DESCRIP, G.CONVN_NM AS ITEM_TP, H.COMN_CD_NM AS BOM_TP, J.UOM_NM
            FROM    TB_CM_SITE_ITEM A,
                    TB_CM_LOC_MGMT B,
                    TB_CM_LOC_DTL C,
                    TB_CM_LOC_MST D,
                    TB_AD_COMN_CODE E,
                    TB_CM_ITEM_MST F,
                    TB_CM_ITEM_TYPE G,
                    TB_AD_COMN_CODE H,
                    TB_CM_UOM J
            WHERE   B.ID = A.LOCAT_MGMT_ID
            AND     C.ID = B.LOCAT_ID
            AND     D.ID = C.LOCAT_MST_ID
            AND     E.ID = D.LOCAT_TP_ID
            AND     F.ID = A.ITEM_MST_ID
            AND     G.ID = F.ITEM_TP_ID
            AND     H.ID = A.BOM_ITEM_TP_ID
            AND     J.ID = F.UOM_ID
            ) C,
            (
            SELECT  A.ID, E.COMN_CD_NM AS LOCAT_TP, D.LOCAT_LV, C.LOCAT_CD, C.LOCAT_NM,
                    F.ITEM_CD, F.ITEM_NM, F.DESCRIP, G.CONVN_NM AS ITEM_TP, H.COMN_CD_NM AS BOM_TP, J.UOM_NM
            FROM    TB_CM_SITE_ITEM A,
                    TB_CM_LOC_MGMT B,
                    TB_CM_LOC_DTL C,
                    TB_CM_LOC_MST D,
                    TB_AD_COMN_CODE E,
                    TB_CM_ITEM_MST F,
                    TB_CM_ITEM_TYPE G,
                    TB_AD_COMN_CODE H,
                    TB_CM_UOM J
            WHERE   B.ID = A.LOCAT_MGMT_ID
            AND     C.ID = B.LOCAT_ID
            AND     D.ID = C.LOCAT_MST_ID
            AND     E.ID = D.LOCAT_TP_ID
            AND     F.ID = A.ITEM_MST_ID
            AND     G.ID = F.ITEM_TP_ID
            AND     H.ID = A.BOM_ITEM_TP_ID
            AND     J.ID = F.UOM_ID
            ) D
    WHERE   1=1
    AND     C.ID = A.LOCAT_ITEM_ID
    AND     D.ID = B.LOCAT_ITEM_ID
    AND     B.ID = A.PRDUCT_BOM_MST_ID
    AND     NVL(A.BASE_BOM_YN, 'Y') = 'Y'
	AND     UPPER(C.LOCAT_TP)	LIKE '%'||UPPER(P_LOCAT_TP)||'%'
	AND     C.LOCAT_LV			LIKE '%'||P_LOCAT_LV||'%'
	AND     UPPER(C.LOCAT_CD)	LIKE '%'||UPPER(P_LOCAT_CD)||'%'
	AND     UPPER(C.LOCAT_NM)	LIKE '%'||UPPER(P_LOCAT_NM)||'%'
	AND     (D.ITEM_CD	        LIKE '%'||LTRIM(RTRIM(P_ITEM_CD))||'%' OR P_ITEM_CD IS NULL)
	AND     (D.DESCRIP	        LIKE '%'||LTRIM(RTRIM(P_ITEM_DESCRIP))||'%' OR P_ITEM_DESCRIP IS NULL)
	AND     (C.ITEM_CD	        LIKE '%'||LTRIM(RTRIM(C_ITEM_CD))||'%' OR C_ITEM_CD IS NULL)
	AND     (C.DESCRIP	        LIKE '%'||LTRIM(RTRIM(C_ITEM_DESCRIP))||'%' OR C_ITEM_DESCRIP IS NULL)
    AND 	A.ACTV_YN = CASE WHEN UPPER(C_ACTV_YN)='A' THEN A.ACTV_YN
                             ELSE UPPER(C_ACTV_YN)
                        END
    ORDER BY C.SEQ, C.LOCAT_LV, C.LOCAT_CD, A.BOM_LV, C.ITEM_CD, A.BOM_VER_ID, B.BOM_LV, D.ITEM_CD;
            
END;

/

