create PROCEDURE "SP_UI_DP_23_VER_CREATE_S3" (
      p_VER_ID      CHAR	--	= (SELECT TOP 1 ID FROM TB_DP_CONTROL_BOARD_VER_MST ORDER BY CREATE_DTTM DESC)
    , p_PLAN_TP_ID  CHAR	--   = (SELECT TOP 1 PLAN_TP_ID FROM TB_DP_CONTROL_BOARD_VER_MST ORDER BY CREATE_DTTM DESC)	
)
IS 

/************************************************************************************************************
Title : SP_DP_VER_CREATE_S3
최초 작성자 : Kim Sohee
최초 생성일 : 2020.05.07
 
Description
 - Make DP Entry Init Data
 
History (수정일자 / 수정자 / 수정내용)
- 2020.05.07 / Kim Sohee / Draft 
- 2020.12.23 / 민경훈 / MSSQL -> ORACLE
- 2021.11.19 / kim sohee / use_yn check
************************************************************************************************************/

BEGIN 
/************************************************************************************************************
	-- Result
************************************************************************************************************/
    INSERT INTO TB_DP_ENTRY	--_20200507
		 (    ID
			, VER_ID
			, AUTH_TP_ID
--			, EMP_ID
			, ITEM_MST_ID
			, ACCOUNT_ID
--			, SALES_LV_ID
			, BASE_DATE
			, QTY
--			, AMT
			, CREATE_BY
			, CREATE_DTTM
			, PLAN_TP_ID
--			, QTY_1
--			, AMT_1
--			, QTY_2
--			, AMT_2
--			, QTY_3
--			, AMT_3		 
		 )
	WITH VER_INFO
	AS (SELECT		 ID
					,FROM_DATE 
					,TO_DATE
					,BUKT	
					,PRICE_TP_ID				 
		 FROM TB_DP_CONTROL_BOARD_VER_MST 
	    WHERE ID = p_VER_ID 
	), VER_INFO_DTL
	AS (
		SELECT VI.ID
		 , (SELECT ID
              FROM (
                SELECT ID 
                  FROM TB_DP_CONTROL_BOARD_VER_MST 
                 WHERE ID != p_VER_ID 
                   AND PLAN_TP_ID = p_PLAN_TP_ID 
              ORDER BY CREATE_DTTM DESC
              )
             WHERE ROWNUM=1
		  )								 AS PREV_VER_ID
		 , VI.FROM_DATE 				 
		 , VI.TO_DATE 					 
		 , LV.LV_CD						 AS AUTH_TP_CD
		 , VE.LV_MGMT_ID				 AS AUTH_TP_ID
		 , IV.CONF_CD					 AS INIT_TP_CD
		 , CASE IV.CONF_CD 
			WHEN 'PR' THEN IL.LV_CD
			WHEN 'MS' THEN MS.MEASURE_CD
		   END							 AS INIT_VAL_CD
		 , CASE IV.CONF_CD 
			WHEN 'PR' THEN IL.ID
			WHEN 'MS' THEN MS.ID
		   END							 AS INIT_VAL_ID
	  FROM VER_INFO VI 
		   INNER JOIN 
		   TB_DP_CONTROL_BOARD_VER_DTL VE
		ON VI.ID = p_VER_ID 
	   AND VE.CONBD_VER_MST_ID = p_VER_ID 
		   INNER JOIN
		   TB_CM_LEVEL_MGMT LV
		ON VE.LV_MGMT_ID = LV.ID
	   AND COALESCE(LV.DEL_YN, 'N') = 'N'
	   AND LV.ACTV_YN = 'Y'   
		   INNER JOIN
		   TB_CM_COMM_CONFIG IV
		ON VE.INIT_VAL_TP_ID = IV.ID 
	   AND IV.ACTV_YN = 'Y'   
		   LEFT OUTER JOIN
		   TB_CM_LEVEL_MGMT IL
		ON VE.INIT_FIXED_LV_MGMT_ID = IL.ID
	   AND COALESCE(IL.DEL_YN, 'N') = 'N'
	   AND IL.ACTV_YN = 'Y'   
		   LEFT OUTER JOIN
		   TB_DP_MEASURE_MST MS
		ON VE.INIT_MEASURE_ID = MS.ID
	), RT
	AS (
		SELECT ITEM_MST_ID
			 , ACCOUNT_ID
			 , BASE_DATE
			 , QTY
			 , VE.AUTH_TP_ID 
		  FROM TB_DP_ENTRY 	DE
			   INNER JOIN
			   VER_INFO_DTL VE
			ON VE.INIT_TP_CD = 'PR'
		   AND DE.VER_ID = VE.PREV_VER_ID 
		   AND VE.INIT_VAL_ID = DE.AUTH_TP_ID 
		UNION
	   SELECT  ITEM_MST_ID
			 , ACCOUNT_ID
			 , BASE_DATE 
			 , CASE VE.INIT_VAL_CD 
				WHEN 'ANNUAL_QTY'		THEN ANNUAL_QTY
				WHEN 'BF_MEAS_QTY'		THEN BF_MEAS_QTY
				WHEN 'RTF_QTY'			THEN RTF_QTY
				WHEN 'YOY_QTY'			THEN YOY_QTY
				WHEN 'YTD_QTY'			THEN YTD_QTY 
				WHEN 'YTD_ANNUAL_QTY'	THEN YTD_ANNUAL_QTY
			   END				AS QTY 
			 , VE.AUTH_TP_ID	
	      FROM TB_DP_MEASURE_DATA ME 			
			   INNER JOIN
			   VER_INFO_DTL VE			 
			ON ME.BASE_DATE BETWEEN VE.FROM_DATE AND VE.TO_DATE
		  AND  VE.INIT_TP_CD = 'MS'			   
	)
--	, PREV_RT_HIS
--	AS (
--		SELECT ITEM_MST_ID
--			 , ACCOUNT_ID
--			 , BASE_DATE
--			 , QTY
--			 , EMP_ID 
--			 , VE.AUTH_TP_ID 
--		  FROM dbo.TB_DP_ENTRY_HISTORY RT
--			   INNER JOIN
--			   VER_INFO_DTL VE
--		    ON  VE.INIT_TP_CD = 'PR'
--		   AND RT.BASE_DATE BETWEEN VE.FROM_DATE AND VE.TO_DATE 
--		   AND RT.PLAN_TP_ID = p_PLAN_TP_ID
	 , CAL
	AS (
		SELECT MIN(DAT)	AS STRT_DT
			 , MAX(DAT) AS END_DT
		  FROM TB_CM_CALENDAR CAL
			   INNER JOIN
			   VER_INFO VER
			ON CAL.DAT BETWEEN VER.FROM_DATE AND VER.TO_DATE 
	  GROUP BY YYYY 
			 , CASE WHEN VER.BUKT IN ('W', 'PW') THEN TO_CHAR(DP_WK) ELSE '1' END
		     , CASE WHEN VER.BUKT IN ('M', 'PW') THEN TO_CHAR(MM) ELSE '1' END	   	
		), ITEM_HIER
	AS (
		SELECT ANCESTER_ID, ANCESTER_CD, DESCENDANT_ID, DESCENDANT_CD FROM TB_DPD_ITEM_HIER_CLOSURE WHERE LEAF_YN = 'Y' 
	), SALES_HIER
	AS (
		SELECT ANCESTER_ID, ANCESTER_CD, DESCENDANT_ID, DESCENDANT_CD FROM TB_DPD_SALES_HIER_CLOSURE WHERE LEAF_YN = 'Y' AND USE_YN = 'Y'
	), ITEM
	AS (-- 내 매핑 ITEM 찾기
		SELECT CASE WHEN CL.LEAF_YN = 'Y' THEN IM.ITEM_MST_ID ELSE IH.DESCENDANT_ID END	AS ID
			 , IM.AUTH_TP_ID ROLE_ID
			 , IM.EMP_ID
		  FROM TB_DP_USER_ITEM_MAP IM 
			   INNER JOIN
			   TB_CM_LEVEL_MGMT CL
			ON IM.LV_MGMT_ID = CL.ID 
		   AND CL.ACTV_YN = 'Y'
		   AND COALESCE(CL.DEL_YN, 'N') = 'N'
			   LEFT OUTER JOIN
			   ITEM_HIER IH
			ON CASE WHEN CL.LEAF_YN = 'Y' THEN NULL ELSE IH.ANCESTER_ID END = IM.ITEM_LV_ID
		 WHERE IM.ACTV_YN = 'Y'	    
	), ACCT
	AS (
		-- 내 매핑 ACCT 찾기
		SELECT CASE WHEN CL.LEAF_YN = 'Y' THEN AM.ACCOUNT_ID ELSE SH.DESCENDANT_ID END	AS ID
			 , AM.AUTH_TP_ID	ROLE_ID
			 , AM.EMP_ID
		  FROM TB_DP_USER_ACCOUNT_MAP AM 
			   INNER JOIN
			   TB_CM_LEVEL_MGMT CL
			ON AM.LV_MGMT_ID = CL.ID 
		   AND CL.ACTV_YN = 'Y'
		   AND COALESCE(CL.DEL_YN, 'N') = 'N'
			   LEFT OUTER JOIN
			   SALES_HIER SH
			ON CASE WHEN CL.LEAF_YN = 'Y' THEN NULL ELSE SH.ANCESTER_ID END = AM.SALES_LV_ID
		 WHERE AM.ACTV_YN = 'Y'	 
	), IA
	AS (
	   SELECT DISTINCT
			   ACCT.ROLE_ID 
			 , ACCT.ID		AS ACCT_ID
			 , ITEM.ID		AS ITEM_ID
		  FROM ACCT		-- ACCT_SH
			   INNER JOIN
			   ITEM		-- ITEM_SH 
			ON ACCT.ROLE_ID = ITEM.ROLE_ID
		   AND ACCT.EMP_ID = ITEM.EMP_ID
		UNION
		SELECT DISTINCT 
			   AUTH_TP_ID   
			 , ACCOUNT_ID
			 , ITEM_MST_ID
		  FROM TB_DP_USER_ITEM_ACCOUNT_MAP UIAM 
	)

		 SELECT TO_SINGLE_BYTE(SYS_GUID())							AS ID
			  , p_VER_ID										AS VER_ID 
			  , IA.ROLE_ID 
			  , IA.ITEM_ID	
			  , IA.ACCT_ID	
			  , CAL.STRT_DT										AS BASE_DATE 
			  , COALESCE(RT.QTY , 0)								AS QTY 
--			  , NULL 											AS AMT
			  , 'system'
			  ,  SYSDATE
			  , p_PLAN_TP_ID 
		   FROM IA 
		        CROSS JOIN
				CAL 
			    LEFT OUTER JOIN 
				RT		-- PREV_RT, MS
		     ON IA.ITEM_ID = RT.ITEM_MST_ID 
			AND IA.ACCT_ID = RT.ACCOUNT_ID 
			AND RT.BASE_DATE = CAL.STRT_DT  
			AND RT.AUTH_TP_ID = IA.ROLE_ID  
    ;
END;
/

