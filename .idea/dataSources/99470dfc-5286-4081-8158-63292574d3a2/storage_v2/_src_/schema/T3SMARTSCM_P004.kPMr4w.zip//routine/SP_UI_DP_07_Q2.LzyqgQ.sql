create PROCEDURE "SP_UI_DP_07_Q2" 
(
    P_FROM_DATE            IN   DATE
  , P_TO_DATE              IN   DATE
  , P_FROM_CURCY_CD_ID     IN   VARCHAR2
  , P_TO_CURCY_CD_ID       IN   VARCHAR2
  , P_CURCY_TP_ID          IN   VARCHAR2
  , P_BUCKET_CD            IN   VARCHAR2
  , pRESULT       OUT SYS_REFCURSOR         
) IS
/*************************************************************************************************************************
    Exchange Rate ？？？ ？？？ ？？？？？ ？？？ ？？？ν？？？
    - ？？？？？ : ？？？？？？ 
    - ？？？？？￥ : 2018.07.03
*************************************************************************************************************************/
    -- ？？？？？ ？？？？
--    P_BUCKET_CD     VARCHAR2(10) := '';
    V_FROM_DATE  DATE         := null;
    V_TO_DATE    DATE         := null;
BEGIN
    --------------------------------------------
        --01 BUCKET ？？？？？
    --------------------------------------------
--     SELECT COUNT(PP.POLICY_VAL)     INTO P_BUCKET_CD   
--      FROM TB_DP_PLAN_POLICY PP
--           LEFT OUTER JOIN
--           TB_CM_COMM_CONFIG BK
--        ON(PP.POLICY_ID = BK.ID)
--           LEFT OUTER JOIN
--           TB_CM_COMM_CONFIG PT
--        ON(PP.PLAN_TP_ID = PT.ID)   
--     WHERE 1=1
--       AND BK.CONF_GRP_CD = 'DP_POLICY'
--       AND BK.CONF_CD     = 'B'
--       AND PT.CONF_GRP_CD = 'DP_PLAN_TYPE'
--       AND PT.CONF_CD     = TRIM(P_BUCKET_CD)    -- 'DP_PLAN_MONTHLY'
--       ;
--    IF(P_BUCKET_CD != 0)
--        THEN
--
--    SELECT TRIM(PP.POLICY_VAL)     INTO P_BUCKET_CD   
--      FROM TB_DP_PLAN_POLICY PP
--           LEFT OUTER JOIN
--           TB_CM_COMM_CONFIG BK
--        ON(PP.POLICY_ID = BK.ID)
--           LEFT OUTER JOIN
--           TB_CM_COMM_CONFIG PT
--        ON(PP.PLAN_TP_ID = PT.ID)   
--     WHERE 1=1
--       AND BK.CONF_GRP_CD = 'DP_POLICY'
--       AND BK.CONF_CD     = 'B'
--       AND PT.CONF_GRP_CD = 'DP_PLAN_TYPE'
--       AND PT.CONF_CD     = TRIM(P_BUCKET_CD)    -- 'DP_PLAN_MONTHLY'
--       ;
--    ELSE
--        P_BUCKET_CD := 'NONE';
--    END IF;
----       P_BUCKET_CD := 'PW'; 
    ----------------------------------------------------------------------------------------------------------------------
        --02 ？？？？？？, ？？？？？？ BUCKET ？？？？？？ ？？？？？？
    ----------------------------------------------------------------------------------------------------------------------

    V_FROM_DATE := P_FROM_DATE;
    V_TO_DATE   := P_TO_DATE;
    ----------------------------------------------------------------------------------------------------------------------
        --03 ？？？？？ ？？？？ ？？￥？？ UNIT PRICE ？？？ν？？？ (M/W/PW/D)
    ----------------------------------------------------------------------------------------------------------------------
    IF (P_BUCKET_CD = 'YEAR') THEN
        OPEN pRESULT
        FOR
        SELECT P.FROM_CURCY_CD_ID
             , F.COMN_CD            AS FROM_CURCY_CD
             , F.COMN_CD_NM         AS FROM_CURCY_CD_NM
             , P.TO_CURCY_CD_ID
             , T.COMN_CD            AS TO_CURCY_CD
             , T.COMN_CD_NM         AS TO_CURCY_CD_NM
--                 , P.UNIT_UOM_VAL
             , C.DAT
             , MAX(P.BASE_DATE) -- DAT ？？ ？？ BAASE_DATE？？ ？？？？ ？？？？？？？？ ？？ ？？？？？？
             , MAX(P.EXCHANGE_RATE) KEEP(DENSE_RANK FIRST ORDER BY BASE_DATE DESC) AS EXCHANGE_RATE -- MAX(BASE_DATE) ？？ ？？？？ ？？？？ ROW？？ UTPIC？？ ？？
--                 , P.ID
          FROM TB_CM_CALENDAR C
               LEFT OUTER JOIN
               TB_DP_EXCHANGE_RATE P
            ON (C.DAT >= P.BASE_DATE)-- AND ADD_MONTHS(P.BASE_DATE, 1)> C.DAT) 
               LEFT OUTER JOIN
               TB_AD_COMN_CODE F
            ON (F.ID = P.FROM_CURCY_CD_ID)
               LEFT OUTER JOIN
               TB_AD_COMN_CODE T
            ON (T.ID = P.TO_CURCY_CD_ID)                
         WHERE 1=1
           AND DAT BETWEEN V_FROM_DATE AND V_TO_DATE
           AND DD = TO_NUMBER(TO_CHAR(V_FROM_DATE,'DD'))   -- ？？？ BUCKET
           AND MM = TO_NUMBER(TO_CHAR(V_FROM_DATE,'MM'))   -- ？？？ BUCKET
           AND P.CURCY_TP_ID = P_CURCY_TP_ID 
           AND (P.FROM_CURCY_CD_ID = P_FROM_CURCY_CD_ID OR RTRIM(P_FROM_CURCY_CD_ID) IS NULL)
           AND (P.TO_CURCY_CD_ID = P_TO_CURCY_CD_ID     OR RTRIM(P_TO_CURCY_CD_ID)   IS NULL)
           GROUP BY FROM_CURCY_CD_ID, F.COMN_CD, F.COMN_CD_NM, P.TO_CURCY_CD_ID, T.COMN_CD, T.COMN_CD_NM, DAT
           ORDER BY FROM_CURCY_CD_ID, TO_CURCY_CD_ID, DAT
        ;
    ELSIF (P_BUCKET_CD = 'MONTH')     --？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        THEN
            OPEN pRESULT  FOR
            SELECT P.FROM_CURCY_CD_ID
                 , F.COMN_CD            AS FROM_CURCY_CD
                 , F.COMN_CD_NM         AS FROM_CURCY_CD_NM
                 , P.TO_CURCY_CD_ID
                 , T.COMN_CD            AS TO_CURCY_CD
                 , T.COMN_CD_NM         AS TO_CURCY_CD_NM
--                 , P.UNIT_UOM_VAL
                 , C.DAT
                 , MAX(P.BASE_DATE) -- DAT ？？ ？？ BAASE_DATE？？ ？？？？ ？？？？？？？？ ？？ ？？？？？？
                 , MAX(P.EXCHANGE_RATE) KEEP(DENSE_RANK FIRST ORDER BY BASE_DATE DESC) AS EXCHANGE_RATE -- MAX(BASE_DATE) ？？ ？？？？ ？？？？ ROW？？ UTPIC？？ ？？
--                 , P.ID
              FROM TB_CM_CALENDAR C
                   LEFT OUTER JOIN
                   TB_DP_EXCHANGE_RATE P
                ON (C.DAT >= P.BASE_DATE)-- AND ADD_MONTHS(P.BASE_DATE, 1)> C.DAT) 
                   LEFT OUTER JOIN
                   TB_AD_COMN_CODE F
                ON (F.ID = P.FROM_CURCY_CD_ID)
                   LEFT OUTER JOIN
                   TB_AD_COMN_CODE T
                ON (T.ID = P.TO_CURCY_CD_ID)                
             WHERE 1=1
               AND DAT BETWEEN V_FROM_DATE AND V_TO_DATE
               AND DD = TO_NUMBER(TO_CHAR(V_FROM_DATE,'DD'))   -- ？？？ BUCKET
               AND P.CURCY_TP_ID = P_CURCY_TP_ID 
               AND (P.FROM_CURCY_CD_ID = P_FROM_CURCY_CD_ID OR RTRIM(P_FROM_CURCY_CD_ID) IS NULL)
               AND (P.TO_CURCY_CD_ID = P_TO_CURCY_CD_ID     OR RTRIM(P_TO_CURCY_CD_ID)   IS NULL)
               GROUP BY FROM_CURCY_CD_ID, F.COMN_CD, F.COMN_CD_NM, P.TO_CURCY_CD_ID, T.COMN_CD, T.COMN_CD_NM, DAT
               ORDER BY FROM_CURCY_CD_ID, TO_CURCY_CD_ID, DAT
                ;
    ELSIF (P_BUCKET_CD = 'WEEK') --？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        THEN
            OPEN pRESULT  FOR
                    SELECT P.FROM_CURCY_CD_ID
                         , F.COMN_CD            AS FROM_CURCY_CD
                         , F.COMN_CD_NM         AS FROM_CURCY_CD_NM
                         , P.TO_CURCY_CD_ID
                         , T.COMN_CD            AS TO_CURCY_CD
                         , T.COMN_CD_NM         AS TO_CURCY_CD_NM
--                         , P.UNIT_UOM_VAL
                         , C.DAT
                         , MAX(P.BASE_DATE) -- DAT ？？ ？？ BAASE_DATE？？ ？？？？ ？？？？？？？？ ？？ ？？？？？？
                         , MAX(P.EXCHANGE_RATE) KEEP(DENSE_RANK FIRST ORDER BY BASE_DATE DESC) AS EXCHANGE_RATE -- MAX(BASE_DATE) ？？ ？？？？ ？？？？ ROW？？ UTPIC？？ ？？
        --                 , P.ID
                      FROM TB_CM_CALENDAR C
                           LEFT OUTER JOIN
                           TB_DP_EXCHANGE_RATE P
                        ON (C.DAT >= P.BASE_DATE)-- AND ADD_MONTHS(P.BASE_DATE, 1)> C.DAT) 
                           LEFT OUTER JOIN
                           TB_AD_COMN_CODE F
                        ON (F.ID = P.FROM_CURCY_CD_ID)
                           LEFT OUTER JOIN
                           TB_AD_COMN_CODE T
                        ON (T.ID = P.TO_CURCY_CD_ID)                
                     WHERE 1=1
                       AND DAT BETWEEN V_FROM_DATE AND V_TO_DATE
                       AND DOW_NM = ( SELECT UPPER(CONF_CD) FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_STD_WEEK' AND ACTV_YN = 'Y' AND USE_YN = 'Y' )
                       -- TO_NUMBER(TO_CHAR(TO_DATE(V_FROM_DATE, 'YY/MM/DD'),'D')) -- ？？？？？？ BUCKET
                                      AND P.CURCY_TP_ID = P_CURCY_TP_ID
               AND (P.FROM_CURCY_CD_ID = P_FROM_CURCY_CD_ID OR RTRIM(P_FROM_CURCY_CD_ID) IS NULL)
               AND (P.TO_CURCY_CD_ID = P_TO_CURCY_CD_ID     OR RTRIM(P_TO_CURCY_CD_ID)   IS NULL)
               GROUP BY FROM_CURCY_CD_ID, F.COMN_CD, F.COMN_CD_NM, P.TO_CURCY_CD_ID, T.COMN_CD, T.COMN_CD_NM, DAT
               ORDER BY FROM_CURCY_CD_ID, TO_CURCY_CD_ID, DAT
                ;
    ELSIF (P_BUCKET_CD = 'PAR_WEEK') --？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
          THEN
            OPEN pRESULT  FOR
                    SELECT P.FROM_CURCY_CD_ID
                         , F.COMN_CD            AS FROM_CURCY_CD
                         , F.COMN_CD_NM         AS FROM_CURCY_CD_NM
                         , P.TO_CURCY_CD_ID
                         , T.COMN_CD            AS TO_CURCY_CD
                         , T.COMN_CD_NM         AS TO_CURCY_CD_NM
--                         , P.UNIT_UOM_VAL
                         , C.DAT
                         , MAX(P.BASE_DATE) -- DAT ？？ ？？ BAASE_DATE？？ ？？？？ ？？？？？？？？ ？？ ？？？？？？
                         , MAX(P.EXCHANGE_RATE) KEEP(DENSE_RANK FIRST ORDER BY BASE_DATE DESC) AS EXCHANGE_RATE -- MAX(BASE_DATE) ？？ ？？？？ ？？？？ ROW？？ UTPIC？？ ？？
        --                 , P.ID
                      FROM TB_CM_CALENDAR C
                           LEFT OUTER JOIN
                           TB_DP_EXCHANGE_RATE P
                        ON (C.DAT >= P.BASE_DATE)-- AND ADD_MONTHS(P.BASE_DATE, 1)> C.DAT) 
                           LEFT OUTER JOIN
                           TB_AD_COMN_CODE F
                        ON (F.ID = P.FROM_CURCY_CD_ID)
                           LEFT OUTER JOIN
                           TB_AD_COMN_CODE T
                        ON (T.ID = P.TO_CURCY_CD_ID)                
                     WHERE 1=1
                       AND DAT BETWEEN V_FROM_DATE AND V_TO_DATE
                       AND (   DOW_NM = ( SELECT UPPER(CONF_CD) FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_STD_WEEK' AND ACTV_YN = 'Y' AND USE_YN = 'Y' )
                            OR  DD = 1)
                            AND P.CURCY_TP_ID = P_CURCY_TP_ID
               AND (P.FROM_CURCY_CD_ID = P_FROM_CURCY_CD_ID OR RTRIM(P_FROM_CURCY_CD_ID) IS NULL)
               AND (P.TO_CURCY_CD_ID = P_TO_CURCY_CD_ID     OR RTRIM(P_TO_CURCY_CD_ID)   IS NULL)
               GROUP BY FROM_CURCY_CD_ID, F.COMN_CD, F.COMN_CD_NM, P.TO_CURCY_CD_ID, T.COMN_CD, T.COMN_CD_NM, DAT
               ORDER BY FROM_CURCY_CD_ID, TO_CURCY_CD_ID, DAT
                ;


    ELSIF (P_BUCKET_CD = 'DAY')     --？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        THEN    
            OPEN pRESULT  FOR
            SELECT P.FROM_CURCY_CD_ID
                 , F.COMN_CD            AS FROM_CURCY_CD
                 , F.COMN_CD_NM         AS FROM_CURCY_CD_NM
                 , P.TO_CURCY_CD_ID
                 , T.COMN_CD            AS TO_CURCY_CD
                 , T.COMN_CD_NM         AS TO_CURCY_CD_NM
--                 , P.UNIT_UOM_VAL
                 , C.DAT
                 , MAX(P.BASE_DATE) -- DAT ？？ ？？ BAASE_DATE？？ ？？？？ ？？？？？？？？ ？？ ？？？？？？
                 , MAX(P.EXCHANGE_RATE) KEEP(DENSE_RANK FIRST ORDER BY BASE_DATE DESC) AS EXCHANGE_RATE -- MAX(BASE_DATE) ？？ ？？？？ ？？？？ ROW？？ UTPIC？？ ？？
--                 , P.ID
              FROM TB_CM_CALENDAR C
                   LEFT OUTER JOIN
                   TB_DP_EXCHANGE_RATE P
                ON (C.DAT >= P.BASE_DATE)-- AND ADD_MONTHS(P.BASE_DATE, 1)> C.DAT) 
                   LEFT OUTER JOIN
                   TB_AD_COMN_CODE F
                ON (F.ID = P.FROM_CURCY_CD_ID)
                   LEFT OUTER JOIN
                   TB_AD_COMN_CODE T
                ON (T.ID = P.TO_CURCY_CD_ID)                
             WHERE 1=1
               AND DAT BETWEEN V_FROM_DATE AND V_TO_DATE
               AND P.CURCY_TP_ID = P_CURCY_TP_ID
               AND (P.FROM_CURCY_CD_ID = P_FROM_CURCY_CD_ID OR RTRIM(P_FROM_CURCY_CD_ID) IS NULL)
               AND (P.TO_CURCY_CD_ID = P_TO_CURCY_CD_ID     OR RTRIM(P_TO_CURCY_CD_ID)   IS NULL)
               GROUP BY FROM_CURCY_CD_ID, F.COMN_CD, F.COMN_CD_NM, P.TO_CURCY_CD_ID, T.COMN_CD, T.COMN_CD_NM, DAT
               ORDER BY FROM_CURCY_CD_ID, TO_CURCY_CD_ID, DAT
                ;

            ELSE
                   OPEN pRESULT  FOR
                SELECT 'NO BUCKET' FROM DUAL;
    END IF;
END
;

/

