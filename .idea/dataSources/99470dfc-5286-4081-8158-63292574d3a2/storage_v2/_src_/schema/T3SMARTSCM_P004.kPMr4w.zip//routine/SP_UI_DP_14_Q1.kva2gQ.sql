create PROCEDURE "SP_UI_DP_14_Q1" (
    p_ACCT_LV   IN VARCHAR2  := ''
  , p_ACCT_CD   IN VARCHAR2 := ''
  , pRESULT     OUT SYS_REFCURSOR
) IS

/** PARAMETER ???？**********************************************************************************************************/
    p_SEQ INT := NULL;
    p_COLUMN_CNT INT := 0;
    p_SQL VARCHAR2(3000) := 'SELECT ''' || p_ACCT_LV || ''' AS LV_MGMT_CD, ';
    p_WHILE_CNT INT := 1 ;
    p_COLUMN_NM VARCHAR2(100) := NULL;
    p_COUNT    INT := 3    ;-- COLUMN ?????? ??？?？?？ COUNT
    p_COLUMN_NM_CNT INT := NULL; 
    p_WHILE_CNT_02 INT := 1;
BEGIN
/*LV_CD?？SEQ ？？ ******************************************************************************************************************************************/
    IF(p_ACCT_LV IS NOT NULL) THEN
        SELECT MAX(ROWNUM) INTO P_SEQ
          FROM TB_CM_LEVEL_MGMT
         WHERE 1=1
           AND ACCOUNT_LV_YN = 'Y'
           AND ACTV_YN = 'Y'
           AND SEQ <= (
            SELECT SEQ
              FROM TB_CM_LEVEL_MGMT
             WHERE LV_CD = p_ACCT_LV
           );        
    ELSE
        SELECT  MAX(ROWNUM) INTO P_SEQ
          FROM TB_CM_LEVEL_MGMT
         WHERE 1=1
           AND ACCOUNT_LV_YN = 'Y'
           AND ACTV_YN = 'Y';
    END IF;
/*NULL ?？？COLUMN ???? COUNT ****************************************************************************************************************************/
    SELECT COUNT(*) INTO P_COLUMN_CNT
      FROM (
        SELECT NM
          FROM TB_DPD_ACCOUNT_HIERACHY2 MAIN
        UNPIVOT (
            VALUE FOR NM IN (
                 LVL01_NM     
               , LVL02_NM     
               , LVL03_NM     
               , LVL04_NM     
               , LVL05_NM     
               , LVL06_NM    
               , LVL07_NM     
               , LVL08_NM     
               , LVL09_NM     
               , LVL10_NM
            )
        ) UNPVT
        WHERE USE_YN = 'Y'
         GROUP BY NM
    ) RESULT;

/*ACCOUNT_LV???？UNT ???? SET *******************************************************************************************************************************/
    SELECT  MIN(ROWNUM) INTO P_COLUMN_NM_CNT
      FROM TB_CM_LEVEL_MGMT
     WHERE 1=1
       AND ACCOUNT_LV_YN = 'Y'
       AND ACTV_YN = 'Y';

    SELECT A.LV_NM INTO P_COLUMN_NM
      FROM (
        SELECT LV_NM, ROW_NUMBER() OVER (ORDER BY SEQ) AS R0WNU
          FROM TB_CM_LEVEL_MGMT
         WHERE 1=1
           AND ACCOUNT_LV_YN = 'Y'
           AND ACTV_YN = 'Y'
      ) A
     WHERE A.R0WNU = P_COLUMN_NM_CNT;
--SELECT P_COLUMN_NM = LV_NM 
--  FROM TB_CM_LEVEL_MGMT 
-- WHERE 1=1
-- AND ACCOUNT_LV_YN = 'Y'
-- AND ACTV_YN = 'Y'
-- AND SEQ = P_COLUMN_NM_CNT
-- AND (LV_CD !=NULL OR LV_CD!='')


    IF(P_COLUMN_CNT<=10) THEN
        P_COLUMN_CNT := P_SEQ-P_COLUMN_NM_CNT+1;
    ELSE
        P_COLUMN_CNT := P_COLUMN_CNT;
    END IF;

/*COUNT?？COLUMN?? SELECT ****************************************************************************************************************************************************************************/

     P_SQL := P_SQL || 'LVL'||LPAD(TO_CHAR(p_WHILE_CNT),2,'0')||'_CD    AS "A_SEQ001'||P_COLUMN_NM||',CD", '
                    || 'LVL'||LPAD(TO_CHAR(p_WHILE_CNT),2,'0')||'_NM    AS "A_SEQ002'||P_COLUMN_NM||',NM" ';

    WHILE(P_WHILE_CNT < P_COLUMN_CNT)
    LOOP
        IF (P_WHILE_CNT < P_COLUMN_CNT)
        THEN
            P_SQL := P_SQL||', ';
        END IF;
        P_WHILE_CNT := P_WHILE_CNT+1;
        P_COLUMN_NM_CNT := P_COLUMN_NM_CNT+1;

        SELECT A.LV_NM INTO P_COLUMN_NM
          FROM (
            SELECT LV_NM, ROW_NUMBER() OVER (ORDER BY SEQ) AS R0WNU
              FROM TB_CM_LEVEL_MGMT
             WHERE 1=1
               AND ACCOUNT_LV_YN = 'Y'
               AND ACTV_YN = 'Y'
          ) A
         WHERE A.R0WNU = P_COLUMN_NM_CNT;

        P_SQL := P_SQL || 'LVL'||LPAD(TO_CHAR(p_WHILE_CNT),2,'0')||'_CD    AS "A_SEQ'|| LPAD(TO_CHAR(p_COUNT),3,'0')||p_COLUMN_NM||',CD", '
                       || 'LVL'||LPAD(TO_CHAR(p_WHILE_CNT),2,'0')||'_NM    AS "A_SEQ'|| LPAD(TO_CHAR(p_COUNT+1),3,'0')||p_COLUMN_NM||',NM"';
        P_COUNT := P_COUNT+2;
    END LOOP;

--    IF((P_SEQ = (SELECT SEQ FROM TB_CM_LEVEL_MGMT WHERE 1=1 AND ACCOUNT_LV_YN = 'N' AND ACCOUNT_LV_YN = 'N' AND LEAF_YN = 'Y')) OR LTRIM(RTRIM(p_ACCT_LV)) = '' OR p_ACCT_LV = NULL)


    SELECT ROW_NUMBER() OVER (ORDER BY SEQ) INTO P_COLUMN_NM
      FROM TB_CM_LEVEL_MGMT
     WHERE 1=1
       AND ACCOUNT_LV_YN = 'Y'
       AND ACTV_YN = 'Y'
       AND LEAF_YN = 'Y';
--            SELECT P_COLUMN_NM = LV_NM 
--              FROM TB_CM_LEVEL_MGMT 
--             WHERE 1=1
--             AND ACCOUNT_LV_YN = 'Y'
--             AND ACTV_YN = 'Y'
--             AND LEAF_YN = 'Y'
    P_SQL := P_SQL || ',LVL'||LPAD(TO_CHAR(p_WHILE_CNT),2,'0')||'_CD    AS KEY_ACCOUNT_CD, '
                   ||  'LVL'||LPAD(TO_CHAR(p_WHILE_CNT),2,'0')||'_ID    AS KEY_ACCOUNT_ID,'
                   ||  'LVL'||LPAD(TO_CHAR(p_WHILE_CNT),2,'0')||'_NM    AS KEY_ACCOUNT_NM';


    P_SQL := P_SQL || ' FROM TB_DPD_ACCOUNT_HIERACHY2 WHERE USE_YN = ''Y'' AND '''||p_ACCT_CD||''' IS NULL '
                   || ' OR REGEXP_LIKE (UPPER(ACCOUNT_CD), '''||REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')||''')' 
                   || ' GROUP BY ';

/*GROUP BY ===============================================================================================================================================================================*/
    WHILE(P_WHILE_CNT_02 <= P_COLUMN_CNT)
    LOOP
        P_SQL := P_SQL || 'LVL'||LPAD(TO_CHAR(p_WHILE_CNT_02),2,'0')||'_CD, '
                       || 'LVL'||LPAD(TO_CHAR(p_WHILE_CNT_02),2,'0')||'_NM';
        IF (P_WHILE_CNT_02 < P_COLUMN_CNT) THEN
            P_SQL := P_SQL||', ';
        END IF;
             P_WHILE_CNT_02 := P_WHILE_CNT_02+1    ;                        
    END LOOP;
            P_SQL := p_SQL || ' ,LVL'||LPAD(TO_CHAR(p_WHILE_CNT_02-1),2,'0')||'_ID ';
    BEGIN
      --OPEN pRESULT FOR SELECT p_SQL FROM DUAL;
        OPEN pRESULT FOR p_SQL;
    END;
END;
/

