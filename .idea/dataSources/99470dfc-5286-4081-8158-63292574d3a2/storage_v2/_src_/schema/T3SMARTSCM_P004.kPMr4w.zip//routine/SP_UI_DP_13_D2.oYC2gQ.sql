create PROCEDURE "SP_UI_DP_13_D2" (
    p_ID                IN VARCHAR2     := ''         
  , p_USER_ID           IN VARCHAR2      := ''      
  , P_RT_ROLLBACK_FLAG  OUT VARCHAR2  
  , P_RT_MSG            OUT VARCHAR2	
) 
IS 
	P_ERR_STATUS NUMBER := 0;
    P_ERR_MSG VARCHAR2(4000):='';
BEGIN
	  -- ？？？ν？？？ ？？？？ 

    DELETE FROM TB_DP_USER_ITEM_MAP
	 WHERE ID = p_ID
    ; 

	  -- ？？？ν？？？ ？？？？ 
    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0002';  --？？？？ ？？？？？？？？.
       /* ？？？？ o？？ ============================================================================*/

EXCEPTION WHEN OTHERS THEN  -- ？？？ ？？？？？？？ ？？？？ ？？？？ ？？？？ : e_products_invalid    
    IF(SQLCODE = -20001) THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
    --SP_COMM_RAISE_ERR();              
        RAISE;
    END IF; 
END;

/

