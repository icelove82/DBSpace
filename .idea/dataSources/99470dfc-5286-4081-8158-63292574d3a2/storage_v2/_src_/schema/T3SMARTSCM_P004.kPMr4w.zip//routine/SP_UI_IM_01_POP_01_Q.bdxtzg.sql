create PROCEDURE "SP_UI_IM_01_POP_01_Q" (
    P_CONF_KEY  IN VARCHAR2 := '',
    P_MODULE_CD IN VARCHAR2 := '',
	pResult     OUT SYS_REFCURSOR
)
IS
BEGIN
	
     IF P_CONF_KEY ='301' /*Planning Horizon & Time Bucket*/
     THEN
      OPEN pResult
      FOR SELECT  B.ID
				 ,C.ID AS PLAN_SNRIO_MGMT_MST_ID
				 ,D.COMN_CD_NM AS MODULE_NM
 			     ,C.SNRIO_VER_ID AS SNRIO_VER_ID
			     ,C.DESCRIP AS SNRIO_DESCRIP
		  	 	 ,B.TIME_UOM_ID	AS TIME_BUCKET
                 ,B.STRT_DATE_TP_ID AS STRT_DATE_TP
                 ,B.DAY_OF_WEEK_ID AS DAY_OF_WEEK
                 ,B.STRT_TIME
      	     	 ,B.DURA
                 ,B.BUCKET_TP_VAL
                 ,B.VAR_TIME_UOM_ID AS VAR_TIME_BUCKET
                 ,B.DURA2
                 ,B.STRT_DATE
                 ,B.STRT_DATE2
                 ,B.END_DATE
                 ,B.DESCRIP
                 ,NVL(B.ACTV_YN,'N') AS ACTV_YN
                 ,B.CREATE_BY
                 ,B.CREATE_DTTM
                 ,B.MODIFY_BY
                 ,B.MODIFY_DTTM
          FROM  TB_CM_CONFIGURATION A
            	INNER JOIN TB_CM_HORIZON_TIME_BUCKET B
                ON A.ID = B.CONF_ID
            	INNER JOIN TB_CM_PLAN_SNRIO_MGMT_MST C
              	ON C.ID = B.PLAN_SNRIO_MGMT_MST_ID
				INNER JOIN TB_AD_COMN_CODE D
			  	ON D.ID = C.MODULE_ID
		  WHERE D.COMN_CD = CASE WHEN P_MODULE_CD IN ('IM','RP','MP') THEN P_MODULE_CD ELSE TO_CHAR(D.COMN_CD) END;
              
      ELSIF P_CONF_KEY ='302'
      THEN
      OPEN pResult
      FOR SELECT  
				 F.ID
				,E.INV_ANLY_PRIOD_ID		AS PERIOD_TP
				,E.LOCAT_ID					AS LOCAT_ID
				,E.LOCAT_TP_NM
				,E.LOCAT_LV
				,E.LOCAT_CD
				,E.LOCAT_NM
				,F.PERIOD_VAL				AS PERIOD
				,F.ACTV_YN
				,F.UOM_ID
				,F.WTFAR
				,F.CREATE_BY
				,F.CREATE_DTTM
				,F.MODIFY_BY
				,F.MODIFY_DTTM
			FROM  
				(	SELECT  
						 A.COMN_CD_NM	AS LOCAT_TP_NM
						,B.LOCAT_LV
						,C.LOCAT_CD
						,C.LOCAT_NM
						,C.ID			AS LOCAT_ID
						,D.ID			AS LOCAT_MGMT_ID
						,D.ACTV_YN
						,A.SEQ
						,E.ID           AS INV_ANLY_PRIOD_ID
						,E.COMN_CD_NM   AS PERIOD_TP
						,E.DISPLAY_SEQ
					FROM 
						TB_AD_COMN_CODE A 
						INNER JOIN TB_CM_LOC_MST B ON (A.ID = B.LOCAT_TP_ID)
						INNER JOIN TB_CM_LOC_DTL C ON (B.ID = C.LOCAT_MST_ID)
						INNER JOIN TB_CM_LOC_MGMT D ON (C.ID = D.LOCAT_ID)
						,(	SELECT 
								G.ID, G.COMN_CD, G.COMN_CD_NM, G.SEQ AS DISPLAY_SEQ
							FROM 
								TB_AD_COMN_GRP F 
								INNER JOIN TB_AD_COMN_CODE G ON F.GRP_CD = 'INV_ANLY_PRIOD' 
															AND F.ID = G.SRC_ID
						) E
					WHERE 
						1=1
						AND B.ACTV_YN = 'Y'
						AND C.ACTV_YN = 'Y'
						AND D.ACTV_YN = 'Y'
				) E
				LEFT OUTER JOIN TB_IM_INV_ANLY_PRIOD F ON E.LOCAT_ID = F.LOCAT_ID 
													  AND E.INV_ANLY_PRIOD_ID = F.INV_ANLY_PRIOD_ID
													  AND F.CATAGY_VAL = 'DEMAND_VARIABILITY'
			ORDER BY E.SEQ, E.LOCAT_LV, E.LOCAT_CD, E.DISPLAY_SEQ;

    ELSIF P_CONF_KEY ='303'
    THEN
        OPEN pResult FOR 
            SELECT  
                 E.ID			
                ,D.ID			AS LOCAT_ID
				,B.COMN_CD_NM	AS LOCAT_TP_NM
      			,C.LOCAT_LV
      			,D.LOCAT_CD
      			,D.LOCAT_NM
      			,E.ACTV_YN
				,E.QUADRANT_BASE_ID AS BASE
				,E.COV_BDV
				,E.SALES_QTY_BDV
				,E.REVENUE_BDV
				,E.SVC_LV_01
				,E.SVC_LV_02
				,E.SVC_LV_03
				,E.SVC_LV_04
      			,E.CREATE_BY
      			,E.CREATE_DTTM
      			,E.MODIFY_BY
      			,E.MODIFY_DTTM
            FROM  
                TB_AD_COMN_GRP A
				INNER JOIN TB_AD_COMN_CODE B
                ON A.ID = B.SRC_ID
				INNER JOIN TB_CM_LOC_MST C
                ON B.ID = C.LOCAT_TP_ID
				INNER JOIN TB_CM_LOC_DTL D
                ON C.ID = D.LOCAT_MST_ID 
				LEFT OUTER JOIN TB_IM_DMND_VARIABILITY_BASE E
				ON D.ID = E.LOCAT_ID
				LEFT OUTER JOIN (
                                SELECT G.ID, G.COMN_CD, G.COMN_CD_NM
                                FROM   TB_AD_COMN_GRP F, TB_AD_COMN_CODE G
                                WHERE  F.GRP_CD = 'QUADRANT_BASE'
                                   AND F.ID = G.SRC_ID
                                ) F
                ON E.QUADRANT_BASE_ID = F.ID
            WHERE 
                1=1
                AND A.GRP_CD = 'LOC_TP'
                AND B.USE_YN ='Y'
                AND D.ACTV_YN='Y';	

    ELSIF P_CONF_KEY ='304' /* Inventory Grade Analysis -  Deman Plan / Actual Shipment Period */
    THEN
    OPEN pResult
    FOR SELECT  F.ID
				, E.INV_ANLY_PRIOD_ID   AS PERIOD_TP
				, E.LOCAT_ID			AS LOCAT_ID
				, E.LOCAT_TP_NM
				, E.LOCAT_LV
				, E.LOCAT_CD
				, E.LOCAT_NM
                , PERIOD_VAL            AS PERIOD
				, F.ACTV_YN			 
                , F.UOM_ID
				, F.WTFAR
		 		, F.CREATE_BY
		 		, F.CREATE_DTTM
		 		, F.MODIFY_BY
		 		, F.MODIFY_DTTM
			FROM  (
					SELECT  A.COMN_CD_NM AS LOCAT_TP_NM
						   ,B.LOCAT_LV
        				   ,C.LOCAT_CD
        				   ,C.LOCAT_NM
						   ,C.ID AS LOCAT_ID
        				   ,D.ID AS LOCAT_MGMT_ID
        				   ,D.ACTV_YN
						   ,A.SEQ
						   ,E.ID            AS INV_ANLY_PRIOD_ID
						   ,E.COMN_CD_NM	AS PERIOD_TP
						   ,E.DISPLAY_SEQ
					  FROM TB_AD_COMN_CODE A
						   INNER JOIN 
						   TB_CM_LOC_MST B
        				ON (A.ID = B.LOCAT_TP_ID)
        				   INNER JOIN 
        				   TB_CM_LOC_DTL C
        				ON (B.ID = C.LOCAT_MST_ID)
        				   INNER JOIN 
        					TB_CM_LOC_MGMT D
        				ON (C.ID = D.LOCAT_ID)
						  ,(SELECT G.ID, G.COMN_CD, G.COMN_CD_NM, G.SEQ AS DISPLAY_SEQ
							  FROM TB_AD_COMN_GRP F
                                   INNER JOIN TB_AD_COMN_CODE G
                                    ON F.GRP_CD = 'INV_ANLY_PRIOD'
                                    AND F.ID = G.SRC_ID) E
					 WHERE 1=1
					   AND B.ACTV_YN = 'Y'
					   AND C.ACTV_YN = 'Y'
					   AND D.ACTV_YN = 'Y'
				   ) E					
                   LEFT OUTER JOIN TB_IM_INV_ANLY_PRIOD F
				   ON E.LOCAT_ID = F.LOCAT_ID
				   AND E.INV_ANLY_PRIOD_ID = F.INV_ANLY_PRIOD_ID
                   AND F.CATAGY_VAL = 'INV_CLASS'
			ORDER BY E.SEQ, E.LOCAT_LV, E.LOCAT_CD, E.DISPLAY_SEQ;

    ELSIF P_CONF_KEY ='306'
    THEN
    OPEN pResult
    FOR SELECT   E.ID
				,D.ID					AS LOCAT_ID
				,B.COMN_CD_NM			AS LOCAT_TP_NM
      			,C.LOCAT_LV
      			,D.LOCAT_CD
      			,D.LOCAT_NM
				,E.TARGET_SVC_CAL_BASE_ID	AS TARGET_SVC_CAL_BASE
				,E.ACTV_YN
      			,E.CREATE_BY
      			,E.CREATE_DTTM
      			,E.MODIFY_BY
      			,E.MODIFY_DTTM
			FROM TB_AD_COMN_GRP A
				 INNER JOIN TB_AD_COMN_CODE B
                 ON A.ID = B.SRC_ID
				 INNER JOIN TB_CM_LOC_MST C
                 ON B.ID = C.LOCAT_TP_ID
				 INNER JOIN TB_CM_LOC_DTL D
                 ON C.ID = D.LOCAT_MST_ID
				 LEFT OUTER JOIN 
				 TB_IM_TARGET_SVC_CAL_BASE E
				 ON D.ID = E.LOCAT_ID  
						LEFT OUTER JOIN 
						(SELECT G.ID, G.COMN_CD, G.COMN_CD_NM
						   FROM TB_AD_COMN_GRP F
							   INNER JOIN TB_AD_COMN_CODE G
                                     ON F.GRP_CD = 'TARGET_SVC_CAL_BASE_TP'
                                 	AND F.ID = G.SRC_ID) F
							ON E.TARGET_SVC_CAL_BASE_ID = F.ID
		   WHERE 1=1
			 AND A.GRP_CD = 'LOC_TP'
			 AND B.USE_YN ='Y'
             AND D.ACTV_YN='Y';

   ELSIF P_CONF_KEY ='307'
   THEN
   OPEN pResult
   FOR SELECT B.ID
             ,A.ID					AS CONF_ID
             ,B.SVC_LV
             ,B.SAFTFCT
             ,NVL(B.ACTV_YN,'N') AS ACTV_YN
             ,B.CREATE_BY
      		 ,B.CREATE_DTTM
      		 ,B.MODIFY_BY
      		 ,B.MODIFY_DTTM
			FROM TB_CM_CONFIGURATION A
				 INNER JOIN TB_IM_SVC_SAFTFCT_BASE B
                 ON A.ID = B.CONF_ID
			 AND A.CONF_KEY = P_CONF_KEY;

    ELSIF P_CONF_KEY ='308'
    THEN
    OPEN pResult
    FOR SELECT  E.ID
				,D.ID				AS LOCAT_ID
				,B.COMN_CD_NM		AS LOCAT_TP_NM
      			,C.LOCAT_LV
      			,D.LOCAT_CD
      			,D.LOCAT_NM
      			,E.ACTUAL_PERIOD
      			,(SELECT A.ID FROM TB_CM_UOM A WHERE A.ID = E.UOM_ID) AS UOM_NM
      			,E.ACTV_YN
      			,E.CREATE_BY
      			,E.CREATE_DTTM
      			,E.MODIFY_BY
      			,E.MODIFY_DTTM
			FROM TB_AD_COMN_GRP A
				 INNER JOIN TB_AD_COMN_CODE B
                 ON A.ID = B.SRC_ID
				 INNER JOIN TB_CM_LOC_MST C
                 ON B.ID = C.LOCAT_TP_ID
				 INNER JOIN TB_CM_LOC_DTL D
                 ON C.ID = D.LOCAT_MST_ID
					LEFT OUTER JOIN 
					TB_IM_VARIABILITY_ACT_PRIOD E
					ON D.ID = E.LOCAT_ID
					AND E.CATAGY_VAL='SUPPLY_VARIABILITY'
		   WHERE 1=1
			 AND A.GRP_CD = 'LOC_TP'
			 AND B.USE_YN ='Y'
             AND D.ACTV_YN='Y';

    ELSIF P_CONF_KEY ='309'
    THEN
    OPEN pResult
    FOR SELECT C.ID
              ,C.MGMT_NM
			  ,C.SEQ
              ,C.ACTV_YN
              ,C.CREATE_BY
              ,C.CREATE_DTTM
              ,C.MODIFY_BY
              ,C.MODIFY_DTTM
          FROM TB_CM_CONFIGURATION A
               INNER JOIN TB_IM_SEGMT_DIM_MST B
               ON A.ID = B.CONF_ID
               INNER JOIN TB_IM_SEGMT_DIM_DTL C
               ON B.ID = C.INV_MGMT_SEGMT_DIM_MST_ID
         WHERE 1=1
           AND B.SEGMT_DIM_CD = 'VAL_02'
         ORDER BY C.SEQ;             

    ELSIF P_CONF_KEY ='310'
    THEN
    OPEN pResult
     FOR SELECT  E.ID
				 ,D.ID			AS LOCAT_ID
				 ,B.COMN_CD_NM	AS LOCAT_TP_NM
      			 ,C.LOCAT_LV
      			 ,D.LOCAT_CD
      			 ,D.LOCAT_NM
				 ,E.CAL_MTD_ID	AS CAL_TP_ID
      			 ,E.ACTV_YN
      			 ,E.DEFAT_VAL_YN	AS DEFAT_VAL
      			 ,E.CREATE_BY
      			 ,E.CREATE_DTTM
      			 ,E.MODIFY_BY
      			 ,E.MODIFY_DTTM
			FROM TB_AD_COMN_GRP A
				 INNER JOIN TB_AD_COMN_CODE B
                 ON A.ID = B.SRC_ID
				 INNER JOIN TB_CM_LOC_MST C
                 ON B.ID = C.LOCAT_TP_ID
				 INNER JOIN TB_CM_LOC_DTL D
                 ON C.ID = D.LOCAT_MST_ID
					LEFT OUTER JOIN
					TB_IM_CAL_METHOD_INFO E
					ON D.ID = E.LOCAT_ID
					AND E.CATAGY_VAL ='AVG_SUPPLY_LT_CAL_METHOD'
					LEFT OUTER JOIN 
					(SELECT G.ID, G.COMN_CD, G.COMN_CD_NM
						FROM TB_AD_COMN_GRP F
							INNER JOIN TB_AD_COMN_CODE G
						ON F.GRP_CD = 'AVG_SUPPLY_LT_CAL_METHOD'
						AND F.ID = G.SRC_ID) F
					ON E.CAL_MTD_ID = F.ID
		   WHERE 1=1
			 AND A.GRP_CD = 'LOC_TP'
			 AND B.USE_YN ='Y'
             AND D.ACTV_YN='Y';

    ELSIF P_CONF_KEY ='311'
    THEN
    OPEN pResult
     FOR SELECT E.ID
				,D.ID			AS LOCAT_ID
				,B.COMN_CD_NM	AS LOCAT_TP_NM
      			,C.LOCAT_LV
      			,D.LOCAT_CD
      			,D.LOCAT_NM
      			,E.CAL_MTD_ID	AS CAL_TP_ID
      			,E.ACTV_YN
      			,E.DEFAT_VAL_YN	AS DEFAT_VAL
      			,E.CREATE_BY
      			,E.CREATE_DTTM
      			,E.MODIFY_BY
      			,E.MODIFY_DTTM
			FROM TB_AD_COMN_GRP A
				INNER JOIN TB_AD_COMN_CODE B
                ON A.ID = B.SRC_ID
				INNER JOIN TB_CM_LOC_MST C
                ON B.ID = C.LOCAT_TP_ID
				INNER JOIN TB_CM_LOC_DTL D
                ON C.ID = D.LOCAT_MST_ID
					LEFT OUTER JOIN 
					TB_IM_CAL_METHOD_INFO E
					ON D.ID = E.LOCAT_ID
					AND E.CATAGY_VAL ='AVG_TRANSF_COST_CAL_METHOD'
					LEFT OUTER JOIN
					(SELECT G.ID, G.COMN_CD, G.COMN_CD_NM
					   FROM TB_AD_COMN_GRP F
						   INNER JOIN TB_AD_COMN_CODE G
                                 ON F.GRP_CD = 'AVG_TRANSF_COST_CAL_METHOD'
                            	 AND F.ID = G.SRC_ID) F
					ON E.CAL_MTD_ID = F.ID
			WHERE 1=1
				 AND A.GRP_CD = 'LOC_TP'
				 AND B.USE_YN ='Y'
                 AND D.ACTV_YN='Y';

    ELSIF P_CONF_KEY ='312'
    THEN
    OPEN pResult
    FOR SELECT  D.ID
				,C.ID			AS LOCAT_MST_ID
				,B.COMN_CD_NM	AS LOCAT_TP_NM
      			,C.LOCAT_LV
      			,D.INV_KEEPING_COST_RATE
      			,D.ACTV_YN
      			,D.CREATE_BY
      			,D.CREATE_DTTM
      			,D.MODIFY_BY
      			,D.MODIFY_DTTM
			FROM TB_AD_COMN_GRP A
				 INNER JOIN TB_AD_COMN_CODE B
                 ON A.ID = B.SRC_ID
				 INNER JOIN TB_CM_LOC_MST C
                 ON B.ID = C.LOCAT_TP_ID
					LEFT OUTER JOIN
					TB_IM_INV_KEPPING_COST_RATE D
					ON C.ID = D.LOCAT_MST_ID
		   WHERE 1=1
			 AND A.GRP_CD = 'LOC_TP'
			 AND B.USE_YN ='Y';

    ELSIF P_CONF_KEY ='313'
    THEN
    OPEN pResult
    FOR SELECT  E.ID
                 ,D.ID                  AS LOCAT_ID
                 ,B.COMN_CD_NM          AS LOCAT_TP_NM
                 ,C.LOCAT_LV
                 ,D.LOCAT_CD
                 ,D.LOCAT_NM
                 ,E.ACTUAL_PERIOD       AS SHIPPING_ACTUAL_PERIOD
                 ,E.UOM_ID              AS TIME_UOM_NM
                 ,E.ACTV_YN
                 ,E.CREATE_BY
                 ,E.CREATE_DTTM
                 ,E.MODIFY_BY
                 ,E.MODIFY_DTTM
            FROM  TB_AD_COMN_CODE B
                 INNER JOIN TB_CM_LOC_MST C
                 ON B.ID = C.LOCAT_TP_ID
                 INNER JOIN TB_CM_LOC_DTL D
                 ON C.ID = D.LOCAT_MST_ID
                 LEFT OUTER JOIN TB_IM_VARIABILITY_ACT_PRIOD E
                 ON D.ID = E.LOCAT_ID
                 AND E.CATAGY_VAL='DEMAND_RATE'
                 LEFT OUTER JOIN TB_CM_UOM F
                 ON E.UOM_ID = F.ID
            AND B.USE_YN ='Y';

    ELSIF P_CONF_KEY ='314'
    THEN
    OPEN pResult
    FOR SELECT  D.ID
				,C.ID			AS LOCAT_MST_ID 
				,B.COMN_CD_NM	AS LOCAT_TP_NM
      			,C.LOCAT_LV
      			,D.SALES_PROFIT_RATE
      			,D.ACTV_YN
      			,D.CREATE_BY
      			,D.CREATE_DTTM
      			,D.MODIFY_BY
      			,D.MODIFY_DTTM
			FROM TB_AD_COMN_GRP A
				 INNER JOIN TB_AD_COMN_CODE B
                 ON A.ID = B.SRC_ID
				 INNER JOIN TB_CM_LOC_MST C
                 ON B.ID = C.LOCAT_TP_ID
					LEFT OUTER JOIN
					TB_IM_SALES_PROFIT_RATE D
					ON C.ID = D.LOCAT_MST_ID
		   WHERE 1=1
			 AND A.GRP_CD = 'LOC_TP'
			 AND B.USE_YN ='Y';

    ELSIF P_CONF_KEY ='317'
    THEN
    OPEN pResult
    FOR SELECT  B.ID  
				,B.SEGMT_DIM_CD
				,B.SEGMT_DIM_NM
				,B.ACTV_YN
				,B.PRIORT
				,B.PRIM_YN		AS PRIM
				,B.SECOND_YN	AS "SECOND"
				,B.CREATE_BY
				,B.CREATE_DTTM
				,B.MODIFY_BY
				,B.MODIFY_DTTM
			FROM TB_CM_CONFIGURATION A
				 INNER JOIN TB_IM_SEGMT_DIM_MST B
                 ON A.ID = B.CONF_ID
		   ORDER BY SEGMT_DIM_CD;

    ELSIF P_CONF_KEY ='318'
    THEN
    OPEN pResult
    FOR SELECT C.ID
			  ,B.ID			AS INV_MGMT_SEGMT_DIM_MST_ID
			  ,C.MGMT_NM	AS UPPR_CATAGY_NM
			  ,C.FROM_VAL	AS FROM_QTY
			  ,C.TO_VAL		AS TO_QTY
			  ,C.ACTV_YN	
			  ,C.CREATE_BY
			  ,C.CREATE_DTTM
			  ,C.MODIFY_BY
			  ,C.MODIFY_DTTM
		  FROM TB_CM_CONFIGURATION A
			   INNER JOIN TB_IM_SEGMT_DIM_MST B
               ON A.ID = B.CONF_ID
			   INNER JOIN TB_IM_SEGMT_DIM_DTL C
               ON B.ID = C.INV_MGMT_SEGMT_DIM_MST_ID
		 WHERE 1=1
		   AND B.SEGMT_DIM_CD = 'VAL_06'
         ORDER BY C.SEQ;

    ELSIF P_CONF_KEY ='319'
    THEN
    OPEN pResult
    FOR SELECT C.ID
			  ,B.ID			AS INV_MGMT_SEGMT_DIM_MST_ID
			  ,C.MGMT_NM	AS UPPR_CATAGY_NM
			  ,C.FROM_VAL	AS FROM_QTY
			  ,C.TO_VAL		AS TO_QTY
			  ,C.ACTV_YN	
			  ,C.CREATE_BY
			  ,C.CREATE_DTTM
			  ,C.MODIFY_BY
			  ,C.MODIFY_DTTM
		  FROM TB_CM_CONFIGURATION A
			   INNER JOIN TB_IM_SEGMT_DIM_MST B
               ON A.ID = B.CONF_ID
			   INNER JOIN TB_IM_SEGMT_DIM_DTL C
               ON B.ID = C.INV_MGMT_SEGMT_DIM_MST_ID
		 WHERE 1=1
		   AND B.SEGMT_DIM_CD = 'VAL_05'
         ORDER BY C.SEQ;

    ELSIF P_CONF_KEY ='320'
    THEN
    OPEN pResult
    FOR SELECT C.ID
			  ,B.ID			AS INV_MGMT_SEGMT_DIM_MST_ID
			  ,C.MGMT_NM	AS UPPR_CATAGY_NM
			  ,C.FROM_VAL	AS FROM_QTY
			  ,C.TO_VAL		AS TO_QTY
			  ,C.ACTV_YN	
			  ,C.CREATE_BY
			  ,C.CREATE_DTTM
			  ,C.MODIFY_BY
			  ,C.MODIFY_DTTM
		  FROM TB_CM_CONFIGURATION A
			   INNER JOIN TB_IM_SEGMT_DIM_MST B
               ON A.ID = B.CONF_ID
			   INNER JOIN TB_IM_SEGMT_DIM_DTL C
               ON B.ID = C.INV_MGMT_SEGMT_DIM_MST_ID
		 WHERE 1=1
		   AND B.SEGMT_DIM_CD = 'VAL_08'
         ORDER BY C.SEQ;

    ELSIF P_CONF_KEY ='321'
    THEN
    OPEN pResult
    FOR SELECT C.ID
			  ,B.ID			AS INV_MGMT_SEGMT_DIM_MST_ID
			  ,C.MGMT_NM	AS UPPR_CATAGY_NM
			  ,C.FROM_VAL	AS FROM_QTY
			  ,C.TO_VAL		AS TO_QTY
			  ,C.ACTV_YN	
			  ,C.CREATE_BY
			  ,C.CREATE_DTTM
			  ,C.MODIFY_BY
			  ,C.MODIFY_DTTM
		  FROM TB_CM_CONFIGURATION A
			   INNER JOIN TB_IM_SEGMT_DIM_MST B
               ON A.ID = B.CONF_ID
			   INNER JOIN TB_IM_SEGMT_DIM_DTL C
               ON B.ID = C.INV_MGMT_SEGMT_DIM_MST_ID
		   AND B.SEGMT_DIM_CD = 'VAL_09'
         ORDER BY C.SEQ;

    ELSIF P_CONF_KEY ='322'
    THEN
    OPEN pResult
    FOR SELECT C.ID
			  ,B.ID			AS INV_MGMT_SEGMT_DIM_MST_ID
			  ,C.MGMT_NM	AS UPPR_CATAGY_NM
			  ,C.FROM_VAL	AS FROM_QTY
			  ,C.TO_VAL		AS TO_QTY
			  ,C.ACTV_YN	
			  ,C.CREATE_BY
			  ,C.CREATE_DTTM
			  ,C.MODIFY_BY
			  ,C.MODIFY_DTTM
		  FROM TB_CM_CONFIGURATION A
			   INNER JOIN TB_IM_SEGMT_DIM_MST B
               ON A.ID = B.CONF_ID
			   INNER JOIN TB_IM_SEGMT_DIM_DTL C
               ON B.ID = C.INV_MGMT_SEGMT_DIM_MST_ID
		 WHERE 1=1
		   AND B.SEGMT_DIM_CD = 'VAL_07'
         ORDER BY C.SEQ;

    ELSIF P_CONF_KEY ='323' /* IM Segmentation Base (Standard Price) */
    THEN
    OPEN pResult
    FOR SELECT C.ID
			  ,B.ID			AS INV_MGMT_SEGMT_DIM_MST_ID
			  ,C.MGMT_NM	AS UPPR_CATAGY_NM
			  ,C.FROM_VAL	AS FROM_QTY
			  ,C.TO_VAL		AS TO_QTY
              ,D.ID         AS CURCY_CD_ID
              ,D.COMN_CD_NM AS CURCY_NM
			  ,C.ACTV_YN	
			  ,C.CREATE_BY
			  ,C.CREATE_DTTM
			  ,C.MODIFY_BY
			  ,C.MODIFY_DTTM
		  FROM TB_CM_CONFIGURATION A
			   INNER JOIN TB_IM_SEGMT_DIM_MST B
               ON A.ID = B.CONF_ID
			   INNER JOIN TB_IM_SEGMT_DIM_DTL C
               ON B.ID = C.INV_MGMT_SEGMT_DIM_MST_ID
				LEFT OUTER JOIN
				TB_AD_COMN_CODE D
				ON C.CURCY_CD_ID = D.ID
		 WHERE 1=1
		   AND B.SEGMT_DIM_CD = 'VAL_11'
         ORDER BY C.SEQ;

    ELSIF P_CONF_KEY ='324' /* Stock QTY Type */
    THEN
    OPEN pResult
    FOR SELECT  B.ID
               ,B.INV_LOCAT_CATAGY_NM	AS STOCK_LOCAT_NM
      	       ,B.ATTR_VAL
      	       ,B.INV_QTY_TP_CD
      	       ,B.INV_QTY_TP_NM			AS STOCK_QTY_TP
      	       ,B.PLAN_YN
      	       ,B.ACTV_YN
      	       ,B.CREATE_BY
      	       ,B.CREATE_DTTM
      	       ,B.MODIFY_BY
      	       ,B.MODIFY_DTTM
          FROM  TB_CM_CONFIGURATION A
                INNER JOIN TB_IM_STOCK_QTY_TYPE B
                ON A.ID = B.CONF_ID;

    ELSIF P_CONF_KEY ='325'
    THEN
    OPEN pResult
    FOR SELECT  E.ID
               ,D.ID				AS LOCAT_ID
               ,B.COMN_CD_NM		AS LOCAT_TP_NM
               ,C.LOCAT_LV
      		   ,D.LOCAT_CD
               ,D.LOCAT_NM
               ,E.ACTUAL_PERIOD
			   ,E.UOM_ID			AS UOM_NM
               ,E.ACTV_YN
               ,E.CREATE_BY
               ,E.CREATE_DTTM
               ,E.MODIFY_BY
               ,E.MODIFY_DTTM
          FROM  TB_AD_COMN_GRP A
                INNER JOIN TB_AD_COMN_CODE B
                ON A.ID = B.SRC_ID
                INNER JOIN TB_CM_LOC_MST C
                ON B.ID = C.LOCAT_TP_ID
                INNER JOIN TB_CM_LOC_DTL D
                ON C.ID = D.LOCAT_MST_ID
                LEFT OUTER JOIN TB_IM_VARIABILITY_ACT_PRIOD E
                ON (D.ID = E.LOCAT_ID
				AND E.CATAGY_VAL='FINAL_PRODUCT_GR_ITEM_INVTURN')
		   WHERE 1=1
			 AND A.GRP_CD = 'LOC_TP'
			 AND B.USE_YN = 'Y'
             AND D.ACTV_YN = 'Y';

    ELSIF P_CONF_KEY ='326' /*Inventory Aging */
    THEN
    OPEN pResult
    FOR SELECT  B.ID
				,B.ATTR_VAL
      			,B.INV_PERIOD_VAL
      			,B.FROM_VAL	AS FROM_QTY
      			,B.TO_VAL		AS TO_QTY
				,B.UOM_ID		AS UOM_NM
      			,B.ACTV_YN
      			,B.CREATE_BY
      			,B.CREATE_DTTM
      			,B.MODIFY_BY
      			,B.MODIFY_DTTM
			FROM  TB_CM_CONFIGURATION A
				  INNER JOIN TB_IM_INV_PERIOD B
                  ON A.ID = B.CONF_ID
		   WHERE 1=1
			 AND B.CATAGY_VAL = 'AGING';

    ELSIF P_CONF_KEY ='327' /*Inventory Surplus */
    THEN
    OPEN pResult
    FOR SELECT B.ID
              ,B.ATTR_VAL
              ,B.INV_PERIOD_VAL
              ,B.FROM_VAL	AS FROM_QTY
              ,B.TO_VAL		AS TO_QTY
              ,B.UOM_ID		AS UOM_NM
              ,B.ACTV_YN
              ,B.CREATE_BY
              ,B.CREATE_DTTM
              ,B.MODIFY_BY
              ,B.MODIFY_DTTM
			FROM  TB_CM_CONFIGURATION A
				  INNER JOIN TB_IM_INV_PERIOD B
                  ON A.ID = B.CONF_ID
		   WHERE 1=1
			 AND B.CATAGY_VAL = 'SURPLUS';

    ELSIF P_CONF_KEY ='328'
    THEN
    OPEN pResult
    FOR SELECT  F.ID
               ,E.LOCAT_ID
               ,E.LOCAT_TP_NM
               ,E.LOCAT_LV
               ,E.LOCAT_CD
               ,E.LOCAT_NM
               ,E.PERIOD_TP_ID
               ,E.PERIOD_TP	
               ,F.ACTV_YN
               ,F.PERIOD_VAL	AS PERIOD
               ,F.UOM_ID
               ,(SELECT A.UOM_NM FROM TB_CM_UOM A WHERE A.ID = F.UOM_ID) AS UOM_NM
               ,F.CREATE_BY
               ,F.CREATE_DTTM
               ,F.MODIFY_BY
               ,F.MODIFY_DTTM
			FROM (
					SELECT  A.COMN_CD_NM AS LOCAT_TP_NM
						   ,B.LOCAT_LV
        				   ,C.LOCAT_CD
        				   ,C.LOCAT_NM
						   ,C.ID AS LOCAT_ID
        				   ,D.ID AS LOCAT_MGMT_ID
        				   ,D.ACTV_YN
						   ,A.SEQ
						   ,E.ID			AS PERIOD_TP_ID
						   ,E.COMN_CD_NM	AS PERIOD_TP
					  FROM TB_AD_COMN_CODE A
						   INNER JOIN 
						   TB_CM_LOC_MST B
        				ON (A.ID = B.LOCAT_TP_ID)
        				   INNER JOIN 
        				   TB_CM_LOC_DTL C
        				ON (B.ID = C.LOCAT_MST_ID)
        				   INNER JOIN 
        					TB_CM_LOC_MGMT D
        				ON (C.ID = D.LOCAT_ID)
						  ,(SELECT G.ID, G.COMN_CD, G.COMN_CD_NM
							  FROM TB_AD_COMN_GRP F
								   INNER JOIN TB_AD_COMN_CODE G
                                   ON F.ID = G.SRC_ID
							 WHERE F.GRP_CD = 'IT_CAL_TP') E
					 WHERE 1=1
					   AND B.ACTV_YN = 'Y'
					   AND C.ACTV_YN = 'Y'
					   AND D.ACTV_YN = 'Y'
				   ) E
					LEFT OUTER JOIN TB_IM_DAYS_CAL_QTY_PERIOD F
						ON E.LOCAT_ID = F.LOCAT_ID
						AND E.PERIOD_TP_ID = F.PERIOD_TP
						AND F.CATAGY_VAL = 'FINAL_PRODUCT_GR_ITEM';
                        
    ELSIF P_CONF_KEY ='329'
    THEN
    OPEN pResult
    FOR SELECT E.ID
			  ,C.ID			AS LOCAT_ID
			  ,B.COMN_CD_NM	AS LOCAT_TP_NM
			  ,C.LOCAT_LV
			  ,D.LOCAT_CD
 			  ,D.LOCAT_NM
			  ,E.CAL_MTD_ID	AS CAL_TP_ID
			  ,E.ACTV_YN
 			  ,E.DEFAT_VAL_YN	AS DEFAT_VAL
			  ,E.CREATE_BY
			  ,E.CREATE_DTTM
			  ,E.MODIFY_BY
			  ,E.MODIFY_DTTM
         FROM TB_AD_COMN_GRP A
              INNER  JOIN TB_AD_COMN_CODE B
              ON A.ID = B.SRC_ID
			  INNER JOIN TB_CM_LOC_MST C
              ON B.ID = C.LOCAT_TP_ID
			  INNER JOIN TB_CM_LOC_DTL D
              ON C.ID = D.LOCAT_MST_ID
              LEFT OUTER JOIN 
              TB_IM_CAL_METHOD_INFO E
              ON D.ID = E.LOCAT_ID
                AND E.CATAGY_VAL ='AVG_MFG_LT_CAL_METHOD'
              LEFT OUTER JOIN
              (SELECT G.ID, G.COMN_CD, G.COMN_CD_NM
               FROM TB_AD_COMN_GRP F
                   ,TB_AD_COMN_CODE G
               WHERE F.GRP_CD = 'AVG_MFG_LT_CAL_METHOD'
                 AND F.ID = G.SRC_ID) F
              ON E.CAL_MTD_ID = F.ID
        WHERE   1=1
			AND A.GRP_CD = 'LOC_TP'
			AND B.USE_YN = 'Y'
            AND D.ACTV_YN = 'Y';	

    ELSIF P_CONF_KEY ='330'
    THEN
    OPEN pResult
    FOR SELECT  E.ID
				,D.ID			AS LOCAT_ID
				,B.COMN_CD_NM	AS LOCAT_TP_NM
      			,C.LOCAT_LV
      			,D.LOCAT_CD
      			,D.LOCAT_NM
				,E.CAL_MTD_ID	AS CAL_TP_ID
      			,E.ACTV_YN
      			,E.DEFAT_VAL_YN	AS DEFAT_VAL
      			,E.CREATE_BY
      			,E.CREATE_DTTM
      			,E.MODIFY_BY
      			,E.MODIFY_DTTM
			FROM TB_AD_COMN_GRP A
				 INNER JOIN TB_AD_COMN_CODE B
                 ON A.ID = B.SRC_ID
				 INNER JOIN TB_CM_LOC_MST C
                 ON B.ID = C.LOCAT_TP_ID
				 INNER JOIN TB_CM_LOC_DTL D
                 ON C.ID = D.LOCAT_MST_ID
					LEFT OUTER JOIN 
					TB_IM_CAL_METHOD_INFO E
					ON D.ID = E.LOCAT_ID
					AND E.CATAGY_VAL ='DEMAND_RATE_CAL_METHOD'
					LEFT OUTER JOIN
					(SELECT G.ID, G.COMN_CD, G.COMN_CD_NM
					   FROM TB_AD_COMN_GRP F
						    INNER JOIN TB_AD_COMN_CODE G
                            ON F.ID = G.SRC_ID
					  WHERE F.GRP_CD = 'DEMAND_RATE_CAL_METHOD') F
					ON E.CAL_MTD_ID = F.ID
			WHERE 1=1
				 AND A.GRP_CD = 'LOC_TP'
				 AND B.USE_YN ='Y'
                 AND D.ACTV_YN = 'Y';	

    ELSIF P_CONF_KEY ='331'
    THEN
    OPEN pResult
    FOR SELECT   E.ID
				,D.ID			AS LOCAT_ID
				,B.COMN_CD_NM	AS LOCAT_TP_NM
      			,C.LOCAT_LV
      			,D.LOCAT_CD
      			,D.LOCAT_NM
				,E.CAL_MTD_ID		AS CAL_TP_ID
      			,F.COMN_CD_NM	AS CAL_METHOD_NM
      			,E.ACTV_YN
      			,E.CREATE_BY
      			,E.CREATE_DTTM
      			,E.MODIFY_BY
      			,E.MODIFY_DTTM
			FROM TB_AD_COMN_GRP A
				 INNER JOIN TB_AD_COMN_CODE B
                 ON A.ID = B.SRC_ID
				 INNER JOIN TB_CM_LOC_MST C
                 ON B.ID = C.LOCAT_TP_ID
				 INNER JOIN TB_CM_LOC_DTL D
                 ON C.ID = D.LOCAT_MST_ID
					LEFT OUTER JOIN 
					TB_IM_CAL_METHOD_INFO E
					ON D.ID = E.LOCAT_ID
					AND E.CATAGY_VAL ='EOQ_DECISION_RULE'
					LEFT OUTER JOIN
					(SELECT G.ID, G.COMN_CD, G.COMN_CD_NM
					   FROM TB_AD_COMN_GRP F
						    INNER JOIN TB_AD_COMN_CODE G
                            ON F.ID = G.SRC_ID
					  WHERE F.GRP_CD = 'EOQ_DECISION_RULE') F
					ON E.CAL_MTD_ID = F.ID
			WHERE 1=1
				 AND A.GRP_CD = 'LOC_TP'
				 AND B.USE_YN ='Y'
                 AND D.ACTV_YN = 'Y';

    ELSIF P_CONF_KEY ='332'
    THEN
    OPEN pResult
    FOR SELECT  F.ID
				,E.LOCAT_ID
				,E.LOCAT_TP_NM
      			,E.LOCAT_LV
      			,E.LOCAT_CD
      			,E.LOCAT_NM
				,E.PERIOD_TP_ID
      			,E.PERIOD_TP
      			,F.ACTV_YN
      			,F.PERIOD_VAL	AS PERIOD
      			,U.UOM_NM		AS UOM_NM
      			,F.CREATE_BY
      			,F.CREATE_DTTM
      			,F.MODIFY_BY
      			,F.MODIFY_DTTM
			FROM (
					SELECT  A.COMN_CD_NM AS LOCAT_TP_NM
						   ,B.LOCAT_LV
        				   ,C.LOCAT_CD
        				   ,C.LOCAT_NM
						   ,C.ID AS LOCAT_ID
        				   ,D.ID AS LOCAT_MGMT_ID
        				   ,D.ACTV_YN
						   ,A.SEQ
						   ,E.ID			AS PERIOD_TP_ID
						   ,E.COMN_CD_NM	AS PERIOD_TP
					  FROM TB_AD_COMN_CODE A
						   INNER JOIN 
						   TB_CM_LOC_MST B
        				ON (A.ID = B.LOCAT_TP_ID)
        				   INNER JOIN 
        				   TB_CM_LOC_DTL C
        				ON (B.ID = C.LOCAT_MST_ID)
        				   INNER JOIN 
        					TB_CM_LOC_MGMT D
        				ON (C.ID = D.LOCAT_ID)
						  ,(SELECT G.ID, G.COMN_CD, G.COMN_CD_NM
							  FROM TB_AD_COMN_GRP F
								   INNER JOIN TB_AD_COMN_CODE G
                                   ON F.ID = G.SRC_ID
							 WHERE F.GRP_CD = 'IT_CAL_TP') E
					 WHERE 1=1
					   AND B.ACTV_YN = 'Y'
					   AND C.ACTV_YN = 'Y'
					   AND D.ACTV_YN = 'Y' 
				   ) E

					LEFT OUTER JOIN TB_IM_DAYS_CAL_QTY_PERIOD F
						ON E.LOCAT_ID = F.LOCAT_ID
						AND E.PERIOD_TP_ID = F.PERIOD_TP
						AND F.CATAGY_VAL = 'SEMI_PRODUCT_GI_ITEM'
						LEFT OUTER JOIN TB_CM_UOM U
							ON F.UOM_ID = U.ID;

    ELSIF P_CONF_KEY ='333'
    THEN
    OPEN pResult
    FOR SELECT C.ID
			  ,B.ID			AS INV_MGMT_SEGMT_DIM_MST_ID
			  ,C.MGMT_NM	AS UPPR_CATAGY_NM
			  ,C.FROM_VAL	AS FROM_QTY
			  ,C.TO_VAL		AS TO_QTY
			  ,C.ACTV_YN	
			  ,C.CREATE_BY
			  ,C.CREATE_DTTM
			  ,C.MODIFY_BY
			  ,C.MODIFY_DTTM
		  FROM TB_CM_CONFIGURATION A
			   INNER JOIN TB_IM_SEGMT_DIM_MST B
               ON A.ID = B.CONF_ID
			   INNER JOIN TB_IM_SEGMT_DIM_DTL C
               ON B.ID = C.INV_MGMT_SEGMT_DIM_MST_ID
		 WHERE 1=1
		   AND B.SEGMT_DIM_CD = 'VAL_10'
		 ORDER BY C.SEQ;

    ELSIF P_CONF_KEY ='335'
    THEN
    OPEN pResult
    FOR   SELECT  E.ID
                 ,D.ID                  AS LOCAT_ID
                 ,B.COMN_CD_NM          AS LOCAT_TP_NM
                 ,C.LOCAT_LV
                 ,D.LOCAT_CD
                 ,D.LOCAT_NM
                 ,E.ACTUAL_PERIOD       AS SHIPPING_ACTUAL_PERIOD
                 ,E.UOM_ID              AS TIME_UOM_NM
                 ,E.ACTV_YN
                 ,E.CREATE_BY
                 ,E.CREATE_DTTM
                 ,E.MODIFY_BY
                 ,E.MODIFY_DTTM
            FROM  TB_AD_COMN_CODE B
                 INNER JOIN TB_CM_LOC_MST C
                 ON B.ID = C.LOCAT_TP_ID
                 INNER JOIN TB_CM_LOC_DTL D
                 ON C.ID = D.LOCAT_MST_ID
                 LEFT OUTER JOIN TB_IM_VARIABILITY_ACT_PRIOD E
                 ON D.ID = E.LOCAT_ID
                 AND E.CATAGY_VAL='INV_CLASS'
                 LEFT OUTER JOIN TB_CM_UOM F
                 ON E.UOM_ID = F.ID
            AND B.USE_YN ='Y';

    ELSIF P_CONF_KEY ='336'
    THEN
    OPEN pResult
    FOR   SELECT  E.ID
                 ,D.ID                  AS LOCAT_ID
                 ,B.COMN_CD_NM          AS LOCAT_TP_NM
                 ,C.LOCAT_LV
                 ,D.LOCAT_CD
                 ,D.LOCAT_NM
                 ,E.ACTUAL_PERIOD       AS SHIPPING_ACTUAL_PERIOD
                 ,E.UOM_ID              AS TIME_UOM_NM
                 ,E.ACTV_YN
                 ,E.CREATE_BY
                 ,E.CREATE_DTTM
                 ,E.MODIFY_BY
                 ,E.MODIFY_DTTM
            FROM  TB_AD_COMN_CODE B
                 INNER JOIN TB_CM_LOC_MST C
                 ON B.ID = C.LOCAT_TP_ID
                 INNER JOIN TB_CM_LOC_DTL D
                 ON C.ID = D.LOCAT_MST_ID
                 LEFT OUTER JOIN TB_IM_VARIABILITY_ACT_PRIOD E
                 ON D.ID = E.LOCAT_ID
                 AND E.CATAGY_VAL='RP_TARGET'
                 LEFT OUTER JOIN TB_CM_UOM F
                 ON E.UOM_ID = F.ID
            AND B.USE_YN ='Y';
    END IF;
    
END;

/

