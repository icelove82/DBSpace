create PROCEDURE SP_UI_IM_01_POP_05_S1 (
	 P_ID				    IN VARCHAR2 := ''
	,P_LOCAT_ID			    IN VARCHAR2 := ''
	,P_INV_CLSS_TP		    IN VARCHAR2 := ''
	,P_ACTV_YN			    IN VARCHAR2 := ''
	,P_UPPR_VAL			    IN NUMBER := ''
	,P_LOWR_VAL			    IN NUMBER := ''
	,P_SVC_LV			    IN NUMBER := ''
	,P_TAB_INDEX	    	IN VARCHAR2 := ''
	,P_USER_ID				IN VARCHAR2 := ''
	,P_WRK_TYPE			    IN VARCHAR2 := ''
	,P_RT_ROLLBACK_FLAG	    OUT VARCHAR2
	,P_RT_MSG				OUT VARCHAR2
)
/*****************************************************************************
 * System Name : T3Enterprise IM
 * Business Name : Inventory Grade Management Base
 * Program Name(ID) :SP_UI_IM_01_POP_05_S1
 * Program Description : Config Key 305, Qty/Revenue base saving operation
 *
 * Create Date : 2017.11.14
 * Author : JAR
 *
 * Modifier    Modified Date    Revision History
 * --------    -------------    ----------------------------------------------
 * RSK         2019/03/12       Formatting & Comments &
 *                              Applied inventory grade base
 *
 *****************************************************************************/
IS
    P_ERR_STATUS NUMBER := 0;
    P_ERR_MSG VARCHAR2(4000) := '';
    V_CATAGY_VAL VARCHAR2(20) := '';    
BEGIN
    IF P_WRK_TYPE = 'SAVE' THEN	
        IF P_TAB_INDEX = '1' THEN 
            V_CATAGY_VAL := 'QTY_BASE';
        ELSE 
            V_CATAGY_VAL := 'REVENUE_BASE';
        END IF;

        P_ERR_MSG := 'MSG_5017'; -- Lower value must be higher than upper value.
        IF P_UPPR_VAL > P_LOWR_VAL THEN 
            RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
        END IF;

        P_ERR_MSG := 'MSG_0012'; -- You have entered a value that exceeds the percentage range.
        IF (P_SVC_LV < 0 OR P_SVC_LV > 100) THEN 
            RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
        END IF;

        MERGE INTO TB_IM_STOCK_CLASS_MGMT B 
            USING (SELECT P_LOCAT_ID AS LOCAT_ID
                         ,P_INV_CLSS_TP AS INV_CLSS_TP
                         ,V_CATAGY_VAL AS CATAGY_VAL
                     FROM DUAL) A
                ON (B.LOCAT_ID = A.LOCAT_ID
                AND B.INV_CLSS_TP = A.INV_CLSS_TP
                AND B.CATAGY_VAL = A.CATAGY_VAL)
        WHEN MATCHED THEN
            UPDATE 
               SET ACTV_YN			= P_ACTV_YN
                 , UPPR_VAL			= P_UPPR_VAL
                 , LOWR_VAL			= P_LOWR_VAL
                 , SVC_LV			= P_SVC_LV
                 , MODIFY_BY		= P_USER_ID
                 , MODIFY_DTTM		= SYSDATE
        WHEN NOT MATCHED THEN
            INSERT (
                ID, LOCAT_ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
                ,CATAGY_VAL
                ,INV_CLSS_TP
                ,UPPR_VAL
                ,LOWR_VAL
                ,SVC_LV
                ,ACTV_YN
                )
            VALUES
                (
                TO_SINGLE_BYTE(SYS_GUID()),P_LOCAT_ID,P_USER_ID, SYSDATE, P_USER_ID, SYSDATE
                ,V_CATAGY_VAL
                ,P_INV_CLSS_TP
                ,P_UPPR_VAL
                ,P_LOWR_VAL
                ,P_SVC_LV
                ,P_ACTV_YN
                );

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';  -- Saved successfully.

    ELSIF P_WRK_TYPE = 'DELETE' THEN
        DELETE FROM TB_IM_STOCK_CLASS_MGMT 
        WHERE ID = P_ID;

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0002';
    END IF;

	EXCEPTION
        WHEN OTHERS THEN
            IF(SQLCODE = -20012)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF;

END;

/

