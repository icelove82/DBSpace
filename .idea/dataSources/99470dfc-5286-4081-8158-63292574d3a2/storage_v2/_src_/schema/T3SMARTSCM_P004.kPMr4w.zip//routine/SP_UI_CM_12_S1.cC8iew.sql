create PROCEDURE SP_UI_CM_12_S1(
	 P_DMND_SHPP_MGMT_MST_ID		IN CHAR := '',
	 P_LOCAT_CD						IN CHAR := '',
	 P_ACTV_YN						IN CHAR := '',
	 P_USER_ID						IN VARCHAR2 :=''
    ,P_RT_ROLLBACK_FLAG             OUT VARCHAR2
    ,P_RT_MSG                       OUT VARCHAR2
)IS

    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG  VARCHAR2(4000) :='';

    BEGIN
    P_RT_ROLLBACK_FLAG := 'true';
   
   
    UPDATE TB_CM_DMND_SHPP_MAP_MST
			   SET LOCAT_MGMT_ID =
               (SELECT ID
			  FROM TB_CM_LOC_MGMT
			 WHERE LOCAT_ID = P_LOCAT_CD)
				 , ACTV_YN = P_ACTV_YN
				 , MODIFY_BY = P_USER_ID
				 , MODIFY_DTTM = SYSDATE
			 WHERE ID = P_DMND_SHPP_MGMT_MST_ID;

            P_RT_ROLLBACK_FLAG := 'true';
            P_RT_MSG := 'MSG_0001';

             EXCEPTION
        WHEN OTHERS THEN
            P_RT_ROLLBACK_FLAG := 'false';
            IF(SQLCODE = -20012)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF; 

END;

/

