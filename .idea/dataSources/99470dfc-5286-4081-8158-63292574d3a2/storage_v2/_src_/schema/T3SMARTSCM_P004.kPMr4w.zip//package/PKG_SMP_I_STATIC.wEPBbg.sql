create PACKAGE                 PKG_SMP_I_STATIC is
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved. 
**************************************************************************
* Name    : PKG_SMP_I_STATIC
* Purpose : MP Static 정보 생성.
* Notes   :
**************************************************************************
* History :
* 2020-02-17 HGD Created
**************************************************************************/
PRAGMA SERIALLY_REUSABLE;
-----------------------------
-- Public type declarations -
-----------------------------

-- CONTINENT_CD,  SITE_CD, P_ITEM_CD, C_ITEM_CD, P_OP_CD, C_OP_CD, P_ITEM_TYP, C_ITEM_TYP
--  // ROUTE_ID,  P_INVENTORY_ID, C_INVENTORY_ID, C_BOM_RATE

PROCEDURE SP_SET_ORG (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_CALENDAR (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_RES_AVAIL (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_ITEM (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_BOM (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_BOR (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);
END PKG_SMP_I_STATIC;
/

