create PROCEDURE SP_UI_CM_08_S1 (
     P_SHPP_LEADTIME_DTL_ID	IN VARCHAR2	:= ''
	,P_SHPP_SCHDL_TP_ID	    IN VARCHAR2 := ''
	,P_ACTV_YN				IN CHAR := ''
	,P_USER_ID				IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG     OUT VARCHAR2
	,P_RT_MSG               OUT VARCHAR2
)
IS
    P_ERR_STATUS NUMBER := 0;
    P_ERR_MSG VARCHAR2(4000) := '';

BEGIN

    UPDATE TB_CM_SHIP_LT_DTL
       SET SHPP_SCHDL_TP_ID = P_SHPP_SCHDL_TP_ID
	     , ACTV_YN			= P_ACTV_YN
         , MODIFY_BY		= P_USER_ID
         , MODIFY_DTTM	    = SYSDATE
     WHERE ID = P_SHPP_LEADTIME_DTL_ID;

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';

    EXCEPTION
    WHEN OTHERS THEN
        IF(SQLCODE = -20012)
        THEN
              P_RT_ROLLBACK_FLAG := 'false';
              P_RT_MSG := P_ERR_MSG;
          ELSE
              RAISE;
          END IF;
END;

/

