create PROCEDURE "SP_UI_DP_36_S1" (
					 P_ID				IN  CHAR		:= ''
					,P_MODULE_ID		IN  CHAR		:= ''
					,P_PLAN_TP_ID		IN  CHAR		:= ''
					,P_POLICY_ID		IN  CHAR		:= ''
					,P_POLICY_VAL		IN  VARCHAR2	:= ''
					,P_DESCRIP			IN  VARCHAR2	:= ''
					,P_USER_ID			IN  VARCHAR2	:= ''
                    ,P_RT_ROLLBACK_FLAG OUT VARCHAR2     
                    ,P_RT_MSG           OUT VARCHAR2    		
)
IS
        P_ERR_STATUS INT := 0;
        P_ERR_MSG VARCHAR2(4000):='';




BEGIN 
/*
		PLAN POLICY ??？ ？?ν？?
*/
/* MESSAGE VALIDATION	*/
	SELECT COUNT(*) INTO P_ERR_STATUS
	  FROM TB_DP_PLAN_POLICY
	WHERE 1=1
	  AND MODULE_ID = P_MODULE_ID
	  AND PLAN_TP_ID = P_PLAN_TP_ID
	  AND POLICY_ID = P_POLICY_ID   
	  AND ID != P_ID;
	IF(P_ERR_STATUS > 0)
		THEN
            P_ERR_MSG := 'MSG_0013';
            RAISE_APPLICATION_ERROR(-20000, P_ERR_MSG);  
    END IF;

				MERGE INTO TB_DP_PLAN_POLICY TGT
				USING ( 
						SELECT
						 P_ID				AS ID			
						,P_MODULE_ID		AS MODULE_ID	
						,P_PLAN_TP_ID		AS PLAN_TP_ID	
						,P_POLICY_ID		AS POLICY_ID	
						,P_POLICY_VAL		AS POLICY_VAL	
						,P_DESCRIP			AS DESCRIP		
						,P_USER_ID			AS USER_ID	
                        FROM dual
					  ) SRC
				ON (TGT.ID = SRC.ID)
				WHEN MATCHED THEN
					 UPDATE 
					   SET   		
							 TGT.MODULE_ID	 = SRC.MODULE_ID	
							,TGT.PLAN_TP_ID	 = SRC.PLAN_TP_ID	
							,TGT.POLICY_ID	 = SRC.POLICY_ID	
							,TGT.POLICY_VAL	 = SRC.POLICY_VAL	
							,TGT.DESCRIP	 = SRC.DESCRIP			
							,TGT.MODIFY_BY	 = SRC.USER_ID	
							,TGT.MODIFY_DTTM = SYSDATE		
				WHEN NOT MATCHED THEN 
					 INSERT (
								 ID			
								,MODULE_ID	
								,PLAN_TP_ID	
								,POLICY_ID	
								,POLICY_VAL	
								,DESCRIP		
								,CREATE_BY	
								,CREATE_DTTM	
								,MODIFY_BY	
								,MODIFY_DTTM								 
							) 
					 VALUES (
							 TO_SINGLE_BYTE(SYS_GUID())			
							,SRC.MODULE_ID	
							,SRC.PLAN_TP_ID	
							,SRC.POLICY_ID	
							,SRC.POLICY_VAL	
							,SRC.DESCRIP		
							,SRC.USER_ID 
							,SYSDATE  
							,NULL
							,NULL          
 							) 
							;    
	   P_RT_ROLLBACK_FLAG := 'true';
	   P_RT_MSG := 'MSG_0001';  --???？？????？？
       /* ???？o?? ============================================================================*/  
       EXCEPTION   
        WHEN OTHERS THEN  -- ?？? ???？？? ?？? ???？?？ : e_products_invalid       
--          P_ERR_MSG := SQLERRM; -- SYS.DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
              P_RT_ROLLBACK_FLAG := 'false';
              IF(SQLCODE = -20000)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF;

END;

/

