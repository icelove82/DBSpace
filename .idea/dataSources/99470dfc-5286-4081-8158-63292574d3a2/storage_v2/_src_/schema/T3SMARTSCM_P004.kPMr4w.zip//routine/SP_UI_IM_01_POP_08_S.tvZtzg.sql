create PROCEDURE SP_UI_IM_01_POP_08_S
(
	 P_ID					IN VARCHAR2 := ''
	,P_LOCAT_ID				IN VARCHAR2 := ''
	,P_ACTUAL_PERIOD		IN NUMBER := ''
    ,P_UOM_NM_ID			IN CHAR := ''
	,P_ACTV_YN				IN VARCHAR2 := ''
	,P_USER_ID				IN VARCHAR2 := ''
	,P_WRK_TYPE				IN VARCHAR2 := ''
	,P_RT_ROLLBACK_FLAG		OUT VARCHAR2
	,P_RT_MSG				OUT VARCHAR2
)
IS
    P_ERR_STATUS    NUMBER := 0;
    P_ERR_MSG       VARCHAR2(4000) := '';
BEGIN

IF P_WRK_TYPE = 'SAVE'
THEN
		P_ERR_MSG := 'MSG_0011'; -- '？？？？？？ ？？？ ？？ ？？ ？？？？？？？. '
		   IF P_ACTUAL_PERIOD > 0 
		   THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
           END IF;

		MERGE INTO TB_IM_VARIABILITY_ACT_PRIOD B 
		USING (SELECT P_ID AS ID FROM DUAL) A
				ON    (B.ID = A.ID)
		WHEN MATCHED THEN
			UPDATE 
			   SET ACTUAL_PERIOD	= P_ACTUAL_PERIOD
				 , UOM_ID			= P_UOM_NM_ID
				 , ACTV_YN			= P_ACTV_YN
				 , MODIFY_BY		= P_USER_ID
				 , MODIFY_DTTM	    = SYSDATE
		WHEN NOT MATCHED THEN
			INSERT (
				-- ？？？？？？
				ID, LOCAT_ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
				-- ？？？？？？？？
				,CATAGY_VAL
				,ACTUAL_PERIOD
                ,UOM_ID
				,ACTV_YN
				)
			VALUES
				(
				-- ？？？？？？
				TO_SINGLE_BYTE(SYS_GUID()), P_LOCAT_ID, P_USER_ID, SYSDATE, P_USER_ID, SYSDATE
				-- ？？？？？？？？
				,'SUPPLY_VARIABILITY'
				,P_ACTUAL_PERIOD
                ,P_UOM_NM_ID
				,P_ACTV_YN		
				);

		  P_RT_ROLLBACK_FLAG := 'true';
	      P_RT_MSG := 'MSG_0001';  --？？？？ ？？？？？？？？.

ELSIF P_WRK_TYPE = 'DELETE'
THEN
		DELETE FROM TB_IM_VARIABILITY_ACT_PRIOD 
		WHERE ID = P_ID;

		P_RT_ROLLBACK_FLAG := 'true';
		P_RT_MSG := 'MSG_0002';
END IF;

	EXCEPTION
        WHEN OTHERS THEN
            P_RT_ROLLBACK_FLAG := 'false';
            IF(SQLCODE = -20012)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF;
END;

/

