create PROCEDURE "SP_UI_DP_21_Q1" (
    p_GB            IN  VARCHAR2 := ''
  , p_VER_ID        IN  VARCHAR2 := ''
  , p_FROM_DATE     IN  DATE     := NULL
  , p_TO_DATE       IN  DATE     := NULL
  , P_ITEM_CD       IN  VARCHAR2 := ''
  , P_ITEM_NM       IN  VARCHAR2 := ''
  , p_ACCOUNT_CD    IN  VARCHAR2 := ''
  , p_ACCOUNT_NM    IN  VARCHAR2 := ''
  , P_PRICE_TP      IN  VARCHAR2 := ''
  , pRESULT         OUT SYS_REFCURSOR
)
IS
BEGIN 

/******************************************************************************************************************************************************************************************
* hanguls
** TB_DP_UNIT_PRICE ?？CURCY_CD_ID?？?？？?? ?？? TB_DP_ACCOUNT_MST?? ?？???？？
** excel upload o???? ??？?? parameter ?? code?θ? ???？ ID?？?？???？？******************************************************************************************************************************************************************************************/

    OPEN pRESULT
    FOR
    SELECT UP.ID
         , AM.ACCOUNT_CD
         , AM.ACCOUNT_NM
         , IM.ITEM_CD
         , IM.ITEM_NM
         , AC.COMN_CD as CURCY_CD
         , AC.COMN_CD_NM as CURCY_NM
         , UP.BASE_DATE  AS BASE_DATE
         , UP.UTPIC
         , UP.CONF_CD as PRICE_TP_CD
         , UP.CONF_NM as PRICE_TP
         , UP.ATTR_01
         , COALESCE(UP.CREATE_DTTM, SYSDATE) AS CREATE_DTTM
      FROM (  
        SELECT A.ID
             , A.ACCOUNT_ID
             , A.ITEM_MST_ID  
             , A.BASE_DATE
             , A.UTPIC
             , A.PRICE_TP_ID
             , CC.CONF_CD
             , CC.CONF_NM
             , A.ATTR_01     
             , A.CREATE_DTTM
          FROM TB_DP_UNIT_PRICE A
               INNER JOIN TB_CM_COMM_CONFIG CC ON CC.Id  = a.PRICE_TP_ID
               INNER JOIN ( -- ??？ ?？？？?？？？ ?？????？???？？？？?? 
                SELECT ID 
                  FROM ( 
                        SELECT UP.ID
                             , ROW_NUMBER () OVER(PARTITION BY UP.PRICE_TP_ID, UP.ACCOUNT_ID, UP.ITEM_MST_ID ORDER BY BASE_DATE DESC) ROW_NUM
                          FROM TB_DP_UNIT_PRICE UP 
                               INNER JOIN  
                               TB_DP_ACCOUNT_MST AM 
                           ON  UP.ACCOUNT_ID = AM.ID 
                           AND COALESCE(AM.DEL_YN, 'N') = 'N' 
                           AND AM.ACTV_YN = 'Y' 
                               INNER JOIN  
                               TB_CM_ITEM_MST IM   
                           ON  UP.ITEM_MST_ID = IM.ID 
                           AND COALESCE(IM.DEL_YN, 'N') = 'N'  
                           AND COALESCE(IM.DP_PLAN_YN, 'Y') = 'Y'         
                               INNER JOIN 
                               TB_AD_COMN_CODE AC 
                           ON  AC.ID = AM.CURCY_CD_ID AND COALESCE(AC.DEL_YN,'N') = 'N' AND AC.USE_YN ='Y'
                         WHERE 1=1
                           AND UP.BASE_DATE <=  p_FROM_DATE 
                           AND (REGEXP_LIKE (UPPER(AM.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCOUNT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                                OR p_ACCOUNT_CD IS NULL
                           )
                           AND (REGEXP_LIKE (UPPER(AM.ACCOUNT_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCOUNT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                                OR p_ACCOUNT_NM IS NULL
                           )                
                           AND (REGEXP_LIKE (UPPER(IM.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                                OR P_ITEM_CD IS NULL
                           )
                           AND (REGEXP_LIKE (UPPER(IM.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                                  OR P_ITEM_NM IS NULL
                           )  
                    ) X 
                 WHERE X.ROW_NUM = 1 
              ) B ON A.ID = B.ID
        UNION 
        SELECT A.ID
             , A.ACCOUNT_ID
             , A.ITEM_MST_ID
             , A.BASE_DATE--,CONVERT(DATETIME, A.BASE_DATE,112)  AS BASE_DATE
             , A.UTPIC
             , A.PRICE_TP_ID
             , CC.CONF_CD
             , CC.CONF_NM
             , A.ATTR_01
             , A.CREATE_DTTM
          FROM TB_DP_UNIT_PRICE A
         INNER JOIN TB_CM_COMM_CONFIG CC ON CC.Id  = a.PRICE_TP_ID
         WHERE  A.BASE_DATE >=  p_FROM_DATE
           AND  A.BASE_DATE <=  p_TO_DATE
      ) UP
     INNER JOIN TB_DP_ACCOUNT_MST AM 
        ON UP.ACCOUNT_ID = AM.ID  AND COALESCE(AM.DEL_YN, 'N') = 'N' AND AM.ACTV_YN = 'Y'
     INNER JOIN TB_CM_ITEM_MST IM   
        ON UP.ITEM_MST_ID = IM.ID AND COALESCE(IM.DEL_YN, 'N') = 'N' AND COALESCE(IM.DP_PLAN_YN, 'Y') = 'Y'
     INNER JOIN TB_AD_COMN_CODE AC 
        ON AC.ID = AM.CURCY_CD_ID AND COALESCE(AC.DEL_YN, 'N') = 'N' AND AC.USE_YN ='Y'
     WHERE 1=1  
       AND (REGEXP_LIKE (UPPER(AM.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCOUNT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
            OR p_ACCOUNT_CD IS NULL
       )
       AND (REGEXP_LIKE (UPPER(IM.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
            OR P_ITEM_CD IS NULL
       )
       AND (REGEXP_LIKE (UPPER(AM.ACCOUNT_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCOUNT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
            OR p_ACCOUNT_NM IS NULL
       )
       AND (REGEXP_LIKE (UPPER(IM.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
            OR P_ITEM_NM IS NULL
       )
       AND UP.PRICE_TP_ID = P_PRICE_TP
     ORDER BY AM.ACCOUNT_CD, IM.ITEM_CD
    ;

END;
/

