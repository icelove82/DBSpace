create PROCEDURE "SP_UI_DP_35_Q5_SALES_LV_CD_LV" 
--(	
--	 p_EMP_ID		VARCHAR2 := ''
--	,p_AUTH_TP_ID	VARCHAR2 := ''
--) 
(
        pResult OUT SYS_REFCURSOR
)
IS 


BEGIN

    OPEN pResult FOR 
	SELECT	A.ID, A.SALES_LV_CD, A.SALES_LV_NM , B.LV_CD, B.LV_NM
	FROM	TB_DP_SALES_LEVEL_MGMT			A 
			INNER JOIN TB_CM_LEVEL_MGMT	B  
            ON A.LV_MGMT_ID = B.ID AND B.ACTV_YN = 'Y'
	WHERE	A.ACTV_YN = 'Y'
	AND		A.SEQ NOT IN (
						SELECT	MIN(X.SEQ) 
						FROM	TB_DP_SALES_LEVEL_MGMT	X 
								INNER JOIN TB_CM_LEVEL_MGMT	Y  
                                ON (X.LV_MGMT_ID = Y.ID 
                                    AND Y.ACTV_YN = 'Y')
--                                ON (A.LV_MGMT_ID = B.ID 

						)
	AND		A.LV_MGMT_ID IN ( SELECT ID 
                                FROM TB_CM_LEVEL_MGMT  
                               WHERE ACTV_YN = 'Y') 
	AND		NVL(A.PARENT_SALES_LV_ID, 'none') NOT IN	(
														SELECT ID FROM TB_DP_SALES_LEVEL_MGMT 
													);


END;


/

