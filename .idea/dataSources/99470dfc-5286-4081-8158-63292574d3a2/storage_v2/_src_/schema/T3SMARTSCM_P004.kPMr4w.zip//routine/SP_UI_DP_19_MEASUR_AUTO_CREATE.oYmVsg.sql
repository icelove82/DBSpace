create PROCEDURE "SP_UI_DP_19_MEASUR_AUTO_CREATE" 
(
    P_GRP_ID       IN  VARCHAR2 :=''
  , P_UI_ID            IN  VARCHAR2 :=''
  , P_GRID_ID          IN  VARCHAR2 :=''
  , P_USER_ID          IN  VARCHAR2 :=''
  , P_RT_ROLLBACK_FLAG OUT VARCHAR2      
  , P_RT_MSG           OUT VARCHAR2  
)IS
    /*****************************************************************************************************************
        DP Measure AI？？y ？？y？？？？
        AU？？？？AI : 2018.06.08
        AU？？？？AU : ？？e？？OEn
        ？？oA？？AI : 20180905
        ？？oA？？？？？？？？e : Demand AO？？A level A？？ AUTH type ？？？？ C？？？？cCI？？A ？？？？？？？ AU？좯 ？？？？？？A
    *****************************************************************************************************************/
    P_ERR_STATUS        INT := 0;
    P_ERR_MSG           VARCHAR2(4000):='';
    V_COL_NM_01         VARCHAR2(100) :=''; -- LEAF_YN = 'N' : ITEM_LV_CD, SALES_LV_CD
    V_COL_NM_02         VARCHAR2(100) :=''; -- LEAF_YN = 'Y' : ITEM_CD, ACCT_CD
    V_SEQ               INT := 0;
    V_DP_MS_VER_TP      CHAR(32) := '';
    V_USER_PREF_MST_ID  CHAR(32);
BEGIN
    -------- Validation -------------------------------------------------------------------------------------------    
    -- ENTRY & COMMON (X)
    -- GRP_ID

    SELECT COUNT(1) INTO P_ERR_STATUS
      FROM TB_AD_GROUP GRP
     WHERE ID = P_GRP_ID;

    IF P_ERR_STATUS = 0 THEN
        P_ERR_MSG := 'MSG_5049';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;


    ------- ？？aA？？ ？？？？AIAI Ao？？i？？i -------------------------------------------------------------------------------------------
    DELETE 
      FROM TB_DP_MEASURE_SETTING
     WHERE 1=1
       AND UI_ID = P_UI_ID
       AND GRID_ID = P_GRID_ID
       AND GRP_ID = P_GRP_ID;

    -----1. A？？？？？ MEASURE ---------------------------------------------------------------------------------------------
                -- MEASURE ？？？ A？？AO NNA？？？？I
    SELECT COUNT(GRP_4.ID) INTO P_ERR_STATUS
      FROM TB_CM_COMM_CONFIG GRP_4
     WHERE 1=1
       AND GRP_4.CONF_GRP_CD    = 'DP_MS_VER_TP'
       AND GRP_4.ACTV_YN        = 'Y'  
       AND GRP_4.CONF_CD        = 'NN';

    IF (P_ERR_STATUS = 0)
    THEN
        V_DP_MS_VER_TP := NULL;
    ELSE
        SELECT GRP_4.ID INTO V_DP_MS_VER_TP
          FROM TB_CM_COMM_CONFIG GRP_4
         WHERE 1=1
           AND GRP_4.CONF_GRP_CD    = 'DP_MS_VER_TP'
           AND GRP_4.ACTV_YN        = 'Y'  
           AND GRP_4.CONF_CD        = 'NN'
           ;                           
    END IF;  
                -- A？？？？？ MEASUREAI？？？ ？？？ INSERT
    INSERT INTO TB_DP_MEASURE_SETTING ( 
        ID
      , UI_ID
      , GRID_ID
      , GRP_ID
      , MEASURE_CONF_TP_ID
      , LV_MGMT_ID            -- 'DEMAND'AI？？？？ MEASURE CODE
      , MEASURE_MST_ID        -- 'ADDITION'AI？？？？ MEASURE CODE
      , VER_APPY_BASE_ID
      , MEASURE_VAL_TP_ID
      , INPUT_YN
      , DISP_NM
      , SEQ
      , ACTV_YN
      , CREATE_BY
      , CREATE_DTTM
      , MODIFY_BY
      , MODIFY_DTTM
    )
    SELECT TO_SINGLE_BYTE(SYS_GUID()) AS ID
         , P_UI_ID                    AS UI_ID
         , P_GRID_ID                  AS GRID_ID
         , P_GRP_ID                   AS GRP_ID
         , (SELECT GRP_1.ID     
              FROM TB_CM_CONFIGURATION CON 
             INNER JOIN TB_CM_COMM_CONFIG GRP_1  
                ON CON.ID = GRP_1.CONF_ID 
             WHERE 1=1
               AND CON.CONF_NM       = GRP_1.CONF_GRP_CD
               AND GRP_1.CONF_GRP_CD = 'DP_MS_INPUT_TP'
               AND GRP_1.ACTV_YN     = 'Y'
               AND GRP_1.CONF_CD     = 'ADDITION' 
            )                         AS MEASURE_CONF_TP_ID                      
         , NULL                       AS LV_MGMT_ID -- DEMAND
         , A.ID                       AS MEASURE_MST_ID
         , V_DP_MS_VER_TP             AS VER_APPY_BASE_ID -- NN
         , GRP_3.ID                   AS MEASURE_VAL_TP_ID
         , 'N'                        AS INPUT_YN
         , A.MEASURE_CD                     
--                     ||CASE SUBSTR(A.MEASURE_CD,-4) 
--                        WHEN '_'||GRP_3.CONF_CD  THEN    NULL
--                        ELSE '_'||GRP_3.CONF_CD 
--                        END                     
                                      AS DISP_NM
         , ROWNUM                     AS SEQ
         , 'Y'                        AS ACTV_YN
         , P_USER_ID                  AS CREATE_BY
         , SYSDATE                    AS CREATE_DTTM
         , NULL                       AS MODIFY_BY
         , NULL                       AS MODIFY_DTTM
--SELECT A.MEASURE_CD, GRP_3.CONF_CD
      FROM TB_DP_MEASURE_MST A
           LEFT OUTER JOIN
           TB_CM_COMM_CONFIG GRP_3
           ON (A.MEASURE_VAL_TP_ID = GRP_3.ID)
     WHERE 1=1
       AND A.DP_YN = 'Y'
       AND CASE WHEN (   P_UI_ID LIKE 'UI_DP_25%'
                      OR P_UI_ID LIKE 'UI_DP_26%'
                      OR P_UI_ID LIKE 'UI_DP_95%'
                      OR P_UI_ID LIKE 'UI_DP_96%')
                THEN 'Y'
                ELSE 'N' END        = COALESCE(A.SYSTEM_YN, 'N')
       AND COALESCE(A.DEL_YN, 'N')  = 'N'
       AND GRP_3.CONF_GRP_CD        = 'DP_MS_VAL_TP'
       AND GRP_3.ACTV_YN            = 'Y'        
    ;
    -----2. Demand AO？？A Level ------------------------------------------------------------------------------------------
    -- MEASURE ？？？？？o COUNT
    SELECT COUNT(*) INTO V_SEQ 
      FROM TB_DP_MEASURE_SETTING
     WHERE 1=1 
       AND UI_ID = P_UI_ID
       AND GRID_ID = P_GRID_ID
       AND RTRIM(GRP_ID) = P_GRP_ID
    ;

    -- MEASURE VERSION A？？AO DEFAULT ？？？A？？？？I
    SELECT COUNT(GRP_4.ID) INTO P_ERR_STATUS
      FROM TB_CM_COMM_CONFIG GRP_4
     WHERE 1=1
       AND GRP_4.CONF_GRP_CD    = 'DP_MS_VER_TP'
       AND GRP_4.ACTV_YN        = 'Y'  
       AND GRP_4.CONF_CD        = 'CT'
--                           AND GRP_4.DEFAT_VAL = 'Y'
    ;

    IF (P_ERR_STATUS = 0)
    THEN
        V_DP_MS_VER_TP := NULL;
    ELSE
        SELECT GRP_4.ID INTO V_DP_MS_VER_TP
          FROM TB_CM_COMM_CONFIG GRP_4
         WHERE 1=1
           AND GRP_4.CONF_GRP_CD    = 'DP_MS_VER_TP'
           AND GRP_4.ACTV_YN        = 'Y'  
           AND GRP_4.CONF_CD        = 'CT'
--                             AND GRP_4.DEFAT_VAL = 'Y'
        ;                           
    END IF; 

    INSERT INTO TB_DP_MEASURE_SETTING (
        ID
      , UI_ID
      , GRID_ID
      , GRP_ID
      , MEASURE_CONF_TP_ID
      , LV_MGMT_ID            -- 'DEMAND'AI？？？？ MEASURE CODE
      , MEASURE_MST_ID        -- 'ADDITION'AI？？？？ MEASURE CODE
      , VER_APPY_BASE_ID
      , MEASURE_VAL_TP_ID
      , INPUT_YN
      , DISP_NM
      , SEQ
      , ACTV_YN
      , CREATE_BY
      , CREATE_DTTM
      , MODIFY_BY
      , MODIFY_DTTM
    )
    SELECT TO_SINGLE_BYTE(SYS_GUID())   AS ID
         , P_UI_ID                      AS UI_ID
         , P_GRID_ID                    AS GRID_ID
         , P_GRP_ID                     AS GRP_ID
         , (SELECT GRP_1.ID     
              FROM TB_CM_CONFIGURATION CON 
             INNER JOIN TB_CM_COMM_CONFIG GRP_1  
                ON CON.ID = GRP_1.CONF_ID 
             WHERE 1=1
               AND CON.CONF_NM          = GRP_1.CONF_GRP_CD
               AND GRP_1.CONF_GRP_CD    = 'DP_MS_INPUT_TP'
               AND GRP_1.ACTV_YN        = 'Y'
               AND GRP_1.CONF_CD        = 'DEMAND' 
           )                            AS MEASURE_CONF_TP_ID                      
         , LV.ID                        AS LV_MGMT_ID
         , NULL                         AS MEASURE_MST_ID
         , V_DP_MS_VER_TP               AS VER_APPY_BASE_ID
         , GRP_3.ID                     AS MEASURE_VAL_TP_ID 
         , 'N'                          AS INPUT_YN
         , LV.LV_CD
           || '_'                
           || GRP_3.CONF_CD             AS DISP_NM
         , V_SEQ+ROWNUM                 AS SEQ
         , 'Y'                          AS ACTV_YN
         , P_USER_ID                    AS CREATE_BY
         , SYSDATE                      AS CREATE_DTTM
         , NULL                         AS MODIFY_BY
         , NULL                         AS MODIFY_DTTM 
--SELECT LV_CD, CONF_CD
      FROM TB_CM_CONFIGURATION CON 
     INNER JOIN TB_CM_COMM_CONFIG GRP  
        ON CON.ID = GRP.CONF_ID AND CON.CONF_NM = GRP.CONF_GRP_CD
     INNER JOIN TB_CM_LEVEL_MGMT LV		
        ON GRP.ID = LV.LV_TP_ID 
     INNER JOIN TB_CM_COMM_CONFIG GRP_3
        ON 1=1
     WHERE CON.MODULE_CD            = 'DP'
       AND GRP.CONF_GRP_CD          = 'DP_LV_TP'
       AND GRP.ACTV_YN              = 'Y'
       AND GRP.CONF_CD              = 'S'
       AND LV.ACTV_YN               = 'Y'
       AND COALESCE(LV.DEL_YN,'N')  = 'N'
       AND LV.SALES_LV_YN           = 'Y'
       AND LV.ID IN (SELECT LV_MGMT_ID
                       FROM TB_DP_CONTROL_BOARD_MST)
       AND GRP_3.CONF_GRP_CD        = 'DP_MS_VAL_TP' 
       AND GRP_3.ACTV_YN            = 'Y'    
       ORDER BY LV.SEQ       
    ;      
    -------------------------------------------------------------------------------------------------------------------------

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001'; 

EXCEPTION WHEN OTHERS THEN  -- ？？I？？？？ A？？AC？？CAo ？？EA？？ ？？？？？？U ？？c？？e : e_products_invalid    
    IF(SQLCODE = -20001)
    THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
    --SP_COMM_RAISE_ERR();              
        RAISE;
    END IF;
END;

/

