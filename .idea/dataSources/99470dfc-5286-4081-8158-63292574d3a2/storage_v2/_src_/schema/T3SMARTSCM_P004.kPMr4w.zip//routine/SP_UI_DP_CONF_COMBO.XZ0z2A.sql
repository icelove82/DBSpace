create PROCEDURE "SP_UI_DP_CONF_COMBO" (
    pRESULT OUT SYS_REFCURSOR
)IS 

/*****************************************************************************
Title : SP_DP_WORK_TP_COMBO
최초 작성자 : 이고은
최초 생성일 : 2017.07.07
 
설명 
 - SP_DP_WORK_TP_COMBO
  
History (수정일자 / 수정자 / 수정내용)
- 2017.07.07 / 이고은 / 최초 작성
- 2020.12.23 / 민경훈 / MSSQL -> ORACLE
*****************************************************************************/
BEGIN
    OPEN pRESULT FOR
    SELECT ID
         , CD
         , CD_NM
         , CONF_TP
      FROM (
        SELECT	 B.ID			AS ID
                ,B.CONF_CD		AS CD
                ,B.CONF_NM		AS CD_NM
                ,B.CONF_GRP_CD	AS CONF_TP
        FROM	TB_CM_CONFIGURATION A 
                INNER JOIN TB_CM_COMM_CONFIG B  ON A.ID = B.CONF_ID 
        WHERE	A.MODULE_CD = 'DP'
        AND		B.ACTV_YN	= 'Y'
        AND     B.CONF_GRP_CD != 'DP_APPV_EVT_TP'
        AND		B.CONF_GRP_CD != 'DP_APPV_CONST_TP'
        AND		B.CONF_GRP_CD != 'DP_INIT_VAL_TP'
        AND		B.CONF_GRP_CD != 'DP_INPUT_TP'
        AND		B.CONF_GRP_CD != 'DP_WK_TP'

        UNION	-- 다국어 Code 화
        SELECT	 B.ID										AS ID
                ,B.CONF_CD									AS CD
                ,'CF_'||B.CONF_GRP_CD||'_'||B.CONF_CD	    AS CD_NM
                ,B.CONF_GRP_CD								AS CONF_TP
        FROM	TB_CM_CONFIGURATION A 
                INNER JOIN TB_CM_COMM_CONFIG B  ON A.ID = B.CONF_ID 
        WHERE	A.MODULE_CD = 'DP'
        AND		B.ACTV_YN	= 'Y'
        AND     (
                   B.CONF_GRP_CD = 'DP_APPV_EVT_TP'
                OR B.CONF_GRP_CD = 'DP_APPV_CONST_TP'
                OR B.CONF_GRP_CD = 'DP_INIT_VAL_TP'
                OR B.CONF_GRP_CD = 'DP_INPUT_TP'
                OR B.CONF_GRP_CD = 'DP_WK_TP'
        )
    )
	ORDER BY CONF_TP
    ;
END;

/

