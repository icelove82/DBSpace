create PROCEDURE        "SP_UI_CM_01_POP_101_S" (
	 P_ID                       IN VARCHAR2 := ''
	,P_PRIORT		            IN NUMBER := ''
    ,P_VAL		                IN VARCHAR2 := ''
    ,P_ACTV_YN		            IN VARCHAR2 := ''
    ,P_DEFAT_VAL		        IN VARCHAR2 := ''
    ,P_WRK_TYPE	                IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG         OUT VARCHAR2 
    ,P_RT_MSG                   OUT VARCHAR2
    
)
IS

    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';

BEGIN
IF P_WRK_TYPE = 'SAVE'
THEN

        P_ERR_MSG := 'MSG_0008'; -- '?????？?？？？ ?? ?????？？ '
            IF P_PRIORT < 0  THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;

    UPDATE TB_CM_COMM_CONFIG
		   SET PRIORT	= TO_CHAR(P_PRIORT)
		     , ATTR_01		= P_VAL
			 , ACTV_YN		= P_ACTV_YN
			 , DEFAT_VAL	= P_DEFAT_VAL
		 WHERE ID = P_ID;

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';  --???？？????？？

END IF;

        EXCEPTION
        WHEN OTHERS THEN
            P_RT_ROLLBACK_FLAG := 'false';
            IF(SQLCODE = -20012)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF; 

END;

/

