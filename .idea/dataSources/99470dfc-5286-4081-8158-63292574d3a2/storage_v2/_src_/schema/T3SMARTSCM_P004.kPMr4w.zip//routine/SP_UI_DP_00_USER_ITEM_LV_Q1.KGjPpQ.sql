create PROCEDURE "SP_UI_DP_00_USER_ITEM_LV_Q1" (
    p_EMP_NO        VARCHAR2    := NULL	
  , p_AUTH_TP_ID    CHAR        := NULL 
  , p_LEAF_YN       IN CHAR     := ''
  , p_TYPE          IN VARCHAR2 := ''                                    
  , pRESULT         OUT SYS_REFCURSOR
) IS 

/************************************************************************
    작성자 : 김소희
    작성일 : 2019.05.20
    프로시저 오류를 막기위한 기본 기능만 우선 컨버팅    

    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID     
************************************************************************/

    P_EMP_ID CHAR(32);
    P_CNT INT;
BEGIN
    IF P_EMP_NO IS NULL
    THEN 
        P_EMP_ID := NULL;
    ELSE
        SELECT ID INTO P_EMP_ID
          FROM TB_AD_USER
         WHERE USERNAME = P_EMP_NO;
    END IF;

    IF P_EMP_ID IS NULL OR P_AUTH_TP_ID IS NULL THEN
        OPEN pRESULT
        FOR
    	SELECT * 
    	FROM ( 
    			SELECT  '' AS ID 
    				  , UPPER(P_TYPE)  AS CD
    				  , UPPER(P_TYPE)  AS CD_NM
    				  , 0 AS LV_SEQ
    				  , 0 AS SEQ
                 FROM DUAL
    			WHERE UPPER(P_TYPE) = 'ALL'
    			UNION ALL 
    			SELECT IL.ID
    				  ,IL.ITEM_LV_CD AS CD 
    				  ,IL.ITEM_LV_NM AS CD_NM 
    				  ,LM.SEQ AS LV_SEQ
    				  ,IL.SEQ
    			  FROM TB_CM_CONFIGURATION A
    				 , TB_CM_COMM_CONFIG B
    				 , TB_CM_LEVEL_MGMT  LM
    				 , TB_CM_ITEM_LEVEL_MGMT  IL
    			  WHERE A.MODULE_CD = 'DP'
    				AND A.ID = B.CONF_ID
    				AND B.CONF_GRP_CD = 'DP_LV_TP'
    				AND B.CONF_CD = 'I'
    				AND B.ID = LM.LV_TP_ID  -- S/C/I
    				AND NVL(LM.DEL_YN,'N') = 'N'
    				AND LM.ACTV_YN = 'Y'
    				AND LM.ID = IL.LV_MGMT_ID 
    				AND LM.LV_LEAF_YN  LIKE '%' || p_LEAF_YN ||'%'	
    				AND NVL(IL.DEL_YN,'N') = 'N'
    				AND IL.ACTV_YN = 'Y'
    	     )  A
    	 ORDER BY A.LV_SEQ, A.SEQ
    	;
    ELSE
        OPEN pRESULT
        FOR
        SELECT NULL  AS ID
             , 'ALL' AS CD_NM
             , 'ALL' AS CD
          FROM DUAL 
         WHERE P_TYPE = 'ALL'
        UNION
        SELECT IL.ID
             , IL.ITEM_LV_NM AS CD_NM
             , IL.ITEM_LV_CD AS CD
          FROM TABLE(FN_DP_TEMP_FIND_ITEM(P_EMP_ID, P_AUTH_TP_ID, NULL)) FI
         INNER JOIN TB_CM_ITEM_LEVEL_MGMT IL
            ON IL.ID = FI.PARENT_ITEM_LV_ID
         GROUP BY IL.ID, ITEM_LV_CD, ITEM_LV_NM
        ;
    END IF;
END;

/

