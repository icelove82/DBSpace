create PACKAGE                 PKG_SMP_O_RESULT IS
PRAGMA SERIALLY_REUSABLE;
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved.
**************************************************************************
* Name    : PKG_SMP_I_RESULT
* Purpose : MP RESULT 정보 생성.
* Notes   :
**************************************************************************
* History :
* 2020-02-27 JMS Created
**************************************************************************/
-----------------------------
-- Public type declarations - 
-----------------------------

/*
 * TB_SMP_RS_LINE_PROD
 * TB_SMP_RS_RM_CONSUME_P1
 * TB_SMP_RS_RM_CONSUME_P2
 * TB_SMP_RS_RM_CONSUME_V
 * TB_SMP_RS_RTF
 * */

PROCEDURE SP_GET_RESULT_LINE_PROD (
  P_sENGINE_ID       IN  VARCHAR2
, P_sVERSION_ID      IN  VARCHAR2
, P_sPDB_VERSION_ID  IN  VARCHAR2
, P_sROLLING_FLAG    IN  VARCHAR2
, P_sBASE_YEAR       IN  VARCHAR2
, P_sBASE_MONTH      IN  VARCHAR2
, O_FLAG             OUT VARCHAR2
);

PROCEDURE SP_GET_RESULT_RTF (
  P_sENGINE_ID       IN  VARCHAR2
, P_sVERSION_ID      IN  VARCHAR2
, P_sPDB_VERSION_ID  IN  VARCHAR2
, P_sROLLING_FLAG    IN  VARCHAR2
, P_sBASE_YEAR       IN  VARCHAR2
, P_sBASE_MONTH      IN  VARCHAR2
, O_FLAG             OUT VARCHAR2
);


PROCEDURE SP_GET_RESULT_CONSUME (
  P_sENGINE_ID       IN  VARCHAR2
, P_sVERSION_ID      IN  VARCHAR2
, P_sPDB_VERSION_ID  IN  VARCHAR2
, P_sROLLING_FLAG    IN  VARCHAR2
, P_sBASE_YEAR       IN  VARCHAR2
, P_sBASE_MONTH      IN  VARCHAR2
, O_FLAG             OUT VARCHAR2
);

PROCEDURE SP_GET_RESULT_PROBLEM (
  P_sENGINE_ID       IN  VARCHAR2
, P_sVERSION_ID      IN  VARCHAR2
, P_sPDB_VERSION_ID  IN  VARCHAR2
, P_sROLLING_FLAG    IN  VARCHAR2
, P_sBASE_YEAR       IN  VARCHAR2
, P_sBASE_MONTH      IN  VARCHAR2
, O_FLAG             OUT VARCHAR2
);

END PKG_SMP_O_RESULT;

/

