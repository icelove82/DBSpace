create PROCEDURE "SP_UI_DP_23_TAB_S3" (
											 p_ID				IN VARCHAR2		:= ''    
											,p_CL_TP_ID			IN VARCHAR2		:= ''  	
											,p_CL_LV_MGMT_ID	IN VARCHAR2		:= ''  		
											,p_USER_ID			IN VARCHAR2		:= ''      
	  										) 
IS
/*********************************************************************
    ???？ ?？?° ？?？Close Tab?？???？？
*********************************************************************/ 
BEGIN 

	UPDATE  TB_DP_CONTROL_BOARD_VER_DTL 
	SET		 CL_TP_ID		= p_CL_TP_ID		
			,CL_LV_MGMT_ID	= p_CL_LV_MGMT_ID
			,MODIFY_BY		= p_USER_ID			 
			,MODIFY_DTTM	= SYSDATE 
	WHERE	ID	=  p_ID;

END;


/

