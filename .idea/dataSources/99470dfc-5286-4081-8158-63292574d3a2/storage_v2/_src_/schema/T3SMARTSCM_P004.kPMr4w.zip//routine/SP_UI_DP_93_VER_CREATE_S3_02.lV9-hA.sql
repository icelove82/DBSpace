create PROCEDURE                 "SP_UI_DP_93_VER_CREATE_S3_02"  (
			P_VER_ID					CHAR 
          , P_FROM_DATE                 DATE 
          , P_TO_DATE                   DATE
          , P_BUKT                      VARCHAR2 
          , pRESULT        OUT SYS_REFCURSOR
)
IS  
/**************************************************************************************************************
    -- Oracle Test瑜� �쐞�븳 SP_UI_DP_93_VER_CREATE_S3 �봽濡쒖떆�� PART 1
    -- �룞�쟻荑쇰━ �솗�씤�슜... �떎�뼇�븳 Case test�븯怨� 湲곕낯 �봽濡쒖떆���옉 �빀移� �삁�젙

    - History ( date / writer / comment )
    - 2021.02.03 / kim sohee / �늻�씫�맂 where 議곌굔 異붽� (data 紐살갼�뒗 error�뿉 ���븳 �삁�쇅 泥섎━ 愿��젴) 
    - 2021.05.03 / kimsohee/ Get Measure Data by DP Bucket => �씪�떒�� Custom 
                           / SK Inovation custom : One version data Seperate Monthly & Yealy plan        
*************************************************************************************************************/	 
		   -- For Loop 
		   P_STR	VARCHAR2(4000); 
           p_SELECT_STR    VARCHAR2(4000);
           P_YEARLY_PLAN_CASE VARCHAR2(4000) := ''; 
           P_YEARLY_PLAN_SELECT VARCHAR2(4000) := '';
		   P_VAL_CNT  INT ;        
BEGIN 
         SELECT COUNT(1) INTO P_VAL_CNT
           FROM TABLE(FN_DP_TEMP_VER_INFO_DTL (P_VER_ID))
          WHERE INIT_TP_CD = 'MS'   
           ;
        IF( P_VAL_CNT = 0)
            THEN
                SELECT COUNT(1) INTO P_VAL_CNT
                  FROM TABLE(FN_DP_TEMP_VER_INFO_INIT (P_VER_ID)) 
                 WHERE INIT_VAL_TP_CD = 'MS'   
                 ;
            END IF;
        IF (P_VAL_CNT > 0)
			THEN	
				P_STR := '';		 
				WITH INI
				  AS (
					SELECT DTL_ID 
						 , AUTH_TP_ID 
						 , INIT_VAL_CD|| ' AS QTY' AS COL
						 , 'QTY' as VAL_COL
						 , 'SRC.QTY'  as IST_COL
						 , 'TGT.QTY = SRC.QTY' as UPT_COL
					 FROM TABLE(FN_DP_TEMP_VER_INFO_DTL (P_VER_ID)) 
					WHERE INIT_TP_CD = 'MS' 
					UNION
					SELECT DTL_ID 
						 , AUTH_TP_ID 
						 , LISTAGG(INIT_MEASURE_CD||' AS '||INIT_MS_VAL_TP_CD, ',') within group (order by INIT_MEASURE_CD)  AS COL
--						 , LISTAGG(INIT_MEASURE_CD, ',') within group (order by INIT_MS_VAL_TP_CD AS MS_COL
						 , LISTAGG(INIT_MS_VAL_TP_CD, ',') within group (order by INIT_MS_VAL_TP_CD) AS VAL_COL
						 , LISTAGG('SRC.'||INIT_MS_VAL_TP_CD, ',') within group (order by INIT_MS_VAL_TP_CD) as IST_COL
						 , LISTAGG ('TGT.'||INIT_MS_VAL_TP_CD||'='||'SRC.'||INIT_MS_VAL_TP_CD, ',') within group (order by INIT_MS_VAL_TP_CD) as UPT_COL
					  FROM TABLE(FN_DP_TEMP_VER_INFO_INIT (P_VER_ID)) 
					 WHERE INIT_VAL_TP_CD = 'MS' 
					 GROUP BY DTL_ID, AUTH_TP_ID
				  ) 
				SELECT  P_STR 
					 || ' MERGE INTO TEMP_DP_RT TGT'
					 || ' USING (			  '
					 || 'SELECT ITEM_MST_ID, ACCOUNT_ID '
				     || ','''||AUTH_TP_ID||''' AS AUTH_TP_ID '
				     || ','''||DTL_ID||''' AS DTL_ID '
                     || '@@YEARLY_PLAN_SELECT'
					 || coalesce('('||COL||')','')||' AS '||COL
					 || ' FROM TB_DP_MEASURE_DATA M'
                     || '@@YEARLY_PLAN_CASE'
					 || ' WHERE BASE_DATE BETWEEN TO_DATE( '''||TO_CHAR(P_FROM_DATE, 'YYYY-MM-DD' )||''') AND TO_DATE( '''||TO_CHAR( P_TO_DATE, 'YYYY-MM-DD')||''') '					                      
                     || ' ) SRC '
					 || ' ON (SRC.ITEM_MST_ID = TGT.ITEM_MST_ID '
					 || ' AND SRC.ACCOUNT_ID = TGT.ACCOUNT_ID '
					 || ' AND SRC.BASE_DATE = TGT.BASE_DATE '
					 || ' AND SRC.AUTH_TP_ID = TGT.AUTH_TP_ID) '
					 || ' WHEN MATCHED THEN '
					 || ' UPDATE SET '||UPT_COL
					 || ' WHEN NOT MATCHED THEN '
					 || ' INSERT  ( '
					 || ' ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, AUTH_TP_ID ,'
					 ||  VAL_COL
					 || ' ) VALUES '
					 || ' (SRC.ITEM_MST_ID, SRC.ACCOUNT_ID, SRC.BASE_DATE, SRC.AUTH_TP_ID ,'
					 || IST_COL
					 || ' )'
					 INTO P_STR
				 FROM INI 
				;	
                IF (P_BUKT IS NOT NULL)
                    THEN
                        P_YEARLY_PLAN_CASE := 'INNER JOIN '
                        ||'( SELECT MIN(DAT) AS STRT_DATE, MAX(DAT) AS END_DATE '
                        ||' FROM TB_CM_CALENDAR '
                        ||' GROUP BY '     
                        ;
                        IF P_BUKT = 'Y'
                            THEN
                            P_YEARLY_PLAN_CASE := P_YEARLY_PLAN_CASE || 'YYYY';
                        ELSIF P_BUKT = 'M'
                            THEN
                            P_YEARLY_PLAN_CASE := P_YEARLY_PLAN_CASE || 'YYYY, MM';
                        ELSIF P_BUKT = 'PW'
                            THEN
                            P_YEARLY_PLAN_CASE := P_YEARLY_PLAN_CASE || 'MM, DP_WK';
                        ELSIF P_BUKT = 'W'
                            THEN
                            P_YEARLY_PLAN_CASE := P_YEARLY_PLAN_CASE || 'DP_WK';                            
                        END IF
                        ;
                        P_YEARLY_PLAN_CASE := P_YEARLY_PLAN_CASE || ') CA ON M.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE ';
                        P_YEARLY_PLAN_SELECT := 'CA.STRT_DATE AS BASE_DATE, SUM';
                    ELSE
                        P_YEARLY_PLAN_SELECT := 'M.BASE_DATE, ';
                    END IF;

                        P_STR := REPLACE(P_STR
                                        , '@@YEARLY_PLAN_CASE'
                                        , P_YEARLY_PLAN_CASE
                                        )
                        ;                
                        P_STR := REPLACE(P_STR
                                        ,'@@YEARLY_PLAN_SELECT'
                                        ,P_YEARLY_PLAN_SELECT
                                        )
                        ;

                OPEN PRESULT FOR 
                SELECT P_STR
                  FROM DUAL;
				EXECUTE IMMEDIATE P_STR;	 
			END IF
            ;

END
;
/

