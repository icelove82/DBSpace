create PROCEDURE SP_UI_CM_17_S6 (
     P_CONBD_MAIN_VER_MST_ID  IN CHAR :=''
    ,P_PLAN_SNRIO_MGMT_DTL_ID IN CHAR :=''
    ,P_ORIGIN_CONBD_MAIN_VER_DTL_ID  IN CHAR :=''
    ,P_USER_ID   IN VARCHAR2 :=''
    ,pResult OUT SYS_REFCURSOR
)
IS
    P_MAX_SIMUL_SEQ NUMBER :=1;
    P_MAIN_VER_ID VARCHAR2(30) :='';
    P_CONBD_MAIN_VER_DTL_ID CHAR(32) :='';
    P_ORIGNAL_MAX_SIMUL_VER_ID VARCHAR2(50) :='';
    P_ORIGN_MAX_SIMUL_VER_DESCRIP VARCHAR2(4000) :='';

BEGIN

    SELECT A.SIMUL_VER_ID
        ,  A.SIMUL_VER_DESCRIP
           INTO P_ORIGNAL_MAX_SIMUL_VER_ID,
           P_ORIGN_MAX_SIMUL_VER_DESCRIP
      FROM TB_CM_CONBD_MAIN_VER_DTL A
     WHERE 1=1
       AND A.ID = P_ORIGIN_CONBD_MAIN_VER_DTL_ID;

    P_CONBD_MAIN_VER_DTL_ID := TO_SINGLE_BYTE(SYS_GUID());

   SELECT NVL(MAX(TO_NUMBER(LTRIM(REPLACE(REPLACE(B.SIMUL_VER_ID,A.MAIN_VER_ID,''),'-','')))) ,0) + 1 
        , A.MAIN_VER_ID
          INTO P_MAX_SIMUL_SEQ, P_MAIN_VER_ID
      FROM  TB_CM_CONBD_MAIN_VER_MST A
            INNER JOIN
            TB_CM_CONBD_MAIN_VER_DTL B
            ON A.ID = B.CONBD_MAIN_VER_MST_ID
     WHERE 1=1
       AND A.ID = P_CONBD_MAIN_VER_MST_ID
        GROUP BY A.MAIN_VER_ID;

    INSERT INTO TB_CM_CONBD_MAIN_VER_DTL 
    (
        ID
        ,CONBD_MAIN_VER_MST_ID
        ,PLAN_SNRIO_MGMT_DTL_ID
        ,EXE_STATUS_ID
        ,STEP_STATUS_ID
        ,SIMUL_VER_ID
        ,CONFRM_YN
        ,CREATE_BY
        ,CREATE_DTTM
    )
    SELECT  P_CONBD_MAIN_VER_DTL_ID
           ,P_CONBD_MAIN_VER_MST_ID AS CONBD_MAIN_VER_MST_ID
           ,P_PLAN_SNRIO_MGMT_DTL_ID  AS PLAN_SNRIO_MGMT_DTL_ID
           ,B.ID AS EXE_STATUS_ID
           ,A.ID AS STEP_STATUS_ID
           ,P_MAIN_VER_ID || '-' ||LPAD (TO_CHAR(P_MAX_SIMUL_SEQ),'3','0') AS SIMUL_VER_ID
           ,'N' AS CONFRM_YN
           ,P_USER_ID
           ,SYSDATE()
       FROM (
            SELECT A.ID
            FROM TB_AD_COMN_CODE A
                        INNER JOIN
                        TB_AD_COMN_GRP B
                        ON A.SRC_ID = B.ID
             WHERE 1=1
               AND B.GRP_CD='STEP_STATUS'
               AND A.COMN_CD='READY'
            ) A,
            (
            SELECT A.ID
            FROM  TB_AD_COMN_CODE A
                        INNER JOIN
                        TB_AD_COMN_GRP B
                        ON A.SRC_ID = B.ID
                       AND B.GRP_CD='EXE_STATUS'
             WHERE 1=1 
               AND A.COMN_CD ='EXE_02'
            ) B;
            
    OPEN pResult FOR
     SELECT  E.COMN_CD AS MODULE_CD
           ,A.MAIN_VER_ID
           ,A.DESCRIP AS MAIN_VER_DESCRIP
           ,D.SNRIO_VER_ID
           ,D.DESCRIP AS SNRIO_VER_DESCRIP
           ,C.STEP
           ,C.PROCESS_DESCRIP
           ,F.COMN_CD_NM AS PROCESS_TP
           ,P_ORIGNAL_MAX_SIMUL_VER_ID AS ORIGINAL_VER_ID
           ,P_ORIGN_MAX_SIMUL_VER_DESCRIP AS ORIGINAL_DESCRIP
           ,B.SIMUL_VER_ID AS MAX_SIMUL_VER_ID
           ,B.SIMUL_VER_DESCRIP
           ,B.PLAN_SNRIO_MGMT_DTL_ID
           ,B.CONBD_MAIN_VER_MST_ID
      FROM TB_CM_CONBD_MAIN_VER_MST A 
           INNER JOIN 
           TB_CM_CONBD_MAIN_VER_DTL B  
        ON (A.ID = B.CONBD_MAIN_VER_MST_ID)
           INNER JOIN
           TB_CM_PLAN_SNRIO_MGMT_DTL C 
        ON (B.PLAN_SNRIO_MGMT_DTL_ID = C.ID)
           INNER JOIN 
           TB_CM_PLAN_SNRIO_MGMT_MST D 
        ON (C.PLAN_SNRIO_MGMT_MST_ID = D.ID)
           INNER JOIN 
           TB_AD_COMN_CODE E 
        ON (A.MODULE_ID = E.ID)
           INNER JOIN 
           TB_AD_COMN_CODE F 
        ON (C.PROCESS_TP_ID = F.ID)
     WHERE 1=1
       AND B.ID = P_CONBD_MAIN_VER_DTL_ID;

END;

/

