create PROCEDURE SP_CM_MAKE_CALENDAR_DATA (
        P_FROM_DATE DATE
       ,P_TO_DATE   DATE
       ,P_STD_WK    VARCHAR2 := 'SUN' --SUN/MON/TUE/WED/...(DP_STD_WEEK)
       ,P_USER_ID   VARCHAR2    
)IS
--------------------------------------------------------------------------------------------------------
    -- Calendar ？？？？？？ ？？？？ ？？？ν？？？
    -- ？？？？
    -- P_FROM_DATE<= DAT <=P_TO_DATE
    -- HOLID : Sunday, ？？？？, ？？？  

    -- ？？？？？ : ？？？？？？
    -- ？？？？？ : 2019.01.29
    -- HISTORY (？？？？？？ / ？？？？？？ / ？？？？ ？？？？)
    -- 2019.01.30 / ？？？？？？ / ？？？ ？？？ ？？？ (？？？？ ？？？？？ ？？？？？？ ？？？？？？ ？？？？ TB_CM_CALENDAR_TMP？？ ？？？？？？ ？？？？)
    -- 2019.01.31 / ？？？？？？ / STD_WEEK ？？ ？？？？？？ ？？？？？？ ？？？？？？？？？. ？？？？？？ 0？？？？ ？？？？？？？ ？？？ ？？？.
    -- 2019.02.07 / ？？？？？？ / ？？？？ ？？？ ？？？？？ ？？？？？？？？ ？？？？ ？？？o？？ (？？？？？？ ？켱 null？？)
-------------------------------------------------------------------------------------------------------   
    V_FROM_LUNAR_DT DATE := P_FROM_DATE;
    V_TO_LUNAR_DT   DATE := P_TO_DATE+1;
    V_STD_WK_NUM    INT;
BEGIN
------------------------------------------------------------------------------------------------------
    -- INIT TABLE DATA
------------------------------------------------------------------------------------------------------
    DELETE 
      FROM TB_CM_CALENDAR_TMP
    ;
            INSERT INTO TB_CM_CALENDAR_TMP
            (
                  ID
                , DAT_ID
                , DAT
                , YYYY
                , YYYY_SEQ
                , MM
                , DD
                , YYYYMM
                , YYYYMM_SEQ
                , YYYYMMDD
                , YYYYMMDD_SEQ
                , DOW
                , DOW_NM
                , WK52
                , WK52_SEQ
                , PARTWK
                , PARTWK_SEQ
                , LUNAR_CAL_DAT_ID
                , HOLID_YN
                , HOLID_NM
                , HOLID_DESCRIP
                , CREATE_BY
                , CREATE_DTTM
                , MODIFY_BY
                , MODIFY_DTTM
                , QTR
                , QTR_NM
                , HALF
                , HALF_NM    
            )
    --OPEN pRESULT   FOR
            SELECT 
                TO_SINGLE_BYTE(SYS_GUID())                                       AS ID
              , TO_CHAR(P_FROM_DATE + ROWNUM-1,'YYYYMMDD')                                   AS DAT_ID
              , P_FROM_DATE + ROWNUM-1                                                       AS DAT
              , TO_CHAR(P_FROM_DATE + ROWNUM-1, 'YYYY')                                      AS YYYY
              , DENSE_RANK() OVER (ORDER BY TO_CHAR(P_FROM_DATE + ROWNUM-1, 'YYYY') ASC)     AS YYYY_SEQ
              , TO_NUMBER(TO_CHAR(P_FROM_DATE + ROWNUM-1, 'MM'))                             AS MM
              , TO_NUMBER(TO_CHAR(P_FROM_DATE + ROWNUM-1,'DD'))                              AS DD
              , TO_CHAR(P_FROM_DATE + ROWNUM-1, 'YYYYMM')                                    AS YYYYMM
              , DENSE_RANK() OVER (ORDER BY TO_CHAR(P_FROM_DATE + ROWNUM-1, 'YYYYMM') ASC)   AS YYYYMM_SEQ
              , TO_CHAR(P_FROM_DATE + ROWNUM-1, 'YYYYMMDD')                                  AS YYYYMMDD
              , DENSE_RANK() OVER (ORDER BY TO_CHAR(P_FROM_DATE + ROWNUM-1, 'YYYYMMDD') ASC) AS YYYYMMDD_SEQ
              , CASE WHEN TO_CHAR(P_FROM_DATE + ROWNUM-1,'D') = 1 
                     THEN 7 ELSE TO_CHAR(P_FROM_DATE + ROWNUM-1,'D')-1 END                   AS DOW      -- ？？？？ ？？？？？？？？ ？？？？ ？？？？？？？ ISO？？？？(？？？？？？ ？？？？)？？？？ ？켱 ？？？. DOW？？ ISO？？ ？？？ DB ？？？？ ？？？？？？？ ？？？？. (DB - SUN : 1 / DOW - MON : 1)
              , TO_CHAR(P_FROM_DATE + ROWNUM-1, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH')           AS DOW_NM
              , TO_CHAR(P_FROM_DATE + ROWNUM-1, 'YYYYIW')                                    AS WK52     --  ISO？？ ？？？？？？ ？？？？ (？？？？？？ ？？？？？？？？？ ？？？？？？ u°？？ ？？？？？？ ？？？？- ？？~？？ : 1W / ？？？？ ？？？W)
              , NULL   AS WK52_SEQ
              , TO_CHAR(P_FROM_DATE + ROWNUM-1, 'YYYYIW')                                    AS PARTWK   --Partial Week
              , NULL                                                                         AS PARTWK_SEQ                  
              , NULL                                                                         AS LUNAR_CAL_DAT_ID    
              ,  CASE TO_CHAR(P_FROM_DATE + ROWNUM-1, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') WHEN 'SUN' THEN 'Y'
                                                ELSE 'N' END                     AS HOLID_YN
              ,  CASE TO_CHAR(P_FROM_DATE + ROWNUM-1, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') WHEN 'SUN' THEN INITCAP('SUN'||'day') 
                                               ELSE NULL END                     AS HOLID_NM
              , CASE TO_CHAR(P_FROM_DATE + ROWNUM-1, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') WHEN 'SUN' THEN INITCAP('SUN'||'day') 
                                               ELSE NULL END                     AS HOLID_DESCRIP
              , P_USER_ID                                                        AS CREATE_BY
              , SYSDATE                                                          AS CREATE_DTTM
              , NULL                                                             AS MODIFY_BY
              , NULL                                                             AS MODIFY_DTTM
              , CASE WHEN TO_NUMBER(TO_CHAR(P_FROM_DATE + ROWNUM-1,'MM')) <4    THEN 1     --1~3
                     WHEN TO_NUMBER(TO_CHAR(P_FROM_DATE + ROWNUM-1,'MM')) <7    THEN 2     --4~6
                     WHEN TO_NUMBER(TO_CHAR(P_FROM_DATE + ROWNUM-1,'MM')) <10   THEN 3     --7~9
                     ELSE 4 END                                                  AS QTR    --10~12
              , CASE WHEN TO_NUMBER(TO_CHAR(P_FROM_DATE + ROWNUM-1,'MM')) <4    THEN 1            
                     WHEN TO_NUMBER(TO_CHAR(P_FROM_DATE + ROWNUM-1,'MM')) <7    THEN 2            
                     WHEN TO_NUMBER(TO_CHAR(P_FROM_DATE + ROWNUM-1,'MM')) <10   THEN 3            
                     ELSE 4  END||'Q'                                            AS QTR_NM
              , CASE WHEN TO_NUMBER(TO_CHAR(P_FROM_DATE + ROWNUM-1,'MM')) <=6 
                     THEN 1 ELSE 2 END                                           AS HALF
              , CASE WHEN TO_NUMBER(TO_CHAR(P_FROM_DATE + ROWNUM-1,'MM')) <=6 
                     THEN 1 ELSE 2 END ||'H'                                     AS HALF_NM
            FROM DUAL  
      CONNECT BY level <= ROUND( P_TO_DATE+1 - P_FROM_DATE )
        ORDER BY P_FROM_DATE + ROWNUM-1  
            ;
---------------------------------------------------------------------------------------------------
        -- ？？？？ STD_WEEK？？ ？？？？？？
---------------------------------------------------------------------------------------------------
    -- 12？？？？？ 1？？？ 53, 1？？？？？ 53？？？ 1.
    -- 1？？？？？ 52？？？ 0 (？？ ？？？？？？？ 1？？ ？？？？？？？ ？？？？)
    MERGE INTO TB_CM_CALENDAR_TMP A
    USING (
            SELECT CASE WHEN MM = 12 AND SUBSTR(WK52, 5,2) = '01' THEN SUBSTR(WK52,1,4)||'53'
                        WHEN MM = 1  AND SUBSTR(WK52, 5,2) IN ('52', '53') THEN SUBSTR(WK52,1,4)||'00'
                        ELSE WK52 END AS WK52     
                  ,DAT_ID      
              FROM TB_CM_CALENDAR_TMP
             WHERE MM IN (12,1)
               AND SUBSTR(WK52, 5,2) IN ('01','53','52')
           ) B ON (A.DAT_ID = B.DAT_ID)
    WHEN MATCHED THEN 
        UPDATE SET A.WK52 = B.WK52
                ,  A.PARTWK = B.WK52
      ;   
    -- UI ？？？？ ？？ ？？？？ ？？？？ ？？？？？？
      SELECT DOW INTO V_STD_WK_NUM
        FROM TB_CM_CALENDAR_TMP 
       WHERE DOW_NM = P_STD_WK 
    GROUP BY DOW;

    MERGE INTO TB_CM_CALENDAR_TMP A
    USING (
              SELECT CASE WHEN V_STD_WK_NUM = 1      -- ？？？？？？？？ ？？ 
                              THEN A.WK52
                          WHEN V_STD_WK_NUM = 7      -- ？？？？？？？ ？？
                              THEN case when a.dow >= v_std_wk_num then to_char(a.wk52+1) else a.wk52 end
                          WHEN V_STD_WK_NUM > 4      -- ？？？？？？？？？ ？ ？？ : ？？,？？
                              THEN (CASE WHEN V_STD_WK_NUM < Y.DOW
                                            THEN case when a.dow < v_std_wk_num then to_char(a.wk52-1) else a.wk52 end
                                            ELSE case when a.dow >= v_std_wk_num then to_char(a.wk52+1) else a.wk52 end
                                                                   END)
                          WHEN V_STD_WK_NUM <= 4      -- ？？？？？？？？？ ？ ？？ : ？,？？,？？
                              THEN (CASE WHEN V_STD_WK_NUM <= Y.DOW 
                                            THEN case when a.dow < v_std_wk_num then to_char(a.wk52-1) else a.wk52 end
                                            ELSE case when a.dow >= v_std_wk_num then to_char(a.wk52+1) else a.wk52 end
                                                                   END)
                              END AS WK52
                        , A.DAT_ID 
                FROM TB_CM_CALENDAR_TMP A
                     INNER JOIN 
                     TB_CM_CALENDAR_TMP Y
                 ON (A.YYYY = Y.YYYY AND Y.MM = 1 AND Y.DD = 1)                 
           ) B ON (A.DAT_ID = B.DAT_ID)
    WHEN MATCHED THEN 
        UPDATE SET A.WK52 = B.WK52
                ,  A.PARTWK = B.WK52
      ;
    -- ？？？？？？ WK52 ？？？？？？？？ WK52_SEQ UPDATE 
    MERGE INTO TB_CM_CALENDAR_TMP A
    USING (         SELECT  DENSE_RANK() OVER (ORDER BY WK52 ASC) AS WK52_SEQ
                           ,DAT_ID                       
                      FROM TB_CM_CALENDAR_TMP        
            ) B ON  (A.DAT_ID = B.DAT_ID)
    WHEN MATCHED THEN
        UPDATE SET A.WK52_SEQ = B.WK52_SEQ
        ;  
    -- DOW DB ？？？？ NUMBER？？ ？？？ ？？？ (？？？？？？？ 1？？ ？？？？？？？ ？？)
    MERGE INTO TB_CM_CALENDAR_TMP A
    USING (         SELECT  TO_CHAR(DAT, 'D') AS DOW, DAT_ID               
                      FROM TB_CM_CALENDAR_TMP        
            ) B ON  (A.DAT_ID = B.DAT_ID)
    WHEN MATCHED THEN
        UPDATE SET A.DOW = B.DOW
        ;   

-------------------------------------------------------------------------------------------------
        -- MAKE PARTIAL WEEK(S) 
-------------------------------------------------------------------------------------------------
    -- PARTWK A,B？？ ？？？？ UPDATE 
    MERGE INTO TB_CM_CALENDAR_TMP A
    USING (         SELECT  CASE WHEN DD > 7 THEN WK52||'A'                        
                                  ELSE WK52||'B' END        AS PARTWK
                           ,DAT_ID                       
                      FROM TB_CM_CALENDAR_TMP        
                     WHERE WK52 IN (SELECT WK52  
                                     FROM TB_CM_CALENDAR_TMP                        
                                     WHERE DD = 1
                                       AND DOW_NM != P_STD_WK        --'MON'  -- 1？？？？？ ？？？？ ？？？？？？ ？？？？ ？？？？
                                       AND SUBSTR(WK52,5,2) NOT IN('01', '53', '52', '00') -- u？？ u°？？, ？？？？？？？？ ？？？？？？ ？？？ ？？？？
                                    )                               
            ) B ON  (A.DAT_ID = B.DAT_ID)
    WHEN MATCHED THEN
        UPDATE SET A.PARTWK = B.PARTWK
        ;
    -- ？？？？？？ PARTWK ？？？？？？？？ PARTWK_SEQ UPDATE
    MERGE INTO TB_CM_CALENDAR_TMP A
    USING (         SELECT  DENSE_RANK() OVER (ORDER BY PARTWK ASC) AS PARTWK_SEQ
                           ,DAT_ID                       
                      FROM TB_CM_CALENDAR_TMP        
            ) B ON  (A.DAT_ID = B.DAT_ID)
    WHEN MATCHED THEN
        UPDATE SET A.PARTWK_SEQ = B.PARTWK_SEQ
        ;
-------------------------------------------------------------------------------------------------
--     -- ？？？？=>？？？？ ？？？ ？？？ FN_CM_LUNAR_TO_SOLAR？？ ？？？？？？ ？？？？ ？？？？？？？？ ？？？？？？ ？？？ ？？ ？？？？？!!!
-------------------------------------------------------------------------------------------------
--    V_FROM_LUNAR_DT := P_FROM_DATE-100;
--    MERGE INTO TB_CM_CALENDAR_TMP A
--    USING   (
--                SELECT DAT_ID, TO_CHAR(MAX(LUNAR_CAL_DAT_ID),'YYYYMMDD') AS LUNAR_CAL_DAT_ID
--                  FROM (
--                        select FN_CM_LUNAR_TO_SOLAR(TO_CHAR(V_FROM_LUNAR_DT + ROWNUM-1,'YYYYMMDD'))    AS DAT_ID
--                             , V_FROM_LUNAR_DT + ROWNUM-1                                           AS LUNAR_CAL_DAT_ID
--                         FROM DUAL  
--                   CONNECT BY level <= ROUND( V_TO_LUNAR_DT - (V_FROM_LUNAR_DT) )
--                      ) A
--             GROUP BY A.DAT_ID        
--            ) B ON (A.DAT_ID = B.DAT_ID)
--    WHEN MATCHED THEN
--        UPDATE SET A.LUNAR_CAL_DAT_ID = B.LUNAR_CAL_DAT_ID
--      ;
-------------------------------------------------------------------------------------------------
--     -- ？？？¿？ ？？？？ ？？？？ ？？？？？
-------------------------------------------------------------------------------------------------
--    MERGE INTO TB_CM_CALENDAR_TMP A
--    USING ( SELECT  'Y' AS HOLID_YN
--                   ,'？？？？' AS HOLID_NM
--                   ,'？？？？' AS HOLID_DESCRIP
--                   ,'0101' AS MMDD            
--            FROM DUAL
--            UNION
--            SELECT  'Y' AS HOILD_YN
--                   ,'？？？' AS HOLID_NM
--                   ,'？？？' AS HOLID_DESCRIP
--                   ,'0815' AS MMDD            
--            FROM DUAL        
--           ) B ON (SUBSTR(A.LUNAR_CAL_DAT_ID,5,4) = B.MMDD)
--    WHEN MATCHED THEN
--        UPDATE SET
--             A.HOLID_YN = B.HOLID_YN
--            ,A.HOLID_NM = B.HOLID_NM
--            ,A.HOLID_DESCRIP = B.HOLID_DESCRIP
--    ;
END
;

/

