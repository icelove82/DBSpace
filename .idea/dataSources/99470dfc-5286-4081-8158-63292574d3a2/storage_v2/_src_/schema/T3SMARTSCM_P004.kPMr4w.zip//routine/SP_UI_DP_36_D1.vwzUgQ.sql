create PROCEDURE "SP_UI_DP_36_D1" (
					P_ID	            IN CHAR := ''
				   ,P_USER_ID	        IN NVARCHAR2 := ''
				   ,P_RT_ROLLBACK_FLAG  OUT NVARCHAR2   
				   ,P_RT_MSG            OUT NVARCHAR2 		
)
AS
        P_ERR_STATUS INT := 0;
        P_ERR_MSG VARCHAR2(4000):='';
BEGIN 
/*
		PLAN POLICY ??？ ？?ν？?
*/
	DELETE FROM TB_DP_PLAN_POLICY
	WHERE ID = P_ID;

	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0002';  --?？ ?？????？？

       /* ???？o?? ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN  -- ?？? ???？？? ?？? ???？?？ : e_products_invalid       
          P_ERR_MSG := SQLERRM; -- SYS.DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;   

END ;


/

