create PROCEDURE "SP_UI_DP_23_S1" 
(
        p_VER_ID  VARCHAR2  := ''
) 
/************************************************
 ???？ ?？?° Tab?？Close ??？?？save operation
*************************************************/
IS

 v_DP_CONTROL_BOARD_VER_DTL_ID VARCHAR2(32);

BEGIN 

        -- TB_DP_CONTROL_BOARD_VER_DTL ID ？？
          SELECT CB.ID INTO v_DP_CONTROL_BOARD_VER_DTL_ID
            FROM TB_DP_CONTROL_BOARD_VER_DTL CB  
      INNER JOIN TB_DP_CONTROL_BOARD_VER_MST CM   
              ON CB.CONBD_VER_MST_ID = CM.ID 
      inner join TB_CM_COMM_CONFIG C3 
              on C3.CONF_CD = 'CL' AND CONF_GRP_CD = 'DP_WK_TP' AND  CB.WORK_TP_ID = C3.ID
            WHERE  CM.VER_ID = p_VER_ID ; 

        -- CLOSE ?？?????？? 
        UPDATE TB_DP_CONTROL_BOARD_VER_DTL 
        SET    CL_STATUS_ID = (SELECT ID 
                               FROM   TB_CM_COMM_CONFIG 
                               WHERE  CONF_GRP_CD = 'DP_CL_STATUS' 
                                      AND CONF_CD = 'CLOSE') 
        WHERE  ID = v_DP_CONTROL_BOARD_VER_DTL_ID;

END;

/

