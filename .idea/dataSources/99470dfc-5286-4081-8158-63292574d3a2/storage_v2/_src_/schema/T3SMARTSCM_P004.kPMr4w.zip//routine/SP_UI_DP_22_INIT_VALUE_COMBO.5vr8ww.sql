create PROCEDURE "SP_UI_DP_22_INIT_VALUE_COMBO" 
(
       p_INIT_VAL_TP_ID IN varchar2 := ''
     , pRESULT       OUT SYS_REFCURSOR
)
IS 
 
BEGIN
    OPEN pRESULT 
    FOR 
    SELECT CM.ID										AS INIT_VAL_TP_ID
         , CM.CONF_GRP_CD								AS TP
         , CM.CONF_CD									AS TP_CD
         , 'CF_' || CM.CONF_GRP_CD || '_' || CM.CONF_CD	AS TP_NM
         ------------------------------------------------------------
         , INIT_VAL_ID
         , VAL_CD VAL_CD
         , COALESCE(VAL_NM,'') AS VAL_NM
         , VAL_SEQ    
	  FROM TB_CM_CONFIGURATION CF
		   INNER JOIN
		   TB_CM_COMM_CONFIG CM
		ON CF.ID = CM.CONF_ID
	   AND CM.CONF_GRP_CD = 'DP_INIT_VAL_TP'
	   AND CM.ACTV_YN = 'Y'
	       LEFT JOIN
		   (
			SELECT CL.ID            AS INIT_VAL_ID
                 , CL.LV_CD         AS VAL_CD
                 , CL.LV_NM         AS VAL_NM
                 , CL.SEQ           AS VAL_SEQ
                 , 'PR'             AS CONF_CD
              FROM TB_CM_LEVEL_MGMT CL
             WHERE CL.SALES_LV_YN = 'Y'
               AND COALESCE(CL.DEL_YN,'N') != 'Y'
               AND CL.ACTV_YN ='Y'
            UNION
            SELECT MS.ID            AS INIT_VAL_ID
                 , COALESCE(MS.MEASURE_CD,'')    AS VAL_CD
                 , MS.MEASURE_CD    AS VAL_NM
                 , 0                AS VAL_SEQ
                 , 'MS'             AS CONF_CD
              FROM TB_DP_MEASURE_MST MS
             WHERE MS.DP_YN ='Y'
               AND COALESCE(MS.DEL_YN,'N')   = 'N'
			   AND SYSTEM_YN = 'Y'
			   AND MS.MEASURE_CD NOT LIKE '%_AMT'
           ) VL 
		   ON VL.CONF_CD = CM.CONF_CD
     WHERE CM.ID = p_INIT_VAL_TP_ID 
        OR p_INIT_VAL_TP_ID IS NULL	  
	ORDER BY VAL_NM
       ;
END
;

/

