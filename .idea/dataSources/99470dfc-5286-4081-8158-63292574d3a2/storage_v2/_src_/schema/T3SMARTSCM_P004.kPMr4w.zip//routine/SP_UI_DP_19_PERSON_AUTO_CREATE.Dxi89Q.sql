create PROCEDURE "SP_UI_DP_19_PERSON_AUTO_CREATE" 
(
    P_GRP_ID       IN  VARCHAR2 :=''
  , P_UI_ID            IN  VARCHAR2 :=''
  , P_GRID_ID          IN  VARCHAR2 :=''
  , P_USER_ID          IN  VARCHAR2 :=''
  , P_RT_ROLLBACK_FLAG OUT VARCHAR2      
  , P_RT_MSG           OUT VARCHAR2  
)IS
    /*****************************************************************************************************************
        DP Measure ？？？？ ？？？？？ ？？？？ ？？？ ？？？？
        ？？？？？ : 2018.06.07
        ？？？？？ : ？？？？？？
    *****************************************************************************************************************/
    v_PERSON_CNT INT;
    P_ERR_STATUS INT := 0;
    P_ERR_MSG VARCHAR2(4000):='';
    V_USER_PREF_MST_ID CHAR(32);

BEGIN

    SELECT ID INTO V_USER_PREF_MST_ID
      FROM TB_AD_USER_PREF_MST
     WHERE VIEW_CD = P_UI_ID
       AND GRID_CD = P_GRID_ID;

    DELETE FROM TB_AD_USER_PREF_DTL
     WHERE 1=1
       AND GRP_ID = P_GRP_ID
       AND USER_PREF_MST_ID = V_USER_PREF_MST_ID
       AND DIM_MEASURE_TP = 'MEASURE'
       ;

    INSERT INTO TB_AD_USER_PREF_DTL (
        ID
      , USER_PREF_MST_ID
      , GRP_ID
      , FLD_CD
      , FLD_APPLY_CD
      , FLD_WIDTH
      , FLD_SEQ
      , FLD_ACTIVE_YN
      , APPLY_YN
      , REFER_VALUE
      , CROSSTAB_ITEM_CD
      , CATEGORY_GROUP
      , DIM_MEASURE_TP
      , EDIT_MEASURE_YN
      , EDIT_TARGET_YN
      , DATA_KEY_YN
      , CROSSTAB_YN
      , CREATE_BY
      , CREATE_DTTM
    )
    SELECT RAWTOHEX(SYS_GUID()) 
         , V_USER_PREF_MST_ID
         , P_GRP_ID
         , 'MEASURE_' || LPAD(TO_CHAR(ROW_NUMBER() OVER (ORDER BY SEQ)), 2, '0') AS FIELD_ID
         , A.DISP_NM                AS FIELD_NM
         , '100'                    AS FIELD_WDTH
         , A.SEQ                    AS SEQ
         , A.ACTV_YN                AS ACTV_YN
         , 'Y'                      AS PNSZ_APPY_YN
         , A.ID                     AS FIELD_VAL
         , 'GROUP-VERTICAL-VALUES'  AS PIVOT_ITEM_CD
         , NULL                     AS CATEGORY_GROUP
         , 'MEASURE'                AS DIM_MEASURE_TP
         , A.INPUT_YN               AS EDIT_MEASURE
         , 'N'                      AS EDIT_TARGET
         , 'N'                      AS DATA_KEY_YN
         , A.ACTV_YN                AS PIVOT_APPY_YN
         , P_USER_ID                AS CREATE_BY
         , SYSDATE                  AS CREATE_DTTM
      FROM TB_DP_MEASURE_SETTING A
     INNER JOIN TB_CM_COMM_CONFIG B
        ON A.MEASURE_CONF_TP_ID = B.ID
     WHERE 1=1
       AND RTRIM(GRP_ID) = RTRIM(P_GRP_ID)
       AND UI_ID = P_UI_ID
       AND GRID_ID = P_GRID_ID
    ;

    DELETE FROM TB_AD_USER_PREF
     WHERE 1=1
       AND GRP_ID = P_GRP_ID
       AND USER_PREF_MST_ID = V_USER_PREF_MST_ID;

        /*****************************************************************************************************/


    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001'; 

EXCEPTION WHEN OTHERS THEN  -- ？？？ ？？？？？？？ ？？？？ ？？？？ ？？？？ : e_products_invalid    
    IF(SQLCODE = -20001)
    THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
    --SP_COMM_RAISE_ERR();              
        RAISE;
    END IF; 

END;

/

