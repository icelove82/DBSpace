create PROCEDURE SP_UI_IM_01_POP_05_S2 (
	 P_ID					IN VARCHAR2 := ''
	,P_LOCAT_ID				IN VARCHAR2 := ''
	,P_SABC_CAL_BASE_ID		IN VARCHAR2 := ''
	,P_ACTV_YN				IN VARCHAR2 := ''
	,P_USER_ID				IN VARCHAR2 := ''
	,P_WRK_TYPE				IN VARCHAR2 := ''
	,P_RT_ROLLBACK_FLAG	    OUT VARCHAR2
	,P_RT_MSG				OUT VARCHAR2
)
/*****************************************************************************
 * System Name : T3Enterprise IM
 * Business Name : Inventory Grade Management Base (3th tab)
 * Program Name(ID) :SP_UI_IM_01_POP_05_S2
 * Program Description : Config Key 305, IM mgmt. base saving operation
 *
 * Create Date : 2017.11.15
 * Author : Jo Aram
 *
 * Modifier    Modified Date    Revision History
 * --------    -------------    ----------------------------------------------
 * RSK         2019/03/13       Comments & Formatting
 *
 *****************************************************************************/
IS
    P_ERR_STATUS    NUMBER := 0;
    P_ERR_MSG       VARCHAR2(4000) := '';    
BEGIN
	IF P_WRK_TYPE = 'SAVE' THEN	
		MERGE INTO TB_IM_SABC_CAL_BASE B 
            USING (SELECT P_LOCAT_ID AS LOCAT_ID FROM DUAL) A
                ON (B.LOCAT_ID = A.LOCAT_ID)
		WHEN MATCHED THEN
			UPDATE 
			   SET ACTV_YN			= P_ACTV_YN
				 , SABC_CAL_BASE_ID	= P_SABC_CAL_BASE_ID
				 , MODIFY_BY		= P_USER_ID
				 , MODIFY_DTTM		= SYSDATE
		WHEN NOT MATCHED THEN
			INSERT (
				ID, LOCAT_ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
				,SABC_CAL_BASE_ID
				,ACTV_YN
				)
			VALUES
				(
				TO_SINGLE_BYTE(SYS_GUID()),P_LOCAT_ID,P_USER_ID, SYSDATE, P_USER_ID, SYSDATE
				,P_SABC_CAL_BASE_ID
				,P_ACTV_YN
				);

		  P_RT_ROLLBACK_FLAG := 'true';
	      P_RT_MSG := 'MSG_0001';  -- Saved successfully.
	
	ELSIF P_WRK_TYPE = 'DELETE' THEN	
        DELETE FROM TB_IM_SABC_CAL_BASE 
		WHERE ID = P_ID;

		P_RT_ROLLBACK_FLAG := 'true';
		P_RT_MSG := 'MSG_0002';		
	END IF;

	EXCEPTION
        WHEN OTHERS THEN
            IF(SQLCODE = -20012) THEN
                P_RT_ROLLBACK_FLAG := 'false';
                P_RT_MSG := P_ERR_MSG;   
            ELSE
                RAISE;
            END IF;              
END;

/

