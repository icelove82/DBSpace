create FUNCTION "FN_DP_TEMP_USER_ITEM_ACCOUNT" 
(
    P_EMP_ID      CHAR    := NULL
   ,P_AUTH_TP_ID  CHAR    := NULL
)
RETURN DP_TEMP_USER_ITEM_ACCOUNT IS
C_DP_TEMP_USER_ITEM_ACCOUNT DP_TEMP_USER_ITEM_ACCOUNT := DP_TEMP_USER_ITEM_ACCOUNT();
CURSOR C_DATA_IMPORT IS     
		SELECT TP_DP_TEMP_USER_ITEM_ACCOUNT
                (
                ITEM_ID    =>ITEM_ID
              , ACCOUNT_ID => ACCOUNT_ID
                )
          FROM (
                SELECT ITEM_ID 
                     , ACCOUNT_ID
                  FROM TABLE(FN_DP_TEMP_FIND_ACCOUNT( P_EMP_ID, P_AUTH_TP_ID, NULL))
                       CROSS JOIN
                       TABLE(FN_DP_TEMP_FIND_ITEM( P_EMP_ID, P_AUTH_TP_ID, NULL))
                 WHERE ITEM_ID||'/'||ACCOUNT_ID NOT IN (
                                                        SELECT ITEM_MST_ID||'/'||ACCOUNT_ID
                                                          FROM TB_DP_USER_ITEM_ACCOUNT_EXCLUD
                                                         WHERE EMP_ID =  P_EMP_ID
                                                           AND AUTH_tP_ID =  P_AUTH_TP_ID
                                                     )
                UNION
                SELECT ITEM_MST_ID
                      , ACCOUNT_ID
                  FROM TB_DP_USER_ITEM_ACCOUNT_MAP
                 WHERE EMP_ID =  P_EMP_ID
                   AND AUTH_tP_ID =  P_AUTH_TP_ID
                ) A
            ;

BEGIN
        OPEN C_DATA_IMPORT;
        FETCH C_DATA_IMPORT BULK COLLECT INTO C_DP_TEMP_USER_ITEM_ACCOUNT;
        CLOSE C_DATA_IMPORT;    
    RETURN C_DP_TEMP_USER_ITEM_ACCOUNT;
END;


/

