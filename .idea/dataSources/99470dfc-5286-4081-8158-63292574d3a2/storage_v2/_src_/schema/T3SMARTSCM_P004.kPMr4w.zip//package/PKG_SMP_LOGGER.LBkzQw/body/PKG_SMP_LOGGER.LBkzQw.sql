create PACKAGE BODY                 PKG_SMP_LOGGER IS

  /**************************************************************************
   * Copyrightⓒ2020 ZIONEX, All rights reserved.
   **************************************************************************
   * Name : PKG_SMP_LOGGER
   * Purpose : 시스템 내부에서 발생하는 로그 정보를 기록하기 위함이다.
   * Notes :
   **************************************************************************
   * History :
   * 2020-02-27 JMS created
   **************************************************************************/  
  ------------------------------- 
  -- Public Type declarations --
  -------------------------------

  -----------------------------------
  -- Public constant declarations --
  -----------------------------------

  -----------------------------------
  -- Public variable declarations --
  -----------------------------------
  
  -----------------------------------
  -- Private function declarations --
  -----------------------------------


  PROCEDURE stepSTART (
    P_nLOG_SEQ          IN OUT NUMBER
  , P_sPROGRAM_ID       IN NVARCHAR2
  , P_sSTEP_SEQ         IN NVARCHAR2
  , P_sSTEP_DESC        IN NVARCHAR2
  , P_sVERSION_ID       IN NVARCHAR2
  , P_sUSER_ID          IN NVARCHAR2
  )
  
  IS
  /**************************************************************************
  * Name    : stepSTART
  * Purpose : Log Start
  * Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
  *           [Special Logic]
  *           [Parameters]
  **************************************************************************
  * History :
  * 2020-02-27 JMS Created
  **************************************************************************/
    ---------------------------------
    -- Local variable declarations --
    ---------------------------------
  PRAGMA AUTONOMOUS_TRANSACTION;
   
  BEGIN
    
    P_nLOG_SEQ := SEQ_SMP_LOG_KEY.NEXTVAL; 

    INSERT INTO TB_SMP_LOG_INFO
    ( LOG_SEQ, LOG_DATE, PROGRAM_ID, STEP_SEQ, STEP_DESC, LOG_MSG
    , VERSION_ID
    , STATUS_CD, SQL_CNT
    , START_DTTM, FINISH_DTTM, EXEC_TIME
    , EXEC_USER_ID
    , ATTR_01, ATTR_02, ATTR_03, ATTR_04, ATTR_05, ATTR_06, ATTR_07, ATTR_08, ATTR_09, ATTR_10
    )
    VALUES
    ( 
      P_nLOG_SEQ, SYSTIMESTAMP, P_sPROGRAM_ID, P_sSTEP_SEQ, P_sSTEP_DESC, NULL
    , P_sVERSION_ID
    , 'P', NULL            -- STATUS 'P' = 진행중, 'C' = 정상완료, 'E' = Error
    , SYSDATE, NULL, NULL
    , P_sUSER_ID
    , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
    );
   
   COMMIT;

  END
  ;
  
  PROCEDURE stepFINISH (
    P_nLOG_SEQ          IN OUT NUMBER
  , P_nSQL_CNT          IN NUMBER
  )
  
  IS
  /**************************************************************************
  * Name    : stepFinish
  * Purpose : Log Finish
  * Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
  *           [Special Logic]
  *           [Parameters]
  **************************************************************************
  * History :
  * 2020-02-27 JMS Created
  **************************************************************************/
    ---------------------------------
    -- Local variable declarations --
    ---------------------------------
  PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
    
    UPDATE TB_SMP_LOG_INFO
       SET STATUS_CD   = 'C' -- STATUS 'P' = 진행중, 'C' = 정상완료, 'E' = Error
         , SQL_CNT     = P_nSQL_CNT
         , FINISH_DTTM = SYSDATE
         , EXEC_TIME   = (SYSDATE - START_DTTM)*(24*60*60) --Second 변환         
     WHERE LOG_SEQ = P_nLOG_SEQ
    ;
   
    COMMIT;
    
  END
  ;

 
  PROCEDURE stepERROR (
    P_nLOG_SEQ          IN OUT NUMBER
  , P_sLOG_MSG          IN VARCHAR2 DEFAULT NULL
  , P_sVERSION_ID       IN VARCHAR2 DEFAULT NULL
  )
  
  IS
  /**************************************************************************
  * Name    : ERROR
  * Purpose : Error Log 용 Procedure
  * Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
  *           [Special Logic]
  *           [Parameters]
  **************************************************************************
  * History :
  * 2020-02-27 JMS Created
  **************************************************************************/
    ---------------------------------
    -- Local variable declarations --
    ---------------------------------
  PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
    
    UPDATE TB_SMP_LOG_INFO
       SET STATUS_CD   = 'E' -- STATUS 'P' = 진행중, 'C' = 정상완료, 'E' = Error
         --, SQL_CNT     = P_nSQL_CNT
         , FINISH_DTTM = SYSDATE
         , EXEC_TIME   = (SYSDATE - START_DTTM)*(24*60*60) --Second 변환
         , LOG_MSG     = P_sLOG_MSG
     WHERE LOG_SEQ = P_nLOG_SEQ
    ;
  
    IF P_sVERSION_ID IS NOT NULL THEN
    
        UPDATE TB_SMP_VER_MST
           SET STATUS_CD = 'E'
             , UPDATE_DTTM = SYSDATE
         WHERE VERSION_ID = P_sVERSION_ID
        ;
      
    END IF;
    
    
    COMMIT;
    
  END
  ;
  
  PROCEDURE stepDEBUG (
    P_nLOG_SEQ          IN OUT NUMBER
  , P_sATTR_01          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_02          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_03          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_04          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_05          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_06          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_07          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_08          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_09          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_10          IN NVARCHAR2 DEFAULT NULL
  )
  
  IS
  /**************************************************************************
  * Name    : DEBUG
  * Purpose : Log Debug 용 프로시져 
  * Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
  *           [Special Logic]
  *           [Parameters]
  **************************************************************************
  * History :
  * 2020-02-27 JMS Created
  **************************************************************************/
    ---------------------------------
    -- Local variable declarations --
    ---------------------------------    
  PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
    
    UPDATE TB_SMP_LOG_INFO
       SET ATTR_01 = P_sATTR_01
         , ATTR_02 = P_sATTR_02
         , ATTR_03 = P_sATTR_03
         , ATTR_04 = P_sATTR_04
         , ATTR_05 = P_sATTR_05
         , ATTR_06 = P_sATTR_06
         , ATTR_07 = P_sATTR_07
         , ATTR_08 = P_sATTR_08
         , ATTR_09 = P_sATTR_09
         , ATTR_10 = P_sATTR_10
     WHERE LOG_SEQ = P_nLOG_SEQ
    ;
   
    COMMIT;
    
  END
  ;
  
  
END PKG_SMP_LOGGER;
/

