create PROCEDURE SP_UI_CM_12_POP_S3 (
	 P_DMND_SHPP_MGMT_MST_ID    IN CHAR := '',
     P_DMND_SHPP_MGMT_DTL_ID    IN CHAR := '',
     P_DMND_SHPP_MGMT_LT_ID     IN CHAR := '',
	 P_VEHICL_TP_ID		        IN CHAR := '',
	 P_BOD_LEADTIME_ID		    IN CHAR := '',
	 P_LEADTIME				    IN NUMBER := '',
	 P_UOM_ID				    IN CHAR := '',
	 P_USER_ID				    IN VARCHAR2 := '',
     P_RT_ROLLBACK_FLAG         OUT VARCHAR2,
     P_RT_MSG                   OUT VARCHAR2
)
IS
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG  VARCHAR2(4000) :='';
    V_DMND_SHPP_MGMT_DTL_ID CHAR(32);

BEGIN
    IF P_VEHICL_TP_ID IS NOT NULL THEN
        IF NVL(P_DMND_SHPP_MGMT_DTL_ID, '') = '' THEN
            SELECT	B.ID INTO V_DMND_SHPP_MGMT_DTL_ID
            FROM	TB_CM_DMND_SHPP_MAP_MST A,
                    TB_CM_DMND_SHPP_MAP_DTL B
            WHERE	A.ID = B.DMND_SHPP_MGMT_MST_ID
            AND		A.ID = P_DMND_SHPP_MGMT_MST_ID
            AND		B.VEHICL_TP_ID = P_VEHICL_TP_ID;
        ELSE
            V_DMND_SHPP_MGMT_DTL_ID := P_DMND_SHPP_MGMT_DTL_ID;
        END IF;
    
        MERGE INTO TB_CM_DMND_SHPP_MAP_LT TARGET
        USING
        (
            SELECT	P_DMND_SHPP_MGMT_LT_ID		AS ID,
                    V_DMND_SHPP_MGMT_DTL_ID	    AS DMND_SHPP_MAP_DTL_ID,
                    P_BOD_LEADTIME_ID			AS BOD_LEADTIME_ID,
                    P_LEADTIME					AS LEADTIME,
                    P_UOM_ID					AS UOM_ID,
                    P_USER_ID					AS USER_ID
            FROM    DUAL
        ) SOURCE
        ON (TARGET.ID = SOURCE.ID)
        WHEN MATCHED THEN
            UPDATE
            SET		LEADTIME	= SOURCE.LEADTIME,
                    UOM_ID		= SOURCE.UOM_ID,
                    MODIFY_BY	= SOURCE.USER_ID,
                    MODIFY_DTTM	= SYSDATE
    
        WHEN NOT MATCHED THEN
            INSERT	(
                    ID,
                    DMND_SHPP_MGMT_DTL_ID,
                    BOD_LEADTIME_ID,
                    LEADTIME,
                    UOM_ID,
                    CREATE_BY,
                    CREATE_DTTM
                    )
            VALUES	(
                    TO_SINGLE_BYTE(SYS_GUID()),
                    SOURCE.DMND_SHPP_MAP_DTL_ID,
                    SOURCE.BOD_LEADTIME_ID,
                    SOURCE.LEADTIME,
                    SOURCE.UOM_ID,
                    SOURCE.USER_ID,
                    SYSDATE
                    );    
    END IF;

	P_RT_ROLLBACK_FLAG := 'true';
	P_RT_MSG := 'MSG_0001';
                    
EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;   
      ELSE
          RAISE;
      END IF; 
END;

/

