create PROCEDURE "SP_UI_CM_15_S2" (
     P_PP_ID            IN CHAR := ''
    ,P_CON_ID		    IN VARCHAR2 := NULL
    ,P_VAL_01		    IN VARCHAR2 := NULL
    ,P_VAL_02		    IN VARCHAR2 := NULL
    ,P_VAL_03		    IN VARCHAR2 := NULL
    ,P_VAL_04		    IN VARCHAR2 := NULL
    ,P_VAL_05		    IN VARCHAR2 := NULL
    ,P_VAL_06		    IN VARCHAR2 := NULL
    ,P_VAL_07		    IN VARCHAR2 := NULL
    ,P_VAL_08		    IN VARCHAR2 := NULL
    ,P_VAL_09		    IN VARCHAR2 := NULL
    ,P_VAL_10		    IN VARCHAR2 := NULL
    ,P_VAL_11		    IN VARCHAR2 := NULL
    ,P_VAL_12		    IN VARCHAR2 := NULL
    ,P_VAL_13		    IN VARCHAR2 := NULL
    ,P_VAL_14		    IN VARCHAR2 := NULL
    ,P_VAL_15	        IN VARCHAR2 := NULL
    ,P_VAL_16	        IN VARCHAR2 := NULL
    ,P_USER_ID          IN VARCHAR2 := NULL
    ,P_RT_ROLLBACK_FLAG OUT VARCHAR2
    ,P_RT_MSG           OUT VARCHAR2
)
IS
    P_SET_ID CHAR(32) :='';
    P_PP_NAME VARCHAR2(30) :='';
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG  VARCHAR2(4000) :='';

BEGIN

/* PP_CON_01	General                           */
/* PP_CON_02	Demand Facing Level				  */
/* PP_CON_03	Confirmed Planning Level		  */
/* PP_CON_04	Infinite Planning Level			  */
/* PP_CON_05	Plan Policy	Coverage			  */
/* PP_CON_06	Plan Priority					  */
/* PP_CON_07	Sub Plan Priority				  */
/* PP_CON_10	Planning Method					  */
/* PP_CON_11	Allocation Rule (Site)			  */
/* PP_CON_12	Allocation Rule (Resource)		  */
/* PP_CON_13	Allocation Rule (Partial Plan)	  */
/* PP_CON_14	Product Mix						  */
/* PP_CON_15	Product Option					  */

/*
M00010000	Module
M00020000	Description
M00030000	Planning Type
M00040000	Demand Facing Level Demand Type - DP Forecast
M00050000	Demand Facing Level Demand Type - SRP P/O
M00060000	Demand Facing Level Demand Type - 앞 거점유형 / 거점 Level 계획
M00070000	Demand Facing Level Demand Type - 앞 거점유형 / 거점 Level 계획 Radio
M00080000	Demand Facing Level Demand Type - 해당 보정 계획
M00090000	Finite Capacity Planning Level Demand Type -DP Forecast
M00100000	Finite Capacity Planning Level Demand Type -SRP P/O
M00110000	거점 유형
M00120000	Fixed Production Plan
M00130000	Fixed Production Plan Horizon
M00140000	Fixed Rolling Plan
M00150000	Fixed Rolling Production Plan Horizon
M00160000	Fixed Adjust Plan
M00170000	Fixed Adjust Production Plan Horizon
M00180000	Fixed Adjust Shipment Plan Horizon
M00190000	반제품 통합 공급계획 수립
M00200000	Confirmed Planning Level
M00210000	Confirmed Planning Level Grid
M00220000	Infinite Planning Level
M00230000	Infinite Planning Level Grid
M00240000	Plan Policy 적용구간
M00250000	선행 생산 제약
M00260000	납기 지연 허용 구간
M00270000	납기 지연 허용 구간값
M00280000	Supply Type Priority - 자가공급
M00290000	Supply Type Priority - SRP 자가공급
M00300000	Supply Type Priority - 판매 공급
M00310000	Delivery Plan Policy
M00320000	Plan Priority
M00330000	반제품 통합 Plan Priority
M00340000	Plan Script
M00350000	EST Site Level
M00360000	재고 배치 전략
M00370000	Allocation Rule Site
M00380000	Cost Optimization Mode
M00390000	1 순위 Vehicle 강제 할당
M00400000	Pre-Assigned Site
M00420000	Allocation Rule Resource
M00430000	Multi-Level Allocation Rule
M00440000	Pre-Assigned Resource
M00450000	주문 분할 모드 - 체크박스
M00460000	주문 분할 모드 - 라디오
M00470000	Min Allocation 제약 적용 여부
M00480000	Min Allocation 제약 적용
M00490000	Max Allocation 제약 적용 여부
M00500000	Max Allocation 제약 적용
M00510000	Material Constraints Type
M00511000	Material Constraints 
M00520000	Constraints Type Change Period
M00530000	완제품/반제품 재고를 할당한다 여부
M00540000	Stock Pre-Consume 여부
M00550000	납기일보다 이후에 입고되는 재고도 할당된다. 여부
M00560000	납기일보다 이후에 입고되는 재고도 할당된다. 라디오
M00570000	휴무일 전후 계획 분할
M00580000	계획 수량 단위
M00151000	Fixed Rolling Shipment Plan Horizon
M00660000	계획 지연 주기
M00670000	계획 지연 주기값
*/

    IF( P_CON_ID ='PP_CON_01')
    /*
    PP_CON_01	General

    P_VAL_01 = M00020000	Description
    P_VAL_02 = ACTIVE YN
    P_VAL_03 = M00030000	Planning Type
    */
    THEN
        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
            USING(
                        SELECT X.ID AS P_P_MGMT_ID,
                                       Z.ID AS P_P_MST_ID
                        FROM TB_CM_PLAN_POLICY_MGMT X,
                             TB_CM_PLAN_POLICY_MST Z
                        WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID = 'M00020000'
                    )A
                    ON
                    (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID
                    AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
                    WHEN MATCHED THEN
                    UPDATE
                    SET  Y.PLAN_POLICY_VAL_01 = P_VAL_01
                        ,Y.MODIFY_BY = P_USER_ID
                        ,Y.MODIFY_DTTM = SYSDATE;

        UPDATE TB_CM_PLAN_POLICY_MGMT X
        SET X.ACTV_YN =P_VAL_02
            ,X.MODIFY_BY = P_USER_ID
            ,X.MODIFY_DTTM = SYSDATE 
        WHERE 1=1
        AND X.ID = P_PP_ID;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING (
            SELECT X.ID AS P_P_MGMT_ID,	Z.ID AS P_P_MST_ID
            FROM TB_CM_PLAN_POLICY_MGMT X,
                 TB_CM_PLAN_POLICY_MST Z
            WHERE 1=1
            AND X.ID = P_PP_ID
            AND Z.PLAN_POLICY_ITEM_ID ='M00030000'
        )A ON
        (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
        WHEN MATCHED THEN
        UPDATE
        SET Y.PLAN_POLICY_DTL_ID = TO_CHAR(P_VAL_03)
                ,Y.MODIFY_BY = P_USER_ID
                ,Y.MODIFY_DTTM = SYSDATE;

    -- PP_CON_02: Demand Facing Level ------------------------------------------------------------------------------------------
    ELSIF P_CON_ID ='PP_CON_02'
    /*
    P_VAL_01 = M00110000	거점 유형 명
    P_VAL_02 = M00110000	거점 레벨
    P_VAL_03 = M00120000	Fixed Production Plan
    P_VAL_04 = M00130000	Fixed Production Plan Horizon
    P_VAL_05 = M00140000	Fixed Rolling Plan
    P_VAL_06 = M00150000	Fixed Rolling Production Plan Horizon
    P_VAL_07 = M00151000	Fixed Rolling Shipment Plan Horizon
    P_VAL_08 = M00160000	Fixed Adjust Plan
    P_VAL_09 = M00170000	Fixed Adjust Production Plan Horizon
    P_VAL_10 = M00180000	Fixed Adjust Shipment Plan Horizon
    P_VAL_11 = M00190000	반제품 통합 공급계획 수립
    P_VAL_12 = M00110000	거점유형 ID
    */
    THEN
	    -- P_VAL_01 = M00110000	거점 유형 명
	    -- P_VAL_02 = M00110000	거점 레벨
	    -- P_VAL_12 = M00110000	거점유형 ID
	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y 
	    USING (
	        SELECT
	            X.ID AS P_P_MGMT_ID,
	            Z.ID AS P_P_MST_ID
	        FROM
	            TB_CM_PLAN_POLICY_MGMT X,
	            TB_CM_PLAN_POLICY_MST Z
	        WHERE
	            1 = 1
	            AND X.ID = P_PP_ID
	            AND Z.PLAN_POLICY_ITEM_ID = 'M00110000'
	    )
	    A ON (
	        A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID
	        AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID
	    )
	    WHEN MATCHED THEN UPDATE SET Y.PLAN_POLICY_VAL_01 = P_VAL_01,
	                                 Y.PLAN_POLICY_VAL_02 = P_VAL_12,
	                                 Y.PLAN_POLICY_VAL_06 = TO_NUMBER(P_VAL_02),
	                                 Y.MODIFY_BY = P_USER_ID,
	                                 Y.MODIFY_DTTM = SYSDATE;

	    -- P_VAL_03 = M00120000	Fixed Production Plan
	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y 
	    USING (
	        SELECT
	            X.ID AS P_P_MGMT_ID,
	            Z.ID AS P_P_MST_ID
	        FROM
	            TB_CM_PLAN_POLICY_MGMT X,
	            TB_CM_PLAN_POLICY_MST Z
	        WHERE
	            1 = 1
	            AND X.ID = P_PP_ID
	            AND Z.PLAN_POLICY_ITEM_ID = 'M00120000'
	    )
	    A ON (
	        A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID
	        AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID
	    )
	    WHEN MATCHED THEN UPDATE SET Y.PLAN_POLICY_DTL_ID = TO_CHAR(P_VAL_03),
	                                 Y.MODIFY_BY = P_USER_ID,
	                                 Y.MODIFY_DTTM = SYSDATE;

	    -- P_VAL_04 = M00130000	Fixed Production Plan Horizon
	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y 
	    USING (
	        SELECT
	            X.ID AS P_P_MGMT_ID,
	            Z.ID AS P_P_MST_ID
	        FROM
	            TB_CM_PLAN_POLICY_MGMT X,
	            TB_CM_PLAN_POLICY_MST Z
	        WHERE
	            1 = 1
	            AND X.ID = P_PP_ID
	            AND Z.PLAN_POLICY_ITEM_ID = 'M00130000'
	    )
	    A ON (
	        A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID
	        AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID
	    )
	    WHEN MATCHED THEN UPDATE SET Y.PLAN_POLICY_VAL_06 = TO_NUMBER(P_VAL_04),
	                                 Y.MODIFY_BY = P_USER_ID,
	                                 Y.MODIFY_DTTM = SYSDATE;

	    -- P_VAL_05 = M00140000	Fixed Rolling Plan
	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y 
	    USING (
	        SELECT
	            X.ID AS P_P_MGMT_ID,
	            Z.ID AS P_P_MST_ID
	        FROM
	            TB_CM_PLAN_POLICY_MGMT X,
	            TB_CM_PLAN_POLICY_MST Z
	        WHERE
	            1 = 1
	            AND X.ID = P_PP_ID
	            AND Z.PLAN_POLICY_ITEM_ID = 'M00140000'
	    )
	    A ON (
	        A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID
	        AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID
	    )
	    WHEN MATCHED THEN UPDATE SET Y.PLAN_POLICY_DTL_ID = TO_CHAR(P_VAL_05),
	                                 Y.MODIFY_BY = P_USER_ID,
	                                 Y.MODIFY_DTTM = SYSDATE;    

	    -- P_VAL_06 = M00150000	Fixed Rolling Production Plan Horizon
	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y 
	    USING (
	        SELECT
	            X.ID AS P_P_MGMT_ID,
	            Z.ID AS P_P_MST_ID
	        FROM
	            TB_CM_PLAN_POLICY_MGMT X,
	            TB_CM_PLAN_POLICY_MST Z
	        WHERE
	            1 = 1
	            AND X.ID = P_PP_ID
	            AND Z.PLAN_POLICY_ITEM_ID = 'M00150000'
	    )
	    A ON (
	        A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID
	        AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID
	    )
	    WHEN MATCHED THEN UPDATE SET Y.PLAN_POLICY_VAL_06 = TO_NUMBER(P_VAL_06),
	                                     Y.MODIFY_BY = P_USER_ID,
	                                 Y.MODIFY_DTTM = SYSDATE;

	    -- P_VAL_07 = M00151000	Fixed Rolling Shipment Plan Horizon
	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y 
	    USING (
	        SELECT
	            X.ID AS P_P_MGMT_ID,
	            Z.ID AS P_P_MST_ID
	        FROM
	            TB_CM_PLAN_POLICY_MGMT X,
	            TB_CM_PLAN_POLICY_MST Z
	        WHERE
	            1 = 1
	            AND X.ID = P_PP_ID
	            AND Z.PLAN_POLICY_ITEM_ID = 'M00151000'
	    )
	    A ON (
	        A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID
	        AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID
	    )
	    WHEN MATCHED THEN UPDATE SET Y.PLAN_POLICY_VAL_06 = TO_NUMBER(P_VAL_07),
	                                     Y.MODIFY_BY = P_USER_ID,
	                                 Y.MODIFY_DTTM = SYSDATE;

	    -- P_VAL_08 = M00160000	Fixed Adjust Plan
	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y 
	    USING (
	        SELECT
	            X.ID AS P_P_MGMT_ID,
	            Z.ID AS P_P_MST_ID
	        FROM
	            TB_CM_PLAN_POLICY_MGMT X,
	            TB_CM_PLAN_POLICY_MST Z
	        WHERE
	            1 = 1
	            AND X.ID = P_PP_ID
	            AND Z.PLAN_POLICY_ITEM_ID = 'M00160000'
	    )
	    A ON (
	        A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID
	        AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID
	    )
	    WHEN MATCHED THEN UPDATE SET Y.PLAN_POLICY_DTL_ID = TO_CHAR(P_VAL_08),
	                                 Y.MODIFY_BY = P_USER_ID,
	                                 Y.MODIFY_DTTM = SYSDATE;

	    -- P_VAL_09 = M00170000	Fixed Adjust Production Plan Horizon
	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y 
	    USING (
	        SELECT
	            X.ID AS P_P_MGMT_ID,
	            Z.ID AS P_P_MST_ID
	        FROM
	            TB_CM_PLAN_POLICY_MGMT X,
	            TB_CM_PLAN_POLICY_MST Z
	        WHERE
	            1 = 1
	            AND X.ID = P_PP_ID
	            AND Z.PLAN_POLICY_ITEM_ID = 'M00170000'
	    )
	    A ON (
	        A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID
	        AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID
	    )
	    WHEN MATCHED THEN UPDATE SET Y.PLAN_POLICY_VAL_06 = TO_NUMBER(P_VAL_09),
	                                     Y.MODIFY_BY = P_USER_ID,
	                                 Y.MODIFY_DTTM = SYSDATE;

	    -- P_VAL_10 = M00180000	Fixed Adjust Shipment Plan Horizon
	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y 
	    USING (
	        SELECT
	            X.ID AS P_P_MGMT_ID,
	            Z.ID AS P_P_MST_ID
	        FROM
	            TB_CM_PLAN_POLICY_MGMT X,
	            TB_CM_PLAN_POLICY_MST Z
	        WHERE
	            1 = 1
	            AND X.ID = P_PP_ID
	            AND Z.PLAN_POLICY_ITEM_ID = 'M00180000'
	    )
	    A ON (
	        A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID
	        AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID
	    )
	    WHEN MATCHED THEN UPDATE SET Y.PLAN_POLICY_VAL_06 = TO_NUMBER(P_VAL_10),
	                                     Y.MODIFY_BY = P_USER_ID,
	                                 Y.MODIFY_DTTM = SYSDATE;

	    -- P_VAL_11 = M00190000	반제품 통합 공급계획 수립
	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y 
	    USING (
	        SELECT
	            X.ID AS P_P_MGMT_ID,
	            Z.ID AS P_P_MST_ID
	        FROM
	            TB_CM_PLAN_POLICY_MGMT X,
	            TB_CM_PLAN_POLICY_MST Z
	        WHERE
	            1 = 1
	            AND X.ID = P_PP_ID
	            AND Z.PLAN_POLICY_ITEM_ID = 'M00190000'
	    )
	    A ON (
	        A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID
	        AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID
	    )
	    WHEN MATCHED THEN UPDATE SET Y.PLAN_POLICY_DTL_ID = TO_CHAR(P_VAL_11),
	                                     Y.MODIFY_BY = P_USER_ID,
	                                 Y.MODIFY_DTTM = SYSDATE;

    ELSIF P_CON_ID IN ('PP_CON_03','PP_CON_04')
   /*
   PP_CON_03	Confirmed Planning Level
   
   @P_VAL_01 = M00200000	거점 유형 명
   @P_VAL_02 = M00200000	거점 유형 ID
   @P_VAL_03 = M00200000	거점 레벨

   PP_CON_04	Infinite Planning Level	
   
   @P_VAL_01 = M00200000	거점 유형 명
   @P_VAL_02 = M00200000	거점 유형 ID
   @P_VAL_03 = M00200000	거점 레벨
   */    
    THEN
	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y 
	    USING (
	        SELECT
	            X.ID AS P_P_MGMT_ID,
	            Z.ID AS P_P_MST_ID
	        FROM
	            TB_CM_PLAN_POLICY_MGMT X,
	            TB_CM_PLAN_POLICY_MST Z
	        WHERE
	            1 = 1
	            AND X.ID = P_PP_ID
	            AND Z.PLAN_POLICY_ITEM_ID =
	                CASE
	                    WHEN P_CON_ID = 'PP_CON_03'  THEN 'M00200000'
	                    WHEN P_CON_ID = 'PP_CON_04'  THEN 'M00220000'
	                    ELSE NULL
	                END
	    )
	    A ON (
	        A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID
	        AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID
	    )
	    WHEN MATCHED THEN UPDATE SET Y.PLAN_POLICY_VAL_01 = P_VAL_01,
	                                 Y.PLAN_POLICY_VAL_02 = TO_CHAR(P_VAL_02),
	                                 Y.PLAN_POLICY_VAL_06 = TO_NUMBER(P_VAL_03),
	                                 Y.MODIFY_BY = P_USER_ID,
	                                 Y.MODIFY_DTTM = SYSDATE;

   ELSIF P_CON_ID = 'PP_CON_05'
   /*
   PP_CON_05	Plan Policy Coverage

   P_VAL_01 = M00240000	Plan Policy 적용구간
   P_VAL_02 = M00250000	선행 생산 제약
   P_VAL_03 = M00260000	납기 지연 허용 구간
   P_VAL_04 = M00270000	납기 지연 허용 구간값
   P_VAL_05 = M00280000	Supply Type Priority - 자가공급
   P_VAL_06 = M00290000	Supply Type Priority - SRP 자가공급
   P_VAL_07 = M00300000	Supply Type Priority - 판매 공급
   P_VAL_08 = M00310000	Delivery Plan Policy
   P_VAL_09 = M00311000	Delivery Plan Policy Radio
   P_VAL_10 = M00660000	계획 지연 주기
   P_VAL_11 = M00670000	계획 지연 주기값
   */
  THEN
	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00240000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_01),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00250000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_02),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00260000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_03),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00270000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_VAL_06 =TO_NUMBER(P_VAL_04),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00280000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_VAL_06 =TO_NUMBER(P_VAL_05),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00290000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_VAL_06 =TO_NUMBER(P_VAL_06),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00300000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_VAL_06 =TO_NUMBER(P_VAL_07),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00310000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_08),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00311000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_09),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00660000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_10),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00670000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_VAL_06 =TO_NUMBER(P_VAL_11),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

   /*
   PP_CON_06	Plan Priority
   PP_CON_07	Sub Plan Priority
   PP_CON_08	반제품 통합 Plan Priority
   PP_CON_09	반제품 통합 Sub Plan Priority
   ==> 그리드 처리
   */
   ELSIF P_CON_ID = 'PP_CON_10'
   /*
   PP_CON_10	Planning Method

   P_VAL_01 = M00340000	Plan Script
   P_VAL_02 = M00350000	EST Site Level 거점 유형 명
   P_VAL_03 = M00350000	EST Site Level 거점 레벨
   P_VAL_04 = M00360000	재고 배치 전략
   P_VAL_05 = M00350000	거점 ID
   */
   THEN
        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00340000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_01),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00350000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_VAL_01 = P_VAL_02,
                            Y.PLAN_POLICY_VAL_02 = P_VAL_05,
                            Y.PLAN_POLICY_VAL_06 = TO_NUMBER(P_VAL_03),
                            Y.MODIFY_BY = P_USER_ID,
                            Y.MODIFY_DTTM = SYSDATE;

	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00360000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_04),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

   ELSIF P_CON_ID = 'PP_CON_11'
   /*
   PP_CON_11	Allocation Rule (Site)

   P_VAL_01 = M00370000	Allocation Rule Site
   P_VAL_02 = M00380000	Cost Optimization Mode
   P_VAL_03 = M00390000	1 순위 Vehicle 강제 할당
   P_VAL_04 = M00400000	Pre-Assigned Site
   P_VAL_05 = M00640000	Heuristics Opt. Mode
   P_VAL_06 = M00650000	Heuristics Max Order Search
   */
    THEN
	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00370000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_01),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00380000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID=TO_CHAR(P_VAL_02),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;


	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00390000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET --Y.PLAN_POLICY_VAL_01 = CASE WHEN P_VAL_03 = 'N' THEN NULL ELSE P_VAL_03 END,
                        Y.PLAN_POLICY_VAL_01 = P_VAL_03,
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;


	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00400000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_04),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00640000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_05),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00650000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_VAL_06 =TO_NUMBER(P_VAL_06),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

    ELSIF P_CON_ID = 'PP_CON_12'
    /*
     PP_CON_12	Allocation Rule (Resource)

     P_VAL_01 = M00420000	Allocation Rule Resource
                M00430000	Multi-Level Allocation Rule ==> 그리드 처리
     P_VAL_02 = M00440000	Pre-Assigned Resource
    */
    THEN
	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y 
	    USING (
	        SELECT
	            X.ID AS P_P_MGMT_ID,
	            Z.ID AS P_P_MST_ID
	        FROM
	            TB_CM_PLAN_POLICY_MGMT X,
	            TB_CM_PLAN_POLICY_MST Z
	        WHERE
	            1 = 1
	            AND X.ID = P_PP_ID
	            AND Z.PLAN_POLICY_ITEM_ID = 'M00420000'
	    )
	    A ON (
	        A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID
	        AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID
	    )
	    WHEN MATCHED THEN UPDATE SET Y.PLAN_POLICY_DTL_ID = TO_CHAR(P_VAL_01),
	                            Y.MODIFY_BY = P_USER_ID,
	                            Y.MODIFY_DTTM = SYSDATE;

	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y 
	    USING (
	        SELECT
	            X.ID AS P_P_MGMT_ID,
	            Z.ID AS P_P_MST_ID
	        FROM
	            TB_CM_PLAN_POLICY_MGMT X,
	            TB_CM_PLAN_POLICY_MST Z
	        WHERE
	            1 = 1
	            AND X.ID = P_PP_ID
	            AND Z.PLAN_POLICY_ITEM_ID = 'M00440000'
	    )
	    A ON (
	        A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID
	        AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID
	    )
	    WHEN MATCHED THEN UPDATE SET Y.PLAN_POLICY_DTL_ID = TO_CHAR(P_VAL_02),
	                            Y.MODIFY_BY = P_USER_ID,
	                            Y.MODIFY_DTTM = SYSDATE;

   ELSIF P_CON_ID = 'PP_CON_13'
   /*
   PP_CON_13	Allocation Rule (Partial Plan)

   P_VAL_01 = M00460000	주문 분할 모드 - 라디오
   P_VAL_02 = M00600000	주문 분할 기준 - Fence Utilization mode
   */
   THEN
        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00460000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_01),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00600000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_02),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

   ELSIF P_CON_ID = 'PP_CON_14'
   /*
   PP_CON_14	Product Mix

   P_VAL_01 = M00470000	Min Allocation 제약 적용 여부
   P_VAL_02 = M00480000	Min Allocation 제약 적용
   P_VAL_03 = M00490000	Max Allocation 제약 적용 여부
   P_VAL_04 = M00500000	Max Allocation 제약 적용
   */
   THEN
        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00470000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_VAL_01 =CASE WHEN P_VAL_01 = 'N' THEN NULL ELSE P_VAL_01 END ,
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;



        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00480000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_02),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;



        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00490000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_VAL_01 =CASE WHEN P_VAL_03 = 'N' THEN NULL ELSE P_VAL_03 END,
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;



  	    MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00500000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_04),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

   ELSIF P_CON_ID = 'PP_CON_15'
   /*
   PP_CON_15	Product Option

   P_VAL_01 = M00510000	Material Constraints Type
   P_VAL_02 = M00511000	Material Constraints
   P_VAL_03 = M00520000	Constraints Type Change Period
   P_VAL_04 = M00530000	완제품/반제품 재고를 할당한다 여부
   P_VAL_05 = M00540000	Stock Pre-Consume 여부
   P_VAL_06 = M00550000	납기일보다 이후에 입고되는 재고도 할당된다. 여부
   P_VAL_07 = M00560000	납기일보다 이후에 입고되는 재고도 할당된다. 라디오
   P_VAL_08 = M00570000	휴무일 전후 계획 분할
   P_VAL_09 = M00580000	계획 수량 단위
   P_VAL_10 = M00590000	Stock Pre-Consume Level (LOCAT_ID)
   P_VAL_11 = M00590000	Stock Pre-Consume Level (LOCAT_TP_NM)
   P_VAL_12 = M00590000	Stock Pre-Consume Leve (LOCAT_LV)
   P_VAL_13 = M00610000	Demand Assign Stock Pegging 정책
   P_VAL_14 = M00620000	Dummy 설비 Capacity 설정
   P_VAL_15 = M00630000	Sales 결과 집계 방식
   P_VAL_16 = M00680000	재고 데이터 사용
   */
   THEN
        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00510000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_01),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00511000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_02),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;                            

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00520000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_VAL_06 =TO_NUMBER(P_VAL_03),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00530000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_VAL_01 =CASE WHEN P_VAL_04 = 'N' THEN NULL ELSE P_VAL_04 END ,
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00540000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_05),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00550000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_VAL_01 =CASE WHEN P_VAL_06 ='N' THEN NULL ELSE P_VAL_06 END,
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00560000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID = TO_CHAR(P_VAL_07);


        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00570000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID = TO_CHAR(P_VAL_08),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00580000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID = TO_CHAR(P_VAL_09),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00590000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_VAL_01 = TO_CHAR(P_VAL_11),
                        Y.PLAN_POLICY_VAL_02 = TO_CHAR(P_VAL_10),
                        Y.PLAN_POLICY_VAL_06 = TO_NUMBER(P_VAL_12),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00610000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_13),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00620000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_14),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00630000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_15),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;

        MERGE INTO TB_CM_PLAN_POLICY_VALUE Y
        USING(
                    SELECT X.ID AS P_P_MGMT_ID, Z.ID AS P_P_MST_ID
                    FROM TB_CM_PLAN_POLICY_MGMT X,
                               TB_CM_PLAN_POLICY_MST Z
                    WHERE 1=1
                        AND X.ID = P_PP_ID
                        AND Z.PLAN_POLICY_ITEM_ID ='M00680000'
                    )A
            ON
                (A.P_P_MGMT_ID = Y.PLAN_POLICY_MGMT_ID AND A.P_P_MST_ID = Y.PLAN_POLICY_MST_ID)
            WHEN MATCHED THEN
                UPDATE
                    SET Y.PLAN_POLICY_DTL_ID =TO_CHAR(P_VAL_16),
                        Y.MODIFY_BY = P_USER_ID,
                        Y.MODIFY_DTTM = SYSDATE;
    END IF;
    
    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';

EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN 
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;
      ELSE
          RAISE;
      END IF;

END;

/

