create PROCEDURE "SP_UI_DP_28_CHART_Q1" (
     p_BUCK			    VARCHAR2
    ,p_STRT_DATE		DATE
    ,p_END_DATE		    DATE
    ,p_USER_ID			VARCHAR2
    ,p_PLAN_TP_ID		VARCHAR2 
    ,p_ITEM_CD			VARCHAR2
    ,p_ACCT_CD			VARCHAR2
    ,p_ITEM_LV_CD		VARCHAR2
    ,p_ACCT_LV_CD		VARCHAR2
    ,P_RT_MSG			OUT VARCHAR2
    ,pRESULT            OUT SYS_REFCURSOR
) 

IS

/*****************************************************************************
Title : [SP_UI_DP_28_CHART_Q1]
최초 작성자 : 한영석
최초 생성일 : 2017.06.20
 
설명 
 - Sales Performance Report CHART 1 쿼리 
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 민희영 / 최초 작성
- 2018.12.21 / 김소희 / FN_DP_TEMP_SALES_REPORT 함수 조회  
- 2020.04.24 / 김소희 / 속도 개선 
- 2020.12.21 / 민경훈 / MSSQL -> ORACLE
*****************************************************************************/

v_ERR_MSG       VARCHAR2(4000):='';
v_ERR_STATUS    INT := NULL;

v_STRT_DATE		DATE;
v_END_DATE		DATE;
v_PLAN_TP_ID	VARCHAR2(32);
v_ITEM_CD		VARCHAR2(4000);
v_ACCT_CD		VARCHAR2(4000);

v_LAST_ITEM_LV	INT;

BEGIN

    v_STRT_DATE     := p_STRT_DATE;
    v_END_DATE	    := p_END_DATE;
    v_PLAN_TP_ID    := p_PLAN_TP_ID;
    v_ITEM_CD	    := p_ITEM_CD;
    v_ACCT_CD	    := p_ACCT_CD;

	SELECT CAST(SUBSTR(MAX(A.FLD_CD), 11,2) AS INT ) INTO v_LAST_ITEM_LV
	  FROM TB_AD_USER_PREF_DTL A 
     inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = 'UI_DP_28' and m.GRID_CD = 'RST_CPT_01' 
     inner join TB_AD_GROUP g on g.ID = A.GRP_ID 
     inner join TB_AD_USER u on u.USERNAME = p_USER_ID 
     inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
     LEFT OUTER JOIN TB_AD_USER_PREF B ON	m.id = B.USER_PREF_MST_ID AND A.GRP_ID = B.GRP_ID	AND	A.FLD_CD = B.FLD_CD	AND B.USER_ID = u.ID					
     WHERE COALESCE(B.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N')) = 'Y' AND A.DIM_MEASURE_TP = 'DIMENSION'    AND SUBSTR(A.FLD_CD, 11,2) BETWEEN 1 AND 20 ; 

    OPEN pRESULT FOR
	WITH VER
	AS (   SELECT DO.ITEM_MST_ID, DO.ACCOUNT_ID
             FROM TB_DP_ENTRY_HISTORY DO
			 	  INNER JOIN
			 	  (SELECT DISTINCT DESCENDANT_ID
			 	     FROM TB_DPD_ITEM_HIER_CLOSURE 
			 	    WHERE LEAF_YN = 'Y'
                      AND (REGEXP_LIKE(UPPER(ANCESTER_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                            OR v_ITEM_CD IS NULL
                      )
--                      AND CASE WHEN v_ITEM_CD LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(v_ITEM_CD,'') END IN (
--                           SELECT TRIM(REGEXP_SUBSTR(v_ITEM_CD, '[^|]+', 1, LEVEL)) AS ITEM_CD
--                                FROM DUAL
--                           CONNECT BY INSTR(v_ITEM_CD, '|', 1, LEVEL - 1) > 0
--                      )
--			 	      AND CASE WHEN v_ITEM_CD NOT LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(v_ITEM_CD,'') END LIKE '%' || COALESCE(v_ITEM_CD,'') || '%'
			 	  ) IH 
			   ON IH.DESCENDANT_ID = DO.ITEM_MST_ID
				   INNER JOIN
				   (SELECT DISTINCT DESCENDANT_ID 
					  FROM TB_DPD_SALES_HIER_CLOSURE 
					 WHERE LEAF_YN = 'Y' 
                       AND (REGEXP_LIKE(UPPER(ANCESTER_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                            OR v_ACCT_CD IS NULL
                      )
--                       AND CASE WHEN v_ACCT_CD LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(v_ACCT_CD,'') END IN (
--                           SELECT TRIM(REGEXP_SUBSTR(v_ACCT_CD, '[^|]+', 1, LEVEL)) AS ACCT_CD
--                                FROM DUAL
--                           CONNECT BY INSTR(v_ACCT_CD, '|', 1, LEVEL - 1) > 0
--                      )
--					   AND CASE WHEN v_ACCT_CD NOT LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(v_ACCT_CD,'') END LIKE '%' || COALESCE(v_ACCT_CD,'') || '%'
				) AM
				ON AM.DESCENDANT_ID = DO.ACCOUNT_ID   
            WHERE 1=1  
		      AND BASE_DATE BETWEEN v_STRT_DATE AND v_END_DATE
		      AND PLAN_TP_ID = v_PLAN_TP_ID
         GROUP BY DO.ITEM_MST_ID, DO.ACCOUNT_ID
	), SA
	AS (SELECT ITEM_MST_ID, ACCOUNT_ID, QTY 
		  FROM TB_CM_ACTUAL_SALES
		 WHERE BASE_DATE BETWEEN v_STRT_DATE AND v_END_DATE
		   AND QTY > 0
	)
		SELECT  CASE v_LAST_ITEM_LV 
				  WHEN 1             THEN  IH.LVL01_CD
				  WHEN 2             THEN  IH.LVL01_CD
				  WHEN 3             THEN  IH.LVL02_CD
				  WHEN 4             THEN  IH.LVL02_CD
				  WHEN 5             THEN  IH.LVL03_CD
				  WHEN 6             THEN  IH.LVL03_CD
				  WHEN 7             THEN  IH.LVL04_CD
				  WHEN 8             THEN  IH.LVL04_CD
				  WHEN 9             THEN  IH.LVL05_CD
				  WHEN 10            THEN  IH.LVL05_CD
				  WHEN 11            THEN  IH.LVL06_CD
				  WHEN 12            THEN  IH.LVL06_CD
				  WHEN 13            THEN  IH.LVL07_CD
				  WHEN 14            THEN  IH.LVL07_CD
				  WHEN 15            THEN  IH.LVL08_CD
				  WHEN 16            THEN  IH.LVL08_CD
				  WHEN 17            THEN  IH.LVL09_CD
				  WHEN 18            THEN  IH.LVL09_CD
				  WHEN 19            THEN  IH.LVL10_CD
				  WHEN 20            THEN  IH.LVL10_CD
				END				AS "CATEGORY"
			  , SUM(SA.QTY) AS "COUNT"
		  FROM  SA 
			    INNER JOIN 
				VER 
			 ON VER.ITEM_MST_ID = SA.ITEM_MST_ID
			AND VER.ACCOUNT_ID = SA.ACCOUNT_ID
		        INNER JOIN
			    TB_DPD_ITEM_HIERACHY2 IH 
		     ON VER.ITEM_MST_ID = IH.ITEM_ID 
	  GROUP BY   CASE v_LAST_ITEM_LV 
				  WHEN 1             THEN  IH.LVL01_CD
				  WHEN 2             THEN  IH.LVL01_CD
				  WHEN 3             THEN  IH.LVL02_CD
				  WHEN 4             THEN  IH.LVL02_CD
				  WHEN 5             THEN  IH.LVL03_CD
				  WHEN 6             THEN  IH.LVL03_CD
				  WHEN 7             THEN  IH.LVL04_CD
				  WHEN 8             THEN  IH.LVL04_CD
				  WHEN 9             THEN  IH.LVL05_CD
				  WHEN 10            THEN  IH.LVL05_CD
				  WHEN 11            THEN  IH.LVL06_CD
				  WHEN 12            THEN  IH.LVL06_CD
				  WHEN 13            THEN  IH.LVL07_CD
				  WHEN 14            THEN  IH.LVL07_CD
				  WHEN 15            THEN  IH.LVL08_CD
				  WHEN 16            THEN  IH.LVL08_CD
				  WHEN 17            THEN  IH.LVL09_CD
				  WHEN 18            THEN  IH.LVL09_CD
				  WHEN 19            THEN  IH.LVL10_CD
				  WHEN 20            THEN  IH.LVL10_CD
				END	

	  ;

	    P_RT_MSG := 'MSG_0003';

       /* ???？o?? ============================================================================*/

        EXCEPTION WHEN OTHERS THEN  -- ?？? ???？？? ?？? ???？?？ : e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_MSG := sqlerrm;
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;   			

END;

/

