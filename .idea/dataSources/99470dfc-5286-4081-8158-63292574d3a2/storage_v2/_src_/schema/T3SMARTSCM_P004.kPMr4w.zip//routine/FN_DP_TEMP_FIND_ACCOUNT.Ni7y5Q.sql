create FUNCTION "FN_DP_TEMP_FIND_ACCOUNT" 
(
    P_EMP_ID     CHAR
  , P_AUTH_TP_ID CHAR
  , P_SALES_LV_CD VARCHAR2 := NULL
)
RETURN DP_TEMP_FIND_ACCOUNT IS
C_DP_TEMP_FIND_ACCOUNT DP_TEMP_FIND_ACCOUNT := DP_TEMP_FIND_ACCOUNT();
CURSOR C_DATA_IMPORT IS     
SELECT TP_DP_TEMP_FIND_ACCOUNT
    (  ACCOUNT_ID           => ID
     , ACCOUNT_CD           => ACCOUNT_CD
     , ACCOUNT_NM           => ACCOUNT_NM
     , PARENT_SALES_LV_ID   => PARENT_SALES_LV_ID
      )
  FROM (

        WITH TB_PR_SALES_LEVEL_MGMT (
            ID
          , PARENT_SALES_LV_ID
          , SALES_LV_CD
          , ORG_LEVEL
        ) AS (
            SELECT ID, PARENT_SALES_LV_ID, SALES_LV_CD, 1 AS ORG_LEVEL
              FROM TB_DP_SALES_LEVEL_MGMT
             WHERE ID IN (
                SELECT M.SALES_LV_ID
                  FROM TB_DP_USER_ACCOUNT_MAP M
                 WHERE M.EMP_ID = P_EMP_ID
                   AND M.AUTH_TP_ID = P_AUTH_TP_ID
             )
            UNION ALL
            SELECT A.ID, A.PARENT_SALES_LV_ID, A.SALES_LV_CD, B.ORG_LEVEL + 1 AS ORG_LEVEL
              FROM TB_DP_SALES_LEVEL_MGMT A, TB_PR_SALES_LEVEL_MGMT B
             WHERE B.ID = A.PARENT_SALES_LV_ID
        )

        SELECT AM.ID, AM.ACCOUNT_CD, AM.ACCOUNT_NM, AM.PARENT_SALES_LV_ID
          FROM TB_PR_SALES_LEVEL_MGMT LV
               INNER JOIN
               TB_DP_ACCOUNT_MST AM
            ON LV.ID = AM.PARENT_SALES_LV_ID 
           and AM.ACTV_YN = 'Y'
           AND COALESCE(AM.DEL_YN,'N') = 'N'
               INNER JOIN
               TABLE(FN_DP_TEMP_ACCT_TREE()) TR
            ON TR.LEAF_SALES_LV_ID = AM.PARENT_SALES_LV_ID
         WHERE (TR.PATH_CD LIKE '%/'||P_SALES_LV_CD||'%' OR P_SALES_LV_CD IS NULL)
        UNION
        SELECT AM.ID, AM.ACCOUNT_CD, AM.ACCOUNT_NM, AM.PARENT_SALES_LV_ID
          FROM (
                SELECT ACCOUNT_ID
                  FROM TB_DP_USER_ACCOUNT_MAP UA
                 WHERE UA.EMP_ID = P_EMP_ID
                   AND UA.AUTH_TP_ID = P_AUTH_TP_ID
                UNION
                SELECT ACCOUNT_ID
                  FROM TB_DP_USER_ITEM_ACCOUNT_MAP UA
                 WHERE UA.EMP_ID = P_EMP_ID
                   AND UA.AUTH_TP_ID = P_AUTH_TP_ID
              GROUP BY ACCOUNT_ID
                )UA
               INNER JOIN
               TB_DP_ACCOUNT_MST AM		   
            ON UA.ACCOUNT_ID = AM.ID
           and AM.ACTV_YN = 'Y'
           AND COALESCE(AM.DEL_YN,'N') = 'N'
               INNER JOIN
               TABLE(FN_DP_TEMP_ACCT_TREE()) TR
            ON TR.LEAF_SALES_LV_ID = AM.PARENT_SALES_LV_ID
         WHERE (TR.PATH_CD LIKE '%/'||P_SALES_LV_CD||'%' OR P_SALES_LV_CD IS NULL)
    )
    ;


BEGIN
        OPEN C_DATA_IMPORT;
        FETCH C_DATA_IMPORT BULK COLLECT INTO C_DP_TEMP_FIND_ACCOUNT;
        CLOSE C_DATA_IMPORT;    
    RETURN C_DP_TEMP_FIND_ACCOUNT;
END;

/

