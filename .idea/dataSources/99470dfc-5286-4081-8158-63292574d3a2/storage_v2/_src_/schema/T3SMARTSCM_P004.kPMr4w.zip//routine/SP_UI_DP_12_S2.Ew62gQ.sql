create PROCEDURE                 "SP_UI_DP_12_S2" (
                                       p_ID                 IN VARCHAR2     := NULL     
									  ,p_SALES_LV_ID        IN VARCHAR2     := NULL     
									  ,p_SEL_SALES_LV_ID    IN VARCHAR2     := NULL         
									  ,p_STRT_DATE_AUTH     IN DATE         := NULL
									  ,p_END_DATE_AUTH      IN DATE         := NULL
									  ,p_EMP_NO             IN VARCHAR2     := ''      
									  ,p_USER_ID            IN VARCHAR2     := ''    
									  ,P_RT_ROLLBACK_FLAG   OUT VARCHAR2  
									  ,P_RT_MSG             OUT VARCHAR2 								    
				                   ) 
iS
/*************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 
    - 2021.04.07 / 源��슜�닔 / SP_UI_DPD_MAKE_HIER_USER 異붽�
************************************************************************/
        v_EMP_ID     VARCHAR2(32) :='';
        P_ERR_STATUS INT := 0;
        P_ERR_MSG VARCHAR2(4000) :='';
        V_LV_MGMT_ID    CHAR(32);

BEGIN
		P_RT_ROLLBACK_FLAG := 'true';
/** VALIDATION **************************************************************************************************************************************************************************/
IF (p_EMP_NO IS NULL)
	THEN
	   P_ERR_MSG := 'MSG_0014'; 
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);			
	END IF;
 SELECT ID INTO v_EMP_ID
 FROM TB_AD_USER
 WHERE USERNAME = p_EMP_NO; 
IF (p_SALES_LV_ID IS NULL
	OR p_SEL_SALES_LV_ID IS NULL)
	THEN
	   P_ERR_MSG := 'MSG_5036'; 
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);	
	END IF;
IF (v_EMP_ID IS NULL)
	THEN
	   P_ERR_MSG := 'MSG_0014'; 
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);			
	END IF;
--IF (p_STRT_DATE_AUTH IS NULL 
--	OR p_END_DATE_AUTH IS NULL
--	)
--	THEN
--	   P_ERR_MSG := 'MSG_0016';
--	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);			
--	END IF;
IF (p_STRT_DATE_AUTH>p_END_DATE_AUTH)
	THEN
	   P_ERR_MSG := 'MSG_0007'; 
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);			
	END IF;


				MERGE INTO TB_DP_SALES_AUTH_MAP TGT
				USING ( 
						SELECT    p_ID                                                          AS   ID 
						         ,CASE WHEN LENGTH(RTRIM(p_SALES_LV_ID))  > 0 
                                       THEN p_SALES_LV_ID ELSE p_SEL_SALES_LV_ID 
                                  END                                                           AS SALES_LV_ID      
								 ,CASE WHEN TO_CHAR(p_STRT_DATE_AUTH, 'YYYYMMDD') LIKE '19010101' 
                                          THEN 	TO_DATE('9999-12-31') 
                                          ELSE p_STRT_DATE_AUTH 
                                       END                                                      AS STRT_DATE_AUTH	
								 ,CASE WHEN TO_CHAR(p_END_DATE_AUTH, 'YYYYMMDD') = '19010101' 
                                          THEN 	TO_DATE('9999-12-31') 
                                          ELSE p_END_DATE_AUTH 
                                       END	                                                    AS 	 END_DATE_AUTH 	
								 ,v_EMP_ID        		                                        AS 	 EMP_ID        	
								 ,p_USER_ID           	                                        AS 	 USER_ID           	
					  FROM dual ) SRC
				ON   (TGT.ID = SRC.ID)
 				WHEN MATCHED THEN
					 UPDATE 
					   SET   
					         TGT.STRT_DATE_AUTH	       = SRC.STRT_DATE_AUTH
							,TGT.END_DATE_AUTH 	       = SRC.END_DATE_AUTH        
							,TGT.EMP_ID        	       = SRC.EMP_ID        
							,TGT.MODIFY_BY             = SRC.USER_ID       
							,TGT.MODIFY_DTTM           = SYSDATE        
				WHEN NOT MATCHED THEN 
					 INSERT ( 
					            ID
					          , SALES_LV_ID   
						      , STRT_DATE_AUTH
						      , END_DATE_AUTH 
						      , EMP_ID        
							  , CREATE_BY
							  , CREATE_DTTM
							) 
					 VALUES (
					            SRC.ID 
                              , SRC.SALES_LV_ID
						      , SRC.STRT_DATE_AUTH
						      , SRC.END_DATE_AUTH 
						      , SRC.EMP_ID        
							  , SRC.USER_ID 
							  , SYSDATE
 							) 
							;    	

	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  --


        SELECT LV_MGMT_ID INTO V_LV_MGMT_ID
          FROM TB_DP_SALES_LEVEL_MGMT
         WHERE ID = P_SALES_LV_ID
         ;
        SP_UI_DP_00_MAKE_USER_GROUP ( V_EMP_ID  , P_EMP_NO, V_LV_MGMT_ID );

        SP_UI_DPD_MAKE_HIER_USER;

       /* ===========================================================================*/
       EXCEPTION
        WHEN OTHERS THEN  -- e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF; 
	END;

/

