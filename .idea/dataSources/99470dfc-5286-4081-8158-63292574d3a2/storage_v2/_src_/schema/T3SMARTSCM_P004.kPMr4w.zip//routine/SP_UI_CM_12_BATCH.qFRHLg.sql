create PROCEDURE "SP_UI_CM_12_BATCH" (
     P_CHK_ITEM_LV          IN CHAR := NULL
    ,P_ITEM_LV_ID           IN CHAR := NULL
    ,P_CHK_SALES_LV         IN CHAR := NULL
    ,P_SALES_LV_ID          IN CHAR := NULL
    ,P_CHK_ITEM             IN CHAR := NULL
    ,P_ITEM_MST_ID          IN CHAR := NULL
    ,P_CHK_ACCOUNT          IN CHAR := NULL
    ,P_ACCOUNT_ID           IN CHAR := NULL
    ,P_LOCAT_MGMT_ID        IN CHAR := NULL
    ,P_TRANSP_LOTSIZE       IN NUMBER := NULL
    ,P_LOAD_UOM_ID          IN CHAR := NULL
    ,P_OVERWRITE_DATA_YN    IN CHAR := NULL
    ,P_USER_ID              IN VARCHAR2
    ,P_RT_ROLLBACK_FLAG     OUT VARCHAR2
    ,P_RT_MSG               OUT VARCHAR2
)
IS
    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';
    P_LOAD_UOM VARCHAR2(100) := '';

BEGIN
    P_ERR_MSG := 'MSG_0006';
    IF P_CHK_ITEM_LV = 'Y' AND NVL(P_ITEM_LV_ID, ' ') = ' ' THEN 
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    IF P_CHK_SALES_LV = 'Y' AND NVL(P_SALES_LV_ID, ' ') = ' ' THEN 
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    IF P_CHK_ITEM = 'Y' AND NVL(P_ITEM_MST_ID, ' ') = ' ' THEN 
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    IF P_CHK_ACCOUNT = 'Y' AND NVL(P_ACCOUNT_ID, ' ') = ' ' THEN 
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    IF NVL(P_LOCAT_MGMT_ID, ' ') = ' ' THEN 
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    
	/***************************************************************************************************************************************************************************
	1. TB_DP_USER_ACCOUNT_MAP 기준의 최하단 ACCOUNT 등록
	***************************************************************************************************************************************************************************/
    INSERT INTO TEMP_ACCOUNT
	(
		ACCOUNT_ID,
		ACCOUNT_CD
	)
    WITH TEMP_SALES_TARGET (LV, P_SALES, C_SALES, SALES_LV_NM, LV_PATH) AS (
        SELECT	0									AS LV,
                CAST(NULL AS CHAR(32))              AS P_SALES,
                A.ID                                AS C_SALES,
                A.SALES_LV_NM,
                CAST(A.SALES_LV_NM AS VARCHAR(4000)) AS LV_PATH
        FROM	TB_DP_SALES_LEVEL_MGMT A
        WHERE	1 = 1
        AND		A.ID IN	(
                        SELECT	ID
                        FROM	TB_DP_SALES_LEVEL_MGMT
                        WHERE	ID IN (SELECT SALES_LV_ID FROM TB_DP_USER_ACCOUNT_MAP)
                        AND		ID = CASE WHEN P_CHK_SALES_LV = 'Y' THEN P_SALES_LV_ID ELSE ID END
                        )
    ),
    TEMP_SALES_LV (LV, P_SALES, C_SALES, SALES_LV_NM, LV_PATH) AS (
        SELECT  LV, P_SALES, C_SALES, SALES_LV_NM, LV_PATH
        FROM    TEMP_SALES_TARGET
        UNION   ALL
        SELECT  A.LV + 1												 AS LV,
                B.PARENT_SALES_LV_ID									 AS P_SALES,
                B.ID													 AS C_SALES,
                B.SALES_LV_NM,
                CAST(A.LV_PATH || ' / ' || B.SALES_LV_NM AS VARCHAR2(4000)) AS LV_PATH
        FROM	TEMP_SALES_LV A,
                TB_DP_SALES_LEVEL_MGMT B
        WHERE	1 = 1
        AND		A.C_SALES = B.PARENT_SALES_LV_ID
    )
	SELECT	B.ID, B.ACCOUNT_CD
	FROM	TEMP_SALES_LV A,
			TB_DP_ACCOUNT_MST B
	WHERE	A.LV = (SELECT MAX(LV) FROM TEMP_SALES_LV)
	AND		A.C_SALES = B.PARENT_SALES_LV_ID
	AND		B.ACTV_YN = 'Y';

	/***************************************************************************************************************************************************************************
	2. TB_DP_USER_ITEM_MAP 기준의 최하단 ITEM 등록
	***************************************************************************************************************************************************************************/
	INSERT INTO TEMP_ITEM
	(
		ITEM_MST_ID,
		ITEM_CD
	)
    WITH TEMP_ITEM_TARGET (LV, P_ITEM, C_ITEM, ITEM_LV_NM, LV_PATH) AS (
        SELECT	0									AS LV,
                CAST(NULL AS CHAR(32))              AS P_ITEM,
                A.ID                                AS C_ITEM,
                A.ITEM_LV_NM,
                CAST(A.ITEM_LV_NM AS VARCHAR2(4000)) AS LV_PATH
        FROM	TB_CM_ITEM_LEVEL_MGMT A
        WHERE	1 = 1
        AND		A.ID IN	(
                        SELECT	ID
                        FROM	TB_CM_ITEM_LEVEL_MGMT
                        WHERE	ID IN (SELECT ITEM_LV_ID FROM TB_DP_USER_ITEM_MAP)
                        AND		ID = CASE WHEN P_CHK_ITEM_LV = 'Y' THEN P_ITEM_LV_ID ELSE ID END
                        )
    )
    ,
    TEMP_ITEM_LV (LV, P_ITEM, C_ITEM, ITEM_LV_NM, LV_PATH) AS (
        SELECT  LV, P_ITEM, C_ITEM, ITEM_LV_NM, LV_PATH
        FROM    TEMP_ITEM_TARGET
        UNION   ALL
        SELECT  A.LV + 1                                              AS LV,
                B.PARENT_ITEM_LV_ID                                   AS P_ITEM,
                B.ID                                                  AS C_ITEM,
                B.ITEM_LV_NM,
                CAST(A.LV_PATH || ' / ' || B.ITEM_LV_NM AS VARCHAR2(4000)) AS LV_PATH 
        FROM	TEMP_ITEM_LV A,
                TB_CM_ITEM_LEVEL_MGMT B
        WHERE	1 = 1
        AND		A.C_ITEM = B.PARENT_ITEM_LV_ID
    )
	SELECT	B.ID, B.ITEM_CD
    FROM	TEMP_ITEM_LV A,
			TB_CM_ITEM_MST B
	WHERE	A.LV = (SELECT MAX(LV) FROM TEMP_ITEM_LV)
	AND		A.C_ITEM = B.PARENT_ITEM_LV_ID
	AND		B.DEL_YN = 'N'
	AND		B.DP_PLAN_YN = 'Y';

	/***************************************************************************************************************************************************************************
	3. DEMAND 대상 ITEM, ACCOUNT 등록
	 - 최하단의 ITEM, ACCOUNT의 조합과 TB_DP_USER_ITEM_ACCOUNT_MAP 데이터
	***************************************************************************************************************************************************************************/
	INSERT INTO TEMP_ITEM_ACCOUNT
	(
		ITEM_MST_ID,
		ACCOUNT_ID
	)
	SELECT	A.ITEM_MST_ID,
			A.ACCOUNT_ID
	FROM	(
			SELECT	A.ITEM_MST_ID, 
					B.ACCOUNT_ID
			FROM	TEMP_ITEM A,
					TEMP_ACCOUNT B
			UNION	ALL
			SELECT	A.ITEM_MST_ID, 
					A.ACCOUNT_ID
			FROM	TB_DP_USER_ITEM_ACCOUNT_MAP A,
					TB_DP_ACCOUNT_MST B,
					TB_CM_ITEM_MST C
			WHERE	B.ID = A.ACCOUNT_ID
			AND		C.ID = A.ITEM_MST_ID
			AND		B.ACTV_YN = 'Y'
			AND		C.DEL_YN = 'N'
			AND		C.DP_PLAN_YN = 'Y'
			) A
	WHERE	1=1
	AND		A.ITEM_MST_ID = CASE WHEN P_CHK_ITEM = 'Y' THEN P_ITEM_MST_ID ELSE A.ITEM_MST_ID END
	AND		A.ACCOUNT_ID  = CASE WHEN P_CHK_ACCOUNT = 'Y' THEN P_ACCOUNT_ID ELSE A.ACCOUNT_ID END
	GROUP	BY A.ITEM_MST_ID, A.ACCOUNT_ID;

	/***************************************************************************************************************************************************************************
	4. 데이터 덮어쓰기 
	 - 옵션 설정된 경우 관련 데이터 모두 삭제
	***************************************************************************************************************************************************************************/
	IF P_OVERWRITE_DATA_YN = 'Y' THEN
		DELETE FROM TB_CM_DMND_SHPP_MAP_LT;
		DELETE FROM TB_CM_DMND_SHPP_MAP_DTL;
		DELETE FROM TB_CM_DMND_SHPP_MAP_MST;
	END IF;

	/***************************************************************************************************************************************************************************
	5. TB_CM_DMND_SHPP_MAP_MST 데이터 생성
	 - ITEM, ACCOUNT 매핑과 출하지 거점 정보 등록
	***************************************************************************************************************************************************************************/
	INSERT INTO TEMP_DMND_SHPP_MAP_MST
	(
		ID,
		ITEM_MST_ID,
		ACCOUNT_ID,
		LOCAT_MGMT_ID
	)
	SELECT	TO_SINGLE_BYTE(SYS_GUID()),
			A.ITEM_MST_ID,
			A.ACCOUNT_ID,
			P_LOCAT_MGMT_ID
	FROM	TEMP_ITEM_ACCOUNT A
	WHERE	NOT EXISTS	(
						SELECT	1
						FROM	TB_CM_DMND_SHPP_MAP_MST X
						WHERE	X.ITEM_MST_ID = A.ITEM_MST_ID
						AND		X.ACCOUNT_ID = A.ACCOUNT_ID
						);

	INSERT INTO TB_CM_DMND_SHPP_MAP_MST
	(
		ID,
		ITEM_MST_ID,
		ACCOUNT_ID,
		LOCAT_MGMT_ID,
		ACTV_YN,
		CREATE_BY,
		CREATE_DTTM
	)
	SELECT	A.ID,
			A.ITEM_MST_ID,
			A.ACCOUNT_ID,
			A.LOCAT_MGMT_ID,
			'Y',
			P_USER_ID,
			SYSDATE
	FROM	TEMP_DMND_SHPP_MAP_MST A;

	/***************************************************************************************************************************************************************************
	6. TB_CM_DMND_SHPP_MAP_DTL 데이터 생성
	 - 대상 : VMI 또는 고객배송모델링이 설정된 경우
	 - 운송관련 정보 등록
	***************************************************************************************************************************************************************************/
	SELECT	NVL(MAX(UPPER(B.COMN_CD)), '') INTO P_LOAD_UOM
	FROM	TB_AD_COMN_GRP A
			INNER JOIN TB_AD_COMN_CODE B
			ON A.ID = B.SRC_ID
	WHERE	1=1
    AND		A.GRP_CD = 'LOAD_UOM_TYPE'
	AND		B.ID = P_LOAD_UOM_ID;

	INSERT INTO TEMP_DMND_SHPP_MAP_DTL
	(
		ID,
		DMND_SHPP_MGMT_MST_ID,
		SHPP_LEADTIME_MST_ID,
		VEHICL_TP_ID,
		PRIORT,
		LOAD_UOM_ID,
		TRANSP_LOTSIZE,
		UOM_QTY,
		PACKING_QTY,
		PACKING_TP_ID,
		PALLET_QTY,
		PALLET_TP_ID
	)
	SELECT	TO_SINGLE_BYTE(SYS_GUID()),
			A.ID AS DMND_SHPP_MGMT_MST_ID,
			B.ID AS SHPP_LEADTIME_MST_ID,
			B.VEHICL_TP_ID,
			B.PRIORT,
			P_LOAD_UOM_ID,
			P_TRANSP_LOTSIZE,
			D.UOM_QTY,
			D.UOM_QTY / D.UOM_PER_PACKING AS PACKING_QTY,
			D.PACKING_TP_CD_ID,
			(D.UOM_QTY / D.UOM_PER_PACKING) / D.PACKING_PER_PALLET AS PALLET_QTY,
			D.PALLET_TP_ID
	FROM	TEMP_DMND_SHPP_MAP_MST A
			INNER JOIN TB_CM_SHIP_LT_MST B
			ON B.ACCOUNT_ID = A.ACCOUNT_ID
			AND B.SUPPLY_LOCAT_ID = A.LOCAT_MGMT_ID
			INNER JOIN
			(SELECT * FROM TB_CM_SITE_ITEM WHERE BOM_ITEM_TP_ID = (SELECT ID FROM TB_AD_COMN_CODE WHERE COMN_CD = 'FINAL_PRODUCT_GR_ITEM')) C
			ON (A.LOCAT_MGMT_ID = C.LOCAT_MGMT_ID AND A.ITEM_MST_ID = C.ITEM_MST_ID)
			LEFT OUTER JOIN
			(
			SELECT	A.LOCAT_ITEM_ID,
					A.PACKING_TP_CD_ID,
					A.UOM_PER_PACKING,
					A.PALLET_TP_ID,
					A.PACKING_PER_PALLET,
					CASE WHEN P_LOAD_UOM = 'UOM'	 THEN P_TRANSP_LOTSIZE
						 WHEN P_LOAD_UOM = 'PACKING' THEN A.UOM_PER_PACKING * P_TRANSP_LOTSIZE
						 WHEN P_LOAD_UOM = 'PALLET'  THEN A.UOM_PER_PACKING * A.PACKING_PER_PALLET * P_TRANSP_LOTSIZE
						 ELSE 0
					END AS UOM_QTY
			FROM	TB_CM_SITE_PACKING A
			WHERE	ACTV_YN = 'Y'
			) D
			ON C.ID = D.LOCAT_ITEM_ID
	WHERE	1=1
	AND		EXISTS	(
					SELECT	1
					FROM	TB_DP_ACCOUNT_MST ACC
							LEFT OUTER JOIN TB_CM_INCOTERMS INC
							ON INC.ID = ACC.INCOTERMS_ID
					WHERE   (ACC.VMI_YN = 'Y' OR INC.CUST_DELIVY_MODELING_YN = 'Y')
					AND		ACC.ID = A.ACCOUNT_ID
					);

	INSERT INTO TB_CM_DMND_SHPP_MAP_DTL
	(
		ID,
		DMND_SHPP_MGMT_MST_ID,
		VEHICL_TP_ID,
		PRIORT,
		LOAD_UOM_ID,
		TRANSP_LOTSIZE,
		UOM_QTY,
		PACKING_QTY,
		PACKING_TP_ID,
		PALLET_QTY,
		PALLET_TP_ID,
		ACTV_YN,
		CREATE_BY,
		CREATE_DTTM
	)
	SELECT	A.ID,
			A.DMND_SHPP_MGMT_MST_ID,
			A.VEHICL_TP_ID,
			A.PRIORT,
			A.LOAD_UOM_ID,
			A.TRANSP_LOTSIZE,
			A.UOM_QTY,
			A.PACKING_QTY,
			A.PACKING_TP_ID,
			A.PALLET_QTY,
			A.PALLET_TP_ID,
			'Y',
			P_USER_ID,
			SYSDATE
	FROM	TEMP_DMND_SHPP_MAP_DTL A;

	/***************************************************************************************************************************************************************************
	7. TB_CM_DMND_SHPP_MAP_LT 데이터 생성
	 - 운송 L/T 정보 등록
	***************************************************************************************************************************************************************************/
	INSERT INTO TB_CM_DMND_SHPP_MAP_LT
	(
		ID,
		DMND_SHPP_MGMT_DTL_ID,
		BOD_LEADTIME_ID,
		LEADTIME,
		UOM_ID,
		CREATE_BY,
		CREATE_DTTM
	)
	SELECT	TO_SINGLE_BYTE(SYS_GUID()),
			A.ID,
			B.BOD_LEADTIME_ID,
			B.LEADTIME,
			B.UOM_ID,
			P_USER_ID,
			SYSDATE
	FROM	TEMP_DMND_SHPP_MAP_DTL A
			INNER JOIN TB_CM_SHIP_LT_DTL B
			ON B.SHPP_LEADTIME_MST_ID = A.SHPP_LEADTIME_MST_ID;

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0003';

EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;
      ELSE
        RAISE;
      END IF;

END;

/

