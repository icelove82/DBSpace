create PACKAGE BODY                 PKG_SMP_I_CONSTRAINT
IS
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved. 
**************************************************************************
* Name    : PKG_SMP_I_CONSTRAINT
* Purpose : MP Static 정보 생성.
* Notes   :   
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
PRAGMA SERIALLY_REUSABLE;

----------------------------- 
-- Public type declarations -
-----------------------------
---
-- Public constant declarations -
---------------------------------

---------------------------------
-- Public variable declarations -
---------------------------------
  G_nLOG_SEQ      NUMBER;
  G_sPKG_ID       NVARCHAR2(1000) := 'PKG_SMP_I_CONSTRAINT';-- DBMS_UTILITY.FORMAT_CALL_STACK;
  G_sPROGRAMN_ID  NVARCHAR2(50);
  G_sSTEP_SEQ     NVARCHAR2(50);
  G_sSTEP_DESC    NVARCHAR2(50);
  --G_sVERSION_ID   NVARCHAR2(50);
  G_sUSER_ID      NVARCHAR2(50);
  G_nSQL_CNT      NUMBER(20);
  G_sLOGMSG       VARCHAR2(4000);
---------------------------------
-- Public function declarations -
---------------------------------

----------------------------------
-- Public procedure declarations -
----------------------------------
PROCEDURE SP_SET_LINE_CAPA ( 
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_LINE_CAPA
* Purpose : 라인 Capacity
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_LINE_CAPA';

--*[V2 AIS]**************************************************************************************
  --* Cell assy capa.-----------------------------------------------------------------------------------
  G_sSTEP_SEQ  := '2.0';   
  G_sSTEP_DESC := 'Set Resource Capacity(Cell) - Month Bucket';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  INSERT INTO RESOURCE_CAPACITY(ENGINE_ID, RESOURCE_ID, START_DATE, END_DATE, CAPACITY, PERIOD_CAPACITY, DISTRIBUTION_CAPACITY) 
  SELECT P_tPLAN_OPTION.ENGINE_ID                                AS ENGINE_ID
        ,ACA.LINE_CD                                             AS RESOURCE_ID
        ,ACA.START_DATE            AS START_DATE
        ,ACA.END_DATE              AS END_DATE
        ,NVL(ACA.CAPACITY, 0)                                 AS CAPACITY
        ,'N'                                                     AS PERIOD_CAPACITY
        ,'N'                                                     AS DISTRIBUTION_CAPACITY
    FROM VW_SMP_LINE_CAPA_VER  ACA
   WHERE VERSION_ID = P_tPLAN_OPTION.VERSION_ID
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_WK_BOR    SWB
          WHERE SWB.VERSION_ID   = P_tPLAN_OPTION.VERSION_ID
            AND SWB.SITE_CD      = ACA.SITE_CD
            AND SWB.LINE_CD      = ACA.LINE_CD)
  ; 
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
--*[V2 AIS]**************************************************************************************  


/*  
  --* Cell assy capa.-----------------------------------------------------------------------------------
  G_sSTEP_SEQ  := '2.0';   
  G_sSTEP_DESC := 'Set Resource Capacity(Cell) - Month Bucket';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  INSERT INTO RESOURCE_CAPACITY(ENGINE_ID, RESOURCE_ID, START_DATE, END_DATE, CAPACITY, PERIOD_CAPACITY, DISTRIBUTION_CAPACITY) 
  SELECT P_tPLAN_OPTION.ENGINE_ID                                AS ENGINE_ID
        ,ACA.LINE_CD                                             AS RESOURCE_ID
        ,TO_DATE(ACA.BASE_MONTH || '01', 'YYYYMMDD')             AS START_DATE
        ,LAST_DAY(TO_DATE(ACA.BASE_MONTH || '01', 'YYYYMMDD'))+1 AS END_DATE
        ,NVL(ACA.T_CAPA_MIN, 0)                                  AS CAPACITY
        ,'N'                                                     AS PERIOD_CAPACITY
        ,'Y'                                                     AS DISTRIBUTION_CAPACITY
    FROM TB_SMP_LINE_CAPA  ACA
   WHERE ACA.BASE_MONTH    <  TO_CHAR(P_tPLAN_OPTION.BUCKET_3_START_DATE, 'YYYYMM')
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_WK_BOR    SWB
          WHERE SWB.VERSION_ID   = P_tPLAN_OPTION.VERSION_ID
            AND SWB.SITE_CD      = ACA.SITE_CD
            AND SWB.LINE_CD      = ACA.LINE_CD)
  ; 
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --* Cell assy capa.-----------------------------------------------------------------------------------
  G_sSTEP_SEQ  := '3.0';   
  G_sSTEP_DESC := 'Set Resource Capacity(Cell) - Year Bucket';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  INSERT INTO RESOURCE_CAPACITY(ENGINE_ID, RESOURCE_ID, START_DATE, END_DATE, CAPACITY, PERIOD_CAPACITY, DISTRIBUTION_CAPACITY) 
  SELECT ENGINE_ID, RESOURCE_ID, START_DATE, END_DATE, CAPACITY, PERIOD_CAPACITY, DISTRIBUTION_CAPACITY
  FROM  (
          SELECT P_tPLAN_OPTION.ENGINE_ID                                  AS ENGINE_ID
                ,ACA.LINE_CD                                               AS RESOURCE_ID
                ,TO_DATE(SUBSTR(ACA.BASE_MONTH,1,4) || '0101', 'YYYYMMDD') AS START_DATE
                ,TO_DATE(SUBSTR(ACA.BASE_MONTH,1,4) || '1231', 'YYYYMMDD') AS END_DATE
                ,NVL(ACA.T_CAPA_MIN, 0) * 12                               AS CAPACITY
                ,'N'                                                       AS PERIOD_CAPACITY
                ,'N'                                                       AS DISTRIBUTION_CAPACITY
                ,ROW_NUMBER() OVER ( PARTITION BY ACA.LINE_CD, SUBSTR(ACA.BASE_MONTH,1,4) ORDER BY ACA.T_CAPA_MIN DESC) RNK
            FROM TB_SMP_LINE_CAPA  ACA
           WHERE ACA.BASE_MONTH    >= TO_CHAR(P_tPLAN_OPTION.BUCKET_3_START_DATE, 'YYYYMM')
             AND ACA.BASE_MONTH    <= TO_CHAR(P_tPLAN_OPTION.END_DATE, 'YYYYMM')
             AND EXISTS (
                 SELECT 1
                   FROM TB_SMP_WK_BOR    SWB
                  WHERE SWB.VERSION_ID   = P_tPLAN_OPTION.VERSION_ID
                    AND SWB.SITE_CD      = ACA.SITE_CD
                    AND SWB.LINE_CD      = ACA.LINE_CD)
          ) 
  WHERE RNK = 1
  ; 
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
*/  
  --* Cell assy capa.-----------------------------------------------------------------------------------
  G_sSTEP_SEQ  := '4.0';   
  G_sSTEP_DESC := 'Set Resource Capacity(Cell) - Not exists capa.';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  INSERT INTO RESOURCE_CAPACITY(ENGINE_ID, RESOURCE_ID, START_DATE, END_DATE, CAPACITY, PERIOD_CAPACITY, DISTRIBUTION_CAPACITY) 
  SELECT P_tPLAN_OPTION.ENGINE_ID                                     AS ENGINE_ID
        ,ACA.LINE_CD
        ,ADD_MONTHS( TO_DATE(MAX(BASE_MONTH)||'01', 'YYYYMMDD'),  1 ) AS START_DATE
        ,P_tPLAN_OPTION.END_DATE + 1                                  AS END_DATE
        ,0                                                            AS CAPACITY
        ,'N'                                                          AS PERIOD_CAPACITY
        ,'N'                                                          AS DISTRIBUTION_CAPACITY        
    FROM TB_SMP_LINE_CAPA  ACA
   WHERE EXISTS (
         SELECT 1
           FROM TB_SMP_WK_BOR    SWB
          WHERE SWB.VERSION_ID   = P_tPLAN_OPTION.VERSION_ID
            AND SWB.SITE_CD      = ACA.SITE_CD
            AND SWB.LINE_CD      = ACA.LINE_CD)
   GROUP BY ACA.SITE_CD, ACA.LINE_CD
  ; 
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

PROCEDURE SP_SET_LINE_MAP (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_LINE_MAP
* Purpose : 전극-조립-화성 라인 Mapping
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_LINE_MAP';

  --* Bundle BOR ---------------------------------------------------------------------------------------
  G_sSTEP_SEQ  := '1.0';   
  G_sSTEP_DESC := 'Set Bundle BOR';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);
  INSERT INTO BUNDLE_BOR (BUNDLE_ID, RESOURCE_ID, ROUTE_ID)
  SELECT M.BUNDLE_ID
         --* BUNDLE_ID = ExxAxxFxx
        ,CASE D.RN WHEN 1 THEN E_LINE_CD 
                   WHEN 2 THEN A_LINE_CD
                   WHEN 3 THEN F_LINE_CD
         END  AS RESOURCE_ID
        ,NULL AS ROUTE_ID
    FROM (
          SELECT SRM.SITE_CD 
--[AIS_TODO] 전극 Bundle 사용 안함.          
                ,'E' || ELN.BUILDING_NO || ELN.LINE_NO || 
                 'A' || ALN.BUILDING_NO || ALN.LINE_NO ||
                 'F' || FLN.BUILDING_NO || FLN.LINE_NO   AS  BUNDLE_ID
                ,SRM.E_LINE_CD     
                ,SRM.A_LINE_CD
                ,SRM.F_LINE_CD           
            FROM TB_SMP_ROUTE_MAP SRM
                ,TB_SMP_LINE_MST  ELN
                ,TB_SMP_LINE_MST  ALN
                ,TB_SMP_LINE_MST  FLN
           WHERE SRM.SITE_CD      = ELN.SITE_CD 
             AND SRM.E_LINE_CD    = ELN.LINE_CD 
             AND SRM.SITE_CD      = ALN.SITE_CD 
             AND SRM.A_LINE_CD    = ALN.LINE_CD 
             AND SRM.SITE_CD      = FLN.SITE_CD 
             AND SRM.F_LINE_CD    = FLN.LINE_CD        
         ) M
        ,(SELECT ROWNUM AS RN FROM DUAL CONNECT BY ROWNUM <= 3) D
  ; 
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------

  --* Bundle -------------------------------------------------------------------------------------------
  G_sSTEP_SEQ  := '2.0';   
  G_sSTEP_DESC := 'Set Bundle';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);
  INSERT INTO BUNDLE (BUNDLE_ID, BUNDLE_NAME )
  SELECT DISTINCT BUNDLE_ID , BUNDLE_ID 
    FROM BUNDLE_BOR 
   WHERE ENGINE_ID = P_tPLAN_OPTION.ENGINE_ID
  ; 
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------  
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

PROCEDURE SP_SET_BOD_PRIORITY (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_BOD_PRIORITY
* Purpose : BOD 우선 순위
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_BOD_PRIORITY';

  --* Set SO Route Assign-------------------------------------------------------------------------------
  G_sSTEP_SEQ  := '1.0';   
  G_sSTEP_DESC := 'Set S/O Route Assign';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);
  INSERT INTO SO_ROUTE_ASSIGN(ENGINE_ID, SALESORDER_ID, ROUTE_ID, USABLE, PRIORITY)
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,BOD.DEMAND_ID
        ,BOD.ROUTE_ID
        ,BOD.USABLE
        ,CASE WHEN BOD.USABLE = 'Y' THEN
                   RANK() OVER ( PARTITION BY BOD.DEMAND_ID 
                                     ORDER BY NVL(PFT.LIMIT_PROFIT_COST, 0) DESC --한계이익  많은것
                                             ,NVL(BOD.LEAD_TIME, 999)            --L/T    적은것
                                             ,CONTINENT_PRIROITY                 --동일 대륙
                                             ,BOD.ROUTE_ID
                               ) 
              ELSE NULL
         END AS PRIORITY
        --,PFT.LIMIT_PROFIT_COST
    FROM (-- DEMAND로 BOD ROUTE_ID 찾기
          SELECT SWD.PGM_D_CD 
                ,SWD.PGM_STATUS_CD
                ,SWD.CELL_CD 
                ,TO_CHAR(SWD.DUE_DATE, 'YYYYMM') BASE_MONTH 
                ,SWB.SITE_CD 
                ,SWD.DEMAND_ID 
                ,SWB.ROUTE_ID 
                ,SWB.LEAD_TIME
                ,SWD.T_CONTINENT_CD AS DEMAND_CONTINENT 
                ,SWB.CONTINENT_CD   AS PROD_CONTINENT       
                ,CASE WHEN SWD.T_CONTINENT_CD = SWB.CONTINENT_CD THEN 1 ELSE 2 END AS CONTINENT_PRIROITY --동일대륙 1, 아니면 2
                ,COUNT(1) OVER ( PARTITION BY SWD.DEMAND_ID, SWD.T_CONTINENT_CD )  AS ROUTE_CNT
                ,BOR.CERTIF_LINE_CNT
                ,CASE WHEN SWD.PGM_STATUS_CD = 'C' AND BOR.CERTIF_LINE_CNT > 0 THEN 'Y' 
                      WHEN SWD.PGM_STATUS_CD = 'P'                             THEN 'Y'
                      ELSE                                                          'N' 
                 END           AS USABLE                
            FROM TB_SMP_WK_DEMAND    SWD
                ,TB_SMP_WK_BOM       SWB
                ,(SELECT B.ITEM_CD, SUM(CASE WHEN B.CERTIF_YN = 'Y' THEN 1 ELSE 0 END) AS CERTIF_LINE_CNT
                    FROM TB_SMP_WK_BOR B
                   WHERE B.VERSION_ID  = P_tPLAN_OPTION.VERSION_ID
                   GROUP BY B.ITEM_CD 
                 )                   BOR 
           WHERE SWD.VERSION_ID      = SWB.VERSION_ID 
             AND SWD.ITEM_CD         = SWB.P_ITEM_CD 
             AND SWD.T_CONTINENT_CD  = SWB.T_CONTINENT_CD -- DEMAND의 대륙과 BOM상의 대륙이 일치하는 경우만 
             AND SWB.P_ROUTE_CD      = P_tPLAN_OPTION.BOD_ROUTE_CD --'BOD'
             AND SWD.USE_FLAG        = 'Y'
             AND SWB.USE_FLAG        = 'Y'
             AND SWD.VERSION_ID      = P_tPLAN_OPTION.VERSION_ID
             AND SWD.CELL_ITEM_CD    = BOR.ITEM_CD (+)
         ) BOD
        ,(--수주프로그램 월별, CELL당 한계 이익
          SELECT SPM.PGM_D_CD 
                ,SPP.CELL_CD 
                ,SPP.SITE_CD
                ,SPP.BASE_MONTH 
                ,SPP.LIMIT_PROFIT_COST 
            FROM TB_SMP_SITE_PGM_PROFIT SPP --단위당 한계 이익으로 변경되어야 함.     
                ,TB_SMP_SALES_PGM_MST   SPM -- 판매단위 pgm
           WHERE SPP.CUTOFF_DATE = P_tPLAN_OPTION.CUTOFF_DATE --'20200103' -- DEMAND_CUTOFF 기준년월일
             AND SPP.PGM_S_CD    = SPM.PGM_S_CD
         ) PFT
   WHERE BOD.PGM_D_CD   = PFT.PGM_D_CD  (+) 
     AND BOD.CELL_CD    = PFT.CELL_CD   (+)
     AND BOD.BASE_MONTH = PFT.BASE_MONTH(+)
     AND BOD.SITE_CD    = PFT.SITE_CD   (+)
     AND ( BOD.USABLE = 'N'                         --라인 인증 없는 경우
           OR
          (BOD.USABLE = 'Y' AND BOD.ROUTE_CNT  > 1) --라인 인증이 있는 경우, 대체 ROUTE가 존재하는 경우만 우선순위 정함.
         )
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT); 
  ------------------------------------------------------------------------------------------------------  
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

PROCEDURE SP_SET_BAS_PRIORITY (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_BAS_PRIORITY
* Purpose : 라인 우선 순위 (PPM 우선 순위)
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_BAS_PRIORITY'; 

  --*Set -----------------------------------------------------------------------------------------------
  G_sSTEP_SEQ  := '1.0';   
  G_sSTEP_DESC := 'Set S/O Resource Assign(수주확정)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  INSERT INTO SO_RESOURCE_ASSIGN(ENGINE_ID, SALESORDER_ID, ROUTE_ID, RESOURCE_ID, USABLE, PRIORITY)   
  WITH W_SRC AS (
    SELECT --DISTINCT
           /*+ USE_HASH (SWD, BOM) */ 
           SWD.DEMAND_ID     
          ,SWD.CELL_CD 
          ,SWD.CELL_ITEM_CD
          ,BOM.SITE_CD 
          ,BOM.ROUTE_ID      ROUTE_ID
          ,BOR.LINE_CD       
          ,SWD.PGM_STATUS_CD
          ,BOR.PROCESS_CAPACITY
          ,BOR.CERTIF_YN
      FROM TB_SMP_WK_DEMAND  SWD
          --,TB_SMP_WK_BOM     BOM
          ,(SELECT B.VERSION_ID, B.SITE_CD, B.P_ITEM_CD, B.ROUTE_ID, B.P_ROUTE_CD, B.USE_FLAG
            FROM   TB_SMP_WK_BOM B
            WHERE  B.VERSION_ID = P_tPLAN_OPTION.VERSION_ID
            AND    B.P_ROUTE_CD = P_tPLAN_OPTION.ASSY_ROUTE_CD--'BAS'
            AND    B.USE_FLAG   = 'Y'
            GROUP BY B.VERSION_ID, B.SITE_CD, B.P_ITEM_CD, B.ROUTE_ID, B.P_ROUTE_CD, B.USE_FLAG
           ) BOM
          ,TB_SMP_WK_BOR     BOR
     WHERE SWD.VERSION_ID    = P_tPLAN_OPTION.VERSION_ID
       AND SWD.VERSION_ID    = BOM.VERSION_ID
       AND SWD.CELL_ITEM_CD  = BOM.P_ITEM_CD 
       AND BOM.P_ROUTE_CD    = P_tPLAN_OPTION.ASSY_ROUTE_CD--'BAS'       
       AND BOM.VERSION_ID    = BOR.VERSION_ID 
       AND BOM.ROUTE_ID      = BOR.ROUTE_ID 
       AND SWD.PGM_STATUS_CD = 'C'--'수주확정' 
       AND BOM.USE_FLAG      = 'Y'
    )
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,W_SRC.DEMAND_ID                      AS SALESORDER_ID
        ,W_SRC.ROUTE_ID                       AS ROUTE_ID
        ,W_SRC.LINE_CD                        AS RESOURCE_ID
--        ,DECODE(ACM.LINE_CD, NULL, 'N', 'Y')  AS USABLE
--        ,RANK() OVER (PARTITION BY W_SRC.DEMAND_ID, W_SRC.ROUTE_ID ORDER BY NVL(ACM.PPM_VAL, -1) DESC, ACM.LINE_CD) 
        ,NVL(CERTIF_YN, 'N')                  AS USABLE
        ,RANK() OVER (PARTITION BY W_SRC.DEMAND_ID, W_SRC.ROUTE_ID ORDER BY NVL(W_SRC.PROCESS_CAPACITY, 999999999), W_SRC.LINE_CD)
                                              AS PRIORITY
    FROM W_SRC
--        ,TB_SMP_ASSY_CERF_MST ACM
--   WHERE W_SRC.SITE_CD        = ACM.SITE_CD (+)
--     AND W_SRC.LINE_CD        = ACM.LINE_CD (+) 
--     AND W_SRC.CELL_CD        = ACM.CELL_CD (+)
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --*Set -----------------------------------------------------------------------------------------------
  G_sSTEP_SEQ  := '2.0';   
  G_sSTEP_DESC := 'Set S/O Resource Assign(수주추진)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);  
  INSERT INTO SO_RESOURCE_ASSIGN(ENGINE_ID, SALESORDER_ID, ROUTE_ID, RESOURCE_ID, USABLE, PRIORITY)   
  WITH W_SRC AS (
    SELECT DISTINCT
           SWD.DEMAND_ID     
          ,SWD.CELL_CD 
          ,SWD.CELL_ITEM_CD
          ,BOM.SITE_CD 
          ,BOM.ROUTE_ID      
          ,BOR.LINE_CD       
          ,SWD.PGM_STATUS_CD
          --DOUBLE / SINGLE      양방향 / 단방향
          --NORM / LONG / WIDE   표준폭 / 장폭 /  광폭
          ,SWD.POLAR_DIRECTION_CD AS CELL_POLAR_DIRECTION_CD 
          ,SWD.WIDTH_TYPE_CD      AS CELL_WIDTH_TYPE_CD
          ,CASE BOR.POLAR_DIRECTION_CD WHEN '양방향' THEN 'DOUBLE'
                                       WHEN '단방향' THEN 'SINGLE'
                ELSE BOR.POLAR_DIRECTION_CD 
           END                    AS LINE_POLAR_DIRECTION_CD
          ,CASE BOR.WIDTH_TYPE_CD WHEN '표준폭' THEN 'NORM'
                                  WHEN '장폭'  THEN 'LONG'
                                  WHEN '광폭'  THEN 'WIDE'
                ELSE BOR.WIDTH_TYPE_CD      
           END                    AS LINE_WIDTH_TYPE_CD          
      FROM TB_SMP_WK_DEMAND  SWD 
          ,TB_SMP_WK_BOM     BOM
          ,TB_SMP_WK_BOR     BOR
     WHERE SWD.VERSION_ID    = P_tPLAN_OPTION.VERSION_ID
       AND SWD.VERSION_ID    = BOM.VERSION_ID
       AND SWD.CELL_ITEM_CD  = BOM.P_ITEM_CD 
       AND BOM.P_ROUTE_CD    = P_tPLAN_OPTION.ASSY_ROUTE_CD--'BAS'
       AND BOM.VERSION_ID    = BOR.VERSION_ID 
       AND BOM.ROUTE_ID      = BOR.ROUTE_ID 
       AND SWD.PGM_STATUS_CD = 'P'--'수주추진' 
       AND BOM.USE_FLAG      = 'Y'
    )
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,W_SRC.DEMAND_ID                      AS SALESORDER_ID
        ,W_SRC.ROUTE_ID                       AS ROUTE_ID
        ,W_SRC.LINE_CD                        AS RESOURCE_ID
--[AIS_TODO] 단/양, 폭정보가 없으면 어떻게 처리할지 정리 필요        
        ,CASE WHEN --(CELL_POLAR_DIRECTION_CD IS NOT NULL AND CELL_WIDTH_TYPE_CD IS NOT NULL) AND
                   (NVL(CELL_POLAR_DIRECTION_CD, '_') = NVL(LINE_POLAR_DIRECTION_CD, '@'))  AND
                   (NVL(CELL_WIDTH_TYPE_CD     , '_') = NVL(LINE_WIDTH_TYPE_CD     , '@'))  THEN 'Y'
              ELSE 'N'
         END                                  AS USABLE
        ,RANK() OVER (PARTITION BY W_SRC.DEMAND_ID, W_SRC.ROUTE_ID ORDER BY LINE_CD) 
                                              AS PRIORITY
    FROM W_SRC
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

PROCEDURE SP_SET_BAS_CERTI (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_BAS_CERTI
* Purpose : 라인 인증 정보 반영
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*    1. ASSY PST
*      (1) CONFIG.에 설정된 DEFAULT 선행 생산 PST (PLAN_PST_MONTH, 6개월로 Setting되어 있음)  
*      (2) 년BUCKET DEMAND의 경우 PST를 1년으로 함                                                                     
*      (3) 법인별 확정구간 적용을 위한 PST (법인별로 확정구간이 달라 SO ROUTE PST 사용 )            
*      (4) 라인 인증 PST                                                             
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_BAS_CERTI';

  --* ROUTE PST- ---------------------------------------------------------------------------------------
  G_sSTEP_SEQ  := '1.0';   
  G_sSTEP_DESC := 'Set S/O Route PST';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);
  --확정구간 SO_ROUTE_PST 설정과 실행 순서가 변경될수 있으므로 MERGE문 사용함
  MERGE INTO SO_ROUTE_PST TAR
  USING (
    WITH W_SRC AS (
      SELECT --DISTINCT
             /*+ USE_HASH(SWD, BOM) */
             SWD.DEMAND_ID     
            ,SWD.CELL_CD 
            ,SWD.CELL_ITEM_CD
            ,BOM.SITE_CD 
            ,BOM.ROUTE_ID      
            ,BOR.LINE_CD 
            ,SWD.ASSY_ROUTE_PST
            ,ADD_MONTHS(P_tPLAN_OPTION.START_DATE, NVL(SSM.MP_FIXED_MM_VAL,0)) AS FIXD_ZONE_PST --SITE별 PST(확정구간이루로만 계획 수립을 위해)
            ,DECODE(SWD.PGM_STATUS_CD, 'P', NULL, BOR.CERTIF_MONTH) AS CERTIF_MONTH --수주추진건은 라인인증 무시
            ,TO_DATE(SLM.VALID_START_DATE, 'YYYYMMDD') AS LINE_VALID_START_DATE
        FROM TB_SMP_WK_DEMAND  SWD 
            --,TB_SMP_WK_BOM     BOM
            ,(SELECT B.VERSION_ID, B.SITE_CD, B.P_ITEM_CD, B.ROUTE_ID, B.P_ROUTE_CD, B.USE_FLAG
              FROM   TB_SMP_WK_BOM B
              WHERE  B.VERSION_ID = P_tPLAN_OPTION.VERSION_ID
              AND    B.P_ROUTE_CD = P_tPLAN_OPTION.ASSY_ROUTE_CD--'BAS'
              AND    B.USE_FLAG   = 'Y'
              GROUP BY B.VERSION_ID, B.SITE_CD, B.P_ITEM_CD, B.ROUTE_ID, B.P_ROUTE_CD, B.USE_FLAG
             ) BOM            
            ,TB_SMP_WK_BOR     BOR
            ,TB_SMP_SITE_MST   SSM
            ,TB_SMP_LINE_MST   SLM
       WHERE SWD.VERSION_ID    = P_tPLAN_OPTION.VERSION_ID
         AND SWD.USE_FLAG      = 'Y'
         AND SWD.VERSION_ID    = BOM.VERSION_ID
         AND SWD.CELL_ITEM_CD  = BOM.P_ITEM_CD 
         AND BOM.USE_FLAG      = 'Y'
         AND BOM.P_ROUTE_CD    = P_tPLAN_OPTION.ASSY_ROUTE_CD -- 'BAS'
         AND BOM.VERSION_ID    = BOR.VERSION_ID 
         AND BOM.ROUTE_ID      = BOR.ROUTE_ID 
         --AND SWD.PGM_STATUS_CD = 'C'--'수주확정' (수주 추진건도 포함하되 라인인증 무시함)
         AND BOM.SITE_CD       = SSM.SITE_CD 
         AND BOR.SITE_CD       = SLM.SITE_CD
         AND BOR.LINE_CD       = SLM.LINE_CD
      )
    SELECT P_tPLAN_OPTION.ENGINE_ID 
                                AS ENGINE_ID
          ,W_SRC.DEMAND_ID      AS SALESORDER_ID
          ,W_SRC.ROUTE_ID       AS ROUTE_ID
          ,W_SRC.LINE_CD        AS RESOURCE_ID
          -- 확정구간, 조립 ROUTE 선행, 라인 유효 시작일, 라인 인증 비교
          ,GREATEST( W_SRC.FIXD_ZONE_PST  
                    ,W_SRC.ASSY_ROUTE_PST
                    ,W_SRC.LINE_VALID_START_DATE
                    ,DECODE(W_SRC.CERTIF_MONTH, NULL, W_SRC.FIXD_ZONE_PST, TO_DATE(W_SRC.CERTIF_MONTH || '01', 'YYYYMMDD'))
                   )            AS PST 
          ,NULL                 AS PET
      FROM W_SRC 
    ) SRC
  ON (    SRC.SALESORDER_ID = TAR.SALESORDER_ID
      AND SRC.ROUTE_ID      = TAR.ROUTE_ID
      AND SRC.RESOURCE_ID   = TAR.RESOURCE_ID
      AND SRC.ENGINE_ID     = TAR.ENGINE_ID
     )
  WHEN MATCHED     THEN
    UPDATE 
       SET TAR.PST = GREATEST(TAR.PST, SRC.PST)   
          ,TAR.PET = TO_DATE('88881231','YYYYMMDD')
  WHEN NOT MATCHED THEN
    INSERT (ENGINE_ID, SALESORDER_ID, ROUTE_ID, RESOURCE_ID, PST, PET) 
    VALUES(SRC.ENGINE_ID
          ,SRC.SALESORDER_ID
          ,SRC.ROUTE_ID
          ,SRC.RESOURCE_ID
          ,SRC.PST
          ,TO_DATE('99991231','YYYYMMDD')
          )
  ; 
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

PROCEDURE SP_SET_BAS_JCT (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_BAS_JCT
* Purpose : JOB CHANGE TIME
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
IS
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_BAS_JCT';
  
  --* Set Route Group Map.------------------------------------------------------------------------------
  G_sSTEP_SEQ  := '1.0';   
  G_sSTEP_DESC := 'Set Route.Route Group Map.';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);
   -- 최소 생산 알박기 BOM, BOR, ROUTE 처리해야 함.
  UPDATE ROUTE RT 
     SET (RT.ROUTE_GRP_MAP, RT.ALTERNATE_RESOURCE_POLICY)
         =
        (SELECT MAX('SIZE=' || S2.WIDTH_VAL || '*' || S2.LENGTH_VAL || ',THICK=' || S2.THICKNESS_VAL)
               ,CASE WHEN COUNT(1) > 1 THEN 'MIN_JCT' ELSE NULL END
           FROM TB_SMP_WK_BOR S2
          WHERE S2.VERSION_ID  = P_tPLAN_OPTION.VERSION_ID
            AND S2.ROUTE_ID    = RT.ROUTE_ID 
            AND S2.ROUTE_CD    = P_tPLAN_OPTION.ASSY_ROUTE_CD)
--[AIS_TODO]          
        --,RT.CONTINU_PROD_MODE         = 'Y'            
   WHERE RT.ENGINE_ID          = P_tPLAN_OPTION.ENGINE_ID
     AND EXISTS (
         SELECT 1         
           FROM TB_SMP_WK_BOR S1
          WHERE S1.VERSION_ID  = P_tPLAN_OPTION.VERSION_ID
            AND S1.ROUTE_ID    = RT.ROUTE_ID 
            AND S1.ROUTE_CD    = P_tPLAN_OPTION.ASSY_ROUTE_CD
         )
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------

  --* Set Job Change Route Group : Size ----------------------------------------------------------------
  G_sSTEP_SEQ  := '2.0';   
  G_sSTEP_DESC := 'Set Job Change Time Group(Size)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);
  INSERT INTO JOB_CHANGE_TIME_GRP(
          ENGINE_ID, RESOURCE_ID, ROUTE_GRP_TYPE, FROM_ROUTE_GRP_ID, TO_ROUTE_GRP_ID
        , JC_CAPACITY, JC_GRP_ID)  
  WITH W_SRC AS (
    SELECT LINE_CD
          ,WIDTH_VAL || '*' || LENGTH_VAL AS RGT_SIZE
          ,MAX(FULL_JC_1ST_VAL)           AS NORM_1ST_JC_VAL
          ,MAX(FULL_JC_2ND_VAL)           AS NORM_2ND_JC_VAL
      FROM TB_SMP_WK_BOR         SWB
     WHERE VERSION_ID  = P_tPLAN_OPTION.VERSION_ID
       AND ROUTE_CD    = P_tPLAN_OPTION.ASSY_ROUTE_CD
     GROUP BY
           LINE_CD
          ,WIDTH_VAL || '*' || LENGTH_VAL
    )      
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,G1.LINE_CD         AS RESOURCE_ID
        ,'SIZE'             AS ROUTE_GRP_TYPE      
        ,G1.RGT_SIZE        AS FROM_ROUTE_GRP_ID 
        ,G2.RGT_SIZE        AS TO_ROUTE_GRP_ID  
        ,G2.NORM_2ND_JC_VAL AS JC_CAPACITY    
        ,'{$ALL}'           AS JC_GRP_ID
    FROM W_SRC G1
        ,W_SRC G2
   WHERE G1.LINE_CD         =  G2.LINE_CD
     AND G1.RGT_SIZE        <> G2.RGT_SIZE
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
COMMIT;
  --* Set Job Change Route Group : Thickness------------------------------------------------------------
  G_sSTEP_SEQ  := '3.0';   
  G_sSTEP_DESC := 'Set Job Change Time Group(Thickness)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);
  INSERT INTO JOB_CHANGE_TIME_GRP(
          ENGINE_ID, RESOURCE_ID, ROUTE_GRP_TYPE, FROM_ROUTE_GRP_ID, TO_ROUTE_GRP_ID
        , JC_CAPACITY, JC_GRP_ID)
  WITH W_SRC AS (
    SELECT LINE_CD
          ,WIDTH_VAL || '*' || LENGTH_VAL AS RGT_SIZE
          ,THICKNESS_VAL                  AS RGT_THICK
          ,MAX(SEMI_JC_1ST_VAL)           AS SEMI_1ST_JC_VAL
          ,MAX(SEMI_JC_2ND_VAL)           AS SEMI_2ND_JC_VAL   
      FROM TB_SMP_WK_BOR 
     WHERE VERSION_ID  = P_tPLAN_OPTION.VERSION_ID
       AND ROUTE_CD    = P_tPLAN_OPTION.ASSY_ROUTE_CD
     GROUP BY
           LINE_CD
          ,WIDTH_VAL || '*' || LENGTH_VAL 
          ,THICKNESS_VAL
    )
  SELECT DISTINCT 
         P_tPLAN_OPTION.ENGINE_ID
        ,G1.LINE_CD         AS RESOURCE_ID
        ,'THICK'            AS ROUTE_GRP_TYPE       
        ,G1.RGT_THICK       AS FROM_ROUTE_GRP_ID  
        ,G2.RGT_THICK       AS TO_ROUTE_GRP_ID   
        ,G2.SEMI_2ND_JC_VAL AS JC_CAPACITY 
        ,'{$ALL}'           AS JC_GRP_ID
    FROM W_SRC G1
        ,W_SRC G2
   WHERE G1.LINE_CD         = G2.LINE_CD
     AND G1.RGT_SIZE        = G2.RGT_SIZE
     AND G1.RGT_THICK       <> G2.RGT_THICK
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
   
--*[V2 AIS]**************************************************************************************  
COMMIT;
  G_sSTEP_SEQ  := '4.0';   
  G_sSTEP_DESC := 'Set JOB_CHANGE_TIME_GRP_TEMP';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);
INSERT INTO JOB_CHANGE_TIME_GRP_TEMP(
RESOURCE_ID, FROM_ROUTE_GRP_ID, TO_ROUTE_GRP_ID, JC_GRP_ID, ROUTE_GRP_TYPE, JC_CAPACITY, JC_TIME, TIME_UOM, ENGINE_ID, OCCUPIED_CAPACITY
)
SELECT RESOURCE_ID, FROM_ROUTE_GRP_ID, TO_ROUTE_GRP_ID, JC_GRP_ID, ROUTE_GRP_TYPE, JC_CAPACITY, JC_TIME, TIME_UOM, ENGINE_ID, OCCUPIED_CAPACITY 
FROM JOB_CHANGE_TIME_GRP X
WHERE ENGINE_ID = P_tPLAN_OPTION.ENGINE_ID
; 
PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);

INSERT INTO JC_DYNAMIC_TYPE
SELECT P_tPLAN_OPTION.ENGINE_ID   AS ENGINE_ID  --   
      ,CE1.ITEM_CD   AS FROM_ITEM_CD
      ,CE2.ITEM_CD   AS TO_ITEM_CD
      ,JCE.CELL_CD_1 || '_' || JCE.CELL_CD_2 AS JC_TYPE_CD
      ,JCE.CELL_CD_1     AS FROM_CELL_CD
      ,JCE.CELL_CD_2     AS TO_CELL_CD
      ,JCE.RATE_APPLY_YN AS RATE_APPLY_YN
      ,JCE.JC_TIME * DECODE(JCE.JC_TIME_UOM, 'DAY', 24, 'WEEK', 24*7) * 60 AS JC_CAPACITY  
      ,JCE.JC_TIME       
      ,JCE.JC_TIME_UOM        
FROM   TB_SMP_JOB_CHANGE_EXCEPTION JCE
      ,TB_SMP_CELL_MST             CE1
      ,TB_SMP_CELL_MST             CE2
WHERE  JCE.CELL_CD_1  = CE1.CELL_CD
AND    JCE.CELL_CD_2  = CE2.CELL_CD
UNION ALL
SELECT P_tPLAN_OPTION.ENGINE_ID   AS ENGINE_ID    
      ,CE2.ITEM_CD   AS FROM_ITEM_CD
      ,CE1.ITEM_CD   AS TO_ITEM_CD
      ,JCE.CELL_CD_1 || '_' || JCE.CELL_CD_2 AS JC_TYPE_CD
      ,JCE.CELL_CD_2     AS FROM_CELL_CD
      ,JCE.CELL_CD_1     AS TO_CELL_CD
      ,JCE.RATE_APPLY_YN AS RATE_APPLY_YN
      ,JCE.JC_TIME * DECODE(JCE.JC_TIME_UOM, 'DAY', 24, 'WEEK', 24*7) * 60 AS JC_CAPACITY  
      ,JCE.JC_TIME       
      ,JCE.JC_TIME_UOM        
FROM   TB_SMP_JOB_CHANGE_EXCEPTION JCE
      ,TB_SMP_CELL_MST             CE1
      ,TB_SMP_CELL_MST             CE2
WHERE  JCE.CELL_CD_1  = CE1.CELL_CD
AND    JCE.CELL_CD_2  = CE2.CELL_CD
;

--*[V2 AIS]**************************************************************************************  

EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

--[AIS_TODO]
PROCEDURE SP_SET_BEL_PST (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_BEL_PST
* Purpose : 전극라인 PST
* Notes   : 전극 라인의 소요 Capa.는 별도 Outbound에서 처리함에 따라 해당 프로시저는 필요없음. 나중에 삭제할것 -[AIS_TOD]                                                     
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-03-20 AIS Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_BEL_PST';

  --* ROUTE PST- ---------------------------------------------------------------------------------------
  G_sSTEP_SEQ  := '1.0';   
  G_sSTEP_DESC := 'Set Elec. Route PST';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);
  /* BEL 공정만 PST 부여
  INSERT INTO SO_ROUTE_PST (ENGINE_ID, SALESORDER_ID, ROUTE_ID, RESOURCE_ID, PST) 
  SELECT DISTINCT
         P_tPLAN_OPTION.ENGINE_ID
        ,SWD.DEMAND_ID     SALESORDER_ID 
        ,BOM.ROUTE_ID      ROUTE_ID
        ,BOR.LINE_CD       RESOURCE_ID      
        ,GREATEST(  SWD.ELEC_ROUTE_PST
                  , TO_DATE(SLM.VALID_START_DATE, 'YYYYMMDD')  
                  , ADD_MONTHS(P_tPLAN_OPTION.START_DATE, NVL(SSM.MP_FIXED_MM_VAL,0)) --SITE별 PST(확정구간이루로만 계획 수립을 위해)
                 )         PST 
    FROM TB_SMP_WK_DEMAND  SWD 
        ,TB_SMP_WK_BOM     BOM
        ,TB_SMP_WK_BOR     BOR
        ,TB_SMP_SITE_MST   SSM
        ,TB_SMP_LINE_MST   SLM
   WHERE SWD.VERSION_ID    = P_tPLAN_OPTION.VERSION_ID
     AND SWD.USE_FLAG      = 'Y'
     AND SWD.VERSION_ID    = BOM.VERSION_ID
     AND SWD.CELL_ITEM_CD  = BOM.REF_CELL_ITEM_CD 
     AND BOM.P_ROUTE_CD    = P_tPLAN_OPTION.ELEC_ROUTE_CD -- 'BEL'
     AND BOM.VERSION_ID    = BOR.VERSION_ID 
     AND BOM.ROUTE_ID      = BOR.ROUTE_ID 
     --AND SWD.PGM_STATUS_CD = 'C'--'수주확정'  
     AND BOM.SITE_CD       = SSM.SITE_CD   
     AND BOR.SITE_CD       = SLM.SITE_CD
     AND BOR.LINE_CD       = SLM.LINE_CD
  ;
  */
 
  --모든 전극 공정 PST 부여
/*  
  INSERT INTO SO_ROUTE_PST (ENGINE_ID, SALESORDER_ID, ROUTE_ID, RESOURCE_ID, PST)
  WITH W_BOM AS ( 
        SELECT VERSION_ID--LEVEL, CONNECT_BY_ISLEAF, SYS_CONNECT_BY_PATH(B.P_ITEM_CD, '*') 
              ,CONNECT_BY_ROOT  B.P_ITEM_CD AS CELL_ITEM_CD
              ,B.SITE_CD
              ,B.P_ITEM_CD
              ,B.P_ROUTE_CD
              ,B.ROUTE_ID
          FROM TB_SMP_WK_BOM    B
         WHERE 1=1 
           AND B.VERSION_ID     = P_tPLAN_OPTION.VERSION_ID
          AND EXISTS ( --전극 품목
                SELECT SIM.ITEM_CD
                  FROM TB_SMP_ITEM_MST       SIM 
                      ,TB_SMP_ITEM_BASE_INFO IBI
                      ,TB_CM_COMM_CONFIG     CCC
                      ,TB_CM_CONFIGURATION   CFG    
                 WHERE SIM.PN_CD             = IBI.PN_CD   
                   AND IBI.ATTR_01           = CCC.CONF_CD
                   AND CCC.CONF_GRP_CD       = 'ITEM_ELETRODE_GRP'
                   AND CCC.USE_YN            = 'Y'
                   AND CCC.CONF_ID           = CFG.ID
                   AND CFG.MODULE_CD         = 'SMP'
                   AND CFG.ACTV_YN           = 'Y'   
                   AND SIM.ITEM_CD           = B.P_ITEM_CD
               )          
        START WITH B.VERSION_ID = P_tPLAN_OPTION.VERSION_ID 
               AND B.P_ROUTE_CD = P_tPLAN_OPTION.ASSY_ROUTE_CD -- 'BAS' 이하 품목을 찾아 해당 공정 모두 PST부여
        CONNECT BY NOCYCLE B.P_ITEM_CD  = PRIOR B.C_ITEM_CD 
                       AND B.SITE_CD    = PRIOR B.SITE_CD
                       AND B.VERSION_ID = PRIOR B.VERSION_ID
  )
  SELECT DISTINCT
         P_tPLAN_OPTION.ENGINE_ID     AS ENGINE_ID
        ,SWD.DEMAND_ID                AS SALESORDER_ID 
        ,BOM.ROUTE_ID                 AS ROUTE_ID
        ,NVL(BOR.LINE_CD, '{$ALL}')   AS RESOURCE_ID      
        ,GREATEST(  SWD.ELEC_ROUTE_PST
                  , TO_DATE(NVL(SLM.VALID_START_DATE, '19990101'), 'YYYYMMDD')  
                  -- 조립 확정구간 안으로 전극 계획 수립되도록 처리함
                  --, ADD_MONTHS(P_tPLAN_OPTION.START_DATE, NVL(SSM.MP_FIXED_MM_VAL,0)) --SITE별 PST(확정구간이루로만 계획 수립을 위해) 
                 )         PST 
    FROM TB_SMP_WK_DEMAND  SWD 
        ,W_BOM             BOM
        ,TB_SMP_WK_BOR     BOR
        ,TB_SMP_SITE_MST   SSM
        ,TB_SMP_LINE_MST   SLM
   WHERE SWD.VERSION_ID    = P_tPLAN_OPTION.VERSION_ID
     AND SWD.USE_FLAG      = 'Y'
     AND SWD.VERSION_ID    = BOM.VERSION_ID
     AND SWD.CELL_ITEM_CD  = BOM.CELL_ITEM_CD 
     AND BOM.VERSION_ID    = BOR.VERSION_ID (+)
     AND BOM.ROUTE_ID      = BOR.ROUTE_ID   (+)
     AND BOM.SITE_CD       = SSM.SITE_CD   
     AND BOR.SITE_CD       = SLM.SITE_CD    (+)
     AND BOR.LINE_CD       = SLM.LINE_CD    (+)
     ; 
*/
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

PROCEDURE SP_SET_STOCK_CAPA (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_STOCK_CAPA
* Purpose : .
* Notes   : Raw Mat. Vendor Capa. -> Stock
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-03-30 AIS Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S'; 
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_STOCK_CAPA';

  --* Stock LOG------------------------------------------------------------------------------------------  
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Set Stock Capa';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO STOCK(ENGINE_ID, STOCK_ID, INVENTORY_ID, RECEIPT_DATE, USABLE_DATE, EXPIRE_DATE, QTY, USABLE, SITE_CD)
  SELECT P_tPLAN_OPTION.ENGINE_ID                      AS ENGINE_ID
        ,'ST_CAPA_' || LPAD(ROWNUM, 10, '0')           AS STOCK_ID
        ,ITEM_CD || '@' || SITE_CD                     AS INVENTORY_ID
        ,TO_DATE(PLAN_MONTH, 'YYYYMM')                 AS RECEIPT_DATE
        ,TO_DATE(PLAN_MONTH, 'YYYYMM')                 AS USABLE_DATE
        --[4/7]
        ,NULL                                          AS EXPIRE_DATE
        --,ADD_MONTHS(TO_DATE(PLAN_MONTH, 'YYYYMM'), 6)  AS EXPIRE_DATE 
        ,CAPA_QTY                                      AS QTY
        ,'Y'                                           AS USABLE
        ,SITE_CD
    FROM TB_SMP_RS_RM_CONSUME_V RCV
   WHERE RCV.VERSION_ID         = P_tPLAN_OPTION.REF_VERSION_ID 
     AND RCV.PLAN_MONTH        >= P_tPLAN_OPTION.BASE_MONTH
     AND RCV.CAPA_QTY           > 0
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_SITE_MST SSM
          WHERE SSM.SITE_CD     = RCV.SITE_CD
         )
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT); 
  ------------------------------------------------------------------------------------------------------  
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

PROCEDURE SP_SET_DYNAMIC_RATE (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_DYNAMIC_RATE
* Purpose : .
* Notes   :  
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-04-20 AIS Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S'; 
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_DYNAMIC_RATE';

  --*---------------------------------------------------------------------------------------------------  
  IF NVL(P_tPLAN_OPTION.USED_DYNAMIC_RATE_YN, 'N') = 'N' THEN
    G_sSTEP_SEQ := '1.0';   
    G_sSTEP_DESC := 'Set Default Dynamic rate';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
    INSERT INTO JC_DYNAMIC_VALUE(ENGINE_ID, JC_DYNAMIC_RATE_ID, JC_DYNAMIC_VALUE_ID, BUCKET_TYPE, JC_TYPE, START_BUCKET, END_BUCKET, DYNAMIC_RATE
                                       ,OPERATING_RATIO, ROUTE_TOTAL_RATE, ROUTE_FM_RATE, ROUTE_AS_RATE, ROUTE_EL_RATE)
    SELECT P_tPLAN_OPTION.ENGINE_ID AS ENGINE_ID
          ,SSM.SITE_CD || '-' || SRC.BUCKET_TYPE || '-' || SRC.JC_TYPE || '-' || SRC.START_BUCKET || '-' || SRC.END_BUCKET AS JC_DYNAMCI_RATE_ID
          ,SSM.SITE_CD      AS JC_DYNAMIC_VALUE_ID
          ,SRC.BUCKET_TYPE  AS BUCKET_TYPE
          ,SRC.JC_TYPE      AS JC_TYPE
          ,SRC.START_BUCKET AS START_BUCKET
          ,SRC.END_BUCKET   AS END_BUCKET
          ,SRC.DYNAMIC_RATE AS DYNAMIC_RATE
          ,1                AS OPERATING_RATIO
          ,1                AS ROUTE_TOTAL_RATE
          ,1                AS ROUTE_FM_RATE
          ,1                AS ROUTE_AS_RATE
          ,1                AS ROUTE_EL_RATE                
      FROM (
            SELECT 'DAY'   BUCKET_TYPE, 'F' JC_TYPE, 1 START_BUCKET,366 END_BUCKET, 1 DYNAMIC_RATE FROM DUAL UNION ALL
            SELECT 'DAY'   BUCKET_TYPE, 'S' JC_TYPE, 1 START_BUCKET,366 END_BUCKET, 1 DYNAMIC_RATE FROM DUAL UNION ALL
            SELECT 'MONTH' BUCKET_TYPE, 'F' JC_TYPE, 1 START_BUCKET,37  END_BUCKET, 1 DYNAMIC_RATE FROM DUAL UNION ALL
            SELECT 'MONTH' BUCKET_TYPE, 'S' JC_TYPE, 1 START_BUCKET,37  END_BUCKET, 1 DYNAMIC_RATE FROM DUAL UNION ALL
            SELECT 'YEAR'  BUCKET_TYPE, 'F' JC_TYPE, 1 START_BUCKET,73  END_BUCKET, 1 DYNAMIC_RATE FROM DUAL UNION ALL
            SELECT 'YEAR'  BUCKET_TYPE, 'S' JC_TYPE, 1 START_BUCKET,73  END_BUCKET, 1 DYNAMIC_RATE FROM DUAL
           ) SRC
          ,TB_SMP_SITE_MST SSM
     WHERE SSM.USE_YN = 'Y'
    ;
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);   
  ELSE
    --*[V2 AIS]**************************************************************************************
    G_sSTEP_SEQ := '1.0';   
    G_sSTEP_DESC := 'Set Dynamic rate - NEW';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);   
    INSERT INTO JC_DYNAMIC_VALUE
    SELECT P_tPLAN_OPTION.ENGINE_ID AS ENGINE_ID
          ,TDR.LINE_CD || '-' || TDR.PLAN_YEAR || '-' || DRU.JC_TYPE_CD || '-' || DRU.RAMP_UP_SEQ || '-' ||DECODE(DRU.RAMP_UP_SEQ, 15, 500, DRU.RAMP_UP_SEQ + 1) AS JC_DYNAMIC_RATE_ID
          ,TDR.LINE_CD         AS JC_DYNAMIC_VALUE_ID
          ,TDR.PLAN_YEAR       AS BUCKET_TYPE
          ,DRU.JC_TYPE_CD      AS JC_TYPE
          ,DRU.RAMP_UP_SEQ     AS START_BUCKET
          ,DECODE(DRU.RAMP_UP_SEQ, 15, 500, DRU.RAMP_UP_SEQ + 1) AS END_BUCKET 
          ,(TDR.UTIL_RATE - DRU.UTIL_RATE)/100 * (TDR.F_YIELD - DRU.F_YIELD)/100 AS DYNAMIC_RATE
          ,(TDR.UTIL_RATE - DRU.UTIL_RATE)/100 AS OPERATING_RATIO
          ,0 ROUTE_TOTAL_RATE
          ,(TDR.F_YIELD - DRU.F_YIELD)/100 AS ROUTE_FM_RATE
          ,(TDR.A_YIELD - DRU.A_YIELD)/100 AS ROUTE_AS_RATE
          ,(TDR.E_YIELD - DRU.E_YIELD)/100 AS ROUTE_EL_RATE
          --,TDR.SITE_CD
          --,DRU.*
    FROM   TB_SMP_TARGET_DYNAMIC_RATE TDR
          ,TB_SMP_DYNAMIC_RAMP_UP     DRU
    WHERE  TDR.SITE_CD    = DRU.SITE_CD  
    ;
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);  
    --*[V2 AIS]************************************************************************************** 
  
  
    /*
    G_sSTEP_SEQ := '1.0';   
    G_sSTEP_DESC := 'Set Dynamic rate - Day(1-30)';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
    --DAY   
    INSERT INTO JC_DYNAMIC_VALUE(ENGINE_ID, JC_DYNAMIC_RATE_ID, JC_DYNAMIC_VALUE_ID, BUCKET_TYPE, JC_TYPE, START_BUCKET, END_BUCKET, DYNAMIC_RATE
                                       ,OPERATING_RATIO, ROUTE_TOTAL_RATE, ROUTE_FM_RATE, ROUTE_AS_RATE, ROUTE_EL_RATE)
    SELECT P_tPLAN_OPTION.ENGINE_ID AS ENGINE_ID
          ,SITE_CD || '-DAY-' || JC_TYPE_CD || '-' || TO_CHAR(SEQ) || '-' || TO_CHAR(SEQ+1) AS DYNAMIC_RATE_ID
          ,SITE_CD                         AS DYNAMIC_VALUE_ID
          ,'DAY'                           AS BUCKET_TYPE
          ,JC_TYPE_CD                      AS JC_TYPE
          ,SEQ                             AS START_BUCKET
          ,SEQ+1                           AS END_BUCKET
          ,D.T_YIELD * D.UTIL_RATE / 10000 AS DYNAMIC_RATE
          ,D.UTIL_RATE                     AS OPERATING_RATIO
          ,D.T_YIELD                       AS ROUTE_TOTAL_RATE
          ,D.F_YIELD                       AS ROUTE_FM_RATE
          ,D.A_YIELD                       AS ROUTE_AS_RATE
          ,D.E_YIELD                       AS ROUTE_EL_RATE       
      FROM TB_SMP_ASSY_DYNAMIC_YIELD D 
     WHERE D.BASE_MONTH LIKE 'D%'
    ;
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);  

    G_sSTEP_SEQ := '2.0';   
    G_sSTEP_DESC := 'Set Dynamic rate - Day(31-90)';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
    INSERT INTO JC_DYNAMIC_VALUE(ENGINE_ID, JC_DYNAMIC_RATE_ID, JC_DYNAMIC_VALUE_ID, BUCKET_TYPE, JC_TYPE, START_BUCKET, END_BUCKET, DYNAMIC_RATE
                                       ,OPERATING_RATIO, ROUTE_TOTAL_RATE, ROUTE_FM_RATE, ROUTE_AS_RATE, ROUTE_EL_RATE)  
    SELECT P_tPLAN_OPTION.ENGINE_ID AS ENGINE_ID
          ,CASE WHEN D.BASE_MONTH = 'M01' THEN SITE_CD || '-DAY-' || JC_TYPE_CD || '-' || TO_CHAR(31) || '-' || TO_CHAR(61) 
                WHEN D.BASE_MONTH = 'M02' THEN SITE_CD || '-DAY-' || JC_TYPE_CD || '-' || TO_CHAR(61) || '-' || TO_CHAR(91)
           END                             AS DYNAMIC_RATE_ID
          ,SITE_CD                         AS DYNAMIC_VALUE_ID
          ,'DAY'                           AS BUCKET_TYPE
          ,JC_TYPE_CD                      AS JC_TYPE
          ,CASE WHEN D.BASE_MONTH = 'M01' THEN 31 
                WHEN D.BASE_MONTH = 'M02' THEN 61
           END                             AS START_BUCKET
          ,CASE WHEN D.BASE_MONTH = 'M01' THEN 61 
                WHEN D.BASE_MONTH = 'M02' THEN 91
           END                             AS END_BUCKET       
          ,D.T_YIELD * D.UTIL_RATE / 10000 AS DYNAMIC_RATE
          ,D.UTIL_RATE                     AS OPERATING_RATIO
          ,D.T_YIELD                       AS ROUTE_TOTAL_RATE
          ,D.F_YIELD                       AS ROUTE_FM_RATE
          ,D.A_YIELD                       AS ROUTE_AS_RATE
          ,D.E_YIELD                       AS ROUTE_EL_RATE      
      FROM TB_SMP_ASSY_DYNAMIC_YIELD D 
     WHERE D.BASE_MONTH LIKE 'M%'
    ;
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);      

    G_sSTEP_SEQ := '3.0';   
    G_sSTEP_DESC := 'Set Dynamic rate - Month';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);   
    INSERT INTO JC_DYNAMIC_VALUE(ENGINE_ID, JC_DYNAMIC_RATE_ID, JC_DYNAMIC_VALUE_ID, BUCKET_TYPE, JC_TYPE, START_BUCKET, END_BUCKET, DYNAMIC_RATE
                                       ,OPERATING_RATIO, ROUTE_TOTAL_RATE, ROUTE_FM_RATE, ROUTE_AS_RATE, ROUTE_EL_RATE)    
    SELECT P_tPLAN_OPTION.ENGINE_ID AS ENGINE_ID
          ,CASE WHEN D.BASE_MONTH = 'M01' THEN SITE_CD || '-MONTH-' || JC_TYPE_CD || '-' || TO_CHAR(1) || '-' || TO_CHAR(2) 
                WHEN D.BASE_MONTH = 'M02' THEN SITE_CD || '-MONTH-' || JC_TYPE_CD || '-' || TO_CHAR(2) || '-' || TO_CHAR(37)
           END                             AS DYNAMIC_RATE_ID
          ,SITE_CD                         AS DYNAMIC_VALUE_ID
          ,'MONTH'                         AS BUCKET_TYPE
          ,JC_TYPE_CD                      AS JC_TYPE
          ,CASE WHEN D.BASE_MONTH = 'M01' THEN 1 
                WHEN D.BASE_MONTH = 'M02' THEN 2
           END                             AS START_BUCKET
          ,CASE WHEN D.BASE_MONTH = 'M01' THEN 2 
                WHEN D.BASE_MONTH = 'M02' THEN 37
           END                             AS END_BUCKET       
          ,D.T_YIELD * D.UTIL_RATE / 10000 AS DYNAMIC_RATE
          ,D.UTIL_RATE                     AS OPERATING_RATIO
          ,D.T_YIELD                       AS ROUTE_TOTAL_RATE
          ,D.F_YIELD                       AS ROUTE_FM_RATE
          ,D.A_YIELD                       AS ROUTE_AS_RATE
          ,D.E_YIELD                       AS ROUTE_EL_RATE       
      FROM TB_SMP_ASSY_DYNAMIC_YIELD D 
     WHERE D.BASE_MONTH LIKE 'M%'
    ;
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);      

    G_sSTEP_SEQ := '4.0';   
    G_sSTEP_DESC := 'Set Dynamic rate - Year';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);   
    INSERT INTO JC_DYNAMIC_VALUE(ENGINE_ID, JC_DYNAMIC_RATE_ID, JC_DYNAMIC_VALUE_ID, BUCKET_TYPE, JC_TYPE, START_BUCKET, END_BUCKET, DYNAMIC_RATE
                                       ,OPERATING_RATIO, ROUTE_TOTAL_RATE, ROUTE_FM_RATE, ROUTE_AS_RATE, ROUTE_EL_RATE)    
    SELECT P_tPLAN_OPTION.ENGINE_ID AS ENGINE_ID
          ,SITE_CD || '-YEAR-' || JC_TYPE_CD || '-' || TO_CHAR(1) || '-' || TO_CHAR(73)  AS DYNAMIC_RATE_ID
          ,SITE_CD                         AS DYNAMIC_VALUE_ID
          ,'YEAR'                          AS BUCKET_TYPE
          ,JC_TYPE_CD                      AS JC_TYPE
          ,1                               AS START_BUCKET
          ,73                              AS END_BUCKET       
          ,D.T_YIELD * D.UTIL_RATE / 10000 AS DYNAMIC_RATE
          ,D.UTIL_RATE                     AS OPERATING_RATIO
          ,D.T_YIELD                       AS ROUTE_TOTAL_RATE
          ,D.F_YIELD                       AS ROUTE_FM_RATE
          ,D.A_YIELD                       AS ROUTE_AS_RATE
          ,D.E_YIELD                       AS ROUTE_EL_RATE      
      FROM TB_SMP_ASSY_DYNAMIC_YIELD D 
     WHERE D.BASE_MONTH = 'M02'
    ;
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);   
    */  
  END IF;
  ------------------------------------------------------------------------------------------------------  
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

END PKG_SMP_I_CONSTRAINT;
/

