create PROCEDURE                 SP_SMP_EXE_VALIDATION(
 P_sUSER_ID        IN     VARCHAR2
,P_sVERSION_ID     IN     VARCHAR2 := NULL
,O_FLAG            OUT    VARCHAR2
)  
IS
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved. 
**************************************************************************
* Name    : SP_SMP_EXE_VALIDATION
* Purpose : MP Validation Procedure.
* Notes   :
* 
**************************************************************************
* History : 
* 2020-04-09 JMS Created
**************************************************************************/
  USER_EXCEPTION  EXCEPTION;

  G_nLOG_SEQ      NUMBER;
  G_sPROGRAMN_ID  NVARCHAR2(50) := 'SP_SMP_EXE_VALIDATION'; --:= DBMS_UTILITY.FORMAT_CALL_STACK;
  G_sSTEP_SEQ     NVARCHAR2(50);
  G_sSTEP_DESC    NVARCHAR2(2000);
  G_sVERSION_ID   NVARCHAR2(50) := P_sVERSION_ID;
  G_sENGINE_ID    NVARCHAR2(50);
  G_sUSER_ID      NVARCHAR2(50) := P_sUSER_ID;
  G_nSQL_CNT      NUMBER;
  G_sLOGMSG       VARCHAR2(4000);

  P_sQRY            VARCHAR2(1000);

  /*Exception Local Procedure*/
  PROCEDURE RAISE_EXCEPTION(sFLAG VARCHAR2, sMSG VARCHAR2)
  IS 
  BEGIN
    IF sFLAG = 'F' THEN
      G_sLOGMSG := sMSG;
      RAISE USER_EXCEPTION; 
    END IF;
  END;
 
BEGIN 
  
  O_FLAG := 'C'; -- 문제없이 성공시 Out Flag
  
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Set Variables..';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
      IF P_sVERSION_ID IS NOT NULL THEN
      
          SELECT VERSION_ID
            INTO G_sVERSION_ID
            FROM TB_SMP_VER_MST
           WHERE 1=1 --STATUS_CD NOT IN ('E', 'C')
             AND VERSION_ID = P_sVERSION_ID
          ;
    
      END IF;
  
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Truncate Data : Validation';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
      P_sQRY := 'TRUNCATE TABLE TB_SMP_DATA_VALIDATION';      
      EXECUTE IMMEDIATE P_sQRY;
    
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
  G_sSTEP_SEQ := '3.0';   
  G_sSTEP_DESC := 'Validation : 소재정보 없는 Item List';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
      INSERT INTO TB_SMP_DATA_VALIDATION
      ( VALID_TYPE_CD, VALID_TYPE_SEQ, VALID_TYPE_NM, DESCRIPTION
      , ITEM_CD, ITEM_NM, LINE_CD, CELL_CD, PGM_D_CD, PGM_D_NM, PLAN_MONTH
      , VERSION_ID, REG_DTTM, REG_USER_ID
      )
      SELECT VALID_CD, VALID_SEQ, VALID_NM , DESCRIPTION
           , ITEM_CD, ITEM_NM, LINE_CD, CELL_CD, PGM_D_CD, PGM_D_NM, PLAN_MONTH
           , G_sVERSION_ID AS VERSION_ID -- 변수처리 필요
           , SYSDATE
           , G_sUSER_ID AS USER_ID -- 변수처리 필요
        FROM (--* 1. [ITEM] 소재정보 없는 item list
              SELECT 'VALID_01' AS VALID_CD, LPAD(ROWNUM, 3, '0') AS VALID_SEQ, 'ITEM' AS VALID_NM , '소재정보 없는 ITEM LIST' DESCRIPTION
                   , SIM.ITEM_CD, SIM.ITEM_NM
                   , NULL AS LINE_CD
                   , NULL AS CELL_CD
                   , NULL AS PGM_D_CD, NULL AS PGM_D_NM, NULL AS PLAN_MONTH
                FROM TB_SMP_ITEM_MST SIM
               WHERE NOT EXISTS (
                                 SELECT 1
                                   FROM TB_SMP_ITEM_BASE_INFO IBI
                                  WHERE IBI.PN_CD = SIM.PN_CD
                                )
             ) VAL
      ;
  
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
 
  COMMIT;
  
  G_sSTEP_SEQ := '4.0';   
  G_sSTEP_DESC := 'Validation : [ITEM] M/E BOM 있는데 ITEM LIST없는 LIST ';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
      INSERT INTO TB_SMP_DATA_VALIDATION
      ( VALID_TYPE_CD, VALID_TYPE_SEQ, VALID_TYPE_NM, DESCRIPTION
      , ITEM_CD, ITEM_NM, LINE_CD, CELL_CD, PGM_D_CD, PGM_D_NM, PLAN_MONTH
      , VERSION_ID, REG_DTTM, REG_USER_ID 
      )
      SELECT VAL.VALID_CD, VAL.VALID_SEQ, VAL.VALID_NM , VAL.DESCRIPTION
           , VAL.ITEM_CD, VAL.ITEM_NM, VAL.LINE_CD, VAL.CELL_CD, VAL.PGM_D_CD, VAL.PGM_D_NM, VAL.PLAN_MONTH
           , G_sVERSION_ID AS VERSION_ID -- 변수처리 필요
           , SYSDATE
           , G_sUSER_ID AS USER_ID -- 변수처리 필요
        FROM (--* 1. [ITEM] M/E BOM 있는데 ITEM LIST없는 LIST
              SELECT DISTINCT 'VALID_02' AS VALID_CD, LPAD(ROWNUM, 3, '0') AS VALID_SEQ, 'ITEM-BOM' AS VALID_NM , 'BOM 있는데 ITEM LIST없는 LIST' DESCRIPTION
                   , ITEM_CD, NULL AS ITEM_NM
                   , NULL AS LINE_CD
                   , NULL AS CELL_CD
                   , NULL AS PGM_D_CD, NULL AS PGM_D_NM, NULL AS PLAN_MONTH
                FROM (
                      SELECT BOM.P_ITEM_CD AS ITEM_CD
                        FROM TB_SMP_BOM BOM
                       WHERE NOT EXISTS (
                                         SELECT 1
                                           FROM TB_SMP_ITEM_MST SIM
                                          WHERE SIM.ITEM_CD = BOM.P_ITEM_CD
                                        )
                       UNION ALL 
                      SELECT BOM.C_ITEM_CD 
                        FROM TB_SMP_BOM BOM
                       WHERE NOT EXISTS (
                                         SELECT 1
                                           FROM TB_SMP_ITEM_MST SIM
                                          WHERE SIM.ITEM_CD = BOM.C_ITEM_CD
                                        )
                     )   
             ) VAL
      ;
   
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
 
  COMMIT;

  G_sSTEP_SEQ := '5.0';   
  G_sSTEP_DESC := 'Validation : [조립라인인증] 조립 LINE중 인증일자가 있는데 PPM이 없는 조립 LINE LIST ';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
      INSERT INTO TB_SMP_DATA_VALIDATION
      ( VALID_TYPE_CD, VALID_TYPE_SEQ, VALID_TYPE_NM, DESCRIPTION
      , ITEM_CD, ITEM_NM, LINE_CD, CELL_CD, PGM_D_CD, PGM_D_NM, PLAN_MONTH
      , VERSION_ID, REG_DTTM, REG_USER_ID 
      )
      SELECT VAL.VALID_CD, VAL.VALID_SEQ, VAL.VALID_NM , VAL.DESCRIPTION
           , VAL.ITEM_CD, VAL.ITEM_NM, VAL.LINE_CD, VAL.CELL_CD, VAL.PGM_D_CD, VAL.PGM_D_NM, VAL.PLAN_MONTH
           , G_sVERSION_ID AS VERSION_ID -- 변수처리 필요
           , SYSDATE
           , G_sUSER_ID AS USER_ID -- 변수처리 필요
        FROM (--* 2. [조립라인인증] 조립 LINE중 인증일자가 있는데 PPM이 없는 조립 LINE LIST
              SELECT 'VALID_03' AS VALID_CD, LPAD(ROWNUM, 3, '0') AS VALID_SEQ, '조립 인증' AS VALID_NM , '조립 LINE 중 인증일자가 있는데 PPM 이 없는 조립 LINE LIST' DESCRIPTION
                   , NULL AS ITEM_CD, NULL AS ITEM_NM
                   , SLM.LINE_CD AS LINE_CD
                   , ACM.CELL_CD AS CELL_CD
                   , NULL AS PGM_D_CD, NULL AS PGM_D_NM, NULL AS PLAN_MONTH
                FROM TB_SMP_LINE_MST      SLM
                   , TB_SMP_ASSY_CERF_MST ACM
               WHERE SLM.SITE_CD          = ACM.SITE_CD
                 AND SLM.LINE_CD          = ACM.LINE_CD
                 AND ACM.CERTIF_MONTH     IS NOT NULL
                 AND NVL(ACM.PPM_VAL, 0)  = 0
             ) VAL
      ;
   
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
 
  COMMIT;

  G_sSTEP_SEQ := '6.0';   
  G_sSTEP_DESC := 'Validation : 전극 LINE 중 코팅속도가 없는 전극 LINE LIST ';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
      INSERT INTO TB_SMP_DATA_VALIDATION
      ( VALID_TYPE_CD, VALID_TYPE_SEQ, VALID_TYPE_NM, DESCRIPTION
      , ITEM_CD, ITEM_NM, LINE_CD, CELL_CD, PGM_D_CD, PGM_D_NM, PLAN_MONTH
      , VERSION_ID, REG_DTTM, REG_USER_ID 
      )
      SELECT VAL.VALID_CD, VAL.VALID_SEQ, VAL.VALID_NM , VAL.DESCRIPTION
           , VAL.ITEM_CD, VAL.ITEM_NM, VAL.LINE_CD, VAL.CELL_CD, VAL.PGM_D_CD, VAL.PGM_D_NM, VAL.PLAN_MONTH
           , G_sVERSION_ID AS VERSION_ID -- 변수처리 필요
           , SYSDATE
           , G_sUSER_ID AS USER_ID -- 변수처리 필요
        FROM (--* 4. [전극라인 - 코팅속도] 전극 LINE중 코팅속도가 없는 전극 LINE LIST
              SELECT 'VALID_04' AS VALID_CD, LPAD(ROWNUM, 3, '0') AS VALID_SEQ, '전극라인-코팅속도' AS VALID_NM , '전극 LINE 중 코팅속도가 없는 전극 LINE LIST' DESCRIPTION
                   , NULL AS ITEM_CD, NULL AS ITEM_NM
                   , SLM.LINE_CD AS LINE_CD
                   , NULL AS CELL_CD
                   , NULL AS PGM_D_CD, NULL AS PGM_D_NM, NULL AS PLAN_MONTH
                FROM TB_SMP_LINE_MST SLM
               WHERE NVL(SLM.COT_SPEED_VAL, 0) = 0
                 --* 전극 라인
                 AND SLM.ROUTE_CD IN (
                                       SELECT ATTR_01
                                         FROM TB_CM_COMM_CONFIG   CCC
                                             ,TB_CM_CONFIGURATION CFG 
                                        WHERE CCC.CONF_ID         = CFG.ID
                                          AND CFG.MODULE_CD       = 'SMP'
                                          AND CFG.ACTV_YN         = 'Y'
                                          AND CCC.CONF_GRP_CD     = 'ITEM_ROUTE_MAP'
                                          AND CCC.CONF_CD         = 'ELECTRODE'
                                          AND CCC.USE_YN          = 'Y'
                                          AND CCC.ACTV_YN         = 'Y'
                                     )  
             ) VAL
      ;
   
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
 
  COMMIT;

  G_sSTEP_SEQ := '7.0';   
  G_sSTEP_DESC := 'Validation : [전극라인 - LANE] PGM 수주단위(혹은 전체 CELL대상?)의 CELL중 LANE수가 없는 CELL LIST ';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
      INSERT INTO TB_SMP_DATA_VALIDATION
      ( VALID_TYPE_CD, VALID_TYPE_SEQ, VALID_TYPE_NM, DESCRIPTION
      , ITEM_CD, ITEM_NM, LINE_CD, CELL_CD, PGM_D_CD, PGM_D_NM, PLAN_MONTH
      , VERSION_ID, REG_DTTM, REG_USER_ID 
      )
      SELECT VAL.VALID_CD, VAL.VALID_SEQ, VAL.VALID_NM , VAL.DESCRIPTION
           , VAL.ITEM_CD, VAL.ITEM_NM, VAL.LINE_CD, VAL.CELL_CD, VAL.PGM_D_CD, VAL.PGM_D_NM, VAL.PLAN_MONTH
           , G_sVERSION_ID AS VERSION_ID -- 변수처리 필요
           , SYSDATE
           , G_sUSER_ID AS USER_ID -- 변수처리 필요
        FROM (--* 5. [전극라인 - LANE] PGM 수주단위(혹은 전체 CELL대상?)의 CELL중 LANE수가 없는 CELL LIST
              SELECT 'VALID_05' AS VALID_CD, LPAD(ROWNUM, 3, '0') AS VALID_SEQ, '전극라인-LANE' AS VALID_NM , 'PGM 의 CELL 중 LANE 수가 없는 CELL LIST' DESCRIPTION
                   , NULL AS ITEM_CD, NULL AS ITEM_NM
                   , NULL AS LINE_CD 
                   , DPM.CELL_CD AS CELL_CD
                   , DPM.PGM_D_CD AS PGM_D_CD, DPM.PGM_D_NM AS PGM_D_NM
                   , NULL AS PLAN_MONTH
                   --SCM.ELEC_LANE_VAL
                FROM TB_SMP_DEMAND_PGM_MST    DPM
                    ,TB_SMP_CELL_MST          SCM
               WHERE DPM.CELL_CD              = SCM.CELL_CD  
                 AND NVL(SCM.ELEC_LANE_VAL, 0) = 0 
             ) VAL
      ;
   
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
 
  COMMIT;

  G_sSTEP_SEQ := '8.0';   
  G_sSTEP_DESC := 'Validation : [PGM - ERP CODE] PGM 수주단위의 완제품 ERP CODE가 없는 PGM LIST ';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
      INSERT INTO TB_SMP_DATA_VALIDATION
      ( VALID_TYPE_CD, VALID_TYPE_SEQ, VALID_TYPE_NM, DESCRIPTION
      , ITEM_CD, ITEM_NM, LINE_CD, CELL_CD, PGM_D_CD, PGM_D_NM, PLAN_MONTH
      , VERSION_ID, REG_DTTM, REG_USER_ID 
      )
      SELECT VAL.VALID_CD, VAL.VALID_SEQ, VAL.VALID_NM , VAL.DESCRIPTION
           , VAL.ITEM_CD, VAL.ITEM_NM, VAL.LINE_CD, VAL.CELL_CD, VAL.PGM_D_CD, VAL.PGM_D_NM, VAL.PLAN_MONTH
           , G_sVERSION_ID AS VERSION_ID -- 변수처리 필요
           , SYSDATE
           , G_sUSER_ID AS USER_ID -- 변수처리 필요
        FROM (--* 6. [PGM - ERP CODE] PGM 수주단위의 완제품 ERP CODE가 없는 PGM LIST
              SELECT 'VALID_06' AS VALID_CD, LPAD(ROWNUM, 3, '0') AS VALID_SEQ, 'PGM-ERP CODE' AS VALID_NM , 'PGM 의 완제품 ERP CODE 가 없는 PGM LIST' DESCRIPTION
                   , DPM.ITEM_CD AS ITEM_CD, NULL AS ITEM_NM
                   , NULL AS LINE_CD 
                   , DPM.CELL_CD AS CELL_CD
                   , DPM.PGM_D_CD AS PGM_D_CD, DPM.PGM_D_NM AS PGM_D_NM
                   , NULL AS PLAN_MONTH
                FROM TB_SMP_DEMAND_PGM_MST DPM
               WHERE DPM.ITEM_CD IS NULL
                 --* ITEM MAST에 없는 경우
                 OR  NOT EXISTS (
                                 SELECT 1
                                   FROM TB_SMP_ITEM_MST SIM
                                  WHERE SIM.ITEM_CD = DPM.ITEM_CD
                                )
             ) VAL
      ;
   
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
 
  COMMIT;

  G_sSTEP_SEQ := '9.0';   
  G_sSTEP_DESC := 'Validation : [PGM - 라인인증] PGM 수주단위의 CELL중 CELL LINE 인증정보 없는 PGM LIST ';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
      INSERT INTO TB_SMP_DATA_VALIDATION
      ( VALID_TYPE_CD, VALID_TYPE_SEQ, VALID_TYPE_NM, DESCRIPTION
      , ITEM_CD, ITEM_NM, LINE_CD, CELL_CD, PGM_D_CD, PGM_D_NM, PLAN_MONTH
      , VERSION_ID, REG_DTTM, REG_USER_ID 
      )
      SELECT VAL.VALID_CD, VAL.VALID_SEQ, VAL.VALID_NM , VAL.DESCRIPTION
           , VAL.ITEM_CD, VAL.ITEM_NM, VAL.LINE_CD, VAL.CELL_CD, VAL.PGM_D_CD, VAL.PGM_D_NM, VAL.PLAN_MONTH
           , G_sVERSION_ID AS VERSION_ID -- 변수처리 필요
           , SYSDATE
           , G_sUSER_ID AS USER_ID -- 변수처리 필요
        FROM (--* 8. [PGM - 라인인증] PGM 수주단위의 CELL중 CELL LINE 인증정보 없는 PGM LIST
              SELECT 'VALID_08' AS VALID_CD, LPAD(ROWNUM, 3, '0') AS VALID_SEQ, 'PGM-라인인증' AS VALID_NM , 'PGM의 CELL중 LINE 인증정보 없는 PGM LIST' DESCRIPTION
                   , DPM.ITEM_CD AS ITEM_CD, SIM.ITEM_NM AS ITEM_NM
                   , NULL AS LINE_CD 
                   , DPM.CELL_CD AS CELL_CD
                   , DPM.PGM_D_CD AS PGM_D_CD, DPM.PGM_D_NM AS PGM_D_NM
                   , NULL AS PLAN_MONTH
                FROM TB_SMP_DEMAND_PGM_MST  DPM
                   , TB_SMP_ITEM_MST SIM
               WHERE 1=1      
                 AND DPM.ITEM_CD  = SIM.ITEM_CD(+)
                 AND NOT EXISTS (
                                 SELECT 1
                                   FROM TB_SMP_ASSY_CERF_MST  ACM
                                  WHERE ACM.CELL_CD = DPM.CELL_CD
                                    AND ACM.CERTIF_MONTH IS NOT NULL
                                ) 
             ) VAL
      ;
   
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
 
  COMMIT;

  G_sSTEP_SEQ := '10.0';   
  G_sSTEP_DESC := 'Validation : [PGM - CELL CODE] PGM 수주단위중 CELL CODE가 CELL 마스터에 없는 경우 ';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
      INSERT INTO TB_SMP_DATA_VALIDATION
      ( VALID_TYPE_CD, VALID_TYPE_SEQ, VALID_TYPE_NM, DESCRIPTION
      , ITEM_CD, ITEM_NM, LINE_CD, CELL_CD, PGM_D_CD, PGM_D_NM, PLAN_MONTH
      , VERSION_ID, REG_DTTM, REG_USER_ID 
      )
      SELECT VAL.VALID_CD, VAL.VALID_SEQ, VAL.VALID_NM , VAL.DESCRIPTION
           , VAL.ITEM_CD, VAL.ITEM_NM, VAL.LINE_CD, VAL.CELL_CD, VAL.PGM_D_CD, VAL.PGM_D_NM, VAL.PLAN_MONTH
           , G_sVERSION_ID AS VERSION_ID -- 변수처리 필요
           , SYSDATE
           , G_sUSER_ID AS USER_ID -- 변수처리 필요
        FROM (--* 10 [PGM - CELL CODE] PGM 수주단위중 CELL CODE가 CELL 마스터에 없는 경우
              SELECT 'VALID_09' AS VALID_CD, LPAD(ROWNUM, 3, '0') AS VALID_SEQ, 'PGM- CELL CODE' AS VALID_NM , 'PGM 중 CELL CODE가 CELL 마스터에 없는 경우' DESCRIPTION
                   , NULL AS ITEM_CD, NULL AS ITEM_NM
                   , NULL AS LINE_CD 
                   , DPM.CELL_CD AS CELL_CD
                   , DPM.PGM_D_CD AS PGM_D_CD, DPM.PGM_D_NM AS PGM_D_NM
                   , NULL AS PLAN_MONTH
                FROM TB_SMP_DEMAND_PGM_MST    DPM
                    ,TB_SMP_CELL_MST          SCM
               WHERE DPM.CELL_CD              = SCM.CELL_CD(+)  
                 AND SCM.CELL_CD              IS NULL
             ) VAL
      ;
   
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
 
  COMMIT;

  G_sSTEP_SEQ := '11.0';   
  G_sSTEP_DESC := 'Validation : [판매계획 - PGM] 판매계획중 PGM 마스터 정보가 없는 경우 ';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
      INSERT INTO TB_SMP_DATA_VALIDATION
      ( VALID_TYPE_CD, VALID_TYPE_SEQ, VALID_TYPE_NM, DESCRIPTION
      , ITEM_CD, ITEM_NM, LINE_CD, CELL_CD, PGM_D_CD, PGM_D_NM, PLAN_MONTH
      , VERSION_ID, REG_DTTM, REG_USER_ID 
      )
      SELECT VAL.VALID_CD, VAL.VALID_SEQ, VAL.VALID_NM , VAL.DESCRIPTION
           , VAL.ITEM_CD, VAL.ITEM_NM, VAL.LINE_CD, VAL.CELL_CD, VAL.PGM_D_CD, VAL.PGM_D_NM, VAL.PLAN_MONTH
           , G_sVERSION_ID AS VERSION_ID -- 변수처리 필요
           , SYSDATE
           , G_sUSER_ID AS USER_ID -- 변수처리 필요
        FROM (--* 9. 판매계획 - PGM] 판매계획중 PGM 마스터 정보가 없는 경우
              SELECT DISTINCT 
                    'VALID_10' AS VALID_CD, LPAD(ROWNUM, 3, '0') AS VALID_SEQ, '판매계획-PGM' AS VALID_NM , '판매계획중 PGM 마스터 정보가 없는 경우' DESCRIPTION
                   , NULL AS ITEM_CD, NULL AS ITEM_NM
                   , NULL AS LINE_CD 
                   , DPM.CELL_CD AS CELL_CD
                   , DPM.PGM_D_CD AS PGM_D_CD, DPM.PGM_D_NM AS PGM_D_NM
                   , NULL AS PLAN_MONTH
                FROM TB_SMP_DEMAND_INFO SDI
                   , TB_SMP_DEMAND_PGM_MST DPM
               WHERE SDI.CUTOFF_DATE = (SELECT MAX(D.CUTOFF_DATE) FROM TB_SMP_DEMAND_INFO D)
                 AND SDI.PGM_D_CD = DPM.PGM_D_CD   
                 AND NOT EXISTS ( 
                                 SELECT 1
                                   FROM TB_SMP_DEMAND_PGM_MST DPM
                                  WHERE DPM.PGM_D_CD = SDI.PGM_D_CD
                                )
              
             ) VAL
      ;
   
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
 
  COMMIT;

  G_sSTEP_SEQ := '12.0';   
  G_sSTEP_DESC := 'Validation : [ITEM] M/E BOM 있는데 ITEM LIST없는 LIST ';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
      INSERT INTO TB_SMP_DATA_VALIDATION
      ( VALID_TYPE_CD, VALID_TYPE_SEQ, VALID_TYPE_NM, DESCRIPTION
      , ITEM_CD, ITEM_NM, LINE_CD, CELL_CD, PGM_D_CD, PGM_D_NM, PLAN_MONTH
      , VERSION_ID, REG_DTTM, REG_USER_ID 
      )
      SELECT VAL.VALID_CD, VAL.VALID_SEQ, VAL.VALID_NM , VAL.DESCRIPTION
           , VAL.ITEM_CD, VAL.ITEM_NM, VAL.LINE_CD, VAL.CELL_CD, VAL.PGM_D_CD, VAL.PGM_D_NM, VAL.PLAN_MONTH
           , G_sVERSION_ID AS VERSION_ID -- 변수처리 필요
           , SYSDATE
           , G_sUSER_ID AS USER_ID -- 변수처리 필요
        FROM (--* 3. [조립라인인증-PGM] 조립인증 정보가 미래구간이어서 인증이라 이전  DUE-DATE DEMAND에 대한 PGM LIST __________________
              SELECT DISTINCT  
                     'VALID_11' AS VALID_CD, LPAD(ROWNUM, 3, '0') AS VALID_SEQ, 'PGM-인증구간' AS VALID_NM , '조립인증 정보가 미래구간이고, 인증일 이전  DUE-DATE DEMAND에 대한 PGM LIST' DESCRIPTION
                   , NULL AS ITEM_CD, NULL AS ITEM_NM
                   , NULL AS LINE_CD 
                   , DPM.CELL_CD AS CELL_CD
                   , DPM.PGM_D_CD AS PGM_D_CD, DPM.PGM_D_NM AS PGM_D_NM
                   , SDI.BASE_MONTH AS PLAN_MONTH
                FROM TB_SMP_DEMAND_INFO    SDI
                   , TB_SMP_DEMAND_PGM_MST DPM
               WHERE SDI.CUTOFF_DATE       = (SELECT MAX(D.CUTOFF_DATE) FROM TB_SMP_DEMAND_INFO D)
                 AND NVL(SDI.QTY, 0)       > 0
                 AND SDI.PGM_D_CD          = DPM.PGM_D_CD   
                 AND EXISTS ( --인증정보는 존재
                             SELECT 1
                               FROM TB_SMP_ASSY_CERF_MST  ACM
                              WHERE ACM.CELL_CD           = DPM.CELL_CD
                                AND ACM.CERTIF_MONTH      IS NOT NULL
                            )
                 AND NOT EXISTS (
                                 SELECT 1
                                   FROM TB_SMP_ASSY_CERF_MST  ACM
                                  WHERE ACM.CELL_CD           = DPM.CELL_CD
                                    AND ACM.CERTIF_MONTH      IS NOT NULL
                                    AND ACM.CERTIF_MONTH     <= SDI.BASE_MONTH
                                ) 
             ) VAL
      ;
   
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
 
  COMMIT;

  G_sSTEP_SEQ := '13.0';   
  G_sSTEP_DESC := 'Validation : PGM의 완제품 ERP CODE 하위의 CELL 조립 BOM이 없는 품목 LIST ';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, G_sVERSION_ID, G_sUSER_ID);
  
      INSERT INTO TB_SMP_DATA_VALIDATION
      ( VALID_TYPE_CD, VALID_TYPE_SEQ, VALID_TYPE_NM, DESCRIPTION
      , ITEM_CD, ITEM_NM, LINE_CD, CELL_CD, PGM_D_CD, PGM_D_NM, PLAN_MONTH
      , VERSION_ID, REG_DTTM, REG_USER_ID 
      )
      WITH W_BOM
        AS (-- BOM을 전개함
            SELECT LEVEL, CONNECT_BY_ISLEAF, SYS_CONNECT_BY_PATH(BOM.P_ITEM_CD, '*') BOM_PATH
                  ,CONNECT_BY_ROOT  BOM.P_ITEM_CD AS TOP_ITEM_CD
                  ,BOM.SITE_CD
                  ,BOM.P_ITEM_CD
                  ,BOM.C_ITEM_CD                
              FROM TB_SMP_BOM    BOM
             WHERE 1=1
             START WITH BOM.P_ITEM_CD IN (SELECT DPM.ITEM_CD
                                            FROM TB_SMP_DEMAND_PGM_MST DPM)
            CONNECT BY NOCYCLE BOM.P_ITEM_CD  = PRIOR BOM.C_ITEM_CD 
                           AND BOM.SITE_CD    = PRIOR BOM.SITE_CD
           )
      SELECT 'VALID_07' AS VALID_CD, LPAD(ROWNUM, 3, '0') AS VALID_SEQ, 'PGM-BOM' AS VALID_NM , 'PGM의 완제품 ERP CODE 하위의 CELL 조립 BOM이 없는 품목 LIST' DESCRIPTION
           , SIM.ITEM_CD AS ITEM_CD, SIM.ITEM_NM AS ITEM_NM
           , NULL AS LINE_CD 
           , DPM.CELL_CD AS CELL_CD
           , DPM.PGM_D_CD AS PGM_D_CD, DPM.PGM_D_NM AS PGM_D_NM
           , NULL AS PLAN_MONTH
           , G_sVERSION_ID AS VERSION_ID -- 변수처리 필요
           , SYSDATE
           , G_sUSER_ID AS USER_ID -- 변수처리 필요
        FROM TB_SMP_DEMAND_PGM_MST DPM
           , TB_SMP_ITEM_MST       SIM
       WHERE DPM.ITEM_CD           = SIM.ITEM_CD
         AND NOT EXISTS (--전개된 BOM에서 조립품목 찾음.
                         SELECT 1
                           FROM W_BOM B
                          WHERE B.TOP_ITEM_CD = DPM.ITEM_CD
                            AND EXISTS (--조립 품목
                                        SELECT 1
                                          FROM TB_SMP_ITEM_MST       SIM 
                                              ,TB_SMP_ITEM_BASE_INFO IBI
                                              ,TB_CM_COMM_CONFIG     CCC
                                              ,TB_CM_CONFIGURATION   CFG    
                                         WHERE SIM.PN_CD             = IBI.PN_CD   
                                           AND IBI.ATTR_01           = CCC.ATTR_02
                                           AND CCC.CONF_GRP_CD       = 'ITEM_ROUTE_MAP'
                                           AND CCC.USE_YN            = 'Y'
                                           AND CCC.CONF_ID           = CFG.ID
                                           AND CFG.MODULE_CD         = 'SMP'
                                           AND CFG.ACTV_YN           = 'Y'   
                                           AND CCC.CONF_CD           = 'ASSY'
                                           AND SIM.ITEM_CD           = B.C_ITEM_CD
                                       )
                        )
      ;
   
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
 
  COMMIT;
        

EXCEPTION
  WHEN USER_EXCEPTION THEN
    ROLLBACK;
    O_FLAG    := 'F';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);
  WHEN OTHERS THEN
    ROLLBACK;
    O_FLAG := 'F';
    G_sLOGMSG   := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
    G_sLOGMSG   := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);
  
END;


/

