create PROCEDURE "SP_UI_DP_40_Q1" (
	  p_PLAN_TP_ID		VARCHAR2
	, p_BUCK			VARCHAR2
	, p_STRT_DATE		DATE
	, p_END_DATE		DATE
	, p_VER_ID_01		CHAR
	, p_VER_ID_02		CHAR
	, p_ITEM_CD			VARCHAR2
	, p_ACCT_CD			VARCHAR2
	, p_CURCY_CD_ID  	VARCHAR2
	, p_UNIT			VARCHAR2
	, p_USER_ID			VARCHAR2 := 'admin'
	, p_RT_MSG			OUT VARCHAR2
    , pRESULT           OUT SYS_REFCURSOR
)
IS

v_CL_LV_MGMT_ID			CHAR(32)		:='';
v_CL_LV_MGMT_ID_02		CHAR(32)		:='';
v_LAST_ITEM_LV         	INT;
v_ERR_MSG				VARCHAR2(4000)	:='';
v_ERR_STATUS			INT				:= NULL;
v_SEARCH_LV_SEQ			iNT				:= NULL;
v_SEARCH_LV_SEQ_02		INT				:= NULL; 
v_ITEM_CHECK			INT				:= NULL;
v_ACCT_CHECK			INT				:= NULL;
v_ITEM_LV_CHECK			INT				:= NULL;
v_ACCT_LV_CHECK			INT				:= NULL;  
v_YOY_VERSION_ID		CHAR(32)		:= NULL;
v_YOY_AUTH_TP_ID		CHAR(32)		:= NULL;
v_DIMENSION_01_ACTV_YN  CHAR(1)	;
v_DIMENSION_02_ACTV_YN  CHAR(1) ;
v_DIMENSION_03_ACTV_YN  CHAR(1) ;
v_DIMENSION_04_ACTV_YN  CHAR(1) ;
v_DIMENSION_05_ACTV_YN  CHAR(1) ;
v_DIMENSION_06_ACTV_YN  CHAR(1) ;
v_DIMENSION_07_ACTV_YN  CHAR(1) ;
v_DIMENSION_08_ACTV_YN  CHAR(1) ;
v_DIMENSION_09_ACTV_YN  CHAR(1) ;
v_DIMENSION_10_ACTV_YN  CHAR(1) ;
v_DIMENSION_11_ACTV_YN  CHAR(1) ;
v_DIMENSION_12_ACTV_YN  CHAR(1) ;
v_DIMENSION_13_ACTV_YN  CHAR(1) ;
v_DIMENSION_14_ACTV_YN  CHAR(1) ;
v_DIMENSION_15_ACTV_YN  CHAR(1) ;
v_DIMENSION_16_ACTV_YN  CHAR(1) ;
v_DIMENSION_17_ACTV_YN  CHAR(1) ;
v_DIMENSION_18_ACTV_YN  CHAR(1) ;
v_DIMENSION_19_ACTV_YN  CHAR(1) ;
v_DIMENSION_20_ACTV_YN  CHAR(1) ;
v_ITEM_YN               INT	:= 0;

v_STRT_DATE     DATE    := ''; --CONVERT(DATE,CONVERT(CHAR(10),DATEADD(D, -DAY(CONVERT(CHAR(10),p_STRT_DATE,23) - 1), CONVERT(CHAR(10),p_STRT_DATE,23)),23)) -- 입력한 날짜의 첫 날 구하기
v_END_DATE      DATE    := ''; --CONVERT(DATE,CONVERT(CHAR(10),DATEADD(MONTH, 1, CONVERT(CHAR(10),p_END_DATE,23)) - DAY(CONVERT(CHAR(10),p_END_DATE,23)),23)) -- 입력한 날짜의 마지막 날 구하기 
v_PLAN_TP_ID	VARCHAR2(100)  := '';
v_BUCK			VARCHAR2(100) := '';
v_VER_ID_01		CHAR(32) := '';
v_VER_ID_02		CHAR(32) := '';
v_ITEM_CD		VARCHAR2(4000) := '';
v_ACCT_CD		VARCHAR2(4000) := '';
v_CURCY_CD_ID  	VARCHAR2(200)  := '';
v_UNIT			VARCHAR2(200)  := '';

BEGIN

	v_STRT_DATE		:= ADD_MONTHS(LAST_DAY(p_STRT_DATE)+1,-1); -- CONVERT(CHAR(10),DATEADD(mm, DATEDIFF(mm,0,p_STRT_DATE), 0),23); -- 입력한 날짜의 첫 날 구하기
	v_END_DATE		:= LAST_DAY(p_END_DATE); -- CONVERT(CHAR(10),DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,p_END_DATE)+1,0)),23); -- 입력한 날짜의 마지막 날 구하기 
	v_PLAN_TP_ID	:= p_PLAN_TP_ID;
	v_BUCK			:= p_BUCK;
	v_VER_ID_01		:= p_VER_ID_01;
	v_VER_ID_02		:= p_VER_ID_02;
	v_ITEM_CD		:= p_ITEM_CD;
	v_ACCT_CD		:= p_ACCT_CD;
	v_CURCY_CD_ID	:= p_CURCY_CD_ID;
	v_UNIT			:= p_UNIT;

	SELECT CL_LV_MGMT_ID INTO v_CL_LV_MGMT_ID
      FROM TB_DP_CONTROL_BOARD_VER_DTL
	 WHERE CL_STATUS_ID = (
                        SELECT ID 
                          FROM TB_CM_COMM_CONFIG
                         WHERE CONF_CD  = 'CLOSE' 
                           AND CONF_GRP_CD = 'DP_CL_STATUS' --ID = '29DDA85D473247DB92FED4ECBE08329D'
                           )
	   AND WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_gRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
       AND CONBD_VER_MST_ID = v_VER_ID_01
  GROUP BY CL_LV_MGMT_ID
    ;

	SELECT CL_LV_MGMT_ID INTO v_CL_LV_MGMT_ID_02
      FROM TB_DP_CONTROL_BOARD_VER_DTL
	 WHERE CL_STATUS_ID IN (
                        SELECT ID 
                          FROM TB_CM_COMM_CONFIG
                        WHERE CONF_CD  = 'CLOSE' 
                          AND CONF_GRP_CD = 'DP_CL_STATUS' --ID = '29DDA85D473247DB92FED4ECBE08329D'
                    )
		AND WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_gRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
       AND CONBD_VER_MST_ID = v_VER_ID_02
     GROUP BY CL_LV_MGMT_ID
    ;

-- 가장 마지막에 CLOSE된 연간 계획 VERSION ID 와 CLOSE한 AUTH YPE 
--	SELECT TOP 1
--		  v_YOY_VERSION_ID =  A.ID  
--		 , v_YOY_AUTH_TP_ID =   B.CL_LV_MGMT_ID  
--	  FROM TB_DP_CONTROL_BOARD_VER_MST A 
--		   INNER JOIN
--		   TB_DP_CONTROL_BOARD_VER_DTL B
--	    ON ( A.ID = B.CONBD_VER_MST_ID )
--	 WHERE 1=1
--	   AND A.PLAN_TP_ID in (
--							SELECT ID
--							  FROM TB_CM_COMM_CONFIG
--							 WHERE 1=1
--							   AND CONF_GRP_CD =  'DP_PLAN_TYPE'
--							   AND ATTR_01 = 'Y'--'IVY'
--							)          
--	   AND B.CL_STATUS_ID IN (
--							SELECT ID 
--							  FROM TB_CM_COMM_CONFIG
--							 WHERE 1=1
--							   AND CONF_CD  = 'CLOSE' 
--							   AND CONF_GRP_CD = 'DP_CL_STATUS' --ID = '29DDA85D473247DB92FED4ECBE08329D'
--							)                    
--	   AND B.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_gRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
--	   AND CONVERT(CHAR(4),A.CREATE_DTTM,23) = CONVERT(CHAR(4),GETDATE(),23)-1    -- 작년 VERSION 중에 
--	ORDER BY A.CREATE_DTTM DESC
--	;
----------------------------------------------------------------------------------
    -- item level 혹은 ITEM CODE를 검색한다면 메시지 Validation
----------------------------------------------------------------------------------
    IF(COALESCE(v_ITEM_CD,'')!='')
    THEN
		-- ITEM_LV_CD, ITEM_CD Validation
		SELECT COUNT(*) INTO v_ITEM_CHECK
		  FROM TB_CM_ITEM_MST
		 WHERE 1=1 
           AND (REGEXP_LIKE(UPPER(ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                            OR v_ITEM_CD IS NULL
                      )
--		   AND ITEM_CD IN (
--                SELECT TRIM(REGEXP_SUBSTR(v_ITEM_CD, '[^|]+', 1, LEVEL)) AS ITEM_CD
--                    FROM DUAL
--                CONNECT BY INSTR(v_ITEM_CD, '|', 1, LEVEL - 1) > 0
--            )
		   AND COALESCE(DEL_YN,'N') = 'N'
		   AND COALESCE(DP_PLAN_YN,'') = 'Y'
		;
		SELECT v_ITEM_CHECK+COUNT(*) INTO v_ITEM_CHECK
		  FROM TB_CM_ITEM_MST
		 WHERE 1=1 
		   AND ITEM_CD LIKE '%'||v_ITEM_CD||'%'
		   AND COALESCE(DEL_YN,'N') = 'N'
		   AND COALESCE(DP_PLAN_YN,'') = 'Y'
		 ;

		SELECT COUNT(*) INTO v_ITEM_LV_CHECK
		  FROM TB_CM_ITEM_LEVEL_MGMT
		 WHERE 1=1 
		   AND ITEM_LV_CD = v_ITEM_CD
		   AND COALESCE(DEL_YN,'N') = 'N'   
		;

		IF(v_ITEM_CHECK !=0)    
        THEN    -- ITEM 최하위 레벨로 SEQ 넣어주기
             SELECT MAX(SEARCH_LV_SEQ)+1 INTO v_SEARCH_LV_SEQ
                FROM(   SELECT DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ
                          FROM TB_CM_ITEM_LEVEL_MGMT IL
                               INNER JOIN
                               TB_CM_LEVEL_MGMT LV
                            ON(IL.LV_MGMT_ID = LV.ID)
                         WHERE 1=1
                           AND COALESCE(IL.DEL_YN,'N') = 'N'
                           AND COALESCE(LV.DEL_YN,'N') = 'N'   
                )
            ;
        ELSIF(v_ITEM_LV_CHECK != 0) -- account level 레벨로 SEQ 넣어주기
        THEN
            SELECT SEARCH_LV_SEQ INTO v_SEARCH_LV_SEQ
            FROM(
                SELECT  IL.ITEM_LV_CD
                      , DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ
                  FROM TB_CM_ITEM_LEVEL_MGMT IL
                       INNER JOIN
                       TB_CM_LEVEL_MGMT LV
                    ON(IL.LV_MGMT_ID = LV.ID)
                 WHERE 1=1
                   AND COALESCE(IL.DEL_YN,'N') = 'N'
                   AND COALESCE(LV.DEL_YN,'N') = 'N'   
            )
            WHERE ITEM_LV_CD = v_ITEM_CD
            ;
		ELSE
            v_ERR_MSG := 'MSG_0020';     
            RAISE_APPLICATION_ERROR(-20001, v_ERR_MSG);
        END IF;
    END IF;

----------------------------------------------------------------------------------
-- ACCOUNT LEVEL 혹은 ACCOUNT CODE를 검색한다면 메시지 Validation
----------------------------------------------------------------------------------
	IF(COALESCE(v_ACCT_CD,'')='')
    THEN
        v_ERR_MSG := 'MSG_0015';     
        RAISE_APPLICATION_ERROR(-20001, v_ERR_MSG);
    END IF;

    -- ACCT_LV_CD, ACCT_CD Validation
    SELECT COUNT(*) INTO v_ACCT_CHECK
      FROM TB_DP_ACCOUNT_MST
     WHERE 1=1
       AND (REGEXP_LIKE(UPPER(ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                            OR v_ACCT_CD IS NULL
                      )
--	   AND ACCOUNT_CD IN (
--            SELECT TRIM(REGEXP_SUBSTR(v_ACCT_CD, '[^|]+', 1, LEVEL)) AS ACCT_CD
--                FROM DUAL
--            CONNECT BY INSTR(v_ACCT_CD, '|', 1, LEVEL - 1) > 0
--        )
       AND COALESCE(DEL_YN,'N') = 'N'
       AND COALESCE(ACTV_YN,'') = 'Y'
     ;
    SELECT v_ACCT_CHECK+COUNT(*) INTO v_ACCT_CHECK
      FROM TB_DP_ACCOUNT_MST
     WHERE 1=1
	   AND ACCOUNT_CD LIKE '%' || v_ACCT_CD || '%'
       AND COALESCE(DEL_YN,'N') = 'N'
       AND COALESCE(ACTV_YN,'') = 'Y'
     ;

    SELECT COUNT(*) INTO v_ACCT_LV_CHECK
      FROM TB_DP_SALES_LEVEL_MGMT
     WHERE 1=1
       AND SALES_LV_CD = v_ACCT_CD
       AND COALESCE(DEL_YN,'N') = 'N'   
    ;    
    IF(v_ACCT_CHECK != 0)    
    THEN    -- ACCOUNT 최하위 레벨로 SEQ 넣어주기
         SELECT MAX(SEARCH_LV_SEQ)+1 INTO v_SEARCH_LV_SEQ_02
            FROM(     SELECT DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ
                        FROM TB_DP_SALES_LEVEL_MGMT SL
                             INNER JOIN
                             TB_CM_LEVEL_MGMT LV
                         ON (SL.LV_MGMT_ID = LV.ID)
                      WHERE 1=1
                        AND COALESCE(SL.DEL_YN,'N') = 'N'
                        AND COALESCE(LV.DEL_YN,'N') = 'N'   
        )
        ;
    ELSIF(v_ACCT_LV_CHECK != 0) -- ACCOUNT LEVEL 레벨로 SEQ 넣어주기
    THEN
        SELECT SEARCH_LV_SEQ_02 INTO v_SEARCH_LV_SEQ_02
        FROM (
                SELECT SL.SALES_LV_CD
                     , DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ_02
                  FROM TB_DP_SALES_LEVEL_MGMT SL
                       INNER JOIN
                       TB_CM_LEVEL_MGMT LV
                    ON(SL.LV_MGMT_ID = LV.ID)
                 WHERE 1=1
                   AND COALESCE(SL.DEL_YN,'N') = 'N'
                   AND COALESCE(LV.DEL_YN,'N') = 'N'   
        )
       WHERE SALES_LV_CD = v_ACCT_CD
    ;
    ELSE 
        v_ERR_MSG := 'MSG_0020';
        RAISE_APPLICATION_ERROR(-20001, v_ERR_MSG);
    END IF;

	IF(v_ERR_STATUS = 0)
    THEN
        v_ERR_MSG := 'MSG_0020';     
        RAISE_APPLICATION_ERROR(-20001, v_ERR_MSG);
    END IF;

-- 최하단 ITEM LV 셋팅
    SELECT CAST(SUBSTR(MAX(A.FLD_CD), 11,2) AS INT ) INTO v_LAST_ITEM_LV
      FROM TB_AD_USER_PREF_DTL A 
     inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = 'UI_DP_40' and m.GRID_CD = 'RST_CPT_01' 
     inner join TB_AD_GROUP g on g.ID = A.GRP_ID 
     inner join TB_AD_USER u on u.USERNAME = p_USER_ID 
     inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
     LEFT OUTER JOIN TB_AD_USER_PREF B  ON	m.id = B.USER_PREF_MST_ID AND A.GRP_ID = B.GRP_ID	AND	A.FLD_CD = B.FLD_CD	AND B.USER_ID = u.ID					
     WHERE COALESCE(B.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N')) = 'Y' AND A.DIM_MEASURE_TP = 'DIMENSION'    AND SUBSTR(A.FLD_CD, 11,2) BETWEEN 1 AND 20 ;  

	SELECT MAX(CASE WHEN A.FLD_CD = 'DIMENSION_01' THEN A.ACTV_YN ELSE NULL END) 
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_02' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_03' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_04' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_05' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_06' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_07' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_08' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_09' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_10' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_11' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_12' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_13' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_14' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_15' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_16' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_17' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_18' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_19' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_20' THEN A.ACTV_YN ELSE NULL END)
           INTO
           v_DIMENSION_01_ACTV_YN
         , v_DIMENSION_02_ACTV_YN
         , v_DIMENSION_03_ACTV_YN
         , v_DIMENSION_04_ACTV_YN
         , v_DIMENSION_05_ACTV_YN
         , v_DIMENSION_06_ACTV_YN
         , v_DIMENSION_07_ACTV_YN
         , v_DIMENSION_08_ACTV_YN
         , v_DIMENSION_09_ACTV_YN
         , v_DIMENSION_10_ACTV_YN
         , v_DIMENSION_11_ACTV_YN
         , v_DIMENSION_12_ACTV_YN
         , v_DIMENSION_13_ACTV_YN
         , v_DIMENSION_14_ACTV_YN
         , v_DIMENSION_15_ACTV_YN
         , v_DIMENSION_16_ACTV_YN
         , v_DIMENSION_17_ACTV_YN
         , v_DIMENSION_18_ACTV_YN
         , v_DIMENSION_19_ACTV_YN
         , v_DIMENSION_20_ACTV_YN
	FROM ( 
			SELECT	 m.VIEW_CD
					,m.GRID_CD
					,g.GRP_CD
					,A.FLD_CD
					,A.REFER_VALUE
					,A.FLD_APPLY_CD
					,A.DIM_MEASURE_TP
					,A.CROSSTAB_ITEM_CD
					,A.FLD_SEQ AS SEQ_1, B.FLD_SEQ AS SEQ_2
					, COALESCE(B.DATA_KEY_YN,COALESCE(A.DATA_KEY_YN,'N'))  AS DATA_KEY_YN 
					, COALESCE(B.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N'))			 AS ACTV_YN 
					, ROW_NUMBER() OVER( ORDER BY A.FLD_CD)   AS ROW_NUM 
			FROM	TB_AD_USER_PREF_DTL A 
					inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = 'UI_DP_40'  AND m.GRID_CD	= 'RST_CPT_01'
					inner join TB_AD_GROUP g on g.ID = A.GRP_ID 
					inner join TB_AD_USER u on u.USERNAME = p_USER_ID
					inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
					LEFT OUTER JOIN TB_AD_USER_PREF B  ON	m.id = B.USER_PREF_MST_ID	AND A.GRP_ID	= B.GRP_ID	AND	A.FLD_CD	= B.FLD_CD	AND B.USER_ID	= u.ID
			WHERE    A.CROSSTAB_ITEM_CD = 'GROUP-COLUMNS'
    )  A
	GROUP BY  CROSSTAB_ITEM_CD
	; 

-- ITEM LV 최하단 레벨이 ITEM CODE이며, 활성화되어있는지

	select count(*) INTO v_ITEM_YN
 	  from ( SELECT	A.REFER_VALUE
					, COALESCE(B.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N'))			 AS ACTV_YN 
			   FROM	TB_AD_USER_PREF_DTL A 
					inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = 'UI_DP_40'  AND m.GRID_CD	= 'RST_CPT_01'
					inner join TB_AD_GROUP g on g.ID = A.GRP_ID 
					inner join TB_AD_USER u on u.USERNAME = p_USER_ID
					inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
					LEFT OUTER JOIN TB_AD_USER_PREF B  ON	m.id = B.USER_PREF_MST_ID	AND A.GRP_ID	= B.GRP_ID	AND	A.FLD_CD	= B.FLD_CD	AND B.USER_ID	= u.ID
			  WHERE A.CROSSTAB_ITEM_CD = 'GROUP-COLUMNS'
            ) M
	 where ACTV_YN = 'Y' and REFER_VALUE in (
                            SELECT ID FROM TB_DP_DIM_SETTING
                            WHERE  UI_ID = 'UI_DP_40' AND GRID_ID = 'RST_CPT_01'
                              AND LV_MGMT_ID IN (
                                                SELECT ID
                                                  FROM TB_cM_LEVEL_MGMT
                                                 WHERE 1=1
                                                   AND SALES_LV_YN != 'Y'
                                                   AND ACCOUNT_LV_YN !='Y'
                                                   AND COALESCE(LEAF_YN,'') = 'Y'
                                                   AND COALESCE(DEL_YN,'N') = 'N'
                                                   AND COALESCE(ACTV_YN,'') ='Y'
                                                )
		)
        ;

        OPEN pRESULT FOR
	    SELECT  CASE WHEN v_DIMENSION_01_ACTV_YN = 'Y' THEN IH.LVL01_CD		ELSE NULL END AS DIMENSION_01
			  , CASE WHEN v_DIMENSION_02_ACTV_YN = 'Y' THEN IH.LVL01_NM		ELSE NULL END AS DIMENSION_02
			  , CASE WHEN v_DIMENSION_03_ACTV_YN = 'Y' THEN IH.LVL02_CD		ELSE NULL END AS DIMENSION_03
			  , CASE WHEN v_DIMENSION_04_ACTV_YN = 'Y' THEN IH.LVL02_NM		ELSE NULL END AS DIMENSION_04
			  , CASE WHEN v_DIMENSION_05_ACTV_YN = 'Y' THEN IH.LVL03_CD		ELSE NULL END AS DIMENSION_05
			  , CASE WHEN v_DIMENSION_06_ACTV_YN = 'Y' THEN IH.LVL03_NM		ELSE NULL END AS DIMENSION_06
			  , CASE WHEN v_DIMENSION_07_ACTV_YN = 'Y' THEN IH.LVL04_CD		ELSE NULL END AS DIMENSION_07
			  , CASE WHEN v_DIMENSION_08_ACTV_YN = 'Y' THEN IH.LVL04_NM		ELSE NULL END AS DIMENSION_08   
			  , CASE WHEN v_DIMENSION_09_ACTV_YN = 'Y' THEN IH.LVL05_CD		ELSE NULL END AS DIMENSION_09
			  , CASE WHEN v_DIMENSION_10_ACTV_YN = 'Y' THEN IH.LVL05_NM		ELSE NULL END AS DIMENSION_10
			  , CASE WHEN v_DIMENSION_11_ACTV_YN = 'Y' THEN IH.LVL06_CD		ELSE NULL END AS DIMENSION_11
			  , CASE WHEN v_DIMENSION_12_ACTV_YN = 'Y' THEN IH.LVL06_NM		ELSE NULL END AS DIMENSION_12
			  , CASE WHEN v_DIMENSION_13_ACTV_YN = 'Y' THEN IH.LVL07_CD		ELSE NULL END AS DIMENSION_13
			  , CASE WHEN v_DIMENSION_14_ACTV_YN = 'Y' THEN IH.LVL07_NM		ELSE NULL END AS DIMENSION_14
			  , CASE WHEN v_DIMENSION_15_ACTV_YN = 'Y' THEN IH.LVL08_CD		ELSE NULL END AS DIMENSION_15
			  , CASE WHEN v_DIMENSION_16_ACTV_YN = 'Y' THEN IH.LVL08_NM		ELSE NULL END AS DIMENSION_16                    
			  , CASE WHEN v_DIMENSION_17_ACTV_YN = 'Y' THEN IH.LVL09_CD		ELSE NULL END AS DIMENSION_17
			  , CASE WHEN v_DIMENSION_18_ACTV_YN = 'Y' THEN IH.LVL09_NM		ELSE NULL END AS DIMENSION_18
			  , CASE WHEN v_DIMENSION_19_ACTV_YN = 'Y' THEN IH.LVL10_CD		ELSE NULL END AS DIMENSION_19
			  , CASE WHEN v_DIMENSION_20_ACTV_YN = 'Y' THEN IH.LVL10_NM		ELSE NULL END AS DIMENSION_20            
--			  , CASE WHEN YEAR(DP.BUCKET_START_DATE)=YEAR(DP.BUCKET_END_DATE)
--					  AND MONTH(DP.BUCKET_START_DATE)=MONTH(DP.BUCKET_END_DATE)
--					 THEN CONVERT(CHAR(7), DP.BUCKET_START_DATE, 23)
--                ELSE 'SUM-'+CONVERT(CHAR(7),DP.BUCKET_START_DATE,102)+'~'+CONVERT(CHAR(2),DP.BUCKET_END_DATE,110)
--                END AS "DATE" 
              , CASE WHEN --YEAR(M.BUCKET_START_DATE)=YEAR(M.BUCKET_END_DATE)
                       -- AND MONTH(M.BUCKET_START_DATE)=MONTH(M.BUCKET_END_DATE)
                       --THEN CONVERT(CHAR(7), M.BUCKET_START_DATE, 23)
                --ELSE 'SUM-'||CONVERT(CHAR(7),M.BUCKET_START_DATE,102)||'~'||CONVERT(CHAR(2),M.BUCKET_END_DATE,110)
                       EXTRACT ( YEAR FROM DP.BUCKET_START_DATE ) = EXTRACT ( YEAR FROM DP.BUCKET_END_DATE )
                   AND EXTRACT ( MONTH FROM DP.BUCKET_START_DATE) = EXTRACT ( MONTH FROM DP.BUCKET_END_DATE)
                  THEN TO_CHAR(DP.BUCKET_START_DATE, 'yyyy-MM')
                  ELSE 'SUM-'||TO_CHAR(DP.BUCKET_START_DATE,'yyyy.MM')||'~'||EXTRACT(MONTH FROM DP.BUCKET_END_DATE)
                  END                AS "DATE" 

              , CASE v_LAST_ITEM_LV    WHEN 1             THEN  IH.LVL01_ID 
									    WHEN 2             THEN  IH.LVL01_ID
									    WHEN 3             THEN  IH.LVL02_ID
									    WHEN 4             THEN  IH.LVL02_ID 
									    WHEN 5             THEN  IH.LVL03_ID
									    WHEN 6             THEN  IH.LVL03_ID
									    WHEN 7             THEN  IH.LVL04_ID
									    WHEN 8             THEN  IH.LVL04_ID 
									    WHEN 9             THEN  IH.LVL05_ID
									    WHEN 10            THEN  IH.LVL05_ID
									    WHEN 11            THEN  IH.LVL06_ID
									    WHEN 12            THEN  IH.LVL06_ID 
									    WHEN 13            THEN  IH.LVL07_ID
									    WHEN 14            THEN  IH.LVL07_ID
									    WHEN 15            THEN  IH.LVL08_ID
									    WHEN 16            THEN  IH.LVL08_ID 
									    WHEN 17            THEN  IH.LVL09_ID
									    WHEN 18            THEN  IH.LVL09_ID
									    WHEN 19            THEN  IH.LVL10_ID
									    WHEN 20            THEN  IH.LVL10_ID
									    END	AS ITEM      
		   , v_ACCT_CD AS "ACCOUNT"
           , v_CL_LV_MGMT_ID AS SALES
		   , CASE WHEN v_ACCT_CHECK != 0 AND v_ITEM_YN !=0 THEN UP.UTPIC ELSE NULL END AS UTPIC
		   , CASE  
                WHEN v_UNIT = 'QTY'                       THEN COALESCE(SUM(M1.QTY),0) 
                WHEN v_UNIT = 'AMT'                       THEN COALESCE(SUM(M1.AMT),0) 
                ELSE NULL END AS MEASURE_01
           , CASE  
                WHEN v_UNIT = 'QTY'                       THEN COALESCE(SUM(M2.QTY),0) 
                WHEN v_UNIT = 'AMT'                       THEN COALESCE(SUM(M2.AMT),0) 
                ELSE NULL END AS MEASURE_02
		   , CASE  
                WHEN v_UNIT = 'QTY'                       THEN COALESCE(SUM(M3.QTY),0) 
                WHEN v_UNIT = 'AMT'                       THEN COALESCE(SUM(M3.AMT),0) 
                ELSE NULL END AS MEASURE_03
		   FROM TB_DPD_ITEM_HIERACHY2 IH
				INNER JOIN
				 (                   -- 금주 계획
                            SELECT  DO.ITEM_MST_ID 
                                  , DO.ACCOUNT_ID
                                  , CA.BUCKET_START_DATE
                                  , CA.BUCKET_END_DATE         
                              FROM TB_DP_ENTRY DO 
                                   CROSS JOIN
                                   FN_DP_TEMP_THREE_CAL(v_STRT_DATE, v_END_DATE) CA                          
                             WHERE 1=1  
                               AND DO.VER_ID = v_VER_ID_01
                               AND DO.AUTH_TP_ID  = v_CL_LV_MGMT_ID
                          GROUP BY DO.ITEM_MST_ID ,DO.ACCOUNT_ID, CA.BUCKET_START_DATE , CA.BUCKET_END_DATE                                 
            ) DP
			 ON DP.ITEM_MST_ID = IH.ITEM_ID 
			    INNER JOIN
				TB_DPD_ACCOUNT_HIERACHY2 AH          
			 ON DP.ACCOUNT_ID = AH.ACCOUNT_ID
				LEFT OUTER JOIN
				(
                            SELECT   DISTINCT
									 ITEM_MST_ID
                                   , ACCOUNT_ID
                                   , PRICE_TP_ID
								   , MAX(UTPIC) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID ORDER BY BASE_DATE DESC) AS UTPIC 
                                   , AC.CURCY_CD_ID
                              FROM TB_DP_UNIT_PRICE UP
                                    INNER JOIN
                                    TB_DP_ACCOUNT_MST AC
                                ON UP.ACCOUNT_ID = AC.ID
                             WHERE 1=1
                               AND (REGEXP_LIKE(UPPER(AC.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                                    OR v_ACCT_CD IS NULL
                              )
--							   AND (	AC.ACCOUNT_CD IN (
--                                    SELECT TRIM(REGEXP_SUBSTR(v_ACCT_CD, '[^|]+', 1, LEVEL)) AS ACCT_CD
--                                        FROM DUAL
--                                    CONNECT BY INSTR(v_ACCT_CD, '|', 1, LEVEL - 1) > 0
--                                )
--                                OR  ( ''  =  COALESCE(v_ACCT_CD,'') AND COALESCE(AC.ACCOUNT_CD,'')  LIKE  '%'  )
--                                OR  AC.ACCOUNT_CD LIKE '%'||v_ACCT_CD||'%'
--								)
                              AND PRICE_TP_ID IN (SELECT PRICE_TP_ID FROM TB_DP_CONTROL_BOARD_VER_MST WHERE ID = v_VER_ID_01)
--                            GROUP BY ITEM_MST_ID
--                                   , ACCOUNT_ID
--                                   , PRICE_TP_ID
--                                   , AC.CURCY_CD_ID
				) UP
			ON (DP.ITEM_MST_ID = UP.ITEM_MST_ID AND DP.ACCOUNT_ID = UP.ACCOUNT_ID)
			   LEFT OUTER JOIN
               (
                            SELECT  DO.ITEM_MST_ID 
                                  , DO.ACCOUNT_ID
                                  , SUM(QTY)        AS QTY
                                  , SUM(AMT)        AS AMT                                  
                                  , CA.BUCKET_START_DATE 
                                  , CA.BUCKET_END_DATE         
                              FROM TB_DP_ENTRY DO 
                                   INNER JOIN 
                                   FN_DP_TEMP_THREE_CAL(v_STRT_DATE, v_END_DATE) CA                                   
                               ON DO.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE  
                             WHERE 1=1  
                               AND DO.VER_ID = v_VER_ID_01
                               AND DO.AUTH_TP_ID  = v_CL_LV_MGMT_ID
                          GROUP BY DO.ITEM_MST_ID ,DO.ACCOUNT_ID, CA.BUCKET_START_DATE , CA.BUCKET_END_DATE                 
                ) M1
        ON (     DP.ITEM_MST_ID = M1.ITEM_MST_ID  
		     AND DP.ACCOUNT_ID = M1.ACCOUNT_ID
             AND DP.BUCKET_START_DATE = M1.BUCKET_START_DATE    
             AND DP.BUCKET_END_DATE = M1.BUCKET_END_DATE )
		LEFT OUTER JOIN
            (
                            SELECT  DO.ITEM_MST_ID 
                                  , DO.ACCOUNT_ID
                                  , SUM(QTY)        AS QTY
                                  , SUM(AMT)        AS AMT                                  
                                  , CA.BUCKET_START_DATE
                                  , CA.BUCKET_END_DATE         
                              FROM TB_DP_ENTRY DO 
                                   INNER JOIN 
                                   FN_DP_TEMP_THREE_CAL(v_STRT_DATE, v_END_DATE) CA                                     
                               ON DO.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE  
                             WHERE 1=1  
                               AND DO.VER_ID = v_VER_ID_02
                               AND DO.AUTH_TP_ID  = v_CL_LV_MGMT_ID_02
                          GROUP BY DO.ITEM_MST_ID ,DO.ACCOUNT_ID, CA.BUCKET_START_DATE , CA.BUCKET_END_DATE                 
            ) M2            
			ON (    DP.ITEM_MST_ID = M2.ITEM_MST_ID 
		        AND DP.ACCOUNT_ID = M2.ACCOUNT_ID
				AND DP.BUCKET_START_DATE = M2.BUCKET_START_DATE    
				AND DP.BUCKET_END_DATE = M2.BUCKET_END_DATE )
           LEFT OUTER JOIN
           (
--                            SELECT  DO.ITEM_MST_ID 
--                                  , DO.ACCOUNT_ID
--                                  , SUM(QTY)        AS QTY
--                                  , SUM(AMT)        AS AMT                                  
--                                  , CA.BUCKET_START_DATE 
--                                  , CA.BUCKET_END_DATE         
--                              FROM TB_DP_ENTRY DO       
--                                   INNER JOIN 
--                                   FN_DP_TEMP_THREE_CAL(v_STRT_DATE, v_END_DATE) CA                                      
--                               ON DO.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE  
--                             WHERE 1=1
--                              AND DO.VER_ID = v_YOY_VERSION_ID
--                              AND DO.AUTH_TP_ID =  v_YOY_AUTH_TP_ID
--                             GROUP BY DO.ITEM_MST_ID ,DO.ACCOUNT_ID, BUCKET_START_DATE , CA.BUCKET_END_DATE         
						  SELECT ITEM_MST_ID, ACCOUNT_ID
								,CA.BUCKET_START_DATE
								,CA.BUCKET_END_DATE
								,SUM(ANNUAL_QTY)	AS QTY
		   						,SUM(ANNUAL_AMT)	AS AMT
						    FROM TB_DP_MEASURE_DATA AN
								 INNER JOIN
								 FN_DP_TEMP_THREE_CAL( v_STRT_DATE, v_END_DATE ) CA
                              ON AN.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
						   WHERE ANNUAL_QTY >0
						GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE, BUCKET_END_DATE  
           ) M3
			ON (	DP.ITEM_MST_ID = M3.ITEM_MST_ID 
				AND DP.ACCOUNT_ID = M3.ACCOUNT_ID
				AND DP.BUCKET_START_DATE = M3.BUCKET_START_DATE   
				AND DP.BUCKET_END_DATE = M3.BUCKET_END_DATE )
         WHERE   1=1   
		   AND (    
--                    AH.ACCOUNT_CD IN (
--					SELECT TRIM(REGEXP_SUBSTR(v_ACCT_CD, '[^|]+', 1, LEVEL)) AS ACCT_CD
--						FROM DUAL
--					CONNECT BY INSTR(v_ACCT_CD, '|', 1, LEVEL - 1) > 0
--				)
                 (REGEXP_LIKE(UPPER(AH.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                        OR v_ACCT_CD IS NULL
                  )
				OR   
					 CASE WHEN v_SEARCH_LV_SEQ_02 = 1  THEN  AH.LVL01_CD		    
						  WHEN v_SEARCH_LV_SEQ_02 = 2  THEN  AH.LVL02_CD		    
						  WHEN v_SEARCH_LV_SEQ_02 = 3  THEN  AH.LVL03_CD      
						  WHEN v_SEARCH_LV_SEQ_02 = 4  THEN  AH.LVL04_CD      
						  WHEN v_SEARCH_LV_SEQ_02 = 5  THEN  AH.LVL05_CD	     
						  WHEN v_SEARCH_LV_SEQ_02 = 6  THEN  AH.LVL06_CD      
						  WHEN v_SEARCH_LV_SEQ_02 = 7  THEN  AH.LVL07_CD      
						  WHEN v_SEARCH_LV_SEQ_02 = 8  THEN  AH.LVL08_CD      
						  WHEN v_SEARCH_LV_SEQ_02 = 9  THEN  AH.LVL09_CD       
						  WHEN v_SEARCH_LV_SEQ_02 = 10 THEN  AH.LVL10_CD      
						  ELSE NULL END LIKE '%'||v_ACCT_CD||'%'
                ) 
		   AND (    
--                    IH.ITEM_CD IN (
--					SELECT TRIM(REGEXP_SUBSTR(v_ITEM_CD, '[^|]+', 1, LEVEL)) AS ITEM_CD
--						FROM DUAL
--					CONNECT BY INSTR(v_ITEM_CD, '|', 1, LEVEL - 1) > 0
--				)
                (REGEXP_LIKE(UPPER(IH.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                        OR v_ITEM_CD IS NULL
                  )
				OR  
					 CASE WHEN v_SEARCH_LV_SEQ = 1  THEN  IH.LVL01_CD		    
						  WHEN v_SEARCH_LV_SEQ = 2  THEN  IH.LVL02_CD		    
						  WHEN v_SEARCH_LV_SEQ = 3  THEN  IH.LVL03_CD      
						  WHEN v_SEARCH_LV_SEQ = 4  THEN  IH.LVL04_CD      
						  WHEN v_SEARCH_LV_SEQ = 5  THEN  IH.LVL05_CD	     
						  WHEN v_SEARCH_LV_SEQ = 6  THEN  IH.LVL06_CD      
						  WHEN v_SEARCH_LV_SEQ = 7  THEN  IH.LVL07_CD      
						  WHEN v_SEARCH_LV_SEQ = 8  THEN  IH.LVL08_CD      
						  WHEN v_SEARCH_LV_SEQ = 9  THEN  IH.LVL09_CD      
						  WHEN v_SEARCH_LV_SEQ = 10 THEN  IH.LVL10_CD      
						  ELSE ' ' END LIKE '%'||COALESCE(v_ITEM_CD,'')||'%'
                 )

    GROUP BY        
             CASE WHEN v_DIMENSION_01_ACTV_YN = 'Y' THEN IH.LVL01_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_02_ACTV_YN = 'Y' THEN IH.LVL01_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_03_ACTV_YN = 'Y' THEN IH.LVL02_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_04_ACTV_YN = 'Y' THEN IH.LVL02_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_05_ACTV_YN = 'Y' THEN IH.LVL03_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_06_ACTV_YN = 'Y' THEN IH.LVL03_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_07_ACTV_YN = 'Y' THEN IH.LVL04_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_08_ACTV_YN = 'Y' THEN IH.LVL04_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_09_ACTV_YN = 'Y' THEN IH.LVL05_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_10_ACTV_YN = 'Y' THEN IH.LVL05_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_11_ACTV_YN = 'Y' THEN IH.LVL06_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_12_ACTV_YN = 'Y' THEN IH.LVL06_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_13_ACTV_YN = 'Y' THEN IH.LVL07_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_14_ACTV_YN = 'Y' THEN IH.LVL07_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_15_ACTV_YN = 'Y' THEN IH.LVL08_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_16_ACTV_YN = 'Y' THEN IH.LVL08_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_17_ACTV_YN = 'Y' THEN IH.LVL09_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_18_ACTV_YN = 'Y' THEN IH.LVL09_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_19_ACTV_YN = 'Y' THEN IH.LVL10_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_20_ACTV_YN = 'Y' THEN IH.LVL10_NM	ELSE NULL END 	
            ,DP.BUCKET_START_DATE 
            ,DP.BUCKET_END_DATE
            , CASE v_LAST_ITEM_LV   WHEN 1             THEN  IH.LVL01_ID 
                                     WHEN 2             THEN  IH.LVL01_ID
                                     WHEN 3             THEN  IH.LVL02_ID
                                     WHEN 4             THEN  IH.LVL02_ID 
                                     WHEN 5             THEN  IH.LVL03_ID
                                     WHEN 6             THEN  IH.LVL03_ID
                                     WHEN 7             THEN  IH.LVL04_ID
                                     WHEN 8             THEN  IH.LVL04_ID 
                                     WHEN 9             THEN  IH.LVL05_ID
                                     WHEN 10            THEN  IH.LVL05_ID
                                     WHEN 11            THEN  IH.LVL06_ID
                                     WHEN 12            THEN  IH.LVL06_ID 
                                     WHEN 13            THEN  IH.LVL07_ID
                                     WHEN 14            THEN  IH.LVL07_ID
                                     WHEN 15            THEN  IH.LVL08_ID
                                     WHEN 16            THEN  IH.LVL08_ID 
                                     WHEN 17            THEN  IH.LVL09_ID
                                     WHEN 18            THEN  IH.LVL09_ID
                                     WHEN 19            THEN  IH.LVL10_ID
                                     WHEN 20            THEN  IH.LVL10_ID
                                     END	            
           ,CASE WHEN v_ACCT_CHECK != 0 AND v_ITEM_YN !=0 THEN UP.UTPIC ELSE NULL END  
      ORDER BY 
             CASE WHEN v_DIMENSION_01_ACTV_YN = 'Y' THEN IH.LVL01_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_02_ACTV_YN = 'Y' THEN IH.LVL01_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_03_ACTV_YN = 'Y' THEN IH.LVL02_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_04_ACTV_YN = 'Y' THEN IH.LVL02_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_05_ACTV_YN = 'Y' THEN IH.LVL03_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_06_ACTV_YN = 'Y' THEN IH.LVL03_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_07_ACTV_YN = 'Y' THEN IH.LVL04_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_08_ACTV_YN = 'Y' THEN IH.LVL04_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_09_ACTV_YN = 'Y' THEN IH.LVL05_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_10_ACTV_YN = 'Y' THEN IH.LVL05_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_11_ACTV_YN = 'Y' THEN IH.LVL06_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_12_ACTV_YN = 'Y' THEN IH.LVL06_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_13_ACTV_YN = 'Y' THEN IH.LVL07_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_14_ACTV_YN = 'Y' THEN IH.LVL07_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_15_ACTV_YN = 'Y' THEN IH.LVL08_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_16_ACTV_YN = 'Y' THEN IH.LVL08_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_17_ACTV_YN = 'Y' THEN IH.LVL09_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_18_ACTV_YN = 'Y' THEN IH.LVL09_NM	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_19_ACTV_YN = 'Y' THEN IH.LVL10_CD	ELSE NULL END 		
            ,CASE WHEN v_DIMENSION_20_ACTV_YN = 'Y' THEN IH.LVL10_NM	ELSE NULL END 	
;


--	SET p_RT_MSG = 'MSG_0003';  --조회 되었습니다.
--
--END TRY
--BEGIN CATCH
--IF (ERROR_MESSAGE() LIKE 'MSG_%')
--	BEGIN
--		SET v_ERR_MSG = ERROR_MESSAGE()
--		SET p_RT_MSG = v_ERR_MSG
--	END
--ELSE 
--		THROW;
--		--EXEC SP_COMM_RAISE_ERR
        p_RT_MSG := 'MSG_0003' ; --조회 되었습니다.

     EXCEPTION WHEN OTHERS THEN  -- ?？? ???？？? ?？? ???？?？ : e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_MSG := SQLERRM;
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;   
END;

/

