create PROCEDURE SP_UI_CM_07_POP_S1 (
	 P_WRK_TYPE					    IN VARCHAR2 := '',
     P_SHPP_LEADTIME_MST_ID		    IN VARCHAR2 := '',
     P_BOD_TP_ID					IN VARCHAR2	:= '',
	 P_CONSUME_LOCAT_MGMT_ID		IN VARCHAR2	:= '',
	 P_ACCOUNT_ID					IN VARCHAR2	:= '',
	 P_SUPPLY_LOCAT_MGMT_ID		    IN VARCHAR2	:= '',
	 P_VEHICL_TP_ID				    IN VARCHAR2	:= '',
	 P_PRIORT				        IN INT	:= -1,
	 P_TRANSP_COST_CAL_BASE_ID		IN VARCHAR2	:= '',
	 P_WEIGHT_UOM_ID				IN VARCHAR2	:='',
	 P_TRANSP_UTPIC				    IN NUMBER := 0,
	 P_CURCY_CD_ID					IN VARCHAR2	:= '',
     P_ACTV_YN                      IN VARCHAR2 := '',
	 P_USER_ID						IN VARCHAR2 := '',
	 P_RT_ROLLBACK_FLAG				OUT VARCHAR2,
	 P_RT_MSG					    OUT VARCHAR2
)
IS

    P_ERR_STATUS NUMBER := 0;
    P_ERR_MSG  VARCHAR2(4000) := '';
    vBOD_TP VARCHAR2(100) := '';
    vSHPP_LEADTIME_MST_ID VARCHAR2(100) := P_SHPP_LEADTIME_MST_ID;

BEGIN
    IF P_VEHICL_TP_ID IS NOT NULL THEN
        BEGIN
            SELECT COMN_CD INTO vBOD_TP
              FROM TB_AD_COMN_CODE 
             WHERE ID = P_BOD_TP_ID;
             EXCEPTION
                WHEN NO_DATA_FOUND THEN NULL;
        END;
        
        BEGIN
            IF vBOD_TP IS NOT NULL AND vBOD_TP = 'SALES_BOD' THEN
                SELECT A.ID INTO vSHPP_LEADTIME_MST_ID
                  FROM TB_CM_SHIP_LT_MST A
                 WHERE A.VEHICL_TP_ID = P_VEHICL_TP_ID
                   AND A.ACCOUNT_ID = P_ACCOUNT_ID
                   AND A.SUPPLY_LOCAT_ID = P_SUPPLY_LOCAT_MGMT_ID;
            ELSIF vSHPP_LEADTIME_MST_ID IS NULL THEN
                SELECT A.ID INTO vSHPP_LEADTIME_MST_ID
                  FROM TB_CM_SHIP_LT_MST A
                 WHERE A.VEHICL_TP_ID = P_VEHICL_TP_ID
                   AND A.CONSUME_LOCAT_ID = P_CONSUME_LOCAT_MGMT_ID
                   AND A.SUPPLY_LOCAT_ID = P_SUPPLY_LOCAT_MGMT_ID;
            END IF;
             EXCEPTION
                WHEN NO_DATA_FOUND THEN NULL;
        END;
        
        IF P_WRK_TYPE = 'N' AND vSHPP_LEADTIME_MST_ID IS NOT NULL THEN
            P_ERR_MSG := 'MSG_0013';
            RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
        END IF;

        MERGE INTO TB_CM_SHIP_LT_MST TARGET
        USING ( 
                SELECT
                  vSHPP_LEADTIME_MST_ID 	AS ID
                 ,P_BOD_TP_ID    			AS BOD_TP_ID
                 ,P_CONSUME_LOCAT_MGMT_ID   AS CONSUME_LOCAT_ID
                 ,P_ACCOUNT_ID     			AS ACCOUNT_ID
                 ,P_SUPPLY_LOCAT_MGMT_ID    AS SUPPLY_LOCAT_ID
                 ,P_VEHICL_TP_ID			AS VEHICL_TP_ID
                 ,CASE WHEN P_PRIORT < 0 THEN NULL ELSE P_PRIORT END AS PRIORT
                 ,P_TRANSP_COST_CAL_BASE_ID AS TRANSP_COST_CAL_BASE_ID
                 ,P_WEIGHT_UOM_ID			AS WEIGHT_UOM_ID
                 ,P_TRANSP_UTPIC			AS TRANSP_UTPIC
                 ,P_CURCY_CD_ID				AS CURCY_CD_ID
                 ,P_ACTV_YN					AS ACTV_YN
                 ,P_USER_ID					AS USER_ID
              FROM DUAL
              ) SOURCE
        ON  (TARGET.ID = SOURCE.ID
        AND TARGET.VEHICL_TP_ID = SOURCE.VEHICL_TP_ID)
        WHEN MATCHED THEN
             UPDATE 
               SET  
                    TARGET.PRIORT     				= SOURCE.PRIORT
                    ,TARGET.TRANSP_COST_CAL_BASE_ID = SOURCE.TRANSP_COST_CAL_BASE_ID
                    ,TARGET.WEIGHT_UOM_ID         	= SOURCE.WEIGHT_UOM_ID
                    ,TARGET.TRANSP_UTPIC         	= SOURCE.TRANSP_UTPIC
                    ,TARGET.CURCY_CD_ID         	= SOURCE.CURCY_CD_ID
                    ,TARGET.ACTV_YN         		= SOURCE.ACTV_YN
                    ,TARGET.MODIFY_BY				= SOURCE.USER_ID
                    ,TARGET.MODIFY_DTTM				= SYSDATE  
        WHEN NOT MATCHED THEN
            INSERT (
                    ID,
                    BOD_TP_ID,
                    CONSUME_LOCAT_ID,
                    ACCOUNT_ID,
                    SUPPLY_LOCAT_ID,
                    VEHICL_TP_ID,
                    PRIORT,
                    TRANSP_COST_CAL_BASE_ID,
                    WEIGHT_UOM_ID,
                    TRANSP_UTPIC,
                    CURCY_CD_ID,
                    ACTV_YN,
                    CREATE_BY,
                    CREATE_DTTM
                   )
            VALUES (
                    TO_SINGLE_BYTE(SYS_GUID()),
                    SOURCE.BOD_TP_ID,
                    SOURCE.CONSUME_LOCAT_ID,
                    SOURCE.ACCOUNT_ID,
                    SOURCE.SUPPLY_LOCAT_ID,
                    SOURCE.VEHICL_TP_ID,
                    SOURCE.PRIORT,
                    SOURCE.TRANSP_COST_CAL_BASE_ID,
                    SOURCE.WEIGHT_UOM_ID,
                    SOURCE.TRANSP_UTPIC,
                    SOURCE.CURCY_CD_ID,
                    SOURCE.ACTV_YN,
                    SOURCE.USER_ID,
                    SYSDATE
                   );
    END IF;
    
    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';

EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;   
      ELSE
          RAISE;
      END IF;
END;

/

