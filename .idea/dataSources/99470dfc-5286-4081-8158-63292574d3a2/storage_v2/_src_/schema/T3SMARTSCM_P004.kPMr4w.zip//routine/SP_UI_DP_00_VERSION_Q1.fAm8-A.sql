create PROCEDURE "SP_UI_DP_00_VERSION_Q1" (
    P_PLAN_TP_ID   IN CHAR :=''
  , P_CL_YN        IN CHAR := 'Y'
  , P_VER_CNT      IN INT  := 5 
  , pRESULT       OUT SYS_REFCURSOR
)Is
/*****************************************************************************
Title : SP_UI_DP_00_CL_VERSION_Q1
？？？？ ？？？？？ : ？？？？？？
？？？？ ？？？？？？ : 2017.12.06

？？？？ 
 -  DP Version ID ？？？
 -  Service : SRV_GET_SP_UI_DP_00_VERSION_Q1
History (？？？？？？？？ / ？？？？？？ / ？？？？？？？？)
-  2018.12.06 / ？？？？？？ / ？？？？ ？？？？
-  2019.07.18 / 김소희  / cutoff status 반영
*****************************************************************************/
    P_DF_PLAN_TP_ID CHAR(32);
BEGIN
    SELECT ID INTO P_DF_PLAN_TP_ID
      FROM TB_CM_COMM_CONFIG
     WHERE CONF_GRP_CD = 'DP_PLAN_TYPE'
       AND DEFAT_VAL = 'Y';

    OPEN pRESULT
    FOR
    SELECT A.*
    FROM (
        SELECT    MS.ID
                , MS.VER_ID
                , MS.BUKT
                , MS.HORIZ
                , MS.FROM_DATE
                , MS."TO_DATE"
                , MS.DTF
                , MS.DTF_DATE
                , MS.VER_S_BUCKET
                , MS.VER_S_HORIZON
                , MS.VER_S_HORIZON_DATE
                , MS.PLAN_TP_ID
                , MS.PRICE_TP_ID
                , MS.CURCY_TP_ID        
                , ROW_NUMBER() OVER (ORDER BY MS.CREATE_DTTM desc) AS ROWN
                , DT.CL_STATUS_ID
                , DT.CL_LV_MGMT_ID AS AUTH_TP_ID           
          FROM TB_DP_CONTROL_BOARD_VER_MST MS
               INNER JOIN
               TB_DP_CONTROL_BOARD_VER_DTL DT
            ON MS.ID = DT.CONBD_VER_MST_ID
           AND DT.WORK_TP_ID IN (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_CD = 'CL' AND CONF_GRP_CD = 'DP_WK_TP')        
         WHERE 1=1
           AND ((P_CL_YN ='Y' AND 
                 DT.CL_STATUS_ID IN (
                    SELECT ID 
                      FROM TB_CM_COMM_CONFIG 
                     WHERE CONF_GRP_CD = 'DP_CL_STATUS' 
                       AND ((P_PLAN_TP_ID IS NOT NULL AND CONF_CD = 'CLOSE') OR
                            (P_PLAN_TP_ID IS NULL AND CONF_CD IN ('CLOSE', 'CUTOFF'))
                       )
                 )
                )
               OR (P_CL_YN = 'N')
           )
           AND CASE WHEN P_PLAN_TP_ID IS NULL THEN P_DF_PLAN_TP_ID ELSE P_PLAN_TP_ID END = MS.PLAN_TP_ID
    ) A
    WHERE A.ROWN <= P_VER_CNT
    ORDER BY A.ROWN
    ;
END;

/

