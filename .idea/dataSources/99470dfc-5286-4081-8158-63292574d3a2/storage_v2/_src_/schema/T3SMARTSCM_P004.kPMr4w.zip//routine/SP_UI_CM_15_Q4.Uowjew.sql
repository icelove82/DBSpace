create PROCEDURE        "SP_UI_CM_15_Q4" (
        pResult OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN pResult FOR 
      SELECT  B.COMN_CD
             ,B.COMN_CD_NM
      FROM  TB_AD_COMN_GRP A 
        INNER JOIN TB_AD_COMN_CODE B 
          ON A.ID = B.SRC_ID
     WHERE 1=1 
       AND A.GRP_CD='PLAN_POLICY_TREE_ITEM'
       AND B.DEL_YN = 'N'
    ORDER BY B.SEQ;

END;

/

