create PROCEDURE SP_UI_IM_01_POP_07_S
(
	 P_ID					IN VARCHAR2 := ''
	,P_SVC_LV				IN NUMBER := ''
	,P_SAFTFCT				IN NUMBER := ''
	,P_ACTV_YN				IN VARCHAR2 := ''
	,P_USER_ID				IN VARCHAR2 := ''
	,P_WRK_TYPE				IN VARCHAR2 := ''
	,P_RT_ROLLBACK_FLAG		OUT VARCHAR2
	,P_RT_MSG				OUT VARCHAR2
)
IS
    P_ERR_STATUS    NUMBER := 0;
    P_ERR_MSG       VARCHAR2(4000) := '';
    vCONF_ID        VARCHAR2(32) := '';
BEGIN

IF P_WRK_TYPE = 'SAVE'
THEN	
		SELECT ID INTO vCONF_ID FROM TB_CM_CONFIGURATION WHERE CONF_KEY='307';

		P_ERR_MSG := 'MSG_0006'; --'？？？ ？？？ ？？？？ ？？μ？？？ ？？？？？？？.'
		IF NVL(P_SVC_LV,0) = 0 THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
        END IF;

		P_ERR_MSG := 'MSG_0006'; --'？？？ ？？？ ？？？？ ？？μ？？？ ？？？？？？？.'
		IF NVL(P_SAFTFCT,0) = 0 THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
        END IF;

		P_ERR_MSG := 'MSG_0012'; -- '？？？？？？ ？？？？？？ ？？？ ？？？？ ？？μ？？？？？？？.'
		IF (P_SVC_LV < 0 OR P_SVC_LV > 100)
		   THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
        END IF;

		MERGE INTO TB_IM_SVC_SAFTFCT_BASE B 
		USING (SELECT P_ID AS ID FROM DUAL) A
				ON    (B.ID = A.ID)
		WHEN MATCHED THEN
			UPDATE 
			   SET ACTV_YN		= P_ACTV_YN
				 , SVC_LV		= P_SVC_LV
				 , SAFTFCT		= P_SAFTFCT
				 , MODIFY_BY	= P_USER_ID
				 , MODIFY_DTTM	= SYSDATE()
		WHEN NOT MATCHED THEN
			INSERT (
				-- ？？？？？？
				ID, CONF_ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
				-- ？？？？？？？？
				,SVC_LV
				,SAFTFCT
				,ACTV_YN
				)
			VALUES
				(
				-- ？？？？？？
				TO_SINGLE_BYTE(SYS_GUID()),vCONF_ID,P_USER_ID, SYSDATE(), P_USER_ID, SYSDATE()
				-- ？？？？？？？？
				,P_SVC_LV
				,P_SAFTFCT
				,P_ACTV_YN		
				);

		P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';  --？？？？ ？？？？？？？？.

ELSIF P_WRK_TYPE = 'DELETE'
THEN
        DELETE FROM TB_IM_SVC_SAFTFCT_BASE 
		WHERE ID = P_ID;

		P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0002';
END IF;

	EXCEPTION
        WHEN OTHERS THEN
            P_RT_ROLLBACK_FLAG := 'false';
            IF(SQLCODE = -20012)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF;
END;

/

