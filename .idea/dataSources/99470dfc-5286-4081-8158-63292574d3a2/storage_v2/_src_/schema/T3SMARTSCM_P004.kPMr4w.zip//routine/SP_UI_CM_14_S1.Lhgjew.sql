create PROCEDURE SP_UI_CM_14_S1(
	 P_ID    			    IN VARCHAR2	:= null
	,P_CALENDAR_DESCRIP		IN VARCHAR2 := null
	,P_STRT_DATE			IN DATE
	,P_END_DATE				IN DATE
	,P_CYCL_TP_ID			IN VARCHAR2 := ''
	,P_ACTV_YN				IN CHAR :=NULL
	,P_USER_ID				IN VARCHAR2 := null
	,P_RT_ROLLBACK_FLAG     OUT VARCHAR2
	,P_RT_MSG               OUT VARCHAR2
)IS
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG  VARCHAR2(4000) :='';
    BEGIN
        P_ERR_MSG := 'MSG_0007'; -- '?????？??￥ ???？?????？????？？ '
	    IF P_STRT_DATE > P_END_DATE 
            THEN
                RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
        END IF;
        
        UPDATE TB_CM_HOLIDAY
        SET CALENDAR_DESCRIP = P_CALENDAR_DESCRIP
           ,STRT_DATE = P_STRT_DATE
           ,END_DATE = P_END_DATE
           ,CYCL_TP_ID = P_CYCL_TP_ID
           ,ACTV_YN = P_ACTV_YN
           ,MODIFY_BY = P_USER_ID
           ,MODIFY_DTTM = SYSDATE
        WHERE ID = P_ID;

	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  --???？？????？？

EXCEPTION
    WHEN OTHERS THEN
        IF(SQLCODE = -20012)
          THEN
              P_RT_ROLLBACK_FLAG := 'false';
              P_RT_MSG := P_ERR_MSG;   
          ELSE
          RAISE;
          END IF; 
END;

/

