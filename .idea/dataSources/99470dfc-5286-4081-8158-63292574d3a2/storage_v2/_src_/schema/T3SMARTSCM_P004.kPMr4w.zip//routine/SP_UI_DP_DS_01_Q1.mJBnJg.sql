create PROCEDURE "SP_UI_DP_DS_01_Q1" 
(
         P_EMP_NO       IN  VARCHAR2   :=''
        ,P_EMP_NM       IN  VARCHAR2   :=''
--        ,P_ETC          IN  VARCHAR2   :=''
        ,pResult		OUT SYS_REFCURSOR 
)IS
/**************************************************
    ?λ？???？ EMPLOYEE SAVE 
***************************************************/
BEGIN
    OPEN pResult
    FOR
    SELECT 
              ID
            , USER_ID
            , EMP_NO
            , EMP_NM
            , ACTV_YN
            , CREATE_BY
            , CREATE_DTTM
            , MODIFY_BY
            , MODIFY_DTTM
      FROM TB_DP_EMPLOYEE
     WHERE 1=1
       AND (EMP_NO LIKE '%'|| P_EMP_NO ||'%' OR P_EMP_NO IS NULL)
       AND (EMP_NM LIKE '%'|| P_EMP_NM ||'%' OR P_EMP_NM IS NULL)
      ;
END
;


/

