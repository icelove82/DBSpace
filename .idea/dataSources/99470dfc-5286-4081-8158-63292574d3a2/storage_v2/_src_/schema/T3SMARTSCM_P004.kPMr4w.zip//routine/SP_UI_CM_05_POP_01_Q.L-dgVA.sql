create PROCEDURE "SP_UI_CM_05_POP_01_Q" (
    P_CONF_KEY          IN VARCHAR2:='',
    P_VIEW_ID           IN VARCHAR2:='',
    P_ITEM_CD           IN VARCHAR2:='',
    P_ITEM_NM           IN VARCHAR2:='',
    P_ITEM_TP           IN VARCHAR2:='',
    P_DESCRIP           IN VARCHAR2:='',
    pResult             OUT SYS_REFCURSOR
)
IS
BEGIN
    IF P_CONF_KEY ='001'
    THEN
        OPEN pResult FOR
            SELECT  A.ID
                   ,A.ITEM_CD
                   ,A.ITEM_NM
                   ,B.ID        AS ITEM_TP_ID
                   ,B.CONVN_NM  AS ITEM_TP
                   ,A.DESCRIP
                   ,P_VIEW_ID   AS VIEW_ID
              FROM TB_CM_ITEM_MST A 
                INNER JOIN TB_CM_ITEM_TYPE B
                  ON (A.ITEM_TP_ID = B.ID)
              WHERE 1=1
                  AND UPPER(NVL(A.ITEM_CD , ' '))  LIKE '%'||UPPER(P_ITEM_CD)||'%'	 
                  AND UPPER(NVL(A.ITEM_NM , ' '))  LIKE '%'||UPPER(P_ITEM_NM)||'%'	
                  AND ( UPPER(NVL(B.ID, ' ')) LIKE '%'||UPPER(P_ITEM_TP)||'%'
                        OR	UPPER(P_ITEM_TP) = 'ALL' )	
                  AND UPPER(NVL(A.DESCRIP , ' '))  LIKE '%'||UPPER(P_DESCRIP)||'%';
    
    ELSIF P_CONF_KEY ='002'
    THEN
        OPEN pResult FOR 
            SELECT  A.COMN_CD_NM        AS LOC_TP
                   ,B.LOCAT_LV
                   ,C.LOCAT_CD
                   ,C.LOCAT_NM
                   ,F.ITEM_CD
                   ,F.ITEM_NM
                   ,G.ID                AS ITEM_TP_ID
                   ,G.CONVN_NM          AS ITEM_TP
                   ,F.DESCRIP
                   ,E.ID
                   ,P_VIEW_ID           AS VIEW_ID
              FROM TB_AD_COMN_CODE A
                   INNER JOIN TB_CM_LOC_MST B
                ON (A.ID = B.LOCAT_TP_ID)
                   INNER JOIN TB_CM_LOC_DTL C
                ON (B.ID = C.LOCAT_MST_ID)
                   INNER JOIN TB_CM_LOC_MGMT D
                ON (C.ID = D.LOCAT_ID)
                   INNER JOIN TB_CM_SITE_ITEM E
                ON (D.ID = E.LOCAT_MGMT_ID)
                   INNER JOIN TB_CM_ITEM_MST F
                ON (E.ITEM_MST_ID = F.ID)
                   INNER JOIN TB_CM_ITEM_TYPE G
                ON (F.ITEM_TP_ID = G.ID)
             WHERE 1=1
               AND UPPER(F.ITEM_CD)  LIKE '%'||UPPER(P_ITEM_CD)||'%'	
               AND UPPER(F.ITEM_NM)  LIKE '%'||UPPER(P_ITEM_NM)||'%'	
               AND (UPPER(G.ID) LIKE '%'||UPPER(P_ITEM_TP)||'%'
                     OR	UPPER(P_ITEM_TP) = 'ALL')	
               AND (UPPER(F.DESCRIP)  LIKE '%'||UPPER(P_DESCRIP)||'%' OR P_DESCRIP IS NULL)
               AND EXISTS (
                           SELECT 1
                             FROM TB_AD_COMN_GRP X
                               INNER JOIN TB_AD_COMN_CODE Y
                                 ON (X.ID = Y.SRC_ID)
                            WHERE 1=1
                              AND X.GRP_CD = 'BOM_ITEM_TYPE'
                              AND Y.COMN_CD = 'FINAL_PRODUCT_GR_ITEM'   
                              AND Y.ID = E.BOM_ITEM_TP_ID 	
                          );
                          
    ELSIF P_CONF_KEY = '003'
    THEN
        OPEN pResult FOR 
            SELECT  A.COMN_CD_NM        AS LOC_TP
                   ,B.LOCAT_LV
                   ,C.LOCAT_CD
                   ,C.LOCAT_NM
                   ,F.ITEM_CD
                   ,F.ITEM_NM
                   ,G.ID                AS ITEM_TP_ID
                   ,G.CONVN_NM          AS ITEM_TP
                   ,F.DESCRIP
                   ,E.ID
                   ,P_VIEW_ID           AS VIEW_ID
              FROM TB_AD_COMN_CODE A
                   INNER JOIN TB_CM_LOC_MST B
                ON (A.ID = B.LOCAT_TP_ID)
                   INNER JOIN TB_CM_LOC_DTL C
                ON (B.ID = C.LOCAT_MST_ID)
                   INNER JOIN TB_CM_LOC_MGMT D
                ON (C.ID = D.LOCAT_ID)
                   INNER JOIN TB_CM_SITE_ITEM E
                ON (D.ID = E.LOCAT_MGMT_ID)
                   INNER JOIN TB_CM_ITEM_MST F
                ON (E.ITEM_MST_ID = F.ID)
                   INNER JOIN TB_CM_ITEM_TYPE G
                ON (F.ITEM_TP_ID = G.ID)
                   INNER JOIN TB_AD_COMN_CODE H
                ON (E.BOM_ITEM_TP_ID = H.ID)
             WHERE 1=1
               AND H.COMN_CD = (CASE WHEN D.SEMI_PRDUCT_GI_USE_YN = 'Y' THEN 'SEMI_PRODUCT_GI_ITEM' ELSE 'FINAL_PRODUCT_GR_ITEM' END)
               AND UPPER(F.ITEM_CD)  LIKE '%'||UPPER(P_ITEM_CD)||'%'	
               AND UPPER(F.ITEM_NM)  LIKE '%'||UPPER(P_ITEM_NM)||'%'	
               AND (UPPER(G.ID) LIKE '%'||UPPER(P_ITEM_TP)||'%'
                     OR	UPPER(P_ITEM_TP) = 'ALL')	
               AND (UPPER(F.DESCRIP)  LIKE '%'||UPPER(P_DESCRIP)||'%' OR P_DESCRIP IS NULL)
               AND G.CONVN_NM <> 'FG';
    END IF;

END;

/

