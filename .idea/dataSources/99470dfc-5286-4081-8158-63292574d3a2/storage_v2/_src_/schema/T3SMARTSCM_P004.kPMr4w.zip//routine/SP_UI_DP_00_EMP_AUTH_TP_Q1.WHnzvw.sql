create PROCEDURE                 "SP_UI_DP_00_EMP_AUTH_TP_Q1" (
    P_USER_ID   IN  VARCHAR2 := ''
  , P_UI_ID     IN  VARCHAR2
  , pRESULT     OUT SYS_REFCURSOR 
) IS 

    V_USER_ID CHAR(32);
    V_IF_CHECK INT;
BEGIN
/*************************************************************************
    History ( Date / Writer / Comment)
    - 2021.01.14 / ksh / get ID of user by user param
    - 2021.02.09 / ksh / relocate unclear code to get user id  
************************************************************************/
    SELECT COUNT(ID) INTO V_IF_CHECK
      FROM TB_AD_USER
     WHERE USERNAME = P_USER_ID
     ;

IF (V_IF_CHECK > 0)
    THEN
        SELECT ID INTO V_USER_ID
          FROM TB_AD_USER
         WHERE USERNAME = P_USER_ID;
    END IF;

IF (P_UI_ID = 'UI_DP_25' OR P_UI_ID = 'UI_DP_25_CHART' OR P_UI_ID = 'UI_DP_95' OR P_UI_ID = 'UI_DP_95_CHART')
    THEN
    -- Entry�뒗 mapping data留� �굹�삤�룄濡� �닔�젙 (20190624)
    -- FN_DP_TEMP_ITEM_TREE, ACCT_TREE �벑 而⑤쾭�똿�쓣 �븘吏� 紐삵빐�꽌 �슦�꽑�� DEL_YN �벑�� 泥댄겕 �븞�븯怨� Auth type 媛��졇�샂
    OPEN pRESULT          
    FOR 
    SELECT IA.AUTH_TP_ID    AS ID
         , CL.LV_CD         AS CD
         , CL.LV_NM         AS CD_NM
         , CL.SEQ           AS SEQ
         , CL.LEAF_YN       AS LEAF_YN
      FROM (
        SELECT UI.EMP_ID, UI.AUTH_TP_ID
          FROM (
            SELECT UI.EMP_ID, UI.AUTH_TP_ID 
              FROM TB_DP_USER_ITEM_MAP UI
             INNER JOIN TB_CM_LEVEL_MGMT IL
                ON UI.LV_MGMT_ID = IL.ID
               AND IL.ACTV_YN = 'Y'
               AND COALESCE(IL.DEL_YN, 'N') = 'N'
               AND COALESCE(IL.ACCOUNT_LV_YN, 'N') = 'N'
               AND COALESCE(IL.SALES_LV_YN, 'N') = 'N'
               AND IL.LEAF_YN = 'Y'
             INNER JOIN TB_CM_ITEM_MST IM
                ON IM.ID = UI.ITEM_MST_ID
               AND IM.DP_PLAN_YN = 'Y'
               AND COALESCE(IM.DEL_YN, 'N') = 'N'
             WHERE UI.EMP_ID = V_USER_ID
            UNION
            SELECT UI.EMP_ID, UI.AUTH_TP_ID
              FROM TB_DP_USER_ITEM_MAP UI
             INNER JOIN TABLE(FN_DP_TEMP_ITEM_TREE()) TR
                ON TR.PATH_ID LIKE '%' || UI.ITEM_LV_ID || '%'
             INNER JOIN TB_CM_ITEM_MST IM
                ON IM.PARENT_ITEM_LV_ID = TR.LEAF_ITEM_LV_ID
               AND IM.DP_PLAN_YN = 'Y'
               AND COALESCE(IM.DEL_YN, 'N') = 'N'
             WHERE UI.EMP_ID = V_USER_ID
             GROUP BY EMP_ID, AUTH_TP_ID
          ) UI
         INNER JOIN (
            SELECT UA.EMP_ID, UA.AUTH_TP_ID
              FROM TB_DP_USER_ACCOUNT_MAP UA
             INNER JOIN TB_CM_LEVEL_MGMT IL
                ON UA.LV_MGMT_ID = IL.ID
               AND IL.ACTV_YN = 'Y'
               AND COALESCE(IL.DEL_YN, 'N') = 'N'
               AND COALESCE(IL.ACCOUNT_LV_YN, 'N') = 'Y'
               AND IL.LEAF_YN = 'Y'
             INNER JOIN TB_DP_ACCOUNT_MST AM
                ON UA.ACCOUNT_ID = AM.ID
               AND COALESCE(AM.DEL_YN, 'N') = 'N'
               AND AM.ACTV_YN = 'Y'
             WHERE UA.EMP_ID = V_USER_ID
            UNION
            SELECT UA.EMP_ID, UA.AUTH_TP_ID
              FROM TB_DP_USER_ACCOUNT_MAP UA
             INNER JOIN TABLE(FN_DP_TEMP_ACCT_TREE()) TR
                ON TR.PATH_ID LIKE '%' || UA.SALES_LV_ID || '%'
             INNER JOIN TB_DP_ACCOUNT_MST AM
                ON AM.PARENT_SALES_LV_ID = TR.LEAF_SALES_LV_ID
               AND COALESCE(AM.DEL_YN, 'N') = 'N'
               AND AM.ACTV_YN = 'Y'
             WHERE UA.EMP_ID = V_USER_ID
             GROUP BY EMP_ID, AUTH_TP_ID
         ) UA
            ON UI.EMP_ID = UA.EMP_ID
           AND UI.AUTH_TP_ID = UA.AUTH_TP_ID
        UNION
        SELECT EMP_ID, AUTH_TP_ID
          FROM TB_DP_USER_ITEM_ACCOUNT_MAP IA
         INNER JOIN TB_CM_ITEM_MST IM
            ON IA.ITEM_MST_ID = IM.ID
           AND IM.DP_PLAN_YN = 'Y'
           AND COALESCE(IM.DEL_YN, 'N') = 'N'
         INNER JOIN TB_DP_ACCOUNT_MST AM
            ON IA.ACCOUNT_ID = AM.ID
           AND COALESCE(AM.DEL_YN, 'N') = 'N'
           AND AM.ACTV_YN = 'Y'
         WHERE EMP_ID = V_USER_ID
         GROUP BY EMP_ID, AUTH_TP_ID
        UNION
        SELECT SA.EMP_ID, SL.LV_MGMT_ID
          FROM TB_DP_SALES_AUTH_MAP SA
         INNER JOIN TB_DP_SALES_LEVEL_MGMT SL
            ON SL.ID = SA.SALES_LV_ID
           AND COALESCE(SL.DEL_YN, 'N') = 'N'
           AND SL.ACTV_YN = 'Y'
         WHERE EMP_ID = V_USER_ID
      ) IA
     INNER JOIN TB_CM_LEVEL_MGMT CL
        ON IA.AUTH_TP_ID = CL.ID
     ORDER BY SEQ
    ;

ELSIF P_UI_ID = 'UI_DP_26_CHART' OR P_UI_ID = 'UI_DP_96_CHART' THEN
    OPEN pRESULT
    FOR
    SELECT A.ID
         , A.LV_CD AS CD
         , A.LV_NM AS CD_NM
         , A.SEQ
      FROM (
        SELECT LM.ID 
             , LM.LV_CD
             , LM.LV_NM
             , LM.SEQ
          FROM TB_CM_COMM_CONFIG CO
             , TB_CM_LEVEL_MGMT LM
         WHERE CO.CONF_GRP_CD = 'DP_LV_TP'
           AND CO.ACTV_YN = 'Y'
           AND CO.CONF_CD = 'S'
           AND CO.ID = LM.LV_TP_ID
           AND COALESCE(LM.DEL_YN, 'N') = 'N'
           AND LM.ACTV_YN = 'Y'
           AND LM.SALES_LV_YN = 'Y'
      ) A
    ;
ELSE
    OPEN pRESULT          
    FOR SELECT A.ID
         , A.LV_CD AS CD
         , A.LV_NM AS CD_NM 
         , A.SEQ
      FROM 
          (
            SELECT   LM.ID 
                   , LM.LV_CD 
                   , LM.LV_NM 
                   , LM.SEQ
             FROM TB_CM_COMM_CONFIG CO
                , TB_CM_LEVEL_MGMT LM
            WHERE CO.CONF_GRP_CD =  'DP_LV_TP'
              AND CO.ACTV_YN = 'Y'
              AND CO.CONF_CD = 'S'
              AND CO.ID = LM.LV_TP_ID
              AND COALESCE(LM.DEL_YN, 'N') = 'N'
              AND LM.ACTV_YN = 'Y'
              AND LM.SALES_LV_YN = 'Y' 
              --AND LM.LEAF_YN = 'Y'
              AND LM.SEQ IN (          
                                     SELECT LM.SEQ
                                       FROM TB_CM_COMM_CONFIG CO
                                          , TB_CM_LEVEL_MGMT LM
                                          , TB_DP_SALES_LEVEL_MGMT SL
                                          , TB_DP_SALES_AUTH_MAP SA 
                                      WHERE CO.CONF_GRP_CD =  'DP_LV_TP'
                                        AND CO.ACTV_YN = 'Y'
                                        AND CO.CONF_CD = 'S'
                                        AND CO.ID = LM.LV_TP_ID
                                        AND COALESCE(LM.DEL_YN, 'N') = 'N'
                                        AND LM.ACTV_YN = 'Y'
                                        AND LM.SALES_LV_YN = 'Y'
                                        AND LM.ID = SL.LV_MGMT_ID
                                        AND SL.ID  = SA.SALES_LV_ID
                                        AND SA.EMP_ID = V_USER_ID  -- '6CE1034002E54DB6A1A88E568D082B5E'
                                        AND (SA.STRT_DATE_AUTH is null or  SA.STRT_DATE_AUTH <= SYSDATE)
                                        AND (SA.END_DATE_AUTH is null or SA.END_DATE_AUTH >= SYSDATE)
                                    ) 
            UNION 
            -- default Sales Man 
            SELECT  LM.ID
                  , LM.LV_CD
                  , LM.LV_NM
                  , LM.SEQ
             FROM TB_CM_COMM_CONFIG CO
                , TB_CM_LEVEL_MGMT LM
            WHERE CO.CONF_GRP_CD =  'DP_LV_TP'
              AND CO.ACTV_YN = 'Y'
              AND CO.CONF_CD = 'S'
              AND CO.ID = LM.LV_TP_ID
              AND COALESCE(LM.DEL_YN, 'N') = 'N'
              AND LM.ACTV_YN = 'Y'
              AND LM.SALES_LV_YN = 'Y' 
              AND LM.LEAF_YN = 'Y'
           )  A
    ORDER BY A.SEQ 
    ; 
END IF;


END
;

/

