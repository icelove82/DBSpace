create PROCEDURE "SP_UI_CM_13_POP_02_S2" (
     P_WRK_TYPE             IN VARCHAR2 :=''
	,P_WH_MGMT_DTL_ID		IN VARCHAR2	:= null
    ,P_LOCAT_MGMT_ID        IN CHAR:=''
    ,P_WAREHOUSE_TP_ID      IN CHAR :=''
	,P_PALLET_LAYER			IN VARCHAR2 := null
	,P_LIMIT_VAL			IN VARCHAR2 := null
	,P_USER_ID				IN VARCHAR2 := null
    ,P_RT_ROLLBACK_FLAG		OUT VARCHAR2
    ,P_RT_MSG				OUT VARCHAR2
)
IS  
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG  VARCHAR2(4000) :='';
    P_WH_MGMT_DTL_ID_TEMP VARCHAR(32) := P_WH_MGMT_DTL_ID;
    P_WAREHOUSE_MGMT_ID CHAR(32) :=NULL;

BEGIN
    BEGIN
        SELECT A.ID INTO P_WAREHOUSE_MGMT_ID 
        FROM TB_CM_SITE_WAREHOUSE_MGMT A
        WHERE A.LOCAT_MGMT_ID = P_LOCAT_MGMT_ID
        AND A.WAREHOUSE_TP_ID = P_WAREHOUSE_TP_ID;
    EXCEPTION
    WHEN NO_DATA_FOUND
        THEN NULL;
    END;
    
    P_RT_MSG := 'MSG_0001';
    
    IF P_WAREHOUSE_MGMT_ID IS NOT NULL THEN
        IF P_WRK_TYPE = 'SAVE' THEN
            MERGE INTO TB_CM_SITE_WH_MGMT_DTL B 
            USING (SELECT P_WH_MGMT_DTL_ID_TEMP AS DTL_ID FROM DUAL) A
                    ON    ( A.DTL_ID = B.ID)
            WHEN MATCHED THEN
             UPDATE 
                SET PALLET_LAYER	= P_PALLET_LAYER
                  , LIMIT_VAL		= P_LIMIT_VAL
                  , MODIFY_BY		= P_USER_ID 
                  , MODIFY_DTTM		= SYSDATE                
            WHEN NOT MATCHED THEN			
                INSERT (
                    ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
                    ,SITE_WAREHOUSE_MGMT_ID
                    ,PALLET_LAYER
                    ,LIMIT_VAL
                    )
                VALUES 
                    (
                    TO_SINGLE_BYTE(SYS_GUID()), P_USER_ID, SYSDATE, P_USER_ID, SYSDATE
                    ,P_WAREHOUSE_MGMT_ID		
                    ,P_PALLET_LAYER
                    ,P_LIMIT_VAL	
                );
    
        ELSIF P_WRK_TYPE = 'DELETE' THEN
            DELETE FROM TB_CM_SITE_WH_MGMT_DTL 
            WHERE SITE_WAREHOUSE_MGMT_ID = P_WAREHOUSE_MGMT_ID;
    
            P_RT_MSG := 'MSG_0002' ;
        END IF;
    END IF;

     P_RT_ROLLBACK_FLAG := 'true';
                    
EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;   
      ELSE
          RAISE;
      END IF; 
END;

/

