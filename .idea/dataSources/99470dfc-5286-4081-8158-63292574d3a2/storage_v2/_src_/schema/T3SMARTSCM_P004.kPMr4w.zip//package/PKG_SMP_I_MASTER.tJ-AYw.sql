create PACKAGE                 PKG_SMP_I_MASTER
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved.
**************************************************************************
* Name    : PKG_SMP_I_MASTER
* Purpose : MP Static 정보 생성.
* Notes   :
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
IS
PRAGMA SERIALLY_REUSABLE;

PROCEDURE SP_SET_PLAN_OPTION (
  P_sENGINE_ID   IN  VARCHAR2 
, P_sVERSION_ID  IN  VARCHAR2  
, P_sBASE_MONTH  IN  VARCHAR2
, P_sPLAN_DESC   IN  VARCHAR2
, O_tPLAN_OPTION IN OUT TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
;

PROCEDURE SP_SET_WORK_DEMAND ( 
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_WORK_FIXED_ORD (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_WORK_BOM (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_WORK_BOR (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_VERIFY_DATA (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
;
/* Working Table : 2020-04-21 09:28
1.-------------------------------------------------------------------------------------------------
  CREATE TABLE TB_SMP_WK_BOM (  
  VERSION_ID       VARCHAR2(50) NOT NULL
 ,SITE_CD          VARCHAR2(50) NOT NULL
 ,P_ITEM_CD        VARCHAR2(50) NOT NULL
 ,C_ITEM_CD        VARCHAR2(50) NOT NULL
 ,P_UNIT_QTY       NUMBER
 ,P_UOM            VARCHAR2(50)
 ,C_UNIT_QTY       NUMBER
 ,C_UOM            VARCHAR2(50)
 ,P_ITEM_TYPE_CD   VARCHAR2(50)
 ,C_ITEM_TYPE_CD   VARCHAR2(50)
 ,CONTINENT_CD     VARCHAR2(50) 
 ,P_ROUTE_CD       VARCHAR2(10) 
 ,C_ROUTE_CD       VARCHAR2(10) 
 ,P_INVENTORY_ID   VARCHAR2(50)
 ,C_INVENTORY_ID   VARCHAR2(50)
 ,ROUTE_ID         VARCHAR2(50)
 ,T_CONTINENT_CD   VARCHAR2(50) 
 ,LEAD_TIME        NUMBER
 ,P_CELL_CD        VARCHAR2(50)
 ,REF_CELL_ITEM_CD VARCHAR2(50) 
 ,USE_FLAG         CHAR(1) DEFAULT 'Y'
 ,ELEC_CAL_HIS     VARCHAR2(600)
 ,REG_DTTM         DATE 
 ,REG_USER_ID      NVARCHAR2(50)
 ,UPDATE_DTTM      DATE
 ,UPDATE_USER_ID   NVARCHAR2(50)  
 ,CONSTRAINT PK_TB_SMP_WK_BOM PRIMARY KEY (VERSION_ID, SITE_CD, P_ITEM_CD, C_ITEM_CD, ROUTE_ID)
 ) ; 
 
 2.-------------------------------------------------------------------------------------------------
 CREATE TABLE SKISCM.TB_SMP_WK_BOR (
  VERSION_ID               VARCHAR2(50) NOT NULL
 ,ROUTE_ID                 VARCHAR2(50) NOT NULL
 ,LINE_CD                  VARCHAR2(50) NOT NULL
 ,ITEM_CD                  VARCHAR2(50)
 ,EFFICIENCY               NUMBER
 ,PROCESS_CAPACITY         NUMBER
 ,CONTINENT_CD             VARCHAR2(10) 
 ,SITE_CD                  VARCHAR2(50)
 ,ROUTE_CD                 VARCHAR2(50)
 ,BUILDING_NO              VARCHAR2(50)
 ,LINE_NO                  VARCHAR2(50)
 ,VALID_START_DATE         VARCHAR2(8)
 ,VALID_FINISH_DATE        VARCHAR2(8)
 ,CELL_CD                  VARCHAR2(50)
 ,POLAR_DIRECTION_CD       VARCHAR2(50)
 ,WIDTH_TYPE_CD            VARCHAR2(50) 
 ,FULL_JC_1ST_VAL          NUMBER
 ,FULL_JC_2ND_VAL          NUMBER
 ,SEMI_JC_1ST_VAL          NUMBER
 ,SEMI_JC_2ND_VAL          NUMBER
 ,LEAD_TIME                NUMBER
 ,WIDTH_VAL                NUMBER
 ,LENGTH_VAL               NUMBER
 ,THICKNESS_VAL            NUMBER
 ,CERTIF_MONTH             VARCHAR2(6)
 ,CERTIF_YN                CHAR(1)
 ,REG_DTTM                 DATE
 ,REG_USER_ID              VARCHAR2(50)
 ,UPDATE_DTTM              DATE
 ,UPDATE_USER_ID           VARCHAR2(50)
 ,CONSTRAINT PK_TB_SMP_WK_BOR PRIMARY KEY (VERSION_ID, ROUTE_ID, LINE_CD)
);
3.-------------------------------------------------------------------------------------------------
CREATE TABLE SKISCM.TB_SMP_WK_DEMAND (
  VERSION_ID               VARCHAR2(50 ) NOT NULL
 ,DEMAND_ID                VARCHAR2(100) NOT NULL  -- pgm + yyyymm
 ,INVENTORY_ID             VARCHAR2(100) NOT NULL  -- item_cd + t_continent_cd
 ,QTY                      NUMBER
 ,DUE_DATE                 DATE          NOT NULL
 ,PST                      DATE
 ,PRIORITY                 NUMBER
 ,DEMAND_TYPE              VARCHAR2(20 )           -- SO Month, SO Year, Cofirmed Plan ?? 
 ,DEMAND_BUCKET_TYPE       VARCHAR2(50 )
 ,ELEC_ROUTE_PST           DATE
 ,ASSY_ROUTE_PST           DATE
 ,BASE_MONTH               VARCHAR2(10 ) NOT NULL
 ,COLOR                    VARCHAR2(20 )
 ,PGM_D_CD                 VARCHAR2(50 ) NOT NULL
 ,PGM_STATUS_CD            VARCHAR2(50) 
 ,T_CONTINENT_CD           VARCHAR2(50 ) NOT NULL
 ,ITEM_CD                  VARCHAR2(50 ) NOT NULL 
 ,CELL_CD                  VARCHAR2(50 ) 
 ,CELL_ITEM_CD             VARCHAR2(50 )
 ,POLAR_DIRECTION_CD       VARCHAR2(50)
 ,WIDTH_TYPE_CD            VARCHAR2(50)  
 ,SVC_LVL_VAL              NUMBER
 ,OEM_CD                   VARCHAR2(50)
 ,USE_FLAG                 VARCHAR2(1) DEFAULT 'Y'
 ,VERIFY_DATA              VARCHAR2(300)
 ,REG_DTTM                 DATE
 ,REG_USER_ID              VARCHAR2(50)
 ,UPDATE_DTTM              DATE
 ,UPDATE_USER_ID           VARCHAR2(50)
 ,CONSTRAINT PK_TB_SMP_WK_DEMAND PRIMARY KEY (VERSION_ID, DEMAND_ID)
);
4.-------------------------------------------------------------------------------------------------
  CREATE TABLE TB_SMP_WK_FIXED_PROD (
   VERSION_ID             VARCHAR2(50) NOT NULL
  ,FIXED_ORDER_ID         VARCHAR2(50) NOT NULL
  ,SITE_CD                VARCHAR2(50) NOT NULL 
  ,ITEM_CD                VARCHAR2(50) NOT NULL 
  ,LINE_CD                VARCHAR2(50) NOT NULL 
  ,PLAN_MONTH             VARCHAR2(6 ) NOT NULL 
  ,OEM_CD                 VARCHAR2(50)  
  ,CELL_CD                VARCHAR2(50)  
  ,QTY                    NUMBER  
  ,REG_DTTM               DATE
  ,REG_USER_ID            VARCHAR2(50)
  ,UPDATE_DTTM            DATE
  ,UPDATE_USER_ID         VARCHAR2(50)
  ,CONSTRAINT PK_TB_SMP_WK_FIXED_PROD PRIMARY KEY (VERSION_ID, FIXED_ORDER_ID)  
);
5.-------------------------------------------------------------------------------------------------
CREATE TABLE TB_SMP_WK_PLAN_OPTION
( VERSION_ID                VARCHAR2(50)
 ,CONFIG_ID                 VARCHAR2(100)
 ,CONFIG_VALUE              VARCHAR2(100)
 ,CONFIG_DESC               VARCHAR2(1000)
 ,ATTR_1                    VARCHAR2(100)
 ,ATTR_2                    VARCHAR2(100)
 ,ATTR_3                    VARCHAR2(100)
 ,ATTR_4                    VARCHAR2(100)
 ,ATTR_5                    VARCHAR2(100)
 ,REG_DTTM                  DATE  DEFAULT SYSDATE 
 ,REG_USER_ID               NVARCHAR2(50)
 ,UPDATE_DTTM               DATE
 ,UPDATE_USER_ID            NVARCHAR2(50)  
 ,CONSTRAINT PK_TB_SMP_WK_PLAN_OPTION PRIMARY KEY (VERSION_ID, CONFIG_ID) 
);
6.-------------------------------------------------------------------------------------------------
CREATE OR REPLACE TYPE TP_SMP_PLAN_OPTION AS OBJECT(
  VERSION_ID                VARCHAR2(50)
 ,BASE_MONTH                VARCHAR2(6)
 ,ENGINE_ID                 VARCHAR2(50)
 ,START_DATE                DATE 
 ,END_DATE                  DATE
 ,PLAN_DESC                 VARCHAR2(1000)
 --*TB_CM_COMM_CONFIG--------------------------------------------
 ,CUTOFF_DATE               VARCHAR2(8)
 --
 ,PLAN_PST_MONTH            NUMBER -- 선행생산기준 (개월 수)
 ,ROLLING_HORIZON_MONTH     NUMBER -- 신규 Rolling 기준월
 ,MAT_CONSTRAINT_MONTH      NUMBER -- 유한자재제약 적용 (개월수)
 --
 ,BUCKET_1_MONTH_VAL        NUMBER -- MONTH
 ,BUCKET_2_MONTH_VAL        NUMBER -- MONTH
 ,BUCKET_3_MONTH_VAL        NUMBER -- MONTH
 ,BUCKET_2_START_DATE       DATE --* 월 구간 시작일
 ,BUCKET_3_START_DATE       DATE --* 년 구간 시작일
 -------------------------------------------------------------------  
 ,REF_VERSION_ID            VARCHAR2(50)  --이전 버전 DATA 사용시 해당 버전 정보
 -------------------------------------------------------------------
 ,ELEC_ROUTE_CD             VARCHAR2(50)  --MP 전극공정
 ,ASSY_ROUTE_CD             VARCHAR2(50)  --MP 조립공정
 ,BOD_ROUTE_CD              VARCHAR2(50)  --BOD 가상 공정코드
 --
 ,PROGRESS_ORDER_YN         CHAR(1) -- 수주추진 오더 포함 여부
 ,CONSTRAINT_ELEC_YN        CHAR(1) -- 전극Capa. 제약 여부           
 ,CONSTRAINT_MAT_YN         CHAR(1) -- 자재제약 여부
 --
 ,APPLY_SVC_LEVEL_YN        CHAR(1)
 ,USED_BOM_TYPE             VARCHAR2(30) -- PLAN_BOM : 전극자재를 조립에 붙임 / MFG_BOM : BOM구조대로 적용
 ,USED_STOCK_YN             CHAR(1)      -- 재고 반영 여부
 ,USED_FIXED_PLAN_YN        CHAR(1)      -- 확정 계획 반영 여부 
 ,USED_DYNAMIC_RATE_YN      CHAR(1)      -- DYNAMIC RATE 반영여부
 -------------------------------------------------------------------
 ,PGM_COMPILE_VER           VARCHAR2(50) -- 현재 최종 사용중인 프로그램 버전
 ,PGM_RUNNING_VER           VARCHAR2(50) -- 실행 프로그램  버전  
  --> Default로 위 2개 버전이 일치 모든 프로그램 실행, 만약 특정 부분 프로그램 테스트시 running 버번을 달리하여 실행 
 ,CONSTRUCTOR FUNCTION TP_SMP_PLAN_OPTION RETURN SELF AS RESULT
)
;
CREATE OR REPLACE TYPE BODY TP_SMP_PLAN_OPTION 
AS
  CONSTRUCTOR FUNCTION TP_SMP_PLAN_OPTION RETURN SELF AS RESULT
  AS 
  BEGIN 
    RETURN;
  END;
END;
 */
END PKG_SMP_I_MASTER;
/

