create PROCEDURE "SP_UI_DP_23_VER_CREATE_S2" (
              P_VER_ID                       IN  VARCHAR2 :=''
            , P_PLAN_TP_ID                   IN  CHAR     :=''
			, P_CNTRL_BOARD_MST_ID 			 IN  CHAR     :=''
			, P_MODULE_ID 					 IN  VARCHAR2 :=''
			, P_WORK_CD 					 IN  VARCHAR2 :=''
			, P_WORK_NM 					 IN  VARCHAR2 :=''
			, P_DESCRIP 					 IN  VARCHAR2 :=''
			, P_SEQ 						 IN  VARCHAR2 :=''
			, P_WORK_TP_ID 					 IN  CHAR     :=''
			, P_LINK 						 IN  VARCHAR2 :=''
			, P_LV_MGMT_ID 					 IN  CHAR     :=''
			, P_INIT_VAL_TP_ID 				 IN  CHAR     :=''
			, P_INIT_VAL_ID 		 IN  CHAR     :=''
			, P_INPUT_TP_ID 				 IN  CHAR     :=''
			, P_CONST_INPUT_YN				 IN  VARCHAR2 :=''
			, P_INIT_CONST_INPUT_DATETIME	 IN  DATE     :=''
			, P_APPV_CONST_ID				 IN  CHAR     :=''
			, P_APPV_EVENT_ID				 IN  CHAR     :=''
			, P_AUTO_APPV_YN				 IN  VARCHAR2 :=''
			, P_INIT_AUTO_APPV_DATETIME		 IN  DATE     :=''
			, P_CANC_CONST_ID				 IN  CHAR     :=''
			, P_CANC_EVENT_ID				 IN  CHAR     :=''
			, P_CL_TP_ID					 IN  CHAR     :=''
			, P_CL_LV_MGMT_ID				 IN  CHAR     :=''
			, P_USER_ID						 IN  VARCHAR2 :=''
			, P_RT_ROLLBACK_FLAG			 OUT VARCHAR2 
			, P_RT_MSG						 OUT VARCHAR2 
)IS
		P_ERR_STATUS INT := 0; 
        P_ERR_MSG VARCHAR2(4000):='';
        V_VER_MST_ID VARCHAR2(32) :='';    
        V_CHECK VARCHAR2(50):='';
BEGIN
    SELECT COUNT(ID)  INTO P_ERR_STATUS
      FROM TB_DP_CONTROL_BOARD_VER_MST
     WHERE VER_ID = P_VER_ID
     ;    
     IF (P_ERR_STATUS = 0)
        THEN
	    P_ERR_MSG := 'Version Info is not valid.'; 
	    RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);               
    ELSE
        SELECT ID  INTO V_VER_MST_ID
          FROM TB_DP_CONTROL_BOARD_VER_MST
         WHERE VER_ID = P_VER_ID
         ;
     END IF
     ; 

     SELECT COUNT(INIT_VAL_ID) INTO V_CHECK
       FROM (
               SELECT   CM.ID                                    AS INIT_VAL_TP_ID
                          , CM.CONF_GRP_CD                           AS TP
                          , CM.CONF_CD                               AS TP_CD
                          , 'CF_'||CM.CONF_GRP_CD||'_'||CM.CONF_CD   AS TP_NM
                          ------------------------------------------------------------
                          , INIT_VAL_ID AS INIT_VAL_ID
                          , VAL_CD AS VAL_CD
                          , VAL_NM AS VAL_NM
                          , VAL_SEQ       
                    FROM  TB_CM_CONFIGURATION CF
                          INNER JOIN
                          TB_CM_COMM_CONFIG CM
                       ON CF.ID = CM.CONF_ID
                      AND CM.CONF_GRP_CD = 'DP_INIT_VAL_TP'
                      AND CM.ACTV_YN = 'Y'   
                          LEFT OUTER JOIN
                          (
                           SELECT CL.ID            AS INIT_VAL_ID
                                , CL.LV_CD         AS VAL_CD
                                , CL.LV_NM         AS VAL_NM
                                , CL.SEQ           AS VAL_SEQ
                                , 'PR'             AS CONF_CD
                             FROM TB_CM_LEVEL_MGMT CL
                            WHERE CL.SALES_LV_YN = 'Y'
                              AND COALESCE(CL.DEL_YN,'N') != 'Y'
                              AND CL.ACTV_YN ='Y'
                           UNION
                           SELECT MS.ID            AS INIT_VAL_ID
                                , MS.MEASURE_CD    AS VAL_CD
                                , MS.MEASURE_CD    AS VAL_NM
                                , 0                AS VAL_SEQ
                                , 'MS'             AS CONF_CD
                             FROM TB_DP_MEASURE_MST MS
                            WHERE MS.DP_YN ='Y'
                              AND NVL(MS.DEL_YN,'N')   = 'N'
                          ) VL ON VL.CONF_CD = CM.CONF_CD
               --     WHERE CM.ID = P_INIT_VAL_TP_ID 
               --       OR P_INIT_VAL_TP_ID IS NULL
                    ORDER BY VAL_NM
               )
     WHERE 1=1
       AND TP_CD='MS'
       AND INIT_VAL_ID=P_INIT_VAL_ID
     ;

     IF ( V_CHECK>0 )
     THEN
          INSERT INTO TB_DP_CONTROL_BOARD_VER_DTL 
			   (
			   ID
			   ,CONBD_VER_MST_ID
			   ,MODULE_ID
			   ,WORK_CD
			   ,WORK_NM
			   ,SEQ
			   ,DESCRIP
			   ,WORK_TP_ID
			   ,LINK
			   ,LV_MGMT_ID
			   ,INIT_VAL_TP_ID
			   ,INIT_FIXED_LV_MGMT_ID
			   ,INPUT_TP_ID
			   ,CONST_INPUT_YN
			   ,CONST_INPUT_DATE    
			   ,APPV_CONST_ID
			   ,APPV_EVENT_ID
			   ,AUTO_APPV_YN
			   ,AUTO_APPV_DATE  
			   ,CANC_CONST_ID
			   ,CANC_EVENT_ID
			   ,CL_TP_ID
			   ,CL_LV_MGMT_ID
			   ,CL_STATUS_ID
                  ,PLAN_TP_ID
			   ,CREATE_BY
			   ,CREATE_DTTM
                  ,INIT_MEASURE_ID
			   )VALUES(
                 TO_SINGLE_BYTE(SYS_GUID()) 
                ,V_VER_MST_ID              
                ,P_MODULE_ID
                ,P_WORK_CD
                ,P_WORK_NM
                ,P_SEQ
                ,P_DESCRIP
                ,P_WORK_TP_ID
                ,P_LINK
                ,P_LV_MGMT_ID
                ,P_INIT_VAL_TP_ID
                ,NULL
                ,P_INPUT_TP_ID
                ,P_CONST_INPUT_YN
                ,P_INIT_CONST_INPUT_DATETIME  
                ,P_APPV_CONST_ID
                ,P_APPV_EVENT_ID
                ,P_AUTO_APPV_YN
                ,P_INIT_AUTO_APPV_DATETIME
                ,P_CANC_CONST_ID
                ,P_CANC_EVENT_ID
                ,P_CL_TP_ID
                ,P_CL_LV_MGMT_ID
                ,(SELECT ID 
                    FROM   TB_CM_COMM_CONFIG 
                    WHERE  CONF_GRP_CD = 'DP_CL_STATUS' 
                        AND CONF_CD = 'READY') 
                ,P_PLAN_TP_ID
                ,p_USER_ID                    
                ,SYSDATE         
                ,P_INIT_VAL_ID
               );
     ELSE
                    INSERT INTO TB_DP_CONTROL_BOARD_VER_DTL 
			   (
			   ID
			   ,CONBD_VER_MST_ID
			   ,MODULE_ID
			   ,WORK_CD
			   ,WORK_NM
			   ,SEQ
			   ,DESCRIP
			   ,WORK_TP_ID
			   ,LINK
			   ,LV_MGMT_ID
			   ,INIT_VAL_TP_ID
			   ,INIT_FIXED_LV_MGMT_ID
			   ,INPUT_TP_ID
			   ,CONST_INPUT_YN
			   ,CONST_INPUT_DATE    
			   ,APPV_CONST_ID
			   ,APPV_EVENT_ID
			   ,AUTO_APPV_YN
			   ,AUTO_APPV_DATE  
			   ,CANC_CONST_ID
			   ,CANC_EVENT_ID
			   ,CL_TP_ID
			   ,CL_LV_MGMT_ID
			   ,CL_STATUS_ID
                  ,PLAN_TP_ID
			   ,CREATE_BY
			   ,CREATE_DTTM
                  ,INIT_MEASURE_ID
			   )VALUES(
                 TO_SINGLE_BYTE(SYS_GUID()) 
                ,V_VER_MST_ID              
                ,P_MODULE_ID
                ,P_WORK_CD
                ,P_WORK_NM
                ,P_SEQ
                ,P_DESCRIP
                ,P_WORK_TP_ID
                ,P_LINK
                ,P_LV_MGMT_ID
                ,P_INIT_VAL_TP_ID
                ,P_INIT_VAL_ID
                ,P_INPUT_TP_ID
                ,P_CONST_INPUT_YN
                ,P_INIT_CONST_INPUT_DATETIME  
                ,P_APPV_CONST_ID
                ,P_APPV_EVENT_ID
                ,P_AUTO_APPV_YN
                ,P_INIT_AUTO_APPV_DATETIME
                ,P_CANC_CONST_ID
                ,P_CANC_EVENT_ID
                ,P_CL_TP_ID
                ,P_CL_LV_MGMT_ID
                ,(SELECT ID 
                    FROM   TB_CM_COMM_CONFIG 
                    WHERE  CONF_GRP_CD = 'DP_CL_STATUS' 
                        AND CONF_CD = 'READY') 
                ,P_PLAN_TP_ID
                ,p_USER_ID                    
                ,SYSDATE         
                ,NULL
               );
     END IF;

        INSERT INTO TB_DP_CONTROL_BOARD_VER_INIT					
			( ID
			 ,CONBD_VER_DTL_ID
			 ,MS_VAL_TP_CD
			 ,INIT_VAL_TP_ID
			 ,INIT_FIXED_LV_MGMT_ID	
			 ,INIT_MEASURE_ID		
			)
			SELECT TO_SINGLE_BYTE(SYS_GUID()) AS ID
				 , D.ID						 AS CONBD_VER_DTL_ID
--			     , M.WORK_CD				-- REFERENCE
				 , I.MS_VAL_TP_CD			 AS MS_VAL_TP_CD
				 , I.INIT_VAL_TP_ID			 AS INIT_VAL_TP_ID
				 , I.INIT_FIXED_LV_MGMT_ID	 AS INIT_FIXED_LV_MGMT_ID	
				 , I.INIT_MEASURE_ID		 AS	INIT_MEASURE_ID		
			  FROM TB_DP_CONTROL_BOARD_MST_INIT I
				   INNER JOIN
				   TB_DP_CONTROL_BOARD_MST M
				ON M.ID = I.CONBD_MST_ID
				   INNER JOIN
				   TB_DP_CONTROL_BOARD_VER_DTL D
				ON D.WORK_CD = M.WORK_CD
			   AND D.CONBD_VER_MST_ID =  v_VER_MST_ID --'DD91D77C3FD4442EAD202BCAC869FBCC'
			   AND D.WORK_cD = p_WORK_CD
 				   INNER JOIN
				   TB_CM_COMM_CONFIG C
				ON I.MS_VAL_tP_CD = C.CONF_CD
			  AND C.ACTV_YN = 'Y'
			  AND C.CONF_GRP_CD = 'DP_MS_VAL_TP'
            ;


	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  --AuAa ？？C？？u？？A？？I？？U.
       /* ？？？？？？U A？？？？？？ ============================================================================*/

       EXCEPTION    
        WHEN OTHERS THEN  -- ？？I？？？？ A？？AC？？CAo ？？EA？？ ？？？？？？U ？？c？？e : e_products_invalid    
              DELETE 
                FROM TB_DP_CONTROL_BOARD_VER_MST
               WHERE VER_ID = RTRIM(P_VER_ID)
              ;
              DELETE 
                FROM TB_DP_CONTROL_BOARD_VER_DTL
               WHERE CONBD_VER_MST_ID = V_VER_MST_ID
              ;

              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                SP_COMM_RAISE_ERR();              
                --RAISE;
              END IF; 

END;

/

