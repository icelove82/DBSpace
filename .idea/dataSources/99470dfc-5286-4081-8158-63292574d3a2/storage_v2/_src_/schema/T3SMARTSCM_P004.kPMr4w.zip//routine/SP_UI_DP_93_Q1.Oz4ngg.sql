create PROCEDURE SP_UI_DP_93_Q1
(
	 p_VERSION_CD   VARCHAR2
	,p_PLAN_TP_ID	VARCHAR2
    ,pRESULT        OUT SYS_REFCURSOR
) 
IS 

BEGIN

    OPEN pRESULT FOR
    WITH DP_STATUS AS  (   
        SELECT DISTINCT ANCS_ROLE_ID	as AUTH_TP_ID
                      , ANCS_ROLE_CD    AS AUTH_TP_CD 
                      , ANCS_CD			AS EMP_CD 
          FROM TB_DPD_USER_HIER_CLOSURE		  
    ), 
    DP_PROCESS AS (
        SELECT DISTINCT 
               AUTH_TYPE
             , OPERATOR_ID		 
             , MAX(STATUS) OVER (PARTITION BY AUTH_TYPE, OPERATOR_ID  ORDER BY STATUS_DATE DESC) AS STATUS
          FROM TB_DP_PROCESS_STATUS_LOG
         WHERE VER_CD = p_VERSION_CD
    )
    SELECT   CB.ID
            ,CB.CONBD_VER_MST_ID
            ,CB.WORK_CD
            ,CB.WORK_NM
            ,CB.DESCRIP
            ,CO.CONF_CD    AS WORK_TP_ID
            --STATUS
            /* TAB_Q2 프로시저의 COLUMN 추가 20180702*/
            ,CB.LV_MGMT_ID 
            ,CB.INIT_VAL_TP_ID
            --,CB.INIT_FIXED_LV_MGMT_ID
            ,CASE WHEN CB.INIT_FIXED_LV_MGMT_ID is null  THEN CB.INIT_MEASURE_ID
                  ELSE INIT_FIXED_LV_MGMT_ID END AS INIT_VAL_ID
            ,CB.INPUT_TP_ID
            --,CB.INIT_INPUT_STRT_VAL 
            --,CB.INPUT_STRT_DATE
            --,CB.INIT_INPUT_END_VAL
            --,CB.INPUT_END_DATE
            ,CB.CONST_INPUT_YN
            ,CB.CONST_INPUT_DATE          
            ,CB.APPV_CONST_ID
            ,CB.APPV_EVENT_ID
            ,CB.AUTO_APPV_YN
            ,CB.AUTO_APPV_DATE
    --		,CB.CANC_CONST_ID
    --		,CB.CANC_EVENT_ID
            /****************************/
            ,CB.LINK        AS UI_ID
            ,CB.SEQ
            ,CB.CREATE_DTTM
            ,CB.MODIFY_BY
            ,CB.MODIFY_DTTM
            ,case when  LV.LV_CD is Not Null then LV.LV_CD ELSE  ST.CONF_CD END AS LV_CD       --AUTH_TP에 대한 CD값(AUTH_TP별 STATUS 확인을 위함)
            ,( SELECT CASE WHEN COUNT(S.EMP_CD)= 0 THEN ST.CONF_NM 
                           --ELSE CONVERT(VARCHAR2(4), COUNT(P.OPERATOR_ID))||'/'|| CONVERT(VARCHAR2(4), COUNT(S.EMP_CD)) 
                           ELSE CAST(COUNT(P.OPERATOR_ID) AS VARCHAR2(4))||'/'|| CAST(COUNT(S.EMP_CD) AS VARCHAR2(4))
                      END 
                  FROM DP_STATUS S
                       LEFT OUTER JOIN
                       DP_PROCESS P
                    ON S.AUTH_TP_CD = P.AUTH_TYPE
                   AND S.EMP_CD = P.OPERATOR_ID
                   AND P.STATUS = 'APPROVAL'
                 WHERE S.AUTH_TP_ID = CB.LV_MGMT_ID	
              )	AS STATUS
    FROM    TB_DP_CONTROL_BOARD_VER_DTL CB 
            LEFT OUTER JOIN 
            TB_DP_CONTROL_BOARD_VER_MST CM 
         ON CB.CONBD_VER_MST_ID = CM.ID 
            LEFT OUTER JOIN 
            TB_CM_COMM_CONFIG CO 
         ON CB.WORK_TP_ID = CO.ID AND CO.CONF_GRP_CD    = 'DP_WK_TP'
            LEFT OUTER JOIN 
            TB_CM_LEVEL_MGMT LV  
         ON LV.ID = CB.LV_MGMT_ID 
        AND LV.ACTV_YN = 'Y' 
        AND LV.SALES_LV_YN = 'Y' 
        AND COALESCE(LV.DEL_YN,'N') = 'N'
            LEFT OUTER JOIN 
            TB_CM_COMM_CONFIG   ST         
         ON  CB.CL_STATUS_ID = ST.ID
    WHERE    1=1
    AND        CM.VER_ID = p_VERSION_CD
    AND        CB.PLAN_TP_ID = p_PLAN_TP_ID
    ORDER BY CB.SEQ
    ;

END;
/

