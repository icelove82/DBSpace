create PROCEDURE "SP_UI_DP_37_Q1" (p_EMP_CD        IN VARCHAR2 := ''
									  , p_AUTH_TP_ID	  IN VARCHAR2 := ''
                                      , p_ITEM_CD    IN VARCHAR2 := ''
                                      , p_ITEM_NM    IN VARCHAR2 := ''
									  , p_ACCT_CD     IN VARCHAR2 := ''
									  , p_ACCT_NM     IN VARCHAR2 := ''
								             ,pRESULT       OUT SYS_REFCURSOR ) IS 


BEGIN
/*************************
Title : SP_DP_15_Q1
최초 작성자 : 민경훈
최초 생성일 : 2018.12.13
History (수정일자 / 수정자 / 수정내용)
- 2019.09.26 / 김소희 / UOM_NM 추가
- 2020.03.12 / Kim sohee / EMP_NO => USER_ID
--2020.12.22 / 민경훈 / MSSQL -> ORACLE
**************************/

		OPEN pRESULT          FOR 
        SELECT  IA.ID
			  , IA.AUTH_TP_ID
			  , LM.LV_CD AS AUTH_TP_CD
			  , LM.LV_NM AS AUTH_TP_NM
			  , IA.ACCOUNT_ID
			  , AM.ACCOUNT_CD
			  , AM.ACCOUNT_NM 
			  , IA.ITEM_MST_ID
			  , IM.ITEM_CD
			  , IM.ITEM_NM 
			  , C.UOM_CD as UOM_CD --C.UOM_CD
			  , C.UOM_NM
			  , IA.EMP_ID
			  , DE.USERNAME as USER_ID
			  , DE.USERNAME as EMP_NO
			  , DE.DISPLAY_NAME as EMP_NM 
			  , IA.CREATE_BY
			  , IA.CREATE_DTTM
			  , IA.MODIFY_BY
			  , IA.MODIFY_DTTM
		  FROM   TB_DP_USER_ITEM_ACCOUNT_EXCLUD IA
			   , TB_DP_ACCOUNT_MST AM 
			   , TB_CM_ITEM_MST IM 
			   , TB_CM_UOM C
			   , TB_CM_LEVEL_MGMT LM
			   , TB_AD_USER  DE
		WHERE IA.AUTH_TP_ID = LM.ID
		  AND IA.ACCOUNT_ID = AM.ID
		  AND IA.ITEM_MST_ID = IM.ID
		  AND IM.UOM_ID = C.ID		
		  AND C.ACTV_YN = 'Y'
		  AND IA.EMP_ID = DE.ID
		  AND DE.USERNAME = p_EMP_CD --'admin'
		  -- AUTH_TP_ID
		  AND IA.AUTH_TP_ID LIKE   '%' || p_AUTH_TP_ID || '%'
              AND  (  REGEXP_LIKE (UPPER(AM.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  p_ACCT_CD IS NULL
                    )
               AND  ( REGEXP_LIKE (UPPER(IM.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  P_ITEM_CD IS NULL
                    )
              AND   ( REGEXP_LIKE (UPPER(AM.ACCOUNT_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ACCT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  P_ACCT_NM IS NULL
                    )
               AND  ( REGEXP_LIKE (UPPER(IM.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  P_ITEM_NM IS NULL
                    )

         ORDER BY AM.ACCOUNT_CD, IM.ITEM_CD
;





END
;

/

