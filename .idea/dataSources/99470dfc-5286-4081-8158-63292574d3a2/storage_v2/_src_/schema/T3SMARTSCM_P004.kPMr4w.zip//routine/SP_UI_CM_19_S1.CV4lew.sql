create PROCEDURE SP_UI_CM_19_S1 (
    P_TRANSP_MGMT_DTL_ID        IN CHAR := ''
   ,P_YYYYMMDD                  IN CHAR := ''
   ,P_CONST_YN                  IN CHAR := ''
   ,P_USER_ID                   IN VARCHAR2 := ''
   ,P_RT_ROLLBACK_FLAG          OUT VARCHAR2
   ,P_RT_MSG                    OUT VARCHAR2
)IS
     P_ERR_STATUS NUMBER :=0;
     P_ERR_MSG  VARCHAR2(4000) :='';      
    BEGIN
        UPDATE TB_CM_ITEM_SHIP_LT_SCH
		SET  CONST_YN = P_CONST_YN
		   ,MODIFY_BY = P_USER_ID
		   ,MODIFY_DTTM = SYSDATE
		WHERE TRANSP_MGMT_DTL_ID = P_TRANSP_MGMT_DTL_ID
		AND   TO_CHAR(SHIP_DATE, 'yyyy-MM-dd') = P_YYYYMMDD;
    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';

    EXCEPTION
    WHEN OTHERS THEN
        IF(SQLCODE = -20012)
          THEN 
              P_RT_ROLLBACK_FLAG := 'false';
              P_RT_MSG := P_ERR_MSG;
          ELSE
              RAISE;
          END IF;

END;

/

