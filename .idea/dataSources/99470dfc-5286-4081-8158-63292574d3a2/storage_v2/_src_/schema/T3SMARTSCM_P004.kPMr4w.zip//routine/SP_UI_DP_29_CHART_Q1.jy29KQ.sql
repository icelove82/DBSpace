create PROCEDURE "SP_UI_DP_29_CHART_Q1" (
     p_PLAN_TP_ID	VARCHAR2
    ,p_BUCK			VARCHAR2
    ,p_STRT_DATE	DATE
    ,p_END_DATE		DATE
    ,p_USER_ID		VARCHAR2
    ,p_ITEM_CD		VARCHAR2
    ,p_ACCT_CD		VARCHAR2
    ,p_ITEM_LV_CD	VARCHAR2
    ,p_ACCT_LV_CD	VARCHAR2
    ,p_RT_MSG		OUT VARCHAR2
    ,pRESULT        OUT SYS_REFCURSOR
)IS

/*****************************************************************************
Title : [SP_UI_DP_29_CHART_Q1]
최초 작성자 : 한영석
최초 생성일 : 2017.12.06
 
설명 
 - DP Volatility 그래프 쿼리
 
History (수정일자 / 수정자 / 수정내용)
- 2017.12.06 / 한영석 / 최초 작성
- 2018.12.21 / 김소희 / MAIN SELECT문 컨버팅  
- 2020.10.13 / 김소희 / 속도 개선 
- 2020.12.21 / 민경훈 / MSSQL -> ORACLE
*****************************************************************************/

v_ERR_MSG		VARCHAR2(4000):='';
v_ERR_STATUS	INT := NULL;
v_BUCK			VARCHAR2(50) :='';
v_STRT_DATE	DATE := '';
v_END_DATE		DATE := '';
v_PLAN_TP_ID	VARCHAR2(100) :='';
v_ITEM_CD		VARCHAR2(4000) :='';
v_ACCT_CD		VARCHAR2(4000) :='';
v_DMND_ID		CHAR(32);

BEGIN 

	v_BUCK		    := COALESCE(p_BUCK, 'M');
	v_STRT_DATE	    := COALESCE(p_STRT_DATE , SYSDATE);
	v_END_DATE		:= COALESCE(p_END_DATE  , SYSDATE);
	v_PLAN_TP_ID	:= p_PLAN_TP_ID;
	v_ITEM_CD		:= p_ITEM_CD;
	v_ACCT_CD		:= p_ACCT_CD;

    SELECT CASE WHEN EXISTS(SELECT 1
                              FROM (
                                SELECT *
                                  FROM TB_RT_DMND_ORD_TRACKING_MST
                                 ORDER BY CREATE_DTTM DESC
                              )
                             WHERE ROWNUM=1
            ) THEN '1' ELSE '0' END INTO v_ERR_STATUS
      FROM DUAL;

    IF v_ERR_STATUS = '1'
    THEN
        SELECT CONBD_MAIN_VER_DTL_ID INTO v_DMND_ID
          FROM (
            SELECT *
              FROM TB_RT_DMND_ORD_TRACKING_MST
             ORDER BY CREATE_DTTM DESC
          )
         WHERE ROWNUM=1
        ;
    ELSE
        v_ERR_MSG :=SQLERRM;
        RAISE_APPLICATION_ERROR(-20001,v_ERR_MSG);
    END IF;

    OPEN pRESULT FOR
    WITH ITEM
    AS (
        SELECT DISTINCT DESCENDANT_ID
          FROM TB_DPD_ITEM_HIER_CLOSURE 
         WHERE LEAF_YN = 'Y' 
           AND (REGEXP_LIKE(UPPER(ANCESTER_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                            OR v_ITEM_CD IS NULL
                      )
--           AND CASE WHEN v_ITEM_CD LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(v_ITEM_CD,'') END IN (
--					SELECT TRIM(REGEXP_SUBSTR(v_ITEM_CD, '[^|]+', 1, LEVEL)) AS ITEM_CD
--						FROM DUAL
--					CONNECT BY INSTR(v_ITEM_CD, '|', 1, LEVEL - 1) > 0
--				)
--           AND CASE WHEN v_ITEM_CD NOT LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(v_ITEM_CD,'') END LIKE '%' || COALESCE(v_ITEM_CD,'') || '%'
    ), ACCT
    AS (
        SELECT DISTINCT DESCENDANT_ID 
          FROM TB_DPD_SALES_HIER_CLOSURE 
         WHERE LEAF_YN = 'Y' 
           AND (REGEXP_LIKE(UPPER(ANCESTER_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                            OR v_ACCT_CD IS NULL
                      )
--           AND CASE WHEN v_ACCT_CD LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(v_ACCT_CD,'') END IN (
--					SELECT TRIM(REGEXP_SUBSTR(v_ACCT_CD, '[^|]+', 1, LEVEL)) AS ACCT_CD
--						FROM DUAL
--					CONNECT BY INSTR(v_ACCT_CD, '|', 1, LEVEL - 1) > 0
--				)
--           AND CASE WHEN v_ACCT_CD NOT LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(v_ACCT_CD,'') END LIKE '%' || COALESCE(v_ACCT_CD,'') || '%'
    ), DP_HISTORY
    AS (
        SELECT ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, QTY 
          FROM TB_DP_ENTRY_HISTORY
         WHERE BASE_DATE BETWEEN v_STRT_DATE AND v_END_DATE	   
           AND PLAN_TP_ID = v_PLAN_TP_ID
           AND QTY > 0
    ), VER
    AS (SELECT DISTINCT DO.ITEM_MST_ID ,DO.ACCOUNT_ID 
          FROM DP_HISTORY DO 
               INNER JOIN
               ITEM IT 
            ON IT.DESCENDANT_ID = DO.ITEM_MST_ID
               INNER JOIN
               ACCT AM
            ON AM.DESCENDANT_ID = DO.ACCOUNT_ID   
    ), CALENDAR
    AS (
        SELECT DAT
             , CASE v_BUCK 
                WHEN 'MONTH'		THEN YYYYMM
                --WHEN 'PAR_WEEK'		THEN YYYYMM||'-'||CONVERT(VARCHAR2(2), DP_WK)
                --WHEN 'WEEK'			THEN YYYY||'-'||CONVERT(VARCHAR2(2), DP_WK) 
                WHEN 'PAR_WEEK'		THEN YYYYMM||'-'||CAST(DP_WK AS VARCHAR2(2))
                WHEN 'WEEK'			THEN YYYY||'-'||CAST(DP_WK AS VARCHAR2(2))
               END AS BUKT
          FROM TB_CM_CALENDAR
         WHERE  DAT BETWEEN v_STRT_DATE AND v_END_DATE	   
    ), CAL
    AS (SELECT MIN(DAT) AS STRT_DATE
             , MAX(DAT) AS END_DATE
             , BUKT
          FROM CALENDAR
      GROUP BY BUKT
    ), SALES
    AS (
        SELECT BASE_DATE
              ,QTY
              ,ITEM_MST_ID
              ,ACCOUNT_ID
         FROM TB_CM_ACTUAL_SALES
        WHERE BASE_DATE BETWEEN v_STRT_DATE AND v_END_DATE	  
          AND QTY > 0	 

    ), T_ACTUAL_SALES
    AS (
        SELECT STRT_DATE
             , sum(qty) qty 
          FROM  SALES A -- TB_CM_ACTUAL_SALES A 
                INNER JOIN
                VER 
             ON A.ITEM_MST_ID = VER.ITEM_MST_ID
            AND A.ACCOUNT_ID = VER.ACCOUNT_ID
                INNER JOIN 
                CAL CA
             ON A.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
    --	 WHERE QTY > 0							 
      GROUP BY STRT_DATE
    ), T_ANNUAL_DP
    AS (
        SELECT STRT_DATE, sum(ANNUAL_qty) qty 
          FROM 
            TB_DP_MEASURE_DATA A
                INNER JOIN
                VER 
             ON A.ITEM_MST_ID = VER.ITEM_MST_ID
            AND A.ACCOUNT_ID = VER.ACCOUNT_ID
            INNER JOIN  
            CAL CA
          ON A.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
         WHERE ANNUAL_QTY > 0 
    GROUP BY STRT_DATE
    ), T_FINAL_DP
    AS (
        SELECT STRT_DATE
             , sum(qty) qty 
             FROM DP_HISTORY A -- TB_DP_ENTRY_HISTORY A		
                  INNER JOIN
                  ITEM IT 
               ON IT.DESCENDANT_ID = A.ITEM_MST_ID
                  INNER JOIN
                  ACCT AM
               ON AM.DESCENDANT_ID = A.ACCOUNT_ID   
                  INNER JOIN
                  CAL CA
               ON A.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE	     
         GROUP BY STRT_DATE
    ), RTF
    AS (
        SELECT ITEM_MST_ID, ACCOUNT_ID, DELIVY_DATE, ON_TIME_QTY
          FROM TB_RT_DMND_ORD_TRACKING_MST
         WHERE CONBD_MAIN_VER_DTL_ID = v_DMND_ID
           AND ON_TIME_QTY > 0 
           AND DELIVY_DATE BETWEEN v_STRT_DATE AND v_END_DATE	  
    ), T_RTF
    AS (
        SELECT STRT_DATE, sum(ON_TIME_QTY) ON_TIME_QTY
          FROM TB_RT_DMND_ORD_TRACKING_MST A  -- RTF A -- 
                INNER JOIN
                VER 
             ON A.ITEM_MST_ID = VER.ITEM_MST_ID
            AND A.ACCOUNT_ID = VER.ACCOUNT_ID
               INNER JOIN
               CAL CA
            ON A.DELIVY_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
        GROUP BY STRT_DATE
    )
    SELECT   M.STRT_DATE						AS "DATE"
           , M.STRT_DATE						AS "CATEGORY"
           , COALESCE(T_ACTUAL_SALES.QTY, 0) 		AS ACT_SALES_QTY
           , COALESCE(T_ANNUAL_DP.QTY, 0) 		AS ANNUAL_QTY
           , COALESCE(T_RTF.ON_TIME_QTY, 0)  		AS RTF
           , COALESCE(T_FINAL_DP.QTY, 0) 			AS FINAL_DP_QTY
       FROM CAL M		
			LEFT OUTER JOIN
			T_ACTUAL_SALES
		 ON T_ACTUAL_SALES.STRT_DATE = M.STRT_DATE-- AND M.END_DATE
			LEFT OUTER JOIN 
			T_ANNUAL_DP 
		 ON T_ANNUAL_DP.STRT_DATE = M.STRT_DATE
			LEFT OUTER JOIN
			T_FINAL_DP 
		 ON T_FINAL_DP.STRT_DATE = M.STRT_DATE
            LEFT OUTER JOIN  
            T_RTF 
         ON T_RTF.STRT_DATE = M.STRT_DATE
		;

	p_RT_MSG :='MSG_0003';

    EXCEPTION WHEN OTHERS THEN  -- ?？? ???？？? ?？? ???？?？ : e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_MSG := sqlerrm;
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;   	
--END TRY
--BEGIN CATCH
--IF (ERROR_MESSAGE() LIKE 'MSG_%')
--	BEGIN
--		SET v_ERR_MSG = ERROR_MESSAGE()
--		SET p_RT_MSG = v_ERR_MSG
--	END
--ELSE 
--		THROW;
----		EXEC SP_COMM_RAISE_ERR

END;

/

