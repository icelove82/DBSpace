create FUNCTION                 FN_DP_TEMP_PR_VER
(
   P_VER_ID     IN CHAR
  ,P_PLAN_TP_ID IN CHAR
)
/**********************************************************************************************************
    -- Get Prev DP Version

    history (date / writer / comment)
    - 2021.02.23 / KSH / wrong code fix 
    -- 2021.05.03 / kimsohee/ SK Inovation custom : One version data Seperate Monthly & Yealy plan
    - 2021.07.12 / kim sohee / SK innovation custom : except DPS
    - 2021.07.14 / kim sohee / dp previous version is by BASE_YM 
    - 2021.07.16 / 源��슜�닔 / DPS踰꾩쟾�씤 寃쎌슦 BASE_YM�씠 �룞�씪�븳 留덉�留� DPM(�젙洹쒕쾭�쟾), DPM踰꾩쟾�씤 寃쎌슦 BASE_YM�씠 吏곸쟾�썡�씤 留덉�留� DPM(�젙洹쒕쾭�쟾)�쓣 媛�吏�怨� �삷
    - 2021.10.20 / 諛뺤삦二� / P_PLAN_TP_ID媛믪� �떒湲�,�옣湲� �삊媛숈� 媛믪쑝濡� INSERT �릺怨� �엳湲� �븣臾몄뿉 議곌굔�뿉�꽌 類��떎.(�떎�젣 �떒湲�, �옣湲곌컪�씠 �꽆�뼱�삱 寃쎌슦 �옣湲곌퀎�쉷�쓣 援щ텇�븯吏� 紐삵븿)
                        /�떒湲�,�옣湲곌퀎�쉷 �젙蹂닿� TB_DP_ENTRY, TB_DP_ENTRY_Y濡� �굹�닠�졇 �엳�쑝�굹 怨좊젮�릺�뼱 �엳吏� �븡�쓬. 10R 踰꾩쟾�젙蹂댁뿉 ���븳 踰꾩폆�쓽 �삁�쇅�궗�빆�뿉 ���빐�꽌�룄 怨좊젮�븯�뿬 �닔�젙
*********************************************************************************************************/
RETURN DP_TEMP_PR_VER IS
C_DP_TEMP_PR_VER DP_TEMP_PR_VER := DP_TEMP_PR_VER();
-- YEAR
CURSOR C_DATA_IMPORT IS 
WITH TYPE_CHECK 
AS (SELECT SUBSTR(VER_ID,1,3) VER_TYPE
         , BASE_YM
      FROM TB_DP_CONTROL_BOARD_VER_MST
     WHERE ID = P_VER_ID 
   )
   , VER AS (
    /* --2021.10.20 �닔�젙媛쒕컻濡� �씤�빐 二쇱꽍泥섎━(�븘�옒 �냼�뒪濡� 蹂�寃�)
    SELECT MIN(M.ID) KEEP (DENSE_RANK FIRST ORDER BY M.CREATE_DTTM DESC)  AS ID
      FROM TB_DP_CONTROL_BOARD_VER_DTL D  
           INNER JOIN 
           TB_DP_CONTROL_BOARD_VER_MST M
        ON D.CONBD_VER_MST_ID = M.ID         
     WHERE CONBD_VER_MST_ID != P_VER_ID 
--     AND PLAN_TP_ID = P_PLAN_TP_ID 
       AND D.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_cD = 'DP_WK_TP' AND CONF_CD = 'CL')
--     AND D.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
       AND M.VER_ID NOT LIKE '%DPS%'
       AND M.BASE_YM = (SELECT CASE WHEN VER_TYPE = 'DPC' THEN TO_CHAR(ADD_MONTHS(TO_DATE(BASE_YM||'01','YYYYMMDD'), -1), 'YYYYMM') ELSE M.BASE_YM END FROM TYPE_CHECK )  -- 源��슜�닔 : 踰꾩쟾 媛�吏�怨� �삤�뒗 濡쒖쭅 �닔�젙
     */
    SELECT 
           M.ID
         , M.VER_ID 
         , M.BASE_YM 
         , M.VER_S_HORIZON_DATE2 --�뿰踰꾩폆 �떆�옉�씪�옄
      FROM TB_DP_CONTROL_BOARD_VER_DTL D  
           INNER JOIN 
           TB_DP_CONTROL_BOARD_VER_MST M
        ON D.CONBD_VER_MST_ID = M.ID         
     WHERE D.CONBD_VER_MST_ID = (SELECT MIN(S.ID) KEEP (DENSE_RANK FIRST ORDER BY S.CREATE_DTTM DESC) 
                                 FROM TB_DP_CONTROL_BOARD_VER_MST S
                                WHERE S.ID != P_VER_ID 
                                  AND S.VER_ID NOT LIKE '%DPS%'
                                  AND S.BASE_YM = (SELECT CASE WHEN VER_TYPE = 'DPS' THEN BASE_YM ELSE S.BASE_YM END FROM TYPE_CHECK ) ) 
       AND D.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_cD = 'DP_WK_TP' AND CONF_CD = 'CL')--�뙋留ㅺ퀎�쉷 醫낅즺
)
 SELECT TP_DP_TEMP_PR_VER 
    ( ITEM_MST_ID => ITEM_MST_ID
    , ACCOUNT_ID => ACCOUNT_ID
    , BASE_DATE => BASE_DATE
    , AUTH_TP_ID => AUTH_TP_ID
    , QTY => QTY
    , QTY_1 => QTY_1
    , QTY_2 => QTY_2
    , QTY_3 => QTY_3
    )
    /* --2021.10.20 �떒湲곌퀎�쉷 �젙蹂대쭔 媛��졇�삤�룄濡� �릺�뼱 �엳�뼱 �떒湲�,�옣湲곌퀎�쉷�젙蹂대�� 媛��졇�삱 �닔 �엳�룄濡� �븘�옒 泥섎읆 �닔�젙
   FROM TB_DP_ENTRY
  WHERE VER_ID = (SELECT ID FROM VER)
    AND PLAN_TP_ID = P_PLAN_TP_ID  */
   FROM 
      (
       SELECT DP.ITEM_MST_ID
            , DP.ACCOUNT_ID
            , DP.BASE_DATE 
            , DP.AUTH_TP_ID
            , DP.QTY   AS QTY
            , DP.QTY_1  AS QTY_1
            , DP.QTY_2  AS QTY_2
            , DP.QTY_3  AS QTY_3
         FROM TB_DP_ENTRY DP
            , VER  VE
        WHERE DP.VER_ID = VE.ID
          AND DP.BASE_DATE < VE.VER_S_HORIZON_DATE2
          --AND DP.PLAN_TP_ID = P_PLAN_TP_ID
        UNION ALL 
       SELECT DP.ITEM_MST_ID
            , DP.ACCOUNT_ID
            , DP.BASE_DATE
            , DP.AUTH_TP_ID
            , DP.QTY
            , DP.QTY_1
            , DP.QTY_2
            , DP.QTY_3
         FROM TB_DP_ENTRY_Y DP
            , VER VE
        WHERE DP.VER_ID = VE.ID
          AND DP.BASE_DATE >= VE.VER_S_HORIZON_DATE2
          --AND DP.PLAN_TP_ID = P_PLAN_TP_ID
      ) ENTRY
  ORDER BY
        ACCOUNT_ID
      , BASE_DATE
;
BEGIN  
        OPEN C_DATA_IMPORT;
        FETCH C_DATA_IMPORT BULK COLLECT INTO C_DP_TEMP_PR_VER;
        CLOSE C_DATA_IMPORT;    
    RETURN C_DP_TEMP_PR_VER;
END;
/

