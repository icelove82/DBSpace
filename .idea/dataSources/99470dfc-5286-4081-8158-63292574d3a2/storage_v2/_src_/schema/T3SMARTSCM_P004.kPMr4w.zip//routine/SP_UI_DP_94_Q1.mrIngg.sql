create PROCEDURE                 SP_UI_DP_94_Q1(
     p_DP_VER_ID       VARCHAR2
    ,P_VER_CD    VARCHAR2
    ,p_AUTH_TYPE    VARCHAR2
    ,p_OPERATOR_ID  VARCHAR2
    ,p_NEXT_ONLY    VARCHAR2 
    ,pRESULT        OUT SYS_REFCURSOR
) IS 
/**************************************************************************************************
	Process Status

	History ( date / writer / comment)
	- ****.**.** / ksh / draft 
	- 2020.12.07 / ksh / check work level about DP version by plan type
    - 2020.12.23 / 誘쇨꼍�썕 / MSSQL -> ORACLE
    - 2021.01.14 / KSH / check a number before into param
    - 2021.03.05 / KSH / Virtual Level is not included 
    - 2021.05.06 / KSH / sk custom : approve status by oem level of user 
    - 2021.05.14 / KSH / SK Custom : Consensus plan 
**************************************************************************************************/

v_PREV_AUTH_TYPE    VARCHAR2(255);
p_NEXT_LV_YN        CHAR(1);
P_CHECK             INT;

BEGIN


    SELECT case when p_NEXT_ONLY =  'Y' or p_NEXT_ONLY = 'true' 
                then 'Y'  
                else 'N' 
           end 
           INTO p_NEXT_LV_YN
      FROM DUAL
    ;

    WITH LV
    AS ( SELECT LV_CD, ROW_NUMBER() OVER ( ORDER BY SEQ ASC) AS RW
           FROM TB_CM_LEVEL_MGMT
          WHERE SALES_LV_YN = 'Y'
            AND COALESCE(DEL_YN,'N') = 'N'
            AND ACTV_yN = 'Y'
            AND (ID IN (SELECT LV_MGMT_ID FROM TB_DP_SALES_LEVEL_MGMT WHERE ACTV_YN = 'Y' AND DEL_YN != 'Y' AND VIRTUAL_YN != 'Y') OR LEAF_YN = 'Y')
        )
        SELECT COUNT(LV_CD) INTO P_CHECK
         FROM LV
        WHERE LV.RW = (SELECT RW+1 FROM LV WHERE LV_CD = p_AUTH_TYPE)
        ;
IF (P_CHECK > 0)
    THEN    
      WITH LV
        AS (
        SELECT LV_CD, ROW_NUMBER() OVER ( ORDER BY SEQ ASC) AS RW
            FROM TB_CM_LEVEL_MGMT
        WHERE SALES_LV_YN = 'Y'
            AND COALESCE(DEL_YN,'N') = 'N'
            AND ACTV_yN = 'Y'
            AND (ID IN (SELECT LV_MGMT_ID 
                          FROM TB_DP_SALES_LEVEL_MGMT 
                         WHERE ACTV_YN = 'Y' 
                           AND DEL_YN != 'Y' 
                           AND VIRTUAL_YN != 'Y'
                         ) OR LEAF_YN = 'Y')
        )
        SELECT LV_CD INTO v_PREV_AUTH_TYPE
          FROM LV
         WHERE LV.RW = (SELECT RW+1 FROM LV WHERE LV_CD = p_AUTH_TYPE)
            ;
    END IF
    ;    


    OPEN pRESULT 
     FOR
    WITH USER_ACCT_MAP
    AS (    SELECT SH.DESCENDANT_ID AS ACCOUNT_ID
                 , EMP_ID
                 , AUTH_TP_ID
                 , MAIN_LV_YN 
              FROM TB_DP_USER_ACCOUNT_MAP  UA
				   INNER JOIN
				   TB_DPD_SALES_HIER_CLOSURE SH
				ON UA.SALES_LV_ID = SH.ANCESTER_ID
             WHERE SH.LEAF_YN = 'Y'
               AND SH.USE_YN = 'Y'
          GROUP BY SH.DESCENDANT_ID
                 , EMP_ID
                 , AUTH_TP_ID 
                 , MAIN_LV_YN
             UNION
            SELECT UA.ACCOUNT_ID
                 , EMP_ID
                 , AUTH_TP_ID
                 , 'N'
              FROM TB_DP_USER_ITEM_ACCOUNT_MAP UA
                   INNER JOIN
                   TB_DPD_USER_HIER_CLOSURE UH
                ON UA.EMP_ID = UH.DESC_ID
                AND UA.AUTH_TP_ID = UH.DESC_ROLE_ID
                    INNER JOIN
                    TB_CM_ITEM_MST IT
                 ON UA.ITEM_MST_ID = IT.ID 
                AND IT.DP_PLAN_YN = 'Y'
                AND IT.DEL_YN != 'Y'    
              WHERE UH.USER_ACCT_YN != 'Y'
                AND MAPPING_SELF_YN = 'Y'                             
              UNION
            SELECT ACCOUNT_ID
                 , EMP_ID
                 , AUTH_TP_ID
                 , MAIN_LV_YN 
              FROM TB_DP_USER_ACCOUNT_MAP  UA             
            WHERE UA.SALES_LV_ID IS NULL 
    ), OEM_LV
    AS (SELECT SH.ANCESTER_ID
              ,SH.DESCENDANT_ID
          FROM TB_DPD_SALES_HIER_CLOSURE SH
               INNER JOIN
               TB_DP_SALES_LEVEL_MGMT SL
            ON SH.ANCESTER_ID = SL.ID
               INNER JOIN
               TB_CM_LEVEL_MGMT LV
            ON SL.LV_MGMT_ID = LV.ID
           AND LV.SRP_LV_YN = 'Y'   -- CUSTOM
           AND LV.ACTV_YN = 'Y'
           AND LV.DEL_YN != 'Y'
         WHERE SH.LEAF_YN = 'Y' 
           AND SH.USE_YN = 'Y'
    ), USER_OEM_MAP
    AS (  SELECT SH.ANCESTER_ID  AS OEM_ID
               , UA.EMP_ID      
               , CASE WHEN MAIN_LV_YN = 'Y' THEN UA.EMP_ID ELSE SB.EMP_ID END AS SUB_EMP_ID
               , UA.AUTH_TP_ID
               , MAIN_LV_YN 
 		   FROM USER_ACCT_MAP UA
 			    INNER JOIN
 			    TB_DP_ACCOUNT_MST AM
 			 ON UA.ACCOUNT_ID = AM.ID
            AND AM.ACTV_YN = 'Y'
            AND AM.DEL_YN != 'Y'             
                INNER JOIN
                OEM_LV SH
             ON SH.DESCENDANT_ID = AM.ID
                LEFT OUTER JOIN
                (   SELECT MAX(EMP_ID) AS EMP_ID
                         , MAX(AUTH_TP_ID) AS AUTH_TP_ID
                         , ACCOUNT_ID
                      FROM USER_ACCT_MAP
                     WHERE MAIN_LV_YN = 'Y'
                  GROUP BY ACCOUNT_ID                        
                ) SB
             ON UA.ACCOUNT_ID = SB.ACCOUNT_ID
            AND UA.MAIN_LV_YN = 'N' 
            AND UA.AUTH_TP_ID = SB.AUTH_TP_ID    
    ), USER_HIER
    AS (
        SELECT *
          FROM TB_DPD_USER_HIER_CLOSURE C
         WHERE c.ANCS_CD = p_OPERATOR_ID
          AND c.ANCS_ROLE_CD = p_AUTH_TYPE
          AND CASE WHEN p_NEXT_LV_YN = 'Y' THEN v_PREV_AUTH_TYPE ELSE DESC_ROLE_CD END = DESC_ROLE_CD          
    ), EMP_INFO
    AS (
        SELECT DESC_ROLE_CD, DESC_CD, E.DISPLAY_NAME as EMP_NM
              ,DESC_ROLE_ID, DESC_ID
        FROM USER_HIER c
             INNER JOIN 
             TB_AD_USER E
          ON C.DESC_ID =E.ID
             INNER JOIN 
             TB_DP_CONTROL_BOARD_VER_DTL D
          ON D.CONBD_VER_MST_ID =  p_DP_VER_ID
         AND D.LV_MGMT_ID = C.DESC_ROLE_ID
    )
    SELECT DISTINCT 
           A.DESC_CD            AS OPERATOR_ID
         , EMP_NM               AS OPERATOR_NAME
         , A.DESC_ROLE_CD       AS AUTH_TYPE
         , case when STATUS is null 
            then 'READY'
            else STATUS 
           end                  AS STATUS
         , STATUS_DATE
         , SL.SALES_LV_CD   AS OEM_CD 
         , SL.SALES_LV_NM   AS OEM_NM
     FROM (  
            SELECT EP.DESC_CD
                 , EP.DESC_ID
                 , EP.DESC_ROLE_CD
                 , EP.DESC_ROLE_ID
                 , EP.EMP_NM
                 , PS.STATUS
                 , ROW_NUMBER () OVER (PARTITION BY EP.DESC_CD, IA.SUB_EMP_ID, IA.OEM_ID ORDER BY PS.STATUS_DATE DESC) AS RW
                 , PS.STATUS_DATE  
                 , IA.MAIN_LV_YN
                 , IA.OEM_ID 
                 , IA.SUB_EMP_ID                  
            FROM EMP_INFO  EP
                 INNER JOIN
                 USER_OEM_MAP IA 
               ON EP.DESC_ROLE_ID = IA.AUTH_TP_ID
              AND EP.DESC_ID = IA.EMP_ID     
                  INNER JOIN
                  TB_AD_USER US
               ON IA.SUB_EMP_ID = US.ID
             LEFT OUTER JOIN
             TB_DP_PROCESS_STATUS_LOG PS
             ON PS.AUTH_TYPE = EP.DESC_ROLE_CD
             AND PS.OPERATOR_ID = US.USERNAME
             AND VER_CD = p_VER_CD
         ) A  
         INNER JOIN
         TB_DP_SALES_LEVEL_MGMT SL
       ON A.OEM_ID = SL.ID 
    WHERE RW = 1  
        ;
END;
/

