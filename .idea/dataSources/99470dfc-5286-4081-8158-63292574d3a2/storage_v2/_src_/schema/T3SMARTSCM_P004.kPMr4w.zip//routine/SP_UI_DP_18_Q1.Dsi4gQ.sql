create PROCEDURE "SP_UI_DP_18_Q1" 
(
    P_GRP_ID IN VARCHAR2  := ''
  , P_UI_ID IN VARCHAR2 := ''
  , P_GRID_ID IN VARCHAR2  := ''
  , pRESULT OUT SYS_REFCURSOR
) IS
BEGIN
    OPEN pRESULT
    FOR
    SELECT DI.ID
         , DI.UI_ID
         , DI.GRID_ID
         , DI.GRP_ID
         , DI.LV_MGMT_ID
         , DI.COL_NM
         , DI.DISP_NM
         , DI.DISP_NM   AS DISP_NM_VAL
         , DI.SEQ
         , DI.ACTV_YN
         , DI.CREATE_BY
         , DI.CREATE_DTTM
         , DI.MODIFY_BY
         , DI.MODIFY_DTTM
      FROM TB_DP_DIM_SETTING DI
     WHERE GRP_ID = P_GRP_ID
       AND UI_ID    = p_UI_ID
       AND GRID_ID  = p_GRID_ID
     ORDER BY DI.SEQ
      ;
END ;

/

