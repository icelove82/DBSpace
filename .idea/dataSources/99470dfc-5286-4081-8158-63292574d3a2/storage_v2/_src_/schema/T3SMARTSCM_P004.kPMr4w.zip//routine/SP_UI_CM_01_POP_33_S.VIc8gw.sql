create PROCEDURE        "SP_UI_CM_01_POP_33_S" (
	 P_ID                   IN VARCHAR2 := ''
    ,P_FROM_LOCAT_TP	    IN VARCHAR2 := ''
    ,P_TO_LOCAT_TP	        IN VARCHAR2 := ''
    ,P_VEHICL_TP	        IN VARCHAR2 := ''
    ,P_ACTV_YN              IN VARCHAR2 := ''
    ,P_USER_ID	            IN VARCHAR2 := ''
    ,P_WRK_TYPE	            IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG     OUT VARCHAR2 
    ,P_RT_MSG               OUT VARCHAR2
    
)
IS

    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';

BEGIN
IF P_WRK_TYPE = 'SAVE'
THEN

        P_ERR_MSG := 'MSG_0006'; --'？？？ ？？？ ？？？？ ？？μ？？？ ？？？？？？？.'
            IF NVL(P_FROM_LOCAT_TP,'') ='' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;

        P_ERR_MSG := 'MSG_0006'; --'？？？ ？？？ ？？？？ ？？μ？？？ ？？？？？？？.'
            IF NVL(P_TO_LOCAT_TP,'') ='' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;

        P_ERR_MSG := 'MSG_0006'; --'？？？ ？？？ ？？？？ ？？μ？？？ ？？？？？？？.'
            IF NVL(P_VEHICL_TP,'') ='' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;

    MERGE INTO TB_CM_LOC_VEHICLE B 
			USING (SELECT P_ID AS ID FROM DUAL) A
					ON     (B.ID = A.ID)

			WHEN MATCHED THEN

				UPDATE 
				   SET ACTV_YN				= P_ACTV_YN
					 , FROM_LOCAT_MST_ID	= P_FROM_LOCAT_TP
					 , VEHICL_TP_ID			= P_VEHICL_TP
					 , TO_LOCAT_MST_ID		= P_TO_LOCAT_TP
					 , MODIFY_BY			= P_USER_ID
					 , MODIFY_DTTM			= SYSDATE()

			WHEN NOT MATCHED THEN
			INSERT (
				-- ？？？？？？
				ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
				-- ？？？？？？？？
				, FROM_LOCAT_MST_ID
				, TO_LOCAT_MST_ID
				, VEHICL_TP_ID	
				, ACTV_YN
				)
			VALUES 
		  	    (
				-- ？？？？？？
				TO_SINGLE_BYTE(SYS_GUID()), P_USER_ID, SYSDATE(), P_USER_ID, SYSDATE()
				-- ？？？？？？？？
				, P_FROM_LOCAT_TP
				, P_TO_LOCAT_TP	
				, P_VEHICL_TP    
				, P_ACTV_YN	

			);

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';  --？？？？ ？？？？？？？？.            

ELSIF P_WRK_TYPE = 'DELETE'
THEN

    DELETE FROM TB_CM_LOC_VEHICLE
			WHERE ID = P_ID;

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0002';

END IF;

        EXCEPTION
        WHEN OTHERS THEN
            P_RT_ROLLBACK_FLAG := 'false';
            IF(SQLCODE = -20012)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF; 

END;

/

