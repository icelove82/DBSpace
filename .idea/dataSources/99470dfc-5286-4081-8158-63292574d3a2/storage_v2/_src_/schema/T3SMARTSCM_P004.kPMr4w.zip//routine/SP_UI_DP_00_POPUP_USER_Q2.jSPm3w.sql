create PROCEDURE                 "SP_UI_DP_00_POPUP_USER_Q2" (
    p_LOGIN_ID  VARCHAR2 := ''   
  , p_EMP_NO    VARCHAR2 := ''
  , p_EMP_NM    VARCHAR2 := ''
  , pRESULT     OUT SYS_REFCURSOR
) IS 
/************************************************************************
    History ( Date / Writer / Comment)
    - 2021.06.10 / 源��슜�닔 / TB_CM_COMM_CONFIG�쓽 CONF_GRP_CD = 'DP_ADMIN_ID' �뿉 �벑濡앸맂 �궗�슜�옄�뒗 �엫吏곸썝 議고쉶 媛��뒫 �븯�룄濡� 泥섎━
    - 2021.09.23 / 諛뺤삦二� / �궗踰� 蹂�寃쎌뿉 �뵲�씪 議곌굔異붽� ENABLED = 'Y' AND NVL(ETC,'A')<>'D' 
************************************************************************/
v_ADMIN_YN    VARCHAR2(1) := 'N';

BEGIN

    SELECT    CASE WHEN COUNT(*) >= 1 THEN 'Y' ELSE 'N' END ADMIN_CHK
      INTO    v_ADMIN_YN      
      FROM  
            (  
              SELECT    ADMIN_USER
                FROM 
                      (  
                        SELECT    ATTR_01  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_02  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_03 AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_04  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_05  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_06  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_07  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_08  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_09  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_10  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                      )
            )    
     WHERE    ADMIN_USER IN ( p_LOGIN_ID )
    ; 


    IF P_LOGIN_ID = 'admin' or v_ADMIN_YN = 'Y'    -- 2021.03.09 源��슜�닔 : admin 異붽�
    THEN
        OPEN pRESULT
        FOR
        SELECT A.ID
             , A.USER_ID
             , A.EMP_NO
             , A.EMP_NM 
          FROM (
            SELECT '' ID,  '' USER_ID, '' EMP_NO, '' EMP_NM
              FROM DUAL
            UNION ALL
            SELECT ID
                 , USERNAME as USER_ID
                 , USERNAME as EMP_NO
                 , DISPLAY_NAME as EMP_NM  
              FROM TB_AD_USER  
             WHERE USERNAME LIKE '%' + P_EMP_NO +'%'            
               AND COALESCE(DISPLAY_NAME,'') LIKE '%' + P_EMP_NM +'%'      
               AND ENABLED = 'Y' AND NVL(ETC,'A')<>'D' --2021.09.23 �궗踰뉾IG �씠�썑 異붽��맂 議곌굔
          ) A
         ORDER BY EMP_NO 
        ;
    END IF;
END;

/

