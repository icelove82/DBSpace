create PROCEDURE "SP_UI_DP_SK_25_POPUP_ATTR_Q1" (
     P_ITEM_CD VARCHAR2
    ,P_ACCOUNT_CD  VARCHAR2
    ,P_SALES_LV_CD  VARCHAR2 -- Sales = TEAM_01, TEAM_02..Sales level 기준은?
    ,P_AUTH_TP_ID  CHAR
    ,P_AUTH_TP_CD  VARCHAR2
    ,pRESULT       OUT SYS_REFCURSOR    
)IS


 P_ITEM_MST_ID CHAR(32);
 P_ACCOUNT_ID  CHAR(32);

BEGIN
SELECT ID INTO P_ITEM_MST_ID
  FROM TB_CM_ITEM_MST
WHERE ITEM_CD = P_ITEM_CD
;
SELECT ID INTO P_ACCOUNT_ID
  FROM TB_DP_ACCOUNT_MST
WHERE ACCOUNT_CD = P_ACCOUNT_CD
;
OPEN pRESULT FOR
SELECT   P_ITEM_MST_ID   AS ITEM_MST_ID
        ,P_ACCOUNT_ID   AS ACCOUNT_ID
        ,'VAL'          AS VAL
        ,I.ATTR_01		AS ITEM_ATTR_01
        ,I.ATTR_02		AS ITEM_ATTR_02
        ,I.ATTR_03		AS ITEM_ATTR_03
        ,I.ATTR_04		AS ITEM_ATTR_04
        ,I.ATTR_05		AS ITEM_ATTR_05
        ,I.ATTR_06		AS ITEM_ATTR_06
        ,I.ATTR_07		AS ITEM_ATTR_07
        ,I.ATTR_08		AS ITEM_ATTR_08
        ,I.ATTR_09		AS ITEM_ATTR_09
        ,I.ATTR_10		AS ITEM_ATTR_10
        ,I.ATTR_11		AS ITEM_ATTR_11
        ,I.ATTR_12		AS ITEM_ATTR_12
        ,I.ATTR_13		AS ITEM_ATTR_13
        ,I.ATTR_14		AS ITEM_ATTR_14
        ,I.ATTR_15		AS ITEM_ATTR_15
        ,I.ATTR_16		AS ITEM_ATTR_16
        ,I.ATTR_17		AS ITEM_ATTR_17
        ,I.ATTR_18		AS ITEM_ATTR_18
        ,I.ATTR_19		AS ITEM_ATTR_19
        ,I.ATTR_20		AS ITEM_ATTR_20
        ,A.ATTR_01		AS ACCT_ATTR_01
        ,A.ATTR_02		AS ACCT_ATTR_02
        ,A.ATTR_03		AS ACCT_ATTR_03
        ,A.ATTR_04		AS ACCT_ATTR_04
        ,A.ATTR_05		AS ACCT_ATTR_05
        ,A.ATTR_06		AS ACCT_ATTR_06
        ,A.ATTR_07		AS ACCT_ATTR_07
        ,A.ATTR_08		AS ACCT_ATTR_08
        ,A.ATTR_09		AS ACCT_ATTR_09
        ,A.ATTR_10		AS ACCT_ATTR_10
        ,A.ATTR_11		AS ACCT_ATTR_11
        ,A.ATTR_12		AS ACCT_ATTR_12
        ,A.ATTR_13		AS ACCT_ATTR_13
        ,A.ATTR_14		AS ACCT_ATTR_14
        ,A.ATTR_15		AS ACCT_ATTR_15
        ,A.ATTR_16		AS ACCT_ATTR_16
        ,A.ATTR_17		AS ACCT_ATTR_17
        ,A.ATTR_18		AS ACCT_ATTR_18
        ,A.ATTR_19		AS ACCT_ATTR_19
        ,A.ATTR_20		AS ACCT_ATTR_20
        ,ASI_R1.QTY		AS ASI_R1
        ,ASI_R2.QTY		AS ASI_R2
        ,ASI_R3.QTY		AS ASI_R3
        ,ASI_3A.QTY		AS ASI_3A
        ,ASI_6A.QTY		AS ASI_6A
        ,ASI_9A.QTY		AS ASI_9A
        ,WSI_9A.QTY     AS WSI_9A
 FROM (
        SELECT   I.ATTR_01
                ,I.ATTR_02
                ,I.ATTR_03
                ,I.ATTR_04
                ,I.ATTR_05
                ,I.ATTR_06
                ,I.ATTR_07
                ,I.ATTR_08
                ,I.ATTR_09
                ,I.ATTR_10
                ,I.ATTR_11
                ,I.ATTR_12
                ,I.ATTR_13
                ,I.ATTR_14
                ,I.ATTR_15
                ,I.ATTR_16
                ,I.ATTR_17
                ,I.ATTR_18
                ,I.ATTR_19
                ,I.ATTR_20
          FROM TB_CM_ITEM_MST I
        WHERE ID =P_ITEM_MST_ID  
        ) I CROSS JOIN  (  -- Item 속성      
        SELECT   A.ATTR_01
                ,A.ATTR_02
                ,A.ATTR_03
                ,A.ATTR_04
                ,A.ATTR_05
                ,A.ATTR_06
                ,A.ATTR_07
                ,A.ATTR_08
                ,A.ATTR_09
                ,A.ATTR_10
                ,A.ATTR_11
                ,A.ATTR_12
                ,A.ATTR_13
                ,A.ATTR_14
                ,A.ATTR_15
                ,A.ATTR_16
                ,A.ATTR_17
                ,A.ATTR_18
                ,A.ATTR_19
                ,A.ATTR_20
          FROM TB_DP_ACCOUNT_MST A
         WHERE ID = P_ACCOUNT_ID
        )A CROSS JOIN (      -- Account 속성  
        SELECT SUM(QTY) AS QTY
          FROM TB_CM_ACTUAL_SALES
         WHERE ITEM_MST_ID =P_ITEM_MST_ID  
           AND TO_CHAR(BASE_DATE,'YYYYMM') = TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM')  
        ) ASI_R1  CROSS JOIN (  -- 한달 전 판매 실적 합계   
        SELECT SUM(QTY) AS QTY
          FROM TB_CM_ACTUAL_SALES
         WHERE ITEM_MST_ID =P_ITEM_MST_ID  
           AND TO_CHAR(BASE_DATE,'YYYYMM') = TO_CHAR(ADD_MONTHS(SYSDATE,-2),'YYYYMM')  
        ) ASI_R2  CROSS JOIN (  -- 두달 전 판매 실적 합계
        SELECT SUM(QTY) AS QTY
          FROM TB_CM_ACTUAL_SALES
         WHERE ITEM_MST_ID =P_ITEM_MST_ID  
           AND TO_CHAR(BASE_DATE,'YYYYMM') = TO_CHAR(ADD_MONTHS(SYSDATE,-3),'YYYYMM')  
        ) ASI_R3  CROSS JOIN (  -- 세달 전 판매 실적 합계
        -- PM Level
--        SELECT SUM(QTY) AS QTY
--          FROM TB_CM_ACTUAL_SALES
--         WHERE ITEM_MST_ID =P_ITEM_MST_ID  
--           AND TO_CHAR(BASE_DATE,'YYYYMM') = TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM')
--           AND ACCOUNT_ID IN (
--                                SELECT ID
--                                  FROM TB_DP_ACCOUNT_MST
--                                 WHERE PARENT_SALES_LV_ID = (SELECT ID FROM TB_DP_SALES_LEVEL_MGMT WHERE SALEs_LV_CD = P_SALES_LV_CD)
--                              )
--        ) ASI_SALES_R1  CROSS JOIN (  -- 한달 전 판매 실적 합계 (영업팀별)  
--        SELECT SUM(QTY) AS QTY
--          FROM TB_CM_ACTUAL_SALES
--         WHERE ITEM_MST_ID =P_ITEM_MST_ID  
--           AND TO_CHAR(BASE_DATE,'YYYYMM') = TO_CHAR(ADD_MONTHS(SYSDATE,-2),'YYYYMM')  
--           AND ACCOUNT_ID IN (
--                                SELECT ID
--                                  FROM TB_DP_ACCOUNT_MST
--                                 WHERE PARENT_SALES_LV_ID = (SELECT ID FROM TB_DP_SALES_LEVEL_MGMT WHERE SALEs_LV_CD = P_SALES_LV_CD)
--                              )           
--        ) ASI_R2  CROSS JOIN (  -- 두달 전 판매 실적 합계
--        SELECT SUM(QTY) AS QTY
--          FROM TB_CM_ACTUAL_SALES
--         WHERE ITEM_MST_ID =P_ITEM_MST_ID  
--           AND TO_CHAR(BASE_DATE,'YYYYMM') = TO_CHAR(ADD_MONTHS(SYSDATE,-3),'YYYYMM')  
--        ) ASI_R3  CROSS JOIN (  -- 세달 전 판매 실적 합계
        SELECT ROUND(AVG(QTY),1) AS QTY
          FROM TB_CM_ACTUAL_SALES
         WHERE ITEM_MST_ID =P_ITEM_MST_ID  
           AND TO_CHAR(BASE_DATE,'YYYYMM') BETWEEN TO_CHAR(ADD_MONTHS(SYSDATE,-3),'YYYYMM')  AND  TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM')               
        ) ASI_3A  CROSS JOIN (  --3개월 판매실적 평균
        SELECT ROUND(AVG(QTY),1) AS QTY
          FROM TB_CM_ACTUAL_SALES
         WHERE ITEM_MST_ID =P_ITEM_MST_ID  
           AND TO_CHAR(BASE_DATE,'YYYYMM') BETWEEN TO_CHAR(ADD_MONTHS(SYSDATE,-6),'YYYYMM')  AND  TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM')               
        ) ASI_6A  CROSS JOIN (  --6개월 판매실적 평균
        SELECT ROUND(AVG(QTY),1) AS QTY
          FROM TB_CM_ACTUAL_SALES
         WHERE ITEM_MST_ID =P_ITEM_MST_ID  
           AND TO_CHAR(BASE_DATE,'YYYYMM') BETWEEN TO_CHAR(ADD_MONTHS(SYSDATE,-12),'YYYYMM')  AND  TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM')               
        ) ASI_9A  CROSS JOIN (  --12개월 판매실적 평균        
        SELECT ROUND(SUM(QTY),1) AS QTY
          FROM TB_CM_WAREHOUSE_STOCK_MST A
               INNER JOIN
               TB_CM_WAREHOUSE_STOCK_QTY B
            ON A.ID = B.WAREHOUSE_INV_MST_ID
           AND A.ACTV_YN = 'Y'
           AND B.ACTV_YN = 'Y'
         WHERE A.ITEM_MST_ID =P_ITEM_MST_ID  
           AND A.CUTOFF_DATE = (SELECT MAX(CUTOFF_DATE) FROM TB_CM_WAREHOUSE_STOCK_MST WHERE ACTV_YN ='Y')             
        ) WSI_9A  --CROSS JOIN (  --재고 실적?? (        

        -- 반품 실적, 재고 실적은 - 어디서 끌어오는거지
        -- C. 기준의 영업팀별 및 전사 차원의 Item 월별 판매 실적, 평균 ?? - 영업팀 기준은?
        -- A. B. 기준의 Item별 판매 실적은 Sales level 상관 없이 하는게 맞나?
        ;      
END
;






/

