create PROCEDURE "SP_UI_DP_35_Q7_I_A_ITEM_CD" 
(	
	 p_OPERATOR_ID		IN VARCHAR2 := ''
	,p_AUTH_TP_ID		IN VARCHAR2 := ''
    ,pResult OUT SYS_REFCURSOR    
) 
IS
/*************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / add USER_ID 
************************************************************************/

BEGIN
    OPEN pResult FOR 
    SELECT	B.USERNAME as USER_ID, B.USERNAME as EMP_NO,B.DISPLAY_NAME as EMP_NM, A.AUTH_TP_ID, L.LV_NM AS AUTH_TP_NM, A.ITEM_MST_ID, C.ITEM_NM, CASE WHEN COALESCE(C.DEL_YN,'N') = 'Y' THEN 'MASTER DATA 삭제' ELSE '그외(I/F문제등)' END ERR_DESC
	FROM	TB_DP_USER_ITEM_ACCOUNT_MAP	A 
			INNER JOIN TB_AD_USER		B  ON A.EMP_ID = B.ID
			LEFT OUTER JOIN TB_CM_ITEM_MST C  ON A.ITEM_MST_ID = C.ID AND C.DP_PLAN_YN = 'Y'
            LEFT OUTER JOIN TB_CM_LEVEL_MGMT L
            ON A.AUTH_TP_ID = L.ID            
	WHERE	NOT EXISTS	(
						SELECT 'X'
						FROM TB_CM_ITEM_MST X 
						WHERE A.ITEM_MST_ID = X.ID
						AND COALESCE(X.DEL_YN,'N') = 'N' AND X.DP_PLAN_YN = 'Y'
						)
	AND		A.AUTH_TP_ID	LIKE '%' || p_AUTH_TP_ID || '%'
	AND		B.USERNAME		LIKE '%' || p_OPERATOR_ID || '%'
    ;
--	SELECT	B.USER_ID, B.EMP_NO, B.EMP_NM, A.AUTH_TP_ID, L.LV_NM AS AUTH_TP_NM, A.ITEM_MST_ID, C.ITEM_CD, C.ITEM_NM, CASE WHEN C.DEL_YN = 'Y' THEN 'MASTER DATA Delete' ELSE 'ETC (ex.I/F problem)' END ERR_DESC
--	FROM	TB_DP_USER_ITEM_ACCOUNT_MAP	A  
--			INNER JOIN TB_DP_EMPLOYEE		B  ON A.EMP_ID = B.ID
--			LEFT OUTER JOIN TB_CM_ITEM_MST C  ON A.ITEM_MST_ID = C.ID --AND C.DP_PLAN_YN = 'Y'
--            LEFT OUTER JOIN TB_CM_LEVEL_MGMT L
--            ON A.AUTH_TP_ID = L.ID            
--	WHERE	NOT EXISTS	(
--						SELECT 'X'
--						FROM TB_CM_ITEM_MST X 
--						WHERE A.ITEM_MST_ID = X.ID
--						AND NVL(X.DEL_YN,'N') = 'N' AND X.DP_PLAN_YN = 'Y'
--						)
--	AND		A.AUTH_TP_ID	LIKE '%' || p_AUTH_TP_ID || '%'
--	AND		B.USER_ID		LIKE '%' || p_OPERATOR_ID	 || '%';
END
;

/

