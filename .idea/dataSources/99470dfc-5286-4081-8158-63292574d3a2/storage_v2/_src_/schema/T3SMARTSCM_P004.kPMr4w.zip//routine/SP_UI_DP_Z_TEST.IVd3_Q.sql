create PROCEDURE "SP_UI_DP_Z_TEST" (
                                       p_INPARAM1                 IN   VARCHAR2    := ''
                                      ,p_INPARAM2                 IN   VARCHAR2    := ''
                                      ,P_RT_MSG             OUT  VARCHAR2     
                                       ) 
IS
BEGIN
    P_RT_MSG := 'hohoho2';

END;


/

