create PROCEDURE SP_UI_CM_04_S2 (
	 P_LOC_MGMT_ID			IN VARCHAR2 := ''
	,P_ITEM_MST_ID			IN VARCHAR2 := ''
	,P_ITEM_SCOPE_ID		IN VARCHAR2 := ''
	,P_BOM_ITEM_TP_ID		IN VARCHAR2 := ''
	,P_PROCUR_TP_ID		    IN VARCHAR2 := ''
	,P_DIFFTD_CLSS_ID		IN VARCHAR2 := ''
	,P_MIN_ORDER_SIZE		IN VARCHAR2:= ''
	,P_MAX_ORDER_SIZE		IN VARCHAR2:= ''
	,P_UOM_CD				IN VARCHAR2 := ''
	,P_CURCY_CD			    IN VARCHAR2 := ''
	,P_ACTV_YN				IN CHAR := ''
	,P_SRA					IN DATE := ''
	,P_RTS					IN DATE := ''
	,P_EOP					IN DATE := ''
	,P_EOS					IN DATE := ''
	,P_PARENT_ITEM_EOL		IN DATE := ''
	,P_INV_ONHAND_YN		IN CHAR := ''
	,P_INV_POLICY		    IN VARCHAR2 := ''
	,P_STD_UTPIC			IN VARCHAR2 := ''
	,P_USER_ID				IN VARCHAR2 := ''		
	,P_RT_ROLLBACK_FLAG     OUT VARCHAR2
	,P_RT_MSG               OUT VARCHAR2
)
IS
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG VARCHAR2(4000) :='';

BEGIN
    P_ERR_MSG := 'MSG_0008';
    IF (P_MIN_ORDER_SIZE < 0 OR P_MAX_ORDER_SIZE < 0 OR P_STD_UTPIC < 0)
    THEN  RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);    END IF;

    P_ERR_MSG := 'MSG_0006';
    IF NVL(P_LOC_MGMT_ID,'') ='' THEN  RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;  

    P_ERR_MSG := 'MSG_0006';
    IF NVL(P_ITEM_MST_ID,'') ='' THEN  RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);  END IF;

    P_ERR_MSG := 'MSG_5015';
    IF P_MIN_ORDER_SIZE > P_MAX_ORDER_SIZE THEN  RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;

    INSERT INTO TB_CM_SITE_ITEM
        ( ID , CREATE_BY , CREATE_DTTM , MODIFY_BY , MODIFY_DTTM 
         ,LOCAT_MGMT_ID
         ,ITEM_MST_ID
         ,ITEM_SCOPE_MST_ID
         ,DIFFTD_CLSS_ID
         ,SRA
         ,RTS
         ,EOP
         ,EOS
         ,PARENT_ITEM_EOL
         ,CUST_SHPP_YN
         ,VEHICL_TP_ID
         ,INCOTERMS_ID
         ,INV_ONHAND_YN
         ,INV_POLICY_ID
         ,INV_KEEPING_COST_RATE
         ,STD_UTPIC
         ,CURCY_CD_ID
         ,MFG_COST
         ,KEY_MAT_YN
         ,LGDY_MAT_YN
         ,MAT_CONST_TP_ID
         ,ACTV_YN
         ,BOM_ITEM_TP_ID
         ,PROCUR_TP_ID
         )
   VALUES(
          TO_SINGLE_BYTE(SYS_GUID()) , P_USER_ID , SYSDATE , P_USER_ID , SYSDATE
         ,P_LOC_MGMT_ID
         ,P_ITEM_MST_ID
         ,P_ITEM_SCOPE_ID
         ,P_DIFFTD_CLSS_ID
         ,P_SRA
         ,P_RTS
         ,P_EOP
         ,P_EOS
         ,P_PARENT_ITEM_EOL
         ,'N'
         ,null
         ,null
         ,P_INV_ONHAND_YN
         ,P_INV_POLICY
         ,null
         ,TO_NUMBER(DECODE(RTRIM(P_STD_UTPIC),'',null,P_STD_UTPIC))
         ,P_CURCY_CD
         ,null
         ,'N'
         ,'N'
         ,null
         ,P_ACTV_YN
         ,P_BOM_ITEM_TP_ID
         ,P_PROCUR_TP_ID
         );

    UPDATE TB_CM_ITEM_MST
        SET
             MIN_ORDER_SIZE = TO_NUMBER(DECODE(RTRIM(P_MIN_ORDER_SIZE),'',null,P_MIN_ORDER_SIZE))
            ,MAX_ORDER_SIZE = TO_NUMBER(DECODE(RTRIM(P_MAX_ORDER_SIZE),'',null,P_MAX_ORDER_SIZE))
            ,UOM_ID = P_UOM_CD
            ,MODIFY_BY = P_USER_ID
            ,MODIFY_DTTM = SYSDATE
        WHERE ID = P_ITEM_MST_ID;

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';

    EXCEPTION
    WHEN OTHERS THEN
        IF(SQLCODE = -20012)
          THEN 
              P_RT_ROLLBACK_FLAG := 'false';
              P_RT_MSG := P_ERR_MSG;
          ELSE
              RAISE;
          END IF;

END;

/

