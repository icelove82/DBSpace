create PROCEDURE "SP_UI_DP_14_D2" (
    p_ID                IN VARCHAR2 := ''         
  , p_USER_ID           IN VARCHAR  := ''     
  , P_RT_ROLLBACK_FLAG  OUT VARCHAR2   
  , P_RT_MSG            OUT VARCHAR2									   
) 
IS 
	P_ERR_STATUS INT := 0;
    P_ERR_MSG VARCHAR2(4000):='';
    V_ACCT_YN CHAR(1);
    V_ACCOUNT_ID CHAR(32);
    V_MAIN_LV_YN CHAR(32);
BEGIN
    P_RT_ROLLBACK_FLAG := 'true';
/*    
    SELECT LV.LEAF_YN 
         , CASE WHEN LEAF_YN = 'Y' THEN AM.ACCOUNT_ID ELSE AM.SALES_LV_ID END 
         , MAIN_LV_YN
         INTO V_ACCT_YN, V_ACCOUNT_ID, V_MAIN_LV_YN
      FROM TB_DP_USER_ACCOUNT_MAP AM
           INNER JOIN
           TB_CM_LEVEL_MGMT LV 
        ON AM.LV_MGMT_ID = LV.ID 
     WHERE AM.ID =p_ID
    ;
*/    
    DELETE FROM TB_DP_USER_ACCOUNT_MAP
	 WHERE ID = p_ID 
    ; 
/*    
    -- OEM 별로 담당자가 무조건 한명은 대표로.          
        IF (V_MAIN_LV_YN = 'Y')
            THEN
                UPDATE TB_DP_USER_ACCOUNT_MAP
                  SET MAIN_LV_YN = 'Y'
                WHERE CASE V_ACCT_YN WHEN 'Y' THEN ACCOUNT_ID ELSE SALES_LV_ID END = V_ACCOUNT_ID
                  AND ROWNUM = 1
                  ;
            END IF;    
*/    
	  -- ？?ν？? ???？	    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0002';  --???？？????？？
       /* ???？o?? ============================================================================*/

EXCEPTION WHEN OTHERS THEN  -- ?？? ???？？? ?？? ???？?？ : e_products_invalid    
    IF(SQLCODE = -20001)
    THEN
        P_ERR_MSG := SQLERRM;
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
    --SP_COMM_RAISE_ERR();              
        RAISE;
    END IF; 
END;
/

