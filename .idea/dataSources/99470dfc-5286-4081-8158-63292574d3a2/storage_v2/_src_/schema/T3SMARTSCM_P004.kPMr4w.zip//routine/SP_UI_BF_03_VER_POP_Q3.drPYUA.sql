create PROCEDURE SP_UI_BF_03_VER_POP_Q3
(
 p_CHANGE_COM		VARCHAR2:=''
,p_VER_FROM_DATE	VARCHAR2:=''
,p_DATE			VARCHAR2:=''
,p_BUCKET			VARCHAR2:=''
,p_HORIZON		VARCHAR2:=''
)
IS

     v_VER_BUCKET		VARCHAR2(50);
     v_VER_HORIZON		INT;
     v_VER_DTF			INT;
     v_VER_STAT_BUCKET   INT;
     v_STAT_WEEK_NUM	INT;
     v_VER_FROM_DATE	DATE;
     v_VER_TO_DATE		DATE;
     v_DTF_DATE		DATE;

BEGIN


IF (p_VER_FROM_DATE = '' OR p_VER_FROM_DATE IS NULL)
THEN
    p_VER_FROM_DATE := SYSDATE;
END IF;

IF (p_DATE = '' OR p_DATE IS NULL)
THEN
     p_DATE := SYSDATE;
END IF;

     v_VER_BUCKET		:=	p_BUCKET	;
     v_VER_HORIZON		:=	p_HORIZON	;
	v_VER_DTF		:=	0	;
	v_VER_STAT_BUCKET  :=	0;

SELECT	CASE CONF_CD WHEN 'Mon' THEN 2
                       WHEN 'Tue' THEN 3
                       WHEN 'Wed' THEN 4
                       WHEN 'Thu' THEN 5
                       WHEN 'Fri' THEN 6
                       WHEN 'Sat' THEN 7
                       WHEN 'Sun' THEN 1
                        END INTO v_STAT_WEEK_NUM
FROM	TB_CM_COMM_CONFIG
WHERE	CONF_GRP_CD = 'DP_STD_WEEK'
AND		ACTV_YN		= 'Y';


IF (p_CHANGE_COM = 'FROM_DT')
THEN
	SELECT CASE v_VER_BUCKET	WHEN 'Y' THEN DATEADD(YEAR,  @v_VER_STAT_BUCKET,   (DATENAME(YEAR, @p_DATE) + '0101') )
                              WHEN 'M' THEN DATEADD(MONTH,  @v_VER_STAT_BUCKET,  (DATENAME(YEAR, @p_DATE) + DATENAME(MONTH, @p_DATE) + '01') )
                              WHEN 'W' THEN DATEADD(WEEK,  @v_VER_STAT_BUCKET,   (DATEADD(DAY, - DATEPART(DW, @p_DATE) + @v_STAT_WEEK_NUM ,CONVERT(DATE, @p_DATE))) )	
                              WHEN 'D' THEN DATEADD(DAY,  @v_VER_STAT_BUCKET,   @p_DATE)
                              END INTO v_VER_FROM_DATE;

	SELECT CASE @v_VER_BUCKET	WHEN 'Y' THEN  DATEADD(YEAR,  @v_VER_STAT_BUCKET,   DATEADD(DAY, -1,DATENAME(YEAR,DATEADD(YEAR, @v_VER_HORIZON + 1, @p_DATE)) + '0101') ) -- 적용일의 마지막일자로 SET
                                   WHEN 'M' THEN  DATEADD(MONTH,  @v_VER_STAT_BUCKET,   DATEADD(DAY, -1,DATENAME(YEAR,DATEADD(MONTH ,@v_VER_HORIZON, @p_DATE)) +   DATENAME(MONTH,DATEADD(MONTH ,@v_VER_HORIZON + 1, @p_DATE)) + '01') )-- 적용 마지막일자로 SET
                                   WHEN 'W' THEN  DATEADD(WEEK,  @v_VER_STAT_BUCKET,   DATEADD(DAY, - DATEPART(DW,@p_DATE) + @v_STAT_WEEK_NUM -1,CONVERT(DATE, DATEADD(WEEK ,@v_VER_HORIZON, @p_DATE))) )	
                                   WHEN 'D' THEN  DATEADD(DAY ,@v_VER_HORIZON, @p_DATE )
                                   END INTO v_VER_TO_DATE;


	SELECT v_VER_FROM_DATE AS VER_FROM_DATE, v_VER_TO_DATE AS VER_TO_DATE
       FROM DUAL;
ELSE IF (p_CHANGE_COM = 'TO_DT')
THEN

	SELECT CASE WHEN p_VER_FROM_DATE > p_DATE THEN p_VER_FROM_DATE 
                 END INTO v_VER_TO_DATE 
       FROM DUAL ;

	SELECT v_VER_TO_DATE AS VER_TO_DATE
       FROM DUAL; 
END IF;
END;

/

