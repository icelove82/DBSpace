create PROCEDURE                 SP_UI_DP_APPROVE(
  P_USER_CD		VARCHAR2 
 ,P_LOGIN_USER_CD		VARCHAR2 
-- ,P_AUTH_TP_ID		CHAR  
 ,P_AUTH_TP_CD		VARCHAR2 
-- ,p_VER_ID			CHAR 
 ,P_VER_CD			VARCHAR2 
 
)
/***************************************************************************************************************************************************
	  DP Approval
	-- Parameter : User Code (inidividual Approval), Login ID(all Approval) Authority Type, Version Id

	History (date / writer / comment)
	- 2020.12.14 / kim sohee / Oracle converting
    - 2021.03.03 / Kim sohee / add a method by approval Constraint Code
    - 2021.11.19 / Kim sohee / USE_YN    
**************************************************************************************************************************************************/

 IS
  P_AUTH_TP_ID  	CHAR(32);
  p_VER_ID	    	CHAR(32);
  P_APPV_EVENT_CD	VARCHAR2(50);
  P_CHECK           INT;
  P_CHECK_02        INT;


--  P_TOP_SALES_LV    VARCHAR2(50);
 BEGIN
    DELETE FROM TEMP_USER_HIER;
    DELETE FROM TEMP_DP_RT;
    DELETE FROM TEMP_DP_ITEM_ACCT_CAL;

   SELECT ID INTO P_VER_ID
	 FROM TB_DP_CONTROL_BOARD_VER_MST
   WHERE VER_ID = P_VER_CD 
   ;
	SELECT ID INTO P_AUTH_TP_ID
	  FROM TB_CM_LEVEL_MGMT
	 WHERE LV_CD = P_AUTH_TP_CD
     ;	 
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- 1. Approve Event Check
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
-- TB_DP_CONTROL_BOARD_VER_DTL �뀒�씠釉붿뿉�꽌 �듅�씤 �씠踰ㅽ듃 媛믪쓣 �솗�씤�빐�빞 �븳�떎

	SELECT CC.CONF_cD INTO P_APPV_EVENT_CD
 	  FROM TB_DP_CONTROL_BOARD_VER_DTL CB
		   INNER JOIN
		   TB_CM_COMM_CONFIG CC
		ON CB.APPV_EVENT_ID = CC.ID 
	 WHERE CONBD_VER_MST_ID = p_VER_ID
	   AND LV_MGMT_ID = P_AUTH_TP_ID 
	   ;	

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- 2. Get User Info to approve
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
        INSERT INTO TEMP_USER_HIER 
        (   ANCS_ROLE_ID
          , ANCS_ROLE_CD
          , ANCS_ID
          , DESC_ID
          , DESC_CD
        )
        WITH USER_HIERARCHY
		AS (SELECT UH.ANCS_ROLE_ID, ANCS_ROLE_CD, ANCS_ID, DESC_ID, DESC_CD
				 , ROW_NUMBER() OVER (PARTITION BY DESC_ID ORDER BY LV.SEQ  DESC) AS SEQ
			  FROM TB_DPD_USER_HIER_CLOSURE UH
				   INNER JOIN 
				   TB_CM_LEVEL_MGMT LV
			   ON UH.ANCS_ROLE_ID = LV.ID		
			  AND LV.ACTV_YN = 'Y'
			  AND COALESCE(LV.DEL_YN,'N') = 'N'
			       INNER JOIN 
				   TB_DP_CONTROL_BOARD_VER_DTL VD
			   ON UH.ANCS_ROLE_ID = VD.LV_MGMT_ID
			  AND VD.CONBD_VER_MST_ID = P_VER_ID 
			WHERE DESC_ROLE_CD = P_AUTH_TP_CD		  
			  AND UH.ANCS_ROLE_CD != UH.DESC_ROLE_CD
		), ANCS_USER
		AS (SELECT ANCS_ID, ANCS_ROLE_ID
			  FROM TB_DPD_USER_HIER_CLOSURE
			 WHERE DESC_CD = COALESCE(P_USER_CD,DESC_CD)
			   AND DESC_ROLE_CD = P_AUTH_TP_CD
		)            
			SELECT UH.ANCS_ROLE_ID, UH.ANCS_ROLE_CD, UH.ANCS_ID, UH.DESC_ID, UH.DESC_CD
			  FROM USER_HIERARCHY UH
			WHERE P_APPV_EVENT_CD = 'NT' AND UH.DESC_CD = COALESCE(P_USER_CD, DESC_CD)
	          AND SEQ = 1 			   
			UNION
			SELECT UH.ANCS_ROLE_ID, UH.ANCS_ROLE_CD, UH.ANCS_ID, UH.DESC_ID, UH.DESC_CD
			  FROM USER_HIERARCHY UH
			WHERE P_APPV_EVENT_CD = 'AA'
	          AND SEQ = 1 			   
			UNION
			SELECT UH.ANCS_ROLE_ID, UH.ANCS_ROLE_CD, UH.ANCS_ID, UH.DESC_ID, UH.DESC_CD
			  FROM USER_HIERARCHY UH
				   INNER JOIN
				   ANCS_USER AU		-- add condition 
				ON UH.ANCS_ID = AU.ANCS_ID
			   AND UH.ANCS_ROLE_ID = AU.ANCS_ROLE_ID	 
			WHERE P_APPV_EVENT_CD = 'AN'
	          AND SEQ = 1 
             ;
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- 3. Check if this time is a momment to approve
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
        SELECT COUNT(OPERATOR_ID)
            INTO P_CHECK
          FROM TB_DP_PROCESS_STATUS_LOG
         WHERE VER_CD= p_VER_CD
           AND AUTH_TYPE = P_AUTH_TP_CD 	
           AND (OPERATOR_ID = COALESCE(P_USER_CD,OPERATOR_ID) OR P_APPV_EVENT_CD != 'NT') -- ONLY 'NT' Event Code , check operator ID
            ;
        SELECT COUNT(1) INTO P_CHECK_02
          FROM TEMP_USER_HIER 
          ;


IF (P_CHECK > 0 AND P_CHECK_02 > 0)
    THEN

  WITH TB_PRC_STA
      AS (
        SELECT OPERATOR_ID
             , MAX(STATUS) OVER (PARTITION BY OPERATOR_ID ORDER BY STATUS_DATE DESC) AS STA
          FROM TB_DP_PROCESS_STATUS_LOG
         WHERE VER_CD= p_VER_CD
           AND AUTH_TYPE = P_AUTH_TP_CD 	
           AND (OPERATOR_ID = COALESCE(P_USER_CD,OPERATOR_ID) OR P_APPV_EVENT_CD != 'NT') -- ONLY 'NT' Event Code , check operator ID
         ) 
SELECT (         
        SELECT COUNT(UH.ANCS_ROLE_CD) 
		  FROM TEMP_USER_HIER UH
			   LEFT OUTER JOIN
			   TB_PRC_STA PS
			ON UH.DESC_CD = PS.OPERATOR_ID
		   AND PS.STA = 'APPROVAL'
	  GROUP BY UH.ANCS_ROLE_CD
	    HAVING COUNT(PS.STA) = COUNT(UH.DESC_CD)
        ) INTO P_CHECK FROM DUAL 
        ;    
    END IF 
    ;

IF P_CHECK > 0 OR P_USER_CD IS NULL
	THEN
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- 4. Item Account Role
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/    
INSERT INTO TEMP_DP_ITEM_ACCT_CAL (ITEM_MST_ID, ACCOUNT_ID, AUTH_TP_ID)
	WITH USER_HIER
	AS (-- User data For Getting item, account, model mapping 
		SELECT US.ANCS_ROLE_ID
			 , UH.DESC_ID, UH.DESC_CD, UH.DESC_ROLE_CD, UH.DESC_ROLE_ID 
		  FROM TB_DPD_USER_HIER_CLOSURE UH
			   INNER JOIN
			   TEMP_USER_HIER US
			ON UH.ANCS_ID = US.DESC_ID
		 WHERE MAPPING_SELF_YN = 'Y'           
	), ITEM_HIER
	AS (
		SELECT ANCESTER_ID
			 , ANCESTER_CD
			 , DESCENDANT_ID
			 , DESCENDANT_CD 
		  FROM TB_DPD_ITEM_HIER_CLOSURE WHERE LEAF_YN = 'Y'		
	), SALES_HIER
	AS (
		SELECT ANCESTER_ID, ANCESTER_CD, DESCENDANT_ID, DESCENDANT_CD FROM TB_DPD_SALES_HIER_CLOSURE WHERE LEAF_YN = 'Y' AND USE_YN = 'Y'
	), ITEM
	AS (  SELECT CASE WHEN CL.LEAF_YN = 'Y' 
					  THEN IM.ITEM_MST_ID 
					  ELSE IM.ITEM_LV_ID 
				  END	AS ID
			    , CL.LEAF_YN
			    , US.ANCS_ROLE_ID
			    , US.DESC_ID
			FROM TB_DP_USER_ITEM_MAP IM 
				  INNER JOIN
				  USER_HIER US 
			   ON IM.EMP_ID	    = US.DESC_ID 
			  AND IM.AUTH_TP_ID = US.DESC_ROLE_ID  
				  INNER JOIN 
				  TB_CM_LEVEL_MGMT CL 
			   ON IM.LV_MGMT_ID = CL.ID 
			  AND CL.ACTV_YN = 'Y'
			  AND COALESCE(CL.DEL_YN,'N') = 'N'
		    WHERE IM.ACTV_YN = 'Y'	             
	), ACCT
	AS (-- �궡 留ㅽ븨 ACCT 李얘린
		SELECT CASE WHEN CL.LEAF_YN = 'Y' THEN AM.ACCOUNT_ID ELSE AM.SALES_LV_ID END	AS ID
			 , US.ANCS_ROLE_ID
			 , US.DESC_ID
			 , CL.LEAF_YN
		  FROM TB_DP_USER_ACCOUNT_MAP AM 
	           INNER JOIN
			   USER_HIER US
			ON AM.EMP_ID     = US.DESC_ID 
		   AND AM.AUTH_TP_ID = US.DESC_ROLE_ID
		       INNER JOIN
			   TB_CM_LEVEL_MGMT CL
			ON AM.LV_MGMT_ID = CL.ID 
		   AND CL.ACTV_YN = 'Y'
		   AND COALESCE(CL.DEL_YN, 'N') = 'N'
		 WHERE AM.ACTV_YN = 'Y'	 
           AND AM.MAIN_LV_YN = 'Y'
	), EX
	AS (
	SELECT EX.ITEM_MST_ID 
		 , EX.ACCOUNT_ID
		 , US.ANCS_ROLE_ID
		 , US.DESC_ID
	  FROM TB_DP_USER_ITEM_ACCOUNT_EXCLUD EX
	           INNER JOIN
			   USER_HIER US
			ON EX.EMP_ID     = US.DESC_ID 
		   AND EX.AUTH_TP_ID = US.DESC_ROLE_ID
	) , IA 
	AS (	
	    SELECT ACCT.ANCS_ROLE_ID
	         , ACCT.DESC_ID
			 , CASE WHEN ITEM.LEAF_YN = 'Y' THEN ITEM.ID ELSE IH.DESCENDANT_ID END		AS ITEM_ID
			 , CASE WHEN ACCT.LEAF_YN = 'Y' THEN ACCT.ID ELSE SH.DESCENDANT_ID END		AS ACCT_ID
		  FROM ACCT		-- ACCT_SH
			   INNER JOIN
			   ITEM		-- ITEM_SH 
			ON ACCT.DESC_ID = ITEM.DESC_ID
			   INNER JOIN 
			   ITEM_HIER IH ON ( ITEM.ID = IH.ANCESTER_ID )
			   INNER JOIN
			   SALES_HIER SH
			ON ACCT.ID = SH.ANCESTER_ID
		 MINUS
		 SELECT ANCS_ROLE_ID 
			  , DESC_ID
			  , ITEM_MST_ID
			  , ACCOUNT_ID
		   FROM EX 	
	)  
	   SELECT DISTINCT 
			  ITEM_ID
			 ,ACCT_ID 
			 ,ANCS_ROLE_ID
		 FROM IA
	    UNION
		SELECT DISTINCT 
			   ITEM_MST_ID
			 , ACCOUNT_ID
			 , ANCS_ROLE_ID
		  FROM TB_DP_USER_ITEM_ACCOUNT_MAP UIAM	-- item, account 媛곴컖�쓽 留ㅽ븨 �젙蹂닿� �엳�쑝硫�, �씠 留ㅽ븨 �젙蹂대뒗 �븞蹂몃떎.
			   INNER JOIN
			   USER_HIER USIF
		    ON UIAM.EMP_ID = USIF.DESC_ID
		   AND UIAM.AUTH_TP_ID = USIF.DESC_ROLE_ID
          ;
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- 4. Update Entry value
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
    -- Make submit data
    INSERT INTO TEMP_DP_RT
    (    ITEM_MST_ID
        ,ACCOUNT_ID
        ,BASE_DATE
        ,QTY
        ,AUTH_TP_ID
        ,QTY_1
        ,QTY_2
        ,QTY_3    
    )
   WITH RT
		AS (
		SELECT ITEM_MST_ID
			 , ACCOUNT_ID
			 , BASE_DATE
			 , QTY 
             , QTY_1
             , QTY_2
             , QTY_3
		  FROM TB_DP_ENTRY 
		 WHERE VER_ID = P_VER_ID
		   AND AUTH_TP_ID = P_AUTH_TP_ID		   
		)
            SELECT  M.ITEM_MST_ID
                  , M.ACCOUNT_ID
                  , RT.BASE_DATE 
                  , RT.QTY
                  , AUTH_TP_ID 
                  , RT.QTY_1
                  , RT.QTY_2
                  , RT.QTY_3
              FROM TEMP_DP_ITEM_ACCT_CAL M
			   INNER JOIN 
			   RT 
			ON M.ITEM_MST_ID = RT.ITEM_MST_ID
		   AND M.ACCOUNT_ID = RT.ACCOUNT_ID
           ;

	-- Get Input data : Item, account, value (DESC of USER_HIER: �굹 �샊�� �굹�� 媛숈� level �궗�슜�옄�뱾)
    MERGE INTO TB_DP_ENTRY TGT
     USING ( SELECT  AUTH_TP_ID
                    ,ITEM_MST_ID
                    ,ACCOUNT_ID
                    ,BASE_DATE        
                    ,QTY
                    ,QTY_1
                    ,QTY_2
                    ,QTY_3
              FROM TEMP_DP_RT    
           ) SRC 
        ON (TGT.VER_ID = P_VER_ID
        AND TGT.AUTH_TP_ID = SRC.AUTH_TP_ID
        AND TGT.ITEM_MST_ID = SRC.ITEM_MST_ID
        AND TGT.ACCOUNT_ID = SRC.ACCOUNT_ID
        AND TGT.BASE_DATE = SRC.BASE_DATE
        )
        WHEN MATCHED THEN
        UPDATE
        SET TGT.QTY = SRC.QTY
           ,TGT.QTY_1=SRC.QTY_1
           ,TGT.QTY_2=SRC.QTY_2
           ,TGT.QTY_3=SRC.QTY_3
           ,TGT.MODIFY_BY = COALESCE(P_USER_CD, P_LOGIN_USER_CD)
           ,TGT.MODIFY_DTTM = SYSDATE
		     ;
    DELETE FROM TEMP_DP_RT;

    -- Yealy Plan custom
    INSERT INTO TEMP_DP_RT
    (    ITEM_MST_ID
        ,ACCOUNT_ID
        ,BASE_DATE
        ,QTY
        ,AUTH_TP_ID
        ,QTY_1
        ,QTY_2
        ,QTY_3    
    )
   WITH RT
		AS (
		SELECT ITEM_MST_ID
			 , ACCOUNT_ID
			 , BASE_DATE
			 , QTY 
             , QTY_1
             , QTY_2
             , QTY_3
		  FROM TB_DP_ENTRY_Y 
		 WHERE VER_ID = P_VER_ID
		   AND AUTH_TP_ID = P_AUTH_TP_ID		   
		)
            SELECT  M.ITEM_MST_ID
                  , M.ACCOUNT_ID
                  , RT.BASE_DATE 
                  , RT.QTY
                  , AUTH_TP_ID 
                  , RT.QTY_1
                  , RT.QTY_2
                  , RT.QTY_3
              FROM TEMP_DP_ITEM_ACCT_CAL M
			   INNER JOIN 
			   RT 
			ON M.ITEM_MST_ID = RT.ITEM_MST_ID
		   AND M.ACCOUNT_ID = RT.ACCOUNT_ID
           ;

	-- Get Input data : Item, account, value (DESC of USER_HIER: �굹 �샊�� �굹�� 媛숈� level �궗�슜�옄�뱾)
    MERGE INTO TB_DP_ENTRY_Y TGT
     USING ( SELECT  AUTH_TP_ID
                    ,ITEM_MST_ID
                    ,ACCOUNT_ID
                    ,BASE_DATE        
                    ,QTY
                    ,QTY_1
                    ,QTY_2
                    ,QTY_3
              FROM TEMP_DP_RT    
           ) SRC 
        ON (TGT.VER_ID = P_VER_ID
        AND TGT.AUTH_TP_ID = SRC.AUTH_TP_ID
        AND TGT.ITEM_MST_ID = SRC.ITEM_MST_ID
        AND TGT.ACCOUNT_ID = SRC.ACCOUNT_ID
        AND TGT.BASE_DATE = SRC.BASE_DATE
        )
        WHEN MATCHED THEN
        UPDATE
        SET TGT.QTY = SRC.QTY
           ,TGT.QTY_1=SRC.QTY_1
           ,TGT.QTY_2=SRC.QTY_2
           ,TGT.QTY_3=SRC.QTY_3
           ,TGT.MODIFY_BY = COALESCE(P_USER_CD, P_LOGIN_USER_CD)
           ,TGT.MODIFY_DTTM = SYSDATE
		     ;
	END IF
    ; 
    DELETE FROM TEMP_USER_HIER;
    DELETE FROM TEMP_DP_RT;
    DELETE FROM TEMP_DP_ITEM_ACCT_CAL;

 END 
 ;
/

