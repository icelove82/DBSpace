create PROCEDURE "SP_UI_DP_15_Q2_T" (      
         p_ITEM_LV  IN VARCHAR2 := 'ITEM'
       , p_ITEM_CD  IN VARCHAR2 := NULL
       , P_ITEM_NM   IN VARCHAR2 := NULL
       , P_RT_MSG              OUT VARCHAR2 
       , pRESULT       OUT SYS_REFCURSOR 
) IS   

  

BEGIN

    OPEN pRESULT
    FOR    
    WITH
    TB_PR_ITEM_LEVEL_MGMT (
        ID
      , "PATH"
      , PATH_ID
      , SEQ
      , ITEM_LV_NM
    ) AS (
        SELECT SL.ID
             , TO_CHAR('/' || SL.ITEM_LV_CD)    "PATH"
             , TO_CHAR('/' || SL.ID)            PATH_ID
             , LM.SEQ                           SEQ
             , SL.ITEM_LV_NM
          FROM TB_CM_ITEM_LEVEL_MGMT SL
         INNER JOIN TB_CM_LEVEL_MGMT LM
            ON SL.LV_MGMT_ID = LM.ID
         WHERE SL.PARENT_ITEM_LV_ID IS NULL
           AND COALESCE(LM.DEL_YN, 'N') = 'N'
           AND COALESCE(SL.DEL_YN, 'N') = 'N'
           AND COALESCE(LM.SALES_LV_YN, 'N') = 'N'
           AND LM.ACTV_YN = 'Y'
           AND SL.ACTV_YN = 'Y'
        UNION ALL
        SELECT SL.ID
             , TO_CHAR("PATH" || '/' || SL.ITEM_LV_CD)  "PATH"
             , TO_CHAR(PATH_ID || '/' || SL.ID)         PATH_ID
             , LM.SEQ
             , SL.ITEM_LV_NM
          FROM TB_CM_ITEM_LEVEL_MGMT SL
         INNER JOIN TB_PR_ITEM_LEVEL_MGMT PL
            ON SL.PARENT_ITEM_LV_ID = PL.ID
         INNER JOIN TB_CM_LEVEL_MGMT LM
            ON SL.LV_MGMT_ID = LM.ID
         WHERE COALESCE(LM.DEL_YN, 'N') = 'N'
           AND COALESCE(SL.DEL_YN, 'N') = 'N'
           AND COALESCE(LM.SALES_LV_YN, 'N') = 'N'
           AND LM.ACTV_YN = 'Y'
           AND SL.ACTV_YN = 'Y'
    ),   

    TB_DPD_ITEM_TREE (
        LEAF_ITEM_LV_ID
      , LEAF_ITEM_LV_CD
      , PATH_ID
      , PATH_CD
      , LEAF_ITEM_LV_NM
      , SEQ
    ) AS (
        SELECT SUBSTR(M.PATH_ID, -INSTR(REVERSE(M.PATH_ID), '/') + 1)   AS LEAF_ITEM_LV_ID
             , SUBSTR(M."PATH",  -INSTR(REVERSE(M."PATH"),  '/') + 1)   AS LEAF_ITEM_LV_CD
             , SUBSTR(PATH_ID, 2, LENGTH(PATH_ID) - 1)                  AS PATH_ID
             , SUBSTR("PATH", 2, LENGTH("PATH") - 1)                    AS PATH_CD
             , M.ITEM_LV_NM                                             AS LEAF_ITEM_LV_NM
             , M.SEQ
          FROM TB_PR_ITEM_LEVEL_MGMT M
    )

    SELECT IT.ID        AS KEY_ITEM_ID
         , IT.ITEM_CD   AS KEY_ITEM_CD
         , IT.ITEM_NM   AS KEY_ITEM_NM
         , LV.ID        AS LV_MGMT_ID
         , 'SEQ' || LPAD(TO_CHAR(LV2.SEQ), 3, '0') || LV2.LV_NM AS GRP
         , TR.VAL           AS CD
         , IL2.ITEM_LV_NM   AS NM
         , IT.ITEM_CD
         , IT.ITEM_NM
      FROM TB_CM_LEVEL_MGMT LV
     INNER JOIN TB_CM_ITEM_LEVEL_MGMT IL
        ON LV.ID = IL.LV_MGMT_ID
     INNER JOIN (
        SELECT TRIM(REGEXP_SUBSTR(PATH_CD, '[^/]+', 1, LEVEL)) VAL
             , LEAF_ITEM_LV_CD
             , LEAF_ITEM_LV_ID
          FROM (
            SELECT PATH_CD
                 , LEAF_ITEM_LV_CD
                 , LEAF_ITEM_LV_ID
              FROM TB_DPD_ITEM_TREE T
          )
        CONNECT BY INSTR(PATH_CD, '/', 1, LEVEL - 1) > 0
     ) TR
        ON IL.ID = TR.LEAF_ITEM_LV_ID
      LEFT OUTER JOIN TB_CM_ITEM_LEVEL_MGMT IL2
        ON IL2.ITEM_LV_CD = TR.VAL
      LEFT OUTER JOIN TB_CM_LEVEL_MGMT LV2
        ON IL2.LV_MGMT_ID = LV2.ID
      LEFT OUTER JOIN (
        SELECT ID, ITEM_CD, ITEM_NM, PARENT_ITEM_LV_ID
          FROM TB_CM_ITEM_MST
         WHERE DP_PLAN_YN = 'Y'
           AND COALESCE(DEL_YN, 'N') = 'N'
      ) IT
        ON TR.LEAF_ITEM_LV_ID = IT.PARENT_ITEM_LV_ID
     WHERE (
        SELECT LV_CD
          FROM TB_CM_LEVEL_MGMT
         WHERE COALESCE(SALES_LV_YN, 'N') = 'N'
           AND COALESCE(ACCOUNT_LV_YN, 'N') = 'N'
           AND LV_LEAF_YN = 'Y'
           AND COALESCE(DEL_YN, 'N') = 'N'
           AND ACTV_YN = 'Y'
         ) = LV.LV_CD
       AND ITEM_CD IS NOT NULL
       AND COALESCE(ITEM_CD, ' ') LIKE '%' || COALESCE(P_ITEM_CD, '') || '%'
       AND COALESCE(ITEM_NM, ' ') LIKE '%' || COALESCE(P_ITEM_NM, '') || '%'
    ;
END;
/

