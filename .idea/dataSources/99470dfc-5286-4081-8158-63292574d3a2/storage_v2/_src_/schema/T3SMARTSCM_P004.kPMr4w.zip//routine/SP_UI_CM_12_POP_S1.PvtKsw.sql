create PROCEDURE SP_UI_CM_12_POP_S1(
	 P_ITEM_MST_ID					IN CHAR := '',
	 P_ACCOUNT_ID						IN CHAR := '',
	 P_LOC_DTL_ID						IN CHAR := '',
	 P_ACTV_YN							IN CHAR := NULL,
	 P_USER_ID							IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG  OUT VARCHAR2 
    ,P_RT_MSG                   OUT VARCHAR2
)IS
    COUNT_NUM NUMBER := NULL;
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG  VARCHAR2(4000) :='';
    P_DMND_MST_ID CHAR(32) :='';
    P_DMND_DTL_ID CHAR(32) :='';
    P_DMND_LEADTIME_ID  CHAR(32) :='';
BEGIN

    IF(LTRIM(RTRIM(P_ITEM_MST_ID)) IS NULL)
    THEN
        P_ERR_MSG :='MSG_0006';
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    
    IF(LTRIM(RTRIM(P_ACCOUNT_ID)) IS NULL)
    THEN
        P_ERR_MSG :='MSG_0006';
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    
    IF(LTRIM(RTRIM(P_LOC_DTL_ID)) IS NULL)
    THEN
        P_ERR_MSG :='MSG_0006';
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    
     SELECT COUNT(*) INTO COUNT_NUM
		  FROM TB_CM_DMND_SHPP_MAP_MST
		 WHERE ITEM_MST_ID = P_ITEM_MST_ID
		   AND ACCOUNT_ID = P_ACCOUNT_ID
		   AND LOCAT_MGMT_ID = (SELECT ID
								  FROM TB_CM_LOC_MGMT
								 WHERE LOCAT_ID = P_LOC_DTL_ID);
    IF( COUNT_NUM >0)
            THEN
                 P_RT_ROLLBACK_FLAG := 'true';
                 P_RT_MSG := 'MSG_0013'; -- ?？？ ???？?？???？？？
        ELSE

        INSERT INTO TB_CM_DMND_SHPP_MAP_MST
			   (ID
			   ,SALES_HRCY_VAL
			   ,ITEM_MST_ID
			   ,ACCOUNT_ID
			   ,LOCAT_MGMT_ID
			   ,ENGINE_MODULE_VAL
			   ,ACTV_YN
			   ,CREATE_BY
			   ,CREATE_DTTM
			   ,MODIFY_BY
			   ,MODIFY_DTTM)

		SELECT 
            TO_SINGLE_BYTE(SYS_GUID())
			 , NULL --SALES_HRCY_VAL
			 , P_ITEM_MST_ID
			 , P_ACCOUNT_ID
			 , LMG.ID
			 , NULL --ENGINE_MODULE_VAL
			 , P_ACTV_YN
			 , P_USER_ID
			 , SYSDATE
			 , P_USER_ID
			 , SYSDATE
		 FROM TB_CM_LOC_MGMT LMG
		WHERE LMG.LOCAT_ID = P_LOC_DTL_ID
        AND NOT EXISTS(
            SELECT *
		  FROM TB_CM_DMND_SHPP_MAP_MST
		 WHERE ITEM_MST_ID = P_ITEM_MST_ID
		   AND ACCOUNT_ID = P_ACCOUNT_ID
		   AND LOCAT_MGMT_ID = (SELECT ID
								  FROM TB_CM_LOC_MGMT
								 WHERE LOCAT_ID = P_LOC_DTL_ID)
        );
        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';
        END IF;

        
EXCEPTION
        WHEN OTHERS THEN
            IF(SQLCODE = -20012)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  RAISE;
              END IF; 

END;

/

