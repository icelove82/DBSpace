create PROCEDURE "SP_UI_CM_01_POP_10_S" (
	 P_ID                       IN VARCHAR2 := ''
	,P_ACTV_YN		            IN VARCHAR2 := ''
    ,P_BASE_PALLET_YN	        IN VARCHAR2 := ''
    ,P_WEIGHT			        IN NUMBER := ''
    ,P_UOM_ID	                IN VARCHAR2 := ''
    ,P_USER_ID	                IN VARCHAR2 := ''
    ,P_WRK_TYPE	                IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG         OUT VARCHAR2 
    ,P_RT_MSG                   OUT VARCHAR2
    
)
IS

    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';
    P_CONF_ID VARCHAR2(32) := '';
    NUMB VARCHAR2(5) := '';
    P_PALLET_CD VARCHAR2(30) := '';

BEGIN
	
	IF P_WRK_TYPE = 'SAVE'
	THEN
	
		SELECT A.ID INTO P_CONF_ID
		  FROM TB_CM_CONFIGURATION A 
		 WHERE A.CONF_KEY = '010';
		
		SELECT LPAD(TO_CHAR(TO_NUMBER(NVL(MAX(SUBSTR(PALLET_CD,-2)),'0'))+ 1),2,'0') INTO NUMB FROM TB_CM_PALLET;
		P_PALLET_CD := CONCAT('Pallet Type ', NUMB);
	
	    P_ERR_MSG := 'MSG_0006'; --'？？？ ？？？ ？？？？ ？？μ？？？ ？？？？？？？.'
	        IF NVL(P_UOM_ID,'') ='' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
	        END IF;
	
	    P_ERR_MSG := 'MSG_0008'; -- '？？？？？？ ？？？ ？？ ？？ ？？？？？？？. '
	        IF P_WEIGHT < 0  THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
	        END IF;
	
	    MERGE INTO TB_CM_PALLET B 
		USING (SELECT P_ID AS ID FROM DUAL) A
				ON     (B.ID = A.ID)
	
		WHEN MATCHED THEN
	
			UPDATE 
			   SET ACTV_YN				= P_ACTV_YN
				 , BASE_PALLET_YN		= P_BASE_PALLET_YN
				 , WEIGHT				= P_WEIGHT
				 , UOM_ID				= P_UOM_ID
				 , MODIFY_BY			= P_USER_ID
				 , MODIFY_DTTM			= SYSDATE()
	
		WHEN NOT MATCHED THEN			
		INSERT (
			--？？？？？？
			ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
			 --？？？？？？？？
			, CONF_ID
			, PALLET_CD
			, BASE_PALLET_YN
			, WEIGHT
			, UOM_ID
			, ACTV_YN
	
			)
		VALUES 
	  	    (
			 --？？？？？？
			TO_SINGLE_BYTE(SYS_GUID()), P_USER_ID, SYSDATE(), P_USER_ID, SYSDATE()
			 --？？？？？？？？
			, P_CONF_ID
			, P_PALLET_CD
			, P_BASE_PALLET_YN
			, P_WEIGHT
			, P_UOM_ID
			, P_ACTV_YN
		);
	
		P_RT_ROLLBACK_FLAG := 'true';
		P_RT_MSG := 'MSG_0001';  --？？？？ ？？？？？？？？.
	
	
	ELSIF P_WRK_TYPE = 'DELETE'
	THEN
	
	    DELETE FROM TB_CM_PALLET
				WHERE ID = P_ID;
	
	        P_RT_ROLLBACK_FLAG := 'true';
	        P_RT_MSG := 'MSG_0002';
	
	END IF;

        EXCEPTION
        WHEN OTHERS THEN
            IF(SQLCODE = -20012)
              THEN
              	  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF; 

END;

/

