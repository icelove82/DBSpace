create PROCEDURE                 SP_SMP_APPROVE_VER(
 P_sPLAN_TYPE      IN     VARCHAR2
,P_sBASE_MONTH     IN     VARCHAR2
,P_sVERSION_ID     IN     VARCHAR2
,P_sEXE_USER_ID    IN     VARCHAR2
,O_sFLAG           OUT    VARCHAR2
)
IS
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved. 
**************************************************************************
* Name    : SP_SMP_APPROVE_VER
* Purpose : 
* Notes   :
* <호출>

**************************************************************************
* History : 
* 2020-06-01 JMS Created
**************************************************************************/
  USER_EXCEPTION  EXCEPTION;

  G_nLOG_SEQ      NUMBER;
  G_sPROGRAMN_ID  NVARCHAR2(50) := 'SP_SMP_SPPROVE_RM_SUPPLY';
  G_sSTEP_SEQ     NVARCHAR2(50);
  G_sSTEP_DESC    NVARCHAR2(50);
  --G_sVERSION_ID   NVARCHAR2(50);
  G_sNEW_ROLL_MM_YN CHAR(1);
  G_sUSER_ID      NVARCHAR2(50);
  G_nSQL_CNT      NUMBER(20);
  G_sLOGMSG       VARCHAR2(4000);  

  G_nLOG_END_SEQ  NUMBER;

  G_nCNT          INT;
  G_sPLAN_TYPE    VARCHAR2(50);

BEGIN   
  O_sFLAG := 'S';
  G_sSTEP_SEQ := '0.0';   
  G_sSTEP_DESC := 'SP_SMP_APPROVE_VER (Start)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_END_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);
 
    IF P_sPLAN_TYPE IS NULL THEN
    
		SELECT PLAN_TYPE
		  INTO G_sPLAN_TYPE
		  FROM TB_SMP_VER_MST
		 WHERE BASE_MONTH = P_sBASE_MONTH
		   AND VERSION_ID = P_sVERSION_ID
		;
    
    END IF; 

  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Approve Ver.';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);  

      --이전에 승인했던 동일 계획 유형의 버전들을 승인 취소 처리
      UPDATE TB_SMP_VER_MST 
         SET APPR_FLAG = NULL
       WHERE PLAN_TYPE = NVL(P_sPLAN_TYPE, G_sPLAN_TYPE)
         AND VERSION_ID = P_sVERSION_ID
      ;
     
      -- 버전 승인 처리
      UPDATE TB_SMP_VER_MST 
         SET APPR_FLAG = 'Y'
           , APPR_DTTM = SYSDATE
           , APPR_USER_ID = P_sEXE_USER_ID
       WHERE PLAN_TYPE = NVL(P_sPLAN_TYPE, G_sPLAN_TYPE)
         AND BASE_MONTH = P_sBASE_MONTH
         AND VERSION_ID = P_sVERSION_ID
      ;
     
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
  COMMIT;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_END_SEQ, SQL%ROWCOUNT);
EXCEPTION
  WHEN USER_EXCEPTION THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);
END;


/

