create PROCEDURE "SP_UI_COMM_DATA_Q" (
     P_DATA_DIV 	 IN VARCHAR2 :=''
    ,P_PARAM1        IN VARCHAR2 :=''
    ,P_PARAM2        IN VARCHAR2 :=''
    ,P_PARAM3		 IN VARCHAR2 :=''
    ,pResult OUT SYS_REFCURSOR
)
IS

BEGIN

	IF P_DATA_DIV = 'UOM'
	THEN
	    OPEN pResult FOR
			SELECT B.UOM_CD		AS CD
				 , B.UOM_NM		AS CD_NM
				 , B.ID			AS UOM_ID
			  FROM TB_CM_CONFIGURATION A
	            INNER JOIN TB_CM_UOM B
	              ON A.ID = B.CONF_ID;
	
	ELSIF P_DATA_DIV = 'CUST'
	THEN
	    OPEN pResult FOR
			SELECT B.CONF_CD		AS CD
				 , B.CONF_NM		AS CD_NM
			  FROM TB_CM_CORPORATION A
	            INNER JOIN TB_CM_COMM_CONFIG B
	              ON A.ID = B.CONF_ID;
	
	ELSIF P_DATA_DIV = 'TEST_DATA'
	THEN
	    OPEN pResult FOR
			SELECT 'TEST_KEY'		AS CD
				 , 'TEST_VALUE'		AS CD_NM
	            FROM DUAL;
	
	ELSIF P_DATA_DIV = 'LOC_TP'
	THEN
	    OPEN pResult FOR
			SELECT A.LOCAT_LV
				 , B.COMN_CD AS LOC_TP
				 , A.LOC_MST_ID
			  FROM	(
					SELECT B.LOCAT_TP_ID
						 , B.LOCAT_LV
						 , B.ID	AS LOC_MST_ID
					  FROM TB_CM_CONFIGURATION A
	                    INNER JOIN TB_CM_LOC_MST  B
	                      ON A.ID = B.CONF_ID
					) A
					LEFT OUTER JOIN TB_AD_COMN_CODE B
					  ON A.LOCAT_TP_ID = B.ID;
	
	ELSIF P_DATA_DIV = 'LOC_CD'
	THEN
	    OPEN pResult FOR
			SELECT A.LOCAT_CD	AS LOC_CD
				 , A.LOCAT_NM	AS LOC_NM
			  FROM TB_CM_LOC_DTL A
			 WHERE A.LOCAT_MST_ID = P_PARAM1;
	
	ELSIF P_DATA_DIV = 'REGION'
	THEN
	    OPEN pResult FOR
			 SELECT Y.CONF_NM AS CD_NM
				  , Y.CONF_CD AS CD
	           FROM TB_CM_CONFIGURATION X 
	             INNER JOIN TB_CM_COMM_CONFIG Y 
	               ON X.ID = Y.CONF_ID
	          WHERE 1=1
	            AND Y.CONF_GRP_CD='CM_REGION'
			    AND Y.ACTV_YN = 'Y';
	
	ELSIF P_DATA_DIV = 'COUNTRY'
	THEN
	    OPEN pResult FOR
			  SELECT  B.CONF_CD		AS CODE  
					 ,B.CONF_NM		AS CODE_TEXT
			    FROM  TB_CM_CONFIGURATION A 
			      INNER JOIN TB_CM_COMM_CONFIG B 
			        ON A.ID = B.CONF_ID
			   WHERE B.CONF_GRP_CD = 'CM_COUNTRY'
			     AND B.ACTV_YN ='Y'
				 AND B.USE_YN ='Y' 
			   ORDER BY B.CONF_CD;
	
	ELSIF P_DATA_DIV = 'PLN_RES_TP'
	THEN
	    OPEN pResult FOR
			SELECT Y.COMN_CD_NM AS CD_NM
				 , Y.COMN_CD AS CD
	          FROM TB_AD_COMN_GRP X 
	            INNER JOIN TB_AD_COMN_CODE Y 
	              ON X.ID = Y.SRC_ID
	         WHERE 1=1
	           AND X.GRP_CD = 'PLN_RES_TP'
	           AND Y.USE_YN ='Y';  
	
	ELSIF P_DATA_DIV = 'DEFAT_INCOTERMS_CD'
	THEN
	    OPEN pResult FOR
			SELECT B.INCOTERMS AS CD  
				 , B.INCOTERMS AS CD_NM
	          FROM TB_CM_CONFIGURATION A 
	            INNER JOIN TB_CM_INCOTERMS B
	              ON A.ID = B.CONF_ID;
	
	ELSIF P_DATA_DIV = 'DEFAT_SHIPPING_TRANSP_TP'
	THEN
	    OPEN pResult FOR
		    SELECT  Y.VEHICL_TP AS CD
				 , Y.VEHICL_TP AS CD_NM			 
		      FROM  TB_CM_CONFIGURATION X 
	            INNER JOIN TB_CM_VEHICLE Y  
	              ON X.ID = Y.CONF_ID
	         WHERE 1=1
		       AND Y.ACTV_YN = 'Y';
	
	ELSIF P_DATA_DIV = 'STOCK_LOCATION_MGMT_TP'
	THEN
	    OPEN pResult FOR
			SELECT  Y.COMN_CD_NM AS CD_NM
				 , Y.COMN_CD AS CD
	           FROM  TB_AD_COMN_GRP X 
	             INNER JOIN TB_AD_COMN_CODE Y 
	               ON X.ID = Y.SRC_ID
	          WHERE 1=1
	            AND X.GRP_CD = 'STOCK_LOCATION_MGMT_TP'
	            AND Y.USE_YN ='Y' ;  
	
	ELSIF P_DATA_DIV = 'FIXED_PLN_TP'
	THEN
	    OPEN pResult FOR
			 SELECT  Y.COMN_CD_NM AS CD_NM
				  , Y.COMN_CD AS CD
	           FROM  TB_AD_COMN_GRP X
	             INNER JOIN TB_AD_COMN_CODE Y 
	               ON X.ID = Y.SRC_ID
	          WHERE 1=1
	            AND X.GRP_CD = 'FIXED_PLN_TP'
	            AND Y.USE_YN ='Y';   
	
	ELSIF P_DATA_DIV = 'CORPORATION1'
	THEN
	    OPEN pResult FOR
			SELECT CORPOR_ID
			  FROM TB_CM_CORPORATION;
	
	ELSIF P_DATA_DIV = 'CORPORATION2'
	THEN
	    OPEN pResult FOR
			SELECT CORPOR_NM
			  FROM TB_CM_CORPORATION;
	
	ELSIF P_DATA_DIV = 'GET_BOM_VER'
	THEN
	    OPEN pResult FOR
			SELECT A.BOM_VER_ID	 AS CD
			     , A.BOM_VER_ID  AS CD_NM
				 , 'BOM_VER'	 AS BOM_VER
			  FROM TB_CM_GLOBAL_BOM_DTL A 
			 WHERE A.PRDUCT_BOM_MST_ID = P_PARAM1;
			 
	ELSIF P_DATA_DIV ='GET_VEHICL_TP'
	    THEN
	        OPEN pResult FOR
            SELECT DISTINCT
                   A.ID          AS CD,
                   A.VEHICL_TP   AS CD_NM
	          FROM TB_CM_VEHICLE A
	               INNER JOIN TB_CM_BOD_LT B
	               ON A.ID = B.VEHICL_TP_ID
                   AND NVL(B.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_MST C
	               ON C.ID = B.FROM_LOCAT_MST_ID
                   AND NVL(C.ACTV_YN, 'N') = 'Y'
   	               INNER JOIN TB_CM_LOC_MST D
	               ON D.ID = B.TO_LOCAT_MST_ID
                   AND NVL(D.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_DTL E
	               ON E.LOCAT_MST_ID = C.ID
                   AND NVL(E.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_DTL F
	               ON F.LOCAT_MST_ID = D.ID
                   AND NVL(F.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_MGMT G
	               ON G.LOCAT_ID = E.ID
                   AND NVL(G.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_MGMT H
	               ON H.LOCAT_ID = F.ID
                   AND NVL(B.ACTV_YN, 'N') = 'Y'
	         WHERE NVL(A.ACTV_YN, 'N') = 'Y'
               AND G.ID = P_PARAM1
	           AND H.ID = P_PARAM2;
	            
	ELSIF P_DATA_DIV ='GET_ITEM_CODE'
		THEN
	        OPEN pResult FOR
	        SELECT DISTINCT
	               IMS.ID		AS ITEM_MST_ID
	             , IMS.ITEM_CD	AS ITEM_CD
                 , IMS.ITEM_NM AS ITEM_NM
                 ,CIT.CONVN_NM  AS ITEM_TP
	          FROM TB_CM_ITEM_MST IMS 
	               INNER JOIN TB_CM_ITEM_TYPE CIT 
	               ON IMS.ITEM_TP_ID = CIT.ID
	               AND ITEM_TP <> 'ROH'
	               AND NVL(CIT.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_SITE_ITEM SIT 
	               ON IMS.ID = SIT.ITEM_MST_ID
	               AND NVL(SIT.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_MGMT LMG
	               ON SIT.LOCAT_MGMT_ID =  LMG.ID
	               AND NVL(LMG.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_DTL LDT 
	               ON LMG.LOCAT_ID = LDT.ID
	               AND NVL(LDT.ACTV_YN, 'N') = 'Y'
                WHERE 1=1
				AND NVL(IMS.DEL_YN, 'N') = 'N'
                AND IMS.ITEM_CD LIKE '%'||P_PARAM1||'%'
                AND NVL(IMS.ITEM_NM, ' ') LIKE '%'||P_PARAM2||'%'
                AND IMS.ITEM_TP_ID = CASE WHEN P_PARAM3='ALL' THEN IMS.ITEM_TP_ID
                                                WHEN LTRIM(RTRIM(P_PARAM3)) IS NULL THEN IMS.ITEM_TP_ID
                                                WHEN LTRIM(RTRIM(P_PARAM3)) IS NOT NULL THEN P_PARAM3 END
             ORDER BY IMS.ITEM_CD;
	            
	ELSIF P_DATA_DIV ='GET_DP_ITEM'
		THEN
	        OPEN pResult FOR
	        SELECT DISTINCT
	               IMS.ID		AS ITEM_MST_ID
	             , IMS.ITEM_CD	AS ITEM_CD
                 , IMS.ITEM_NM AS ITEM_NM
                 ,CIT.CONVN_NM  AS ITEM_TP
	          FROM TB_CM_ITEM_MST IMS 
	               INNER JOIN TB_CM_ITEM_TYPE CIT 
	               ON IMS.ITEM_TP_ID = CIT.ID
	               AND ITEM_TP <> 'ROH'
	               AND NVL(CIT.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_SITE_ITEM SIT 
	               ON IMS.ID = SIT.ITEM_MST_ID
	               AND NVL(SIT.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_MGMT LMG
	               ON SIT.LOCAT_MGMT_ID =  LMG.ID
	               AND NVL(LMG.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_DTL LDT 
	               ON LMG.LOCAT_ID = LDT.ID
	               AND NVL(LDT.ACTV_YN, 'N') = 'Y'
                WHERE 1=1
				AND NVL(IMS.DEL_YN, 'N') = 'N'
				AND NVL(IMS.DP_PLAN_YN, 'N') = 'Y'
                AND IMS.ITEM_CD LIKE '%'||P_PARAM1||'%'
                AND NVL(IMS.ITEM_NM, ' ') LIKE '%'||P_PARAM2||'%'
                AND IMS.ITEM_TP_ID = CASE WHEN P_PARAM3='ALL' THEN IMS.ITEM_TP_ID
                                                WHEN LTRIM(RTRIM(P_PARAM3)) IS NULL THEN IMS.ITEM_TP_ID
                                                WHEN LTRIM(RTRIM(P_PARAM3)) IS NOT NULL THEN P_PARAM3 END
             ORDER BY IMS.ITEM_CD;
             
    ELSIF P_DATA_DIV = 'GET_ITEM_CODE_LIST'
        THEN
            OPEN pResult FOR
                 SELECT DISTINCT
	               IMS.ID		AS CD
	             , IMS.ITEM_CD	AS CD_NM
	          FROM TB_CM_ITEM_MST IMS 
	               INNER JOIN TB_CM_ITEM_TYPE CIT 
	               ON IMS.ITEM_TP_ID = CIT.ID
	               AND ITEM_TP <> 'ROH'
	               AND NVL(CIT.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_SITE_ITEM SIT 
	               ON IMS.ID = SIT.ITEM_MST_ID
	               AND NVL(SIT.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_MGMT LMG
	               ON SIT.LOCAT_MGMT_ID =  LMG.ID
	               AND NVL(LMG.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_DTL LDT 
	               ON LMG.LOCAT_ID = LDT.ID
	               AND NVL(LDT.ACTV_YN, 'N') = 'Y'
                WHERE 1= CASE WHEN P_PARAM1 IS NULL OR P_PARAM1 = '' THEN 1
	                        WHEN LDT.ID = P_PARAM1 THEN 1
	                   END;
                       
	ELSIF P_DATA_DIV ='GET_ITEM_CODE_ALL'
		THEN
	        OPEN pResult FOR
	        SELECT DISTINCT
	               IMS.ID			AS CD
	             , IMS.ITEM_CD		AS CD_NM
	          FROM TB_CM_ITEM_MST IMS 
	               INNER JOIN TB_CM_SITE_ITEM SIT 
	               ON IMS.ID = SIT.ITEM_MST_ID
	               AND NVL(SIT.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_MGMT LMG
	               ON SIT.LOCAT_MGMT_ID =  LMG.ID
	               AND NVL(LMG.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_DTL LDT 
	               ON LMG.LOCAT_ID = LDT.ID
	               AND NVL(LDT.ACTV_YN, 'N') = 'Y'
	         WHERE 1 = CASE WHEN P_PARAM1 IS NULL OR P_PARAM1 = '' THEN 1
	                        WHEN LDT.ID = P_PARAM1 THEN 1
	                   END
             ORDER BY IMS.ITEM_CD;
             
	ELSIF P_DATA_DIV ='GET_LOCAT_ITEM'
		THEN
			--P_PARAM2 : LOC_DTL_ID
	        OPEN pResult FOR
		    SELECT SIT.ID			AS CD
				 , IMS.ITEM_CD		AS CD_NM
		      FROM TB_CM_LOC_DTL LDT 
		           INNER JOIN TB_CM_LOC_MGMT LMG 
		           ON LDT.ID = LMG.LOCAT_ID
	               AND NVL(LMG.ACTV_YN, 'N') = 'Y'
		           INNER JOIN TB_CM_SITE_ITEM SIT
		           ON LMG.ID = SIT.LOCAT_MGMT_ID
	               AND NVL(SIT.ACTV_YN, 'N') = 'Y'
				   INNER JOIN TB_CM_ITEM_MST IMS 
		           ON SIT.ITEM_MST_ID = IMS.ID
		     WHERE NVL(LDT.ACTV_YN, 'N') = 'Y'
		       AND 1 = CASE WHEN P_PARAM1 IS NULL OR P_PARAM1 = '' THEN 1
		                    WHEN LDT.ID = P_PARAM1 THEN 1
		               END
		     ORDER BY IMS.ITEM_CD;
             
	ELSIF P_DATA_DIV ='GET_ITEM_LOCAT'
		THEN
			--P_PARAM2 : ITEM_ID
	        OPEN pResult FOR
        	SELECT DISTINCT 
		   		   LDT.ID				AS CD
		 		 , LDT.LOCAT_CD			AS CD_NM
	  		  FROM TB_CM_LOC_DTL LDT 
	    		   INNER JOIN TB_CM_LOC_MGMT LMG 
          		   ON LDT.ID = LMG.LOCAT_ID
	               AND NVL(LMG.ACTV_YN, 'N') = 'Y'
        		   INNER JOIN TB_CM_SITE_ITEM SIT	
          		   ON LMG.ID = SIT.LOCAT_MGMT_ID
	               AND NVL(SIT.ACTV_YN, 'N') = 'Y'
        		   INNER JOIN TB_CM_ITEM_MST IMS
          		   ON SIT.ITEM_MST_ID = IMS.ID
	 		 WHERE NVL(LDT.ACTV_YN, 'N') = 'Y'
         	   AND 1 = CASE WHEN P_PARAM1 IS NULL OR P_PARAM1 = '' THEN 1
                            WHEN IMS.ID = P_PARAM1 THEN 1
             		   END
			 ORDER BY LDT.LOCAT_CD;
             
	ELSIF P_DATA_DIV ='GET_ITEM_RES_PREF'
		THEN
			--P_PARAM1 : LOC_DTL_ID
			--P_PARAM2 : ITEM_ID
	        OPEN pResult FOR
	        SELECT RMD.ID			AS CD
	             , RMD.RES_CD		AS CD_NM
	          FROM TB_MP_RES_MGMT_DTL RMD  
	               INNER JOIN TB_MP_ITEM_RES_PREFER_MST RPM  
	               ON RMD.ID = RPM.RES_ID
	               INNER JOIN TB_CM_SITE_ITEM SIT  
	               ON RPM.LOCAT_ITEM_ID = SIT.ID
	               INNER JOIN TB_CM_ITEM_MST IMS  
	               ON SIT.ITEM_MST_ID = IMS.ID
	               INNER JOIN TB_CM_ITEM_TYPE CIT  
	               ON IMS.ITEM_TP_ID = CIT.ID
	               AND ITEM_TP <> 'ROH'
	               INNER JOIN TB_CM_LOC_MGMT LMG  
	               ON SIT.LOCAT_MGMT_ID =  LMG.ID
	               INNER JOIN TB_CM_LOC_DTL LDT  
	               ON LMG.LOCAT_ID = LDT.ID
	         WHERE 1 = 1
	           AND 1 = CASE WHEN P_PARAM1 IS NULL THEN 1
	                       WHEN LDT.ID = P_PARAM1 THEN 1
	                   END
	           AND 1 = CASE WHEN P_PARAM2 IS NULL THEN 1
	                       WHEN SIT.ID = P_PARAM2 THEN 1
	                   END;
             
	ELSIF P_DATA_DIV ='GET_LOCAT_RES'
		THEN
			--P_PARAM1 : LOC_DTL_ID
	        OPEN pResult FOR
	        SELECT RMD.ID			AS CD
	             , RMD.RES_CD		AS CD_NM
	          FROM TB_MP_RES_MGMT_DTL RMD  
	               INNER JOIN TB_MP_RES_MGMT_MST RMM  
	               ON RMD.RES_MGMT_MST_ID = RMM.ID 
	               INNER JOIN TB_CM_LOC_MGMT LMG
	               ON RMM.LOCAT_MGMT_ID = LMG.ID
	               INNER JOIN TB_CM_LOC_DTL LDT
	               ON LMG.LOCAT_ID = LDT.ID
	         WHERE 1=1
	           AND 1 = CASE WHEN P_PARAM1 = NULL THEN 1
	                       WHEN LDT.ID = P_PARAM1 THEN 1
	                   END;
             
	ELSIF P_DATA_DIV ='GET_ITEM_RES_PREF'
		THEN
			--P_PARAM1 : LOCAT_ITEM_ID
	        OPEN pResult FOR
            SELECT RPM.ID				AS CD
	             , RMD.RES_CD			AS CD_NM
	          FROM TB_CM_SITE_ITEM SIT 
	               INNER JOIN TB_MP_ITEM_RES_PREFER_MST RPM 
	               ON SIT.ID = RPM.LOCAT_ITEM_ID
	               INNER JOIN TB_MP_RES_MGMT_DTL RMD
	               ON RPM.RES_ID = RMD.ID
	         WHERE 1=1
	           AND SIT.ID = P_PARAM1;
             
	ELSIF P_DATA_DIV ='GET_LOCAT_INFO'
		THEN
			--P_PARAM1 : P_LOC_CD
	        OPEN pResult FOR
	        SELECT DISTINCT 
			 	   DTL.ID
				 , ACM.COMN_CD_NM		AS LOCAT_TP
				 , MST.LOCAT_LV			AS LOCAT_LV
				 , DTL.LOCAT_CD			AS LOCAT_CD
				 , DTL.LOCAT_NM			AS LOCAT_NM
				 , MGT.PLAN_RES_TP_ID	AS PLAN_RES_TP_ID
				 , ACD1.COMN_CD_NM		AS PLAN_RES_TP
				 , RMG.ROUTE_GRP		AS ROUTE_GRP
				 , RGP.RES_GRP_CD		AS RES_GRP_CD
				 , RGP.DESCRIP			AS RES_DESCRIP
				 , ACD2.COMN_CD_NM		AS RES_GRP_TP
				 , RMG.WC				AS WC
				 , RMG.ACTV_YN			AS ACTV_YN
			  FROM TB_CM_LOC_DTL DTL 
				   LEFT OUTER JOIN TB_CM_LOC_MST MST 
				   ON MST.ID = DTL.LOCAT_MST_ID
				   LEFT OUTER JOIN TB_AD_COMN_CODE	ACM
				   ON MST.LOCAT_TP_ID = ACM.ID
				   LEFT OUTER JOIN TB_CM_LOC_MGMT MGT
				   ON DTL.ID = MGT.LOCAT_ID
				   LEFT OUTER JOIN TB_AD_COMN_CODE ACD1
				   ON MGT.PLAN_RES_TP_ID = ACD1.ID
				   LEFT OUTER JOIN TB_MP_RES_MGMT_MST RMG 
				   ON MGT.ID = RMG.LOCAT_MGMT_ID
				   LEFT OUTER JOIN TB_CM_RES_GROUP RGP
				   ON RMG.RES_GRP_ID = RGP.ID
				   LEFT OUTER JOIN TB_AD_COMN_CODE ACD2 
				   ON RGP.RES_GRP_TP_ID = ACD2.ID
			 WHERE DTL.ID = P_PARAM1;
             
	ELSIF P_DATA_DIV ='GET_ITEM_CLASS'
		THEN
	        OPEN pResult FOR
	        SELECT A.ID 
			     , B.ITEM_SCOPE_NM AS ITEM_LV_NM
			     , A.ITEM_CLASS_VAL
			     , A.DESCRIP
			     , A.CONTINU_PRDUCT_YN
			     , A.PROD_MIX_YN
			     , A.ACTV_YN
		      FROM TB_CM_ITEM_CLASS_MST A
			       LEFT OUTER JOIN TB_CM_UOM C  
	               ON A.UOM_ID = C.ID
			       INNER JOIN TB_CM_ITEM_SCOPE_MST B 
	               ON A.ITEM_SCOPE_MST_ID = B.ID;
             
	ELSIF P_DATA_DIV ='GET_MAIN_CAL'
		THEN
	        OPEN pResult FOR
  	        SELECT ACD1.COMN_CD_NM			AS LOCAT_TP
			     , LMS.LOCAT_LV				AS LOCAT_LV
			     , LDT.LOCAT_CD				AS LOCAT_CD
			     , LDT.LOCAT_NM				AS LOCAT_NM
			     , RMD.RES_CD				AS RES_CD
			     , RMD.RES_DESCRIP			AS RES_DESCRIP
		    	 , RHL.CALENDAR_ID			AS CALENDAR_ID
			     , RHL.CALENDAR_DESCRIP		AS CALENDAR_DESCRIP
		    	 , ACD3.COMN_CD_NM			AS CYCL_TP
		      FROM TB_MP_RES_HOLIDAY RHL
				   INNER JOIN TB_AD_COMN_CODE ACD3
				   ON RHL.CYCL_TP_ID = ACD3.ID
	               INNER JOIN TB_MP_RES_MGMT_DTL RMD
	               ON RHL.RES_ID = RMD.ID
	               INNER JOIN TB_MP_RES_MGMT_MST RMM
	               ON RMD.RES_MGMT_MST_ID =  RMM.ID 
	               INNER JOIN TB_CM_LOC_MGMT LMG
	               ON RMM.LOCAT_MGMT_ID = LMG.ID
			       LEFT OUTER JOIN TB_AD_COMN_CODE ACD2
				   ON LMG.PLAN_RES_TP_ID = ACD2.ID
	               INNER JOIN TB_CM_LOC_DTL LDT
	               ON LMG.LOCAT_ID = LDT.ID
	               INNER JOIN TB_CM_LOC_MST LMS
	               ON LDT.LOCAT_MST_ID = LMS.ID
				   INNER JOIN TB_AD_COMN_CODE ACD1
				   ON LMS.LOCAT_TP_ID = ACD1.ID
		     WHERE UPPER(LDT.LOCAT_CD) LIKE '%'||UPPER(P_PARAM1)||'%'
		     ORDER BY ACD1.COMN_CD_NM, LDT.LOCAT_CD, RMD.RES_CD;
             
	ELSIF P_DATA_DIV ='GET_ITEM_LV'
		THEN
	        OPEN pResult FOR
			SELECT A.ID				AS ITEM_LV_ID
				 , A.ITEM_LV_CD
				 , A.ITEM_LV_NM
				 , B.ITEM_LV_CD		AS PARENT_ITEM_LV_CD
				 , B.ITEM_LV_NM		AS PARENT_ITEM_LV_NM
			  FROM TB_CM_ITEM_LEVEL_MGMT A
				   LEFT OUTER JOIN TB_CM_ITEM_LEVEL_MGMT B
				   ON B.ID = A.PARENT_ITEM_LV_ID
			 WHERE A.ACTV_YN = 'Y';
             
	ELSIF P_DATA_DIV ='GET_SALES_LV'
		THEN
	        OPEN pResult FOR
			SELECT A.ID				AS SALES_LV_ID
				 , A.SALES_LV_CD
				 , A.SALES_LV_NM
				 , B.SALES_LV_CD	AS PARENT_SALES_LV_CD
				 , B.SALES_LV_NM	AS PARENT_SALES_LV_NM
				 , A.VIRTUAL_YN
			  FROM TB_DP_SALES_LEVEL_MGMT A
				   LEFT OUTER JOIN TB_DP_SALES_LEVEL_MGMT B
				   ON B.ID = A.PARENT_SALES_LV_ID
			 WHERE A.ACTV_YN = 'Y';
			 
	END IF;

END;

/

