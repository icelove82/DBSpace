create procedure "SP_UI_BF_10_S1" 
(
     P_VER_ID           IN  VARCHAR2
    ,P_SALES_LV_CD      IN  VARCHAR2
    ,P_ACCOUNT_CD       IN  VARCHAR2
    ,P_ITEM_LV_CD       IN  VARCHAR2
    ,P_ITEM_CD          IN  VARCHAR2
    ,P_BASE_DATE        IN  DATE
    ,P_QTY              IN  FLOAT
    ,P_USER_ID          IN  VARCHAR2
    ,P_RT_ROLLBACK_FLAG OUT VARCHAR2
    ,P_RT_MSG           OUT VARCHAR2
)IS
/************************************************************
     ？？？？？ : ？？？？？？
     ？？？？？ : 2019.02.12
     ？？？？ : BF ？？？？ ？？？？

     History (？？？？？？ / ？？？？？？ / ？？？？ ？？？？)
     > 2019.02.12 / ？？？？？？ / ？？？ ？？？
************************************************************/
       P_ERR_STATUS INT := 0;
       P_ERR_MSG VARCHAR2(4000):='';
BEGIN
--------------------------------------------------------------------------------------------------------
    -- Validation
--------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------
    -- Main Procedure
--------------------------------------------------------------------------------------------------------
-- VF Result Save (Dynamic Level？？？ ID？？ a？？ ？？？？ ？？？？)
    UPDATE TB_BF_RESULT
       SET QTY      = p_QTY
        ,  MODIFY_BY     = P_USER_ID
        ,  MODIFY_DTTM   = SYSDATE
     WHERE VER_CD      = P_VER_ID
       AND SALES_LV_CD = P_SALES_LV_CD
--       AND ACCOUNT_CD  = P_ACCOUNT_CD
       AND ITEM_LV_CD  = P_ITEM_LV_CD
--       AND ITEM_CD     = P_ITEM_CD
       AND BASE_DATE   = P_BASE_DATE
    ;

       P_RT_MSG := 'MSG_0001';
       /* ？？？？ o？？ ============================================================================*/
       EXCEPTION   
        WHEN OTHERS THEN  -- ？？？ ？？？？？？？ ？？？？ ？？？？ ？？？？ : e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF; 
END
;

/

