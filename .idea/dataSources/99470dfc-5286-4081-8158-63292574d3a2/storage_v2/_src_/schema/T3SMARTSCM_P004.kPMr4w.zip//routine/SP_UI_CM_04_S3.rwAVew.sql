create PROCEDURE SP_UI_CM_04_S3(
    P_ID					IN VARCHAR2 :=''				-- ID
	,P_BOM_ITEM_TP_ID		IN VARCHAR2 :=''		-- BOM Item Type
	,P_PROCUR_TP_ID		    IN VARCHAR2 :=''		-- ？？？？？？？？
	,P_MIN_ORDER_SIZE		IN VARCHAR2 :=''		-- Min Order Size
	,P_MAX_ORDER_SIZE		IN VARCHAR2 :=''		-- Max Order Size
	,P_SRA					IN DATE := ''		-- SRA
	,P_RTS					IN DATE := ''		-- RTS
	,P_EOP					IN DATE := ''		-- EOP
	,P_EOS					IN DATE := ''		-- EOS
	,P_PARENT_ITEM_EOL		IN DATE := ''		-- ？？？？？？？？？？？？？
	,P_INV_ONHAND_YN		IN CHAR := ''		-- ？？？？？？？？？？？？
	,P_INV_POLICY		    IN VARCHAR2 :=''		-- INV Policy
	,P_STD_UTPIC			IN VARCHAR2 :=''		-- ？？？？？
	,P_ITEM_MST_ID			IN VARCHAR2 :=''			    -- ITEM_MST_ID
	,P_USER_ID				IN VARCHAR2 :='' 		
	,P_RT_ROLLBACK_FLAG	     OUT VARCHAR2
	,P_RT_MSG				 OUT VARCHAR2
)IS

P_ERR_STATUS NUMBER :=0;
P_ERR_MSG  VARCHAR2(4000) :='';
BEGIN 
        P_RT_ROLLBACK_FLAG := 'true';
            P_ERR_MSG := 'MSG_0008'; -- '？？？？？？ ？？？ ？？ ？？ ？？？？？？？. '
		   IF (P_MIN_ORDER_SIZE < 0 OR P_MAX_ORDER_SIZE < 0 OR P_STD_UTPIC < 0)
		   THEN  RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;

		 P_ERR_MSG := 'MSG_5015'; --'？？？？？？？？？？？？ ？？？？？？？？？？？？？？ ？？？？？ ？？？？.'
		IF P_MIN_ORDER_SIZE > P_MAX_ORDER_SIZE THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;
            
        UPDATE TB_CM_SITE_ITEM
			SET
					BOM_ITEM_TP_ID	=	P_BOM_ITEM_TP_ID
				  , PROCUR_TP_ID	=	P_PROCUR_TP_ID
				  , SRA				=	P_SRA
				  , RTS				=	P_RTS
				  , EOP				=	P_EOP
				  , EOS				=	P_EOS
				  , PARENT_ITEM_EOL	=	P_PARENT_ITEM_EOL
				  , INV_ONHAND_YN   =	P_INV_ONHAND_YN
				  , INV_POLICY_ID	=	P_INV_POLICY
				  , STD_UTPIC		=	TO_NUMBER(DECODE(RTRIM(P_STD_UTPIC),'',null,P_STD_UTPIC))
				  , MODIFY_BY		=	P_USER_ID
				  , MODIFY_DTTM		=	SYSDATE
			WHERE ID = P_ID;

		UPDATE TB_CM_ITEM_MST
			SET
				 MIN_ORDER_SIZE = TO_NUMBER(DECODE(RTRIM(P_MIN_ORDER_SIZE),'',null,P_MIN_ORDER_SIZE))
				,MAX_ORDER_SIZE = TO_NUMBER(DECODE(RTRIM(P_MAX_ORDER_SIZE),'',null,P_MAX_ORDER_SIZE))
				,MODIFY_BY      = P_USER_ID
				,MODIFY_DTTM    = SYSDATE
			WHERE ID = P_ITEM_MST_ID;
		------------------------------------------------------------------------------
		-- ？？？？, MIN/MAX ORDER SIZE ？？ ？？？？ TB_CM_ITEM_MST ？？？？？？？ ？？？？ ？？？ ？？ 
		-- TB_CM_SITE_ITEM ？？ TB_CM_ITEM_MST ？？ 1:N ？？？？？？？？ ？？？？？ ROW？？ ？？？？？？ 
		-- ？？？？ ITEM_MST_ID？？ ？？？？ ？？？？？ ROW？？ ？？？？？ ？？.	 by ？？？？？？
		------------------------------------------------------------------------------

	  P_RT_ROLLBACK_FLAG := 'true';
	  P_RT_MSG := 'MSG_0001';  --？？？？ ？？？？？？？？.


    EXCEPTION
    WHEN OTHERS THEN
        IF(SQLCODE = -20012)
          THEN 
              P_RT_ROLLBACK_FLAG := 'false';
              P_RT_MSG := P_ERR_MSG;
          ELSE
              RAISE;
          END IF;

END;

/

