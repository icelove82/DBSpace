create PROCEDURE SP_UI_BF_01_S1 (
     P_ID                IN   VARCHAR2 := '',
     P_POLICY_CD         IN   VARCHAR2 := '',
     P_POLICY_VAL        IN   VARCHAR2 := '',
     P_DESCRIP           IN   VARCHAR2 := '',
     P_USER_ID           IN   VARCHAR2 := '',
     P_RT_ROLLBACK_FLAG OUT VARCHAR2  ,
     P_RT_MSG           OUT VARCHAR2   
)
IS
     P_ERR_STATUS INT := 0;
     P_ERR_MSG VARCHAR2(4000):='';
BEGIN

     SELECT COUNT(*) INTO P_ERR_STATUS
       FROM TB_BF_PLAN_POLICY
      WHERE 1=1
        AND POLICY_CD = P_POLICY_CD
        AND ID != P_ID;

     IF ( P_ERR_STATUS > 0 )
     THEN 
          P_ERR_MSG := 'MSG_0013';
          RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);	
     END IF;

     MERGE INTO TB_BF_PLAN_POLICY TGT
          USING ( 
                    SELECT
                     P_ID			    	    AS ID			
                    ,UPPER(RTRIM(P_POLICY_CD))   AS POLICY_CD	
                    ,RTRIM(P_POLICY_VAL)	    AS POLICY_VAL	
                    ,RTRIM(P_DESCRIP)		    AS DESCRIP		
                    ,P_USER_ID			    AS USER_ID	
                    FROM DUAL
                 ) SRC
				ON (TGT.ID = SRC.ID)
				WHEN MATCHED THEN
					 UPDATE 
					   SET   		
							 TGT.POLICY_CD	 = SRC.POLICY_CD	
							,TGT.POLICY_VAL = SRC.POLICY_VAL	
							,TGT.DESCRIP	 = SRC.DESCRIP			
							,TGT.MODIFY_BY	 = SRC.USER_ID	
							,TGT.MODIFY_DTTM = SYSDATE	
				WHEN NOT MATCHED THEN 
					 INSERT (
							 ID			
							,POLICY_CD	
							,POLICY_VAL	
							,DESCRIP		
							,CREATE_BY	
							,CREATE_DTTM	
							,MODIFY_BY	
							,MODIFY_DTTM								 
							) 
					 VALUES (
							 TO_SINGLE_BYTE(SYS_GUID())	
							,SRC.POLICY_CD	
							,SRC.POLICY_VAL	
							,SRC.DESCRIP		
							,SRC.USER_ID 
							,SYSDATE
							,NULL
							,NULL          
 							) 
							;    

     P_RT_ROLLBACK_FLAG := 'true';
     P_RT_MSG := 'MSG_0001'; 
       /* ？？？？ o？？ ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN   
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;     

END;

/

