create PROCEDURE                 SP_UI_DP_23_VER_POP_Q3
(
     p_CHANGE_COM       VARCHAR2
    ,p_VER_FROM_DATE    DATE
    ,p_VER_TO_DATE      DATE
    ,p_DATE             DATE
    ,p_PLAN_TP          VARCHAR2
    ,pRESULT            OUT SYS_REFCURSOR
)
IS

/*****************************************************************************
Title : SP_UI_DP_23_VER_POP_Q3
理쒖큹 �옉�꽦�옄 : �씠怨좎�
理쒖큹 �깮�꽦�씪 : 2017.08.09
?
�꽕紐� 
 - DP Control Board 理쒖떊 踰꾩쟾 �뙘�뾽(Horizon From/ To Date , DTF Date Change)
 ?
History (�닔�젙�씪�옄 / �닔�젙�옄 / �닔�젙�궡�슜)
-  2017.08.09 / �씠怨좎� / 理쒖큹 �옉�꽦
-  2019.06.26 / 源��냼�씗 / TO DATE Month �씪 �븣, 怨꾩궛 �삤瑜� �닔�젙 諛� 肄붾뱶 �젙由�?
-  2019.12.27 / 源��냼�씗 / Partial week�뿉 ���븳 DTF& �떆�옉�씪 泥섎━ 
-  2020.03.18 / 源��냼�씗 / Change Week Rule : DP_WK
-  2020.08.24 / 源��냼�씗 / DTF 留덉�留됰궇吏쒕줈 �꽭�똿 
-  2020.12.23 / 誘쇨꼍�썕 / MSSQL -> ORACLE
-  2021.01.25 / �꽌���븯 / 3�떒 媛�蹂� 援ш컙 蹂�寃�
-  2021.02.08 / 源��슜�닔 / SK�씠�끂踰좎씠�뀡�뿉 留욊쾶 DP_PLAN_BASE 媛믪쓣 �솢�슜�븯�뿬 �씪�옄 �꽕�젙
-  2021.10.26 / 諛뺤삦二� / 1st_Year(Y1:Week, Y2~Y3:Month), 2th_Year(Y1~Y2:Week, Y3~Y4:Month) �빐�떦 湲곗��쑝濡� 媛�蹂��씪�옄 議곗젙
*****************************************************************************/

v_VER_BUCKET        VARCHAR2(50);
v_VER_HORIZON       INT;
v_VER_DTF           INT;
v_VER_STAT_BUCKET   INT;
v_VER_FROM_DATE     DATE;
v_VER_TO_DATE       DATE;
v_DTF_DATE          DATE;
/* Partial Parameter Add*/
v_PAR_HORIZON       INT;
v_PAR_BUCKET        VARCHAR2(10);
v_PAR_DATE          DATE;
v_PAR_TO_DATE       DATE;
v_PAR_HORIZON2      INT;
v_PAR_BUCKET2       VARCHAR2(10);
v_PAR_DATE2         DATE;
v_PAR_TO_DATE2      DATE;
v_DATE              DATE := NULL;
v_TMP_ENDDATE       DATE := NULL ;
v_CHANGE_MON        VARCHAR2(2);   -- 2021.02.08 源��슜�닔 : 1�뀈�씠 異붽��릺�뒗 �썡 湲곗� - �쁽�옱 : 10�썡
v_ALLYEAR           VARCHAR2(3);   -- 2021.02.08 源��슜�닔 : �쟾泥닿린媛�(�뀈)          - �쁽�옱 : 10�뀈
v_1ST_MONTH         VARCHAR2(2);   -- 2021.02.08 源��슜�닔 : 泥ル쾲吏� 媛�蹂�援ш컙 �떆�옉�썡 - �쁽�옱 : 13媛쒖썡 遺��꽣 媛�蹂�(誘몄궗�슜) => v_1ST_YEAR�쓣 �솢�슜�븯�뒗 寃껋쑝濡� 蹂�寃�
v_1ST_YEAR          VARCHAR2(2);   -- 2021.02.08 源��슜�닔 : 泥ル쾲吏� 媛�蹂�援ш컙 �떆�옉�뀈 -> v_1ST_MONTH ���떊�뿉 �궗�슜  - �쁽�옱 : 3�뀈李⑤��꽣 媛�蹂�
v_2TH_YEAR          VARCHAR2(2);   -- 2021.02.08 源��슜�닔 : �몢踰덉㎏ 媛�蹂�援ш컙 �떆�옉�뀈 - �쁽�옱 : 4�뀈李⑤��꽣 媛�蹂�
v_CURDT             VARCHAR2(8) := TO_CHAR(SYSDATE,'YYYYMMDD');  -- 2021.02.08 源��슜�닔 : �쁽�옱 �씪�옄

BEGIN

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    1. Setting Master Data
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
    v_DATE := p_DATE;

    SELECT  "'B'"
           ,"'H'"
           ,"'DTF'"
           ,CASE WHEN p_CHANGE_COM = 'FROM_DT' THEN 0 ELSE TO_NUMBER("'SB'") END
           ,"'PB'"
           ,"'PH'"
           ,"'PB2'"
           ,"'PH2'"
            INTO
             v_VER_BUCKET       
           , v_VER_HORIZON  
           , v_VER_DTF      
           , v_VER_STAT_BUCKET
           , v_PAR_BUCKET       
           , v_PAR_HORIZON  
           , v_PAR_BUCKET2  
           , v_PAR_HORIZON2 
      FROM (
            SELECT   PL.CONF_CD     AS POLICY_CD
                   , PP.POLICY_VAL  AS POLICY_VAL
              FROM TB_DP_PLAN_POLICY PP
                   INNER JOIN
                   TB_CM_COMM_CONFIG PL
                ON(PP.POLICY_ID = PL.ID  AND PL.ACTV_YN = 'Y') -- PLAN POLICY VALUES
            WHERE 1=1
              AND PP.MODULE_ID = 'DP'
              AND PP.PLAN_TP_ID = p_PLAN_TP
              AND (PL.CONF_CD = 'B' OR PL.CONF_CD = 'H' OR PL.CONF_CD ='DTF' OR PL.CONF_CD ='SB' OR PL.CONF_CD ='PB' OR PL.CONF_CD ='PH'OR PL.CONF_CD ='PB2' OR PL.CONF_CD ='PH2')            
          ) CONF PIVOT (MAX(POLICY_VAL) FOR POLICY_CD IN ('B','H','DTF','SB','PB', 'PH', 'PB2','PH2')) PVT 
          ;


/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    2. Change << From Date >> Datepicker
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
    IF (p_CHANGE_COM = 'FROM_DT' OR p_CHANGE_COM = 'OPEN')
    THEN
    /************************************************************************************************************************
        -- Date Setting
    ************************************************************************************************************************/
/*
        WITH CAL
        AS (
            SELECT  MIN(DAT)    AS STRT_DATE
                  , MAX(DAT)    AS END_DATE
                  , DENSE_RANK () OVER (ORDER BY MIN(DAT) ASC) AS RW 
              FROM TB_CM_CALENDAR
          GROUP BY TO_CHAR(YYYY)
                 , CASE WHEN v_VER_BUCKET IN ('M', 'PW') THEN TO_CHAR(MM) ELSE '1' END
                 , CASE WHEN v_VER_BUCKET IN ('W', 'PW') THEN TO_CHAR(DP_WK) ELSE '1' END
        ), 
        RW
        AS (
             SELECT RW+COALESCE(v_VER_STAT_BUCKET,0)                                        AS ST
                  , RW+COALESCE(v_VER_HORIZON   ,0)+COALESCE(v_VER_STAT_BUCKET,0)-1     AS ED
                  , RW+COALESCE(v_VER_DTF       ,0)+COALESCE(v_VER_STAT_BUCKET,0)-1     AS DT
                  , RW+COALESCE(v_PAR_HORIZON   ,0)+COALESCE(v_VER_STAT_BUCKET,0)-1     AS PA
              FROM CAL
             WHERE v_DATE BETWEEN STRT_DATE AND END_DATE 
        ), 
        RWP
        AS (    SELECT BASE, "NUM"
                  FROM RW
                       UNPIVOT ("NUM" FOR BASE IN (ST, ED, DT, PA)) UP
        ), 
        M
        AS (
            SELECT  CASE RWP.BASE
                    WHEN 'ST' THEN CAL.STRT_DATE
                    WHEN 'ED' THEN CAL.END_DATE
                    WHEN 'DT' THEN CAL.END_DATE 
                    WHEN 'PA' THEN CAL.STRT_DATE
                   END      AS BASE_DATE
                 , RWP.BASE                 
              FROM CAL
                   INNER JOIN
                   RWP
                ON CAL.RW = RWP."NUM"
           )
           SELECT "'ST'"
                , "'ED'"
                , "'DT'"
                , "'PA'"
                  INTO
                  v_VER_FROM_DATE
                , v_VER_TO_DATE
                , v_DTF_DATE
                , v_PAR_DATE
             FROM M
                   PIVOT 
                   (MAX(BASE_DATE) FOR BASE IN ('ST', 'ED', 'DT', 'PA')) PVT        
        ;
*/
    -- 2021.02.08 源��슜�닔 : DP_PLAN_BASE 媛믪쓣 湲곗��쑝濡� �옱�꽕�젙

    BEGIN
        SELECT    ATTR_01 
          INTO    v_CHANGE_MON
          FROM    TB_CM_COMM_CONFIG      
         WHERE    CONF_ID = (SELECT ID FROM TB_CM_CONFIGURATION WHERE CONF_NM = 'DP_PLAN_BASE')
           AND    CONF_CD = 'CHANGE_MON'
           AND    ACTV_YN = 'Y'
           AND    USE_YN  = 'Y'
        ;

        SELECT    ATTR_01 
          INTO    v_ALLYEAR
          FROM    TB_CM_COMM_CONFIG      
         WHERE    CONF_ID = (SELECT ID FROM TB_CM_CONFIGURATION WHERE CONF_NM = 'DP_PLAN_BASE')
           AND    CONF_CD = 'ALLYEAR'
           AND    ACTV_YN = 'Y'
           AND    USE_YN  = 'Y'
        ;

        SELECT    ATTR_01 
          INTO    v_1ST_YEAR
          FROM    TB_CM_COMM_CONFIG      
         WHERE    CONF_ID = (SELECT ID FROM TB_CM_CONFIGURATION WHERE CONF_NM = 'DP_PLAN_BASE')
           AND    CONF_CD = '1ST_YEAR'
           AND    ACTV_YN = 'Y'
           AND    USE_YN  = 'Y'
        ;

        SELECT    ATTR_01 
          INTO    v_2TH_YEAR
          FROM    TB_CM_COMM_CONFIG      
         WHERE    CONF_ID = (SELECT ID FROM TB_CM_CONFIGURATION WHERE CONF_NM = 'DP_PLAN_BASE')
           AND    CONF_CD = '2TH_YEAR'
           AND    ACTV_YN = 'Y'
           AND    USE_YN  = 'Y'
        ;

    EXCEPTION WHEN OTHERS THEN
        NULL;
    END;

    -- �궗�슜�옄媛� �떎瑜� �썡�쓣 �꽑�깮�븳 寃쎌슦 �빐�떦 �썡濡� 蹂�寃�
    IF p_VER_FROM_DATE IS NOT NULL THEN
        SELECT    TO_CHAR(TO_DATE(TO_CHAR(p_VER_FROM_DATE,'YYYYMM')||'01','YYYYMMDD'),'YYYYMMDD') AS ST
          INTO    v_CURDT
          FROM    DUAL
        ;
    END IF;    

    SELECT    TO_DATE(SUBSTR(DAT_ID,1,6)||'01','YYYYMMDD') AS ST                                                                        -- �떆�옉�씪�옄
            , CASE WHEN TO_NUMBER(v_CHANGE_MON) <= TO_NUMBER(SUBSTR(v_CURDT,5,2)) THEN TO_DATE(TO_CHAR(TO_NUMBER(SUBSTR(v_CURDT,1,4)) + TO_NUMBER(v_ALLYEAR))||'1231','YYYYMMDD')
              ELSE TO_DATE(TO_CHAR(TO_NUMBER(SUBSTR(v_CURDT,1,4)) + TO_NUMBER(v_ALLYEAR) - 1)||'1231','YYYYMMDD')
              END           AS ED                                                                                                         -- 醫낅즺�씪�옄
            , CASE WHEN SUBSTR(DAT_ID,5,2) = '01' THEN TO_DATE(SUBSTR(DAT_ID,1,6)||'01','YYYYMMDD') 
              ELSE TO_DATE(SUBSTR(DAT_ID,1,6)||'01','YYYYMMDD') - 1 
              END           AS DT                                                                                                         -- DTF �떆�옉�씪�옄 : DTF�뒗 �궗�슜�옄 �꽑�깮�븳 �썡�쓽 �씠�쟾�떖 留먯씪(1�썡�씪 寃쎌슦�뒗 洹몃�濡� �쑀吏�)
            --, CASE WHEN TO_NUMBER(v_CHANGE_MON) <= TO_NUMBER(SUBSTR(v_CURDT,5,2)) THEN TO_DATE(TO_CHAR(ADD_MONTHS(TO_DATE(v_CURDT,'YYYYMMDD'),(TO_NUMBER(v_1ST_YEAR)) * 12),'YYYY')||'0101','YYYYMMDD') 
              --ELSE  TO_DATE(TO_CHAR(ADD_MONTHS(TO_DATE(v_CURDT,'YYYYMMDD'),(TO_NUMBER(v_1ST_YEAR) - 1) * 12),'YYYY')||'0101','YYYYMMDD') 
              --1�썡~6�썡 : Y1(Week), Y2~Y3(Month)
              --10�썡~12�썡 : Y1,Y2(Week), Y3~Y4(Month)
            , CASE WHEN TO_NUMBER(v_CHANGE_MON) <= TO_NUMBER(SUBSTR(v_CURDT,5,2)) THEN TO_DATE(TO_CHAR(ADD_MONTHS(TO_DATE(v_CURDT,'YYYYMMDD'),(TO_NUMBER(v_1ST_YEAR)-1) * 12),'YYYY')||'0101','YYYYMMDD') 
              ELSE  TO_DATE(TO_CHAR(ADD_MONTHS(TO_DATE(v_CURDT,'YYYYMMDD'),(TO_NUMBER(v_1ST_YEAR) - 2) * 12),'YYYY')||'0101','YYYYMMDD') 
              END           AS PA                                                                                                        -- 2�떒怨� �떆�옉�씪�옄
      INTO    v_VER_FROM_DATE
            , v_VER_TO_DATE
            , v_DTF_DATE
            , v_PAR_DATE 
      FROM    TB_CM_CALENDAR
     WHERE    DAT_ID = v_CURDT
    ;

/*
    -- �궗�슜�옄媛� �떎瑜� �썡�쓣 �꽑�깮�븳 寃쎌슦 �빐�떦 �썡濡� 蹂�寃�
    IF p_VER_FROM_DATE IS NOT NULL THEN
        SELECT    TO_DATE(TO_CHAR(p_VER_FROM_DATE,'YYYYMM')||'01','YYYYMMDD') AS ST
          INTO    v_VER_FROM_DATE
          FROM    DUAL
        ;
    END IF;    
*/


    /***********************************************************************************************************************
        -- Reflect Partial Date
    ************************************************************************************************************************/ 
        IF (LENGTH(RTRIM(v_PAR_BUCKET)) > 0)
        THEN
/*   2021.02.08 源��슜�닔 : 湲곗〈 寃� 留됱쓬     
            SELECT MAX(DAT)+1 INTO v_PAR_DATE
              FROM TB_CM_CALENDAR
             GROUP BY TO_CHAR(YYYY)
                    , CASE WHEN v_PAR_BUCKET IN ('M', 'PW') THEN TO_CHAR(MM) ELSE '1' END
                    , CASE WHEN v_PAR_BUCKET IN ('W', 'PW') THEN TO_CHAR(DP_WK) ELSE '1' END
            HAVING v_PAR_DATE BETWEEN MIN(DAT) AND MAX(DAT)
            ;
*/
            IF (LENGTH(RTRIM(v_PAR_BUCKET2)) > 0 ) 
            THEN
                -- PARTIAL 2 START DATE 


                if (v_PAR_BUCKET = 'M')
                THEN
                    -- 理쒖냼 踰꾪궥 諛섏쁺
                  /* 2021.02.08 源��슜�닔 : 湲곗〈 寃� 留됱쓬
                    SELECT ADD_MONTHS(v_PAR_DATE,v_PAR_HORIZON2) INTO v_PAR_DATE2
                      FROM DUAL
                      ;
                  */

                    -- 2021.02.08 源��슜�닔 
                    SELECT    CASE WHEN TO_NUMBER(v_CHANGE_MON) <= TO_NUMBER(SUBSTR(v_CURDT,5,2)) THEN  TO_DATE(TO_CHAR(ADD_MONTHS(TO_DATE(v_CURDT,'YYYYMMDD'),(TO_NUMBER(v_2TH_YEAR) - 1) * 12),'YYYY')||'0101','YYYYMMDD')
                              ELSE TO_DATE(TO_CHAR(ADD_MONTHS(TO_DATE(v_CURDT,'YYYYMMDD'),(TO_NUMBER(v_2TH_YEAR) - 2) * 12),'YYYY')||'0101','YYYYMMDD')
                              END           AS PA2
                      INTO    v_PAR_DATE2 
                      FROM    TB_CM_CALENDAR
                     WHERE    DAT_ID = v_CURDT 
                    ;  

                    -- �떎�쓬 踰꾪궥���엯 �떆�옉 諛섏쁺
                    SELECT MAX(DAT)+1 INTO v_PAR_DATE2
                        FROM TB_CM_CALENDAR
                    GROUP BY TO_CHAR(YYYY)
                           , CASE WHEN v_PAR_BUCKET2 = 'Q' THEN TO_CHAR(QTR)  ELSE '1' END
                           , CASE WHEN v_PAR_BUCKET2 = 'Y' THEN TO_CHAR(YYYY) ELSE '1' END
                    HAVING v_PAR_DATE2 BETWEEN MIN(DAT) AND MAX(DAT)
                    ;


                ELSIF ( v_PAR_BUCKET = 'Q')
                THEN
                  -- 理쒖냼踰꾪궥 諛섏쁺
                  /* 2021.02.08 源��슜�닔 : 湲곗〈 寃� 留됱쓬
                    SELECT ADD_MONTHS(v_PAR_DATE,v_PAR_HORIZON2*3) INTO v_PAR_DATE2
                      FROM DUAL
                    ;
                  */

                    -- 2021.02.08 源��슜�닔 
                    SELECT    CASE WHEN TO_NUMBER(v_CHANGE_MON) <= TO_NUMBER(SUBSTR(v_CURDT,5,2)) THEN  TO_DATE(TO_CHAR(ADD_MONTHS(TO_DATE(v_CURDT,'YYYYMMDD'),(TO_NUMBER(v_2TH_YEAR) - 1) * 12),'YYYY')||'0101','YYYYMMDD')
                              ELSE TO_DATE(TO_CHAR(ADD_MONTHS(TO_DATE(v_CURDT,'YYYYMMDD'),(TO_NUMBER(v_2TH_YEAR) - 2) * 12),'YYYY')||'0101','YYYYMMDD')
                              END           AS PA2
                      INTO    v_PAR_DATE2 
                      FROM    TB_CM_CALENDAR
                     WHERE    DAT_ID = v_CURDT 
                    ;  
/*
                    SELECT TO_DATE(TO_CHAR(ADD_MONTHS(TO_DATE(v_CURDT,'YYYYMMDD'),(TO_NUMBER(v_2TH_YEAR) - 2) * 12),'YYYY')||'0101','YYYYMMDD') INTO v_PAR_DATE2 
                      FROM DUAL
                    ;  
*/

                  -- �떎�쓬 踰꾪궥 ���엯 �떆�옉 諛섏쁺
                    SELECT MAX(DAT)+1 INTO v_PAR_DATE2
                        FROM TB_CM_CALENDAR
                    GROUP BY TO_CHAR(YYYY)
                           , CASE WHEN v_PAR_BUCKET2 = 'Q' THEN TO_CHAR(QTR)  ELSE '1' END
                           , CASE WHEN v_PAR_BUCKET2 = 'Y' THEN TO_CHAR(YYYY) ELSE '1' END
                    HAVING v_PAR_DATE2 BETWEEN MIN(DAT) AND MAX(DAT)
                    ;

                end IF;

                -- PARTIAL 1 END DATE 
                SELECT v_PAR_DATE2-1 INTO v_PAR_TO_DATE
                  FROM DUAL;

                -- PARTIAL 2 END DATE 
                -- to do total horizon 諛섏쁺�븳 end date媛� v_PAR_DATE2 蹂대떎 �옉�떎硫� �븳踰꾪궥留� 諛섏쁺�븯湲곕줈..
                -- total horizon 諛섏쁺�븳 end date 瑜� �룷�븿�븯�뒗 理쒖쥌 踰꾪궥���엯�쓽 留덉�留� �궇吏� 援ы븯湲�
                -- �궇吏쒕�� 援ы븯怨� �몢踰덉㎏ 踰꾪궥���엯�쓽 留덉�留� �궇吏�

                --select max(dat) INTO v_TMP_ENDDATE 
                 -- from TB_CM_CALENDAR
                 --where PARTWK_SEQ = (select PARTWK_SEQ from TB_CM_CALENDAR where DAT = v_VER_FROM_DATE) + 40
                --;

                SELECT MAX(DAT) INTO v_PAR_TO_DATE2
                  FROM TB_CM_CALENDAR
                 GROUP BY TO_CHAR(YYYY)
                        , CASE WHEN v_PAR_BUCKET2 = 'Q' THEN TO_CHAR(QTR) ELSE '1' END
                        , CASE WHEN v_PAR_BUCKET2 = 'Y' THEN TO_CHAR(YYYY) ELSE '1' END
                HAVING v_VER_TO_DATE BETWEEN MIN(DAT) AND MAX(DAT)  
                ;   

                -- version end date
                SELECT v_PAR_TO_DATE2 INTO v_VER_TO_DATE
                  FROM DUAL
                  ;
            ELSE
                SELECT MAX(DAT) INTO v_PAR_TO_DATE
                  FROM TB_CM_CALENDAR
              GROUP BY TO_CHAR(YYYY)
                     , CASE WHEN v_PAR_BUCKET IN ('M', 'PW') THEN TO_CHAR(MM) ELSE '1' END
                     , CASE WHEN v_PAR_BUCKET IN ('W', 'PW') THEN TO_CHAR(DP_WK) ELSE '1' END
                HAVING v_VER_TO_DATE BETWEEN MIN(DAT) AND MAX(DAT)  
                ;   

                -- version end date
                SELECT v_PAR_TO_DATE INTO v_VER_TO_DATE
                  FROM DUAL
                ;
            END IF;
        END IF;

    /************************************************************************************************************************
        -- Result
    *************************************************************************************************************************/ 
        OPEN pRESULT FOR
        SELECT    v_VER_FROM_DATE                                                                   AS VER_FROM_DATE
                , v_VER_TO_DATE                                     AS VER_TO_DATE
                , CASE WHEN LENGTH(RTRIM(v_PAR_BUCKET)) = 0 OR v_PAR_BUCKET IS NULL THEN NULL ELSE v_PAR_DATE             END           AS PAR_DATE
                , v_PAR_BUCKET                                                                                                                                  AS PAR_BUCKET
                , v_PAR_HORIZON                                                                                                                               AS PAR_HORIZON 
--              , CASE WHEN v_VER_DTF = 0 THEN v_VER_FROM_DATE ELSE v_DTF_DATE END                                                                              AS DTF_DATE
            , v_DTF_DATE  AS DTF_DATE
                , CASE WHEN LENGTH(RTRIM(v_PAR_BUCKET2)) = 0 OR v_PAR_BUCKET2 IS NULL THEN NULL ELSE v_PAR_DATE2              END       AS PAR_DATE2
                , v_PAR_BUCKET2                                                                     AS PAR_BUCKET2
                , v_PAR_HORIZON2                                                                    AS PAR_HORIZON2 
                , v_PAR_TO_DATE                                                                   AS PAR_TO_DATE 
                , v_PAR_TO_DATE2                                                                    AS PAR_TO_DATE2 
          FROM    DUAL
        ;
    END IF;
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    3. Change << To Date >> Datepicker
    ....
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
END ;
/

