create PROCEDURE "SP_COMM_SRH_DMND_VER" (
    P_SNRIO_MST_ID      IN CHAR := ''
   ,P_PLAN_TP_ID        IN CHAR := ''
   ,P_CL_YN             IN CHAR := ''
   ,pResult             OUT SYS_REFCURSOR
)
IS
    V_DMND_MODULE_ID CHAR(32) := '';
    V_DF_PLAN_TP_ID CHAR(32);
	V_DISPLAY_BLANK_VER	INT := 1;

BEGIN
    IF NVL(P_SNRIO_MST_ID, ' ') = ' ' THEN
        V_DMND_MODULE_ID := 'DP';
        V_DISPLAY_BLANK_VER := 0;
    ELSE
        BEGIN
            SELECT B.COMN_CD INTO V_DMND_MODULE_ID
            FROM TB_CM_PLAN_SNRIO_MGMT_MST A
                ,TB_AD_COMN_CODE B
            WHERE A.DMND_MODULE_ID = B.ID
            AND   A.ID = P_SNRIO_MST_ID;
            EXCEPTION WHEN NO_DATA_FOUND
            THEN NULL;
        END;
    END IF;

    SELECT ID INTO V_DF_PLAN_TP_ID
    FROM TB_CM_COMM_CONFIG
    WHERE CONF_GRP_CD = 'DP_PLAN_TYPE'
    AND DEFAT_VAL = 'Y';

    IF V_DMND_MODULE_ID = 'DP'
    THEN
        OPEN pResult FOR
		SELECT A.ID,
               A.VER_ID
          FROM (
                SELECT MS.ID,
                       MS.VER_ID,
                       ROW_NUMBER() OVER (ORDER BY MS.CREATE_DTTM desc, MS.MODIFY_DTTM DESC) AS ROWN
                  FROM TB_DP_CONTROL_BOARD_VER_MST MS
                       INNER JOIN
                       TB_DP_CONTROL_BOARD_VER_DTL DT
                       ON MS.ID = DT.CONBD_VER_MST_ID
                       AND DT.WORK_TP_ID IN (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_CD = 'CL' AND CONF_GRP_CD = 'DP_WK_TP')        
                 WHERE 1=1
                   AND ((P_CL_YN ='Y' AND DT.CL_STATUS_ID IN (
                                                              SELECT ID 
                                                                FROM TB_CM_COMM_CONFIG 
                                                               WHERE CONF_GRP_CD = 'DP_CL_STATUS' 
															     AND ((V_DF_PLAN_TP_ID is NOT null and CONF_CD = 'CLOSE')
																  OR (V_DF_PLAN_TP_ID IS NULL AND CONF_CD IN ('CLOSE', 'CUTOFF')))
                                                              )
                        )
                        OR (P_CL_YN = 'N')
                        )
                    AND CASE WHEN P_PLAN_TP_ID IS NULL OR P_PLAN_TP_ID = '' THEN V_DF_PLAN_TP_ID ELSE P_PLAN_TP_ID END = MS.PLAN_TP_ID
			   )  A
		WHERE A.ROWN <= 10
        UNION ALL
        SELECT NULL AS ID,
               ' '  AS VER_ID
          FROM DUAL
         WHERE 1 = V_DISPLAY_BLANK_VER;
          
    ELSIF V_DMND_MODULE_ID = 'RP'
    THEN
        OPEN pResult FOR
        SELECT A.ID,
               A.VER_ID
          FROM (
               SELECT C.ID				AS ID,
                      C.SIMUL_VER_ID	AS VER_ID,
                      ROW_NUMBER() OVER (ORDER BY C.CREATE_DTTM DESC, C.MODIFY_DTTM DESC) AS ROW_NUM
                 FROM TB_CM_CONBD_MAIN_VER_MST B
                      INNER JOIN TB_AD_COMN_CODE A
                      ON B.MODULE_ID = A.ID
                      AND A.COMN_CD = 'RP',
                      TB_CM_CONBD_MAIN_VER_DTL C
                WHERE 1=1
                  AND B.ID = C.CONBD_MAIN_VER_MST_ID
                  AND C.CONFRM_YN = 'Y'
              ) A
        WHERE ROW_NUM <= 10
        UNION ALL
        SELECT NULL AS ID,
               ' '  AS VER_ID
          FROM DUAL
         WHERE 1 = V_DISPLAY_BLANK_VER;
    END IF;
    
END;

/

