create PROCEDURE SP_UI_CM_07_POP_S2 (
     P_SHPP_LEADTIME_MST_ID		    IN VARCHAR2 := '',
     P_BOD_TP_ID					IN VARCHAR2	:= '',
	 P_CONSUME_LOCAT_MGMT_ID		IN VARCHAR2	:= '',
	 P_ACCOUNT_ID					IN VARCHAR2	:= '',
	 P_SUPPLY_LOCAT_MGMT_ID		    IN VARCHAR2	:= '',
	 P_VEHICL_TP_ID				    IN VARCHAR2	:= '',
	 P_BOD_LEADTIME_ID				IN VARCHAR2	:= '',
	 P_BOD_LEAD_TIME				IN NUMBER := 0,
	 P_UOM_ID					    IN VARCHAR2	:= '',
     P_ACTV_YN                      IN VARCHAR2 := '',
	 P_USER_ID						IN VARCHAR2 := '',
	 P_RT_ROLLBACK_FLAG				OUT VARCHAR2,
	 P_RT_MSG					    OUT VARCHAR2
)
IS
    P_ERR_STATUS NUMBER := 0;
    P_ERR_MSG  VARCHAR2(4000) := '';
    vBOD_TP VARCHAR2(100) := '';
    vSHPP_LEADTIME_MST_ID VARCHAR2(100) := P_SHPP_LEADTIME_MST_ID;

BEGIN
    IF P_VEHICL_TP_ID IS NOT NULL THEN
        BEGIN
            SELECT COMN_CD INTO vBOD_TP
              FROM TB_AD_COMN_CODE 
             WHERE ID = P_BOD_TP_ID;
             EXCEPTION
                WHEN NO_DATA_FOUND THEN NULL;
        END;
        
        BEGIN
            IF vBOD_TP IS NOT NULL AND vBOD_TP = 'SALES_BOD' THEN
                SELECT A.ID INTO vSHPP_LEADTIME_MST_ID
                  FROM TB_CM_SHIP_LT_MST A
                 WHERE A.VEHICL_TP_ID = P_VEHICL_TP_ID
                   AND A.ACCOUNT_ID = P_ACCOUNT_ID
                   AND A.SUPPLY_LOCAT_ID = P_SUPPLY_LOCAT_MGMT_ID;
            ELSIF vSHPP_LEADTIME_MST_ID IS NULL THEN
                SELECT A.ID INTO vSHPP_LEADTIME_MST_ID
                  FROM TB_CM_SHIP_LT_MST A
                 WHERE A.VEHICL_TP_ID = P_VEHICL_TP_ID
                   AND A.CONSUME_LOCAT_ID = P_CONSUME_LOCAT_MGMT_ID
                   AND A.SUPPLY_LOCAT_ID = P_SUPPLY_LOCAT_MGMT_ID;
            END IF;
             EXCEPTION
                WHEN NO_DATA_FOUND THEN NULL;
        END;

        MERGE INTO TB_CM_SHIP_LT_DTL TARGET
        USING ( 
                SELECT
                  vSHPP_LEADTIME_MST_ID	AS SHPP_LEADTIME_MST_ID
                 ,P_BOD_LEADTIME_ID   	AS BOD_LEADTIME_ID
                 ,P_BOD_LEAD_TIME		AS LEADTIME
                 ,P_UOM_ID      		AS UOM_ID
                 ,P_ACTV_YN				AS ACTV_YN
                 ,P_USER_ID				AS USER_ID
              FROM DUAL
              ) SOURCE
        ON  (TARGET.SHPP_LEADTIME_MST_ID = SOURCE.SHPP_LEADTIME_MST_ID
        AND TARGET.BOD_LEADTIME_ID = SOURCE.BOD_LEADTIME_ID)
        WHEN MATCHED THEN
             UPDATE 
               SET  
                    TARGET.LEADTIME     = SOURCE.LEADTIME
                    ,TARGET.UOM_ID 		= SOURCE.UOM_ID
                    ,TARGET.ACTV_YN     = SOURCE.ACTV_YN
                    ,TARGET.MODIFY_BY	= SOURCE.USER_ID
                    ,TARGET.MODIFY_DTTM	= SYSDATE
        WHEN NOT MATCHED THEN
            INSERT (
                    ID,
                    SHPP_LEADTIME_MST_ID,
                    BOD_LEADTIME_ID,
                    LEADTIME,
                    UOM_ID,
                    ACTV_YN,
                    CREATE_BY,
                    CREATE_DTTM
                   )
            VALUES (
                    TO_SINGLE_BYTE(SYS_GUID()),
                    SOURCE.SHPP_LEADTIME_MST_ID,
                    SOURCE.BOD_LEADTIME_ID,
                    SOURCE.LEADTIME,
                    SOURCE.UOM_ID,
                    SOURCE.ACTV_YN,
                    SOURCE.USER_ID,
                    SYSDATE
                   );
    END IF;
    
    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';

EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;   
      ELSE
          RAISE;
      END IF;
END;

/

