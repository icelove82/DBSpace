create PROCEDURE SP_UI_IM_01_POP_01_S (
    P_ID                        IN VARCHAR2 := '',
	P_PLAN_SNRIO_MGMT_MST_ID    IN VARCHAR2	:= NULL,
    P_TIME_BUCKET               IN VARCHAR2 := '',
    P_STRT_DATE_TP              IN VARCHAR2 := '',
    P_DAY_OF_WEEK               IN VARCHAR2 := '',
    P_STRT_TIME                 IN VARCHAR2 := '00:00',
    P_DURA                      IN NUMBER := '',
    P_BUCKET_TP_VAL             IN VARCHAR2 := 'Single',
    P_VAR_TIME_BUCKET           IN VARCHAR2 := '',
    P_DURA2                     IN NUMBER := '',
    P_DESCRIP                   IN VARCHAR2 := '',
    P_ACTV_YN                   IN CHAR := '',
    P_STRT_DATE                 IN DATE := '',
    P_USER_ID                   IN VARCHAR2 := '',
    P_WRK_TYPE                  IN VARCHAR2 := '',
    P_RT_ROLLBACK_FLAG          OUT VARCHAR2,
    P_RT_MSG                    OUT VARCHAR2
) 
IS
    P_ERR_STATUS            NUMBER := 0;
    P_ERR_MSG               VARCHAR2(4000) := '';
    V_CONF_ID               VARCHAR2(32) := '';    
    V_TIME_BUCKET_CD        VARCHAR2(50) := '';
    V_DAY_OF_WEEK           INT := 0;
    V_STRT_DATE_TP_CD       VARCHAR2(50) := '';
    V_STRT_DATE1            DATE := '';
    V_STRT_DATE2            DATE := '';
    V_END_DATE              DATE := '';   
    V_VAR_TIME_BUCKET_CD    VARCHAR2(50) := '';
    V_CNT                   INT :=0;
    
BEGIN

    IF P_WRK_TYPE = 'SAVE' THEN
        P_ERR_MSG := 'MSG_0006'; --'Required input value didn't enter.'
        IF NVL(P_DURA,0) = 0 OR P_PLAN_SNRIO_MGMT_MST_ID IS NULL THEN
            RAISE_APPLICATION_ERROR(-20012,P_ERR_MSG);
        END IF;
        
        P_ERR_MSG := 'MSG_0005';
        SELECT COUNT(ID) INTO V_CNT FROM TB_CM_HORIZON_TIME_BUCKET WHERE ID <> P_ID AND PLAN_SNRIO_MGMT_MST_ID = P_PLAN_SNRIO_MGMT_MST_ID;
        IF V_CNT > 0 THEN
            RAISE_APPLICATION_ERROR(-20012,P_ERR_MSG);
        END IF;

        P_ERR_MSG := 'MSG_0008'; -- 'Negative numbers can not be entered.'
        IF P_DURA < 0 THEN
            RAISE_APPLICATION_ERROR(-20012,P_ERR_MSG);
        END IF;
        
        SELECT  ID INTO V_CONF_ID
        FROM    TB_CM_CONFIGURATION
        WHERE   CONF_KEY = '301';
        
        SELECT COMN_CD INTO V_STRT_DATE_TP_CD FROM TB_AD_COMN_CODE WHERE ID=P_STRT_DATE_TP;
        SELECT  CASE COMN_CD 
                    WHEN 'MON' THEN 0
                    WHEN 'TUE' THEN 1
                    WHEN 'WED' THEN 2
                    WHEN 'THU' THEN 3
                    WHEN 'FRI' THEN 4
                    WHEN 'SAT' THEN 5
                    WHEN 'SUN' THEN 6
                    ELSE 0
                END INTO V_DAY_OF_WEEK
        FROM    TB_AD_COMN_CODE WHERE ID=NVL(P_DAY_OF_WEEK, '');
        
        IF P_STRT_DATE IS NOT NULL THEN 
            V_STRT_DATE1 := P_STRT_DATE;
        ELSE 
            V_STRT_DATE1 := SYSDATE;
        END IF;
        
        /* Find start date of zone1 */
        V_STRT_DATE1 :=
            CASE V_STRT_DATE_TP_CD
                WHEN 'CURRENT_DATE' THEN TO_DATE(TO_CHAR(V_STRT_DATE1, 'YYYYMMDD') || ' ' || NVL(P_STRT_TIME, '00:00'), 'YYYYMMDD HH24:MI')    
                WHEN 'THIS_WEEK' THEN TO_DATE(TO_CHAR(TRUNC(V_STRT_DATE1, 'IW') + V_DAY_OF_WEEK, 'YYYYMMDD') || ' ' || NVL(P_STRT_TIME, '00:00'), 'YYYYMMDD HH24:MI')
                WHEN 'NEXT_WEEK' THEN TO_DATE(TO_CHAR(TRUNC(V_STRT_DATE1, 'IW') + 7 + V_DAY_OF_WEEK, 'YYYYMMDD') || ' ' || NVL(P_STRT_TIME, '00:00'), 'YYYYMMDD HH24:MI')
                WHEN 'THIS_MONTH' THEN TO_DATE(TO_CHAR(TRUNC(V_STRT_DATE1,'MM'), 'YYYYMMDD') || ' ' || NVL(P_STRT_TIME, '00:00'), 'YYYYMMDD HH24:MI')
                WHEN 'NEXT_MONTH' THEN TO_DATE(TO_CHAR(ADD_MONTHS(TRUNC(V_STRT_DATE1,'MM'), 1), 'YYYYMMDD') || ' ' || NVL(P_STRT_TIME, '00:00'), 'YYYYMMDD HH24:MI')
            END;
            
        SELECT MAX(UOM_CD) INTO V_TIME_BUCKET_CD FROM TB_CM_UOM WHERE ID = P_TIME_BUCKET;
        SELECT MAX(UOM_CD) INTO V_VAR_TIME_BUCKET_CD FROM TB_CM_UOM WHERE ID = P_VAR_TIME_BUCKET;        
        
        IF P_BUCKET_TP_VAL = 'Variable' THEN
            /* Find start date of zone2 */
            V_STRT_DATE2 :=
                CASE V_TIME_BUCKET_CD
                    WHEN 'DAY' THEN V_STRT_DATE1 + P_DURA
                    WHEN 'WEEK' THEN V_STRT_DATE1 + (P_DURA * 7)
                    WHEN 'PARTIAL_WEEK' THEN V_STRT_DATE1 + (P_DURA * 7)
                    WHEN 'MONTH' THEN ADD_MONTHS(V_STRT_DATE1, P_DURA)
                    WHEN 'YEAR' THEN ADD_MONTHS(V_STRT_DATE1, P_DURA * 12)
                END;
                
            /* Adjust start date of zone2 */
            V_STRT_DATE2 :=
                CASE 
                    WHEN V_VAR_TIME_BUCKET_CD = 'WEEK' AND TO_DATE(TO_CHAR(TRUNC(V_STRT_DATE2, 'IW') + V_DAY_OF_WEEK, 'YYYYMMDD') || ' ' || NVL(P_STRT_TIME, '00:00'), 'YYYYMMDD HH24:MI') > V_STRT_DATE2 
                        THEN TO_DATE(TO_CHAR(TRUNC(V_STRT_DATE2, 'IW') + V_DAY_OF_WEEK, 'YYYYMMDD') || ' ' || NVL(P_STRT_TIME, '00:00'), 'YYYYMMDD HH24:MI')
                    WHEN V_VAR_TIME_BUCKET_CD = 'WEEK' AND TO_DATE(TO_CHAR(TRUNC(V_STRT_DATE2, 'IW') + V_DAY_OF_WEEK, 'YYYYMMDD') || ' ' || NVL(P_STRT_TIME, '00:00'), 'YYYYMMDD HH24:MI') < V_STRT_DATE2 
                        THEN TO_DATE(TO_CHAR(TRUNC(V_STRT_DATE2, 'IW') + 7 + V_DAY_OF_WEEK, 'YYYYMMDD') || ' ' || NVL(P_STRT_TIME, '00:00'), 'YYYYMMDD HH24:MI')
                    WHEN V_VAR_TIME_BUCKET_CD = 'PARTIAL_WEEK' AND TO_DATE(TO_CHAR(TRUNC(V_STRT_DATE2, 'IW') + V_DAY_OF_WEEK, 'YYYYMMDD') || ' ' || NVL(P_STRT_TIME, '00:00'), 'YYYYMMDD HH24:MI') > V_STRT_DATE2 
                        THEN TO_DATE(TO_CHAR(TRUNC(V_STRT_DATE2, 'IW') + V_DAY_OF_WEEK, 'YYYYMMDD') || ' ' || NVL(P_STRT_TIME, '00:00'), 'YYYYMMDD HH24:MI')
                    WHEN V_VAR_TIME_BUCKET_CD = 'PARTIAL_WEEK' AND TO_DATE(TO_CHAR(TRUNC(V_STRT_DATE2, 'IW') + V_DAY_OF_WEEK, 'YYYYMMDD') || ' ' || NVL(P_STRT_TIME, '00:00'), 'YYYYMMDD HH24:MI') < V_STRT_DATE2 
                        THEN TO_DATE(TO_CHAR(TRUNC(V_STRT_DATE2, 'IW') + 7 + V_DAY_OF_WEEK, 'YYYYMMDD') || ' ' || NVL(P_STRT_TIME, '00:00'), 'YYYYMMDD HH24:MI')
                    WHEN V_VAR_TIME_BUCKET_CD = 'MONTH' AND TRUNC(V_STRT_DATE2,'MM') < V_STRT_DATE2
                        THEN ADD_MONTHS(TRUNC(V_STRT_DATE2,'MM'), 1)
                END;
                
            /* Find end date */
            V_END_DATE :=
                CASE V_VAR_TIME_BUCKET_CD
                    WHEN 'DAY' THEN V_STRT_DATE2 + P_DURA2
                    WHEN 'WEEK' THEN V_STRT_DATE2 + (P_DURA2 * 7)
                    WHEN 'PARTIAL_WEEK' THEN V_STRT_DATE2 + (P_DURA2 * 7)
                    WHEN 'MONTH' THEN ADD_MONTHS(V_STRT_DATE2, P_DURA2)
                    WHEN 'YEAR' THEN ADD_MONTHS(V_STRT_DATE2, P_DURA2 * 12)
                END;
        ELSE
            /* Find end date */
            V_END_DATE :=
                CASE V_TIME_BUCKET_CD
                    WHEN 'DAY' THEN V_STRT_DATE1 + P_DURA
                    WHEN 'WEEK' THEN V_STRT_DATE1 + (P_DURA * 7)
                    WHEN 'PARTIAL_WEEK' THEN V_STRT_DATE1 + (P_DURA * 7)
                    WHEN 'MONTH' THEN ADD_MONTHS(V_STRT_DATE1, P_DURA)
                    WHEN 'YEAR' THEN ADD_MONTHS(V_STRT_DATE1, P_DURA * 12)
                END;
        END IF;

        MERGE INTO TB_CM_HORIZON_TIME_BUCKET B 
            USING (SELECT P_ID AS ID FROM DUAL ) A ON ( B.ID = A.ID )
        WHEN MATCHED THEN 
        UPDATE 
        SET PLAN_SNRIO_MGMT_MST_ID = P_PLAN_SNRIO_MGMT_MST_ID,
            TIME_UOM_ID = P_TIME_BUCKET,
            STRT_DATE_TP_ID = P_STRT_DATE_TP,
            DAY_OF_WEEK_ID = P_DAY_OF_WEEK,
            STRT_TIME = P_STRT_TIME,
            BUCKET_TP_VAL = P_BUCKET_TP_VAL,
            VAR_TIME_UOM_ID = P_VAR_TIME_BUCKET,
            STRT_DATE = V_STRT_DATE1,
            STRT_DATE2 = V_STRT_DATE2,
            END_DATE = V_END_DATE,
            DURA = P_DURA,
            DURA2 = P_DURA2,
            DESCRIP = P_DESCRIP,
            ACTV_YN = P_ACTV_YN,
            MODIFY_BY = P_USER_ID,
            MODIFY_DTTM = SYSDATE
        WHEN NOT MATCHED THEN 
            INSERT (
                -- Required Columns
                ID,
                CREATE_BY,
                CREATE_DTTM,
                MODIFY_BY,
                MODIFY_DTTM,
                -- Contents Columns
                CONF_ID,
				PLAN_SNRIO_MGMT_MST_ID,
                TIME_UOM_ID,
                STRT_DATE,
                STRT_DATE2,
                END_DATE,
                DURA,
                DESCRIP,
                ACTV_YN,
                STRT_DATE_TP_ID,
                DAY_OF_WEEK_ID,
                STRT_TIME,
                BUCKET_TP_VAL,
                VAR_TIME_UOM_ID,
                DURA2) 
            VALUES (
				-- Required Columns
                TO_SINGLE_BYTE(SYS_GUID() ),
                P_USER_ID,
                SYSDATE,
                P_USER_ID,
                SYSDATE,
				-- Contents Columns
                V_CONF_ID,
				P_PLAN_SNRIO_MGMT_MST_ID,
                P_TIME_BUCKET,
                V_STRT_DATE1,
                V_STRT_DATE2,
                V_END_DATE,
                P_DURA,
                P_DESCRIP,
                P_ACTV_YN,
                P_STRT_DATE_TP,
                P_DAY_OF_WEEK,
                P_STRT_TIME,
                P_BUCKET_TP_VAL,
                P_VAR_TIME_BUCKET,
                P_DURA2);

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';  --Saved.
        
    ELSIF P_WRK_TYPE = 'DELETE' THEN
        DELETE FROM TB_CM_HORIZON_TIME_BUCKET
        WHERE   ID = P_ID;

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0002';
    END IF;
    
EXCEPTION
    WHEN OTHERS THEN
        P_RT_ROLLBACK_FLAG := 'false';
        IF ( SQLCODE =-20012 ) THEN
            P_RT_MSG := P_ERR_MSG;
        ELSE
            P_RT_MSG := SQLERRM;
        END IF;

END;

/

