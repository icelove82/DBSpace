create PROCEDURE SP_UI_CM_07_S1 (
    P_SHPP_LEADTIME_MST_ID	    IN CHAR	    := NULL,
	P_VEHICL_ACTV_YN			IN CHAR	    := '',
	P_PRIORT					IN INT      := NULL,
	P_OUTBOUND_LT				IN NUMBER   := NULL,
    P_VOYAGE_LT				    IN NUMBER   := NULL,
    P_INBOUND_LT				IN NUMBER   := NULL,
    P_LT_UOM					IN CHAR     := '',
	P_TRANSP_COST_CAL_BASE_ID	IN CHAR     := NULL,
	P_TRANSP_COST_CAL_BASE_CD	IN VARCHAR2 := NULL,
	P_WEIGHT_UOM_ID			    IN CHAR	    := NULL,
	P_TRANSP_UTPIC				IN NUMBER   := NULL,
	P_CURCY_CD_ID				IN CHAR	    := NULL,
    P_USER_ID					IN VARCHAR2 :='',
	P_RT_ROLLBACK_FLAG          OUT VARCHAR2,
	P_RT_MSG                    OUT VARCHAR2
)
IS
	P_ERR_STATUS NUMBER :=0;
	P_ERR_MSG  VARCHAR2(4000) :='';
	V_BOD_LEADTIME_TP VARCHAR2(10) := NULL;
	V_TRANSP_COST_CAL_BASE VARCHAR2(10) := NULL;

BEGIN
    P_ERR_MSG := 'MSG_0008';
    IF P_PRIORT IS NOT NULL AND P_PRIORT < 0 THEN
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    IF P_OUTBOUND_LT IS NOT NULL AND P_OUTBOUND_LT < 0 THEN
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    IF P_VOYAGE_LT IS NOT NULL AND P_VOYAGE_LT < 0 THEN
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    IF P_INBOUND_LT IS NOT NULL AND P_INBOUND_LT < 0 THEN
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    IF P_TRANSP_UTPIC IS NOT NULL AND P_TRANSP_UTPIC < 0 THEN
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
	
    UPDATE TB_CM_SHIP_LT_MST 
	   SET ACTV_YN = P_VEHICL_ACTV_YN
	     , PRIORT = P_PRIORT
		 , TRANSP_COST_CAL_BASE_ID = P_TRANSP_COST_CAL_BASE_ID
		 , WEIGHT_UOM_ID = P_WEIGHT_UOM_ID
		 , TRANSP_UTPIC = P_TRANSP_UTPIC
		 , CURCY_CD_ID = P_CURCY_CD_ID
		 , MODIFY_BY = P_USER_ID
		 , MODIFY_DTTM = SYSDATE
	 WHERE ID = P_SHPP_LEADTIME_MST_ID;
       
	UPDATE	TB_CM_SHIP_LT_DTL A
	SET		A.UOM_ID = P_LT_UOM,
            A.LEADTIME =    (
                            SELECT	CASE WHEN Z.COMN_CD = 'OUTBOUND' THEN P_OUTBOUND_LT
                                         WHEN Z.COMN_CD = 'VOYAGE'   THEN P_VOYAGE_LT
                                         WHEN Z.COMN_CD = 'INBOUND'  THEN P_INBOUND_LT
                                    ELSE NULL
                                    END
                            FROM	TB_CM_SHIP_LT_DTL X,
                                    TB_CM_BOD_LT Y
                                    INNER JOIN TB_AD_COMN_CODE Z
                                    ON Z.ID = Y.LEADTIME_TP_ID
                            WHERE	Y.ID = X.BOD_LEADTIME_ID
                            AND		X.SHPP_LEADTIME_MST_ID = P_SHPP_LEADTIME_MST_ID
                            AND     X.ID = A.ID
                            );

    P_RT_MSG := 'MSG_0001';
    P_RT_ROLLBACK_FLAG := 'true';

    EXCEPTION
    WHEN OTHERS THEN
        IF(SQLCODE = -20012)
          THEN
              P_RT_ROLLBACK_FLAG := 'false';
              P_RT_MSG := P_ERR_MSG;
          ELSE
              RAISE;
          END IF;

END;

/

