create PROCEDURE SP_UI_CM_08_POP_03_S (
     P_WRK_TYPE					IN VARCHAR2 := ''
	,P_ID	                    IN CHAR := ''
	,P_SHPP_LEADTIME_DTL_ID	    IN VARCHAR2:=  ''
	,P_STRT_DATE				IN DATE :=  ''
	,P_END_DATE					IN DATE :=  ''
	,P_TRANSFER_DD				IN CHAR := ''
    ,P_ACTV_YN                  IN CHAR := ''
	,P_USER_ID					IN VARCHAR2 :=  ''
    ,P_RT_ROLLBACK_FLAG         OUT VARCHAR2
	,P_RT_MSG                   OUT VARCHAR2
)
IS
    P_ERR_STATUS NUMBER := 0;
    P_ERR_MSG VARCHAR2(4000) := '';
    
BEGIN
    IF P_WRK_TYPE = 'SAVE'
	THEN
		MERGE INTO TB_CM_SHIP_LT_EXCEPTION_SCH B 
		USING (SELECT P_ID AS ID
                 FROM DUAL
               ) A
           ON (B.ID = A.ID)
		WHEN MATCHED THEN
			UPDATE 
			   SET STRT_DATE    = P_STRT_DATE
                 , END_DATE     = P_END_DATE
                 , TRANSFER_DD	= P_TRANSFER_DD
                 , ACTV_YN      = P_ACTV_YN
			     , MODIFY_BY	= P_USER_ID
				 , MODIFY_DTTM	= SYSDATE
		WHEN NOT MATCHED THEN
			INSERT (
				ID
				,SHPP_LEADTIME_DTL_ID
				,STRT_DATE
				,END_DATE
				,TRANSFER_DD			
				,ACTV_YN
                ,CREATE_BY
                ,CREATE_DTTM
				)
			VALUES 
		  	    (
				TO_SINGLE_BYTE(SYS_GUID())
				,P_SHPP_LEADTIME_DTL_ID
				,P_STRT_DATE	
				,P_END_DATE	
				,P_TRANSFER_DD
				,P_ACTV_YN
                ,P_USER_ID
                ,SYSDATE
			);
            
        P_RT_MSG := 'MSG_0001';

	ELSIF P_WRK_TYPE = 'DELETE'
    THEN
        DELETE 
          FROM TB_CM_SHIP_LT_EXCEPTION_SCH
         WHERE ID = P_ID;
        
        P_RT_MSG := 'MSG_0002';
    END IF;
    
    P_RT_ROLLBACK_FLAG := 'true';

EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
    THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;
      ELSE
          RAISE;
      END IF;
END;

/

