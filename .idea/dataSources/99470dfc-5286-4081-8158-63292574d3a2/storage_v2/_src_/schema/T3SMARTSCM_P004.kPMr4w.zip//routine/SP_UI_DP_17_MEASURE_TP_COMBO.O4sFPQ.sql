create PROCEDURE "SP_UI_DP_17_MEASURE_TP_COMBO" 
(
/* SP_UI_DP_17_MEASURE_VAL_TP_COMBO ？？ ？？？？ ？？？ν？？？ ？？？？？？？？,
   ORACLE？？ ？？？？？？？ ？？？？？ ？？？？ 30？？ ？？？？？？ ？？？？？？ ？？？ */
 pRESULT       OUT SYS_REFCURSOR
)
IS 


BEGIN

OPEN pRESULT          
FOR 
  SELECT    A.ID, A.CD_NM, A.ALL_YN
  FROM    (
        SELECT  '' AS ID 
              , '' AS CD
              , 'ALL' AS CD_NM
              , 0 AS SEQ
              , 'ALL' AS ALL_YN
        FROM dual
        UNION
        SELECT     B.ID        AS ID
                ,B.CONF_CD    AS CD
                ,B.CONF_NM    AS CD_NM
                ,COALESCE(B.PRIORT, 0)+1    AS SEQ
                ,'NOT_ALL'        AS ALL_YN
        FROM    TB_CM_CONFIGURATION A 
                INNER JOIN TB_CM_COMM_CONFIG B
                ON A.ID = B.CONF_ID
        WHERE    A.CONF_NM = 'DP_MS_VAL_TP'
        AND        B.ACTV_YN = 'Y'
        AND        B.DEFAT_VAL = 'Y' 
        )A
  ORDER BY A.SEQ;    


END
;

/

