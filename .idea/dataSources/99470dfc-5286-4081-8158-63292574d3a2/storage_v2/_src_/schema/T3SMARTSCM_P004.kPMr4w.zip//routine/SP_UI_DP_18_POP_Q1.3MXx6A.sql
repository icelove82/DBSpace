create PROCEDURE "SP_UI_DP_18_POP_Q1" 
(
    p_TBL_NM      IN VARCHAR2 := ''
  , pRESULT       OUT SYS_REFCURSOR 
) 
IS 

BEGIN
    OPEN pRESULT          
    FOR 
    SELECT 
            TABLE_NAME
           ,COLUMN_NAME
    FROM ALL_TAB_COLUMNS
    WHERE 1=1
      AND OWNER IN (                                   
                        SELECT USERNAME
                          FROM user_users
                   )            
      AND TABLE_NAME = p_TBL_NM
    ORDER BY TABLE_NAME, COLUMN_NAME
    ;
/*
SELECT      a.name AS TABLE_NAME
        , b.name AS COLUMN_NAME 
--        , CASE WHEN CONVERT(VARCHAR2,c.value)IS NULL THEN b.name ELSE b.name + ' (' + CONVERT(VARCHAR2,c.value) + ')' END AS DESCRIPTION
FROM    sys.objects a
        LEFT JOIN sys.columns b 
        ON a.object_id=b.object_id
        LEFT JOIN  systypes B2 
        ON b.user_type_id = B2.xtype and B2.status = 0
--        LEFT JOIN sys.extended_properties c ON (a.object_id=c.major_id AND b.column_id=c.minor_id)
where    a.name = p_TBL_NM
AND        A.type  = 'U'
ORDER BY a.object_id, b.column_id;
*/
END
;

/

