create PROCEDURE                 "SP_UI_DPD_MAKE_HIER_SALES" 
IS          
/******************************************************************************************
	-- Create table 
	-- 2020.12.09 / kim sohee / oracle conveting
********************************************************************************************/
v_depth       INT := 1;
 v_max_depth    INT;
 v_lv_cnt       INT;
 P_CHECK  INT;

BEGIN
/***************************************************************************************************************************
    -- Create Table and Index
****************************************************************************************************************************/
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_SALES_HIER_CLOSURE_01' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_SALES_HIER_CLOSURE_01 ON TB_DPD_SALES_HIER_CLOSURE (ANCESTER_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_SALES_HIER_CLOSURE_02' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_SALES_HIER_CLOSURE_02 ON TB_DPD_SALES_HIER_CLOSURE (ANCESTER_CD)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_SALES_HIER_CLOSURE_03' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_SALES_HIER_CLOSURE_03 ON TB_DPD_SALES_HIER_CLOSURE (DESCENDANT_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_SALES_HIER_CLOSURE_04' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_SALES_HIER_CLOSURE_04 ON TB_DPD_SALES_HIER_CLOSURE (DESCENDANT_CD)';
    END IF;
/* TB_DPD_ACCOUNT_HIERARCHY2 */
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'PK_TB_DPD_ACCOUNT_HIERACHY2' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN    -- PK
        EXECUTE IMMEDIATE  'ALTER TABLE TB_DPD_ACCOUNT_HIERACHY2 ADD CONSTRAINT PK_TB_DPD_ACCOUNT_HIERACHY2 PRIMARY KEY (ACCOUNT_ID)';        
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'UK_TB_DPD_ACCOUNT_HIERACHY2' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN    -- UK
        EXECUTE IMMEDIATE  'CREATE UNIQUE INDEX UK_TB_DPD_ACCOUNT_HIERACHY2 ON TB_DPD_ACCOUNT_HIERACHY2 (ACCOUNT_CD)';                
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_01' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_01 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL01_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_02' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_02 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL02_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_03' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_03 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL03_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_04' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_04 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL04_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_05' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_05 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL05_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_06' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_06 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL06_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_07' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_07 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL07_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_08' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_08 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL08_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_09' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_09 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL09_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_10' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_10 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL10_ID)';
    END IF;
/************************************************************************************************************************************************************************************************************
	-- Main Query
************************************************************************************************************************************************************************************************************/ 
	SELECT COUNT(SEQ) 
		 , SUM(LV_CNT) 
         INTO v_max_depth, v_lv_cnt
	  FROM (
			SELECT CL.SEQ
                 , COUNT(SL.SEQ) AS LV_CNT
			  FROM TB_CM_LEVEL_MGMT CL
				   INNER JOIN 
				   TB_DP_SALES_LEVEL_MGMT SL 
				ON CL.ID = SL.LV_MGMT_ID
			 WHERE NVL(CL.ACCOUNT_LV_YN ,'N') = 'Y'
			   AND NVL(CL.SALES_LV_YN ,'N') = 'Y'
			   AND NVL(CL.DEL_YN ,'N') = 'N' 
			   AND CL.ACTV_YN = 'Y'
			   AND NVL(SL.DEL_YN ,'N') = 'N' 
			   AND SL.ACTV_YN = 'Y'
		--	   AND SL.LEAF_YN = 'N'
		  GROUP BY CL.SEQ
		) A
        ;
	delete from TB_DPD_SALES_HIER_CLOSURE;


    insert into TB_DPD_SALES_HIER_CLOSURE 
		 ( ancester_id
		 , ancester_cd
--		 , ancester_seq
		 , descendant_id
		 , descendant_cd
--		 , descendant_seq
		 , depth_num
		 , leaf_yn 
         , USE_YN 
 		  )
	with sales_hier as
	(select m.id					as descendant_id 
		  , m.SALES_LV_CD			as descendant_cd
--		  , DENSE_RANK() OVER (ORDER BY CL.SEQ, M.SEQ)+1	AS descendant_seq  
		  , m.parent_sales_lv_id	as ancester_id
		  , p.SALES_LV_CD			as ancester_cd 
		  , 'N'						AS LEAF_YN 
--		  , DENSE_RANK() OVER (ORDER BY PL.SEQ, P.SEQ)	AS ancester_seq  
          , 'Y' AS USE_YN
	   from tb_dp_sales_level_mgmt m 
		    LEFT OUTER JOIN
			tb_dp_sales_level_mgmt p 
		 ON m.PARENT_SALES_LV_ID=p.ID 
		and m.ACTV_YN = 'Y' 
			INNER JOIN 
			TB_CM_LEVEL_MGMT CL
		 ON m.LV_MGMT_ID = CL.ID 
		AND NVL(CL.DEL_YN,'N') = 'N'
		AND CL.ACTV_YN = 'Y'


--			INNER JOIN 
--			TB_CM_LEVEL_MGMT PL
--		 ON P.LV_MGMT_ID = PL.ID 
--		AND NVL(PL.DEL_YN,'N') = 'N'
--		AND PL.ACTV_YN = 'Y'
--	    and P.actv_yn = 'Y'
--	    and NVL(P.del_yn,'N') = 'N'
	 union all 
	 select a.id							as descendant_id
		  , ACCOUNT_CD						as descendant_cd
--		  , v_lv_cnt+1						AS descendant_seq  
		  , a.parent_sales_lv_id			as ancester_id
		  , p.SALES_LV_CD					as ancester_cd 
		  , 'Y'								AS LEAF_YN 
--		  , v_lv_cnt-DENSE_RANK() OVER (ORDER BY P.SEQ DESC)+1	AS ancester_seq  
          , CASE WHEN A.ACTV_YN = 'Y' AND COALESCE(A.DEL_YN,'N') = 'N' THEN 'Y' ELSE 'N' END AS USE_YN 
	  from tb_dp_sales_level_mgmt p 
			INNER JOIN 
			TB_CM_LEVEL_MGMT PL
		 ON P.LV_MGMT_ID = PL.ID 
		AND NVL(PL.DEL_YN,'N') = 'N'
		AND PL.ACTV_YN = 'Y'
	    and P.actv_yn = 'Y'
	    and NVL(P.del_yn,'N') = 'N'
		   INNER JOIN
		   tb_dp_account_mst a
		ON a.PARENT_SALES_LV_ID=p.ID
	 where 1=1
--       AND a.ACTV_YN = 'Y' 
--	   and NVL(a.DEL_YN,'N') = 'N'  
	   and p.ACTV_YN = 'Y'
	)
	select descendant_id
		 , descendant_cd
--		 , descendant_seq
		 , descendant_id
		 , descendant_cd
--		 , descendant_seq
		 , 0				as depth_num  
		 , LEAF_YN			as leaf_yn
         , USE_YN
	   from sales_hier
	  where descendant_id is not null	   
	   ;

	while v_depth <= v_max_depth
	LOOP
       insert into TB_DPD_SALES_HIER_CLOSURE 
			 ( ancester_id
			 , ancester_cd
--			 , ancester_seq
			 , descendant_id
			 , descendant_cd
--			 , descendant_seq
			 , depth_num
			 , leaf_yn  
             , USE_YN
			  )
		with sales_hier as
		(
			select m.id					as descendant_id 
				 , m.SALES_LV_CD		as descendant_cd
--				 , DENSE_RANK() OVER (ORDER BY CL.SEQ, M.SEQ)	AS ancester_seq 
				 , m.parent_sales_lv_id as ancester_id
--				 , p.SALES_LV_CD		as ancester_cd 
				 , 'N'					AS LEAF_YN
                 , 'Y'   AS USE_YN 
			  from tb_dp_sales_level_mgmt m 
				   INNER JOIN
				   tb_dp_sales_level_mgmt p 
				ON m.PARENT_SALES_LV_ID=p.ID 
			   and m.ACTV_YN = 'Y' 
			   	   INNER JOIN 
			   	   TB_CM_LEVEL_MGMT CL
			    ON M.LV_MGMT_ID = CL.ID 
			   AND NVL(CL.DEL_YN,'N') = 'N'
			   AND CL.ACTV_YN = 'Y'
			   and M.actv_yn = 'Y'
			   and NVL(M.del_yn,'N') = 'N'
			   	   INNER JOIN 
			   	   TB_CM_LEVEL_MGMT PL
			    ON P.LV_MGMT_ID = PL.ID 
			   AND NVL(PL.DEL_YN,'N') = 'N'
			   AND PL.ACTV_YN = 'Y'
			   and P.actv_yn = 'Y'
			   and NVL(P.del_yn,'N') = 'N'

			union all 
			select a.id					 as descendant_id
				 , ACCOUNT_CD			 as descendant_cd
--				 , v_lv_cnt+1 SEQ 
				 , a.parent_sales_lv_id  as ancester_id
--				 , l.SALES_LV_CD		 as ancester_cd
				 , 'Y'					 AS LEAF_YN
                 , CASE WHEN A.ACTV_YN = 'Y' AND COALESCE(A.DEL_YN,'N') = 'N' THEN 'Y' ELSE 'N' END AS USE_YN 
			 from tb_dp_account_mst a
				  INNER JOIN
				  tb_dp_sales_level_mgmt l 
			   ON A.PARENT_SALES_LV_ID=l.ID
			  and a.parent_sales_lv_id is not null
			where 1=1
--              AND a.ACTV_YN = 'Y' 
--			  and NVL(a.DEL_YN,'N') = 'N'  
			  and l.ACTV_YN = 'Y'
		)
		select c.ancester_id
			 , c.ancester_cd
--			 , c.ancester_seq
			 , h.descendant_id
			 , h.descendant_cd
--			 , h.ancester_seq
			 , v_depth 	
			 , H.LEAF_YN
             , H.USE_YN 
		from TB_DPD_SALES_HIER_CLOSURE c 
			  inner join 
			  sales_hier h 
		  on (c.descendant_id = h.ancester_id
		 and  c.depth_num = v_depth-1) 
			 ;

		v_depth := v_depth+1
        ;
	END LOOP;
 /*
update 
(
			SELECT   H.LVL01_ID
                    ,H.LVL01_CD
                    ,H.LVL01_NM
                    ,H.LVL02_ID
                    ,H.LVL02_CD
                    ,H.LVL02_NM
                    ,H.LVL03_ID
                    ,H.LVL03_CD
                    ,H.LVL03_NM
                    ,H.LVL04_ID
                    ,H.LVL04_CD
                    ,H.LVL04_NM
                    ,H.LVL05_ID
                    ,H.LVL05_CD
                    ,H.LVL05_NM
                    ,H.LVL06_ID
                    ,H.LVL06_CD
                    ,H.LVL06_NM
                    ,H.LVL07_ID
                    ,H.LVL07_CD
                    ,H.LVL07_NM
                    ,H.LVL08_ID
                    ,H.LVL08_CD
                    ,H.LVL08_NM
                    ,H.LVL09_ID
                    ,H.LVL09_CD
                    ,H.LVL09_NM
                    ,H.LVL10_ID
                    ,H.LVL10_CD
                    ,H.LVL10_NM
                    ,H.ACCOUNT_ID
                    ,H.ACCOUNT_CD
                    ,H.ACCOUNT_NM
                    ,H.CURCY_CD
                    ,H.CURCY_NM
                    ,H.CURCY_ID
                    ,H.SOLD_CUSTOMER_CD
                    ,H.SOLD_CUSTOMER_NM
                    ,H.SHIP_CUSTOMER_CD
                    ,H.SHIP_CUSTOMER_NM
                    ,H.BILL_CUSTOMER_CD
                    ,H.BILL_CUSTOMER_NM
                    ,H.INCOTERMS
                    ,H.CHANNEL_NM
                    ,H.COUNTRY_CD
                    ,H.COUNTRY_NM
                    ,H.VMI_YN
                    ,H.ATTR_01
                    ,H.ATTR_02
                    ,H.ATTR_03
                    ,H.ATTR_04
                    ,H.ATTR_05
                    ,H.ATTR_06
                    ,H.ATTR_07
                    ,H.ATTR_08
                    ,H.ATTR_09
                    ,H.ATTR_10
                    ,H.ATTR_11
                    ,H.ATTR_12
                    ,H.ATTR_13
                    ,H.ATTR_14
                    ,H.ATTR_15
                    ,H.ATTR_16
                    ,H.ATTR_17
                    ,H.ATTR_18
                    ,H.ATTR_19
                    ,H.ATTR_20                    
                  , a.id          AS N_ACCT_ID
                  , c.COMN_CD     as N_CURCY_CD
                  , c.COMN_CD_NM  as N_CURCY_NM
                  , a.CURCY_CD_ID as N_CURCY_ID
                  , s.CUST_CD     as N_SOLD_CUSTOMER_CD
                  , s.CUST_NM     as N_SOLD_CUSTOMER_NM
                  , h.CUST_CD     as N_SHIP_CUSTOMER_CD
                  , h.CUST_NM     as N_SHIP_CUSTOMER_NM
				  , b.CUST_CD     as N_BILL_CUSTOMER_CD
                  , b.CUST_NM     as N_BILL_CUSTOMER_NM
                  , t.INCOTERMS   AS N_INCOTERMS
                  , ct.CHANNEL_NM AS N_CHANNEL_NM
                  , cn.CONF_CD    as N_COUNTRY_CD
                  , cn.CONF_NM    as N_COUNTRY_NM
                  , a.VMI_YN      AS  N_VMI_YN 
                  , a.ATTR_01     AS  N_ATTR_01
                  , a.ATTR_02     AS  N_ATTR_02 
                  , a.ATTR_03     AS  N_ATTR_03
                  , a.ATTR_04     AS  N_ATTR_04
                  , a.ATTR_05     AS  N_ATTR_05
                  , a.ATTR_06     AS  N_ATTR_06
                  , a.ATTR_07     AS  N_ATTR_07 
                  , a.ATTR_08     AS  N_ATTR_08
                  , a.ATTR_09     AS  N_ATTR_09
                  , a.ATTR_10     AS  N_ATTR_10
                  , a.ATTR_11     AS  N_ATTR_11
                  , a.ATTR_12     AS  N_ATTR_12
                  , a.ATTR_13     AS  N_ATTR_13
                  , a.ATTR_14     AS  N_ATTR_14
                  , a.ATTR_15     AS  N_ATTR_15
                  , a.ATTR_16     AS  N_ATTR_16
                  , a.ATTR_17     AS  N_ATTR_17
                  , a.ATTR_18     AS  N_ATTR_18
                  , a.ATTR_19     AS  N_ATTR_19
                  , a.ATTR_20     AS  N_ATTR_20
			FROM TB_DPD_ACCOUNT_HIERACHY2 H
                 INNER JOIN 
                 TB_DP_ACCOUNT_MST  A
              ON H.ACCOUNT_ID = A.ID 
                 inner join 
                 TB_AD_COMN_CODE c on  a.CURCY_CD_ID = c.ID
                 left outer join 
                 TB_CM_CUSTOMER s on s.id = SOLD_TO_ID
                 left outer join 
                 TB_CM_CUSTOMER h on h.id = SHIP_TO_ID
                 left outer join 
                 TB_CM_CUSTOMER b on b.id = BILL_TO_ID
                 left outer join 
                 TB_CM_INCOTERMS T on t.id = INCOTERMS_ID
                 left outer join 
                 TB_CM_CHANNEL_TYPE ct on ct.id = a.CHANNEL_ID
                 left outer join 
                 TB_CM_COMM_CONFIG cn on cn.id =  a.COUNTRY_ID
--           WHERE a.ACTV_YN='Y' 
--             and (a.DEL_YN = 'N' or a.DEL_YN is null) 			
)
   set  CURCY_CD = N_CURCY_CD
      , CURCY_NM = N_CURCY_NM
      , CURCY_ID = N_CURCY_ID,
        SOLD_CUSTOMER_CD=N_SOLD_CUSTOMER_CD, 
        SOLD_CUSTOMER_NM=N_SOLD_CUSTOMER_NM, 
        SHIP_CUSTOMER_CD=N_SHIP_CUSTOMER_CD,
        SHIP_CUSTOMER_NM=N_SHIP_CUSTOMER_NM,
        BILL_CUSTOMER_CD=N_BILL_CUSTOMER_CD,
        BILL_CUSTOMER_NM=N_BILL_CUSTOMER_NM,
        INCOTERMS=N_INCOTERMS,
        CHANNEL_NM=N_CHANNEL_NM,
        COUNTRY_CD=N_COUNTRY_CD,
        COUNTRY_NM=N_COUNTRY_NM,
        VMI_YN=N_VMI_YN,
        ATTR_01=N_ATTR_01,
        ATTR_02=N_ATTR_02,
        ATTR_03=N_ATTR_03,
        ATTR_04=N_ATTR_04,
        ATTR_05=N_ATTR_05,
        ATTR_06=N_ATTR_06,
        ATTR_07=N_ATTR_07,
        ATTR_08=N_ATTR_08,
        ATTR_09=N_ATTR_09,
        ATTR_10=N_ATTR_10,
        ATTR_11=N_ATTR_11,
        ATTR_12=N_ATTR_12,
        ATTR_13=N_ATTR_13,
        ATTR_14=N_ATTR_14,
        ATTR_15=N_ATTR_15,
        ATTR_16=N_ATTR_16,
        ATTR_17=N_ATTR_17,
        ATTR_18=N_ATTR_18,
        ATTR_19=N_ATTR_19,
        ATTR_20=N_ATTR_20,
       ;
*/
    DELETE FROM TB_DPD_ACCOUNT_HIERACHY2;
    INSERT INTO TB_DPD_ACCOUNT_HIERACHY2
    (     LVL01_ID
        , LVL02_ID
        , LVL03_ID
        , LVL04_ID
        , LVL05_ID
        , LVL06_ID
        , LVL07_ID
        , LVL08_ID
        , LVL09_ID
        , LVL10_ID
        , LVL01_CD
        , LVL02_CD
        , LVL03_CD
        , LVL04_CD
        , LVL05_CD
        , LVL06_CD
        , LVL07_CD
        , LVL08_CD
        , LVL09_CD
        , LVL10_CD
        , LVL01_NM
        , LVL02_NM
        , LVL03_NM
        , LVL04_NM
        , LVL05_NM
        , LVL06_NM
        , LVL07_NM
        , LVL08_NM
        , LVL09_NM
        , LVL10_NM
        , ACCOUNT_ID
        , ACCOUNT_CD
        , ACCOUNT_NM
        , CURCY_CD
        , CURCY_NM
        , CURCY_ID
        , SOLD_CUSTOMER_CD
        , SOLD_CUSTOMER_NM
        , SHIP_CUSTOMER_CD
        , SHIP_CUSTOMER_NM
        , BILL_CUSTOMER_CD
        , BILL_CUSTOMER_NM
        , INCOTERMS
        , CHANNEL_NM
        , COUNTRY_CD
        , COUNTRY_NM
        , VMI_YN
        , ATTR_01
        , ATTR_02
        , ATTR_03
        , ATTR_04
        , ATTR_05
        , ATTR_06
        , ATTR_07
        , ATTR_08
        , ATTR_09
        , ATTR_10
        , ATTR_11
        , ATTR_12
        , ATTR_13
        , ATTR_14
        , ATTR_15
        , ATTR_16
        , ATTR_17
        , ATTR_18
        , ATTR_19
        , ATTR_20
        , USE_YN 
    ) 
    WITH SALES_HIER 
     AS (
        SELECT ANCESTER_ID  
                 , ANCESTER_CD
                 , COALESCE(SL.SALES_LV_NM, AC.ACCOUNT_NM) AS ANCESTER_NM
                 , DESCENDANT_ID
                 , DESCENDANT_CD
                 , 'LVL'|| LPAD( DENSE_RANK () OVER ( ORDER BY DEPTH_NUM DESC ), 2, '0')  AS COL
          FROM TB_DPD_SALES_HIER_CLOSURE SH 
               LEFT OUTER JOIN 
               TB_DP_SALES_LEVEL_MGMT SL 
            ON SH.ANCESTER_ID = SL.ID 
              LEFT OUTER JOIN 
              TB_DP_ACCOUNT_MST AC
           ON SH.ANCESTER_ID = AC.ID 
         WHERE SH.LEAF_YN = 'Y' 
     ), CURRENCY
     AS (
         SELECT CD.ID, CD.COMN_CD, CD.COMN_CD_NM 
           FROM TB_AD_COMN_GRP CM
                INNER JOIN 
                TB_AD_COMN_CODE CD 
             ON CM.ID = CD.SRC_ID 
            AND CM.GRP_CD = 'CURRENCY'  
     ), COUNTRY
    AS (
         SELECT B.ID  AS ID
              , B.CONF_CD 
              , B.CONF_NM 
           FROM TB_CM_CONFIGURATION A
                INNER JOIN 
                TB_CM_COMM_CONFIG B
             ON A.ID = B.CONF_ID
            AND B.CONF_GRP_CD = 'CM_COUNTRY'
            AND B.ACTV_YN = 'Y'
        ) 
    SELECT  LVL01_ID
          , LVL02_ID
          , LVL03_ID
          , LVL04_ID
          , LVL05_ID
          , LVL06_ID
          , LVL07_ID
          , LVL08_ID
          , LVL09_ID
          , LVL10_ID
          , LVL01_CD
          , LVL02_CD
          , LVL03_CD
          , LVL04_CD
          , LVL05_CD
          , LVL06_CD
          , LVL07_CD
          , LVL08_CD
          , LVL09_CD
          , LVL10_CD
          , LVL01_NM
          , LVL02_NM
          , LVL03_NM
          , LVL04_NM
          , LVL05_NM
          , LVL06_NM
          , LVL07_NM
          , LVL08_NM
          , LVL09_NM
          , LVL10_NM
          , DESCENDANT_ID					AS ACCOUNT_ID
          , DESCENDANT_CD					AS ACCOUNT_CD
          , AM.ACCOUNT_NM					AS ACCOUNT_NM
          , CC.COMN_CD						AS CURCY_CD
          , CC.COMN_CD_NM					AS CURCY_NM
          , AM.CURCY_CD_ID					AS CURCY_ID
          , ST.CUST_CD						AS SOLD_CUSTOMER_CD
          , ST.CUST_NM						AS SOLD_CUSTOMER_NM
          , PT.CUST_CD						AS SHIP_CUSTOMER_CD
          ,	PT.CUST_NM						AS SHIP_CUSTOMER_NM
          ,	BT.CUST_CD						AS BILL_CUSTOMER_CD
          ,	BT.CUST_NM						AS BILL_CUSTOMER_NM
          , IC.INCOTERMS
          , CH.CHANNEL_NM
          , CR.CONF_CD						AS COUNTRY_CD
          , CR.CONF_NM						AS COUNTRY_NM
          , AM.VMI_YN
          , AM.ATTR_01
          , AM.ATTR_02
          , AM.ATTR_03
          , AM.ATTR_04
          , AM.ATTR_05
          , AM.ATTR_06
          , AM.ATTR_07
          , AM.ATTR_08
          , AM.ATTR_09
          , AM.ATTR_10
          , AM.ATTR_11
          , AM.ATTR_12
          , AM.ATTR_13
          , AM.ATTR_14
          , AM.ATTR_15
          , AM.ATTR_16
          , AM.ATTR_17
          , AM.ATTR_18
          , AM.ATTR_19
          , AM.ATTR_20
          , CASE WHEN AM.ACTV_YN = 'Y' AND COALESCE(AM.DEL_YN,'N') = 'N' THEN 'Y' ELSE 'N' END AS USE_YN 
      FROM SALES_HIER SH
           PIVOT (MAX(ANCESTER_ID) AS ID
                , MAX(ANCESTER_CD) AS CD
                , MAX(ANCESTER_NM) AS NM 
            FOR COL IN ( 'LVL01' AS LVL01	
                       , 'LVL02' AS LVL02
                       , 'LVL03' AS LVL03
                       , 'LVL04' AS LVL04
                       , 'LVL05' AS LVL05
                       , 'LVL06' AS LVL06
                       , 'LVL07' AS LVL07
                       , 'LVL08' AS LVL08
                       , 'LVL09' AS LVL09
                       , 'LVL10' AS LVL10)
                      )  SH
           INNER JOIN
           TB_DP_ACCOUNT_MST AM
        ON SH.DESCENDANT_ID = AM.ID 
           LEFT OUTER JOIN
           TB_CM_CUSTOMER ST
        ON AM.SOLD_TO_ID = ST.ID 
           LEFT OUTER JOIN
           TB_CM_CUSTOMER PT
        ON AM.SHIP_TO_ID = PT.ID 	
           LEFT OUTER JOIN
           TB_CM_CUSTOMER BT
        ON AM.BILL_TO_ID = BT.ID 	
           LEFT OUTER JOIN 
           TB_CM_INCOTERMS IC
        ON IC.ID = AM.INCOTERMS_ID
           LEFT OUTER JOIN 
           TB_CM_CHANNEL_TYPE CH 
        ON CH.ID = AM.CHANNEL_ID
           LEFT OUTER JOIN
           CURRENCY CC
        ON AM.CURCY_CD_ID = CC.ID 
           LEFT OUTER JOIN
           COUNTRY CR
        ON CR.ID = AM.COUNTRY_ID
    WHERE LVL01_ID IS NOT NULL
    ; 


END
;
/

