create PROCEDURE "SP_UI_DP_35_VALID_Q6_U_AUTH" 
--(	
--	 p_EMP_ID		VARCHAR2 := ''
--	,p_AUTH_TP_ID	VARCHAR2 := ''
--) 
(
 pRESULT       OUT SYS_REFCURSOR
)
IS 


BEGIN

OPEN pRESULT          
FOR 
	SELECT	A.ID, A.SALES_LV_CD, A.SALES_LV_NM , B.LV_CD, B.LV_NM
	FROM	TB_DP_SALES_LEVEL_MGMT	A 
			INNER JOIN TB_CM_LEVEL_MGMT	B ON A.LV_MGMT_ID = B.ID AND B.ACTV_YN = 'Y'
	WHERE	A.ACTV_YN = 'Y' AND A.VIRTUAL_YN = 'N'
	AND		A.LV_MGMT_ID IN ( SELECT ID 
                                FROM TB_CM_LEVEL_MGMT
                               WHERE ACTV_YN = 'Y') 
	AND		NVL(A.PARENT_SALES_LV_ID, 'none') IN	(
												SELECT ID 
												FROM TB_DP_SALES_LEVEL_MGMT 
												WHERE ACTV_YN = 'Y'
												)
	AND		NOT EXISTS	(
						SELECT 'X'
						FROM TB_DP_SALES_AUTH_MAP X 
						WHERE A.ID = X.SALES_LV_ID
						);
END
;

/

