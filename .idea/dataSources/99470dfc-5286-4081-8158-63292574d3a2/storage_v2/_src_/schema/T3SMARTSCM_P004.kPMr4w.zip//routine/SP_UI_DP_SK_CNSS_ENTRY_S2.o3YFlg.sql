create PROCEDURE                 "SP_UI_DP_SK_CNSS_ENTRY_S2" 
(
 P_C_VER_CD          VARCHAR2 -- New Version ID
,P_USER_ID           VARCHAR2
,P_AUTH_TP_ID        VARCHAR2
,P_ACCOUNT_ID        VARCHAR2
,P_RT_ROLLBACK_FLAG  OUT VARCHAR2   
,P_RT_MSG            OUT VARCHAR2 
) IS
/************************************************************************************************
    Consensus Version Save

    History (date / writer / comment)
    - 2021.05.13 / Kimsohee / Draft
    - 2012.06.01 / 源��슜�닔
*************************************************************************************************/ 
P_ERR_STATUS INT := 0;
P_ERR_MSG VARCHAR2(4000) :='';   
P_EMP_ID CHAR(32);
P_STRT_DATE DATE ;
P_BOE     NUMBER(20,3);
BEGIN 
        SELECT ID INTO P_EMP_ID
          FROM TB_AD_USER 
         WHERE USERNAME = P_USER_ID
        ;

        SELECT C.FROM_DATE INTO P_STRT_DATE
          FROM TB_SDP_CONSENSUS_VER_MST C
         WHERE C_VER_CD = P_C_VER_CD 
         ;

        SELECT QTY_5 INTO P_BOE
          FROM TB_SDP_CONSENSUS_ENTRY
         WHERE C_VER_CD = P_C_VER_CD
           AND ACCOUNT_ID = P_ACCOUNT_ID 
           AND BASE_DATE = P_STRT_DATE 
           ;

        MERGE INTO TB_SDP_CONSENSUS_ENTRY TGT
         USING (
                SELECT BASE_DATE 
--                       ,C.QTY      -- �닔�웾 (�쁽 R Consensus F'cst) : A
--                       ,C.QTY_1    -- �닔�웾 (�쁽 R RTF) : B
                       ,C.QTY_2    -- �닔�웾 (RTF Target) : C
--                       ,C.QTY_3    -- �닔�웾 (Consensus Plan) : G
                       ,C.QTY_2 - C.QTY   AS QTY_4 -- 李⑥씠 : C-A : QTY_2-QTY
                       ,NVL(P_BOE,0) - SUM(NVL(C.QTY_2,0)) OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC) + SUM(NVL(C.QTY_6,0)) 
                        OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC) + NVL(C.QTY_2,0) - NVL(C.QTY_6,0)   AS QTY_5 -- BOH : 吏��궃二� H (QTY_7)
--                       ,C.QTY_6    -- 媛��슜�옱怨� : E  
                       ,NVL(P_BOE,0) - SUM(NVL(C.QTY_2,0)) OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC) + SUM(NVL(C.QTY_6,0)) 
                        OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC) AS QTY_7   -- EOH : D+E-C : QTY_5 + QTY_6 - QTY_2  / BOH + 媛��슜�옱怨� - �엯�젰�닔�웾 (RTF Target)
--                       ,C.QTY_8    -- �닔�웾 (�쟾R �뿰�룞怨꾪쉷)
--                       ,C.QTY_9    -- �닔�웾 (寃쎌쁺怨꾪쉷)
                       , C.QTY_3 - C.QTY   AS QTY_10   -- 李⑥씠 : G-A : QTY3-QTY
                  FROM TB_SDP_CONSENSUS_ENTRY C
                 WHERE C_VER_CD = P_C_VER_CD
                   AND ACCOUNT_ID = P_ACCOUNT_ID
         ) SRC ON (TGT.C_VER_CD = P_C_VER_CD
              AND TGT.ACCOUNT_ID = P_ACCOUNT_ID
              AND TGT.BASE_DATE = SRC.BASE_DATE)
        WHEN MATCHED THEN
        UPDATE 
           SET TGT.QTY_4 = SRC.QTY_4
            ,  TGT.QTY_5 = SRC.QTY_5
            ,  TGT.QTY_7 = SRC.QTY_7
            ,  TGT.QTY_10 = SRC.QTY_10
            ,  TGT.EMP_ID = P_EMP_ID
            ,  TGT.MODIFY_DTTM = SYSDATE
            ,  TGT.MODIFY_BY = P_EMP_ID
        ;


 	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  
       /*  ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN  -- : e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF; 

END
;

/

