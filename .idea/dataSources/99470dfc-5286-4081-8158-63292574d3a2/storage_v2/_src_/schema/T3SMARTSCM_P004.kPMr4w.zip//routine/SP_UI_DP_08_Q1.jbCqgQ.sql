create PROCEDURE "SP_UI_DP_08_Q1" (p_ITEM_LV       IN  VARCHAR2 := ''
                                             ,p_ACTV_YN            IN VARCHAR2 := ''
                                             ,pRESULT       OUT SYS_REFCURSOR ) IS 


BEGIN


OPEN pRESULT          
FOR 
SELECT IL.ID
      ,IL.ITEM_LV_CD
      ,IL.ITEM_LV_NM
      ,IL.LV_MGMT_ID
      ,IL.ATTR_01
      ,NVL(IL.PARENT_ITEM_LV_ID, '') AS PARENT_ITEM_LV_ID
      ,IL2.ITEM_LV_CD  AS PARENT_ITEM_LV_CD
      ,IL2.ITEM_LV_NM  AS PARENT_ITEM_LV_NM        
      ,IL.SEQ
      ,IL.ACTV_YN
      ,IL.DEL_YN
      ,IL.CREATE_BY
      ,IL.CREATE_DTTM
      ,IL.MODIFY_BY
      ,IL.MODIFY_DTTM
--      ,IL.ITEM_LV_NM||(CASE WHEN ITEM_CNT = 0 OR ITEM_CNT IS NULL THEN NULL ELSE' ('|| ITEM_CNT||')' END) AS ITEM_LV_TREE_NM
  FROM TB_CM_CONFIGURATION A
     , TB_CM_COMM_CONFIG B
     , TB_CM_LEVEL_MGMT  LM
     , TB_CM_ITEM_LEVEL_MGMT IL 
          LEFT OUTER JOIN  TB_CM_ITEM_LEVEL_MGMT IL2 ON  IL.PARENT_ITEM_LV_ID = IL2.ID AND IL2.DEL_YN = 'N' AND IL2.ACTV_YN = 'Y'
--      LEFT OUTER JOIN
--         (SELECT PARENT_ITEM_LV_ID
--               , COUNT(ITEM_CD) AS ITEM_CNT
--            FROM TB_CM_ITEM_MST IM
--          WHERE 1=1
--            AND DEL_YN !='Y'
--            AND DP_PLAN_YN = 'Y'          
--       GROUP BY PARENT_ITEM_LV_ID)IM
--     ON IM.PARENT_ITEM_LV_ID = IL.ID          
  WHERE A.MODULE_CD = 'DP'
    AND A.ID = B.CONF_ID
    AND B.CONF_GRP_CD = 'DP_LV_TP'
    AND B.CONF_CD = 'I'
    AND B.ID = LM.LV_TP_ID  -- S/C/I
    AND COALESCE(LM.DEL_YN, 'N') = 'N'
    AND LM.ACTV_YN = 'Y'
    AND LM.ID = IL.LV_MGMT_ID 
--    AND IL.DEL_YN = 'N'
    AND IL.LV_MGMT_ID  LIKE '%' || LTRIM(RTRIM(p_ITEM_LV)) || '%'
    AND (IL.ACTV_YN LIKE '%' || RTRIM(p_ACTV_YN) || '%' OR RTRIM(P_ACTV_YN) IS NULL)
  ORDER BY LM.SEQ, IL.SEQ
 ;
----FOR TREE COMPONENT QUERY
--SELECT  IL.ID
--        , IL.ITEM_LV_CD
--        , IL.ITEM_LV_NM
--        , IL.PARENT_ITEM_LV_ID
--         ,IL.ITEM_LV_NM||(CASE WHEN ITEM_CNT = 0 THEN NULL ELSE' ('|| ITEM_CNT||')' END) AS ITEM_LV_TREE_NM
--    FROM TB_CM_ITEM_LEVEL_MGMT IL
--         INNER JOIN
--         TB_CM_LEVEL_MGMT LM
--      ON LM.ID = IL.LV_MGMT_ID
--     AND LM.ACTV_YN ='Y'
--     AND LM.DEL_YN !='Y'
--     AND LM.SALES_LV_YN ='N'
--     AND LM.ACCOUNT_LV_YN ='N'
--     AND LEAF_YN ='N'
--         LEFT OUTER JOIN
--         (SELECT PARENT_ITEM_LV_ID
--               , COUNT(ITEM_CD) AS ITEM_CNT
--            FROM TB_CM_ITEM_MST IM
--          WHERE 1=1
--            AND DEL_YN !='Y'
--            AND DP_PLAN_YN = 'Y'          
--       GROUP BY PARENT_ITEM_LV_ID)IM
--     ON IM.PARENT_ITEM_LV_ID = IL.ID
--   WHERE 1=1
--     AND IL.ACTV_YN = 'Y'
--     AND IL.DEL_YN !='Y'
--     ;

END
;
/

