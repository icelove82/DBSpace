create PROCEDURE SP_UI_BF_00_VERSION_Q2(
     pRESULT        OUT  SYS_REFCURSOR
)

IS

BEGIN
     OPEN pRESULT
     FOR
     SELECT *
       FROM (
               SELECT RS.VER_ID
                 FROM (
                          SELECT VER_ID
                            FROM TB_DF_ACCRY_REF
                           GROUP BY VER_ID
                       ) RS
                INNER JOIN TB_DF_LC_VER_MST VM ON RS.VER_ID = VM.VER_ID
             ) M
      WHERE ROWNUM<=5;
END;

/

