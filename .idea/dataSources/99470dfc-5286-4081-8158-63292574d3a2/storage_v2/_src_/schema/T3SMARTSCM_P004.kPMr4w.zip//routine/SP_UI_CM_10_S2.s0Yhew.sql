create PROCEDURE SP_UI_CM_10_S2 (
    P_TRANSP_MGMT_MST_ID        IN CHAR	    := NULL,
 	P_BOD_LT_ACTV_YN			IN CHAR		:= '',
    P_FIXED_YN                  IN CHAR     := '',
	P_BOD_PRIORITY			    IN INT      := NULL,
    P_OUTBOUND_LT               IN NUMBER   := NULL,
	P_VOYAGE_LT				    IN NUMBER   := NULL,
    P_INBOUND_LT			    IN NUMBER   := NULL,
    P_LT_UOM_ID				    IN CHAR     := NULL,
	P_LOAD_UOM_ID				IN CHAR	    := NULL,
	P_TRANSP_LOTSIZE			IN NUMBER   := NULL,
	P_USER_ID					IN VARCHAR2 :='',
	P_RT_ROLLBACK_FLAG	        OUT VARCHAR2,
	P_RT_MSG				    OUT VARCHAR2
)
IS
    P_ERR_STATUS NUMBER := 0;
    P_ERR_MSG  VARCHAR2(4000) := '';
    V_LOAD_UOM VARCHAR2(30) := '';
    
BEGIN

    P_ERR_MSG := 'MSG_0008';
    IF P_BOD_PRIORITY IS NOT NULL AND P_BOD_PRIORITY < 0 THEN
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    IF P_TRANSP_LOTSIZE IS NOT NULL AND P_TRANSP_LOTSIZE < 0 THEN
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    IF P_OUTBOUND_LT IS NOT NULL AND P_OUTBOUND_LT < 0 THEN
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    IF P_VOYAGE_LT IS NOT NULL AND P_VOYAGE_LT < 0 THEN
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    IF P_INBOUND_LT IS NOT NULL AND P_INBOUND_LT < 0 THEN
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;

    BEGIN
        SELECT UPPER(B.COMN_CD) INTO V_LOAD_UOM
          FROM TB_AD_COMN_GRP A
               INNER JOIN TB_AD_COMN_CODE B
               ON A.ID = B.SRC_ID
         WHERE 1=1
           AND A.GRP_CD = 'LOAD_UOM_TYPE'
           AND B.ID = P_LOAD_UOM_ID;
        EXCEPTION
        WHEN NO_DATA_FOUND
        THEN NULL;
    END;

    MERGE INTO TB_CM_TRANSFER_MGMT_MST B
    USING (
           SELECT  A.ID                 AS TRANSP_MGMT_MST_ID
                 , C.PALLET_TP_ID
                 , C.PACKING_TP_CD_ID
                 , C.UOM_PER_PACKING    AS UOM_PER_PACKING
                 , C.PACKING_PER_PALLET AS PACKING_PER_PALLET
                 , V_LOAD_UOM           AS LOAD_UOM
                 , P_TRANSP_LOTSIZE     AS TRANSP_LOTSIZE
                 , CASE WHEN V_LOAD_UOM = 'UOM'		THEN P_TRANSP_LOTSIZE
                        WHEN V_LOAD_UOM = 'PACKING' THEN C.UOM_PER_PACKING * P_TRANSP_LOTSIZE
                        WHEN V_LOAD_UOM = 'PALLET'	THEN C.UOM_PER_PACKING * C.PACKING_PER_PALLET * P_TRANSP_LOTSIZE
                        ELSE 0
                   END AS UOM_QTY
                 ,P_BOD_LT_ACTV_YN		AS BOD_LT_ACTV_YN
                 ,P_FIXED_YN            AS FIXED_YN
                 ,P_BOD_PRIORITY		AS BOD_PRIORITY
                 ,P_LOAD_UOM_ID			AS LOAD_UOM_ID
                 ,P_USER_ID				AS USER_ID
                 ,SYSDATE				AS MODIFY_DTTM
             FROM TB_CM_TRANSFER_MGMT_MST A
                  INNER JOIN  TB_CM_SITE_ITEM B
                  ON A.SUPPLY_LOCAT_ITEM_ID = B.ID
                  LEFT OUTER JOIN  TB_CM_SITE_PACKING C
                  ON B.ID = C.LOCAT_ITEM_ID
            WHERE 1=1
              AND A.ID = P_TRANSP_MGMT_MST_ID
        ) A 
     ON (A.TRANSP_MGMT_MST_ID = B.ID)
     WHEN MATCHED THEN
        UPDATE 
        SET
            B.ACTV_YN = A.BOD_LT_ACTV_YN,
            B.FIXED_YN = A.FIXED_YN,
            B.PRIORT = A.BOD_PRIORITY,
            B.LOAD_UOM_ID = A.LOAD_UOM_ID,
            B.TRANSP_LOTSIZE = A.TRANSP_LOTSIZE,
            B.UOM_QTY = A.UOM_QTY,
            B.PACKING_QTY = A.UOM_QTY/A.UOM_PER_PACKING,
            B.PACKING_TP_ID = A.PACKING_TP_CD_ID,
            B.PALLET_QTY = (A.UOM_QTY/A.UOM_PER_PACKING)/A.PACKING_PER_PALLET,
            B.PALLET_TP_ID = A.PALLET_TP_ID,
            B.MODIFY_BY = A.USER_ID,
            B.MODIFY_DTTM = A.MODIFY_DTTM;

	UPDATE	TB_CM_TRANSFER_MGMT_DTL A
	SET		A.UOM_ID = P_LT_UOM_ID,
            A.LEADTIME =    (
                            SELECT	CASE WHEN Z.COMN_CD = 'OUTBOUND' THEN P_OUTBOUND_LT
                                         WHEN Z.COMN_CD = 'VOYAGE'   THEN P_VOYAGE_LT
                                         WHEN Z.COMN_CD = 'INBOUND'  THEN P_INBOUND_LT
                                    ELSE NULL
                                    END
                            FROM	TB_CM_TRANSFER_MGMT_DTL X,
                                    TB_CM_BOD_LT Y
                                    INNER JOIN TB_AD_COMN_CODE Z
                                    ON Z.ID = Y.LEADTIME_TP_ID
                            WHERE	Y.ID = X.BOD_LEADTIME_ID
                            AND		X.TRANSP_MGMT_MST_ID = P_TRANSP_MGMT_MST_ID
                            AND     X.ID = A.ID
                            );

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';

EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
    THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;
      ELSE
          RAISE;
      END IF;
END;

/

