create PROCEDURE "SP_UI_DP_22_1_Q0" (
    P_WORK_CD       VARCHAR2 
  , P_PLAN_TP_ID    CHAR  
  , P_MS_VAL_TP_CD  VARCHAR2
  , pRESULT         OUT SYS_REFCURSOR
) AS
/***************************************
    -- Default value : NONE
**************************************/
    P_NONE_VAL_TP_ID CHAR(32);

BEGIN
--DECLARE @P_WORK_CD         NVARCHAR(30)   = 'SALESMAN'
--    , @P_PLAN_TP_ID    CHAR(32)       = '4FFB97D63C36417D810450471B7D752D'
--    , @P_MS_VAL_TP_CD  NVARCHAR(100)  = 'QTY_5'

    SELECT ID INTO P_NONE_VAL_TP_ID
      FROM TB_CM_COMM_CONFIG
     WHERE CONF_GRP_CD = 'DP_INIT_VAL_TP'
       AND CONF_CD = 'NN';

    OPEN pRESULT
    FOR
    SELECT COALESCE(I.INIT_VAL_TP_ID, P_NONE_VAL_TP_ID) AS INIT_VAL_TP_ID
         , CASE WHEN C.CONF_CD='PR' THEN I.INIT_FIXED_LV_MGMT_ID
                WHEN C.CONF_CD='MS' THEN I.INIT_MEASURE_ID
            END AS INIT_VAL_ID
         , U.WORK_CD
         , U.PLAN_TP_ID
         , U.MS_VAL_TP_CD
         , U.MS_VAL_TP_NM
         , U.MASTER_YN
      FROM (
        SELECT P_WORK_CD            AS WORK_CD
             , P_PLAN_TP_ID         AS PLAN_TP_ID
             , P_MS_VAL_TP_CD       AS MS_VAL_TP_CD
             , (SELECT CONF_NM 
                  FROM TB_CM_COMM_CONFIG 
                 WHERE CONF_GRP_CD ='DP_MS_VAL_TP' 
                   AND CONF_CD = P_MS_VAL_TP_CD 
               )                    AS MS_VAL_TP_NM
             , 'true'               AS MASTER_YN
          FROM DUAL
      ) U
      LEFT OUTER JOIN TB_DP_CONTROL_BOARD_MST M
        ON 1=1
      LEFT OUTER JOIN TB_DP_CONTROL_BOARD_MST_INIT I
        ON I.CONBD_MST_ID = M.ID 
       AND I.MS_VAL_TP_CD = P_MS_VAL_TP_CD
      LEFT OUTER JOIN TB_CM_COMM_CONFIG C
        ON I.INIT_VAL_TP_ID = C.ID  
     WHERE M.WORK_CD = P_WORK_CD
       AND M.PLAN_TP_ID = P_PLAN_TP_ID
    ;
END;

/

