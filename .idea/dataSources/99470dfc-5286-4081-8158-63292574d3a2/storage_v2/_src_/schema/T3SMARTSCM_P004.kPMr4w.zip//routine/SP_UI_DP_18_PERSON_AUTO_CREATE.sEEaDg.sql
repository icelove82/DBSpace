create PROCEDURE                "SP_UI_DP_18_PERSON_AUTO_CREATE" 
(
    P_GRP_ID           IN  VARCHAR2 :=''
  , P_UI_ID            IN  VARCHAR2 :=''
  , P_GRID_ID          IN  VARCHAR2 :=''
  , P_USER_ID          IN  VARCHAR2 :='' 
  , P_RT_ROLLBACK_FLAG OUT VARCHAR2      
  , P_RT_MSG           OUT VARCHAR2  
)IS
    V_AUTH_TP_CD VARCHAR2(100) :='';
    V_PERSON_CNT INT;
    P_USER_PREF_MST_ID CHAR(32);
    P_ERR_STATUS INT := 0;
    P_ERR_MSG VARCHAR2(4000):='';
    /*****************************************************************************************************************
        DP Dimension 
        2018.06.07
        2021.03.08 / kimsohee / code 정리
        2021.03.22 / kimsohee / bug fix
    *****************************************************************************************************************/
BEGIN                  
    SELECT ID INTO P_USER_PREF_MST_ID
      FROM TB_AD_USER_PREF_MST
     WHERE VIEW_CD = P_UI_ID
       AND GRID_CD = P_GRID_ID;
    /************************************************************************************************************
        -- Validation
    ************************************************************************************************************/    
    SELECT COUNT(*) INTO P_ERR_STATUS
      FROM TB_DP_DIM_SETTING
     WHERE UI_ID = P_UI_ID
       AND GRP_ID = P_GRP_ID
       AND GRID_ID = P_GRID_ID
       AND LV_MGMT_ID IN ( SELECT ID
                             FROM TB_CM_LEVEL_MGMT
                            WHERE 1=1
                              AND COALESCE(SALES_LV_YN, 'N') = 'N'
                              AND COALESCE(ACCOUNT_LV_YN, 'N') = 'N'
                              AND COALESCE(DEL_YN, 'N') = 'N'
                              AND ACTV_YN = 'Y'           
                         ) 
    ;

    IF(P_ERR_STATUS >20)
    THEN
         P_ERR_MSG := 'MSG_5108';
         RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF
    ;


    SELECT COUNT(*) INTO P_ERR_STATUS
      FROM TB_DP_DIM_SETTING
     WHERE 1=1
       AND UI_ID               = P_UI_ID
       AND GRP_ID              = P_GRP_ID
       AND GRID_ID             = P_GRID_ID
       ;
    IF(P_ERR_STATUS >40)
    THEN
         P_ERR_MSG := 'MSG_5047';
         RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF
    ;


    /************************************************************************************************************
        -- REMOVE Preference Data
    ************************************************************************************************************/    
    DELETE FROM TB_AD_USER_PREF_DTL
     WHERE 1=1
       AND GRP_ID = P_GRP_ID
       AND USER_PREF_MST_ID = P_USER_PREF_MST_ID
       AND COALESCE(DIM_MEASURE_TP, 'DEFAULT') != 'MEASURE';
    /************************************************************************************************************
        -- MAKE KEY
    ************************************************************************************************************/           
    INSERT INTO TB_AD_USER_PREF_DTL (
        ID
      , USER_PREF_MST_ID
      , GRP_ID
      , FLD_CD
--    , FLD_APPLY_CD
      , FLD_WIDTH
      , FLD_SEQ
      , FLD_ACTIVE_YN
      , APPLY_YN
      , CROSSTAB_ITEM_CD
      , DIM_MEASURE_TP
      , EDIT_TARGET_YN
      , DATA_KEY_YN
      , CROSSTAB_YN
      , CREATE_BY
      , CREATE_DTTM
    )
    WITH
    MN AS (
        SELECT P_USER_PREF_MST_ID   AS USER_PREF_MST_ID
             , P_GRP_ID             AS GRP_ID
             , 0                    AS SEQ
             , 100                  AS FIELD_WDTH
             , 'N'                  AS PSNZ_APPY_YN
             , 'DEFAULT'            AS DIM_MEASURE_TP
             , 'Y'                  AS PIVOT_APPY_YN
             , P_USER_ID            AS CREATE_BY
             , SYSDATE              AS CREATE_DTTM
        FROM dual
    ), DATA_KEY AS (
        SELECT 'ITEM'           AS FIELD_ID
             , 'GROUP-COLUMNS'  AS PIVOT_ITEM_CD
             , 'N'              AS ACTV_YN
             , 'Y'              AS DATA_KEY_YN
             , 'N'              AS DAT_FIELD_YN
             , 'N'              AS EDIT_TARGET 
        FROM dual
        UNION  
        SELECT 'SALES'          AS FIELD_ID
             , 'GROUP-COLUMNS'  AS PIVOT_ITEM_CD
             , 'N'              AS ACTV_YN
             , 'Y'              AS DATA_KEY_YN
             , 'N'              AS DAT_FIELD_YN
             , 'N'              AS EDIT_TARGET 
        FROM dual
       WHERE P_UI_ID LIKE 'UI_DP_2%'
        UNION  
        SELECT 'ACCOUNT'        AS FIELD_ID
             , 'GROUP-COLUMNS'  AS PIVOT_ITEM_CD
             , 'N'              AS ACTV_YN
             , 'Y'              AS DATA_KEY_YN
             , 'N'              AS DAT_FIELD_YN
             , 'N'              AS EDIT_TARGET
        FROM dual
        UNION  
        SELECT 'DATE'           AS FIELD_ID
             , 'GROUP-ROWS'     AS PIVOT_ITEM_CD
             , 'Y'              AS ACTV_YN
             , 'N'              AS DATA_KEY_YN
             , 'Y'              AS DAT_FIELD_YN
             , 'Y'              AS EDIT_TARGET
        FROM dual
        UNION  
        SELECT 'PERIOD'                   AS FIELD_ID
             , 'GROUP-HORIZONTAL-VALUES'  AS PIVOT_ITEM_CD
             , 'N'                        AS ACTV_YN
             , 'N'                        AS DATA_KEY_YN
             , 'N'                        AS DAT_FIELD_YN
             , 'N'                        AS EDIT_TARGET -- UI 화면에서 보여지지 않도록 N 처리
        FROM dual
       WHERE P_UI_ID LIKE 'UI_DP_2%'        
        UNION  
        SELECT 'CATEGORY'     AS FIELD_ID
             , NULL           AS PIVOT_ITEM_CD
             , 'Y'            AS ACTV_YN
             , 'N'            AS DATA_KEY_YN
             , 'N'            AS DAT_FIELD_YN 
             , 'N'            AS EDIT_TARGET
        FROM dual
        UNION  
        SELECT 'BUCK_TP'     AS FIELD_ID
             , 'GROUP-COLUMNS'           AS PIVOT_ITEM_CD
             , 'N'            AS ACTV_YN
             , 'N'            AS DATA_KEY_YN
             , 'N'            AS DAT_FIELD_YN 
             , 'N'            AS EDIT_TARGET
        FROM dual 
       where P_UI_ID like 'UI_DP_95%' or P_UI_ID like 'UI_BP_95%'
    )
    SELECT TO_SINGLE_BYTE(SYS_GUID()) 
         , A.USER_PREF_MST_ID
         , A.GRP_ID
         , B.FIELD_ID
--                               , FIELD_NM 
         , A.FIELD_WDTH
         , A.SEQ
         , B.ACTV_YN
         , A.PSNZ_APPY_YN -- APPY_YN 
         -- REFER_VALUE
         , B.PIVOT_ITEM_CD
         -- CATEGORY_GROUP
         , A.DIM_MEASURE_TP
         , B.EDIT_TARGET
         , B.DATA_KEY_YN
         , A.PIVOT_APPY_YN 
--                               , B.DAT_FIELD_YN   
         , A.CREATE_BY
         , A.CREATE_DTTM
      FROM MN A
     CROSS JOIN DATA_KEY B
    ;
    /************************************************************************************************************
        -- Insert Preference Data
    ************************************************************************************************************/    
    -- ITEM LEVEL
    INSERT INTO TB_AD_USER_PREF_DTL (
        ID
      , USER_PREF_MST_ID
      , GRP_ID
      , FLD_CD
      , FLD_APPLY_CD
      , FLD_WIDTH
      , FLD_SEQ
      , FLD_ACTIVE_YN
      , APPLY_YN
      , REFER_VALUE
      , CROSSTAB_ITEM_CD
      , CATEGORY_GROUP
      , DIM_MEASURE_TP
--    , SUMMARY_TP
--    , SUMMARY_YN
      , EDIT_MEASURE_YN
      , EDIT_TARGET_YN
      , DATA_KEY_YN
      , CROSSTAB_YN
      , CREATE_BY
      , CREATE_DTTM
    )
    SELECT TO_SINGLE_BYTE(SYS_GUID())
         , P_USER_PREF_MST_ID
         , P_GRP_ID
         , 'DIMENSION_' || LPAD(TO_CHAR(ROW_NUMBER() OVER (ORDER BY SEQ)), 2, '0') AS FIELD_ID
         , DISP_NM          AS FIELD_NM
         , '100'            AS FIELD_WDTH
         , SEQ              AS SEQ
         , ACTV_YN          AS ACTV_YN
         , 'Y'              AS PSNZ_APPY_YN
         , ID               AS FIELD_VAL
         , 'GROUP-COLUMNS'  AS PIVOT_ITEM_CD
         , NULL             AS CATEGORY_GROUP
         , 'DIMENSION'      AS DIM_MEASURE_TP
         , 'N'              AS EDIT_MEASURE
         , CASE WHEN COL_NM = '_COMMENT' THEN ACTV_YN ELSE 'N' END      AS EDIT_TARGET
         , 'N'              AS DATA_KEY_YN
         , CASE WHEN (P_UI_ID LIKE 'UI_DP_9%' or P_UI_ID LIKE 'UI_BP_9%') THEN ACTV_yN ELSE 'Y' END              AS CROSSTAB_YN
         , P_USER_ID        AS CREATE_BY
         , SYSDATE          AS CREATE_DTTM
      FROM TB_DP_DIM_SETTING
     WHERE 1=1
       AND GRP_ID = P_GRP_ID
       AND UI_ID = P_UI_ID
       AND GRID_ID = P_GRID_ID
       AND LV_MGMT_ID NOT IN (
            SELECT ID
              FROM TB_CM_LEVEL_MGMT
             WHERE 1=1
               AND ACCOUNT_LV_YN = 'Y'
               AND COALESCE(DEL_YN, 'N') = 'N'
               AND ACTV_YN = 'Y'
       )
    ;
    -- SALES_LEVEL + ACCOUNT
    INSERT INTO TB_AD_USER_PREF_DTL (
        ID
      , USER_PREF_MST_ID
      , GRP_ID
      , FLD_CD
      , FLD_APPLY_CD
      , FLD_WIDTH
      , FLD_SEQ
      , FLD_ACTIVE_YN
      , APPLY_YN
      , REFER_VALUE
      , CROSSTAB_ITEM_CD
      , CATEGORY_GROUP
      , DIM_MEASURE_TP
--    , SUMMARY_TP
--    , SUMMARY_YN
      , EDIT_MEASURE_YN
      , EDIT_TARGET_YN
      , DATA_KEY_YN
      , CROSSTAB_YN
      , CREATE_BY
      , CREATE_DTTM
    )
    SELECT TO_SINGLE_BYTE(SYS_GUID())
         , P_USER_PREF_MST_ID
         , P_GRP_ID
         , 'DIMENSION_' || LPAD(TO_CHAR(20 + ROW_NUMBER() OVER (ORDER BY SEQ)), 2, '0') AS FIELD_ID
         , DISP_NM          AS FIELD_NM
         , '100'            AS FIELD_WDTH
         , SEQ              AS SEQ
         , ACTV_YN          AS FLD_ACTIVE_YN
         , 'Y'              AS PSNZ_APPY_YN
         , ID               AS FIELD_VAL
         , 'GROUP-COLUMNS'  AS PIVOT_ITEM_CD
         , NULL             AS CATEGORY_GROUP
         , 'DIMENSION'      AS DIM_MEASURE_TP
         , 'N'              AS EDIT_MEASURE
         , 'N'              AS EDIT_TARGET
         , 'N'              AS DATA_KEY_YN
         , CASE WHEN (P_UI_ID LIKE 'UI_DP_9%' or P_UI_ID LIKE 'UI_BP_9%') THEN ACTV_yN ELSE 'Y' END AS CROSSTAB_YN
         , P_USER_ID        AS CREATE_BY
         , SYSDATE          AS CREATE_DTTM
      FROM TB_DP_DIM_SETTING
     WHERE 1=1
       AND GRP_ID = P_GRP_ID
       AND UI_ID = P_UI_ID
       AND GRID_ID = P_GRID_ID
       AND LV_MGMT_ID IN (
            SELECT ID
              FROM TB_CM_LEVEL_MGMT
             WHERE 1=1
               AND ACCOUNT_LV_YN = 'Y'
               AND COALESCE(DEL_YN, 'N') = 'N'
               AND ACTV_YN = 'Y'
       )
    ;
    -- FIELD_ID - CATEGORY / DATE
    UPDATE TB_AD_USER_PREF_DTL
       SET FLD_SEQ = (
        SELECT CASE WHEN FLD_CD = 'CATEGORY' THEN A.NEW_SEQ + 1
                    WHEN FLD_CD = 'DATE'     THEN A.NEW_SEQ + 2
                    WHEN FLD_CD = 'PERIOD'   THEN A.NEW_SEQ + 3
                    ELSE 0 END
          FROM (
            SELECT USER_PREF_MST_ID
                 , GRP_ID
                 , MAX(COALESCE(FLD_SEQ, 0)) AS NEW_SEQ
              FROM TB_AD_USER_PREF_DTL A
             WHERE A.USER_PREF_MST_ID = P_USER_PREF_MST_ID
               AND A.GRP_ID = P_GRP_ID
               AND A.DIM_MEASURE_TP != 'MEASURE'
             GROUP BY USER_PREF_MST_ID, GRP_ID
          ) A
       )
     WHERE USER_PREF_MST_ID = P_USER_PREF_MST_ID
       AND GRP_ID = P_GRP_ID
       AND FLD_CD IN ('CATEGORY', 'DATE', 'PERIOD')
      ;

    UPDATE TB_AD_USER_PREF_DTL
       SET FLD_CD = 'COMMENT'
         , DIM_MEASURE_TP = 'DEFAULT'
         , CROSSTAB_YN = 'Y'
		 , APPLY_YN = 'N'     
         , FLD_ACTIVE_YN = 'N'
         , CROSSTAB_ITEM_CD = 'GROUP-HORIZONTAL-VALUES'
     WHERE USER_PREF_MST_ID = P_USER_PREF_MST_ID
       AND GRP_ID = P_GRP_ID
       AND DIM_MEASURE_TP = 'DIMENSION'
       AND FLD_APPLY_CD = '_COMMENT'
    ; 

    DELETE 
      FROM TB_AD_USER_PREF
     WHERE USER_PREF_MST_ID = P_USER_PREF_MST_ID
       AND GRP_ID = P_GRP_ID
       ;

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001'; 

EXCEPTION WHEN OTHERS THEN  -- e_products_invalid    
    IF(SQLCODE = -20001)
    THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
    --SP_COMM_RAISE_ERR();              
        RAISE;
    END IF; 
END;
/

