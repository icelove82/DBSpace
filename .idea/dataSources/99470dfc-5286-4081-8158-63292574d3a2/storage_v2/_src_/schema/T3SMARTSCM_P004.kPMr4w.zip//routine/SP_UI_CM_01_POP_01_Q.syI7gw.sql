create PROCEDURE "SP_UI_CM_01_POP_01_Q" (
    P_CONF_KEY      IN VARCHAR2 := '' ,
    P_VIEW_ID       IN VARCHAR2 := '' ,
    P_MODULE_CD     IN VARCHAR2 := '' ,
    pResult OUT SYS_REFCURSOR
)
IS

BEGIN
    IF P_CONF_KEY ='001' /* Corporation*/
    THEN
        OPEN pResult FOR
          SELECT A.ID
                ,A.CORPOR_ID
                ,A.CORPOR_NM
                ,A.CREATE_BY
                ,A.CREATE_DTTM
                ,A.MODIFY_BY
                ,A.MODIFY_DTTM
                ,P_VIEW_ID	    AS VIEW_ID
           FROM TB_CM_CORPORATION A;
    
    ELSIF P_CONF_KEY ='002' /* Location Type & Level*/
    THEN
        OPEN pResult FOR
          SELECT  C.ID
                 ,B.ID          AS CORP_ID
                 ,B.CORPOR_ID
                 ,B.CORPOR_NM
                 ,C.MODULE_VAL
                 ,D.COMN_CD		AS LOCAT_TP
                 ,C.LOCAT_TP_ID AS LOCAT_TP_ID
                 ,D.COMN_CD_NM  AS LOCAT_TP_NM
                 ,C.LOCAT_LV_DESCRIP
                 ,C.LOCAT_LV
                 ,C.DMND_INTG_YN
                 ,C.INV_POLICY_TARGET_YN
                 ,C.ACTV_YN
                 ,C.CREATE_BY
                 ,C.CREATE_DTTM
                 ,C.MODIFY_BY
                 ,C.MODIFY_DTTM
                 ,P_VIEW_ID	AS VIEW_ID
            FROM  TB_CM_LOC_MST C
              INNER JOIN TB_CM_CORPORATION B
                ON B.ID = C.CORPOR_ID
              INNER JOIN TB_CM_CONFIGURATION A
                ON A.ID = C.CONF_ID
              INNER JOIN TB_AD_COMN_CODE D
                ON C.LOCAT_TP_ID = D.ID
	       ORDER BY D.SEQ, C.LOCAT_LV;
    
    ELSIF P_CONF_KEY ='006' /* Item Attributes */
    THEN
        OPEN pResult FOR
          SELECT  B.ID
                 ,B.ATTR_NM
                 ,B.CONVN_NM
                 ,B.ACTV_YN
                 ,B.CREATE_BY
                 ,B.CREATE_DTTM
                 ,B.MODIFY_BY
                 ,B.MODIFY_DTTM
                 ,P_VIEW_ID	AS VIEW_ID
            FROM TB_CM_CONFIGURATION A
                 INNER JOIN TB_CM_ITEM_ATTRIBUTE B
                 ON A.ID = B.CONF_ID
           ORDER BY  B.ATTR_NM;
    
    ELSIF P_CONF_KEY ='007' /* Item Hierarchy */
    THEN
        OPEN pResult FOR
          SELECT  C.ID
                 ,A.ID				AS ATTR_ID
                 ,D.ITEM_SCOPE_NM	AS ITEM_LV
                 ,A.ATTR_NM
                 ,A.CONVN_NM
                 ,C.HRCY_YN
                 ,(
                   SELECT  X.ID
                     FROM TB_CM_ITEM_ATTRIBUTE X
                    WHERE 1=1
                      AND X.ID = C.PARENT_ATTR_ID
                  )                 AS PARENT_ATTR_CONVN_NM
                 ,C.ROOT_LV_YN
                 ,C.ACTV_YN
                 ,C.CREATE_BY
                 ,C.CREATE_DTTM
                 ,C.MODIFY_BY
                 ,C.MODIFY_DTTM
                 ,P_VIEW_ID	AS VIEW_ID
            FROM TB_CM_ITEM_ATTRIBUTE A
                 LEFT OUTER JOIN TB_CM_ITEM_ATTRIBUTE_LEVEL C
                 ON A.ID = C.ATTR_ID
                 LEFT OUTER JOIN TB_CM_ITEM_SCOPE_MST D
                 ON C.ITEM_SCOPE_MST_ID = D.ID;
    
    ELSIF P_CONF_KEY ='008' /*  UOM */
    THEN
        OPEN pResult FOR
          SELECT  B.ID
                 ,B.UOM_CD
                 ,B.UOM_NM
                 ,B.ACTV_YN
                 ,B.BASE_PLAN_UOM_YN
                 ,B.BASE_WEIGHT_UOM_YN
                 ,B.TIME_BUCKET_YN
                 ,B.ACTUAL_REF_YN
                 ,B.TIME_UOM_YN
                 ,B.CREATE_BY
                 ,B.CREATE_DTTM
                 ,B.MODIFY_BY
                 ,B.MODIFY_DTTM
                 ,P_VIEW_ID AS VIEW_ID
            FROM  TB_CM_CONFIGURATION A
              INNER JOIN TB_CM_UOM B
                ON A.ID = B.CONF_ID
            ORDER BY TIME_UOM_YN DESC;
    
    ELSIF P_CONF_KEY ='009' /* Packing Type */
    THEN
        OPEN pResult FOR
             SELECT   A.ID
                     ,A.PACKING_CD		AS PACKING_TP
                     ,A.ACTV_YN
                     ,A.BASE_PACKING_YN
                     ,A.WEIGHT
                     ,A.UOM_ID			AS UOM_CD
                     ,B.UOM_NM
                     ,A.CREATE_BY
                     ,A.CREATE_DTTM
                     ,A.MODIFY_BY
                     ,A.MODIFY_DTTM
                     ,P_VIEW_ID         AS VIEW_ID
                FROM TB_CM_PACKING A
                INNER JOIN TB_CM_UOM B
                  ON A.UOM_ID = B.ID
               ORDER by A.PACKING_CD;
    
    ELSIF P_CONF_KEY ='010' /* Pallet Type */
    THEN
        OPEN pResult FOR
          SELECT  B.ID
                 ,B.PALLET_CD
                 ,B.ACTV_YN
                 ,B.BASE_PALLET_YN
                 ,B.WEIGHT
                 ,B.UOM_ID			AS UOM_CD
                 ,C.UOM_NM
                 ,B.CREATE_BY
                 ,B.CREATE_DTTM
                 ,B.MODIFY_BY
                 ,B.MODIFY_DTTM
                 ,P_VIEW_ID AS VIEW_ID
            FROM  TB_CM_CONFIGURATION A
              INNER JOIN TB_CM_PALLET B
                ON A.ID = B.CONF_ID
              INNER JOIN TB_CM_UOM C
                ON B.UOM_ID = C.ID;
    
    ELSIF P_CONF_KEY ='014' /* Base Discrete Route */
    THEN
        OPEN pResult FOR
              SELECT  D.ID
                     ,C.ID			AS LOCAT_MST_ID
                     ,B.COMN_CD_NM	AS LOCAT_TP_NM
                     ,C.LOCAT_LV
                     ,D.USE_YN
                     ,D.ACTV_YN
                     ,D.CREATE_BY
                     ,D.CREATE_DTTM
                     ,D.MODIFY_BY
                     ,D.MODIFY_DTTM
                     ,P_VIEW_ID	AS VIEW_ID
                FROM  TB_AD_COMN_GRP A
                  INNER JOIN TB_AD_COMN_CODE B
                    ON A.ID = B.SRC_ID
                  INNER JOIN TB_CM_LOC_MST C
                    ON B.ID = C.LOCAT_TP_ID
                  LEFT OUTER JOIN TB_CM_BASE_ROUTE D
                    ON (C.ID = D.LOCAT_MST_ID)
                        AND D.ROUTE_CATAGY='DISCRETE'
               WHERE 1=1
                 AND A.GRP_CD = 'LOC_TP'
                 AND B.COMN_CD IN ('LOC_FERT','LOC_HALB');
    
    ELSIF P_CONF_KEY ='015' /* Base Divisible Route */
    THEN
        OPEN pResult FOR
            SELECT  D.ID
                     ,C.ID			AS LOCAT_MST_ID
                     ,B.COMN_CD_NM	AS LOCAT_TP_NM
                     ,C.LOCAT_LV
                     ,D.USE_YN
                     ,D.ACTV_YN
                     ,D.CREATE_BY
                     ,D.CREATE_DTTM
                     ,D.MODIFY_BY
                     ,D.MODIFY_DTTM
                FROM  TB_AD_COMN_GRP A
                     ,TB_AD_COMN_CODE B
                     ,TB_CM_LOC_MST C
                      LEFT OUTER JOIN
                      TB_CM_BASE_ROUTE D
                      ON C.ID = D.LOCAT_MST_ID
                      AND D.ROUTE_CATAGY='DIVISIBLE'
               WHERE 1=1
                 AND A.GRP_CD = 'LOC_TP'
                 AND A.ID = B.SRC_ID
                 AND B.COMN_CD IN ('LOC_FERT','LOC_HALB')
                 AND B.ID = C.LOCAT_TP_ID;
    
    ELSIF P_CONF_KEY ='024' /* Base Order Due Date Fence */
    THEN
        OPEN pResult FOR
          SELECT  B.ID
                 ,B.CATAGY_CD
                 ,B.CATAGY_VAL		AS	DUE_DATE_FNC
                 ,(SELECT C.ID FROM TB_CM_UOM C WHERE B.UOM_ID = C.ID) AS TIME_UOM_CD
                 ,B.ACTV_YN
                 ,B.CREATE_BY
                 ,B.CREATE_DTTM
                 ,B.MODIFY_BY
                 ,B.MODIFY_DTTM
                 ,P_VIEW_ID	AS VIEW_ID
            FROM  TB_CM_CONFIGURATION A
              INNER JOIN TB_CM_BASE_ORDER B
                ON A.ID = B.CONF_ID
           WHERE 1=1
             AND B.CATAGY_CD = 'BASE_ORDER_DUE_DATE_FENCE';
    
    ELSIF P_CONF_KEY ='025' /* Base Order Delay Lead Time */
    THEN
        OPEN pResult FOR
          SELECT  B.ID
                 ,B.CATAGY_CD
                 ,B.CATAGY_VAL
                 ,C.UOM_CD
                 ,B.ACTV_YN
                 ,B.CREATE_BY
                 ,B.CREATE_DTTM
                 ,B.MODIFY_BY
                 ,B.MODIFY_DTTM
                 ,P_VIEW_ID	AS VIEW_ID
            FROM  TB_CM_CONFIGURATION A
            INNER JOIN TB_CM_BASE_ORDER B
              ON A.ID = B.CONF_ID
            INNER JOIN TB_CM_UOM C
              ON B.UOM_ID = C.ID
           WHERE 1=1
             AND B.CATAGY_CD='BASE_ORDER_DELAY_LT';
    
    ELSIF P_CONF_KEY ='026' /* Vehicle Type */
    THEN
        OPEN pResult FOR
          SELECT  B.ID
                 ,B.VEHICL_TP
                 ,B.PRIORT
                 ,B.VIRTUAL_VEHICL_YN
                 ,B.MIXLOAD_YN
                 ,B.ACTV_YN
                 ,B.CREATE_BY
                 ,B.CREATE_DTTM
                 ,B.MODIFY_BY
                 ,B.MODIFY_DTTM
                 ,P_VIEW_ID	AS VIEW_ID
            FROM  TB_CM_CONFIGURATION A
              INNER JOIN TB_CM_VEHICLE B
                ON A.ID = B.CONF_ID;
    
    ELSIF P_CONF_KEY ='027' /* Resource Group */
    THEN
        OPEN pResult FOR
          SELECT  B.ID
                 ,B.RES_GRP_CD			AS RES_GRP_CD
                 ,B.DESCRIP				AS RES_GRP_DESCRIP
                 ,B.RES_GRP_TP_ID		AS RES_GRP_TP
                 ,B.ACTV_YN
                 ,B.CREATE_BY
                 ,B.CREATE_DTTM
                 ,B.MODIFY_BY
                 ,B.MODIFY_DTTM
                 ,P_VIEW_ID	AS VIEW_ID
            FROM  TB_CM_CONFIGURATION A
            INNER JOIN TB_CM_RES_GROUP B
              ON A.ID = B.CONF_ID
            INNER JOIN TB_AD_COMN_CODE D
              ON B.RES_GRP_TP_ID = D.ID;
    
    ELSIF P_CONF_KEY ='028' /* Lot Size Group */
    THEN
        OPEN pResult FOR
          SELECT  D.ID
                 ,C.ID			AS LOCAT_TP_NM
                 ,C.LOCAT_LV
                 ,D.CATAGY_GRP
                 ,D.UOM_ID		AS UOM_CD
                 ,F.UOM_NM
                 ,D.GRP_NO
                 ,D.LOTSIZE_CD
                 ,D.FROM_QTY
                 ,D.TO_QTY
                 ,D.EFFICY
                 ,D.ACTV_YN
                 ,D.CREATE_BY
                 ,D.CREATE_DTTM
                 ,D.MODIFY_BY
                 ,D.MODIFY_DTTM
                 ,P_VIEW_ID	AS VIEW_ID
            FROM  TB_AD_COMN_GRP A
              INNER JOIN TB_AD_COMN_CODE B
                ON A.ID = B.SRC_ID
              INNER JOIN TB_CM_LOC_MST C
                ON B.ID = C.LOCAT_TP_ID
              INNER JOIN TB_CM_LOT_SIZE_GROUP D
                ON C.ID = D.LOCAT_MST_ID
              INNER JOIN TB_CM_UOM F
                ON (D.UOM_ID = F.ID);
    
    ELSIF P_CONF_KEY ='032' /* BOD L/T Period */
    THEN
        OPEN pResult FOR
         SELECT A.ID					AS ID
             ,A.FROM_LOCAT_MST_ID		AS FROM_LOCAT_NM
             ,B.LOCAT_LV				AS FROM_LOCAT_LV
             ,A.TO_LOCAT_MST_ID			AS TO_LOCAT_NM
             ,D.LOCAT_LV				AS TO_LOCAT_LV
             ,A.VEHICL_TP_ID			AS VEHICL_TP
             ,A.BOD_LEADTIME_PERIOD		AS BOD_LEADTIME_PERIOD
             ,A.BOD_LEADTIME_SEQ		AS BOD_LEADTIME_SEQ
             ,A.LEADTIME_TP_ID			AS LEADTIME_TP_NM
             ,A.LEADTIME_MGMT_YN		AS LEADTIME_MGMT_YN
             ,A.TRANSFER_MGMT_YN		AS TRANSFER_MGMT_YN
             ,A.ACTV_YN					AS LT_ACTV_YN
             ,A.CREATE_BY				AS CREATE_BY
             ,A.CREATE_DTTM				AS CREATE_DTTM
             ,A.MODIFY_BY				AS MODIFY_BY
             ,A.MODIFY_DTTM				AS MODIFY_DTTM
             ,P_VIEW_ID				    AS VIEW_ID
            FROM TB_CM_BOD_LT A
            INNER JOIN TB_CM_LOC_MST B
              ON A.FROM_LOCAT_MST_ID = B.ID
            INNER JOIN TB_AD_COMN_CODE C
              ON B.LOCAT_TP_ID = C.ID
            INNER JOIN TB_CM_LOC_MST D
              ON A.TO_LOCAT_MST_ID = D.ID
            INNER JOIN TB_AD_COMN_CODE E
              ON D.LOCAT_TP_ID = E.ID
            INNER JOIN TB_CM_VEHICLE F
              ON A.VEHICL_TP_ID = F.ID
            INNER JOIN TB_AD_COMN_CODE G
              ON A.LEADTIME_TP_ID = G.ID
            ORDER BY C.SEQ, B.LOCAT_LV, E.SEQ, D.LOCAT_LV, F.PRIORT, A.BOD_LEADTIME_SEQ;
    
    ELSIF P_CONF_KEY ='033' /* Base Transportation Between Locations */
    THEN
        OPEN pResult FOR
            SELECT A.ID					AS ID
                  ,A.FROM_LOCAT_MST_ID		AS FROM_LOCAT_TP
                  ,C.LOCAT_LV				AS FROM_LOCAT_LV
                  ,A.TO_LOCAT_MST_ID		AS TO_LOCAT_TP
                  ,D.LOCAT_LV				AS TO_LOCAT_LV
                  ,A.VEHICL_TP_ID			AS VEHICL_TP
                  ,A.ACTV_YN				AS ACTV_YN
                  ,A.CREATE_BY				AS CREATE_BY
                  ,A.CREATE_DTTM			AS CREATE_DTTM
                  ,A.MODIFY_BY				AS MODIFY_BY
                  ,A.MODIFY_DTTM			AS MODIFY_DTTM
                  ,P_VIEW_ID				AS VIEW_ID
                FROM TB_CM_LOC_VEHICLE A
                INNER JOIN TB_CM_VEHICLE B
                  ON A.VEHICL_TP_ID = B.ID
                INNER JOIN TB_CM_LOC_MST C
                  ON A.FROM_LOCAT_MST_ID = C.ID
                INNER JOIN TB_CM_LOC_MST D
                  ON A.TO_LOCAT_MST_ID = D.ID;
    
    ELSIF P_CONF_KEY ='035' /* Base Material Constraint Type Change Period */
    THEN
        OPEN pResult FOR
          SELECT  B.ID
                 ,B.LIMIT_FNC_TIME
                 ,(SELECT C.ID FROM TB_CM_UOM C WHERE B.UOM_ID = C.ID)	AS TIME_UOM_NM
                 ,B.ACTV_YN
                 ,B.CREATE_BY
                 ,B.CREATE_DTTM
                 ,B.MODIFY_BY
                 ,B.MODIFY_DTTM
                 ,P_VIEW_ID	AS VIEW_ID
            FROM  TB_CM_CONFIGURATION A
            INNER JOIN TB_CM_MAT_CONST_CHG_PERIOD B
              ON A.ID = B.CONF_ID
            INNER JOIN TB_CM_UOM C
              ON B.UOM_ID = C.ID ;
    
    ELSIF P_CONF_KEY ='037' /* Product Actual Reference Period */
    THEN
        OPEN pResult FOR
              SELECT  E.ID
                     ,D.ID				AS LOCAT_ID
                     ,B.COMN_CD_NM		AS LOCAT_TP_NM
                     ,C.LOCAT_LV
                     ,D.LOCAT_CD
                     ,D.LOCAT_NM
                     ,E.ACTUAL_PERIOD	AS PRDUCT_ACTUAL_PERIOD
                     ,(SELECT B.ID FROM TB_CM_UOM B WHERE E.UOM_ID = B.ID)	AS TIME_UOM_NM
                     ,E.ACTV_YN
                     ,E.CREATE_BY
                     ,E.CREATE_DTTM
                     ,E.MODIFY_BY
                     ,E.MODIFY_DTTM
                     ,P_VIEW_ID	        AS VIEW_ID
                FROM  TB_AD_COMN_GRP A
                INNER JOIN TB_AD_COMN_CODE B
                  ON A.ID = B.SRC_ID
                INNER JOIN TB_CM_LOC_MST C
                  ON B.ID = C.LOCAT_TP_ID
                INNER JOIN TB_CM_LOC_DTL D
                  ON C.ID = D.LOCAT_MST_ID
                LEFT OUTER JOIN TB_CM_ACTUAL_PERIOD E
                  ON D.ID = E.LOCAT_ID
               WHERE 1=1
                 AND A.GRP_CD = 'LOC_TP'
                 AND E.ACTUAL_TP='MFG';
    
    ELSIF P_CONF_KEY ='038' /* Channel Type Type */
    THEN
        OPEN pResult FOR
          SELECT  ID
               ,CHANNEL_ID
               ,CHANNEL_NM
               ,VMI_YN
               ,ACTV_YN
               ,CREATE_BY
               ,CREATE_DTTM
               ,MODIFY_BY
               ,MODIFY_DTTM
               ,P_VIEW_ID	AS VIEW_ID
            FROM  TB_CM_CHANNEL_TYPE;
    
    ELSIF P_CONF_KEY ='040' /* Material Purchase Actual Reference Period */
    THEN
        OPEN pResult FOR
              SELECT  E.ID
                     ,D.ID				AS LOCAT_ID
                     ,B.COMN_CD_NM		AS LOCAT_TP_NM
                     ,C.LOCAT_LV
                     ,D.LOCAT_CD
                     ,D.LOCAT_NM
                     ,E.ACTUAL_PERIOD
                     ,(SELECT B.ID FROM TB_CM_UOM B WHERE E.UOM_ID = B.ID)	AS TIME_UOM_CD
                     ,E.ACTV_YN
                     ,E.CREATE_BY
                     ,E.CREATE_DTTM
                     ,E.MODIFY_BY
                     ,E.MODIFY_DTTM
                     ,P_VIEW_ID	AS VIEW_ID
                FROM  TB_AD_COMN_GRP A
                  INNER JOIN TB_AD_COMN_CODE B
                    ON A.ID = B.SRC_ID
                  INNER JOIN TB_CM_LOC_MST C
                    ON B.ID = C.LOCAT_TP_ID
                  INNER JOIN TB_CM_LOC_DTL D
                    ON C.ID = D.LOCAT_MST_ID
                  LEFT OUTER JOIN TB_CM_ACTUAL_PERIOD E
                    ON D.ID = E.LOCAT_ID
               WHERE 1=1
                 AND A.GRP_CD = 'LOC_TP'
                 AND E.ACTUAL_TP='MATERIAL'	;
    
    ELSIF P_CONF_KEY ='042' /* Item Type */
    THEN
        OPEN pResult FOR
           SELECT B.ID
                 ,B.ITEM_TP
                 ,B.CONVN_NM
                 ,E.ID			AS ITEM_TP_CD
                 ,B.ACTV_YN
                 ,B.CREATE_BY
                 ,B.CREATE_DTTM
                 ,B.MODIFY_BY
                 ,B.MODIFY_DTTM
                 ,P_VIEW_ID	AS VIEW_ID
            FROM
                 TB_CM_ITEM_TYPE B
              INNER JOIN TB_AD_COMN_CODE E
                ON B.ITEM_TP_CD_ID = E.ID;
    
    ELSIF P_CONF_KEY ='043' /* Production Type */
    THEN
        OPEN pResult FOR
          SELECT  A.ID
                 ,A.PRDUCT_TP
                 ,A.PRDUCT_TP_CD_ID AS PRDUCT_TP_DESC
                 ,A.ACTV_YN
                 ,A.CREATE_BY
                 ,A.CREATE_DTTM
                 ,A.MODIFY_BY
                 ,A.MODIFY_DTTM
                 ,P_VIEW_ID	AS VIEW_ID
            FROM TB_CM_PRODUCTION_TYPE A
              INNER JOIN TB_AD_COMN_CODE B
                ON A.PRDUCT_TP_CD_ID = B.ID;
    
    ELSIF P_CONF_KEY ='045' /* Incoterms */
    THEN
        OPEN pResult FOR
          SELECT  ID
                 ,INCOTERMS
                 ,CUST_DELIVY_MODELING_YN
                 ,ACTV_YN
                 ,CREATE_BY
                 ,CREATE_DTTM
                 ,MODIFY_BY
                 ,MODIFY_DTTM
                 ,P_VIEW_ID	AS VIEW_ID
            FROM  TB_CM_INCOTERMS B;
    
    ELSIF P_CONF_KEY ='046' /* Item Level */
    THEN
        OPEN pResult FOR
          SELECT     A.ID
                    ,A.ITEM_SCOPE_MST_ID
                    ,A.LOCAT_MST_ID
                    ,C.LOCAT_LV
                    ,A.ACTV_YN
                    ,A.CREATE_BY
                    ,A.CREATE_DTTM
                    ,A.MODIFY_BY
                    ,A.MODIFY_DTTM
                    ,P_VIEW_ID	AS VIEW_ID
                FROM TB_CM_ITEM_SCOPE_DTL A
                  INNER JOIN TB_CM_ITEM_SCOPE_MST B
                    ON A.ITEM_SCOPE_MST_ID = B.ID
                  INNER JOIN TB_CM_LOC_MST C
                    ON A.LOCAT_MST_ID = C.ID;
    
    ELSIF P_CONF_KEY ='047' /* Warehouse Type */
    THEN
        OPEN pResult FOR
            SELECT ID
                  ,WAREHOUSE_TP
                  ,WAREHOUSE_TP_NM
                  ,LOAD_CAPA_MGMT_BASE
                  ,ACTV_YN
                  ,CREATE_BY
                  ,CREATE_DTTM
                  ,MODIFY_BY
                  ,MODIFY_DTTM
                  ,P_VIEW_ID	AS VIEW_ID
                FROM TB_CM_WAREHOUSE_TYPE;
    
    ELSIF P_CONF_KEY ='051' /* Target Service Level Simulation Scale Range */
    THEN
        OPEN pResult FOR
          SELECT  B.ID
                 ,B.SIMUL_SCALE_RANGE
                 ,B.ACTV_YN
                 ,B.CREATE_BY
                 ,B.CREATE_DTTM
                 ,B.MODIFY_BY
                 ,B.MODIFY_DTTM
                 ,P_VIEW_ID	AS VIEW_ID
            FROM  TB_CM_CONFIGURATION A
              INNER JOIN TB_CM_SL_SIMUL_SCALE_RANGE B
                ON A.ID = B.CONF_ID;
    
    ELSIF (P_MODULE_CD = 'DP' AND P_CONF_KEY <>'120') OR P_MODULE_CD = 'SRP' /* DP 101~119 */
    THEN
        OPEN pResult FOR
          SELECT  B.ID
                 ,B.CONF_CD
                 ,B.CONF_NM
                 ,B.DESCRIP
                 ,B.PRIORT
                 ,B.ATTR_01		AS VAL
                 ,B.ACTV_YN
                 ,B.DEFAT_VAL
                 ,B.CREATE_BY
                 ,B.CREATE_DTTM
                 ,B.MODIFY_BY
                 ,B.MODIFY_DTTM
            FROM  TB_CM_CONFIGURATION A
              INNER JOIN TB_CM_COMM_CONFIG B
                ON A.ID = B.CONF_ID
           WHERE 1=1
             AND A.MODULE_CD = P_MODULE_CD
             AND A.CONF_KEY = P_CONF_KEY;
    
    ELSE
        OPEN pResult FOR
          SELECT  B.ID
                 ,B.CONF_CD
                 ,B.CONF_NM
                 ,B.DESCRIP
                 ,B.DEFAT_VAL
                 ,B.PRIORT
                 ,B.ATTR_01
                 ,B.ACTV_YN
                 ,B.CREATE_BY
                 ,B.CREATE_DTTM
                 ,B.MODIFY_BY
                 ,B.MODIFY_DTTM
                 ,P_VIEW_ID	        AS VIEW_ID
            FROM  TB_CM_CONFIGURATION A
              INNER JOIN TB_CM_COMM_CONFIG B
                ON A.ID = B.CONF_ID
           WHERE A.CONF_KEY = P_CONF_KEY
             AND A.MODULE_CD IN ('CM','IM','MP')
           ORDER BY B.PRIORT, B.CONF_NM;

    END IF;

END;

/

