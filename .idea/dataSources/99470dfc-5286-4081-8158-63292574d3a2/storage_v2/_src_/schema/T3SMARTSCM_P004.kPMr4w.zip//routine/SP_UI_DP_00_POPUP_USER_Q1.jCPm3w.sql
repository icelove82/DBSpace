create PROCEDURE                 "SP_UI_DP_00_POPUP_USER_Q1" (
    p_EMP_NO    IN VARCHAR2 := ''
  , p_EMP_NM    IN VARCHAR2 := ''
  , p_USER_ID   IN VARCHAR2 :=''
  , pRESULT     OUT SYS_REFCURSOR
)
IS 
/************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 
    - 2021.06.10 / 源��슜�닔 / TB_CM_COMM_CONFIG�쓽 CONF_GRP_CD = 'DP_ADMIN_ID' �뿉 �벑濡앸맂 �궗�슜�옄�뒗 �엫吏곸썝 議고쉶 媛��뒫 �븯�룄濡� 泥섎━
    - 2021.09.23 / 諛뺤삦二� / �궗踰� 蹂�寃쎌뿉 �뵲�씪 議곌굔異붽� ENABLED = 'Y' AND NVL(ETC,'A')<>'D' 
************************************************************************/
v_ADMIN_YN    VARCHAR2(1) := 'N';

BEGIN

    SELECT    CASE WHEN COUNT(*) >= 1 THEN 'Y' ELSE 'N' END ADMIN_CHK
      INTO    v_ADMIN_YN      
      FROM  
            (  
              SELECT    ADMIN_USER
                FROM 
                      (  
                        SELECT    ATTR_01  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_02  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_03 AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_04  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_05  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_06  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_07  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_08  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_09  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                        UNION ALL
                        SELECT    ATTR_10  AS ADMIN_USER
                          FROM    TB_CM_COMM_CONFIG
                         WHERE    CONF_GRP_CD = 'DP_ADMIN_ID'
                           AND    ACTV_YN     = 'Y'
                      )
            )    
     WHERE    ADMIN_USER IN ( p_USER_ID )
    ; 

    IF (p_USER_ID = 'administrator' OR p_USER_ID = 'LOGIN_ID_IGNORE_ALL_LOAD' OR p_USER_ID = 'admin' OR v_ADMIN_YN = 'Y')  -- 2021.03.09 源��슜�닔 : admin 異붽�
      THEN
        OPEN pRESULT 
        FOR 
        SELECT DISTINCT	  
               US.ID
             , US.USERNAME AS EMP_NO
             , US.USERNAME AS USER_ID
             , US.DISPLAY_NAME AS EMP_NM 
             , US.DEPARTMENT AS DEPT_NM
          FROM TB_AD_USER US
         WHERE UPPER(US.USERNAME) LIKE '%' || UPPER(p_EMP_NO) || '%'            
           AND (COALESCE(UPPER(US.DISPLAY_NAME), '')  LIKE '%' || UPPER(p_EMP_NM) || '%' or p_emp_nm is null)
           AND US.ENABLED = 'Y' AND NVL(US.ETC,'A')<>'D' --2021.09.23 �궗踰뉾IG �씠�썑 異붽��맂 議곌굔
         ORDER BY US.USERNAME;
    ELSE
        OPEN pRESULT 
        FOR SELECT US.ID
                 , US.USERNAME AS EMP_NO
                 , US.USERNAME AS USER_ID
                 , US.DISPLAY_NAME AS EMP_NM
                 , US.DEPARTMENT AS DEPT_NM
              FROM TB_AD_USER US 
             WHERE ID IN (
                   SELECT DEL.USER_ID 
                     FROM TB_AD_DELEGATION DEL 
                    INNER JOIN TB_AD_USER U ON U.ID = DEL.DELEGATION_USER_ID
                    WHERE U.USERNAME = p_USER_ID 
                      AND (
                               (DEL.APPLY_START_DTTM <= SYSDATE AND DEL.APPLY_END_DTTM > SYSDATE)
                            OR (DEL.APPLY_START_DTTM IS NULL AND DEL.APPLY_END_DTTM > SYSDATE)
                            OR (DEL.APPLY_START_DTTM <= SYSDATE AND DEL.APPLY_END_DTTM IS NULL)
                            OR (DEL.APPLY_START_DTTM IS NULL AND DEL.APPLY_END_DTTM IS NULL)
                           )
                    UNION
                   SELECT p_USER_ID
                     FROM DUAL
                   )
               AND US.ENABLED = 'Y' AND NVL(US.ETC,'A')<>'D' --2021.09.23 �궗踰뉾IG �씠�썑 異붽��맂 議곌굔    
               AND UPPER(US.USERNAME) LIKE '%' || UPPER(p_EMP_NO) || '%'            
               AND COALESCE(UPPER(US.DISPLAY_NAME), '') LIKE '%' || UPPER(p_EMP_NM) || '%'
        ORDER BY US.USERNAME;
    END IF;
 END;

/

