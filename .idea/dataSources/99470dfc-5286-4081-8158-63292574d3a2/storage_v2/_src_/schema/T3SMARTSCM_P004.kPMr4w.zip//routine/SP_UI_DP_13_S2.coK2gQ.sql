create PROCEDURE "SP_UI_DP_13_S2" (
    p_EMP_NO              IN  VARCHAR2      := ''   
  , p_AUTH_TP_ID          IN  VARCHAR2      := ''
  , p_LV_CD               IN  VARCHAR2      := NULL  
  , p_ITEM_CD             IN  VARCHAR2      := NULL  
  , p_ACTV_YN             IN  CHAR          := ''   
  , p_USER_ID             IN  VARCHAR2      := ''										
  , p_RT_ROLLBACK_FLAG    OUT VARCHAR2
  , p_RT_MSG              OUT VARCHAR2
) 
/*************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 
    - 2020.03.12 / Kim sohee / MSSQL Converting     
************************************************************************/                                   
IS
		-- Paremeter ？？？ 
    P_ERR_STATUS    INT               := 0;
    P_ERR_MSG       VARCHAR2(4000)    :='';
    V_EMP_ID        VARCHAR2(32)      := NULL ; 
    V_ITEM_YN	    CHAR(1);
    V_ITEM_ID       VARCHAR2(32)      := NULL ;   
    V_LV_MGMT_ID    VARCHAR2(32)      := NULL ;
    V_ITEM_LV_ID    VARCHAR2(32)      := NULL ;

BEGIN
				--AUTH TP Setting
    IF (p_AUTH_TP_ID IS NULL) 
    THEN	
        P_RT_ROLLBACK_FLAG := 'false';
        P_ERR_MSG := 'MSG_5044';				
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); 
    END IF;
    -- EMP_ID Setting 

    SELECT ID INTO V_EMP_ID 
      FROM TB_AD_USER
     WHERE USERNAME = P_EMP_NO;	
    -- LV_CD => LV_MGMT_ID
    SELECT ID
         , LEAF_YN INTO v_LV_MGMT_ID, V_ITEM_YN
      FROM TB_CM_LEVEL_MGMT
     WHERE LV_CD = p_LV_CD;

    IF(V_ITEM_YN = 'Y')
    THEN
        SELECT ID INTO V_ITEM_ID
          FROM TB_CM_ITEM_MST
         WHERE ITEM_CD = P_ITEM_CD                
         ;
    ELSE                
        SELECT ID, ID INTO V_ITEM_ID, V_ITEM_LV_ID
          FROM TB_CM_ITEM_LEVEL_MGMT
         WHERE ITEM_LV_CD = P_ITEM_CD
           AND LV_MGMT_ID = V_LV_MGMT_ID
           ;
    END IF;

              -- Validation
    IF (V_LV_MGMT_ID IS NULL) THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_ERR_MSG := 'MSG_5029';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

    IF (V_ITEM_ID IS NULL) THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_ERR_MSG := 'MSG_0017';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;
    -- 중복													
    SELECT COUNT(*) INTO P_ERR_STATUS
      FROM TB_DP_USER_ITEM_MAP
     WHERE 1=1
       AND CASE V_ITEM_YN WHEN 'Y' THEN ITEM_MST_ID ELSE ITEM_LV_ID END = V_ITEM_ID
       AND EMP_ID = V_EMP_ID
       AND ACTV_YN = p_ACTV_YN -- 유일 수정 값인 활성화 여부로 INSERT와 UPDATE 구분
       ;
    IF ( P_ERR_STATUS != 0 )
    THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_ERR_MSG := 'MSG_0013';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;


    MERGE INTO TB_DP_USER_ITEM_MAP TGT
    USING ( 
    		SELECT  TO_SINGLE_BYTE(SYS_GUID())                  AS  ID 
    			   ,V_EMP_ID                                    AS  EMP_ID
    			   ,P_AUTH_TP_ID		                        AS  AUTH_TP_ID
    			   ,V_LV_MGMT_ID                                AS  LV_MGMT_ID
                   ,CASE V_ITEM_YN WHEN 'N' THEN V_ITEM_ID END  AS  ITEM_LV_ID
                   ,CASE V_ITEM_YN WHEN 'Y' THEN V_ITEM_ID END  AS  ITEM_MST_ID
    			   ,p_ACTV_YN                                   AS  ACTV_YN
    			   ,p_USER_ID                                   AS  USER_ID
    	      FROM  dual
    	   ) SRC
    ON (TGT.EMP_ID = SRC.EMP_ID
    AND TGT.AUTH_TP_ID = SRC.AUTH_TP_ID
    AND TGT.LV_MGMT_ID = SRC.LV_MGMT_ID
    AND COALESCE(TGT.ITEM_LV_ID,  '') = COALESCE(SRC.ITEM_LV_ID, '')
    AND COALESCE(TGT.ITEM_MST_ID, '') = COALESCE(SRC.ITEM_MST_ID, '')
    )
    WHEN MATCHED THEN
    	 UPDATE 
    	    SET  TGT.ACTV_YN     = SRC.ACTV_YN 
    			,TGT.MODIFY_BY   = SRC.USER_ID       
    			,TGT.MODIFY_DTTM = SYSDATE       
    WHEN NOT MATCHED THEN 
    	 INSERT (
    	            ID
    			  , EMP_ID
    			  , AUTH_TP_ID
    			  , LV_MGMT_ID
    			  , ITEM_LV_ID
    			  , ITEM_MST_ID
    			  , ACTV_YN
    			  , CREATE_BY
    			  , CREATE_DTTM
    			) 
    	 VALUES (
    	            SRC.ID 
    			  , SRC.EMP_ID
    			  , SRC.AUTH_TP_ID
    			  , SRC.LV_MGMT_ID
    			  , SRC.ITEM_LV_ID
    			  , SRC.ITEM_MST_ID
    			  , SRC.ACTV_YN
    			  , SRC.USER_ID 
    			  , SYSDATE       
    			) 
    ;

    SP_UI_DPD_MAKE_HIER_USER;

    FOR CUR IN (
        SELECT VER_ID
          FROM (
            SELECT M.ID AS VER_ID
                 , DENSE_RANK() OVER (PARTITION BY M.PLAN_TP_ID ORDER BY M.CREATE_DTTM DESC) AS RW
              FROM TB_DP_CONTROL_BOARD_VER_MST M
             INNER JOIN TB_DP_CONTROL_BOARD_VER_DTL D
                ON M.ID = D.CONBD_VER_MST_ID
             INNER JOIN TB_CM_COMM_CONFIG W
                ON W.ID = D.WORK_TP_ID
               AND W.CONF_CD = 'CL'
             INNER JOIN TB_CM_COMM_CONFIG C
                ON D.CL_STATUS_ID = C.ID
               AND C.CONF_CD != 'CLOSE'
             WHERE EXISTS (SELECT DISTINCT VER_ID FROM TB_DP_ENTRY WHERE VER_ID = M.ID)
          ) A
         WHERE RW = 1
    ) 
    LOOP
        IF V_ITEM_YN = 'N' THEN
            V_ITEM_ID := NULL;
        END IF;
--        SP_UI_DP_93_ITEM_ACCT_CREATE(
--            V_ITEM_ID
--          , V_ITEM_LV_ID
--          , NULL
--          , NULL
--          , P_USER_ID
--          , P_AUTH_TP_ID
--          , CUR.VER_ID
--        );
    END LOOP;

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';  --？？？？ ？？？？？？？？.
       /* ？？？？ o？？ ============================================================================*/

EXCEPTION WHEN OTHERS THEN  -- ？？？ ？？？？？？？ ？？？？ ？？？？ ？？？？ : e_products_invalid
    IF(SQLCODE = -20001)
    THEN
        P_ERR_MSG := SQLERRM;
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
    ELSE
    --SP_COMM_RAISE_ERR();
        RAISE;
    END IF;
END;
/

