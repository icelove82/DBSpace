create PROCEDURE "SP_UI_CM_18_Q1" (
    p_ITEM_TREE     IN VARCHAR2 := '',
    p_ITEM_TP_ID    IN CHAR := '',
    p_ITEM_CD       IN VARCHAR2 := '',
    p_ITEM_NM       IN VARCHAR2 := '',
    p_DEL_YN        IN VARCHAR2 := '',
    p_DP_PLAN_YN    IN VARCHAR2 := '',
    pRESULT         OUT SYS_REFCURSOR
)
IS
BEGIN
      OPEN pRESULT FOR
      SELECT  A.ID 
            , A.ITEM_CD 
            , A.ITEM_NM
            , A.ITEM_TP_ID
            , A.MIN_ORDER_SIZE
            , A.MAX_ORDER_SIZE
            , A.EOS  AS EOS      
            , A.RTS  AS RTS  
            , A.UOM_ID
            , C.UOM_NM
            , A.DESCRIP
            , A.DP_PLAN_YN
            , A.DEL_YN
            , A.PARENT_ITEM_LV_ID 
            , D.ITEM_LV_CD   AS PARENT_ITEM_LV_CD
            , D.ITEM_LV_NM   AS PARENT_ITEM_LV_NM
            , A.ATTR_01
            , A.ATTR_02
            , A.ATTR_03
            , A.ATTR_04
            , A.ATTR_05
            , A.ATTR_06
            , A.ATTR_07
            , A.ATTR_08
            , A.ATTR_09
            , A.ATTR_10
            , A.ATTR_11
            , A.ATTR_12
            , A.ATTR_13
            , A.ATTR_14
            , A.ATTR_15
            , A.ATTR_16
            , A.ATTR_17
            , A.ATTR_18
            , A.ATTR_19
            , A.ATTR_20
            , A.DISPLAY_COLOR
            , A.CREATE_BY
            , A.CREATE_DTTM
            , A.MODIFY_BY
            , A.MODIFY_DTTM
      FROM    TB_CM_ITEM_MST A 
              LEFT OUTER JOIN  TB_CM_UOM C             ON A.UOM_ID = C.ID	 AND  C.ACTV_YN = 'Y'	
              LEFT OUTER JOIN  TB_CM_ITEM_LEVEL_MGMT D ON A.PARENT_ITEM_LV_ID = D.ID  AND  D.ACTV_YN = 'Y'
     WHERE (A.PARENT_ITEM_LV_ID LIKE '%'|| p_ITEM_TREE ||'%'	OR p_ITEM_TREE IS NULL)
       AND (A.ITEM_TP_ID LIKE '%'|| P_ITEM_TP_ID ||'%'  OR P_ITEM_TP_ID IS NULL)
       AND  NVL(A.DEL_YN, 'N') LIKE '%' || RTRIM(p_DEL_YN) || '%'
       AND  NVL(A.DP_PLAN_YN, 'N') LIKE '%' || RTRIM(p_DP_PLAN_YN) || '%'
       AND  (  REGEXP_LIKE (UPPER(A.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\['))
                OR 
               p_ITEM_CD IS NULL
            )
       AND  (  REGEXP_LIKE (UPPER(A.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                OR                 
               p_ITEM_NM IS NULL
            )
    ORDER BY D.SEQ, D.ITEM_LV_CD,  A.ITEM_CD;

END;

/

