create PROCEDURE "SP_UI_DP_00_ITEM_LV_DATA_Q1" (
    p_LEAF_TP     IN VARCHAR2 := '' -- LEAF
  , p_TYPE        IN VARCHAR2 := ''
  , pRESULT       OUT SYS_REFCURSOR
) IS 
    v_LEAF_TP char(1);
BEGIN
    IF (p_LEAF_TP = 'LEAF')   THEN
        v_LEAF_TP := 'Y' ;
    END IF;
/*
    USED UI : DP_09
*/
    OPEN pRESULT         
    FOR 
    SELECT * 
      FROM (
        SELECT ''               AS ID 
             , UPPER(P_TYPE)    AS CD
             , UPPER(P_TYPE)    AS CD_NM
             , 0                AS LV_SEQ
             , 0                AS SEQ
          FROM dual
         WHERE UPPER(P_TYPE) = 'ALL'
        UNION ALL 
        SELECT IL.ID         AS ID
             , IL.ITEM_LV_CD AS CD 
             , IL.ITEM_LV_NM AS CD_NM 
             , LM.SEQ        AS LV_SEQ
             , IL.SEQ        AS SEQ
          FROM TB_CM_CONFIGURATION A
             , TB_CM_COMM_CONFIG B
             , TB_CM_LEVEL_MGMT LM
             , TB_CM_ITEM_LEVEL_MGMT  IL
         WHERE A.MODULE_CD = 'DP'
           AND A.ID = B.CONF_ID
           AND B.CONF_GRP_CD = 'DP_LV_TP'
           AND B.CONF_CD = 'I'
           AND B.ID = LM.LV_TP_ID
           AND COALESCE(LM.DEL_YN, 'N') = 'N'
           AND LM.ACTV_YN = 'Y'
           AND LM.ID = IL.LV_MGMT_ID 
           AND LM.LV_LEAF_YN  LIKE '%' || v_LEAF_TP || '%'    
           AND COALESCE(IL.DEL_YN,'N') = 'N'
           AND IL.ACTV_YN = 'Y'
      ) A
     ORDER BY A.LV_SEQ, A.SEQ
    ;
END;

/

