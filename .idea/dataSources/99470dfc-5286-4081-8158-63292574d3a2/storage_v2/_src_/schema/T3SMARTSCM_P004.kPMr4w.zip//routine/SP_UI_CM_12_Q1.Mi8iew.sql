create PROCEDURE        "SP_UI_CM_12_Q1" (
    P_ITEM_CD           IN VARCHAR2:='' ,
    P_ITEM_NM	        IN VARCHAR2:='' ,
    P_ACCOUNT_CD	    IN VARCHAR2:='' ,
    P_ACCOUNT_NM	    IN VARCHAR2:='' ,
    P_LOCAT_TP			IN VARCHAR2:='' ,
    P_LOCAT_LV			IN VARCHAR2:='' ,
    P_LOCAT_CD			IN VARCHAR2:='' ,
    P_LOCAT_NM			IN VARCHAR2:='' ,
    P_RESULT            OUT SYS_REFCURSOR
)IS
    ACCOUNT_NM_TEMP VARCHAR2(100) := '';
BEGIN	
    SELECT 
        CASE 
            WHEN P_ACCOUNT_NM LIKE '%' ||'[CG]'||'%' 
            THEN SUBSTR(P_ACCOUNT_NM,1,LENGTH(P_ACCOUNT_NM)-4) 
            ELSE P_ACCOUNT_NM END 
        INTO ACCOUNT_NM_TEMP FROM DUAL;

	OPEN P_RESULT FOR
       SELECT   A.ID           AS DMND_SHPP_MGMT_MST_ID
               ,A.ITEM_MST_ID
               ,B.ITEM_CD
               ,B.ITEM_NM
               ,C.ITEM_TP
               ,C.CONVN_NM	   AS ITEM_TP_NM
               ,A.ACCOUNT_ID
               ,D.ACCOUNT_CD
               ,D.ACCOUNT_NM
               ,D.SHIP_TO
               ,D.SOLD_TO
               ,D.BILL_TO
               ,D.CHANNEL_NM
               ,D.VMI_YN
               ,D.INCOTERMS
               ,D.CUST_DELIVY_MODELING_YN
               ,E.LOCAT_TP_NM
               ,E.LOCAT_LV
               ,E.LOCAT_CD
               ,E.LOCAT_NM
               ,E.LOCAT_MGMT_ID
               ,A.ACTV_YN
               ,A.CREATE_BY
               ,A.CREATE_DTTM
               ,A.MODIFY_BY
               ,A.MODIFY_DTTM
          FROM TB_CM_DMND_SHPP_MAP_MST A
               INNER JOIN 
               TB_CM_ITEM_MST B 
            ON (A.ITEM_MST_ID = B.ID)
               LEFT OUTER JOIN 
               TB_CM_ITEM_TYPE C 
            ON (B.ITEM_TP_ID = C.ID)
               LEFT OUTER JOIN 
               (
                SELECT  A.ID AS ACCOUNT_ID
                       ,A.ACCOUNT_CD
                       ,A.ACCOUNT_NM
                       ,B.CUST_NM AS SHIP_TO
                       ,C.CUST_NM AS SOLD_TO
                       ,D.CUST_NM AS BILL_TO
                       ,E.CHANNEL_NM
                       ,A.VMI_YN
                       ,F.INCOTERMS
                       ,F.CUST_DELIVY_MODELING_YN
                  FROM TB_DP_ACCOUNT_MST A 
                       LEFT OUTER JOIN 
                       TB_CM_CUSTOMER B 
                    ON (A.SHIP_TO_ID = B.ID)
                       LEFT OUTER JOIN 
                       TB_CM_CUSTOMER C 
                    ON (A.SOLD_TO_ID = C.ID)
                       LEFT OUTER JOIN 
                       TB_CM_CUSTOMER D 
                    ON (A.BILL_TO_ID = D.ID)	       
                       LEFT OUTER JOIN 
                       TB_CM_CHANNEL_TYPE E
                    ON (A.CHANNEL_ID = E.ID)
                       LEFT OUTER JOIN 
                       TB_CM_INCOTERMS F
                    ON (A.INCOTERMS_ID = F.ID)	   
               ) D
            ON (A.ACCOUNT_ID = D.ACCOUNT_ID)
               LEFT OUTER JOIN 
               (
                SELECT  A.COMN_CD_NM AS LOCAT_TP_NM
                       ,B.LOCAT_LV
                       ,C.LOCAT_CD
                       ,C.LOCAT_NM
                       ,D.ID AS LOCAT_MGMT_ID
                       ,D.ACTV_YN
                       ,A.SEQ
                  FROM TB_AD_COMN_CODE A 
                       INNER JOIN 
                       TB_CM_LOC_MST B
                    ON (A.ID = B.LOCAT_TP_ID)
                       INNER JOIN 
                       TB_CM_LOC_DTL C 
                    ON (B.ID = C.LOCAT_MST_ID)
                       INNER JOIN 
                        TB_CM_LOC_MGMT D
                    ON (C.ID = D.LOCAT_ID)
                 WHERE 1=1
                   AND B.ACTV_YN = 'Y'
                   AND C.ACTV_YN = 'Y'
                   AND D.ACTV_YN = 'Y'	   
               ) E
            ON (A.LOCAT_MGMT_ID = E.LOCAT_MGMT_ID)
         WHERE 1=1
            AND UPPER(NVL(B.ITEM_CD, ''))      LIKE '%' || UPPER(P_ITEM_CD) || '%'
            AND UPPER(NVL(B.ITEM_NM,''))       LIKE '%' || UPPER(P_ITEM_NM) || '%'
            AND UPPER(NVL(D.ACCOUNT_CD,''))    LIKE '%' || UPPER(P_ACCOUNT_CD) || '%'
            AND UPPER(NVL(D.ACCOUNT_NM,''))    LIKE '%' || UPPER(ACCOUNT_NM_TEMP) || '%'
            AND UPPER(NVL(E.LOCAT_TP_NM, ''))	LIKE '%' || UPPER(P_LOCAT_TP) || '%'
            AND UPPER(NVL(E.LOCAT_LV, ''))		LIKE '%' || UPPER(P_LOCAT_LV) || '%'
            AND UPPER(NVL(E.LOCAT_CD, ''))		LIKE '%' || UPPER(P_LOCAT_CD) || '%'
            AND UPPER(NVL(E.LOCAT_NM, ''))		LIKE '%' || UPPER(P_LOCAT_NM) || '%'
        ORDER BY B.ITEM_CD
                ,D.ACCOUNT_CD
                ,E.SEQ
                ,E.LOCAT_LV
                ,E.LOCAT_CD;
END;

/

