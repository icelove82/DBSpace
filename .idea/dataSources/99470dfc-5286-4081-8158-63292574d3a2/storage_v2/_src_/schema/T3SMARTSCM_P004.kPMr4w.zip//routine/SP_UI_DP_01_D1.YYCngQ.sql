create PROCEDURE "SP_UI_DP_01_D1" (
									   p_ID				    IN VARCHAR2
									  ,P_USER_ID			IN VARCHAR2
									  ,P_GRP_CONF_NM		IN VARCHAR2
									  ,P_RT_ROLLBACK_FLAG   OUT VARCHAR2  
									  ,P_RT_MSG             OUT VARCHAR2 										  									
									        )IS
		 P_ERR_STATUS INT := 0;
         P_ERR_MSG VARCHAR2(4000) :='';
         v_CONF_GRP_CD VARCHAR2(50) := '';
BEGIN
         P_RT_ROLLBACK_FLAG := 'true';

		SELECT CONF_NM INTO v_CONF_GRP_CD
		FROM TB_CM_CONFIGURATION
		WHERE ID = p_ID;

        DELETE 
        FROM TB_AD_LANG_PACK
        WHERE 1=1
          AND LANG_CD = 'en'
          AND LANG_KEY = UPPER(v_CONF_GRP_CD)||'_DESCRIP'
          ;
		DELETE
		FROM TB_AD_LANG_PACK
		WHERE 1=1
		AND LANG_CD = 'en'
		AND LANG_KEY LIKE 'CF_'||v_CONF_GRP_CD||'%';

	   -- CONFIGURATION ROW 竊잞폕竊잞폕
		DELETE 
		FROM TB_CM_CONFIGURATION
		WHERE ID = P_ID;

		-- 竊잞폕竊잞폕 竊잞폕竊잞폕 竊잞폕竊잞폕		
		DELETE
		FROM TB_CM_COMM_CONFIG
		WHERE CONF_ID = P_ID;
	  -- 竊잞폕竊읦쏙폕竊잞폕 竊잞폕竊잞폕 




	     P_RT_ROLLBACK_FLAG := 'true';
	     P_RT_MSG := 'MSG_0002';
        EXCEPTION
        WHEN OTHERS THEN
              IF(SQLCODE = -20001)
              THEN
                  P_ERR_MSG := SQLERRM;
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;  
        END;

/

