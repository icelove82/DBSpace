create PROCEDURE                 "SP_UI_DP_SK_CNSS_NEW_VER_S" 
(
 P_ORG_VER_CD  VARCHAR2
,P_DP_VER_CD   VARCHAR2
,P_C_VER_CD    VARCHAR2 -- New Version ID
,P_DESCRIP     VARCHAR2
,P_USER_ID     VARCHAR2
,P_VER_TP      VARCHAR2 -- ORG, CUTOFF, CONSENSUS
,P_RT_ROLLBACK_FLAG  OUT VARCHAR2   
,P_RT_MSG            OUT VARCHAR2 
) IS

P_STRT_DATE     DATE;
P_END_DATE      DATE;
P_DP_VER_ID     CHAR(32);
P_PREV_VER_ID   CHAR(32);

P_ERR_STATUS INT := 0;
P_ERR_MSG VARCHAR2(4000) :='';     

BEGIN 
/************************************************************************************************
    Consensus Version Create

    History (date / writer / comment)
    - 2021.05.11 / Kimsohee / Draft
    - 2021.06.01 / 김용수 / 경영계획, 전R 연동계획, 현R RTF, BOH, 가용재고 데이터 셋팅 

    - Consensus Plan Measuer 필드
    . QTY : Consensus Forecast
    . QTY_1 : 현R RTF
    . QTY_2 : RTF Target
    . QTY_3 : MP return RTF 명칭 => Consensus Plan
    . QTY_4 : 차이(RTF Target - Consensus Forecast)
    . QTY_5 : 기초재고
    . QTY_6 : 가용재고
    . QTY_7 : 기말재고
    . QTY_8 : 전R 연동계획
    . QTY_9 : 경영계획
    . QTY_10 : 차이(Consensus Plan - Consensus Forecast)
    . QTY_11 : 기말재고를 계산하기 위한 기초재고 값
    . QTY_12 : CONSENSUS PLAN용 기초재고
    . QTY_13 : CONSENSUS PLAN용 가용재고

    - TB_DP_ENTRY의 필드 (현재 버전인 경우)
    . QTY   : 마케팅전략 권한은 현R Consensus Forecast, 마케팅담당자는 현R Sales Forecast
    . QTY_1 : 현R Customer Forecast
    . QTY_2 : 현R 연동계획
    . QTY_3 : 현R RTF

*************************************************************************************************/
  BEGIN
    SELECT     ID AS PREV_VER_ID
      INTO     P_PREV_VER_ID
      FROM 
            (  
              SELECT ID, VER_ID, ROW_NUMBER() OVER(PARTITION BY BASE_YM ORDER BY VER_ID DESC) R_NUM 
                FROM TB_DP_CONTROL_BOARD_VER_MST
               WHERE BASE_YM = (SELECT TO_CHAR(ADD_MONTHS(TO_DATE(BASE_YM,'YYYYMM'),-1),'YYYYMM') FROM TB_DP_CONTROL_BOARD_VER_MST WHERE VER_ID = P_DP_VER_CD)
            )
     WHERE    R_NUM = 1       
    ;

  EXCEPTION 
    WHEN OTHERS THEN
      P_PREV_VER_ID := NULL;
  END;

    SELECT TO_DATE(BASE_YM||'01','YYYYMMDD')          AS STRT_DATE     -- 시작일자를 기준년월의 1일자로 설정
          ,COALESCE(VER_S_HORIZON_DATE - 1,TO_DATE)   AS END_DATE      -- 1번째 버킷의 1일전 일자로 설정
          ,ID
      INTO P_STRT_DATE, P_END_DATE, P_DP_VER_ID
      FROM TB_DP_CONTROL_BOARD_VER_MST
     WHERE VER_ID = P_DP_VER_CD
     ;

    INSERT INTO TB_SDP_CONSENSUS_VER_MST
    (ID
    ,MAIN_VER_CD
    ,C_VER_CD
    ,DP_VER_CD    
    ,DESCRIP
    ,STATUS
    ,FROM_DATE
    ,TO_DATE
    ,BASE_YM
    ,CREATE_BY
    ,CREATE_DTTM
    )VALUES
    (TO_SINGLE_BYTE(SYS_GUID())
    ,P_ORG_VER_CD
    ,P_C_VER_CD
    ,P_DP_VER_CD
    ,P_DESCRIP
    ,'READY'
    ,P_STRT_DATE
    ,P_END_DATE
    ,SUBSTR(TO_CHAR(P_STRT_DATE,'YYYYMMDD'),1,6)   -- 기준년월은 시작일자의 월
    ,P_USER_ID
    ,SYSDATE
    )
    ;

-- DP Entry / Cutoff / Consensus     
    IF P_VER_TP = 'MAIN'
        THEN
            INSERT INTO TEMP_DP_RT
            (
                ITEM_MST_ID
               ,ACCOUNT_ID
               ,BASE_DATE
               ,QTY             -- Consensus Forecast
               ,QTY_1           -- 현R RTF
               ,QTY_2           -- RTF Target : 최초는 현R RTF값을 그대로 사용
               ,QTY_4           -- 차이(RTF Target - Consensus Forecast)
            )                
            SELECT  ITEM_MST_ID
                   ,ACCOUNT_ID
                   ,BASE_DATE
                   ,QTY
                   ,QTY_3       -- 현R RTF
                   ,QTY_3       -- 현R RTF
                   ,NVL(QTY_3,0) - NVL(QTY,0) 
              FROM TB_DP_ENTRY
             WHERE VER_ID = P_DP_VER_ID
               AND BASE_DATE BETWEEN P_STRT_DATE AND P_END_DATE
               AND AUTH_TP_ID = (SELECT ID FROM TB_CM_LEVEL_MGMT WHERE LV_CD = 'SCM') -- SCM : 마케팅전략
             ;    

        -- 경영계획 반영
        MERGE INTO TEMP_DP_RT T
        USING
        (
        SELECT    A.ITEM_MST_ID, A.ACCOUNT_ID, B.BASE_DATE, B.BUSINESS_PLAN_QTY MGMT_QTY, B.BUSINESS_PLAN_AMT MGMT_AMT 
          FROM    TB_DP_ENTRY A
          JOIN    TB_DP_MEASURE_DATA B ON B.ACCOUNT_ID = A.ACCOUNT_ID AND B.ITEM_MST_ID = A.ITEM_MST_ID AND  B.BASE_DATE = A.BASE_DATE
         WHERE    A.VER_ID = P_DP_VER_ID
           AND    A.AUTH_TP_ID = (SELECT ID FROM TB_CM_LEVEL_MGMT WHERE LV_CD = 'SALESMAN') 
        ) S
        ON (
            T.ITEM_MST_ID = S.ITEM_MST_ID
        AND T.ACCOUNT_ID  = S.ACCOUNT_ID
        AND T.BASE_DATE   = S.BASE_DATE
        )
        WHEN MATCHED THEN
            UPDATE
               SET
                    T.QTY_9 = S.MGMT_QTY  -- 수량(경영계획)
        ; 

        -- 전R 연동계획 반영
        MERGE INTO TEMP_DP_RT T
        USING
        (
        SELECT    A.ITEM_MST_ID, A.ACCOUNT_ID, A.BASE_DATE, QTY_2 CONN_QTY 
          FROM    TB_DP_ENTRY A
         WHERE    A.VER_ID = P_PREV_VER_ID   -- 이전버전
           AND    A.AUTH_TP_ID = (SELECT ID FROM TB_CM_LEVEL_MGMT WHERE LV_CD = 'SALESMAN')
           AND    A.BASE_DATE BETWEEN P_STRT_DATE AND P_END_DATE 
        ) S
        ON (
            T.ITEM_MST_ID = S.ITEM_MST_ID
        AND T.ACCOUNT_ID  = S.ACCOUNT_ID
        AND T.BASE_DATE   = S.BASE_DATE
        )
        WHEN MATCHED THEN
            UPDATE
               SET
                    T.QTY_8 = S.CONN_QTY   -- 전R 연동계획
        ; 

        -- BOH, 가용재고 반영
        MERGE INTO TEMP_DP_RT T
        USING
        (
        SELECT    A.C_VER_CD, B.ACCOUNT_ID, B.BASE_DATE, B.QTY_1, B.QTY_3, B.QTY_5, B.QTY_6, B.QTY_10
          FROM    TB_SDP_CONSENSUS_VER_MST A
                , (
                  SELECT    *
                    FROM
                          (
                            SELECT    VER_ID, PGM_CD, ARRIVAL_CD, ACCOUNT_ID, BASE_DATE, 'QTY_3' COLS, SUM(NVL(RTF,0)) AS QTY
                              FROM    TB_SDP_DEMAND_REQ A
                              JOIN    TB_SDP_CONSENSUS_VER_MST B ON B.DP_VER_CD = A.VER_ID
                             WHERE    A.VER_ID = P_DP_VER_CD
                               AND    BASE_DATE BETWEEN FROM_DATE AND TO_DATE
                            GROUP BY  VER_ID, PGM_CD, ARRIVAL_CD, ACCOUNT_ID, BASE_DATE
                            UNION ALL
                            SELECT    VER_ID, PGM_CD, ARRIVAL_CD, ACCOUNT_ID, BASE_DATE, 'QTY_1' COLS, SUM(NVL(QTY,0)) AS QTY
                              FROM    TB_SDP_DEMAND_REQ A
                              JOIN    TB_SDP_CONSENSUS_VER_MST B ON B.DP_VER_CD = A.VER_ID
                             WHERE    A.VER_ID = P_DP_VER_CD
                               AND    BASE_DATE BETWEEN FROM_DATE AND TO_DATE
                            GROUP BY  VER_ID, PGM_CD, ARRIVAL_CD, ACCOUNT_ID, BASE_DATE
                            UNION ALL
                            SELECT    VER_ID, PGM_CD, ARRIVAL_CD, ACCOUNT_ID, BASE_DATE, 'QTY_10' COLS, SUM(NVL(RTF,0)) - SUM(NVL(QTY,0)) AS QTY
                              FROM    TB_SDP_DEMAND_REQ A
                              JOIN    TB_SDP_CONSENSUS_VER_MST B ON B.DP_VER_CD = A.VER_ID
                             WHERE    A.VER_ID = P_DP_VER_CD
                               AND    BASE_DATE BETWEEN FROM_DATE AND TO_DATE
                            GROUP BY  VER_ID, PGM_CD, ARRIVAL_CD, ACCOUNT_ID, BASE_DATE
                            UNION ALL
                            SELECT    VER_ID, PGM_CD, ARRIVAL_CD, ACCOUNT_ID, BASE_DATE, 'QTY_6' COLS, NVL(QTY,0) AS QTY
                              FROM    TB_SDP_AVAILABLE_STOCK A
                              JOIN    TB_SDP_CONSENSUS_VER_MST B ON B.DP_VER_CD = A.VER_ID
                             WHERE    A.VER_ID = P_DP_VER_CD
                               AND    BASE_DATE BETWEEN FROM_DATE AND TO_DATE
                               AND    STOCK_TYPE = 'AVAILABLE_STOCK'                                              -- 가용재고
                            UNION ALL
                            SELECT    VER_ID, PGM_CD, ARRIVAL_CD, ACCOUNT_ID, BASE_DATE, 'QTY_5' COLS, NVL(QTY,0) AS QTY
                              FROM    TB_SDP_AVAILABLE_STOCK A
                              JOIN    TB_SDP_CONSENSUS_VER_MST B ON B.DP_VER_CD = A.VER_ID
                             WHERE    A.VER_ID = P_DP_VER_CD
                               AND    BASE_DATE = FROM_DATE
                               AND    STOCK_TYPE = 'BOH'                                                          -- 계획시작일의 BOH  
                          ) B
                   PIVOT  ( 
                            SUM(QTY)
                            FOR COLS IN ('QTY_1' QTY_1, 'QTY_3' QTY_3, 'QTY_5' QTY_5, 'QTY_6' QTY_6, 'QTY_10' QTY_10)
                          )  
                  ORDER BY  ACCOUNT_ID, BASE_DATE
                ) B
         WHERE    A.C_VER_CD   = P_C_VER_CD
        ) S
        ON (
            T.ACCOUNT_ID = S.ACCOUNT_ID
        AND T.BASE_DATE  = S.BASE_DATE    
        )
        WHEN MATCHED THEN
            UPDATE
               SET
                     T.QTY_5  = S.QTY_5            -- BOH
                   , T.QTY_6  = S.QTY_6            -- 가용재고
                   , T.QTY_10 = S.QTY_10           -- DIFF
                   , T.QTY_3  = S.QTY_5            -- BOH, EOH 재계산을 위한 최초 BOH값 복사
        ;

        -- BOH, EOH 재계산
        MERGE INTO TEMP_DP_RT T
        USING
        (
        SELECT    ACCOUNT_ID, BASE_DATE
                , NVL(QTY,0)                                                                                   AS QTY     -- Consensus Forecast
                , NVL(QTY_2,0)                                                                                 AS QTY_2   -- RTF Target
                , NVL(QTY_2,0) - NVL(QTY,0)                                                                    AS QTY_4   -- 차이 (RTF Target - Consensus Forecast) : QTY_2 - QTY
                , SUM(NVL(C.QTY_3,0)) OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC) 
                  - SUM(NVL(C.QTY_2,0)) OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC) 
                  + SUM(NVL(C.QTY_6,0)) OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC) 
                  + NVL(C.QTY_2,0) - NVL(C.QTY_6,0)                                                            AS QTY_5    -- BOH : 전주의 EOH 값
                , NVL(QTY_6,0)                                                                                 AS QTY_6    -- 가용재고
                , SUM(NVL(C.QTY_3,0)) OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC) 
                  - SUM(NVL(C.QTY_2,0)) OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC) 
                  + SUM(NVL(C.QTY_6,0)) OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC)                AS QTY_7  -- EOH (BOH + 가용재고 - RTF Target) :  QTY_5 + QTY_6 - QTY_2
          FROM    TEMP_DP_RT C
        ) S
        ON (
            T.ACCOUNT_ID = S.ACCOUNT_ID
        AND T.BASE_DATE  = S.BASE_DATE    
        )
        WHEN MATCHED THEN 
            UPDATE
               SET
                     T.QTY_5  = S.QTY_5            -- BOH
                   , T.QTY_7  = S.QTY_7            -- EOH
        ;   

        INSERT INTO TB_SDP_CONSENSUS_ENTRY
        (   ID        
           ,C_VER_CD
           ,ACCOUNT_ID
           ,ITEM_MST_ID
           ,BASE_DATE
           ,QTY
           ,QTY_1
           ,QTY_2
           ,QTY_4
           ,QTY_5
           ,QTY_6
           ,QTY_7
           ,QTY_8
           ,QTY_9
           ,QTY_10
           ,QTY_11
           ,EMP_ID    
           ,CREATE_DTTM
           ,CREATE_BY
        )
        SELECT  TO_SINGLE_BYTE(SYS_GUID())
               ,P_C_VER_CD
               ,ACCOUNT_ID
               ,ITEM_MST_ID
               ,BASE_DATE
               ,QTY
               ,QTY_1
               ,QTY_2
               ,QTY_4
               ,QTY_5
               ,QTY_6
               ,QTY_7
               ,QTY_8
               ,QTY_9
               ,QTY_10
               ,QTY_3            -- 최초 BOH값을 넣어줌
               ,NULL    AS EMP_ID
               ,SYSDATE
               ,P_USER_ID            
          FROM TEMP_DP_RT
          ;

          DELETE FROM TEMP_DP_RT;

    -- 현재는 미사용
    ELSIF P_VER_TP = 'CUTOFF'
        THEN 
            INSERT INTO TEMP_DP_RT
            (
                ITEM_MST_ID
               ,ACCOUNT_ID
               ,BASE_DATE
               ,QTY
               ,QTY_1
               ,QTY_2
               ,QTY_3            
            )        
            SELECT  ITEM_MST_ID
                   ,ACCOUNT_ID
                   ,BASE_DATE
                   ,QTY
                   ,QTY_1
                   ,QTY_2
                   ,QTY_3    
              FROM TB_DP_ENTRY_CUTOFF
             WHERE CUTOFF_VER_CD = P_ORG_VER_CD 
               AND BASE_DATE BETWEEN P_STRT_DATE AND P_END_DATE 
--               AND VER_ID = P_DP_VER_ID
             ;        

    -- CONSENSUS VERSION 인 경우 CONSENSUS VERSION에서 가져옴
    ELSIF P_VER_TP = 'CONSENSUS'
        THEN


            INSERT INTO TEMP_DP_RT
            (
                ITEM_MST_ID
               ,ACCOUNT_ID
               ,BASE_DATE
               ,QTY                 -- Consensus Forecast
               ,QTY_1               -- 현R RTF
               ,QTY_2               -- RTF Target : Consensus Plan에서 복사하는 경우 MP return 값(QTY_3) 반영
               ,QTY_4               -- 차이(RTF Target - Consensus Forecast)            
               ,QTY_5               -- 기초재고 : Consensus Plan인 경우 Consensus Plan용 기초재고(QTY_12) 반영
               ,QTY_6               -- 가용재고 : Consensus Plan인 경우 Consensus Plan용 가용재고(QTY_13) 반영
               ,QTY_8               -- 전R 연동계획
               ,QTY_9               -- 경영계획
            )
            SELECT  ITEM_MST_ID
                   ,ACCOUNT_ID
                   ,BASE_DATE
                   ,QTY
                   ,QTY_1
                   ,QTY_3                      AS QTY_2
                   ,NVL(QTY_3,0) - NVL(QTY,0)  AS QTY_4
                   ,QTY_12                     AS QTY_5
                   ,QTY_13                     AS QTY_6
                   ,QTY_8
                   ,QTY_9                   
              FROM TB_SDP_CONSENSUS_ENTRY 
             WHERE C_VER_CD = P_ORG_VER_CD
               AND BASE_DATE BETWEEN P_STRT_DATE AND P_END_DATE 
            ;

            -- BOH, EOH 재계산을 위한 최초 BOH값 복사
            UPDATE    TEMP_DP_RT
               SET    QTY_3 = QTY_5
             WHERE    1 = 1
               AND    BASE_DATE = P_STRT_DATE
           ;    

            -- BOH, EOH 재계산
            MERGE INTO TEMP_DP_RT T
            USING
            (
            SELECT    ACCOUNT_ID, BASE_DATE
                    , NVL(QTY,0)                                                                                   AS QTY     -- Consensus Forecast
                    , NVL(QTY_2,0)                                                                                 AS QTY_2   -- RTF Target
                    , NVL(QTY_2,0) - NVL(QTY,0)                                                                    AS QTY_4   -- 차이 (RTF Target - Consensus Forecast) : QTY_2 - QTY
                    , SUM(NVL(C.QTY_3,0)) OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC) 
                      - SUM(NVL(C.QTY_2,0)) OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC) 
                      + SUM(NVL(C.QTY_6,0)) OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC) 
                      + NVL(C.QTY_2,0) - NVL(C.QTY_6,0)                                                            AS QTY_5    -- BOH : 전주의 EOH 값
                    , NVL(QTY_6,0)                                                                                 AS QTY_6    -- 가용재고
                    , SUM(NVL(C.QTY_3,0)) OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC) 
                      - SUM(NVL(C.QTY_2,0)) OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC) 
                      + SUM(NVL(C.QTY_6,0)) OVER (PARTITION BY ACCOUNT_ID ORDER BY C.BASE_DATE ASC)                AS QTY_7  -- EOH (BOH + 가용재고 - RTF Target) :  QTY_5 + QTY_6 - QTY_2
              FROM    TEMP_DP_RT C
            ) S
            ON (
                T.ACCOUNT_ID = S.ACCOUNT_ID
            AND T.BASE_DATE  = S.BASE_DATE    
            )
            WHEN MATCHED THEN 
                UPDATE
                   SET
                         T.QTY_5  = S.QTY_5            -- BOH
                       , T.QTY_7  = S.QTY_7            -- EOH
            ;   

            -- CONSENSUS PLAN 전체 반영
            INSERT INTO TB_SDP_CONSENSUS_ENTRY
            (   ID        
               ,C_VER_CD
               ,ACCOUNT_ID
               ,ITEM_MST_ID
               ,BASE_DATE
               ,QTY
               ,QTY_1
               ,QTY_2
               ,QTY_4
               ,QTY_5
               ,QTY_6
               ,QTY_7
               ,QTY_8
               ,QTY_9
               ,QTY_11
               ,EMP_ID    
               ,CREATE_DTTM
               ,CREATE_BY
            )
            SELECT  TO_SINGLE_BYTE(SYS_GUID())
                   ,P_C_VER_CD
                   ,ACCOUNT_ID
                   ,ITEM_MST_ID
                   ,BASE_DATE
                   ,QTY
                   ,QTY_1
                   ,QTY_2
                   ,QTY_4
                   ,QTY_5
                   ,QTY_6
                   ,QTY_7
                   ,QTY_8
                   ,QTY_9
                   ,QTY_3            -- BOH값을 동일하게 넣어줌
                   ,NULL    AS EMP_ID
                   ,SYSDATE
                   ,P_USER_ID            
              FROM TEMP_DP_RT
              ;

              DELETE FROM TEMP_DP_RT;

    END IF
    ;


	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  --
       /*  ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN  -- : e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF; 

END
;
/

