create PROCEDURE                 SP_UI_DP_95_PROCESS_STATUS_S1(
   P_USER_CD		VARCHAR2 
 , P_AUTH_TP_CD		VARCHAR2 
 , P_VER_CD			VARCHAR2 
 , p_STATUS         VARCHAR2 
)
IS
      P_APPV_CONST_CD   VARCHAR2(50);
      P_AUTH_TP_ID  	CHAR(32);
      p_VER_ID	    	CHAR(32);    
      P_DP_VER_CD       VARCHAR2(50);
      P_C_VER_CD        VARCHAR2(50);
      P_LEAF_YN         CHAR(1);
      P_IF_CHECK        INT;
BEGIN 
/*****************************************************************************************************
    History ( date / writer / comment )
    - 2021.03.10 / ksh / draft
    - 2021.04.28 / ksh / sk custom : check main level
    - 2021.05.27 / ksh / consensus bug fix & scm user also approve all
****************************************************************************************************/
	SELECT ID , LEAF_YN
          INTO P_AUTH_TP_ID , P_LEAF_YN 
	  FROM TB_CM_LEVEL_MGMT
	 WHERE LV_CD = P_AUTH_TP_CD
     ;
   SELECT COUNT(ID) INTO P_IF_CHECK
	 FROM TB_SDP_CONSENSUS_VER_MST
   WHERE C_VER_CD = P_VER_CD 
    ;
    IF (P_IF_CHECK > 0)
        THEN
           SELECT C_VER_CD  
--                , DP_VER_CD
                  , M.ID
                INTO P_C_VER_CD
--                   , P_DP_VER_CD
                   , P_VER_ID
             FROM TB_SDP_CONSENSUS_VER_MST C
                  INNER JOIN
                  TB_DP_CONTROL_BOARD_VER_MST M 
               ON C.DP_VER_CD = M.VER_ID 
           WHERE C_VER_CD = P_VER_CD 
           ;         
    ELSE
           SELECT VER_ID
                , ID 
             INTO P_DP_VER_CD
                , P_VER_ID
             FROM TB_DP_CONTROL_BOARD_VER_MST
           WHERE VER_ID = P_VER_CD 
           ;     
    END IF;

    SELECT CC.ATTR_01 INTO P_APPV_CONST_CD
 	  FROM TB_DP_CONTROL_BOARD_VER_DTL CB
		   INNER JOIN
		   TB_CM_COMM_CONFIG CC
		ON CB.APPV_CONST_ID = CC.ID 
	 WHERE CONBD_VER_MST_ID = p_VER_ID
	   AND LV_MGMT_ID = P_AUTH_TP_ID 
	   ;	    
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Main Procedure
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
IF (P_APPV_CONST_CD = 'ALL')
    THEN
/*    
          SELECT DESC_ID INTO P_TOP_SALES_LV
               FROM TB_dPD_USER_HIER_CLOSURE 
            GROUP BY DESC_ID 
            HAVING COUNT(DESC_ID) = 1
            ;
*/          
        INSERT INTO TB_DP_PROCESS_STATUS_LOG
        (    ID
           , VER_CD
           , AUTH_TYPE
           , OPERATOR_ID
           , STATUS
           , STATUS_DATE
         )  
        WITH PARENT_LV 
        AS (-- 理쒖긽�쐞 �궗�슜�옄媛� �븘�땺 �븣
            SELECT UH.ANCS_ROLE_ID, ANCS_ROLE_CD
                 , ANCS_ID , ANCS_CD
                 , DENSE_RANK() OVER (ORDER BY LV.SEQ  DESC) AS SEQ           
              FROM TB_DPD_USER_HIER_CLOSURE UH
                   INNER JOIN 
                   TB_CM_LEVEL_MGMT LV
               ON UH.ANCS_ROLE_ID = LV.ID		
              AND LV.ACTV_YN = 'Y'
              AND COALESCE(LV.DEL_YN,'N') = 'N'
              AND DESC_ROLE_ID = P_AUTH_TP_ID   
              AND DESC_CD = P_USER_CD
              AND DESC_CD != ANCS_CD 
              AND CASE WHEN P_LEAF_YN = 'Y' THEN MAIN_LV_YN ELSE 'Y' END = 'Y' 
            ) , APPV_USER
        AS (
            SELECT DISTINCT
                   M.DESC_ROLE_ID 
                 , M.DESC_ROLE_CD 
                 , M.DESC_ID
                 , M.DESC_CD 
              FROM TB_DPD_USER_HIER_CLOSURE M
                   INNER JOIN
                   PARENT_LV P 
                ON M.ANCS_ROLE_ID = P.ANCS_ROLE_ID
               AND M.ANCS_ID = P.ANCS_ID
               AND M.DESC_ROLE_ID = P_AUTH_TP_ID 
               AND P.SEQ = 1 
               AND CASE WHEN P_LEAF_YN = 'Y' THEN MAIN_LV_YN ELSE 'Y' END = 'Y' 
               AND M.DESC_CD != P_USER_CD
            )  
            SELECT TO_SINGLE_BYTE(SYS_GUID())
                  ,COALESCE(P_DP_VER_CD, P_C_VER_CD)
                  ,DESC_ROLE_CD
                  ,DESC_CD  
                  ,p_STATUS  
                  ,SYSDATE 
              FROM TB_DPD_USER_HIER_CLOSURE 
            WHERE DESC_ROLE_ID = (SELECT LV_MGMT_ID FROM TB_DP_SALES_LEVEL_MGMT WHERE ACTV_YN = 'Y' AND DEL_YN != 'Y' AND PARENT_SALES_LV_ID IS NULL)   
              AND DESC_ROLE_ID = P_AUTH_TP_ID
              AND DESC_CD != P_USER_CD 
            UNION 
            SELECT TO_SINGLE_BYTE(SYS_GUID())
                  ,COALESCE(P_DP_VER_CD, P_C_VER_CD)
                  ,DESC_ROLE_CD
                  ,DESC_CD  
                  ,p_STATUS  
                  ,SYSDATE 
              FROM APPV_USER 
            ;
    END IF
    ;       
END;
/

