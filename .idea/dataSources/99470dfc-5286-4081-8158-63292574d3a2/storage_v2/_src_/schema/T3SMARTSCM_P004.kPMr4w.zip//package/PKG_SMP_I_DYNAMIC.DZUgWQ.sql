create PACKAGE                 PKG_SMP_I_DYNAMIC
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved.
**************************************************************************
* Name    : PKG_SMP_I_DYNAMIC
* Purpose : MP Static 정보 생성.
* Notes   :
**************************************************************************
* History :
* 2020-02-17 HGD Created
**************************************************************************/
IS
PRAGMA SERIALLY_REUSABLE;

PROCEDURE SP_SET_STOCK (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_SO (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
);

PROCEDURE SP_SET_FIXED_ZONE (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION --TB_SMP_WK_PLAN_OPTION%ROWTYPE
, O_sFLAG        OUT VARCHAR2
);
END PKG_SMP_I_DYNAMIC;
/

