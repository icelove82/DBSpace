create PROCEDURE "SP_UI_DP_00_USER_GRP_Q1" (
    pRESULT OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN pRESULT
    FOR
    WITH AUTH_TP
    AS (
        SELECT LV_CD, SEQ
          FROM TB_CM_LEVEL_MGMT 
         WHERE SALES_LV_YN = 'Y' 
           AND ACTV_YN = 'Y'
           AND COALESCE(DEL_YN, 'N') = 'N' 
    ), M 
    AS (
        SELECT G.ID
              ,G.GRP_CD
              ,G.GRP_NM
              ,G.GRP_DESCRIP
              ,SEQ          AS SEQ 
          FROM TB_AD_GROUP G
               INNER JOIN 
               AUTH_TP L
            ON L.LV_CD = G.GRP_CD
        UNION
        SELECT ID
             , GRP_CD
             , GRP_NM
             , GRP_DESCRIP
             , 1+(SELECT MAX(SEQ) FROM AUTH_TP) AS SEQ 
          FROM TB_AD_GROUP GP
         WHERE GRP_CD NOT IN (SELECT LV_CD FROM AUTH_TP)
    )
     SELECT M.*
       FROM M 
    ORDER BY SEQ ;
END ;

/

