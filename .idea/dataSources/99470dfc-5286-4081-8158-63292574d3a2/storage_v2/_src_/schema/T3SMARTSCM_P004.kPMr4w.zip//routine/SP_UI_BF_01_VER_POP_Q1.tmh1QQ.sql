create PROCEDURE "SP_UI_BF_01_VER_POP_Q1" 
(
  P_ENGINE_TP   IN VARCHAR2 := '',
  pRESULT       OUT SYS_REFCURSOR
)
IS
/*********************************************************************
    ？？？？ : ？？？？ ？？？？ ？？？？？ version ？？？？？？ ？？？？？ ？？？？？？ ？？？ (ex. Bucket, Price type,...)
*********************************************************************/ 
BEGIN
--4FFB97D63C36417D810450471B7D752D
OPEN pRESULT          
FOR

SELECT IH
     , TH
     , IB
     , TB
     , DR
     , ADD_MONTHS(SYSDATE,-1)			     AS IP_TO_DT
     , ADD_MONTHS(SYSDATE,-1-TO_NUMBER(IH))  AS IP_FR_DT
     , SYSDATE					          AS TG_FR_DT
     , ADD_MONTHS(SYSDATE,TO_NUMBER(TH))     AS TG_TO_DT
   FROM (     
			 SELECT POLICY_CD, POLICY_VAL
			  FROM TB_BF_PLAN_POLICY
			 WHERE ENGINE_TYPE_CD = 'BEST_SELECTION' --@P_ENGINE_TP
		)
   PIVOT (     MIN(POLICY_VAL)     
               FOR POLICY_CD 
               IN ('IH' IH, 'TH' TH, 'IB' IB, 'TB' TB, 'DR' DR) 
          ) 
     ; 
END
;

/

