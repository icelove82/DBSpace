create PROCEDURE "SP_UI_DP_22_1_S1" (
    p_ID                        IN VARCHAR2  := ''         
  , p_MODULE_ID                 IN VARCHAR2  := ''         
  , p_WORK_CD                   IN VARCHAR2  := ''         
  , p_SEQ                       IN INT       := ''      
  , p_DESCRIP                   IN VARCHAR2  := ''      
  , p_WORK_NM                   IN VARCHAR2  := ''      
  , p_WORK_TP_ID                IN VARCHAR2  := ''      
  , p_LINK                      IN VARCHAR2  := ''      
  , p_LV_MGMT_ID                IN VARCHAR2  := ''      
  , p_INIT_VAL_TP_ID            IN VARCHAR2  := ''      
  , p_INIT_FIXED_LV_MGMT_ID     IN VARCHAR2  := ''      
  , p_INPUT_TP_ID               IN VARCHAR2  := ''      
  , p_CONST_INPUT_YN            IN VARCHAR2  := ''      
  , p_INIT_CONST_INPUT_VAL      IN INT       := ''      
  , p_INIT_CONST_INPUT_TIME_VAL IN INT       := ''      
  , p_APPV_CONST_ID	            IN VARCHAR2  := ''       
  , p_APPV_EVENT_ID             IN VARCHAR2  := ''      
  , p_AUTO_APPV_YN              IN VARCHAR2  := ''      
  , p_INIT_AUTO_APPV_VAL        IN INT       := ''      
  , p_INIT_AUTO_APPV_TIME_VAL   IN INT       := ''   
  , p_CANC_CONST_ID             IN VARCHAR2  := ''      
  , p_CANC_EVENT_ID             IN VARCHAR2  := ''      
  , p_CL_TP_ID                  IN VARCHAR2  := ''      
  , p_CL_LV_MGMT_ID             IN VARCHAR2  := ''      
  , p_PLAN_TP_ID                IN VARCHAR2	 := ''  	
  , p_USER_ID                   IN VARCHAR2  := ''     
  , P_RT_ROLLBACK_FLAG          OUT VARCHAR2
  , P_RT_MSG                    OUT VARCHAR2
) 
IS
	P_ERR_STATUS INT := 0;
	P_ERR_MSG VARCHAR2(4000) :='';
    V_MODULE_ID CHAR(32) := '';

BEGIN 

    IF (p_MODULE_ID IS NULL OR p_WORK_CD IS NULL) THEN
    	P_ERR_MSG := 'MSG_0006'; 
    	RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);         
    END IF;

    SELECT COUNT(*) INTO P_ERR_STATUS
      FROM TB_DP_CONTROL_BOARD_MST
     WHERE 1=1
       AND MODULE_ID = p_MODULE_ID	
       AND WORK_CD = p_WORK_CD	
       AND PLAN_TP_ID = P_PLAN_TP_ID
       AND ID != p_ID;

    IF (P_ERR_STATUS >=1) THEN
	    P_ERR_MSG := 'MSG_0013'; 
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); 
    END IF;

    SELECT B.ID INTO V_MODULE_ID
      FROM TB_AD_COMN_GRP A
     INNER JOIN TB_AD_COMN_CODE B
        ON (A.ID = B.SRC_ID)
     WHERE 1=1
       AND A.GRP_CD = 'MODULE_TP'
       AND B.COMN_CD = trim(p_MODULE_ID)
     GROUP BY B.ID
    ;

	MERGE INTO TB_DP_CONTROL_BOARD_MST TARGET
	USING ( 
		SELECT p_ID						    AS ID
             , V_MODULE_ID				    AS MODULE_ID			
             , p_WORK_CD					AS WORK_CD	
             , p_WORK_NM					AS WORK_NM					
             , p_SEQ						AS SEQ							
             , p_DESCRIP					AS DESCRIP				
             , p_WORK_TP_ID				    AS WORK_TP_ID				
             , p_LINK					    AS LINK				
             , p_LV_MGMT_ID				    AS LV_MGMT_ID
             , p_INIT_VAL_TP_ID			    AS INIT_VAL_TP_ID			
             , p_INIT_FIXED_LV_MGMT_ID	    AS INIT_FIXED_LV_MGMT_ID	
             , p_INPUT_TP_ID				AS INPUT_TP_ID			
             , p_CONST_INPUT_YN             AS CONST_INPUT_YN
             , p_INIT_CONST_INPUT_VAL       AS INIT_CONST_INPUT_VAL
             , p_INIT_CONST_INPUT_TIME_VAL  AS INIT_CONST_INPUT_TIME_VAL 
             , p_APPV_CONST_ID			    AS APPV_CONST_ID			
             , p_APPV_EVENT_ID			    AS APPV_EVENT_ID			
             , p_AUTO_APPV_YN			    AS AUTO_APPV_YN		
             , p_INIT_AUTO_APPV_VAL		    AS INIT_AUTO_APPV_VAL	
             , p_INIT_AUTO_APPV_TIME_VAL	AS INIT_AUTO_APPV_TIME_VAL	
             , p_CANC_CONST_ID			    AS CANC_CONST_ID			
             , p_CANC_EVENT_ID			    AS CANC_EVENT_ID			
             , p_CL_TP_ID				    AS CL_TP_ID				
             , p_CL_LV_MGMT_ID			    AS CL_LV_MGMT_ID		
             , p_PLAN_TP_ID					AS PLAN_TP_ID	                        
             , p_USER_ID                    AS USER_ID			
          FROM DUAL 
	) SOURCE
	ON (TARGET.ID = SOURCE.ID)	
	--AND TARGET.MODULE_ID		= SOURCE.MODULE_ID
	--AND TARGET.WORK_CD		= SOURCE.WORK_CD
	--AND TARGET.SEQ			= SOURCE.SEQ
	WHEN MATCHED THEN
		 UPDATE 
		    SET TARGET.WORK_CD					    = SOURCE.WORK_CD
              , TARGET.WORK_NM					    = SOURCE.WORK_NM						  
              , TARGET.SEQ						    = SOURCE.SEQ						  			  
              , TARGET.DESCRIP					    = SOURCE.DESCRIP					  
              , TARGET.WORK_TP_ID				    = SOURCE.WORK_TP_ID					  
              , TARGET.LINK					        = SOURCE.LINK					  
              , TARGET.LV_MGMT_ID				    = SOURCE.LV_MGMT_ID				  
              , TARGET.INIT_VAL_TP_ID			    = SOURCE.INIT_VAL_TP_ID				  
              , TARGET.INIT_FIXED_LV_MGMT_ID	    = SOURCE.INIT_FIXED_LV_MGMT_ID		  
              , TARGET.INPUT_TP_ID				    = SOURCE.INPUT_TP_ID
              --,TARGET.INIT_INPUT_STRT_VAL		    = SOURCE.INIT_INPUT_STRT_VAL
              --,TARGET.INIT_INPUT_END_VAL		    = SOURCE.INIT_INPUT_END_VAL	
              , TARGET.CONST_INPUT_YN			    = SOURCE.CONST_INPUT_YN	
              , TARGET.INIT_CONST_INPUT_VAL		    = SOURCE.INIT_CONST_INPUT_VAL	
              , TARGET.INIT_CONST_INPUT_TIME_VAL	= SOURCE.INIT_CONST_INPUT_TIME_VAL	
              , TARGET.APPV_CONST_ID			    = SOURCE.APPV_CONST_ID			
              , TARGET.APPV_EVENT_ID			    = SOURCE.APPV_EVENT_ID			
              , TARGET.AUTO_APPV_YN			        = SOURCE.AUTO_APPV_YN		
              , TARGET.INIT_AUTO_APPV_VAL		    = SOURCE.INIT_AUTO_APPV_VAL	
              , TARGET.INIT_AUTO_APPV_TIME_VAL	    = SOURCE.INIT_AUTO_APPV_TIME_VAL	
              , TARGET.CANC_CONST_ID			    = SOURCE.CANC_CONST_ID			
              , TARGET.CANC_EVENT_ID			    = SOURCE.CANC_EVENT_ID			
              , TARGET.CL_TP_ID				        = SOURCE.CL_TP_ID				
              , TARGET.CL_LV_MGMT_ID			    = SOURCE.CL_LV_MGMT_ID			
              , TARGET.MODIFY_BY				    = SOURCE.USER_ID       
              , TARGET.MODIFY_DTTM				    = SYSDATE
	WHEN NOT MATCHED THEN 
		 INSERT (
            ID
           ,MODULE_ID
           ,WORK_CD
           ,WORK_NM
           ,SEQ
           ,DESCRIP
           ,WORK_TP_ID
           ,LINK
           ,LV_MGMT_ID
           ,INIT_VAL_TP_ID
           ,INIT_FIXED_LV_MGMT_ID
           ,INPUT_TP_ID
           --,INIT_INPUT_STRT_VAL
           --,INIT_INPUT_END_VAL
           ,CONST_INPUT_YN	
           ,INIT_CONST_INPUT_VAL	
           ,INIT_CONST_INPUT_TIME_VAL
           ,APPV_CONST_ID
           ,APPV_EVENT_ID
           ,AUTO_APPV_YN
           ,INIT_AUTO_APPV_VAL
           ,INIT_AUTO_APPV_TIME_VAL
           ,CANC_CONST_ID
           ,CANC_EVENT_ID
           ,CL_TP_ID
           ,CL_LV_MGMT_ID
           ,DEL_YN
           ,PLAN_TP_ID
           ,CREATE_BY
           ,CREATE_DTTM
         ) 
		 VALUES (
            TO_SINGLE_BYTE(SYS_GUID()) 
           ,SOURCE.MODULE_ID
           ,SOURCE.WORK_CD	
           ,SOURCE.WORK_NM				
           ,SOURCE.SEQ	
           ,SOURCE.DESCRIP				
           ,SOURCE.WORK_TP_ID				
           ,SOURCE.LINK					
           ,SOURCE.LV_MGMT_ID				
           ,''
           ,''
           ,SOURCE.INPUT_TP_ID				
           ,'N'
           ,0
           ,0
           ,''
           ,''
           ,'N'
           ,0
           ,0
           ,SOURCE.CANC_CONST_ID
           ,SOURCE.CANC_EVENT_ID
           ,SOURCE.CL_TP_ID
           ,SOURCE.CL_LV_MGMT_ID
           ,'N'
           ,SOURCE.PLAN_TP_ID
           ,SOURCE.USER_ID
           ,SYSDATE
         )
    ;
    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';  --???？？????？？
       /* ???？o?? ============================================================================*/

EXCEPTION WHEN OTHERS THEN  -- ?？? ???？？? ?？? ???？?？ : e_products_invalid
    IF(SQLCODE = -20001)
    THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
    ELSE
        SP_COMM_RAISE_ERR();
    --RAISE;
    END IF;

END;

/

