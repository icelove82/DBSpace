create PROCEDURE "SP_UI_DP_13_Q1_T" (
    P_ITEM_LV        IN VARCHAR2 := NULL
  , P_ITEM_CD        IN VARCHAR2 := NULL
  , pRESULT  OUT SYS_REFCURSOR 
) IS 

    P_LEAF_LV_CD VARCHAR2(100);
/******************************************************************************************
	Check a User's Task Status

	Description
	- CNT : a number of approval
	- If CNT is 0, Status is true.
	- 최종 Close를 해도, close를 한번 더 못하지만, 다른 처리는 가능한 상태

	History (Date / Writer / Comment)
	- 2020.12.09 / Kim sohee / Oracle Converting
********************************************************************************************/
BEGIN

    SELECT LV_CD
      INTO P_LEAF_LV_CD
      FROM TB_CM_LEVEL_MGMT
     WHERE COALESCE(SALES_LV_YN, 'N') = 'N'
       AND COALESCE(ACCOUNT_LV_YN, 'N') = 'N'
       AND LEAF_YN = 'Y'
       AND COALESCE(DEL_YN, 'N') = 'N'
       AND ACTV_YN = 'Y';

    OPEN pRESULT
    FOR
    WITH
    TB_PR_ITEM_LEVEL_MGMT (
        ID
      , "PATH"
      , PATH_ID
      , SEQ
      , ITEM_LV_NM
    ) AS (
        SELECT SL.ID
             , TO_CHAR('/' || SL.ITEM_LV_CD)    "PATH"
             , TO_CHAR('/' || SL.ID)            PATH_ID
             , LM.SEQ
             , SL.ITEM_LV_NM
          FROM TB_CM_ITEM_LEVEL_MGMT SL
         INNER JOIN TB_CM_LEVEL_MGMT LM
            ON SL.LV_MGMT_ID = LM.ID
         WHERE SL.PARENT_ITEM_LV_ID IS NULL
           AND COALESCE(LM.DEL_YN, 'N') = 'N'
           AND COALESCE(SL.DEL_YN, 'N') = 'N'
           AND COALESCE(LM.SALES_LV_YN, 'N') = 'N'
           AND LM.ACTV_YN = 'Y'
           AND SL.ACTV_YN = 'Y'
        UNION ALL
        SELECT SL.ID
             , TO_CHAR("PATH" || '/' || SL.ITEM_LV_CD)  "PATH"
             , TO_CHAR(PATH_ID || '/' || SL.ID)         PATH_ID
             , LM.SEQ
             , SL.ITEM_LV_NM
          FROM TB_CM_ITEM_LEVEL_MGMT SL
         INNER JOIN TB_PR_ITEM_LEVEL_MGMT PL
            ON SL.PARENT_ITEM_LV_ID = PL.ID
         INNER JOIN TB_CM_LEVEL_MGMT LM
            ON SL.LV_MGMT_ID = LM.ID
         WHERE COALESCE(LM.DEL_YN, 'N') = 'N'
           AND COALESCE(SL.DEL_YN, 'N') = 'N'
           AND COALESCE(LM.SALES_LV_YN, 'N') = 'N'
           AND LM.ACTV_YN = 'Y'
           AND SL.ACTV_YN = 'Y'
    ),

    TB_DPD_ITEM_TREE (
        LEAF_ITEM_LV_ID
      , LEAF_ITEM_LV_CD
      , PATH_ID
      , PATH_CD
      , LEAF_ITEM_LV_NM
      , SEQ
    ) AS (
        SELECT SUBSTR(M.PATH_ID, -INSTR(REVERSE(M.PATH_ID), '/') + 1)   AS LEAF_ITEM_LV_ID
             , SUBSTR(M."PATH",  -INSTR(REVERSE(M."PATH"),  '/') + 1)   AS LEAF_ITEM_LV_CD
             , SUBSTR(PATH_ID, 2, LENGTH(PATH_ID) - 1)                  AS PATH_ID
             , SUBSTR("PATH", 2, LENGTH("PATH") - 1)                    AS PATH_CD
             , M.ITEM_LV_NM                                             AS LEAF_ITEM_LV_NM
             , M.SEQ
          FROM TB_PR_ITEM_LEVEL_MGMT M
    )

    SELECT CASE WHEN IT.ITEM_CD IS NULL
                THEN TR.LEAF_ITEM_LV_ID
                ELSE IT.ID
           END                          AS KEY_ITEM_ID
         , CASE WHEN IT.ITEM_CD IS NULL
                THEN TR.LEAF_ITEM_LV_CD
                ELSE IT.ITEM_CD
           END                          AS KEY_ITEM_CD
         , CASE WHEN IT.ITEM_NM IS NULL
                THEN TR.LEAF_ITEM_LV_NM
                ELSE IT.ITEM_NM
           END                          AS KEY_ITEM_NM
         , LV.ID                        AS LV_MGMT_ID
         , P_ITEM_LV                    AS LV_MGMT_CD
         , 'SEQ' || LPAD(TO_CHAR(LV2.SEQ), 3, '0') || LV2.LV_NM AS GRP
         , TR.VAL                       AS CD
         , IL2.ITEM_LV_NM               AS NM
         , IT.ITEM_CD
         , IT.ITEM_NM
      FROM TB_CM_LEVEL_MGMT LV
     INNER JOIN TB_CM_ITEM_LEVEL_MGMT IL
        ON LV.ID = IL.LV_MGMT_ID
     INNER JOIN (
        SELECT TRIM(REGEXP_SUBSTR(PATH_CD, '[^/]+', 1, LEVEL)) VAL
             , LEAF_ITEM_LV_CD
             , LEAF_ITEM_LV_ID
             , LEAF_ITEM_LV_NM
          FROM (
            SELECT PATH_CD
                 , LEAF_ITEM_LV_CD
                 , LEAF_ITEM_LV_ID
                 , LEAF_ITEM_LV_NM
              FROM TB_DPD_ITEM_TREE T
          )
        CONNECT BY INSTR(PATH_CD, '/', 1, LEVEL - 1) > 0
     ) TR
        ON IL.ID = TR.LEAF_ITEM_LV_ID
      LEFT OUTER JOIN TB_CM_ITEM_LEVEL_MGMT IL2
        ON IL2.ITEM_LV_CD = TR.VAL
      LEFT OUTER JOIN TB_CM_LEVEL_MGMT LV2
        ON IL2.LV_MGMT_ID = LV2.ID
      LEFT OUTER JOIN (
        SELECT ID, ITEM_CD, ITEM_NM, PARENT_ITEM_LV_ID
          FROM TB_CM_ITEM_MST
         WHERE DP_PLAN_YN = 'Y'
           AND COALESCE(DEL_YN, 'N') = 'N'
           AND P_ITEM_LV = P_LEAF_LV_CD
      ) IT
        ON TR.LEAF_ITEM_LV_ID = IT.PARENT_ITEM_LV_ID
     WHERE CASE WHEN P_ITEM_LV = P_LEAF_LV_CD
                THEN (
                    SELECT LV_CD
                      FROM TB_CM_LEVEL_MGMT
                     WHERE COALESCE(SALES_LV_YN, 'N') = 'N'
                       AND COALESCE(ACCOUNT_LV_YN, 'N') = 'N'
                       AND LV_LEAF_YN = 'Y'
                       AND COALESCE(DEL_YN, 'N') = 'N'
                       AND ACTV_YN = 'Y'
                )
                ELSE P_ITEM_LV
           END = LV.LV_CD
       AND CASE WHEN P_ITEM_LV = P_LEAF_LV_CD
                THEN ITEM_CD
                ELSE ' '
           END IS NOT NULL
       AND CASE WHEN P_ITEM_LV = P_LEAF_LV_CD AND P_ITEM_CD NOT LIKE '%|%'
                THEN ITEM_CD
                ELSE COALESCE(P_ITEM_CD, ' ') END LIKE '%' || COALESCE(P_ITEM_CD, '') || '%'
       AND (P_ITEM_CD IS NULL
            OR (REGEXP_LIKE(UPPER(ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\['))))
    ;
END;
/

