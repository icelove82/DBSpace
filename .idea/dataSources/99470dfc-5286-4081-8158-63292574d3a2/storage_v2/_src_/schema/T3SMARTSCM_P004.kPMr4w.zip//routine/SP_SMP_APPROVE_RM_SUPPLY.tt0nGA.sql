create PROCEDURE                 SP_SMP_APPROVE_RM_SUPPLY(
 P_sVERSION_ID     IN     VARCHAR2
,P_sUSER_ID        IN     VARCHAR2
,O_sFLAG           OUT    VARCHAR2
)
IS
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved. 
**************************************************************************
* Name    : SP_SMP_APPROVE_RM_SUPPLY
* Purpose : 
* Notes   :
* <호출>

**************************************************************************
* History : 
* 2020-06-01 JMS Created
**************************************************************************/
  USER_EXCEPTION  EXCEPTION;

  G_nLOG_SEQ      NUMBER;
  G_sPROGRAMN_ID  NVARCHAR2(50) := 'SP_SMP_SPPROVE_RM_SUPPLY';
  G_sSTEP_SEQ     NVARCHAR2(50);
  G_sSTEP_DESC    NVARCHAR2(50);
  --G_sVERSION_ID   NVARCHAR2(50);
  G_sNEW_ROLL_MM_YN CHAR(1);
  G_sUSER_ID      NVARCHAR2(50);
  G_nSQL_CNT      NUMBER(20);
  G_sLOGMSG       VARCHAR2(4000);  

  G_nLOG_END_SEQ  NUMBER;

  G_nCNT          INT;

BEGIN   
  O_sFLAG := 'S';
  G_sSTEP_SEQ := '0.0';   
  G_sSTEP_DESC := 'SP_SMP_APPROVE_RM_SUPPLY (Start)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_END_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);  

  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Approve Raw Material Supply Plan';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_sVERSION_ID, G_sUSER_ID);  

      MERGE INTO TB_SMP_RS_RM_CONSUME_V_APPR APR
      USING (
             SELECT P_sVERSION_ID AS VERSION_ID, VENDOR_CD, P_SITE_CD
               FROM TB_SMP_VENDOR_EMP_MAP tsvem 
              WHERE EMPLOYEE_ID = P_sUSER_ID
              GROUP BY VENDOR_CD, P_SITE_CD
            ) GRD
      ON (APR.VERSION_ID = GRD.VERSION_ID
      AND APR.VENDOR_CD = GRD.VENDOR_CD
      AND APR.P_SITE_CD = GRD.P_SITE_CD)
      WHEN MATCHED THEN
      UPDATE
      SET APR.APPR_FLAG = 'Y'
        , APR.UPDATE_USER_ID = P_sUSER_ID
        , APR.UPDATE_DTTM = SYSDATE
      WHEN NOT MATCHED THEN
      INSERT (APR.VERSION_ID, APR.VENDOR_CD, APR.P_SITE_CD, APR.APPR_FLAG, APR.REG_DTTM, APR.REG_USER_ID)
      VALUES (GRD.VERSION_ID, GRD.VENDOR_CD, GRD.P_SITE_CD, 'Y', SYSDATE, P_sUSER_ID)
      ;
 
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
  COMMIT;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_END_SEQ, SQL%ROWCOUNT);
EXCEPTION
  WHEN USER_EXCEPTION THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);
END;

/

