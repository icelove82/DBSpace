create PROCEDURE                 SP_SMP_CREATE_VER(
 P_sENGINE_ID      IN     VARCHAR2
,P_sPLAN_TYPE      IN     VARCHAR2
,P_sBASE_MONTH     IN     VARCHAR2
,P_sPLAN_DESC      IN     VARCHAR2
,P_sEXE_USER_ID    IN     VARCHAR2
,P_sREF_VERSION_ID IN     VARCHAR2 := NULL
,P_sP_PGM_APPLY_YN IN     VARCHAR2 := 'N' --Default : 수주추진 반영 안함
,O_sVERSION_ID     OUT    VARCHAR2
,O_sFLAG           OUT    VARCHAR2
,O_sMSG            OUT    VARCHAR2
)
IS
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved. 
**************************************************************************
* Name    : SP_SMP_CREATE_VER
* Purpose : 
* Notes   :
* <호출>

**************************************************************************
* History : 
* 2020-02-21 AIS Created
**************************************************************************/
  USER_EXCEPTION  EXCEPTION;

  G_nLOG_SEQ      NUMBER;
  G_sPROGRAMN_ID  NVARCHAR2(50) := 'SP_SMP_CREATE_VER';
  G_sSTEP_SEQ     NVARCHAR2(50);
  G_sSTEP_DESC    NVARCHAR2(50);
  --G_sVERSION_ID   NVARCHAR2(50);
  G_sNEW_ROLL_MM_YN CHAR(1);
  G_sUSER_ID      NVARCHAR2(50);
  G_nSQL_CNT      NUMBER(20);
  G_sLOGMSG       VARCHAR2(4000);  

  G_nLOG_END_SEQ  NUMBER;

  G_nCNT          INT;

BEGIN   
  O_sFLAG := 'S';
  G_sSTEP_SEQ := '0.0';   
  G_sSTEP_DESC := 'SP_SMP_CREATE_VER (Start)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_END_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, O_sVERSION_ID, G_sUSER_ID);  

  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Create Ver.';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, O_sVERSION_ID, G_sUSER_ID);
      
      -- 동일 기준월 버전 생성 여부
      SELECT COUNT(*)
        INTO G_nCNT
        FROM TB_SMP_VER_MST
       WHERE PLAN_TYPE      = P_sPLAN_TYPE 
         AND BASE_MONTH     = P_sBASE_MONTH
      ;
      
      IF G_nCNT > 0 THEN
      
          SELECT P_sPLAN_TYPE || '-' || P_sBASE_MONTH || '-' || LPAD( NVL(SUBSTR(MAX(VERSION_ID), -2, 2), '00') + 1, 2, '0')
            INTO O_sVERSION_ID
            FROM TB_SMP_VER_MST
           WHERE PLAN_TYPE      = P_sPLAN_TYPE 
             AND BASE_MONTH     = P_sBASE_MONTH
          ;
        
      ELSE 
      
          O_sVERSION_ID := P_sPLAN_TYPE || '-' || P_sBASE_MONTH || '-' || '01';
      
      END IF;
    
      -- Rolling Horizon 대상 월 여부 판단.
      SELECT CASE WHEN TO_NUMBER(TO_CHAR(TO_DATE(P_sBASE_MONTH, 'YYYYMM'), 'MM')) >= TO_NUMBER(ATTR_01)
                  THEN 'Y'
                  ELSE 'N'
                  END
        INTO G_sNEW_ROLL_MM_YN
        FROM TB_CM_COMM_CONFIG
       WHERE CONF_GRP_CD = 'PLAN_MONTH'
         AND CONF_CD = 'ROLLING_HORIZON_MONTH'
      ;
  
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);

  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Insert Ver.';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, O_sVERSION_ID, G_sUSER_ID);     

  INSERT INTO TB_SMP_VER_MST(
         VERSION_ID
        ,ENGINE_ID
        ,BASE_YEAR
        ,BASE_MONTH
        ,VERSION_DESC
        ,PLAN_TYPE
        ,NEW_ROLL_MM_YN
        ,P_PGM_APPLY_YN
        ,PLAN_FLAG
        --,APPR_FLAG
        --,SVC_LVL_YN
        --,SVC_LVL_WHT
        ,REF_VERSION_ID 
        ,STATUS_CD
        --,PDB_VERSION_ID
        --,EXE_DTTM
        --,FINISH_DTTM
        --,EXE_USER_ID
        --,APPR_DTTM -- 20200406 Version  조회조건 정렬을 위한 임시 
        --,APPR_USER_ID
        ,REG_DTTM
        ,REG_USER_ID
        ) 
  SELECT O_sVERSION_ID              VERSION_ID  -- Plan Type + 실행 년월일 + 순번
        ,P_sENGINE_ID               ENGINE_ID
        ,SUBSTR(P_sBASE_MONTH,1,4)  BASE_YEAR
        ,P_sBASE_MONTH              BASE_MONTH
        ,P_sPLAN_DESC               VERSION_DESC
        ,P_sPLAN_TYPE               PLAN_TYPE
        ,G_sNEW_ROLL_MM_YN          NEW_ROLL_MM_YN
        ,NVL(P_sP_PGM_APPLY_YN, 'N') P_PGM_APPLY_YN
        ,'N'                        PLAN_FLAG
        --,'N'              APPR_FLAG
        --,'Y'              SVC_LVL_YN
        --,SVC_LVL_WHT
        ,P_sREF_VERSION_ID
        ,'W'                        STATUS_CD   -- INBOUND(S) -> INBOUND(E) -> ENGINE(S) -> ENGINE(E) -> OUTBOUND(S) -> OUTBOUND(E)     H:대기중, P:진행중, C:완료, E:에러
        --,PDB_VERSION_ID
        --,SYSDATE                    EXE_DTTM      
        --,FINISH_DTTM
        --,P_sEXE_USER_ID             EXE_USER_ID
        --,SYSDATE --,APPR_DTTM
        --,APPR_USER_ID
        ,SYSDATE                    REG_DTTM
        ,P_sEXE_USER_ID             REG_USER_ID
    FROM DUAL  
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
  COMMIT;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_END_SEQ, SQL%ROWCOUNT);
EXCEPTION
  WHEN USER_EXCEPTION THEN
    ROLLBACK;
    O_sFLAG    := 'F'; 
    O_sMSG     := G_sLOGMSG;
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';      
    O_sMSG     := G_sLOGMSG;
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);
END;

/

