create PROCEDURE "SP_UI_DP_19_Q1" (
    p_GRP_ID    IN VARCHAR2 := ''
  , p_UI_ID        IN VARCHAR2 := ''
  , p_GRID_ID        IN VARCHAR2 := ''
  , pRESULT       OUT SYS_REFCURSOR
) 
IS 


BEGIN


--SELECT     MS.ID    
--        ,MS.AUTH_TP_ID
--        ,MS.MEASURE_CONF_TP_ID AS MEASURE_CONF
--        ,MS.LV_MGMT_ID
--        ,MS.MEASURE_MST_ID
--        ,MS.VER_APPY_BASE_ID
--        ,MS.INPUT_YN
--        ,MS.DISP_NM
--        ,MS.SEQ
--        ,MS.ACTV_YN
--FROM    TB_DP_MEASURE_SETTING MS WITH 
--WHERE    MS.AUTH_TP_ID LIKE '%' || p_AUTH_TP_ID || '%'
--AND        MS.UI_ID    = p_UI_ID
--AND        MS.GRID_ID    = p_GRID_ID
--ORDER BY MS.SEQ, MS.MEASURE_CONF_TP_ID,MS.LV_MGMT_ID
--;


    OPEN pRESULT
    FOR
    SELECT MS.ID    
         , MS.UI_ID
         , MS.GRID_ID
         , GRP_ID       AS GRP_ID
         , MS.MEASURE_CONF_TP_ID
         , B.CONF_NM    AS MEASURE_CONF
         , CASE WHEN B.CONF_CD = 'DEMAND'   THEN MS.LV_MGMT_ID
                WHEN B.CONF_CD = 'ADDITION' THEN MS.MEASURE_MST_ID 
                END     AS MEASURE_CD
         , MS.VER_APPY_BASE_ID
         , MS.MEASURE_VAL_TP_ID
         , MS.INPUT_YN
         , DISP_NM
         , DISP_NM            AS DISP_NM_VAL
         , MS.SEQ
         , MS.ACTV_YN
         , MS.CREATE_BY
         , MS.CREATE_DTTM
         , MS.MODIFY_BY
         , MS.MODIFY_DTTM
      FROM TB_DP_MEASURE_SETTING MS
      LEFT OUTER JOIN TB_CM_COMM_CONFIG B 
        ON MS.MEASURE_CONF_TP_ID = B.ID
     WHERE B.CONF_GRP_CD = 'DP_MS_INPUT_TP'
       AND MS.GRP_ID = P_GRP_ID
       AND MS.UI_ID    = p_UI_ID 
       AND MS.GRID_ID    = p_GRID_ID
     ORDER BY MS.SEQ, MS.MEASURE_CONF_TP_ID,MS.LV_MGMT_ID;
END;

/

