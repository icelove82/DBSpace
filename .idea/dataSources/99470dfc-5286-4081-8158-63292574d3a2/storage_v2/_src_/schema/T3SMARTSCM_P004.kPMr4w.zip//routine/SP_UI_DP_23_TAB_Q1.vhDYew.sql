create PROCEDURE "SP_UI_DP_23_TAB_Q1" 
(p_VERSION_ID  IN VARCHAR2 := ''
,P_PLAN_TP_ID     IN VARCHAR2 :=''
, pRESULT       OUT SYS_REFCURSOR
) 
IS 
V_PLAN_TP CHAR(32);
BEGIN
/****************************************************************
    Get Version Info tab 1
    History (date / writer / comment)
    - 20210206 / kimsohee / add a second bucket info   
    - 20210709 / kimsohee / sk custom 
*****************************************************************/
OPEN pRESULT          
FOR 
SELECT	 VM.VER_ID	            	AS VER_ID	  
		,VM.BUKT	            	AS VER_BUCKET
		,VM.HORIZ		            AS VER_HORIZON
		,VM.FROM_DATE	            AS VER_FROM_DATE
		,VM.TO_DATE		            AS VER_TO_DATE
		,VM.DTF		            	AS VER_DTF
		,VM.DTF_DATE	            AS VER_DTF_DATE
		,NVL(VM.DESCRIP,' ')		AS VER_DESCRIP
        ,VM.PRICE_TP_ID             AS PRICE_TYPE
        ,VM.CURCY_TP_ID             AS CURRENCY_TYPE
        ,VER_S_BUCKET               AS VER_S_BUCKET
        ,VER_S_HORIZON              AS VER_S_HORIZON
        ,VER_S_HORIZON_DATE         AS VER_S_HORIZON_DATE
        ,VER_S_BUCKET2
        ,VER_S_HORIZON2
        ,VER_S_HORIZON_DATE2 
		,VD.CL_TP_ID
		,VD.CL_LV_MGMT_ID
		,VD.CL_STATUS_ID
        ,VM.DESCRIP AS VER_DESCRIP
FROM	TB_DP_CONTROL_BOARD_VER_DTL VD 
		INNER JOIN TB_DP_CONTROL_BOARD_VER_MST VM   
        ON VD.CONBD_VER_MST_ID = VM.ID
        LEFT OUTER JOIN TB_CM_COMM_CONFIG CO   
        ON VD.WORK_TP_ID = CO.ID AND CO.CONF_GRP_CD    = 'DP_WK_TP'        
WHERE	1=1
--AND		VD.MODULE_ID	= 'DP'
AND		VM.VER_ID		= p_VERSION_ID
AND		CO.CONF_CD     = 'CL'
AND     VD.PLAN_TP_ID = p_PLAN_TP_ID
    ;

END
;
/

