create PROCEDURE "SP_UI_DP_HD_38_Q1" 
(
         P_UNIT               IN CHAR := '' -- QTY/AMT
        ,pRESULT              OUT SYS_REFCURSOR  
)IS


BEGIN
----------------------------------------------------------------------------------------------------
    -- ？？ ？？？ν？？？
    -- ？？？？ ？？￥ / ？？？？ / ？？？？？？
    -- 20181219 / ？？？？？？, calendar ？？？ι？？？ ？？？？ / ？？？？？？
----------------------------------------------------------------------------------------------------
 OPEN pRESULT FOR 
    SELECT  
            case (SELECT USER FROM DUAL)
            WHEN 'MD01' THEN 'INDUST_VEHICL'
            ELSE 'CONSTR_EQUIP' END AS DB_NM
          , CASE WHEN SL.SRP_YN = 'Y' 
            THEN 'ABOARD' ELSE 'DIRECT' END             AS DIMENSION_01
          , CASE WHEN SL.SRP_YN = 'Y' 
            THEN AH.LVL03_NM ELSE AH.LVL02_NM END                                                AS DIMENSION_02  

          ,CASE WHEN TO_CHAR(DP.BUCKET_START_DATE, 'YYYY-MM') = TO_CHAR(DP.BUCKET_END_DATE, 'YYYY-MM')
                THEN TO_CHAR(DP.BUCKET_START_DATE, 'yyyy-MM')
                ELSE 'SUM-'
                ||TO_CHAR(DP.BUCKET_START_DATE, 'YYYY')||'.'
                ||TO_CHAR(DP.BUCKET_START_DATE, 'MM')||'~'||TO_CHAR(DP.BUCKET_END_DATE, 'MM')
                END                AS "DATE"  
        , CASE P_UNIT WHEN 'QTY' THEN SUM(NVL(YOY.QTY,0)) ELSE  SUM(NVL(YOY.AMT,0)) END  AS YOY --"？？？？ ？？？？(？？)"
        , CASE P_UNIT WHEN 'QTY' THEN SUM(NVL(WEK.QTY,0)) ELSE  SUM(NVL(WEK.AMT,0)) END  AS WEK --"？？？ ？？？？(？？)"
        , CASE P_UNIT WHEN 'QTY' THEN SUM(NVL(ACS.QTY,0)) ELSE  SUM(NVL(ACS.AMT,0)) END  AS ACS --"？？？？ ？？？？(？？)"
        , CASE P_UNIT WHEN 'QTY' 
                        THEN CASE SUM(NVL(YOY.QTY,0)) WHEN 0 THEN NULL ELSE (NVL(SUM(ACS.QTY),0)/SUM(YOY.QTY))*100 END  
                        ELSE CASE SUM(NVL(YOY.AMT,0)) WHEN 0 THEN NULL ELSE (NVL(SUM(ACS.AMT),0)/SUM(YOY.AMT))*100 END   
                        END AS MGMT_PLAN_ACHIEV_RATE --"？？？？？？？ ？？？？？？"     
        , CASE P_UNIT WHEN 'QTY'
                        THEN CASE SUM(NVL(WEK.QTY,0)) WHEN 0 THEN NULL ELSE (NVL(SUM(ACS.QTY),0)/SUM(WEK.QTY))*100 END  
                        ELSE CASE SUM(NVL(WEK.AMT,0)) WHEN 0 THEN NULL ELSE (NVL(SUM(ACS.AMT),0)/SUM(WEK.AMT))*100 END  
                        END AS SALES_PLAN_ACHIEV_RATE --"？？？？？？ ？？？？？？"     
      FROM (
                            SELECT  DO.ITEM_MST_ID 
                                  , DO.ACCOUNT_ID
                                  , CA.BUCKET_START_DATE
                                  , CA.BUCKET_END_DATE                                       
                              FROM (
                                    SELECT ITEM_MST_ID, ACCOUNT_ID
                                      FROM TB_DP_ENTRY DO
                                     WHERE 1=1  
                                       AND DO.VER_ID = (  SELECT MAX(DC.ID) KEEP (DENSE_RANK FIRST ORDER BY DC.CREATE_DTTM DESC) 
                                                           FROM TB_DP_CONTROL_BOARD_VER_MST DC
                                                                INNER JOIN 
                                                                TB_DP_CONTROL_BOARD_VER_DTL DT
                                                            ON DC.ID = DT.CONBD_VER_MST_ID
                                                           WHERE DT.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
                                                             AND DC.PLAN_TP_ID = ( SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01 = 'M')
                                                             AND DT.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
                                                           ) 
                                       AND DO.AUTH_TP_ID = (  SELECT MAX(DT.CL_LV_MGMT_ID) KEEP (DENSE_RANK FIRST ORDER BY DC.CREATE_DTTM DESC) 
                                                           FROM TB_DP_CONTROL_BOARD_VER_MST DC
                                                                INNER JOIN 
                                                                TB_DP_CONTROL_BOARD_VER_DTL DT
                                                            ON DC.ID = DT.CONBD_VER_MST_ID
                                                           WHERE DT.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
                                                             AND DC.PLAN_TP_ID = ( SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01 = 'M')
                                                             AND DT.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
                                                           )

                                    GROUP BY DO.ITEM_MST_ID ,DO.ACCOUNT_ID
                                   )DO 
                                   CROSS JOIN
                                   TABLE(FN_DP_TEMP_THREE_CAL(ADD_MONTHS(SYSDATE,-4), LAST_DAY(ADD_MONTHS(SYSDATE,-1)))) CA                           
                             WHERE 1=1  
                          GROUP BY DO.ITEM_MST_ID ,DO.ACCOUNT_ID, BUCKET_START_DATE, BUCKET_END_DATE       
            ) DP -- KEY
--           INNER JOIN
--           TB_DPD_ITEM_HIERACHY2 IH          
--        ON DP.ITEM_MST_ID = IH.ITEM_ID     
           INNER JOIN
           TB_DPD_ACCOUNT_HIERACHY2 AH          
        ON DP.ACCOUNT_ID = AH.ACCOUNT_ID
           LEFT OUTER JOIN
           TB_DP_SALES_LEVEL_MGMT SL
        ON SL.ID = AH.LVL04_ID       
        ----------------------------------------------------------------------------
               -- ？？？？ ？？？ 
        ----------------------------------------------------------------------------
        LEFT OUTER JOIN
        (SELECT ITEM_MST_ID, ACCOUNT_ID, CA.BUCKET_START_DATE , CA.BUCKET_END_DATE , SUM(QTY) AS QTY, SUM(AMT) AS AMT
           FROM (                            -- ？？？？？ Version ？？
                                     SELECT ITEM_MST_ID, ACCOUNT_ID, BASE_DATE AS BASE_DATE, SUM(QTY) AS QTY, SUM(AMT) AS AMT
                                      FROM TB_DP_ENTRY DO
                                     WHERE 1=1  
                                       AND DO.VER_ID = (  SELECT MAX(DC.ID) KEEP (DENSE_RANK FIRST ORDER BY DC.CREATE_DTTM DESC) 
                                                           FROM TB_DP_CONTROL_BOARD_VER_MST DC
                                                                INNER JOIN 
                                                                TB_DP_CONTROL_BOARD_VER_DTL DT
                                                            ON DC.ID = DT.CONBD_VER_MST_ID
                                                           WHERE DT.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
                                                             AND TO_CHAR(DC.CREATE_DTTM, 'YYYY') = TO_CHAR(SYSDATE, 'YYYY')-2   
                                                             AND TO_NUMBER(TO_CHAR(SYSDATE, 'MM')) BETWEEN 1 AND 3
                                                             AND DC.PLAN_TP_ID = ( SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01 = 'Y')
                                                             AND DT.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
                                                           ) 
                                       AND DO.AUTH_TP_ID = (  SELECT MAX(DT.CL_LV_MGMT_ID) KEEP (DENSE_RANK FIRST ORDER BY DC.CREATE_DTTM DESC) 
                                                           FROM TB_DP_CONTROL_BOARD_VER_MST DC
                                                                INNER JOIN 
                                                                TB_DP_CONTROL_BOARD_VER_DTL DT
                                                            ON DC.ID = DT.CONBD_VER_MST_ID
                                                           WHERE DT.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
                                                             AND TO_CHAR(DC.CREATE_DTTM, 'YYYY') = TO_CHAR(SYSDATE, 'YYYY')-2   
                                                             AND TO_NUMBER(TO_CHAR(SYSDATE, 'MM')) BETWEEN 1 AND 3
                                                             AND DC.PLAN_TP_ID = ( SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01 = 'Y')
                                                             AND DT.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
                                                           )     
                                       AND PLAN_TP_ID IN (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01  = 'Y')
                                    GROUP BY DO.ITEM_MST_ID ,DO.ACCOUNT_ID, BASE_DATE
                                    UNION
                                    -- ？？？ Version ？？
                                     SELECT ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, SUM(QTY), SUM(AMT)
                                      FROM TB_DP_ENTRY DO
                                     WHERE 1=1  
                                       AND DO.VER_ID = (  SELECT MAX(DC.ID) KEEP (DENSE_RANK FIRST ORDER BY DC.CREATE_DTTM DESC) 
                                                           FROM TB_DP_CONTROL_BOARD_VER_MST DC
                                                                INNER JOIN 
                                                                TB_DP_CONTROL_BOARD_VER_DTL DT
                                                            ON DC.ID = DT.CONBD_VER_MST_ID
                                                           WHERE DT.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
                                                             AND TO_CHAR(DC.CREATE_DTTM, 'YYYY') = TO_CHAR(SYSDATE, 'YYYY')-1
                                                             AND TO_NUMBER(TO_CHAR(SYSDATE, 'MM')) BETWEEN 2 AND 12
                                                             AND DC.PLAN_TP_ID = ( SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01 = 'Y')
                                                             AND DT.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
                                                           ) 
                                       AND DO.AUTH_TP_ID = (  SELECT MAX(DT.CL_LV_MGMT_ID) KEEP (DENSE_RANK FIRST ORDER BY DC.CREATE_dTTM DESC) 
                                                           FROM TB_DP_CONTROL_BOARD_VER_MST DC
                                                                INNER JOIN 
                                                                TB_DP_CONTROL_BOARD_VER_DTL DT
                                                            ON DC.ID = DT.CONBD_VER_MST_ID
                                                           WHERE DT.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
                                                             AND TO_CHAR(DC.CREATE_DTTM, 'YYYY') = TO_CHAR(SYSDATE, 'YYYY')-1
                                                             AND TO_NUMBER(TO_CHAR(SYSDATE, 'MM')) BETWEEN 2 AND 12
                                                             AND DC.PLAN_TP_ID = ( SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01 = 'Y')
                                                             AND DT.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
                                                           )   
                                       AND PLAN_TP_ID IN (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01  = 'Y')
                                    GROUP BY DO.ITEM_MST_ID ,DO.ACCOUNT_ID, BASE_DATE                                    
                        ) A
                                INNER JOIN
                                TABLE( FN_DP_TEMP_THREE_CAL( ADD_MONTHS(SYSDATE,-4), LAST_DAY(ADD_MONTHS(SYSDATE,-1)))) CA
                            ON A.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE      
                       GROUP BY ITEM_MST_ID, ACCOUNT_ID, CA.BUCKET_START_DATE , CA.BUCKET_END_DATE                             
                        ) YOY ON DP.ITEM_MST_ID = YOY.ITEM_MST_ID 
                            AND DP.ACCOUNT_ID = YOY.ACCOUNT_ID
                            AND YOY.BUCKET_START_DATE = DP.BUCKET_START_DATE AND YOY.BUCKET_END_DATE   = DP.BUCKET_END_DATE
              LEFT OUTER JOIN
             ----------------------------------------------------------------------------
                  -- ？？？ ？？？ 
             ----------------------------------------------------------------------------
             (         SELECT ITEM_MST_ID, ACCOUNT_ID, SUM(QTY) AS QTY, SUM(AMT) AS AMT,  CA.BUCKET_START_DATE, CA.BUCKET_END_DATE 
                         FROM (
                                 -- ？？？ ？？
                                 SELECT ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, SUM(QTY) AS QTY, SUM(AMT) AS AMT
                                      FROM TB_DP_ENTRY DO                                          
                                     WHERE 1=1  
                                       AND BASE_DATE BETWEEN TO_DATE(TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM')||'01', 'YYYYMMDD') AND LAST_DAY(ADD_MONTHS(SYSDATE,-1))
                                       AND DO.VER_ID = (  SELECT MAX(DC.ID) KEEP (DENSE_RANK FIRST ORDER BY DC.CREATE_DTTM DESC) 
                                                           FROM TB_DP_CONTROL_BOARD_VER_MST DC
                                                                INNER JOIN 
                                                                TB_DP_CONTROL_BOARD_VER_DTL DT
                                                            ON DC.ID = DT.CONBD_VER_MST_ID
                                                           WHERE DT.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
                                                             AND TO_DATE(TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM')||'01', 'YYYYMMDD') BETWEEN FROM_DATE AND TO_DATE
--                                                             AND TO_DATE = LAST_DAY(ADD_MONTHS(SYSDATE,-1))
                                                             AND DC.PLAN_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01  = 'M')
                                                             AND DT.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
                                                           ) 
                                       AND DO.AUTH_TP_ID = (  SELECT MAX(DT.CL_LV_MGMT_ID) KEEP (DENSE_RANK FIRST ORDER BY DC.CREATE_DTTM DESC) 
                                                           FROM TB_DP_CONTROL_BOARD_VER_MST DC
                                                                INNER JOIN 
                                                                TB_DP_CONTROL_BOARD_VER_DTL DT
                                                            ON DC.ID = DT.CONBD_VER_MST_ID
                                                           WHERE DT.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
                                                             AND  TO_DATE(TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM')||'01', 'YYYYMMDD') BETWEEN FROM_DATE AND TO_DATE
--                                                             AND TO_DATE = LAST_DAY(ADD_MONTHS(SYSDATE,-1))
                                                             AND DC.PLAN_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01  = 'M')
                                                             AND DT.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
                                                             )
                                    GROUP BY DO.ITEM_MST_ID ,DO.ACCOUNT_ID, BASE_DATE      
                                    UNION
                                    -- ？δ？ ？？
                                    SELECT ITEM_MST_ID, ACCOUNT_ID,BASE_DATE, SUM(QTY) AS QTY, SUM(AMT) AS AMT
                                      FROM TB_DP_ENTRY DO
                                     WHERE 1=1  
                                       AND BASE_DATE BETWEEN TO_DATE(TO_CHAR(ADD_MONTHS(SYSDATE,-2),'YYYYMM')||'01', 'YYYYMMDD') AND LAST_DAY(ADD_MONTHS(SYSDATE,-2))
                                       AND DO.VER_ID = (  SELECT MAX(DC.ID) KEEP (DENSE_RANK FIRST ORDER BY DC.CREATE_DTTM DESC) 
                                                           FROM TB_DP_CONTROL_BOARD_VER_MST DC
                                                                INNER JOIN 
                                                                TB_DP_CONTROL_BOARD_VER_DTL DT
                                                            ON DC.ID = DT.CONBD_VER_MST_ID
                                                           WHERE DT.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
                                                             AND  TO_DATE(TO_CHAR(ADD_MONTHS(SYSDATE,-2),'YYYYMM')||'01', 'YYYYMMDD') BETWEEN FROM_DATE AND TO_DATE
--                                                             AND TO_DATE = LAST_DAY(ADD_MONTHS(SYSDATE,-2))
                                                             AND DC.PLAN_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01  = 'M')
                                                             AND DT.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
                                                           ) 
                                       AND DO.AUTH_TP_ID = (  SELECT MAX(DT.CL_LV_MGMT_ID) KEEP (DENSE_RANK FIRST ORDER BY DC.CREATE_DTTM DESC) 
                                                           FROM TB_DP_CONTROL_BOARD_VER_MST DC
                                                                INNER JOIN 
                                                                TB_DP_CONTROL_BOARD_VER_DTL DT
                                                            ON DC.ID = DT.CONBD_VER_MST_ID
                                                           WHERE DT.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
                                                             AND TO_DATE(TO_CHAR(ADD_MONTHS(SYSDATE,-2),'YYYYMM')||'01', 'YYYYMMDD') BETWEEN FROM_DATE AND TO_DATE
--                                                             AND TO_DATE = LAST_DAY(ADD_MONTHS(SYSDATE,-2))
                                                             AND DC.PLAN_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01  = 'M')
                                                             AND DT.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
                                                           )     
                                    GROUP BY DO.ITEM_MST_ID ,DO.ACCOUNT_ID, BASE_DATE       
                                    UNION
                                    -- ？？？？ ？？
                                    SELECT ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, SUM(QTY) AS QTY, SUM(AMT) AS AMT
                                      FROM TB_DP_ENTRY DO
                                     WHERE 1=1  
                                       AND BASE_DATE BETWEEN TO_DATE(TO_CHAR(ADD_MONTHS(SYSDATE,-3),'YYYYMM')||'01', 'YYYYMMDD') AND LAST_DAY(ADD_MONTHS(SYSDATE,-3))
                                       AND DO.VER_ID = (  SELECT MAX(DC.ID) KEEP (DENSE_RANK FIRST ORDER BY DC.CREATE_DTTM DESC) 
                                                           FROM TB_DP_CONTROL_BOARD_VER_MST DC
                                                                INNER JOIN 
                                                                TB_DP_CONTROL_BOARD_VER_DTL DT
                                                            ON DC.ID = DT.CONBD_VER_MST_ID
                                                           WHERE DT.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE') 
                                                             AND TO_DATE(TO_CHAR(ADD_MONTHS(SYSDATE,-3),'YYYYMM')||'01', 'YYYYMMDD') BETWEEN FROM_DATE AND TO_DATE
--                                                             AND TO_DATE = LAST_DAY(ADD_MONTHS(SYSDATE,-3))
                                                             AND DC.PLAN_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01  = 'M')
                                                             AND DT.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
                                                           ) 
                                       AND DO.AUTH_TP_ID = (  SELECT MAX(DT.CL_LV_MGMT_ID) KEEP (DENSE_RANK FIRST ORDER BY DC.CREATE_DTTM DESC) 
                                                           FROM TB_DP_CONTROL_BOARD_VER_MST DC
                                                                INNER JOIN 
                                                                TB_DP_CONTROL_BOARD_VER_DTL DT
                                                            ON DC.ID = DT.CONBD_VER_MST_ID
                                                           WHERE DT.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
                                                             AND TO_DATE(TO_CHAR(ADD_MONTHS(SYSDATE,-3),'YYYYMM')||'01', 'YYYYMMDD') BETWEEN FROM_DATE AND TO_DATE
--                                                             AND TO_DATE = LAST_DAY(ADD_MONTHS(SYSDATE,-3))
                                                             AND DC.PLAN_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01  = 'M')
                                                             AND DT.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
                                                           )     
                                    GROUP BY DO.ITEM_MST_ID ,DO.ACCOUNT_ID, BASE_DATE   
                            ) A INNER JOIN
                                TABLE( FN_DP_TEMP_THREE_CAL( ADD_MONTHS(SYSDATE,-4), LAST_DAY(ADD_MONTHS(SYSDATE,-1)))) CA
                            ON A.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE    
                            GROUP BY ITEM_MST_ID, ACCOUNT_ID, CA.BUCKET_START_DATE, CA.BUCKET_END_DATE    
                       ) WEK ON DP.ITEM_MST_ID = WEK.ITEM_MST_ID 
                            AND DP.ACCOUNT_ID = WEK.ACCOUNT_ID
                            AND WEK.BUCKET_START_DATE = DP.BUCKET_START_DATE AND WEK.BUCKET_END_DATE = DP.BUCKET_END_DATE

             ----------------------------------------------------------------------------
                     --  ACTUAL_SALES
             ----------------------------------------------------------------------------
          LEFT OUTER JOIN
            (
              SELECT ITEM_MST_ID
                                 , ACCOUNT_ID
                                 , BUCKET_START_DATE
                                 , BUCKET_END_DATE
                                , SUM(QTY) AS QTY 
                                , SUM(AMT) AS AMT
                              FROM TB_CM_ACTUAL_SALES A 
                                   INNER JOIN
                                   TABLE( FN_DP_TEMP_THREE_CAL( ADD_MONTHS(SYSDATE,-4), LAST_DAY(ADD_MONTHS(SYSDATE,-1)) )) CA
                                ON A.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
               WHERE QTY > 0
                GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE, BUCKET_END_DATE
            ) ACS
             ON DP.ITEM_MST_ID = ACS.ITEM_MST_ID
            AND DP.ACCOUNT_ID = ACS.ACCOUNT_ID
            AND ACS.BUCKET_START_DATE = DP.BUCKET_START_DATE
            AND ACS.BUCKET_END_DATE = DP.BUCKET_END_DATE       
 GROUP BY            
            SL.SRP_YN
         ,  CASE WHEN SL.SRP_YN = 'Y' 
            THEN AH.LVL03_NM ELSE AH.LVL02_NM END                                                  
          ,CASE WHEN TO_CHAR(DP.BUCKET_START_DATE, 'YYYY-MM') = TO_CHAR(DP.BUCKET_END_DATE, 'YYYY-MM')
                THEN TO_CHAR(DP.BUCKET_START_DATE, 'yyyy-MM')
                ELSE 'SUM-'
                ||TO_CHAR(DP.BUCKET_START_DATE, 'YYYY')||'.'
                ||TO_CHAR(DP.BUCKET_START_DATE, 'MM')||'~'||TO_CHAR(DP.BUCKET_END_DATE, 'MM')
                END       
ORDER BY   
          SL.SRP_YN 
          ,CASE WHEN SL.SRP_YN = 'Y' THEN AH.LVL03_NM ELSE AH.LVL02_NM  END             
                ;
END
;


/

