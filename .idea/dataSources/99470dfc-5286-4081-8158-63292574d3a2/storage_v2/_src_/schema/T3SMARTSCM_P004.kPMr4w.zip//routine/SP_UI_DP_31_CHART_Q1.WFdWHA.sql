create PROCEDURE "SP_UI_DP_31_CHART_Q1" (
     p_PLAN_TP_ID 	VARCHAR2
    ,p_VER_ID		VARCHAR2
    ,p_AUTH_TP_ID	VARCHAR2
    ,p_BUCK			VARCHAR2
    ,p_STRT_DATE	DATE
    ,p_END_DATE		DATE
    ,p_OPTION		VARCHAR2
    ,p_USER_ID		VARCHAR2
    ,p_ITEM_CD		VARCHAR2
    ,p_ACCT_CD		VARCHAR2
    ,p_ITEM_LV_CD  	VARCHAR2
    ,p_ACCT_LV_CD  	VARCHAR2
    ,p_RT_MSG		OUT VARCHAR2
    ,pRESULT		OUT SYS_REFCURSOR
)IS

/*****************************************************************************
Title : [SP_UI_DP_31_CHART_Q1]
최초 작성자 : 한영석
최초 생성일 : 2017.12.06
 
설명 
 - RTF Analysis Report 그래프 쿼리
 
History (수정일자 / 수정자 / 수정내용)
- 2017.12.06 / 한영석 / 최초 작성
- 2018.12.21 / 김소희 / MAIN SELECT문 컨버팅   
- 2020.12.22 / 민경훈 / MSSQL -> ORACLE 
*****************************************************************************/

v_ERR_MSG		VARCHAR2(4000);
v_ERR_STATUS	INT 			:= NULL;
v_VER_ID		VARCHAR2(100)  	:= NULL;
v_AUTH_TP_ID	VARCHAR2(100)  	:= NULL;
v_BUCK			VARCHAR2(50)   	:= NULL;
v_STRT_DATE		DATE		   	:= NULL;
v_END_DATE		DATE		   	:= NULL;
v_OPTION		CHAR(1)		   	:=''   ;
v_ACCT_CD		VARCHAR2(4000)  := NULL;
v_ITEM_CD		VARCHAR2(4000)  := NULL;

BEGIN
	v_VER_ID		:= p_VER_ID;
	v_AUTH_TP_ID	:= p_AUTH_TP_ID;
	v_BUCK			:= p_BUCK;
	v_STRT_DATE		:= p_STRT_DATE;
	v_END_DATE		:= p_END_DATE;
	v_OPTION		:= p_OPTION;	
	v_ACCT_CD		:= p_ACCT_CD;		
	v_ITEM_CD		:= p_ITEM_CD;

    OPEN pRESULT FOR
    WITH RT AS (
        SELECT ITEM_MST_ID, ACCOUNT_ID, BASE_DATE
             , CASE v_OPTION WHEN 'Q' THEN QTY ELSE AMT END AS QTY
          FROM TB_DP_ENTRY
         WHERE VER_ID = p_VER_ID
           AND AUTH_TP_ID = v_AUTH_TP_ID
           AND BASE_DATE BETWEEN v_STRT_DATE AND v_END_DATE
    ), 
    VER AS (
        SELECT DISTINCT DO.ITEM_MST_ID ,DO.ACCOUNT_ID 
          FROM RT DO
         INNER JOIN (
            SELECT DISTINCT DESCENDANT_ID
              FROM TB_DPD_ITEM_HIER_CLOSURE 
             WHERE LEAF_YN = 'Y' 
               AND (REGEXP_LIKE(UPPER(ANCESTER_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                        OR v_ITEM_CD IS NULL
                )
--               AND CASE WHEN v_ITEM_CD LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(v_ITEM_CD,'') END IN (
--					SELECT TRIM(REGEXP_SUBSTR(v_ITEM_CD, '[^|]+', 1, LEVEL)) AS ITEM_CD
--						FROM DUAL
--					CONNECT BY INSTR(v_ITEM_CD, '|', 1, LEVEL - 1) > 0
--				)
--               AND CASE WHEN v_ITEM_CD NOT LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(v_ITEM_CD,'') END LIKE '%' || COALESCE(v_ITEM_CD,'') || '%'
         ) IT 
            ON IT.DESCENDANT_ID = DO.ITEM_MST_ID
               INNER JOIN
               (SELECT DISTINCT DESCENDANT_ID 
                  FROM TB_DPD_SALES_HIER_CLOSURE 
                 WHERE LEAF_YN = 'Y' 
                   AND (REGEXP_LIKE(UPPER(ANCESTER_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                        OR v_ACCT_CD IS NULL
                )
--                   AND CASE WHEN v_ACCT_CD LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(v_ACCT_CD,'') END IN (
--					SELECT TRIM(REGEXP_SUBSTR(v_ACCT_CD, '[^|]+', 1, LEVEL)) AS ACCT_CD
--						FROM DUAL
--					CONNECT BY INSTR(v_ACCT_CD, '|', 1, LEVEL - 1) > 0
--				)
--                   AND CASE WHEN v_ACCT_CD NOT LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(v_ACCT_CD,'') END LIKE '%' || COALESCE(v_ACCT_CD,'') || '%'
            ) AM
            ON AM.DESCENDANT_ID = DO.ACCOUNT_ID   
         WHERE 1=1  
           AND BASE_DATE BETWEEN v_STRT_DATE AND v_END_DATE
    ), 
    CAL AS (
        SELECT MIN(DAT) AS STRT_DATE
             , MAX(DAT) AS END_DATE
          FROM TB_CM_CALENDAR
         WHERE DAT BETWEEN v_STRT_DATE AND v_END_DATE
      GROUP BY TO_CHAR(YYYY)
             , CASE WHEN v_BUCK IN ('M', 'PW') THEN TO_CHAR(MM) ELSE '1' END 
             , CASE WHEN v_BUCK IN ('PW', 'W') THEN TO_CHAR(DP_WK) ELSE '1' END 
    ) 
---------------------------------------------------------------------------------------------------------------------------------------
	-- 본 프로시저
---------------------------------------------------------------------------------------------------------------------------------------		
	SELECT   M.STRT_DATE										AS "DATE"
	       , M.STRT_DATE										AS "CATEGORY"
		   , COALESCE(T_FINAL_DP.QTY, 0) 					AS FINAL_DP_QTY
		   , COALESCE(T_RTF.ON_TIME_QTY, 0) 					AS RTF
			/* 0으로 나누는 경우 예외처리 */
		   , CASE WHEN	COALESCE(T_FINAL_DP.QTY, 0)  = 0 THEN 0
				  ELSE	COALESCE(T_RTF.ON_TIME_QTY, 0) / COALESCE(T_FINAL_DP.QTY, 0)   * 100 END AS SALES_PLAN_SUPPLY_RATE			
        FROM CAL M	
        LEFT OUTER JOIN  (  
            SELECT STRT_DATE	AS BASE_DATE 
                 , sum(QTY) QTY 
              FROM RT A
             INNER JOIN VER    ON A.ITEM_MST_ID = VER.ITEM_MST_ID AND A.ACCOUNT_ID = VER.ACCOUNT_ID
	 		 INNER JOIN CAL CA ON A.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
             WHERE A.QTY > 0 
             GROUP BY STRT_DATE
	 	 ) T_FINAL_DP ON M.STRT_DATE = T_FINAL_DP.BASE_DATE 
        LEFT OUTER JOIN  (
             SELECT STRT_DATE 
                  , SUM(ON_TIME_QTY) ON_TIME_QTY 
               FROM TB_RT_DMND_ORD_TRACKING_MST A
	 		  INNER JOIN VER    ON VER.ITEM_MST_ID = A.ITEM_MST_ID AND VER.ACCOUNT_ID = A.ACCOUNT_ID
              INNER JOIN CAL CA ON A.DELIVY_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
              WHERE A.CONBD_MAIN_VER_DTL_ID = ( SELECT CONBD_MAIN_VER_DTL_ID
                                                  FROM (
                                                            SELECT CONBD_MAIN_VER_DTL_ID
                                                              FROM TB_RT_DMND_ORD_TRACKING_MST
                                                             ORDER BY CREATE_DTTM DESC
                                                  )
                                                 WHERE ROWNUM=1
                )
                AND A.ON_TIME_QTY > 0   
              GROUP BY STRT_DATE
         ) T_RTF ON  M.STRT_DATE = T_RTF.STRT_DATE 
    ;	
    P_RT_MSG := 'MSG_0003';

    EXCEPTION WHEN OTHERS THEN
              IF(SQLCODE = -20001)
              THEN
                  P_RT_MSG := sqlerrm;
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;
--END TRY
--BEGIN CATCH
--	IF (ERROR_MESSAGE() LIKE 'MSG_%')
--		BEGIN
--			SET v_ERR_MSG = ERROR_MESSAGE()
--			SET p_RT_MSG = v_ERR_MSG
--		END
--	ELSE 
--			THROW
----			EXEC SP_COMM_RAISE_ERR

END ;

/

