create PROCEDURE "SP_UI_DP_41_Q1" (
     p_MEASURE		VARCHAR2 := 'ACT_SALES' 
    ,p_ITEM_CD      VARCHAR2
    ,p_ITEM_NM      VARCHAR2
    ,p_ACCT_CD		VARCHAR2
    ,p_ACCT_NM		VARCHAR2
    ,p_FROM_DATE 	DATE
    ,p_TO_DATE 		DATE
    ,pRESULT        OUT SYS_REFCURSOR
)IS

p_SQL VARCHAR2(4000) := '';

BEGIN
    p_SQL := 'SELECT ITEM_CD, ACCOUNT_CD, ACCOUNT_NM, BASE_DATE'
    ||',A.ATTR_01 AS ACCT_ATTR_01'
    ||',A.ATTR_02 AS ACCT_ATTR_02'
    ||',A.ATTR_03 AS ACCT_ATTR_03'
    ||',A.ATTR_04 AS ACCT_ATTR_04'
    ||',A.ATTR_05 AS ACCT_ATTR_05'
    ||',A.ATTR_06 AS ACCT_ATTR_06'
    ||',A.ATTR_07 AS ACCT_ATTR_07'
    ||',A.ATTR_08 AS ACCT_ATTR_08'
    ||',A.ATTR_09 AS ACCT_ATTR_09'
    ||',A.ATTR_10 AS ACCT_ATTR_10'
    ||',A.ATTR_11 AS ACCT_ATTR_11'
    ||',A.ATTR_12 AS ACCT_ATTR_12'
    ||',A.ATTR_13 AS ACCT_ATTR_13'
    ||',A.ATTR_14 AS ACCT_ATTR_14'
    ||',A.ATTR_15 AS ACCT_ATTR_15'
    ||',A.ATTR_16 AS ACCT_ATTR_16'
    ||',A.ATTR_17 AS ACCT_ATTR_17'
    ||',A.ATTR_18 AS ACCT_ATTR_18'
    ||',A.ATTR_19 AS ACCT_ATTR_19'
    ||',A.ATTR_20 AS ACCT_ATTR_20'
             ||', '||p_MEASURE||'_QTY AS QTY'
             ||', '||p_MEASURE||'_AMT AS AMT'
          ||' FROM TB_DP_MEASURE_DATA M'
          ||     ' INNER JOIN TB_CM_ITEM_MST I'
          ||  ' ON I.ID = M.ITEM_MST_ID'
          || ' AND I.DP_PLAN_YN = ''Y'''
          || ' AND COALESCE(I.DEL_YN,''N'') = ''N'''
          ||     ' INNER JOIN TB_DP_ACCOUNT_MST A'
          ||  ' ON A.ID = M.ACCOUNT_ID'
          || ' AND A.ACTV_YN = ''Y'''
          || ' AND COALESCE(A.DEL_YN,''N'') = ''N'''
--          || CASE WHEN p_ITEM_CD LIKE '%|%' THEN ' WHERE ITEM_CD IN (
--					SELECT TRIM(REGEXP_SUBSTR(p_ITEM_CD, ''[^|]+'', 1, LEVEL)) AS ITEM_CD
--						FROM DUAL
--					CONNECT BY INSTR(p_ITEM_CD, ''|'', 1, LEVEL - 1) > 0
--				)' -- 다중검색
--                 ELSE ' WHERE UPPER(ITEM_CD) LIKE ''%'||COALESCE(UPPER(p_ITEM_CD),'')||'%''' -- 단일 LIKE검색
--            END
          || ' WHERE UPPER(ITEM_CD) LIKE ''%'||COALESCE(UPPER(p_ITEM_CD),'')||'%'''
--          || CASE WHEN p_ITEM_NM LIKE '%|%' THEN ' AND ITEM_NM IN (
--					SELECT TRIM(REGEXP_SUBSTR(p_ITEM_NM, ''[^|]+'', 1, LEVEL)) AS ITEM_CD
--						FROM DUAL
--					CONNECT BY INSTR(p_ITEM_NM, ''|'', 1, LEVEL - 1) > 0
--				)' -- 다중검색
--                 ELSE ' AND UPPER(ITEM_NM) LIKE ''%'||COALESCE(UPPER(p_ITEM_NM),'')||'%''' -- 단일 LIKE검색
--            END
          || ' AND UPPER(ITEM_NM) LIKE ''%'||COALESCE(UPPER(p_ITEM_NM),'')||'%'''
--          || CASE WHEN p_ACCT_CD LIKE '%|%' THEN ' AND ACCOUNT_CD IN (
--					SELECT TRIM(REGEXP_SUBSTR(p_ACCT_CD, ''[^|]+'', 1, LEVEL)) AS ITEM_CD
--						FROM DUAL
--					CONNECT BY INSTR(p_ACCT_CD, ''|'', 1, LEVEL - 1) > 0
--				)' -- 다중검색
--                 ELSE ' AND UPPER(ACCOUNT_CD) LIKE ''%'||COALESCE(UPPER(p_ACCT_CD),'')||'%''' -- 단일 LIKE 검색
--            END
          || ' AND UPPER(ACCOUNT_CD) LIKE ''%'||COALESCE(UPPER(p_ACCT_CD),'')||'%'''
--          || CASE WHEN p_ACCT_NM LIKE '%|%' THEN ' AND ACCOUNT_NM IN (
--					SELECT TRIM(REGEXP_SUBSTR(:p_ACCT_NM, ''[^|]+'', 1, LEVEL)) AS ITEM_CD
--						FROM DUAL
--					CONNECT BY INSTR(p_ACCT_NM, ''|'', 1, LEVEL - 1) > 0
--				)' -- 다중검색
--                 ELSE ' AND UPPER(ACCOUNT_NM) LIKE ''%'||COALESCE(UPPER(p_ACCT_NM),'')||'%''' -- LIKE 검색
--            END
          ||' AND UPPER(ACCOUNT_NM) LIKE ''%'||COALESCE(UPPER(p_ACCT_NM),'')||'%'''
          ||' AND BASE_DATE BETWEEN :p_FROM_DATE AND :p_TO_DATE'
          ||' AND ('||p_MEASURE||'_QTY IS NOT NULL OR '||p_MEASURE||'_AMT IS NOT NULL)'
          ;
        --EXEC SP_EXECUTESQL p_SQL, N'p_FROM_DATE AS DATE, p_TO_DATE AS DATE, p_ITEM_CD AS VARCHAR2(4000), p_ITEM_NM VARCHAR2(4000), p_ACCT_CD VARCHAR2(4000), p_ACCT_NM VARCHAR2(4000)', p_FROM_DATE, p_TO_DATE, p_ITEM_CD, p_ITEM_NM , p_ACCT_CD, p_ACCT_NM ;
--        EXECUTE IMMEDIATE p_SQL USING p_FROM_DATE, p_TO_DATE, p_ITEM_CD, p_ITEM_NM , p_ACCT_CD, p_ACCT_NM;
        OPEN pRESULT
        FOR p_SQL
        USING p_FROM_DATE, p_TO_DATE -- p_ITEM_CD, p_ITEM_NM, p_ACCT_CD, p_ACCT_NM, p_ACCT_NM,
        ;
END;
/

