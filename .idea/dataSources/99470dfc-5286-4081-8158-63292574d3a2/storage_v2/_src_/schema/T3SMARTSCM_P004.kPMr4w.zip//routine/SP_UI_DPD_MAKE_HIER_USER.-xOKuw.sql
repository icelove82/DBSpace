create PROCEDURE "SP_UI_DPD_MAKE_HIER_USER"  
IS          
/******************************************************************************************
	-- Create table 
	-- 2020.12.09 / kim sohee / oracle conveting
    -- 2021.03.10 / kim sohee / SK CUTOM
********************************************************************************************/
 v_depth       INT := 1;
 v_max_depth    INT;
 v_lv_cnt       INT;

 P_CHECK INT ;
BEGIN 
/***************************************************************************************************************************
    -- Create Table and Index
****************************************************************************************************************************/
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_USER_HIER_CLOSURE_01' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_USER_HIER_CLOSURE_01 ON TB_DPD_USER_HIER_CLOSURE (ANCS_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_USER_HIER_CLOSURE_02' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_USER_HIER_CLOSURE_02 ON TB_DPD_USER_HIER_CLOSURE (ANCS_CD)';
    END IF;

SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_USER_HIER_CLOSURE_03' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_USER_HIER_CLOSURE_03 ON TB_DPD_USER_HIER_CLOSURE (ANCS_ROLE_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_USER_HIER_CLOSURE_04' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_USER_HIER_CLOSURE_04 ON TB_DPD_USER_HIER_CLOSURE (ANCS_ROLE_CD)';
    END IF;



SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_USER_HIER_CLOSURE_05' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_USER_HIER_CLOSURE_05 ON TB_DPD_USER_HIER_CLOSURE (DESC_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_USER_HIER_CLOSURE_06' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_USER_HIER_CLOSURE_06 ON TB_DPD_USER_HIER_CLOSURE (DESC_CD)';
    END IF;


SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_USER_HIER_CLOSURE_07' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_USER_HIER_CLOSURE_07 ON TB_DPD_USER_HIER_CLOSURE (DESC_ROLE_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_USER_HIER_CLOSURE_08' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_USER_HIER_CLOSURE_08 ON TB_DPD_USER_HIER_CLOSURE (DESC_ROLE_CD)';
    END IF;    
/************************************************************************************************************************************************************************************************************
	-- Main Query
************************************************************************************************************************************************************************************************************/     
	DELETE FROM TB_DPD_USER_HIER_CLOSURE
	;

    INSERT INTO TB_DPD_USER_HIER_CLOSURE
	(    ANCS_ROLE_ID
		,ANCS_ROLE_CD
		,ANCS_ID 	 
		,ANCS_CD 	 
		,DESC_ROLE_ID
		,DESC_ROLE_CD
		,DESC_ID 	 
		,DESC_CD
		,USER_ACCT_YN		
		,MAPPING_SELF_YN
        ,MAIN_LV_YN
	)
	WITH SALES_LV
	AS (SELECT SL.ID
		     , LV.ID	AS LV_ID 
		     , LV.LV_CD AS LV_CD 
		     , LV.SEQ   AS LV_SEQ
		  FROM TB_DP_SALES_LEVEL_MGMT SL
			   INNER JOIN 
			   TB_CM_LEVEL_MGMT LV
			ON SL.LV_MGMT_ID = LV.ID
		   AND LV.ACTV_YN = 'Y'
		   AND NVL(LV.DEL_YN,'N') = 'N' 		
		WHERE SL.ACTV_YN = 'Y'
		  AND NVL(SL.DEL_YN,'N') = 'N'
	), ITEM
	AS (
	SELECT IT.ID 
	  FROM TB_CM_ITEM_MST IT	
		   INNER JOIN 
		   TB_CM_ITEM_LEVEL_MGMT IL
		ON IT.PARENT_ITEM_LV_ID = IL.ID
	   AND IL.ACTV_YN = 'Y'
	   AND NVL(IL.DEL_YN,'N') = 'N'
		   INNER JOIN 
		   TB_CM_LEVEL_MGMT LV
		ON IL.LV_MGMT_ID = LV.ID
	   AND LV.ACTV_YN = 'Y'
	   AND NVL(LV.DEL_YN,'N') = 'N' 	
  	 WHERE IT.DP_PLAN_YN = 'Y'
	   AND NVL(IT.DEL_YN,'N') = 'N' 	
	), ACCT
	AS (SELECT AM.ID 
		  FROM Tb_DP_ACCOUNT_MST AM 
			   INNER JOIN
			   SALES_LV SL 
			ON AM.PARENT_SALES_LV_ID = SL.ID
		 WHERE AM.ACTV_YN ='Y'
		   AND NVL(AM.DEL_YN,'N') = 'N'	
	), USER_INFO
	AS (
	    SELECT SALES_LV_ID SALES_ID
		     , RL.ID		AS ROLE_ID
			 , RL.LV_CD		AS ROLE_CD
			 , RL.SEQ		AS ROLE_SEQ 
			 , EMP_ID		AS EMP_ID
			 , EP.USERNAME AS EMP_NO
			 , 'Y'			AS MAPPING_SELF_YN
			 , 'Y'			AS USER_ACCT_YN
             , MAX(UA.MAIN_LV_YN) AS MAIN_LV_YN
		  FROM TB_DP_USER_ACCOUNT_MAP UA
			   INNER JOIN
			   SALES_LV SL
			ON UA.SALES_LV_ID = SL.ID
			   INNER JOIN
			   TB_CM_LEVEL_MGMT CL
			ON UA.LV_MGMT_ID = CL.ID
		   AND NVL(CL.DEL_YN,'N') = 'N'
		   AND CL.ACTV_YN = 'Y'
		   AND NVL(CL.LEAF_YN,'N') = 'N'
			   INNER JOIN
			   TB_CM_LEVEL_MGMT RL
			ON UA.AUTH_TP_ID = RL.ID
		   AND RL.ACTV_YN ='Y'
		   AND NVL(RL.DEL_YN,'N') = 'N'
			   INNER JOIN
			   TB_AD_USER EP
			ON EP.ID = UA.EMP_ID
	  GROUP BY EMP_ID, SALES_LV_ID, EP.USERNAME , ACCOUNT_ID, CL.LEAF_YN
			  , RL.ID	
			  , RL.LV_CD
			  , RL.SEQ 
		 UNION
	    SELECT ACCOUNT_ID	AS SALES_ID
		     , RL.ID		AS ROLE_ID
			 , RL.LV_CD		AS ROLE_CD
			 , RL.SEQ		AS ROLE_SEQ 
			 , EMP_ID		AS EMP_ID
			 , EP.USERNAME AS EMP_NO
			 , 'Y'			AS MAPPING_SELF_YN
			 , 'Y'			AS USER_ACCT_YN
             , MAX(UA.MAIN_LV_YN) AS MAIN_LV_YN
		  FROM TB_DP_USER_ACCOUNT_MAP UA
			   INNER JOIN 
			   ACCT AM
			ON UA.ACCOUNT_ID = AM.ID 
			   INNER JOIN
			   TB_CM_LEVEL_MGMT CL
			ON UA.LV_MGMT_ID = CL.ID
		   AND NVL(CL.DEL_YN,'N') = 'N'
		   AND CL.ACTV_YN = 'Y'
		   AND NVL(CL.LEAF_YN,'N') = 'Y'
			   INNER JOIN
			   TB_CM_LEVEL_MGMT RL
			ON UA.AUTH_TP_ID = RL.ID
		   AND RL.ACTV_YN ='Y'
		   AND NVL(RL.DEL_YN,'N') = 'N'
			   INNER JOIN
			   TB_AD_USER EP
			ON EP.ID = UA.EMP_ID
	  GROUP BY EMP_ID, SALES_LV_ID, EP.USERNAME , ACCOUNT_ID, CL.LEAF_YN
			  , RL.ID	
			  , RL.LV_CD
			  , RL.SEQ 
	     UNION  
	    SELECT UM.ACCOUNT_ID 
		     , RL.ID		AS ROLE_ID
			 , RL.LV_CD		AS ROLE_CD
			 , RL.SEQ		AS ROLE_SEQ 
			 , UM.EMP_ID
			 , EP.USERNAME AS USER_ID 
			 , 'Y'
			 , 'N'		AS USER_ACCT_YN
             , 'N'      AS MAIN_LV_YN
	      FROM TB_DP_USER_ITEM_ACCOUNT_MAP UM
			   INNER JOIN 
			   ITEM IT
			ON UM.ITEM_MST_ID = IT.ID 
			   INNER JOIN
			   ACCT AM
			ON UM.ACCOUNT_ID = AM.ID 
			   LEFT OUTER JOIN
			   (	SELECT EMP_ID, AUTH_TP_ID, COUNT(ACCOUNT_ID) AS CNT
					  FROM TB_DP_USER_ACCOUNT_MAP
					GROUP BY EMP_ID, AUTH_TP_ID
			   ) UA ON UM.EMP_ID = UA.EMP_ID 
				   AND UM.AUTH_TP_ID = UA.AUTH_TP_ID
			   INNER JOIN
			   TB_CM_LEVEL_MGMT RL
			ON UM.AUTH_TP_ID = RL.ID
		   AND RL.ACTV_YN ='Y'
		   AND NVL(RL.DEL_YN,'N') = 'N'
			   INNER JOIN
			   TB_AD_USER EP
			ON EP.ID = UM.EMP_ID
		 WHERE NVL(UA.CNT,0) = 0
	  GROUP BY UM.EMP_ID, EP.USERNAME, UM.ACCOUNT_ID 
			  , RL.ID	
			  , RL.LV_CD
			  , RL.SEQ
		UNION  
		SELECT SALES_LV_ID 
		     , SL.LV_ID 
			 , SL.LV_CD AS ROLE_CD
			 , SL.LV_SEQ		AS ROLE_SEQ 
			 , EMP_ID
			 , EP.USERNAME as USER_ID
			 , 'N'
			 , 'N'		AS USER_ACCT_YN
             , 'N'      AS MAIN_LV_YN             
		  FROM TB_DP_SALES_AUTH_MAP SA
			   INNER JOIN
			   SALES_LV SL
			ON SA.SALES_LV_ID = SL.ID
			   INNER JOIN
			   TB_AD_USER EP
			ON EP.ID = SA.EMP_ID
        UNION   -- OEM CUSTOM 
        SELECT SL.ID
             , LV.ID
             , LV.LV_CD
             , LV.SEQ
             , SL.ID
             , SL.SALES_LV_CD
             , 'N'
             , 'N'
             , 'N'
          FROM TB_CM_LEVEL_MGMT LV
               INNER JOIN
               TB_DP_SALES_LEVEL_MGMT SL
            ON LV.ID = SL.LV_MGMT_ID 
         WHERE SRP_LV_YN = 'Y'         
	), P_USER_INFO
	AS (
			SELECT SALES_ID				AS SALES_LV_ID		
				 , ROLE_ID				AS ROLE_ID	
				 , ROLE_CD				AS ROLE_CD	
				 , ROLE_SEQ 			AS ROLE_SEQ
				 , EMP_ID				AS EMP_ID		
				 , EMP_NO				AS EMP_NO		
				 , MAX(MAPPING_SELF_YN) AS MAPPING_SELF_YN 
				 , MAX(USER_ACCT_YN)	AS USER_ACCT_YN	
                 , MAX(MAIN_LV_YN)      AS MAIN_LV_YN
			  FROM USER_INFO 
		GROUP BY   SALES_ID
				 , ROLE_ID
				 , ROLE_CD
				 , ROLE_SEQ 
				 , EMP_ID
				 , EMP_NO	
	)	
		SELECT UH.ROLE_ID	 
			  ,UH.ROLE_CD
			  ,UH.EMP_ID		 AS MANAGER_ID
			  ,UH.EMP_NO 		 AS MANAGER_NO
			  ,UH.ROLE_ID 
			  ,UH.ROLE_CD
			  ,UH.EMP_ID
			  ,UH.EMP_NO 
			  ,MAX(UH.USER_ACCT_YN)		-- User Account mapping이 하나라도 있으면 'Y'
			  ,MAX(UH.MAPPING_SELF_YN)	-- 내가 관리하는 Sales level에 대해 내 매핑 정보가 하나라도 있으면 'Y'
              ,MAX(MAIN_LV_YN) AS MAIN_LV_YN
		  FROM P_USER_INFO UH 
	  GROUP BY  UH.ROLE_ID	
	  		   ,UH.ROLE_CD
	  		   ,UH.EMP_ID	
	  		   ,UH.EMP_NO 	
	  		   ,UH.ROLE_ID 
	  		   ,UH.ROLE_CD
	  		   ,UH.EMP_ID
	  		   ,UH.EMP_NO 
		;


	INSERT INTO TB_DPD_USER_HIER_CLOSURE
	(    ANCS_ROLE_ID
		,ANCS_ROLE_CD
		,ANCS_ID 	 
		,ANCS_CD 	 
		,DESC_ROLE_ID
		,DESC_ROLE_CD
		,DESC_ID 	 
		,DESC_CD
		,USER_ACCT_YN		
		,MAPPING_SELF_YN
        ,MAIN_LV_YN
	)
	WITH SALES_LV
	AS (SELECT SL.ID
		     , LV.ID	AS LV_ID 
		     , LV.LV_CD AS LV_CD 
		     , LV.SEQ   AS LV_SEQ
		  FROM TB_DP_SALES_LEVEL_MGMT SL
			   INNER JOIN 
			   TB_CM_LEVEL_MGMT LV
			ON SL.LV_MGMT_ID = LV.ID
		   AND LV.ACTV_YN = 'Y'
		   AND NVL(LV.DEL_YN,'N') = 'N' 		
		WHERE SL.ACTV_YN = 'Y'
		  AND NVL(SL.DEL_YN,'N') = 'N'
	), ITEM
	AS (
	SELECT IT.ID 
	  FROM TB_CM_ITEM_MST IT	
		   INNER JOIN 
		   TB_CM_ITEM_LEVEL_MGMT IL
		ON IT.PARENT_ITEM_LV_ID = IL.ID
	   AND IL.ACTV_YN = 'Y'
	   AND NVL(IL.DEL_YN,'N') = 'N'
		   INNER JOIN 
		   TB_CM_LEVEL_MGMT LV
		ON IL.LV_MGMT_ID = LV.ID
	   AND LV.ACTV_YN = 'Y'
	   AND NVL(LV.DEL_YN,'N') = 'N' 	
  	 WHERE IT.DP_PLAN_YN = 'Y'
	   AND NVL(IT.DEL_YN,'N') = 'N' 	
	), ACCT
	AS (SELECT AM.ID 
		  FROM Tb_DP_ACCOUNT_MST AM 
			   INNER JOIN
			   SALES_LV SL 
			ON AM.PARENT_SALES_LV_ID = SL.ID
		 WHERE AM.ACTV_YN ='Y'
		   AND NVL(AM.DEL_YN,'N') = 'N'	
	), USER_INFO
	AS (
	    SELECT SALES_LV_ID SALES_ID
		     , RL.ID		AS ROLE_ID
			 , RL.LV_CD		AS ROLE_CD
			 , RL.SEQ		AS ROLE_SEQ 
			 , EMP_ID		AS EMP_ID
			 , EP.USERNAME AS EMP_NO
			 , 'Y'			AS MAPPING_SELF_YN
			 , 'Y'			AS USER_ACCT_YN
             , MAX(MAIN_LV_YN) AS MAIN_LV_YN
		  FROM TB_DP_USER_ACCOUNT_MAP UA
			   INNER JOIN
			   SALES_LV SL
			ON UA.SALES_LV_ID = SL.ID
			   INNER JOIN
			   TB_CM_LEVEL_MGMT CL
			ON UA.LV_MGMT_ID = CL.ID
		   AND NVL(CL.DEL_YN,'N') = 'N'
		   AND CL.ACTV_YN = 'Y'
		   AND NVL(CL.LEAF_YN,'N') = 'N'
			   INNER JOIN
			   TB_CM_LEVEL_MGMT RL
			ON UA.AUTH_TP_ID = RL.ID
		   AND RL.ACTV_YN ='Y'
		   AND NVL(RL.DEL_YN,'N') = 'N'
			   INNER JOIN
			   TB_AD_USER EP
			ON EP.ID = UA.EMP_ID
	  GROUP BY EMP_ID, SALES_LV_ID, EP.USERNAME , ACCOUNT_ID, CL.LEAF_YN
			  , RL.ID	
			  , RL.LV_CD
			  , RL.SEQ 
		 UNION
	    SELECT ACCOUNT_ID	AS SALES_ID
		     , RL.ID		AS ROLE_ID
			 , RL.LV_CD		AS ROLE_CD
			 , RL.SEQ		AS ROLE_SEQ 
			 , EMP_ID		AS EMP_ID
			 , EP.USERNAME AS EMP_NO
			 , 'Y'			AS MAPPING_SELF_YN
			 , 'Y'			AS USER_ACCT_YN
             , MAX(MAIN_LV_YN) AS MAIN_LV_YN
		  FROM TB_DP_USER_ACCOUNT_MAP UA
			   INNER JOIN 
			   ACCT AM
			ON UA.ACCOUNT_ID = AM.ID 
			   INNER JOIN
			   TB_CM_LEVEL_MGMT CL
			ON UA.LV_MGMT_ID = CL.ID
		   AND NVL(CL.DEL_YN,'N') = 'N'
		   AND CL.ACTV_YN = 'Y'
		   AND NVL(CL.LEAF_YN,'N') = 'Y'
			   INNER JOIN
			   TB_CM_LEVEL_MGMT RL
			ON UA.AUTH_TP_ID = RL.ID
		   AND RL.ACTV_YN ='Y'
		   AND NVL(RL.DEL_YN,'N') = 'N'
			   INNER JOIN
			   TB_AD_USER EP
			ON EP.ID = UA.EMP_ID
	  GROUP BY EMP_ID, SALES_LV_ID, EP.USERNAME , ACCOUNT_ID, CL.LEAF_YN
			  , RL.ID	
			  , RL.LV_CD
			  , RL.SEQ 
	     UNION  
	    SELECT UM.ACCOUNT_ID 
		     , RL.ID		AS ROLE_ID
			 , RL.LV_CD		AS ROLE_CD
			 , RL.SEQ		AS ROLE_SEQ 
			 , UM.EMP_ID
			 , EP.USERNAME AS USER_ID
			 , 'Y'
			 , 'N'		AS USER_ACCT_YN
             , 'N'             
	      FROM TB_DP_USER_ITEM_ACCOUNT_MAP UM
			   INNER JOIN 
			   ITEM IT
			ON UM.ITEM_MST_ID = IT.ID 
			   INNER JOIN
			   ACCT AM
			ON UM.ACCOUNT_ID = AM.ID 
			   LEFT OUTER JOIN
			   (	SELECT EMP_ID, AUTH_TP_ID, COUNT(ACCOUNT_ID) AS CNT
					  FROM TB_DP_USER_ACCOUNT_MAP
					GROUP BY EMP_ID, AUTH_TP_ID
			   ) UA ON UM.EMP_ID = UA.EMP_ID 
				   AND UM.AUTH_TP_ID = UA.AUTH_TP_ID
			   INNER JOIN
			   TB_CM_LEVEL_MGMT RL
			ON UM.AUTH_TP_ID = RL.ID
		   AND RL.ACTV_YN ='Y'
		   AND NVL(RL.DEL_YN,'N') = 'N'
			   INNER JOIN
			   TB_AD_USER EP
			ON EP.ID = UM.EMP_ID
		 WHERE NVL(UA.CNT,0) = 0
	  GROUP BY UM.EMP_ID, EP.USERNAME, UM.ACCOUNT_ID 
			  , RL.ID	
			  , RL.LV_CD
			  , RL.SEQ
		UNION  
		SELECT SALES_LV_ID 
		     , SL.LV_ID 
			 , SL.LV_CD AS ROLE_CD
			 , SL.LV_SEQ		AS ROLE_SEQ 
			 , EMP_ID
			 , EP.USERNAME as USER_ID
			 , 'N'
			 , 'N'		AS USER_ACCT_YN
             , 'N'
		  FROM TB_DP_SALES_AUTH_MAP SA
			   INNER JOIN
			   SALES_LV SL
			ON SA.SALES_LV_ID = SL.ID
			   INNER JOIN
			   TB_AD_USER EP
			ON EP.ID = SA.EMP_ID
        UNION   -- OEM CUSTOM 
        SELECT SL.ID
             , LV.ID
             , LV.LV_CD
             , LV.SEQ
             , SL.ID
             , SL.SALES_LV_CD
             , 'N'
             , 'N'
             , 'N'
          FROM TB_CM_LEVEL_MGMT LV
               INNER JOIN
               TB_DP_SALES_LEVEL_MGMT SL
            ON LV.ID = SL.LV_MGMT_ID 
         WHERE SRP_LV_YN = 'Y'                 
	), P_USER_INFO
	AS (
			SELECT SALES_ID				AS SALES_LV_ID		
				 , ROLE_ID				AS ROLE_ID	
				 , ROLE_CD				AS ROLE_CD	
				 , ROLE_SEQ 			AS ROLE_SEQ
				 , EMP_ID				AS EMP_ID		
				 , EMP_NO				AS EMP_NO		
				 , MAX(MAPPING_SELF_YN) AS MAPPING_SELF_YN 
				 , MAX(USER_ACCT_YN)	AS USER_ACCT_YN	
                 , MAX(MAIN_LV_YN)      AS MAIN_LV_YN
			  FROM USER_INFO 
		GROUP BY   SALES_ID
				 , ROLE_ID
				 , ROLE_CD
				 , ROLE_SEQ 
				 , EMP_ID
				 , EMP_NO	
	)
		SELECT UH.ROLE_ID	 
			  ,UH.ROLE_CD
			  ,UH.EMP_ID		 AS MANAGER_ID
			  ,UH.EMP_NO 		 AS MANAGER_NO
			  ,US.ROLE_ID 
			  ,US.ROLE_CD
			  ,US.EMP_ID
			  ,US.EMP_NO 
			  ,MAX(US.USER_ACCT_YN)              
			  , CASE WHEN MAX(SRP_LV_YN) = 'N' THEN (SELECT CASE WHEN MAPPING_SELF_YN = 'Y' THEN 'N' ELSE 'Y' END
			       FROM TB_DPD_USER_HIER_CLOSURE
				  WHERE UH.EMP_ID = ANCS_ID 
				    AND UH.ROLE_ID = ANCS_ROLE_ID 
			   ) ELSE 'N' END
             , MAX(US.MAIN_LV_YN) 
		  FROM (
                SELECT SALES_LV_ID, EMP_ID, 'N' AS SRP_LV_YN 
                  FROM  TB_DP_SALES_AUTH_MAP 
                UNION   -- OEM CUSTOM 
                SELECT SL.ID
                     , SL.ID
                     , SRP_LV_YN 
                  FROM TB_CM_LEVEL_MGMT LV
                       INNER JOIN
                       TB_DP_SALES_LEVEL_MGMT SL
                    ON LV.ID = SL.LV_MGMT_ID 
                 WHERE SRP_LV_YN = 'Y'                                    
                )SA
		       INNER JOIN
			   P_USER_INFO UH 
			ON SA.EMP_ID = UH.EMP_ID
		   AND SA.SALES_LV_ID = UH.SALES_LV_ID
			   INNER JOIN
			   TB_DPD_SALES_HIER_CLOSURE SH			-- 해당 판매 레벨의 하위 계층 정보
			ON SA.SALES_LV_ID = SH.ANCESTER_ID
           AND SH.USE_YN = 'Y'
			   INNER JOIN
			   P_USER_INFO US
			ON SH.DESCENDANT_ID = US.SALES_LV_ID		
		 WHERE UH.ROLE_SEQ  <= US.ROLE_SEQ  		
		  AND  UH.EMP_ID != US.EMP_ID 
		  AND UH.ROLE_ID != US.ROLE_ID   
	GROUP BY   UH.ROLE_ID	 
			  ,UH.ROLE_CD
			  ,UH.EMP_ID		 
			  ,UH.EMP_NO 		 
			  ,US.ROLE_ID 
			  ,US.ROLE_CD
			  ,US.EMP_ID
			  ,US.EMP_NO 
	;



END
;
/

