create PROCEDURE SP_UI_CM_16_S1 (
    	 P_MODULE_ID               IN CHAR :=''
        ,P_DMND_MODULE_ID          IN VARCHAR2 := NULL
		,P_SCENARIO_DESC           IN VARCHAR2 := NULL
		,P_ACTV_YN                 IN VARCHAR2 := 'Y'
        ,P_USER_ID                 IN VARCHAR2 := ''
        ,P_RT_ROLLBACK_FLAG OUT VARCHAR2
        ,P_RT_MSG   OUT VARCHAR2                
)IS
        P_SET_ID CHAR(32) :='';
        P_PP_NAME VARCHAR2(30) :='';
        P_PREFIX VARCHAR2(50) :='';
        P_MAX_INT NUMBER:=0;
        T_VERSION VARCHAR2(100) :='';
    	P_ERR_STATUS NUMBER :=0;
    	P_ERR_MSG  VARCHAR2(4000) :='';             
        vDMND_MODULE_ID CHAR(32) := '';
    BEGIN
	    P_RT_ROLLBACK_FLAG := 'true'; 
        P_SET_ID := TO_SINGLE_BYTE(SYS_GUID());
        SELECT DISTINCT
            B.COMN_CD INTO P_PREFIX
	    FROM  TB_AD_COMN_GRP A 
        INNER JOIN TB_AD_COMN_CODE B 
        ON A.ID = B.SRC_ID
	     WHERE 1=1
	     AND A.GRP_CD='SCENARIO_VER_NAMING_RULE';

        SELECT MAX(TO_NUMBER(SUBSTR(A.SNRIO_VER_ID,-3))) INTO P_MAX_INT
        FROM TB_CM_PLAN_SNRIO_MGMT_MST A 
        WHERE 1=1
        AND A.MODULE_ID = P_MODULE_ID;

        T_VERSION := P_PREFIX||' - '||LPAD(NVL(P_MAX_INT,0)+1,3,'0');
       
        SELECT A.ID INTO vDMND_MODULE_ID
        FROM TB_AD_COMN_CODE A, TB_AD_COMN_GRP B
        WHERE 1=1
        AND A.SRC_ID = B.ID AND B.GRP_CD ='MODULE_TP'
        AND A.COMN_CD = P_DMND_MODULE_ID; 

      INSERT INTO TB_CM_PLAN_SNRIO_MGMT_MST
      (ID
	  ,MODULE_ID
      ,SNRIO_VER_ID
	  ,DESCRIP
      ,ACTV_YN
      ,CREATE_BY
      ,CREATE_DTTM
      ,MODIFY_BY
      ,MODIFY_DTTM
      ,DMND_MODULE_ID
      )
      SELECT  P_SET_ID  
	         ,P_MODULE_ID
      	     ,T_VERSION
			 ,P_SCENARIO_DESC
		     ,CASE WHEN P_ACTV_YN IN ('true','Y') then 'Y' ELSE 'N' END
      	     ,P_USER_ID
      	     ,SYSDATE
      	     ,P_USER_ID
      	     ,SYSDATE
             ,vDMND_MODULE_ID
        FROM DUAL;
        
        P_RT_ROLLBACK_FLAG := 'true';
		P_RT_MSG := 'MSG_0001';    

    EXCEPTION
    WHEN OTHERS THEN
        IF(SQLCODE = -20012)
          THEN 
              P_RT_ROLLBACK_FLAG := 'false';
              P_RT_MSG := P_ERR_MSG;
          ELSE
              RAISE;
          END IF; 
           END;

/

