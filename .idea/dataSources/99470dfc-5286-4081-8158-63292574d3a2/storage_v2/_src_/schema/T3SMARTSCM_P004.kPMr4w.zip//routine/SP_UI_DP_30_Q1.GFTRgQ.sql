create PROCEDURE "SP_UI_DP_30_Q1" (
     p_PLAN_TP_ID	VARCHAR2
    ,p_BUCK			VARCHAR2
    ,p_STRT_DATE	DATE
    ,p_END_DATE	  	DATE
    ,p_OPTION		CHAR
    ,p_USER_ID		VARCHAR2
    ,p_ITEM_CD      VARCHAR2
    ,p_ACCT_CD      VARCHAR2
    ,p_ITEM_LV_CD   VARCHAR2        
    ,p_ACCT_LV_CD   VARCHAR2 
    ,p_RT_MSG       OUT VARCHAR2
    ,pRESULT		OUT SYS_REFCURSOR
)IS


/*****************************************************************************
Title : [SP_UI_DP_30_Q1]
최초 작성자 : 한영석
최초 생성일 : 2017.06.20
 
설명 
 - Compare Sales & DP 그리드 조회 쿼리
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 한영석 / 최초 작성
- 2018.12.21 / 김소희 / MAIN SELECT문 컨버팅 
- 2020.12.22 / 민경훈 / MSSQL ->  ORACLE 
*****************************************************************************/

v_DIMENSION_01_ACTV_YN   CHAR(1)	:='Y';					   /* DIMENSION 조회 여부 */
v_DIMENSION_02_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_03_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_04_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_05_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_06_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_07_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_08_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_09_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_10_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_11_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_12_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_13_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_14_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_15_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_16_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_17_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_18_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_19_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_20_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_21_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_22_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_23_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_24_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_25_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_26_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_27_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_28_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_29_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_30_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_31_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_32_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_33_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_34_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_35_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_36_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_37_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_38_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_39_ACTV_YN   CHAR(1) 	:='Y';
v_DIMENSION_40_ACTV_YN   CHAR(1) 	:='Y';




v_ERR_MSG			VARCHAR2(4000) :='';
v_ERR_STATUS		INT := NULL;
v_SEARCH_LV_SEQ		INT := NULL;
v_SEARCH_LV_SEQ_02	INT := NULL;
v_ITEM_CHECK		INT	:= NULL;
v_ACCT_CHECK		INT	:= NULL;
v_ITEM_LV_CHECK		INT	:= NULL;
v_ACCT_LV_CHECK		INT	:= NULL;

v_LAST_ITEM_LV      INT;
v_LAST_ACCT_LV      INT;

v_BUCK				VARCHAR2(50) :='';
v_STRT_DATE			DATE := '';
v_END_DATE			DATE := '';
v_PLAN_TP_ID		VARCHAR2(100) :='';
v_ITEM_CD			VARCHAR2(4000) :='';
v_ACCT_CD			VARCHAR2(4000) :='';
v_ITEM_LV_CD		VARCHAR2(50) :='';
v_ACCT_LV_CD		VARCHAR2(50) :='';
v_OPTION			VARCHAR2(200) := '';

BEGIN 

	v_BUCK			:= p_BUCK       ;
	v_STRT_DATE		:= p_STRT_DATE  ;
	v_END_DATE		:= p_END_DATE   ;
	v_PLAN_TP_ID	:= p_PLAN_TP_ID ;
	v_ITEM_CD		:= p_ITEM_CD    ;
	v_ACCT_CD		:= p_ACCT_CD    ;
	v_ITEM_LV_CD	:= p_ITEM_LV_CD ;
	v_ACCT_LV_CD	:= p_ACCT_LV_CD ;
	v_OPTION		:= p_OPTION     ;

----------------------------------------------------------------------------------
    -- item level 혹은 ITEM CODE를 검색한다면 메시지 Validation
----------------------------------------------------------------------------------

	IF( v_ITEM_LV_CD IS NOT NULL OR v_ITEM_CD IS NOT NULL)
	THEN
		-- ITEM_LV_CD, ITEM_CD Validation
		SELECT COUNT(*) INTO v_ITEM_CHECK
		  FROM TB_CM_ITEM_MST
		 WHERE 1=1 
           AND (REGEXP_LIKE(UPPER(ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                            OR v_ITEM_CD IS NULL
                      )
--		    AND ITEM_CD IN (
--					SELECT TRIM(REGEXP_SUBSTR(v_ITEM_CD, '[^|]+', 1, LEVEL)) AS ITEM_CD
--						FROM DUAL
--					CONNECT BY INSTR(v_ITEM_CD, '|', 1, LEVEL - 1) > 0
--				)
		   AND COALESCE(DEL_YN,'N') = 'N'
		   AND DP_PLAN_YN = 'Y'
        ;

		SELECT COUNT(*) INTO v_ITEM_LV_CHECK
		  FROM TB_CM_ITEM_LEVEL_MGMT
		 WHERE 1=1 
		   AND ITEM_LV_CD = v_ITEM_LV_CD
		   AND COALESCE(DEL_YN,'N') = 'N'   
        ;
		IF(v_ITEM_CHECK !=0)    
        THEN
            -- ITEM 최하위 레벨로 SEQ 넣어주기
             SELECT MAX(SEARCH_LV_SEQ)+1 INTO v_SEARCH_LV_SEQ
                FROM (  SELECT DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ
                          FROM TB_CM_ITEM_LEVEL_MGMT IL
                               INNER JOIN TB_CM_LEVEL_MGMT LV ON(IL.LV_MGMT_ID = LV.ID)
                         WHERE 1=1
                           AND COALESCE(IL.DEL_YN,'N') = 'N'
                           AND COALESCE(LV.DEL_YN,'N') = 'N'   
                );
		ELSIF(v_ITEM_LV_CHECK != 0) -- account level 레벨로 SEQ 넣어주기
        THEN        
            SELECT SEARCH_LV_SEQ INTO v_SEARCH_LV_SEQ
              FROM (  SELECT IL.ITEM_LV_CD
                           , DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ
                        FROM TB_CM_ITEM_LEVEL_MGMT IL 
                       INNER JOIN TB_CM_LEVEL_MGMT LV ON(IL.LV_MGMT_ID = LV.ID)
                       WHERE 1=1
                         AND COALESCE(IL.DEL_YN,'N') = 'N'
                         AND COALESCE(LV.DEL_YN,'N') = 'N'   
              )
             WHERE ITEM_LV_CD = v_ITEM_LV_CD
             ;
		ELSE
            v_ERR_MSG := 'MSG_0020';
            RAISE_APPLICATION_ERROR(-20001, v_ERR_MSG);         
        END IF;
	END IF;
----------------------------------------------------------------------------------
    -- ACCOUNT LEVEL 혹은 ACCOUNT CODE를 검색한다면 메시지 Validation
----------------------------------------------------------------------------------
    IF( v_ACCT_LV_CD IS NOT NULL OR v_ACCT_CD IS NOT NULL)
	THEN    
    -- ACCT_LV_CD, ACCT_CD Validation
		SELECT COUNT(*) INTO v_ACCT_CHECK
		  FROM TB_DP_ACCOUNT_MST
		 WHERE 1=1
           AND (REGEXP_LIKE(UPPER(ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                            OR v_ACCT_CD IS NULL
                      )
--		   AND ACCOUNT_CD IN (
--					SELECT TRIM(REGEXP_SUBSTR(v_ACCT_CD, '[^|]+', 1, LEVEL)) AS ACCT_CD
--						FROM DUAL
--					CONNECT BY INSTR(v_ACCT_CD, '|', 1, LEVEL - 1) > 0
--				)
		   AND COALESCE(DEL_YN,'N') = 'N'
		   AND ACTV_YN = 'Y'
        ;
		SELECT COUNT(*) INTO v_ACCT_LV_CHECK
		  FROM TB_DP_SALES_LEVEL_MGMT
		 WHERE 1=1
		   AND SALES_LV_CD = v_ACCT_LV_CD
		   AND COALESCE(DEL_YN,'N') = 'N'
        ;
        IF(v_ACCT_CHECK != 0)  
		THEN  
            -- ACCOUNT 최하위 레벨로 SEQ 넣어주기
             SELECT MAX(SEARCH_LV_SEQ)+1 INTO v_SEARCH_LV_SEQ_02
               FROM ( SELECT DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ
                        FROM TB_DP_SALES_LEVEL_MGMT SL
                       INNER JOIN TB_CM_LEVEL_MGMT LV ON(SL.LV_MGMT_ID = LV.ID)
                       WHERE 1=1
                         AND COALESCE(SL.DEL_YN,'N') = 'N'
                         AND COALESCE(LV.DEL_YN,'N') = 'N'   
               )
             ;
        ELSIF(v_ACCT_LV_CHECK != 0) -- ACCOUNT LEVEL 레벨로 SEQ 넣어주기
        THEN
            SELECT SEARCH_LV_SEQ_02 INTO v_SEARCH_LV_SEQ_02
              FROM (  SELECT SL.SALES_LV_CD
                           , DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ_02
                        FROM TB_DP_SALES_LEVEL_MGMT SL
                       INNER JOIN TB_CM_LEVEL_MGMT LV ON(SL.LV_MGMT_ID = LV.ID)
                       WHERE 1=1
                         AND COALESCE(SL.DEL_YN,'N') = 'N'
                         AND COALESCE(LV.DEL_YN,'N') = 'N'   
               )
             WHERE SALES_LV_CD = v_ACCT_LV_CD
            ;
        ELSE 
            v_ERR_MSG := 'MSG_0020';
            RAISE_APPLICATION_ERROR(-20001, v_ERR_MSG);         
        END IF;
   END IF;

---------------------------------------------------------------------------------
    -- PLAN TYPE 에 해당하는 가장 최신 VERSION 찾기
---------------------------------------------------------------------------------


---------------------------------------------------------------------------------
    -- 개인화에서 DIMENSION 칼럼의 활성화 여부 값 가져오기
    ---- 20개까지 DIMENSION이 있을 것이라고 가정한 것 (하드코딩)
---------------------------------------------------------------------------------

-- 최하단 ITEM & ACCOUNT LV 셋팅
    SELECT CAST(SUBSTR(MAX(A.FLD_CD), 11,2) AS INT ) INTO v_LAST_ITEM_LV
     FROM  TB_AD_USER_PREF_DTL A 
     inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = 'UI_DP_30' and m.GRID_CD = 'RST_CPT_01' 
     inner join TB_AD_GROUP g on g.ID = A.GRP_ID 
     inner join TB_AD_USER u on u.USERNAME = p_USER_ID 
     inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
     LEFT OUTER JOIN TB_AD_USER_PREF B ON m.id = B.USER_PREF_MST_ID AND A.GRP_ID = B.GRP_ID	AND	A.FLD_CD = B.FLD_CD	AND B.USER_ID = u.ID					
    WHERE COALESCE(B.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N')) = 'Y' AND A.DIM_MEASURE_TP = 'DIMENSION'    AND SUBSTR(A.FLD_CD, 11,2) BETWEEN 1 AND 20   
    ;


    SELECT	CAST(SUBSTR(MAX(A.FLD_CD), 11,2) AS INT ) INTO v_LAST_ACCT_LV
    FROM	TB_AD_USER_PREF_DTL A 
    inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = 'UI_DP_30' and m.GRID_CD = 'RST_CPT_01' 
    inner join TB_AD_GROUP g on g.ID = A.GRP_ID
    inner join TB_AD_USER u on u.USERNAME = p_USER_ID 
    inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
    LEFT OUTER JOIN TB_AD_USER_PREF B  ON	m.id = B.USER_PREF_MST_ID AND A.GRP_ID = B.GRP_ID	AND	A.FLD_CD = B.FLD_CD	AND B.USER_ID = u.ID					
    WHERE COALESCE(B.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N')) = 'Y' AND A.DIM_MEASURE_TP = 'DIMENSION'    AND SUBSTR(A.FLD_CD, 11,2) BETWEEN 21 AND 40   
    ;
    SELECT MAX(CASE WHEN A.FLD_CD = 'DIMENSION_01' THEN A.ACTV_YN ELSE NULL END) 
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_02' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_03' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_04' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_05' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_06' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_07' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_08' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_09' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_10' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_11' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_12' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_13' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_14' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_15' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_16' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_17' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_18' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_19' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_20' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_21' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_22' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_23' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_24' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_25' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_26' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_27' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_28' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_29' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_30' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_31' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_32' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_33' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_34' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_35' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_36' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_37' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_38' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_39' THEN A.ACTV_YN ELSE NULL END)
        ,  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_40' THEN A.ACTV_YN ELSE NULL END)
           INTO
           v_DIMENSION_01_ACTV_YN
         , v_DIMENSION_02_ACTV_YN
         , v_DIMENSION_03_ACTV_YN
         , v_DIMENSION_04_ACTV_YN
         , v_DIMENSION_05_ACTV_YN
         , v_DIMENSION_06_ACTV_YN
         , v_DIMENSION_07_ACTV_YN
         , v_DIMENSION_08_ACTV_YN
         , v_DIMENSION_09_ACTV_YN
         , v_DIMENSION_10_ACTV_YN
         , v_DIMENSION_11_ACTV_YN
         , v_DIMENSION_12_ACTV_YN
         , v_DIMENSION_13_ACTV_YN
         , v_DIMENSION_14_ACTV_YN
         , v_DIMENSION_15_ACTV_YN
         , v_DIMENSION_16_ACTV_YN
         , v_DIMENSION_17_ACTV_YN
         , v_DIMENSION_18_ACTV_YN
         , v_DIMENSION_19_ACTV_YN
         , v_DIMENSION_20_ACTV_YN
         , v_DIMENSION_21_ACTV_YN
         , v_DIMENSION_22_ACTV_YN
         , v_DIMENSION_23_ACTV_YN
         , v_DIMENSION_24_ACTV_YN
         , v_DIMENSION_25_ACTV_YN
         , v_DIMENSION_26_ACTV_YN
         , v_DIMENSION_27_ACTV_YN
         , v_DIMENSION_28_ACTV_YN
         , v_DIMENSION_29_ACTV_YN
         , v_DIMENSION_30_ACTV_YN
         , v_DIMENSION_31_ACTV_YN
         , v_DIMENSION_32_ACTV_YN
         , v_DIMENSION_33_ACTV_YN
         , v_DIMENSION_34_ACTV_YN
         , v_DIMENSION_35_ACTV_YN
         , v_DIMENSION_36_ACTV_YN
         , v_DIMENSION_37_ACTV_YN
         , v_DIMENSION_38_ACTV_YN
         , v_DIMENSION_39_ACTV_YN
         , v_DIMENSION_40_ACTV_YN
    FROM ( 
                SELECT	 m.VIEW_CD
                        ,m.GRID_CD
                        ,g.GRP_CD
                        ,A.FLD_CD
                        ,A.REFER_VALUE
                        ,A.FLD_APPLY_CD
                        ,A.DIM_MEASURE_TP
                        ,A.CROSSTAB_ITEM_CD
                        ,A.FLD_SEQ AS SEQ_1, B.FLD_SEQ AS SEQ_2
                        , COALESCE(B.DATA_KEY_YN,COALESCE(A.DATA_KEY_YN,'N'))  AS DATA_KEY_YN 
                        , COALESCE(B.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N'))			 AS ACTV_YN 
                        , ROW_NUMBER() OVER( ORDER BY A.FLD_CD)   AS ROW_NUM 
                FROM	TB_AD_USER_PREF_DTL A 
                        inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = 'UI_DP_30'  AND m.GRID_CD	= 'RST_CPT_01'
                        inner join TB_AD_GROUP g on g.ID = A.GRP_ID 
                        inner join TB_AD_USER u on u.USERNAME = p_USER_ID
                        inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
                        LEFT OUTER JOIN TB_AD_USER_PREF B ON	m.id = B.USER_PREF_MST_ID	AND A.GRP_ID	= B.GRP_ID	AND	A.FLD_CD	= B.FLD_CD	AND B.USER_ID	= u.ID
                WHERE    A.CROSSTAB_ITEM_CD = 'GROUP-COLUMNS'
           )  A
    GROUP BY  CROSSTAB_ITEM_CD
    ;


----  ========================================
--  CODE   SETTING 
----   =======================================

----  ========================================
-- ITEM * MEASURE   SETTING 
----   =======================================

    IF( v_OPTION = 'Q')
	THEN
        OPEN pRESULT FOR
        SELECT --MES.ITEM_CD          AS ITEM 
                M.BUCKET_START_DATE   AS "DATE"  
                -----------------------
                -- DIMENSION:   LEVEL 값을 하드코딩 해야 함
                ----------------------- 
                -- ITEM
                , CASE WHEN v_DIMENSION_01_ACTV_YN = 'Y'  THEN ITEM_LVL01_CD	   ELSE NULL END AS DIMENSION_01
                , CASE WHEN v_DIMENSION_02_ACTV_YN = 'Y'  THEN ITEM_LVL01_NM       ELSE NULL END AS DIMENSION_02
                , CASE WHEN v_DIMENSION_03_ACTV_YN = 'Y'  THEN ITEM_LVL02_CD	   ELSE NULL END AS DIMENSION_03
                , CASE WHEN v_DIMENSION_04_ACTV_YN = 'Y'  THEN ITEM_LVL02_NM       ELSE NULL END AS DIMENSION_04
                , CASE WHEN v_DIMENSION_05_ACTV_YN = 'Y'  THEN ITEM_LVL03_CD       ELSE NULL END AS DIMENSION_05
                , CASE WHEN v_DIMENSION_06_ACTV_YN = 'Y'  THEN ITEM_LVL03_NM       ELSE NULL END AS DIMENSION_06
                , CASE WHEN v_DIMENSION_07_ACTV_YN = 'Y'  THEN ITEM_LVL04_CD       ELSE NULL END AS DIMENSION_07
                , CASE WHEN v_DIMENSION_08_ACTV_YN = 'Y'  THEN ITEM_LVL04_NM       ELSE NULL END AS DIMENSION_08
                , CASE WHEN v_DIMENSION_09_ACTV_YN = 'Y'  THEN ITEM_LVL05_CD	   ELSE NULL END AS DIMENSION_09
                , CASE WHEN v_DIMENSION_10_ACTV_YN = 'Y'  THEN ITEM_LVL05_NM       ELSE NULL END AS DIMENSION_10
                , CASE WHEN v_DIMENSION_11_ACTV_YN = 'Y'  THEN ITEM_LVL06_CD       ELSE NULL END AS DIMENSION_11
                , CASE WHEN v_DIMENSION_12_ACTV_YN = 'Y'  THEN ITEM_LVL06_NM       ELSE NULL END AS DIMENSION_12
                , CASE WHEN v_DIMENSION_13_ACTV_YN = 'Y'  THEN ITEM_LVL07_CD       ELSE NULL END AS DIMENSION_13
                , CASE WHEN v_DIMENSION_14_ACTV_YN = 'Y'  THEN ITEM_LVL07_NM       ELSE NULL END AS DIMENSION_14
                , CASE WHEN v_DIMENSION_15_ACTV_YN = 'Y'  THEN ITEM_LVL08_CD       ELSE NULL END AS DIMENSION_15
                , CASE WHEN v_DIMENSION_16_ACTV_YN = 'Y'  THEN ITEM_LVL08_NM       ELSE NULL END AS DIMENSION_16
                , CASE WHEN v_DIMENSION_17_ACTV_YN = 'Y'  THEN ITEM_LVL09_CD       ELSE NULL END AS DIMENSION_17
                , CASE WHEN v_DIMENSION_18_ACTV_YN = 'Y'  THEN ITEM_LVL09_NM       ELSE NULL END AS DIMENSION_18
                , CASE WHEN v_DIMENSION_19_ACTV_YN = 'Y'  THEN ITEM_LVL10_CD       ELSE NULL END AS DIMENSION_19
                , CASE WHEN v_DIMENSION_20_ACTV_YN = 'Y'  THEN ITEM_LVL10_NM       ELSE NULL END AS DIMENSION_20

                -- ACCOUNT
                , CASE WHEN v_DIMENSION_21_ACTV_YN = 'Y' THEN  ACCOUNT_LVL01_CD    ELSE NULL END AS DIMENSION_21
                , CASE WHEN v_DIMENSION_22_ACTV_YN = 'Y' THEN  ACCOUNT_LVL01_NM    ELSE NULL END AS DIMENSION_22
                , CASE WHEN v_DIMENSION_23_ACTV_YN = 'Y' THEN  ACCOUNT_LVL02_CD    ELSE NULL END AS DIMENSION_23
                , CASE WHEN v_DIMENSION_24_ACTV_YN = 'Y' THEN  ACCOUNT_LVL02_NM	   ELSE NULL END AS DIMENSION_24
                , CASE WHEN v_DIMENSION_25_ACTV_YN = 'Y' THEN  ACCOUNT_LVL03_CD    ELSE NULL END AS DIMENSION_25
                , CASE WHEN v_DIMENSION_26_ACTV_YN = 'Y' THEN  ACCOUNT_LVL03_NM    ELSE NULL END AS DIMENSION_26
                , CASE WHEN v_DIMENSION_27_ACTV_YN = 'Y' THEN  ACCOUNT_LVL04_CD    ELSE NULL END AS DIMENSION_27
                , CASE WHEN v_DIMENSION_28_ACTV_YN = 'Y' THEN  ACCOUNT_LVL04_NM    ELSE NULL END AS DIMENSION_28
                , CASE WHEN v_DIMENSION_29_ACTV_YN = 'Y' THEN  ACCOUNT_LVL05_CD    ELSE NULL END AS DIMENSION_29
                , CASE WHEN v_DIMENSION_30_ACTV_YN = 'Y' THEN  ACCOUNT_LVL05_NM    ELSE NULL END AS DIMENSION_30
                , CASE WHEN v_DIMENSION_31_ACTV_YN = 'Y' THEN  ACCOUNT_LVL06_CD    ELSE NULL END AS DIMENSION_31
                , CASE WHEN v_DIMENSION_32_ACTV_YN = 'Y' THEN  ACCOUNT_LVL06_NM    ELSE NULL END AS DIMENSION_32        
                , CASE WHEN v_DIMENSION_33_ACTV_YN = 'Y' THEN  ACCOUNT_LVL07_CD    ELSE NULL END AS DIMENSION_33
                , CASE WHEN v_DIMENSION_34_ACTV_YN = 'Y' THEN  ACCOUNT_LVL07_NM    ELSE NULL END AS DIMENSION_34
                , CASE WHEN v_DIMENSION_35_ACTV_YN = 'Y' THEN  ACCOUNT_LVL08_CD    ELSE NULL END AS DIMENSION_35
                , CASE WHEN v_DIMENSION_36_ACTV_YN = 'Y' THEN  ACCOUNT_LVL08_NM    ELSE NULL END AS DIMENSION_36
                , CASE WHEN v_DIMENSION_37_ACTV_YN = 'Y' THEN  ACCOUNT_LVL09_CD    ELSE NULL END AS DIMENSION_37
                , CASE WHEN v_DIMENSION_38_ACTV_YN = 'Y' THEN  ACCOUNT_LVL09_NM    ELSE NULL END AS DIMENSION_38
                , CASE WHEN v_DIMENSION_39_ACTV_YN = 'Y' THEN  ACCOUNT_LVL10_CD    ELSE NULL END AS DIMENSION_39
                , CASE WHEN v_DIMENSION_40_ACTV_YN = 'Y' THEN  ACCOUNT_LVL10_NM    ELSE NULL END AS DIMENSION_40
                , CASE v_LAST_ITEM_LV WHEN 1            THEN   ITEM_LVL01_CD
                                      WHEN 2            THEN   ITEM_LVL01_CD
                                      WHEN 3            THEN   ITEM_LVL02_CD
                                      WHEN 4            THEN   ITEM_LVL02_CD
                                      WHEN 5            THEN   ITEM_LVL03_CD
                                      WHEN 6            THEN   ITEM_LVL03_CD
                                      WHEN 7            THEN   ITEM_LVL04_CD
                                      WHEN 8            THEN   ITEM_LVL04_CD
                                      WHEN 9            THEN   ITEM_LVL05_CD
                                      WHEN 10           THEN   ITEM_LVL05_CD
                                      WHEN 11           THEN   ITEM_LVL06_CD
                                      WHEN 12           THEN   ITEM_LVL06_CD
                                      WHEN 13           THEN   ITEM_LVL07_CD
                                      WHEN 14           THEN   ITEM_LVL07_CD
                                      WHEN 15           THEN   ITEM_LVL08_CD
                                      WHEN 16           THEN   ITEM_LVL08_CD
                                      WHEN 17           THEN   ITEM_LVL09_CD
                                      WHEN 18           THEN   ITEM_LVL09_CD
                                      WHEN 19           THEN   ITEM_LVL10_CD
                                      WHEN 20           THEN   ITEM_LVL10_CD
                                      END	AS ITEM
                , CASE v_LAST_ACCT_LV WHEN 21           THEN   ACCOUNT_LVL01_CD
                                      WHEN 22           THEN   ACCOUNT_LVL01_CD
                                      WHEN 23           THEN   ACCOUNT_LVL02_CD
                                      WHEN 24           THEN   ACCOUNT_LVL02_CD
                                      WHEN 25           THEN   ACCOUNT_LVL03_CD
                                      WHEN 26           THEN   ACCOUNT_LVL03_CD
                                      WHEN 27           THEN   ACCOUNT_LVL04_CD
                                      WHEN 28           THEN   ACCOUNT_LVL04_CD
                                      WHEN 29           THEN   ACCOUNT_LVL05_CD
                                      WHEN 30           THEN   ACCOUNT_LVL05_CD
                                      WHEN 31           THEN   ACCOUNT_LVL06_CD
                                      WHEN 32           THEN   ACCOUNT_LVL06_CD
                                      WHEN 33           THEN   ACCOUNT_LVL07_CD
                                      WHEN 34           THEN   ACCOUNT_LVL07_CD
                                      WHEN 35           THEN   ACCOUNT_LVL08_CD
                                      WHEN 36           THEN   ACCOUNT_LVL08_CD
                                      WHEN 37           THEN   ACCOUNT_LVL09_CD
                                      WHEN 38           THEN   ACCOUNT_LVL09_CD
                                      WHEN 39           THEN   ACCOUNT_LVL10_CD
                                      WHEN 40           THEN   ACCOUNT_LVL10_CD
                                      END  AS ACCOUNT
                , 'COMMON'                  AS SALES
                -- MEASURE
                , SUM( COALESCE(T_ACTUAL_SALES.QTY, 0))		     										            AS MEASURE_01
                , SUM( COALESCE(T_ANNUAL_DP.QTY, 0))														        AS MEASURE_02
                , SUM( COALESCE(T_FINAL_DP.QTY, 0)) 										                        AS MEASURE_03
                , CASE WHEN	SUM( COALESCE(T_FINAL_DP.QTY, 0)) = 0  THEN 0
                       ELSE	SUM( COALESCE(T_ACTUAL_SALES.QTY, 0) ) / SUM( COALESCE(T_FINAL_DP.QTY, 0) ) * 100 END	AS MEASURE_04
               , CASE WHEN	SUM( COALESCE(T_ANNUAL_DP.QTY, 0)) = 0  THEN 0
                       ELSE	SUM( COALESCE(T_ACTUAL_SALES.QTY, 0) ) / SUM( COALESCE(T_ANNUAL_DP.QTY, 0) ) * 100 END  AS MEASURE_05
			FROM FN_DP_TEMP_REPORT_MAIN_TABLE(v_BUCK
                                            , v_STRT_DATE
                                            , v_END_DATE
                                            , CASE WHEN v_ITEM_CHECK = 0     THEN NULL ELSE v_ITEM_CD    END
                                            , CASE WHEN v_ACCT_CHECK =0      THEN NULL ELSE v_ACCT_CD    END
                                            , CASE WHEN v_ITEM_LV_CHECK = 0  THEN NULL ELSE v_ITEM_LV_CD END
                                            , CASE WHEN v_ACCT_LV_CHECK = 0  THEN NULL ELSE v_ACCT_LV_CD END
                                            , v_SEARCH_LV_SEQ
                                            , v_SEARCH_LV_SEQ_02
                                            , p_PLAN_TP_ID
                                            , p_USER_ID) M  
						   -------------------------------------- 
						   --  MEASURE 1 ACTUAL_SALES
						   -------------------------------------- 
            LEFT OUTER JOIN
                (
                    SELECT ITEM_MST_ID
                         , ACCOUNT_ID
                         , BUCKET_START_DATE
                         , sum(qty) qty 
                      FROM TB_CM_ACTUAL_SALES A 
                          ,FN_DP_TEMP_CAL( v_STRT_DATE, v_END_DATE, v_BUCK ) CA
                     WHERE A.QTY > 0 
                       AND A.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
                  GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE
                ) T_ACTUAL_SALES
                ON
                M.ITEM_ID = T_ACTUAL_SALES.ITEM_MST_ID
                AND M.ACCOUNT_ID = T_ACTUAL_SALES.ACCOUNT_ID
                AND T_ACTUAL_SALES.BUCKET_START_DATE = M.BUCKET_START_DATE-- AND M.BUCKET_END_DATE
--				 UNION ALL 
               -------------------------------------- 
               -- MEASURE 2 Annual DP 
               -------------------------------------- 
            LEFT OUTER JOIN 
                (
                    SELECT ITEM_MST_ID
                         , ACCOUNT_ID
                         , BUCKET_START_DATE
                         , sum(ANNUAL_qty) qty 
                      FROM TB_dP_MEASURE_DATA A 
                          ,FN_DP_TEMP_CAL( v_STRT_DATE, v_END_DATE, v_BUCK ) CA
                     WHERE A.ANNUAL_qty > 0 AND A.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
                  GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE
                ) T_ANNUAL_DP 
                ON
                M.ITEM_ID = T_ANNUAL_DP.ITEM_MST_ID
                AND M.ACCOUNT_ID = T_ANNUAL_DP.ACCOUNT_ID
                AND T_ANNUAL_DP.BUCKET_START_DATE = M.BUCKET_START_DATE

--             UNION ALL 
               -------------------------------------- 
               --  MEASURE 4 Final DP 
               -------------------------------------- 
			  LEFT OUTER JOIN 
                (
                    SELECT ITEM_MST_ID
                         , ACCOUNT_ID
                         , BUCKET_START_DATE
                         , sum(qty) qty 
                      FROM TB_DP_ENTRY_HISTORY A 
                           INNER JOIN
                           FN_DP_TEMP_CAL( v_STRT_DATE, v_END_DATE, v_BUCK ) CA
                        ON A.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
                    WHERE A.QTY > 0 
                      AND BASE_DATE BETWEEN p_STRT_DATE AND p_END_DATE
                      AND PLAN_tP_ID = p_PLAN_TP_ID
                 GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE
                ) T_FINAL_DP 
                ON M.ITEM_ID = T_FINAL_DP.ITEM_MST_ID 
            AND M.ACCOUNT_ID = T_FINAL_DP.ACCOUNT_ID
            AND T_FINAL_DP.BUCKET_START_DATE = M.BUCKET_START_DATE

	-- WHERE
    GROUP BY 	  
			  M.BUCKET_START_DATE
			, CASE WHEN v_DIMENSION_01_ACTV_YN = 'Y'  THEN ITEM_LVL01_CD	    ELSE NULL END 
			, CASE WHEN v_DIMENSION_02_ACTV_YN = 'Y'  THEN ITEM_LVL01_NM       ELSE NULL END
			, CASE WHEN v_DIMENSION_03_ACTV_YN = 'Y'  THEN ITEM_LVL02_CD	    ELSE NULL END 
			, CASE WHEN v_DIMENSION_04_ACTV_YN = 'Y'  THEN ITEM_LVL02_NM       ELSE NULL END 
			, CASE WHEN v_DIMENSION_05_ACTV_YN = 'Y'  THEN ITEM_LVL03_CD       ELSE NULL END
			, CASE WHEN v_DIMENSION_06_ACTV_YN = 'Y'  THEN ITEM_LVL03_NM       ELSE NULL END 
			, CASE WHEN v_DIMENSION_07_ACTV_YN = 'Y'  THEN ITEM_LVL04_CD       ELSE NULL END
			, CASE WHEN v_DIMENSION_08_ACTV_YN = 'Y'  THEN ITEM_LVL04_NM       ELSE NULL END
			, CASE WHEN v_DIMENSION_09_ACTV_YN = 'Y'  THEN ITEM_LVL05_CD       ELSE NULL END
			, CASE WHEN v_DIMENSION_10_ACTV_YN = 'Y'  THEN ITEM_LVL05_NM       ELSE NULL END
			, CASE WHEN v_DIMENSION_11_ACTV_YN = 'Y'  THEN ITEM_LVL06_CD       ELSE NULL END
			, CASE WHEN v_DIMENSION_12_ACTV_YN = 'Y'  THEN ITEM_LVL06_NM       ELSE NULL END
			, CASE WHEN v_DIMENSION_13_ACTV_YN = 'Y'  THEN ITEM_LVL07_CD       ELSE NULL END
			, CASE WHEN v_DIMENSION_14_ACTV_YN = 'Y'  THEN ITEM_LVL07_NM       ELSE NULL END
			, CASE WHEN v_DIMENSION_15_ACTV_YN = 'Y'  THEN ITEM_LVL08_CD       ELSE NULL END
			, CASE WHEN v_DIMENSION_16_ACTV_YN = 'Y'  THEN ITEM_LVL08_NM       ELSE NULL END
			, CASE WHEN v_DIMENSION_17_ACTV_YN = 'Y'  THEN ITEM_LVL09_CD       ELSE NULL END
			, CASE WHEN v_DIMENSION_18_ACTV_YN = 'Y'  THEN ITEM_LVL09_NM       ELSE NULL END
			, CASE WHEN v_DIMENSION_19_ACTV_YN = 'Y'  THEN ITEM_LVL10_CD       ELSE NULL END
			, CASE WHEN v_DIMENSION_20_ACTV_YN = 'Y'  THEN ITEM_LVL10_NM       ELSE NULL END

			-- ACCOUNT
			, CASE WHEN v_DIMENSION_21_ACTV_YN = 'Y'  THEN ACCOUNT_LVL01_CD       ELSE NULL END 
			, CASE WHEN v_DIMENSION_22_ACTV_YN = 'Y'  THEN ACCOUNT_LVL01_NM       ELSE NULL END 
			, CASE WHEN v_DIMENSION_23_ACTV_YN = 'Y'  THEN ACCOUNT_LVL02_CD       ELSE NULL END 
			, CASE WHEN v_DIMENSION_24_ACTV_YN = 'Y'  THEN ACCOUNT_LVL02_NM	   ELSE NULL END 
			, CASE WHEN v_DIMENSION_25_ACTV_YN = 'Y'  THEN ACCOUNT_LVL03_CD       ELSE NULL END
			, CASE WHEN v_DIMENSION_26_ACTV_YN = 'Y'  THEN ACCOUNT_LVL03_NM       ELSE NULL END 
			, CASE WHEN v_DIMENSION_27_ACTV_YN = 'Y'  THEN ACCOUNT_LVL04_CD       ELSE NULL END 
			, CASE WHEN v_DIMENSION_28_ACTV_YN = 'Y'  THEN ACCOUNT_LVL04_NM       ELSE NULL END 
			, CASE WHEN v_DIMENSION_29_ACTV_YN = 'Y'  THEN ACCOUNT_LVL05_CD       ELSE NULL END 
			, CASE WHEN v_DIMENSION_30_ACTV_YN = 'Y'  THEN ACCOUNT_LVL05_NM	   ELSE NULL END 
			, CASE WHEN v_DIMENSION_31_ACTV_YN = 'Y'  THEN ACCOUNT_LVL06_CD       ELSE NULL END
			, CASE WHEN v_DIMENSION_32_ACTV_YN = 'Y'  THEN ACCOUNT_LVL06_NM       ELSE NULL END 
			, CASE WHEN v_DIMENSION_33_ACTV_YN = 'Y'  THEN ACCOUNT_LVL07_CD       ELSE NULL END 
			, CASE WHEN v_DIMENSION_34_ACTV_YN = 'Y'  THEN ACCOUNT_LVL07_NM       ELSE NULL END 
			, CASE WHEN v_DIMENSION_35_ACTV_YN = 'Y'  THEN ACCOUNT_LVL08_CD       ELSE NULL END 
			, CASE WHEN v_DIMENSION_36_ACTV_YN = 'Y'  THEN ACCOUNT_LVL08_NM	   ELSE NULL END 
			, CASE WHEN v_DIMENSION_37_ACTV_YN = 'Y'  THEN ACCOUNT_LVL09_CD       ELSE NULL END
			, CASE WHEN v_DIMENSION_38_ACTV_YN = 'Y'  THEN ACCOUNT_LVL09_NM       ELSE NULL END 
			, CASE WHEN v_DIMENSION_39_ACTV_YN = 'Y'  THEN ACCOUNT_LVL10_CD       ELSE NULL END
			, CASE WHEN v_DIMENSION_40_ACTV_YN = 'Y'  THEN ACCOUNT_LVL10_NM       ELSE NULL END 
			, CASE v_LAST_ITEM_LV WHEN 1             THEN ITEM_LVL01_CD
								  WHEN 2              THEN ITEM_LVL01_CD
								  WHEN 3              THEN ITEM_LVL02_CD
								  WHEN 4              THEN ITEM_LVL02_CD
								  WHEN 5              THEN ITEM_LVL03_CD
								  WHEN 6              THEN ITEM_LVL03_cD
								  WHEN 7              THEN ITEM_LVL04_CD
								  WHEN 8              THEN ITEM_LVL04_CD
								  WHEN 9              THEN ITEM_LVL05_CD
								  WHEN 10             THEN ITEM_LVL05_CD
								  WHEN 11             THEN ITEM_LVL06_CD
								  WHEN 12             THEN ITEM_LVL06_CD
								  WHEN 13             THEN ITEM_LVL07_CD
								  WHEN 14             THEN ITEM_LVL07_CD
								  WHEN 15             THEN ITEM_LVL08_CD
								  WHEN 16             THEN ITEM_LVL08_cD
								  WHEN 17             THEN ITEM_LVL09_CD
								  WHEN 18             THEN ITEM_LVL09_CD
								  WHEN 19             THEN ITEM_LVL10_CD
								  WHEN 20             THEN ITEM_LVL10_CD
								  END	

			, CASE v_LAST_ACCT_LV WHEN 21            THEN ACCOUNT_LVL01_CD
								  WHEN 22             THEN ACCOUNT_LVL01_cD
								  WHEN 23             THEN ACCOUNT_LVL02_CD
								  WHEN 24             THEN ACCOUNT_LVL02_CD
								  WHEN 25             THEN ACCOUNT_LVL03_CD
								  WHEN 26             THEN ACCOUNT_LVL03_CD
								  WHEN 27             THEN ACCOUNT_LVL04_CD
								  WHEN 28             THEN ACCOUNT_LVL04_cD
								  WHEN 29             THEN ACCOUNT_LVL05_CD
								  WHEN 30             THEN ACCOUNT_LVL05_cD
								  WHEN 31             THEN ACCOUNT_LVL06_CD
								  WHEN 32             THEN ACCOUNT_LVL06_cD
								  WHEN 33             THEN ACCOUNT_LVL07_CD
								  WHEN 34             THEN ACCOUNT_LVL07_cD
								  WHEN 35             THEN ACCOUNT_LVL08_CD
								  WHEN 36             THEN ACCOUNT_LVL08_cD
								  WHEN 37             THEN ACCOUNT_LVL09_CD
								  WHEN 38             THEN ACCOUNT_LVL09_cD
								  WHEN 39             THEN ACCOUNT_LVL10_CD
								  WHEN 40             THEN ACCOUNT_LVL10_cD
					END
        ;
    ELSE
        OPEN pRESULT FOR
		SELECT --MES.ITEM_CD          AS ITEM 
				M.BUCKET_START_DATE   AS "DATE"  
				-----------------------
				-- DIMENSION:   LEVEL 값을 하드코딩 해야 함
				----------------------- 
				-- ITEM
				, CASE WHEN v_DIMENSION_01_ACTV_YN = 'Y'  THEN ITEM_LVL01_CD	    ELSE NULL END AS DIMENSION_01
				, CASE WHEN v_DIMENSION_02_ACTV_YN = 'Y'  THEN ITEM_LVL01_NM       ELSE NULL END AS DIMENSION_02
				, CASE WHEN v_DIMENSION_03_ACTV_YN = 'Y'  THEN ITEM_LVL02_CD	    ELSE NULL END AS DIMENSION_03
				, CASE WHEN v_DIMENSION_04_ACTV_YN = 'Y'  THEN ITEM_LVL02_NM       ELSE NULL END AS DIMENSION_04
				, CASE WHEN v_DIMENSION_05_ACTV_YN = 'Y'  THEN ITEM_LVL03_CD       ELSE NULL END AS DIMENSION_05
				, CASE WHEN v_DIMENSION_06_ACTV_YN = 'Y'  THEN ITEM_LVL03_NM       ELSE NULL END AS DIMENSION_06
				, CASE WHEN v_DIMENSION_07_ACTV_YN = 'Y'  THEN ITEM_LVL04_CD       ELSE NULL END AS DIMENSION_07
				, CASE WHEN v_DIMENSION_08_ACTV_YN = 'Y'  THEN ITEM_LVL04_NM       ELSE NULL END AS DIMENSION_08
				, CASE WHEN v_DIMENSION_09_ACTV_YN = 'Y'  THEN ITEM_LVL05_CD	    ELSE NULL END AS DIMENSION_09
				, CASE WHEN v_DIMENSION_10_ACTV_YN = 'Y'  THEN ITEM_LVL05_NM       ELSE NULL END AS DIMENSION_10
				, CASE WHEN v_DIMENSION_11_ACTV_YN = 'Y'  THEN ITEM_LVL06_CD       ELSE NULL END AS DIMENSION_11
				, CASE WHEN v_DIMENSION_12_ACTV_YN = 'Y'  THEN ITEM_LVL06_NM       ELSE NULL END AS DIMENSION_12
				, CASE WHEN v_DIMENSION_13_ACTV_YN = 'Y'  THEN ITEM_LVL07_CD       ELSE NULL END AS DIMENSION_13
				, CASE WHEN v_DIMENSION_14_ACTV_YN = 'Y'  THEN ITEM_LVL07_NM       ELSE NULL END AS DIMENSION_14
				, CASE WHEN v_DIMENSION_15_ACTV_YN = 'Y'  THEN ITEM_LVL08_CD       ELSE NULL END AS DIMENSION_15
				, CASE WHEN v_DIMENSION_16_ACTV_YN = 'Y'  THEN ITEM_LVL08_NM       ELSE NULL END AS DIMENSION_16
				, CASE WHEN v_DIMENSION_17_ACTV_YN = 'Y'  THEN ITEM_LVL09_CD       ELSE NULL END AS DIMENSION_17
				, CASE WHEN v_DIMENSION_18_ACTV_YN = 'Y'  THEN ITEM_LVL09_NM       ELSE NULL END AS DIMENSION_18
				, CASE WHEN v_DIMENSION_19_ACTV_YN = 'Y'  THEN ITEM_LVL10_CD       ELSE NULL END AS DIMENSION_19
				, CASE WHEN v_DIMENSION_20_ACTV_YN = 'Y'  THEN ITEM_LVL10_NM       ELSE NULL END AS DIMENSION_20

				-- ACCOUNT
				, CASE WHEN v_DIMENSION_21_ACTV_YN = 'Y'  THEN ACCOUNT_LVL01_CD       ELSE NULL END AS DIMENSION_21
				, CASE WHEN v_DIMENSION_22_ACTV_YN = 'Y'  THEN ACCOUNT_LVL01_NM       ELSE NULL END AS DIMENSION_22
				, CASE WHEN v_DIMENSION_23_ACTV_YN = 'Y'  THEN ACCOUNT_LVL02_CD       ELSE NULL END AS DIMENSION_23
				, CASE WHEN v_DIMENSION_24_ACTV_YN = 'Y'  THEN ACCOUNT_LVL02_NM	    ELSE NULL END AS DIMENSION_24
				, CASE WHEN v_DIMENSION_25_ACTV_YN = 'Y'  THEN ACCOUNT_LVL03_CD       ELSE NULL END AS DIMENSION_25
				, CASE WHEN v_DIMENSION_26_ACTV_YN = 'Y'  THEN ACCOUNT_LVL03_NM       ELSE NULL END AS DIMENSION_26
				, CASE WHEN v_DIMENSION_27_ACTV_YN = 'Y'  THEN ACCOUNT_LVL04_CD       ELSE NULL END AS DIMENSION_27
				, CASE WHEN v_DIMENSION_28_ACTV_YN = 'Y'  THEN ACCOUNT_LVL04_NM       ELSE NULL END AS DIMENSION_28
				, CASE WHEN v_DIMENSION_29_ACTV_YN = 'Y'  THEN ACCOUNT_LVL05_CD       ELSE NULL END AS DIMENSION_29
				, CASE WHEN v_DIMENSION_30_ACTV_YN = 'Y'  THEN ACCOUNT_LVL05_NM       ELSE NULL END AS DIMENSION_30
				, CASE WHEN v_DIMENSION_31_ACTV_YN = 'Y'  THEN ACCOUNT_LVL06_CD       ELSE NULL END AS DIMENSION_31
				, CASE WHEN v_DIMENSION_32_ACTV_YN = 'Y'  THEN ACCOUNT_LVL06_NM       ELSE NULL END AS DIMENSION_32        
				, CASE WHEN v_DIMENSION_33_ACTV_YN = 'Y'  THEN ACCOUNT_LVL07_CD       ELSE NULL END AS DIMENSION_33
				, CASE WHEN v_DIMENSION_34_ACTV_YN = 'Y'  THEN ACCOUNT_LVL07_NM       ELSE NULL END AS DIMENSION_34
				, CASE WHEN v_DIMENSION_35_ACTV_YN = 'Y'  THEN ACCOUNT_LVL08_CD       ELSE NULL END AS DIMENSION_35
				, CASE WHEN v_DIMENSION_36_ACTV_YN = 'Y'  THEN ACCOUNT_LVL08_NM       ELSE NULL END AS DIMENSION_36
				, CASE WHEN v_DIMENSION_37_ACTV_YN = 'Y'  THEN ACCOUNT_LVL09_CD       ELSE NULL END AS DIMENSION_37
				, CASE WHEN v_DIMENSION_38_ACTV_YN = 'Y'  THEN ACCOUNT_LVL09_NM       ELSE NULL END AS DIMENSION_38
				, CASE WHEN v_DIMENSION_39_ACTV_YN = 'Y'  THEN ACCOUNT_LVL10_CD       ELSE NULL END AS DIMENSION_39
				, CASE WHEN v_DIMENSION_40_ACTV_YN = 'Y'  THEN ACCOUNT_LVL10_NM       ELSE NULL END AS DIMENSION_40
				, CASE v_LAST_ITEM_LV WHEN 1             THEN ITEM_LVL01_CD
									  WHEN 2              THEN ITEM_LVL01_NM
									  WHEN 3              THEN ITEM_LVL02_CD
									  WHEN 4              THEN ITEM_LVL02_NM
									  WHEN 5              THEN ITEM_LVL03_CD
									  WHEN 6              THEN ITEM_LVL03_NM
									  WHEN 7              THEN ITEM_LVL04_CD
									  WHEN 8              THEN ITEM_LVL04_NM
									  WHEN 9              THEN ITEM_LVL05_CD
									  WHEN 10             THEN ITEM_LVL05_NM
									  WHEN 11             THEN ITEM_LVL06_CD
									  WHEN 12             THEN ITEM_LVL06_NM
									  WHEN 13             THEN ITEM_LVL07_CD
									  WHEN 14             THEN ITEM_LVL07_NM
									  WHEN 15             THEN ITEM_LVL08_CD
									  WHEN 16             THEN ITEM_LVL08_NM
									  WHEN 17             THEN ITEM_LVL09_CD
									  WHEN 18             THEN ITEM_LVL09_NM
									  WHEN 19             THEN ITEM_LVL10_CD
									  WHEN 20             THEN ITEM_LVL10_NM
									  END	AS ITEM

				, CASE v_LAST_ACCT_LV WHEN 21            THEN ACCOUNT_LVL01_CD
									  WHEN 22             THEN ACCOUNT_LVL01_NM
									  WHEN 23             THEN ACCOUNT_LVL02_CD
									  WHEN 24             THEN ACCOUNT_LVL02_NM
									  WHEN 25             THEN ACCOUNT_LVL03_CD
									  WHEN 26             THEN ACCOUNT_LVL03_NM
									  WHEN 27             THEN ACCOUNT_LVL04_CD
									  WHEN 28             THEN ACCOUNT_LVL04_NM
									  WHEN 29             THEN ACCOUNT_LVL05_CD
									  WHEN 30             THEN ACCOUNT_LVL05_NM
									  WHEN 31             THEN ACCOUNT_LVL06_CD
									  WHEN 32             THEN ACCOUNT_LVL06_NM
									  WHEN 33             THEN ACCOUNT_LVL07_CD
									  WHEN 34             THEN ACCOUNT_LVL07_NM
									  WHEN 35             THEN ACCOUNT_LVL08_CD
									  WHEN 36             THEN ACCOUNT_LVL08_NM
									  WHEN 37             THEN ACCOUNT_LVL09_CD
									  WHEN 38             THEN ACCOUNT_LVL09_NM
									  WHEN 39             THEN ACCOUNT_LVL10_CD
									  WHEN 40             THEN ACCOUNT_LVL10_NM
						END
						AS ACCOUNT
				, 'COMMON'                  AS SALES
				-- MEASURE
				, SUM( COALESCE(T_ACTUAL_SALES.AMT, 0))												                AS MEASURE_01
				, SUM( COALESCE(T_ANNUAL_DP.AMT, 0))													            AS MEASURE_02
                , SUM( COALESCE(T_FINAL_DP.AMT, 0)) 										                        AS MEASURE_03
                , CASE WHEN	SUM( COALESCE(T_FINAL_DP.AMT, 0)) = 0 THEN 0
                       ELSE	SUM( COALESCE(T_ACTUAL_SALES.AMT, 0) ) / SUM( COALESCE(T_FINAL_DP.AMT, 0) ) * 100 END   AS MEASURE_04
               , CASE WHEN	SUM( COALESCE(T_ANNUAL_DP.AMT, 0)) = 0 THEN 0
                       ELSE	SUM( COALESCE(T_ACTUAL_SALES.AMT, 0) ) / SUM( COALESCE(T_ANNUAL_DP.AMT, 0) ) * 100 END  AS MEASURE_05
				FROM     FN_DP_TEMP_REPORT_MAIN_TABLE(v_BUCK
                                                    , v_STRT_DATE
                                                    , v_END_DATE
                                                    , CASE WHEN v_ITEM_CHECK = 0     THEN NULL ELSE v_ITEM_CD    END
                                                    , CASE WHEN v_ACCT_CHECK =0      THEN NULL ELSE v_ACCT_CD    END
                                                    , CASE WHEN v_ITEM_LV_CHECK = 0  THEN NULL ELSE v_ITEM_LV_CD END
                                                    , CASE WHEN v_ACCT_LV_CHECK = 0  THEN NULL ELSE v_ACCT_LV_CD END
                                                    , v_SEARCH_LV_SEQ
                                                    , v_SEARCH_LV_SEQ_02
                                                    , p_PLAN_TP_ID
                                                    , p_USER_ID) M  
							   -------------------------------------- 
							   --  MEASURE 1 ACTUAL_SALES
							   -------------------------------------- 
                    LEFT OUTER JOIN
                        (
                            SELECT ITEM_MST_ID
                                 , ACCOUNT_ID
                                 , BUCKET_START_DATE
                                 , sum(AMT) amt 
                              FROM TB_CM_ACTUAL_SALES A 
                                  , FN_DP_TEMP_CAL( v_STRT_DATE, v_END_DATE, v_BUCK ) CA
                             WHERE A.AMT > 0 
                               AND A.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
                          GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE
                        ) T_ACTUAL_SALES
                        ON
                        M.ITEM_ID = T_ACTUAL_SALES.ITEM_MST_ID
                        AND M.ACCOUNT_ID = T_ACTUAL_SALES.ACCOUNT_ID
                        AND T_ACTUAL_SALES.BUCKET_START_DATE = M.BUCKET_START_DATE-- AND M.BUCKET_END_DATE

        --				 UNION ALL 
                       -------------------------------------- 
                       -- MEASURE 2 Annual DP 
                       -------------------------------------- 
                    LEFT OUTER JOIN 
                        (
                            SELECT ITEM_MST_ID
                                 , ACCOUNT_ID
                                 , BUCKET_START_DATE
                                 , sum(ANNUAL_amt) amt 
                              FROM TB_DP_MEASURE_DATA A 
                                  , FN_DP_TEMP_CAL( v_STRT_DATE, v_END_DATE, v_BUCK ) CA
                             WHERE A.ANNUAL_amt > 0 AND A.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
                          GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE
                        ) T_ANNUAL_DP 
                        ON
                        M.ITEM_ID = T_ANNUAL_DP.ITEM_MST_ID
                        AND M.ACCOUNT_ID = T_ANNUAL_DP.ACCOUNT_ID
                        AND T_ANNUAL_DP.BUCKET_START_DATE = M.BUCKET_START_DATE
        --             UNION ALL 


                       -------------------------------------- 
                       --  MEASURE 4 Final DP 
                       -------------------------------------- 
				  LEFT OUTER JOIN (
                        SELECT ITEM_MST_ID
                             , ACCOUNT_ID
                             , BUCKET_START_DATE
                             , sum(amt) amt 
                          FROM TB_DP_ENTRY_HISTORY A 
                               INNER JOIN
                               FN_DP_TEMP_CAL( v_STRT_DATE, v_END_DATE, v_BUCK ) CA
                            ON A.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
                        WHERE A.AMT > 0 
                          AND BASE_DATE BETWEEN p_STRT_DATE AND p_END_DATE
                          AND PLAN_TP_ID = p_PLAN_TP_ID
                     GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE
                    ) T_FINAL_DP ON M.ITEM_ID = T_FINAL_DP.ITEM_MST_ID 
            AND M.ACCOUNT_ID = T_FINAL_DP.ACCOUNT_ID
            AND T_FINAL_DP.BUCKET_START_DATE = M.BUCKET_START_DATE


		-- WHERE
		GROUP BY 	  
				  M.BUCKET_START_DATE
				, CASE WHEN v_DIMENSION_01_ACTV_YN = 'Y' THEN ITEM_LVL01_CD	    ELSE NULL END 
				, CASE WHEN v_DIMENSION_02_ACTV_YN = 'Y' THEN ITEM_LVL01_NM       ELSE NULL END
				, CASE WHEN v_DIMENSION_03_ACTV_YN = 'Y' THEN ITEM_LVL02_CD	    ELSE NULL END 
				, CASE WHEN v_DIMENSION_04_ACTV_YN = 'Y' THEN ITEM_LVL02_NM       ELSE NULL END 
				, CASE WHEN v_DIMENSION_05_ACTV_YN = 'Y' THEN ITEM_LVL03_CD       ELSE NULL END
				, CASE WHEN v_DIMENSION_06_ACTV_YN = 'Y' THEN ITEM_LVL03_NM       ELSE NULL END 
				, CASE WHEN v_DIMENSION_07_ACTV_YN = 'Y' THEN ITEM_LVL04_CD       ELSE NULL END
				, CASE WHEN v_DIMENSION_08_ACTV_YN = 'Y' THEN ITEM_LVL04_NM       ELSE NULL END
				, CASE WHEN v_DIMENSION_09_ACTV_YN = 'Y' THEN ITEM_LVL05_CD       ELSE NULL END
				, CASE WHEN v_DIMENSION_10_ACTV_YN = 'Y' THEN ITEM_LVL05_NM       ELSE NULL END
				, CASE WHEN v_DIMENSION_11_ACTV_YN = 'Y' THEN ITEM_LVL06_CD       ELSE NULL END
				, CASE WHEN v_DIMENSION_12_ACTV_YN = 'Y' THEN ITEM_LVL06_NM       ELSE NULL END
				, CASE WHEN v_DIMENSION_13_ACTV_YN = 'Y' THEN ITEM_LVL07_CD       ELSE NULL END
				, CASE WHEN v_DIMENSION_14_ACTV_YN = 'Y' THEN ITEM_LVL07_NM       ELSE NULL END
				, CASE WHEN v_DIMENSION_15_ACTV_YN = 'Y' THEN ITEM_LVL08_CD       ELSE NULL END
				, CASE WHEN v_DIMENSION_16_ACTV_YN = 'Y' THEN ITEM_LVL08_NM       ELSE NULL END
				, CASE WHEN v_DIMENSION_17_ACTV_YN = 'Y' THEN ITEM_LVL09_CD       ELSE NULL END
				, CASE WHEN v_DIMENSION_18_ACTV_YN = 'Y' THEN ITEM_LVL09_NM       ELSE NULL END
				, CASE WHEN v_DIMENSION_19_ACTV_YN = 'Y' THEN ITEM_LVL10_CD       ELSE NULL END
				, CASE WHEN v_DIMENSION_20_ACTV_YN = 'Y' THEN ITEM_LVL10_NM       ELSE NULL END

				-- ACCOUNT
				, CASE WHEN v_DIMENSION_21_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_CD       ELSE NULL END 
				, CASE WHEN v_DIMENSION_22_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_NM       ELSE NULL END 
				, CASE WHEN v_DIMENSION_23_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_CD       ELSE NULL END 
				, CASE WHEN v_DIMENSION_24_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_NM	    ELSE NULL END 
				, CASE WHEN v_DIMENSION_25_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_CD       ELSE NULL END
				, CASE WHEN v_DIMENSION_26_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_NM       ELSE NULL END 
				, CASE WHEN v_DIMENSION_27_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_CD       ELSE NULL END 
				, CASE WHEN v_DIMENSION_28_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_NM       ELSE NULL END 
				, CASE WHEN v_DIMENSION_29_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_CD       ELSE NULL END 
				, CASE WHEN v_DIMENSION_30_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_NM	    ELSE NULL END 
				, CASE WHEN v_DIMENSION_31_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_CD       ELSE NULL END
				, CASE WHEN v_DIMENSION_32_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_NM       ELSE NULL END 
				, CASE WHEN v_DIMENSION_33_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_CD       ELSE NULL END 
				, CASE WHEN v_DIMENSION_34_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_NM       ELSE NULL END 
				, CASE WHEN v_DIMENSION_35_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_CD       ELSE NULL END 
				, CASE WHEN v_DIMENSION_36_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_NM	    ELSE NULL END 
				, CASE WHEN v_DIMENSION_37_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_CD       ELSE NULL END
				, CASE WHEN v_DIMENSION_38_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_NM       ELSE NULL END 
				, CASE WHEN v_DIMENSION_39_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_CD       ELSE NULL END
				, CASE WHEN v_DIMENSION_40_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_NM       ELSE NULL END 
				, CASE v_LAST_ITEM_LV WHEN 1             THEN ITEM_LVL01_CD
									  WHEN 2              THEN ITEM_LVL01_NM
									  WHEN 3              THEN ITEM_LVL02_CD
									  WHEN 4              THEN ITEM_LVL02_NM
									  WHEN 5              THEN ITEM_LVL03_CD
									  WHEN 6              THEN ITEM_LVL03_NM
									  WHEN 7              THEN ITEM_LVL04_CD
									  WHEN 8              THEN ITEM_LVL04_NM
									  WHEN 9              THEN ITEM_LVL05_CD
									  WHEN 10             THEN ITEM_LVL05_NM
									  WHEN 11             THEN ITEM_LVL06_CD
									  WHEN 12             THEN ITEM_LVL06_NM
									  WHEN 13             THEN ITEM_LVL07_CD
									  WHEN 14             THEN ITEM_LVL07_NM
									  WHEN 15             THEN ITEM_LVL08_CD
									  WHEN 16             THEN ITEM_LVL08_NM
									  WHEN 17             THEN ITEM_LVL09_CD
									  WHEN 18             THEN ITEM_LVL09_NM
									  WHEN 19             THEN ITEM_LVL10_CD
									  WHEN 20             THEN ITEM_LVL10_NM
									  END	

				, CASE v_LAST_ACCT_LV WHEN 21             THEN ACCOUNT_LVL01_CD
									  WHEN 22             THEN ACCOUNT_LVL01_NM
									  WHEN 23             THEN ACCOUNT_LVL02_CD
									  WHEN 24             THEN ACCOUNT_LVL02_NM
									  WHEN 25             THEN ACCOUNT_LVL03_CD
									  WHEN 26             THEN ACCOUNT_LVL03_NM
									  WHEN 27             THEN ACCOUNT_LVL04_CD
									  WHEN 28             THEN ACCOUNT_LVL04_NM
									  WHEN 29             THEN ACCOUNT_LVL05_CD
									  WHEN 30             THEN ACCOUNT_LVL05_NM
									  WHEN 31             THEN ACCOUNT_LVL06_CD
									  WHEN 32             THEN ACCOUNT_LVL06_NM
									  WHEN 33             THEN ACCOUNT_LVL07_CD
									  WHEN 34             THEN ACCOUNT_LVL07_NM
									  WHEN 35             THEN ACCOUNT_LVL08_CD
									  WHEN 36             THEN ACCOUNT_LVL08_NM
									  WHEN 37             THEN ACCOUNT_LVL09_CD
									  WHEN 38             THEN ACCOUNT_LVL09_NM
									  WHEN 39             THEN ACCOUNT_LVL10_CD
									  WHEN 40             THEN ACCOUNT_LVL10_NM
						END;

    END IF;


--     	   SET p_RT_MSG = 'MSG_0003'  --조회 되었습니다.
--END TRY
--BEGIN CATCH
--	IF (ERROR_MESSAGE() LIKE 'MSG_%')
--		BEGIN
--			SET v_ERR_MSG = ERROR_MESSAGE()
--			SET p_RT_MSG = v_ERR_MSG
--		END
--	ELSE 
--			THROW
--			EXEC SP_COMM_RAISE_ERR
    P_RT_MSG := 'MSG_0003';

    EXCEPTION WHEN OTHERS THEN  -- ?？? ???？？? ?？? ???？?？ : e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_MSG := sqlerrm;
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;   
END;

/

