create PROCEDURE "SP_UI_DP_22_1_S2" (
    p_ID                        IN VARCHAR2				:= ''         
  , p_INIT_VAL_TP_ID			IN VARCHAR2				:= ''      
  , p_INIT_FIXED_LV_MGMT_ID		IN VARCHAR2				:= ''      
  , p_CONST_INPUT_YN            IN VARCHAR2				:= ''      
  , p_INIT_CONST_INPUT_VAL      IN INT					:= ''      
  , p_INIT_CONST_INPUT_TIME_VAL IN INT					:= ''      
  , P_INPUT_TP_ID               IN VARCHAR2             := ''
  , p_APPV_CONST_ID				IN VARCHAR2				:= ''      
  , p_APPV_EVENT_ID				IN VARCHAR2				:= ''      
  , p_AUTO_APPV_YN				IN VARCHAR2				:= ''      
  , p_INIT_AUTO_APPV_VAL		IN INT					:= ''      
  , p_INIT_AUTO_APPV_TIME_VAL	IN INT					:= ''   
  , p_USER_ID					IN VARCHAR2				:= ''    
  , p_PLAN_TP_ID				IN VARCHAR2				:= ''  	
  , P_RT_ROLLBACK_FLAG			OUT VARCHAR2   
  , P_RT_MSG					OUT VARCHAR2
) 
IS
	P_ERR_STATUS INT := 0;
	P_ERR_MSG VARCHAR2(4000) :='';
    V_CHECK VARCHAR2(50):='';

BEGIN 
    SELECT COUNT(INIT_VAL_ID) INTO V_CHECK
      FROM (
        SELECT CM.ID                                    AS INIT_VAL_TP_ID
             , CM.CONF_GRP_CD                           AS TP
             , CM.CONF_CD                               AS TP_CD
             , 'CF_'||CM.CONF_GRP_CD||'_'||CM.CONF_CD   AS TP_NM
             ------------------------------------------------------------
             , INIT_VAL_ID AS INIT_VAL_ID
             , VAL_CD AS VAL_CD
             , VAL_NM AS VAL_NM
             , VAL_SEQ       
          FROM TB_CM_CONFIGURATION CF
         INNER JOIN TB_CM_COMM_CONFIG CM
            ON CF.ID = CM.CONF_ID
           AND CM.CONF_GRP_CD = 'DP_INIT_VAL_TP'
           AND CM.ACTV_YN = 'Y'   
          LEFT OUTER JOIN (
               SELECT CL.ID            AS INIT_VAL_ID
                    , CL.LV_CD         AS VAL_CD
                    , CL.LV_NM         AS VAL_NM
                    , CL.SEQ           AS VAL_SEQ
                    , 'PR'             AS CONF_CD
                 FROM TB_CM_LEVEL_MGMT CL
                WHERE CL.SALES_LV_YN = 'Y'
                  AND CL.DEL_YN != 'Y'
                  AND CL.ACTV_YN ='Y'
               UNION
               SELECT MS.ID            AS INIT_VAL_ID
                    , MS.MEASURE_CD    AS VAL_CD
                    , MS.MEASURE_CD    AS VAL_NM
                    , 0                AS VAL_SEQ
                    , 'MS'             AS CONF_CD
                 FROM TB_DP_MEASURE_MST MS
                WHERE MS.DP_YN ='Y'
                  AND NVL(MS.DEL_YN,'N')   = 'N'
              ) VL ON VL.CONF_CD = CM.CONF_CD
   --     WHERE CM.ID = P_INIT_VAL_TP_ID 
   --       OR P_INIT_VAL_TP_ID IS NULL
        ORDER BY VAL_NM
      )
     WHERE 1=1
       AND TP_CD='MS'
       AND INIT_VAL_ID=p_INIT_FIXED_LV_MGMT_ID
    ;

    IF ( V_CHECK>0 )
    THEN
        UPDATE TB_DP_CONTROL_BOARD_MST
           SET INIT_VAL_TP_ID               = p_INIT_VAL_TP_ID
             , INIT_FIXED_LV_MGMT_ID        = NULL
             , CONST_INPUT_YN               = p_CONST_INPUT_YN
             , INIT_CONST_INPUT_VAL         = p_INIT_CONST_INPUT_VAL
             , INIT_CONST_INPUT_TIME_VAL    = p_INIT_CONST_INPUT_TIME_VAL
             , INPUT_TP_ID                  = P_INPUT_TP_ID
             , APPV_CONST_ID                = p_APPV_CONST_ID
             , APPV_EVENT_ID                = p_APPV_EVENT_ID
             , AUTO_APPV_YN                 = p_AUTO_APPV_YN
             , INIT_AUTO_APPV_VAL           = p_INIT_AUTO_APPV_VAL
             , INIT_AUTO_APPV_TIME_VAL      = p_INIT_AUTO_APPV_TIME_VAL
             , MODIFY_BY                    = p_USER_ID
             , MODIFY_DTTM                  = SYSDATE
             , INIT_MEASURE_ID              = p_INIT_FIXED_LV_MGMT_ID
         WHERE ID = p_ID
           AND PLAN_TP_ID = p_PLAN_TP_ID
        ;
    ELSE
        UPDATE TB_DP_CONTROL_BOARD_MST
           SET INIT_VAL_TP_ID               = p_INIT_VAL_TP_ID
             , INIT_FIXED_LV_MGMT_ID        = p_INIT_FIXED_LV_MGMT_ID
             , CONST_INPUT_YN               = p_CONST_INPUT_YN
             , INIT_CONST_INPUT_VAL         = p_INIT_CONST_INPUT_VAL
             , INIT_CONST_INPUT_TIME_VAL    = p_INIT_CONST_INPUT_TIME_VAL
             , INPUT_TP_ID                  = P_INPUT_TP_ID
             , APPV_CONST_ID                = p_APPV_CONST_ID
             , APPV_EVENT_ID                = p_APPV_EVENT_ID
             , AUTO_APPV_YN                 = p_AUTO_APPV_YN
             , INIT_AUTO_APPV_VAL           = p_INIT_AUTO_APPV_VAL
             , INIT_AUTO_APPV_TIME_VAL      = p_INIT_AUTO_APPV_TIME_VAL
             , MODIFY_BY                    = p_USER_ID
             , MODIFY_DTTM                  = SYSDATE
             , INIT_MEASURE_ID              = NULL
         WHERE ID = p_ID
           AND PLAN_TP_ID = p_PLAN_TP_ID
        ;
    END IF;


    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';  --？？？？ ？？？？？？？？.
       /* ？？？？ o？？ ============================================================================*/
EXCEPTION WHEN OTHERS THEN  -- ？？？ ？？？？？？？ ？？？？ ？？？？ ？？？？ : e_products_invalid
    IF(SQLCODE = -20001)
    THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
    ELSE
        SP_COMM_RAISE_ERR();
    --RAISE;
    END IF;

END;

/

