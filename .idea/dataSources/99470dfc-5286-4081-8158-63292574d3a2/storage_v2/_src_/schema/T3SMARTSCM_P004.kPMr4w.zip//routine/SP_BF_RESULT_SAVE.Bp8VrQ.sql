create PROCEDURE SP_BF_RESULT_SAVE (
       P_VER_CD		IN VARCHAR2 := ''
     , P_QTY			IN FLOAT	  := ''
     , P_ITEM_CD		IN VARCHAR2 := ''
     , P_ACCOUNT_CD		IN VARCHAR2 := ''
     , P_SALES_LV_CD	IN VARCHAR2 := ''
     , P_ITEM_LV_CD		IN VARCHAR2 := ''
     , P_BASE_DATE		IN VARCHAR2 := ''
)
IS
     V_BASE_DATE DATE := '';
BEGIN 
     IF ( P_BASE_DATE is not null )
     THEN
          V_BASE_DATE := TO_DATE(P_BASE_DATE);
     ELSE
          V_BASE_DATE := '';
     END IF;

    INSERT INTO TB_BF_RESULT (
							  ID
							, VER_CD
							, ITEM_CD	
							, ACCOUNT_CD
							, BASE_DATE	
							, QTY		
							, CREATE_BY	
							, CREATE_DTTM
			) VALUES (
							  TO_SINGLE_BYTE(SYS_GUID())
							, P_VER_CD
							, P_ITEM_CD
							, P_ACCOUNT_CD
							, V_BASE_DATE
							, P_QTY
							, 'admin'
							, SYSDATE
	);
END;

/

