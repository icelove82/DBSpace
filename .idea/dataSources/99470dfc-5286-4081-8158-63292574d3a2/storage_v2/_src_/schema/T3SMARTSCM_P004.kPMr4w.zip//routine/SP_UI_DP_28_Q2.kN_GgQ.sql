create PROCEDURE "SP_UI_DP_28_Q2" (
	 p_BUCK			VARCHAR2
	,p_STRT_DATE	DATE
	,p_END_DATE		DATE
	,p_USER_ID		VARCHAR2
	,p_PLAN_TP_ID	VARCHAR2
	,p_ITEM_CD		VARCHAR2
	,p_ACCT_CD		VARCHAR2
	,p_ITEM_LV_CD	VARCHAR2
	,p_ACCT_LV_CD	VARCHAR2
	,p_RT_MSG		OUT VARCHAR2
    ,pRESULT		OUT SYS_REFCURSOR
)IS


/*****************************************************************************
Title : [SP_UI_DP_28_Q2]
최초 작성자 : 한영석
최초 생성일 : 2017.06.20
 
설명 
 - Sales Performance Report 쿼리
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 한영석 / 최초 작성
- 2018.12.21 / 김소희 / FN_DP_TEMP_SALES_REPORT 함수 조회 
- 2020.12.21 / 민경훈 / MSSQL -> ORACLE 
*****************************************************************************/

v_ERR_MSG		VARCHAR2(4000):='';
v_ERR_STATUS	INT := NULL;
v_BUCK			VARCHAR2(50) :='';
v_STRT_DATE	DATE := '';
v_END_DATE		DATE := '';
v_PLAN_TP_ID	VARCHAR2(100) :='';
v_ITEM_CD		VARCHAR2(4000) :='';
v_ACCT_CD		VARCHAR2(4000) :='';
v_ITEM_LV_CD	VARCHAR2(50) :='';
v_ACCT_LV_CD	VARCHAR2(50) :='';

BEGIN
	v_BUCK			:= p_BUCK	   ;
	v_STRT_DATE		:= p_STRT_DATE ;
	v_END_DATE		:= p_END_DATE  ;
	v_PLAN_TP_ID	:= p_PLAN_TP_ID;
	v_ITEM_CD		:= p_ITEM_CD   ;
	v_ACCT_CD		:= p_ACCT_CD   ;
	v_ITEM_LV_CD	:= p_ITEM_LV_CD;
	v_ACCT_LV_CD	:= p_ACCT_LV_CD;

	SELECT SUM(CNT) INTO v_ERR_STATUS
		FROM (
			SELECT COUNT(*) AS CNT
				FROM TB_CM_ITEM_MST
				WHERE 1=1
                  AND (REGEXP_LIKE(UPPER(ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                            OR v_ITEM_CD IS NULL
                      )
--				AND ITEM_CD IN (
--					SELECT TRIM(REGEXP_SUBSTR(v_ITEM_CD, '[^|]+', 1, LEVEL)) AS ITEM_CD
--						FROM DUAL
--					CONNECT BY INSTR(v_ITEM_CD, '|', 1, LEVEL - 1) > 0
--				)
				AND COALESCE(DEL_YN,'N')  = 'N' 
				AND DP_PLAN_YN ='Y'
				UNION
				SELECT COUNT(*) AS CNT
				FROM TB_CM_ITEM_LEVEL_MGMT
				WHERE 1=1
				AND ITEM_LV_CD = v_ITEM_LV_CD
				AND COALESCE(DEL_YN,'N')  = 'N' 
			) A
    ;
	IF(v_ERR_STATUS = 0 AND LENGTH(v_ITEM_LV_CD) !=0 AND LENGTH(v_ITEM_CD) !=0)
	THEN
		v_ERR_MSG :='MSG_0020';
        RAISE_APPLICATION_ERROR(-20001, v_ERR_MSG);         
	END IF;

	SELECT SUM(CNT) INTO v_ERR_STATUS
		FROM (
			SELECT COUNT(*) AS CNT
				FROM TB_DP_ACCOUNT_MST
				WHERE 1=1
                AND (REGEXP_LIKE(UPPER(ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                            OR v_ACCT_CD IS NULL
                      )
--				AND ACCOUNT_CD IN (
--					SELECT TRIM(REGEXP_SUBSTR(v_ACCT_CD, '[^|]+', 1, LEVEL)) AS ACCT_CD
--						FROM DUAL
--					CONNECT BY INSTR(v_ACCT_CD, '|', 1, LEVEL - 1) > 0
--				)
				AND COALESCE(DEL_YN,'N')  = 'N' 
				AND ACTV_YN ='Y'
				UNION
				SELECT COUNT(*) AS CNT
				FROM TB_DP_SALES_LEVEL_MGMT
				WHERE 1=1
				AND SALES_LV_CD = v_ACCT_LV_CD
				AND COALESCE(DEL_YN,'N')  = 'N' 
			) A
	;

	IF(v_ERR_STATUS = 0 AND LENGTH(v_ACCT_LV_CD) !=0 AND LENGTH(v_ACCT_CD) !=0)
	THEN
		v_ERR_MSG :='MSG_0020';
        RAISE_APPLICATION_ERROR(-20001, v_ERR_MSG);
	END IF;

	SELECT COUNT(*) INTO v_ERR_STATUS
	  FROM TB_DP_CONTROL_BOARD_VER_MST A
	 WHERE A.PLAN_TP_ID = v_PLAN_TP_ID
	 ;

	 IF (v_ERR_STATUS = 0 )
	 THEN
		v_ERR_MSG := 'MSG_5105';
        RAISE_APPLICATION_ERROR(-20001, v_ERR_MSG);         
	 END IF;

    OPEN pRESULT FOR
    SELECT
		  DAT   AS "DATE"  
		-----------------------
		-- DIMENSION:   LEVEL 값을 하드코딩 해야 함
		----------------------- 
        -- ITEM
		, DIMENSION_01
		, DIMENSION_02
		, DIMENSION_03
		, DIMENSION_04
		, DIMENSION_05 
		, DIMENSION_06
		, DIMENSION_07
		, DIMENSION_08
		, DIMENSION_09
		, DIMENSION_10
		, DIMENSION_11
		, DIMENSION_12
		, DIMENSION_13
		, DIMENSION_14
		, DIMENSION_15
		, DIMENSION_16
		, DIMENSION_17
		, DIMENSION_18
		, DIMENSION_19
		, DIMENSION_20
        -- ACCOUNT
		, DIMENSION_21
		, DIMENSION_22
		, DIMENSION_23
		, DIMENSION_24
		, DIMENSION_25
		, DIMENSION_26
		, DIMENSION_27
		, DIMENSION_28
		, DIMENSION_29
		, DIMENSION_30
		, DIMENSION_31
		, DIMENSION_32
		, DIMENSION_33
		, DIMENSION_34
		, DIMENSION_35
		, DIMENSION_36
		, DIMENSION_37
		, DIMENSION_38
		, DIMENSION_39
		, DIMENSION_40
        , ITEM
        , ACCOUNT
        , 'COMMON' AS SALES
       -- MEASURE
       , MEASURE_01
       , MEASURE_02
       , MEASURE_03
       , MEASURE_04
       , MEASURE_05
       , MEASURE_06
   FROM FN_DP_TEMP_SALES_REPORT(v_BUCK, v_STRT_DATE, v_END_DATE, p_USER_ID, v_PLAN_TP_ID
                                      ,v_ITEM_CD, v_ACCT_CD, v_ITEM_LV_CD, v_ACCT_LV_CD)
	;
	 p_RT_MSG := 'MSG_0003' ; --조회 되었습니다.

     EXCEPTION WHEN OTHERS THEN  -- ?？? ???？？? ?？? ???？?？ : e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_MSG := sqlerrm;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;   	


END;

/

