create PROCEDURE "SP_UI_DP_31_Q2" (
	 p_PLAN_TP_ID	VARCHAR2
	,p_VER_ID		VARCHAR2
	,p_AUTH_TP_ID	VARCHAR2
	,p_BUCK			VARCHAR2
	,p_STRT_DATE	DATE
	,p_END_DATE		DATE
	,p_OPTION		CHAR
	,p_ACCT_CD		VARCHAR2
	,p_ACCT_LV_CD	VARCHAR2
	,p_ITEM_CD		VARCHAR2
	,p_ITEM_LV_CD	VARCHAR2
	,p_USER_ID		VARCHAR2
	,p_RT_MSG		OUT VARCHAR2
    ,pRESULT		OUT SYS_REFCURSOR
)
IS

/*****************************************************************************
Title : [SP_UI_DP_31_Q2]
최초 작성자 : 한영석
최초 생성일 : 2017.12.06
 
설명 
 - RTF Analysis Report 쿼리
 
History (수정일자 / 수정자 / 수정내용)
- 2017.12.06 / 한영석 / 최초 작성
- 2018.12.21 / 김소희 / MAIN SELECT문 컨버팅  
- 2020.12.22 / 민경훈 / MSSQL -> ORACLE
*****************************************************************************/

v_DIMENSION_01_ACTV_YN      CHAR(1)	:= 'Y';
v_DIMENSION_02_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_03_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_04_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_05_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_06_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_07_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_08_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_09_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_10_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_11_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_12_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_13_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_14_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_15_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_16_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_17_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_18_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_19_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_20_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_21_ACTV_YN      CHAR(1)	:= 'Y';
v_DIMENSION_22_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_23_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_24_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_25_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_26_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_27_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_28_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_29_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_30_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_31_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_32_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_33_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_34_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_35_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_36_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_37_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_38_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_39_ACTV_YN      CHAR(1) 	:= 'Y';
v_DIMENSION_40_ACTV_YN      CHAR(1) 	:= 'Y';

v_DP_VERSION_ID				VARCHAR2(100);

v_ERR_MSG					VARCHAR2(4000);
v_ERR_STATUS				INT := NULL;
v_SEARCH_LV_SEQ				INT := NULL;
v_SEARCH_LV_SEQ_02			INT := NULL;
v_ITEM_CHECK				INT := NULL;
v_ACCT_CHECK				INT := NULL;
v_ITEM_LV_CHECK				INT := NULL;
v_ACCT_LV_CHECK				INT := NULL;
v_LAST_ITEM_LV              INT := NULL;
v_LAST_ACCT_LV              INT := NULL;

v_PLAN_TP_ID				VARCHAR2(100) := NULL;
v_VER_ID					VARCHAR2(100)  := NULL;
v_AUTH_TP_ID				VARCHAR2(100)	   := NULL;
v_BUCK						VARCHAR2(50)   := NULL;
v_STRT_DATE					DATE		   := NULL;
v_END_DATE					DATE		   := NULL;
v_OPTION					CHAR(1)		   :='Q'  ;
v_ACCT_CD					VARCHAR2(4000) := NULL;
v_ACCT_LV_CD				VARCHAR2(50)   := NULL;
v_ITEM_CD					VARCHAR2(4000) := NULL;
v_ITEM_LV_CD				VARCHAR2(50)   := NULL;

BEGIN

	v_PLAN_TP_ID	:= p_PLAN_TP_ID;
	v_VER_ID		:= p_VER_ID		;
	v_AUTH_TP_ID	:= p_AUTH_TP_ID;
	v_BUCK			:= p_BUCK		;
	v_STRT_DATE		:= p_STRT_DATE ;
	v_END_DATE		:= p_END_DATE	;
	v_OPTION		:= p_OPTION		;
	v_ACCT_CD		:= p_ACCT_CD	;	
	v_ACCT_LV_CD	:= p_ACCT_LV_CD;
	v_ITEM_CD		:= p_ITEM_CD	;	
	v_ITEM_LV_CD	:= p_ITEM_LV_CD;

	IF (v_ITEM_LV_CD IS NOT NULL OR v_ITEM_CD IS NOT NULL )
    THEN
        SELECT COUNT(*) INTO v_ITEM_CHECK
          FROM TB_CM_ITEM_MST
         WHERE 1=1
           AND (REGEXP_LIKE(UPPER(ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                            OR v_ITEM_CD IS NULL
                      )
--           AND ITEM_CD IN (
--					SELECT TRIM(REGEXP_SUBSTR(v_ITEM_CD, '[^|]+', 1, LEVEL)) AS ITEM_CD
--						FROM DUAL
--					CONNECT BY INSTR(v_ITEM_CD, '|', 1, LEVEL - 1) > 0
--				)
           AND COALESCE(DEL_YN,'N')  = 'N' 
           AND DP_PLAN_YN='Y'
          ;
        SELECT COUNT(*) INTO v_ITEM_LV_CHECK
          FROM TB_CM_ITEM_LEVEL_MGMT
         WHERE 1=1
           AND ITEM_LV_CD = v_ITEM_LV_CD
           AND COALESCE(DEL_YN,'N') = 'N'
           ;
        IF(v_ITEM_CHECK !=0)    
        THEN    -- ITEM 최하위 레벨로 SEQ 넣어주기
            SELECT MAX(SEARCH_LV_SEQ)+1 INTO v_SEARCH_LV_SEQ
              FROM( SELECT DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ
                      FROM TB_CM_ITEM_LEVEL_MGMT IL
                     INNER JOIN TB_CM_LEVEL_MGMT LV ON(IL.LV_MGMT_ID = LV.ID)
                     WHERE 1=1
                       AND COALESCE(IL.DEL_YN,'N') = 'N'
                       AND COALESCE(LV.DEL_YN,'N') = 'N'   
                )
            ;
        ELSIF (v_ITEM_LV_CHECK != 0) -- account level 레벨로 SEQ 넣어주기
        THEN
            SELECT SEARCH_LV_SEQ INTO v_SEARCH_LV_SEQ
            FROM(
                    SELECT  IL.ITEM_LV_CD
                          , DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ
                      FROM TB_CM_ITEM_LEVEL_MGMT IL
                           INNER JOIN
                           TB_CM_LEVEL_MGMT LV
                        ON(IL.LV_MGMT_ID = LV.ID)
                     WHERE 1=1
                       AND COALESCE(IL.DEL_YN,'N')  = 'N'
                       AND COALESCE(LV.DEL_YN,'N')  = 'N'   
               )
            WHERE ITEM_LV_CD = v_ITEM_LV_CD
            ;
        ELSE
            v_ERR_MSG := 'MSG_0020';
            RAISE_APPLICATION_ERROR(-20001, v_ERR_MSG);
        END IF;
    END IF;

    IF (v_ACCT_LV_CD IS NOT NULL OR v_ACCT_CD IS NOT NULL)
    THEN
        SELECT COUNT(*) INTO v_ACCT_CHECK
          FROM TB_DP_ACCOUNT_MST
         WHERE 1=1
           AND (REGEXP_LIKE(UPPER(ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                            OR v_ACCT_CD IS NULL
                      )
--           AND ACCOUNT_CD IN (
--					SELECT TRIM(REGEXP_SUBSTR(v_ACCT_CD, '[^|]+', 1, LEVEL)) AS ACCT_CD
--						FROM DUAL
--					CONNECT BY INSTR(v_ACCT_CD, '|', 1, LEVEL - 1) > 0
--				)
           AND COALESCE(DEL_YN,'N')  = 'N' 
           AND ACTV_YN ='Y'
           ;
        SELECT COUNT(*) INTO v_ACCT_LV_CHECK
          FROM TB_DP_SALES_LEVEL_MGMT
         WHERE 1=1
           AND SALES_LV_CD = v_ACCT_LV_CD
           AND COALESCE(DEL_YN,'N') = 'N'   
        ;    
        IF(v_ACCT_CHECK != 0)    
        THEN    -- ACCOUNT 최하위 레벨로 SEQ 넣어주기
             SELECT  MAX(SEARCH_LV_SEQ)+1 INTO v_SEARCH_LV_SEQ_02
               FROM(  SELECT DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ
                        FROM TB_DP_SALES_LEVEL_MGMT SL
                       INNER JOIN TB_CM_LEVEL_MGMT LV ON(SL.LV_MGMT_ID = LV.ID)
                       WHERE 1=1
                         AND COALESCE(SL.DEL_YN,'N') = 'N'
                         AND COALESCE(LV.DEL_YN,'N') = 'N'   
                )
              ;
        ELSIF(v_ACCT_LV_CHECK != 0 )
        THEN
            SELECT SEARCH_LV_SEQ_02 INTO v_SEARCH_LV_SEQ_02
              FROM (
                    SELECT SL.SALES_LV_CD
                         , DENSE_RANK() OVER(ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ_02
                      FROM TB_DP_SALES_LEVEL_MGMT SL
                           INNER JOIN TB_CM_LEVEL_MGMT LV ON ( SL.LV_MGMT_ID = LV.ID )
                     WHERE 1=1
                       AND COALESCE(SL.DEL_YN,'N')  = 'N' 
                       AND COALESCE(LV.DEL_YN,'N')  = 'N' 
                    )
             WHERE SALES_LV_CD = v_ACCT_LV_CD
            ;
        ELSE
            v_ERR_MSG :='MSG_0020';
            RAISE_APPLICATION_ERROR(-20001, v_ERR_MSG);
        END IF;
	END IF;
---------------------------------------------------------------------------------
    -- 개인화에서 DIMENSION 칼럼의 활성화 여부 값 가져오기
    ---- 20개까지 DIMENSION이 있을 것이라고 가정한 것 (하드코딩)
---------------------------------------------------------------------------------

-- 최하단 ITEM & ACCOUNT LV 셋팅

	   	SELECT CAST(SUBSTR(MAX(A.FLD_CD), 11,2) AS INT ) INTO v_LAST_ITEM_LV
          FROM TB_AD_USER_PREF_DTL A 
         inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = 'UI_DP_31' and m.GRID_CD = 'RST_CPT_01' 
         inner join TB_AD_GROUP g on g.ID = A.GRP_ID 
         inner join TB_AD_USER u on u.USERNAME = p_USER_ID 
         inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
         LEFT OUTER JOIN TB_AD_USER_PREF B ON	m.id = B.USER_PREF_MST_ID AND A.GRP_ID = B.GRP_ID	AND	A.FLD_CD = B.FLD_CD	AND B.USER_ID = u.ID					
		WHERE COALESCE(B.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N')) = 'Y' AND A.DIM_MEASURE_TP = 'DIMENSION'    AND SUBSTR(A.FLD_CD, 11,2) BETWEEN 1 AND 20   
        ;


	   	SELECT CAST(SUBSTR(MAX(A.FLD_CD), 11,2) AS INT ) INTO v_LAST_ACCT_LV
		  FROM TB_AD_USER_PREF_DTL A 
         inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = 'UI_DP_31' and m.GRID_CD = 'RST_CPT_01' 
         inner join TB_AD_GROUP g on g.ID = A.GRP_ID
         inner join TB_AD_USER u on u.USERNAME = p_USER_ID 
         inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
         LEFT OUTER JOIN TB_AD_USER_PREF B  ON	m.id = B.USER_PREF_MST_ID AND A.GRP_ID = B.GRP_ID	AND	A.FLD_CD = B.FLD_CD	AND B.USER_ID = u.ID					
		WHERE COALESCE(B.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N')) = 'Y' AND A.DIM_MEASURE_TP = 'DIMENSION'    AND SUBSTR(A.FLD_CD, 11,2) BETWEEN 21 AND 40   
        ;

	SELECT MAX(CASE WHEN A.FLD_CD = 'DIMENSION_01' THEN A.ACTV_YN ELSE NULL END) 
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_02' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_03' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_04' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_05' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_06' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_07' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_08' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_09' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_10' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_11' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_12' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_13' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_14' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_15' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_16' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_17' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_18' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_19' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_20' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_21' THEN A.ACTV_YN ELSE NULL END) 
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_22' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_23' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_24' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_25' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_26' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_27' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_28' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_29' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_30' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_31' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_32' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_33' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_34' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_35' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_36' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_37' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_38' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_39' THEN A.ACTV_YN ELSE NULL END)
         , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_40' THEN A.ACTV_YN ELSE NULL END)
           INTO
           v_DIMENSION_01_ACTV_YN
         , v_DIMENSION_02_ACTV_YN
         , v_DIMENSION_03_ACTV_YN
         , v_DIMENSION_04_ACTV_YN
         , v_DIMENSION_05_ACTV_YN
         , v_DIMENSION_06_ACTV_YN
         , v_DIMENSION_07_ACTV_YN
         , v_DIMENSION_08_ACTV_YN
         , v_DIMENSION_09_ACTV_YN
         , v_DIMENSION_10_ACTV_YN
         , v_DIMENSION_11_ACTV_YN
         , v_DIMENSION_12_ACTV_YN
         , v_DIMENSION_13_ACTV_YN
         , v_DIMENSION_14_ACTV_YN
         , v_DIMENSION_15_ACTV_YN
         , v_DIMENSION_16_ACTV_YN
         , v_DIMENSION_17_ACTV_YN
         , v_DIMENSION_18_ACTV_YN
         , v_DIMENSION_19_ACTV_YN
         , v_DIMENSION_20_ACTV_YN
         , v_DIMENSION_21_ACTV_YN
         , v_DIMENSION_22_ACTV_YN
         , v_DIMENSION_23_ACTV_YN
         , v_DIMENSION_24_ACTV_YN
         , v_DIMENSION_25_ACTV_YN
         , v_DIMENSION_26_ACTV_YN
         , v_DIMENSION_27_ACTV_YN
         , v_DIMENSION_28_ACTV_YN
         , v_DIMENSION_29_ACTV_YN
         , v_DIMENSION_30_ACTV_YN
         , v_DIMENSION_31_ACTV_YN
         , v_DIMENSION_32_ACTV_YN
         , v_DIMENSION_33_ACTV_YN
         , v_DIMENSION_34_ACTV_YN
         , v_DIMENSION_35_ACTV_YN
         , v_DIMENSION_36_ACTV_YN
         , v_DIMENSION_37_ACTV_YN
         , v_DIMENSION_38_ACTV_YN
         , v_DIMENSION_39_ACTV_YN
         , v_DIMENSION_40_ACTV_YN
	FROM ( 
			SELECT	 m.VIEW_CD
					,m.GRID_CD
					,g.GRP_CD
					,A.FLD_CD
					,A.REFER_VALUE
					,A.FLD_APPLY_CD
					,A.DIM_MEASURE_TP
					,A.CROSSTAB_ITEM_CD
					,A.FLD_SEQ AS SEQ_1, B.FLD_SEQ AS SEQ_2
					, COALESCE(B.DATA_KEY_YN,COALESCE(A.DATA_KEY_YN,'N'))  AS DATA_KEY_YN 
					, COALESCE(B.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N'))			 AS ACTV_YN 
					, ROW_NUMBER() OVER( ORDER BY A.FLD_CD)   AS ROW_NUM 
			FROM	TB_AD_USER_PREF_DTL A 
					inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = 'UI_DP_31'  AND m.GRID_CD	= 'RST_CPT_01'
					inner join TB_AD_GROUP g on g.ID = A.GRP_ID 
					inner join TB_AD_USER u on u.USERNAME = p_USER_ID
					inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
					LEFT OUTER JOIN TB_AD_USER_PREF B  ON	m.id = B.USER_PREF_MST_ID	AND A.GRP_ID	= B.GRP_ID	AND	A.FLD_CD	= B.FLD_CD	AND B.USER_ID	= u.ID
			WHERE    A.CROSSTAB_ITEM_CD = 'GROUP-COLUMNS'
    )  A
	GROUP BY  CROSSTAB_ITEM_CD
	;

    SELECT ID INTO v_DP_VERSION_ID
      FROM (
        SELECT MST.ID
          FROM TB_DP_CONTROL_BOARD_VER_MST MST
               INNER JOIN
               TB_DP_CONTROL_BOARD_VER_DTL DTL
            ON DTL.CONBD_VER_MST_ID = MST.ID
         WHERE 1=1
           AND DTL.CL_STATUS_ID = ( SELECT ID
                                      FROM TB_CM_COMM_CONFIG
                                     WHERE CONF_GRP_CD = 'DP_CL_STATUS'
                                       AND CONF_CD = 'CLOSE')
         AND DTL.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_gRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
       ORDER BY MST.CREATE_DTTM DESC
    )
   WHERE ROWNUM = 1
    ;
---------------------------------------------------------------------------------------------------------------------------------------
	-- 본 프로시저
---------------------------------------------------------------------------------------------------------------------------------------		
    IF( v_OPTION = 'Q')
    THEN
        OPEN pRESULT FOR
       SELECT CASE WHEN v_DIMENSION_01_ACTV_YN = 'Y' THEN ITEM_LVL01_CD	   ELSE NULL END AS DIMENSION_01
            , CASE WHEN v_DIMENSION_02_ACTV_YN = 'Y' THEN ITEM_LVL01_NM       ELSE NULL END AS DIMENSION_02
            , CASE WHEN v_DIMENSION_03_ACTV_YN = 'Y' THEN ITEM_LVL02_CD	   ELSE NULL END AS DIMENSION_03
            , CASE WHEN v_DIMENSION_04_ACTV_YN = 'Y' THEN ITEM_LVL02_NM       ELSE NULL END AS DIMENSION_04
            , CASE WHEN v_DIMENSION_05_ACTV_YN = 'Y' THEN ITEM_LVL03_CD       ELSE NULL END AS DIMENSION_05
            , CASE WHEN v_DIMENSION_06_ACTV_YN = 'Y' THEN ITEM_LVL03_NM       ELSE NULL END AS DIMENSION_06
            , CASE WHEN v_DIMENSION_07_ACTV_YN = 'Y' THEN ITEM_LVL04_CD       ELSE NULL END AS DIMENSION_07
            , CASE WHEN v_DIMENSION_08_ACTV_YN = 'Y' THEN ITEM_LVL04_NM       ELSE NULL END AS DIMENSION_08
            , CASE WHEN v_DIMENSION_09_ACTV_YN = 'Y' THEN ITEM_LVL05_CD	   ELSE NULL END AS DIMENSION_09
            , CASE WHEN v_DIMENSION_10_ACTV_YN = 'Y' THEN ITEM_LVL05_NM       ELSE NULL END AS DIMENSION_10
            , CASE WHEN v_DIMENSION_11_ACTV_YN = 'Y' THEN ITEM_LVL06_CD       ELSE NULL END AS DIMENSION_11
            , CASE WHEN v_DIMENSION_12_ACTV_YN = 'Y' THEN ITEM_LVL06_NM       ELSE NULL END AS DIMENSION_12
            , CASE WHEN v_DIMENSION_13_ACTV_YN = 'Y' THEN ITEM_LVL07_CD       ELSE NULL END AS DIMENSION_13
            , CASE WHEN v_DIMENSION_14_ACTV_YN = 'Y' THEN ITEM_LVL07_NM       ELSE NULL END AS DIMENSION_14
            , CASE WHEN v_DIMENSION_15_ACTV_YN = 'Y' THEN ITEM_LVL08_CD       ELSE NULL END AS DIMENSION_15
            , CASE WHEN v_DIMENSION_16_ACTV_YN = 'Y' THEN ITEM_LVL08_NM       ELSE NULL END AS DIMENSION_16
            , CASE WHEN v_DIMENSION_17_ACTV_YN = 'Y' THEN ITEM_LVL09_CD       ELSE NULL END AS DIMENSION_17
            , CASE WHEN v_DIMENSION_18_ACTV_YN = 'Y' THEN ITEM_LVL09_NM       ELSE NULL END AS DIMENSION_18
            , CASE WHEN v_DIMENSION_19_ACTV_YN = 'Y' THEN ITEM_LVL10_CD       ELSE NULL END AS DIMENSION_19
            , CASE WHEN v_DIMENSION_20_ACTV_YN = 'Y' THEN ITEM_LVL10_NM       ELSE NULL END AS DIMENSION_20

            -- ACCOUNT
            , CASE WHEN v_DIMENSION_21_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_CD       ELSE NULL END AS DIMENSION_21
            , CASE WHEN v_DIMENSION_22_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_NM       ELSE NULL END AS DIMENSION_22
            , CASE WHEN v_DIMENSION_23_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_CD       ELSE NULL END AS DIMENSION_23
            , CASE WHEN v_DIMENSION_24_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_NM	      ELSE NULL END AS DIMENSION_24
            , CASE WHEN v_DIMENSION_25_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_CD       ELSE NULL END AS DIMENSION_25
            , CASE WHEN v_DIMENSION_26_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_NM       ELSE NULL END AS DIMENSION_26
            , CASE WHEN v_DIMENSION_27_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_CD       ELSE NULL END AS DIMENSION_27
            , CASE WHEN v_DIMENSION_28_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_NM       ELSE NULL END AS DIMENSION_28
            , CASE WHEN v_DIMENSION_29_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_CD       ELSE NULL END AS DIMENSION_29
            , CASE WHEN v_DIMENSION_30_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_NM       ELSE NULL END AS DIMENSION_30
            , CASE WHEN v_DIMENSION_31_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_CD       ELSE NULL END AS DIMENSION_31
            , CASE WHEN v_DIMENSION_32_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_NM       ELSE NULL END AS DIMENSION_32        
            , CASE WHEN v_DIMENSION_33_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_CD       ELSE NULL END AS DIMENSION_33
            , CASE WHEN v_DIMENSION_34_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_NM       ELSE NULL END AS DIMENSION_34
            , CASE WHEN v_DIMENSION_35_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_CD       ELSE NULL END AS DIMENSION_35
            , CASE WHEN v_DIMENSION_36_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_NM       ELSE NULL END AS DIMENSION_36
            , CASE WHEN v_DIMENSION_37_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_CD       ELSE NULL END AS DIMENSION_37
            , CASE WHEN v_DIMENSION_38_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_NM       ELSE NULL END AS DIMENSION_38
            , CASE WHEN v_DIMENSION_39_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_CD       ELSE NULL END AS DIMENSION_39
            , CASE WHEN v_DIMENSION_40_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_NM       ELSE NULL END AS DIMENSION_40
            , CASE v_LAST_ITEM_LV WHEN 1            THEN  ITEM_LVL01_CD
            WHEN 2             THEN  ITEM_LVL01_CD
            WHEN 3             THEN  ITEM_LVL02_CD
            WHEN 4             THEN  ITEM_LVL02_CD
            WHEN 5             THEN  ITEM_LVL03_CD
            WHEN 6             THEN  ITEM_LVL03_CD
            WHEN 7             THEN  ITEM_LVL04_CD
            WHEN 8             THEN  ITEM_LVL04_cD
            WHEN 9             THEN  ITEM_LVL05_CD
            WHEN 10            THEN  ITEM_LVL05_cD
            WHEN 11            THEN  ITEM_LVL06_CD
            WHEN 12            THEN  ITEM_LVL06_CD
            WHEN 13            THEN  ITEM_LVL07_CD
            WHEN 14            THEN  ITEM_LVL07_CD
            WHEN 15            THEN  ITEM_LVL08_CD
            WHEN 16            THEN  ITEM_LVL08_CD
            WHEN 17            THEN  ITEM_LVL09_CD
            WHEN 18            THEN  ITEM_LVL09_cD
            WHEN 19            THEN  ITEM_LVL10_CD
            WHEN 20            THEN  ITEM_LVL10_CD
            ELSE NULL
            END	AS ITEM                            
            , CASE v_LAST_ACCT_LV WHEN 21           THEN  ACCOUNT_LVL01_CD
            WHEN 22            THEN  ACCOUNT_LVL01_CD
            WHEN 23            THEN  ACCOUNT_LVL02_CD
            WHEN 24            THEN  ACCOUNT_LVL02_CD
            WHEN 25            THEN  ACCOUNT_LVL03_CD
            WHEN 26            THEN  ACCOUNT_LVL03_CD
            WHEN 27            THEN  ACCOUNT_LVL04_CD
            WHEN 28            THEN  ACCOUNT_LVL04_CD
            WHEN 29            THEN  ACCOUNT_LVL05_CD
            WHEN 30            THEN  ACCOUNT_LVL05_CD
            WHEN 31            THEN  ACCOUNT_LVL06_CD
            WHEN 32            THEN  ACCOUNT_LVL06_cD
            WHEN 33            THEN  ACCOUNT_LVL07_CD
            WHEN 34            THEN  ACCOUNT_LVL07_CD
            WHEN 35            THEN  ACCOUNT_LVL08_CD
            WHEN 36            THEN  ACCOUNT_LVL08_CD
            WHEN 37            THEN  ACCOUNT_LVL09_CD
            WHEN 38            THEN  ACCOUNT_LVL09_cD
            WHEN 39            THEN  ACCOUNT_LVL10_CD
            WHEN 40            THEN  ACCOUNT_LVL10_cD
            ELSE NULL  END AS ACCOUNT
           , 'COMMON'                  AS SALES		 
           ,M.BUCKET_START_DATE   AS "DATE"  
           -- MEASURE
           , SUM( COALESCE(T_FINAL_DP.QTY, 0))											AS MEASURE_01
           , SUM( COALESCE(T_RTF.ON_TIME_QTY, 0))									    AS MEASURE_02
            /* 0으로 나누는 경우 예외처리 */
           , CASE WHEN	SUM( COALESCE(T_FINAL_DP.QTY, 0)) = 0 THEN 0
                ELSE	SUM( COALESCE(T_RTF.ON_TIME_QTY, 0) ) / SUM( COALESCE(T_FINAL_DP.QTY, 0) ) * 100 END AS MEASURE_03			
         FROM		    (
							SELECT         
									  IH.LVL01_ID				AS ITEM_LVL01_ID 	
									, IH.LVL01_CD				AS ITEM_LVL01_CD 	
									, IH.LVL01_NM				AS ITEM_LVL01_NM 	
									, IH.LVL02_ID				AS ITEM_LVL02_ID 	
									, IH.LVL02_CD				AS ITEM_LVL02_CD 	
									, IH.LVL02_NM				AS ITEM_LVL02_NM 	
									, IH.LVL03_ID				AS ITEM_LVL03_ID 	
									, IH.LVL03_CD				AS ITEM_LVL03_CD 	
									, IH.LVL03_NM				AS ITEM_LVL03_NM 	
									, IH.LVL04_ID				AS ITEM_LVL04_ID 	
									, IH.LVL04_CD				AS ITEM_LVL04_CD 	
									, IH.LVL04_NM				AS ITEM_LVL04_NM 	
									, IH.LVL05_ID				AS ITEM_LVL05_ID 	
									, IH.LVL05_CD				AS ITEM_LVL05_CD 	
									, IH.LVL05_NM				AS ITEM_LVL05_NM 	
									, IH.LVL06_ID				AS ITEM_LVL06_ID 	
									, IH.LVL06_CD				AS ITEM_LVL06_CD 	
									, IH.LVL06_NM				AS ITEM_LVL06_NM 	
									, IH.LVL07_ID				AS ITEM_LVL07_ID 	
									, IH.LVL07_CD				AS ITEM_LVL07_CD 	
									, IH.LVL07_NM				AS ITEM_LVL07_NM 	
									, IH.LVL08_ID				AS ITEM_LVL08_ID 	
									, IH.LVL08_CD				AS ITEM_LVL08_CD 	
									, IH.LVL08_NM				AS ITEM_LVL08_NM 	
									, IH.LVL09_ID				AS ITEM_LVL09_ID 	
									, IH.LVL09_CD				AS ITEM_LVL09_CD 	
									, IH.LVL09_NM				AS ITEM_LVL09_NM 	
									, IH.LVL10_ID				AS ITEM_LVL10_ID 	
									, IH.LVL10_CD				AS ITEM_LVL10_CD 	
									, IH.LVL10_NM				AS ITEM_LVL10_NM 	
									, IH.ITEM_ID				AS ITEM_ID 			
									, IH.ITEM_CD				AS ITEM_CD 			
									, IH.ITEM_NM 				AS ITEM_NM  		
									, AH.LVL01_ID				AS ACCOUNT_LVL01_ID 
									, AH.LVL01_CD				AS ACCOUNT_LVL01_CD 
									, AH.LVL01_NM				AS ACCOUNT_LVL01_NM 
									, AH.LVL02_ID				AS ACCOUNT_LVL02_ID 
									, AH.LVL02_CD				AS ACCOUNT_LVL02_CD 
									, AH.LVL02_NM				AS ACCOUNT_LVL02_NM 
									, AH.LVL03_ID				AS ACCOUNT_LVL03_ID 
									, AH.LVL03_CD				AS ACCOUNT_LVL03_CD 
									, AH.LVL03_NM				AS ACCOUNT_LVL03_NM 
									, AH.LVL04_ID				AS ACCOUNT_LVL04_ID 
									, AH.LVL04_CD				AS ACCOUNT_LVL04_CD 
									, AH.LVL04_NM				AS ACCOUNT_LVL04_NM 
									, AH.LVL05_ID				AS ACCOUNT_LVL05_ID 
									, AH.LVL05_CD				AS ACCOUNT_LVL05_CD 
									, AH.LVL05_NM				AS ACCOUNT_LVL05_NM 
									, AH.LVL06_ID				AS ACCOUNT_LVL06_ID 
									, AH.LVL06_CD				AS ACCOUNT_LVL06_CD 
									, AH.LVL06_NM				AS ACCOUNT_LVL06_NM 
									, AH.LVL07_ID				AS ACCOUNT_LVL07_ID 
									, AH.LVL07_CD				AS ACCOUNT_LVL07_CD 
									, AH.LVL07_NM				AS ACCOUNT_LVL07_NM 
									, AH.LVL08_ID				AS ACCOUNT_LVL08_ID 
									, AH.LVL08_CD				AS ACCOUNT_LVL08_CD 
									, AH.LVL08_NM				AS ACCOUNT_LVL08_NM 
									, AH.LVL09_ID				AS ACCOUNT_LVL09_ID 
									, AH.LVL09_CD				AS ACCOUNT_LVL09_CD 
									, AH.LVL09_NM				AS ACCOUNT_LVL09_NM 
									, AH.LVL10_ID				AS ACCOUNT_LVL10_ID 
									, AH.LVL10_CD				AS ACCOUNT_LVL10_CD 
									, AH.LVL10_NM				AS ACCOUNT_LVL10_NM 
									, AH.ACCOUNT_ID				AS ACCOUNT_ID 		
									, AH.ACCOUNT_CD				AS ACCOUNT_CD 		
									, AH.ACCOUNT_NM				AS ACCOUNT_NM 		
									, CA.BUCKET_START_DATE		AS BUCKET_START_DATE
									, CA.BUCKET_END_DATE		AS BUCKET_END_DATE 	                     
								FROM (
											SELECT DO.ITEM_MST_ID ,DO.ACCOUNT_ID 
											  FROM TB_DP_ENTRY DO
											 WHERE 1=1  
											   AND DO. VER_ID = p_VER_ID
											   AND DO.AUTH_TP_ID = p_AUTH_TP_ID
										  GROUP BY DO.ITEM_MST_ID ,DO.ACCOUNT_ID 
									   ) DO
									  INNER JOIN -- FN_Dp_TEMp_CAL : 버킷별로 CALENDAR 정보 가져오는 함수
                                      FN_DP_TEMP_CAL(p_STRT_DATE, p_END_DATE, p_BUCK) CA ON(1=1)
									  INNER JOIN
									  TB_DPD_ITEM_HIERACHY2 IH                                  
								 ON   IH.ITEM_ID = DO.ITEM_MST_ID
									  INNER JOIN
									  TB_DPD_ACCOUNT_HIERACHY2 AH
								 ON   AH.ACCOUNT_ID = DO.ACCOUNT_ID                    
								 WHERE   1=1      -- ( ) [ ]
                                   AND (REGEXP_LIKE(UPPER(AH.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                                        OR v_ACCT_CD IS NULL
                                  )
-- 								   AND (  ( v_ACCT_CD LIKE '%|%' 
--											AND AH.ACCOUNT_CD IN (
--                                                SELECT TRIM(REGEXP_SUBSTR(v_ACCT_CD, '[^|]+', 1, LEVEL)) AS ACCT_CD
--                                                    FROM DUAL
--                                                CONNECT BY INSTR(v_ACCT_CD, '|', 1, LEVEL - 1) > 0
--                                            )
-- 					 					)OR(COALESCE(v_ACCT_CD,'') NOT LIKE '%|%' 
--											AND COALESCE(AH.ACCOUNT_CD,'')  LIKE  '%' || COALESCE(v_ACCT_CD,'') || '%'  ))       
                                  AND (REGEXP_LIKE(UPPER(IH.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                                        OR v_ITEM_CD IS NULL
                                  )
-- 								   AND (  ( v_ITEM_CD LIKE '%|%' 
--											AND IH.ITEM_CD IN (
--                                                SELECT TRIM(REGEXP_SUBSTR(v_ITEM_CD, '[^|]+', 1, LEVEL)) AS ITEM_CD
--                                                    FROM DUAL
--                                                CONNECT BY INSTR(v_ITEM_CD, '|', 1, LEVEL - 1) > 0
--                                            )
-- 										)OR(COALESCE(v_ITEM_CD,'') NOT LIKE '%|%' 
--											AND COALESCE(IH.ITEM_CD,'')  LIKE  '%' || COALESCE(v_ITEM_CD,'') || '%'   ))
								 AND ( v_ITEM_LV_CD = 
									 CASE WHEN v_SEARCH_LV_SEQ = 1  THEN  IH.LVL01_CD		    
										  WHEN v_SEARCH_LV_SEQ = 2  THEN  IH.LVL02_CD		    
										  WHEN v_SEARCH_LV_SEQ = 3  THEN  IH.LVL03_CD      
										  WHEN v_SEARCH_LV_SEQ = 4  THEN  IH.LVL04_CD      
										  WHEN v_SEARCH_LV_SEQ = 5  THEN  IH.LVL05_CD	     
										  WHEN v_SEARCH_LV_SEQ = 6  THEN  IH.LVL06_CD      
										  WHEN v_SEARCH_LV_SEQ = 7  THEN  IH.LVL07_CD      
										  WHEN v_SEARCH_LV_SEQ = 8  THEN  IH.LVL08_CD      
										  WHEN v_SEARCH_LV_SEQ = 9  THEN  IH.LVL09_CD      
										  WHEN v_SEARCH_LV_SEQ = 10 THEN  IH.LVL10_CD      
										  ELSE NULL END
									OR v_ITEM_LV_CD IS NULL
								 )
								 AND ( v_ACCT_LV_CD =  
										 CASE WHEN v_SEARCH_LV_SEQ_02 = 1  THEN  AH.LVL01_CD		    
											  WHEN v_SEARCH_LV_SEQ_02 = 2  THEN  AH.LVL02_CD		    
											  WHEN v_SEARCH_LV_SEQ_02 = 3  THEN  AH.LVL03_CD      
											  WHEN v_SEARCH_LV_SEQ_02 = 4  THEN  AH.LVL04_CD      
											  WHEN v_SEARCH_LV_SEQ_02 = 5  THEN  AH.LVL05_CD	     
											  WHEN v_SEARCH_LV_SEQ_02 = 6  THEN  AH.LVL06_CD      
											  WHEN v_SEARCH_LV_SEQ_02 = 7  THEN  AH.LVL07_CD      
											  WHEN v_SEARCH_LV_SEQ_02 = 8  THEN  AH.LVL08_CD      
											  WHEN v_SEARCH_LV_SEQ_02 = 9  THEN  AH.LVL09_CD       
											  WHEN v_SEARCH_LV_SEQ_02 = 10 THEN  AH.LVL10_CD      
											  ELSE NULL END
									OR v_ACCT_LV_CD IS NULL
								 )     			 
						) M    
						LEFT OUTER JOIN (
                            SELECT ITEM_MST_ID
                                 , ACCOUNT_ID
                                 , BUCKET_START_DATE
                                 , sum(qty) qty 
                              FROM TB_DP_ENTRY A 
                                  ,FN_DP_TEMP_CAL( v_STRT_DATE, v_END_DATE, v_BUCK ) CA
                             WHERE A.QTY > 0 
                               AND A.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
                               AND A.VER_ID = v_DP_VERSION_ID
                               AND A.AUTH_TP_ID = v_AUTH_TP_ID
                             GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE
                        ) T_FINAL_DP 
						ON  M.ITEM_ID = T_FINAL_DP.ITEM_MST_ID 
						AND M.ACCOUNT_ID = T_FINAL_DP.ACCOUNT_ID
						AND T_FINAL_DP.BUCKET_START_DATE = M.BUCKET_START_DATE
					LEFT OUTER JOIN  
					  (
						SELECT ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE, sum(ON_TIME_QTY) ON_TIME_QTY -- delivery_qty? on_time_qty?
						  FROM TB_RT_DMND_ORD_TRACKING_MST A,	-- MP 기준으로
						   FN_DP_TEMP_CAL( v_STRT_DATE, v_END_DATE, v_BUCK ) CA
						WHERE A.ON_TIME_QTY > 0 
						  AND A.CONBD_MAIN_VER_DTL_ID = (  SELECT ID
                                                             FROM ( SELECT	MAX(A.ID) OVER (ORDER BY A.SIMUL_VER_ID DESC ) ID
                                                                    FROM	TB_CM_CONBD_MAIN_VER_DTL A
                                                                            INNER JOIN TB_CM_CONBD_MAIN_VER_MST B
                                                                            ON B.ID = A.CONBD_MAIN_VER_MST_ID
                                                                            INNER JOIN TB_DP_CONTROL_BOARD_VER_MST C
                                                                            ON C.ID = B.DMND_VER_ID
                                                                    WHERE	C.VER_ID = p_VER_ID 
                                                                    AND		A.CONFRM_YN = 'Y'
                                                                    AND     B.MODULE_ID = (SELECT C.ID
                                                                                             FROM TB_AD_COMN_GRP G
                                                                                                  INNER JOIN 
                                                                                                  TB_AD_COMN_CODE C
                                                                                                ON G.ID = C.SRC_ID 
                                                                                             WHERE COMN_CD = 'MP' AND G.GRP_CD = 'MODULE_TP'
                                                                                            )
                                                                    )
                                                            WHERE ROWNUM=1
														  )
						  AND A.DELIVY_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
					 GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE
					) T_RTF 
                  ON T_RTF.ITEM_MST_ID = M.ITEM_ID
                  AND T_RTF.ACCOUNT_ID = M.ACCOUNT_ID
                  AND T_RTF.BUCKET_START_DATE = M.BUCKET_START_DATE
	GROUP BY 	  
          M.BUCKET_START_DATE
		, CASE WHEN v_DIMENSION_01_ACTV_YN = 'Y' THEN ITEM_LVL01_CD	   ELSE NULL END 
		, CASE WHEN v_DIMENSION_02_ACTV_YN = 'Y' THEN ITEM_LVL01_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_03_ACTV_YN = 'Y' THEN ITEM_LVL02_CD	   ELSE NULL END 
		, CASE WHEN v_DIMENSION_04_ACTV_YN = 'Y' THEN ITEM_LVL02_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_05_ACTV_YN = 'Y' THEN ITEM_LVL03_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_06_ACTV_YN = 'Y' THEN ITEM_LVL03_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_07_ACTV_YN = 'Y' THEN ITEM_LVL04_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_08_ACTV_YN = 'Y' THEN ITEM_LVL04_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_09_ACTV_YN = 'Y' THEN ITEM_LVL05_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_10_ACTV_YN = 'Y' THEN ITEM_LVL05_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_11_ACTV_YN = 'Y' THEN ITEM_LVL06_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_12_ACTV_YN = 'Y' THEN ITEM_LVL06_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_13_ACTV_YN = 'Y' THEN ITEM_LVL07_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_14_ACTV_YN = 'Y' THEN ITEM_LVL07_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_15_ACTV_YN = 'Y' THEN ITEM_LVL08_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_16_ACTV_YN = 'Y' THEN ITEM_LVL08_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_17_ACTV_YN = 'Y' THEN ITEM_LVL09_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_18_ACTV_YN = 'Y' THEN ITEM_LVL09_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_19_ACTV_YN = 'Y' THEN ITEM_LVL10_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_20_ACTV_YN = 'Y' THEN ITEM_LVL10_NM       ELSE NULL END

        -- ACCOUNT
		, CASE WHEN v_DIMENSION_21_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_22_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_23_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_24_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_NM	      ELSE NULL END 
		, CASE WHEN v_DIMENSION_25_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_26_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_27_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_28_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_29_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_30_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_NM	      ELSE NULL END 
		, CASE WHEN v_DIMENSION_31_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_32_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_33_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_34_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_35_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_36_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_NM	      ELSE NULL END 
		, CASE WHEN v_DIMENSION_37_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_38_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_39_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_40_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_NM       ELSE NULL END 
        , CASE v_LAST_ITEM_LV WHEN 1            THEN  ITEM_LVL01_CD
                              WHEN 2             THEN  ITEM_LVL01_CD
                              WHEN 3             THEN  ITEM_LVL02_CD
                              WHEN 4             THEN  ITEM_LVL02_CD
                              WHEN 5             THEN  ITEM_LVL03_CD
                              WHEN 6             THEN  ITEM_LVL03_CD
                              WHEN 7             THEN  ITEM_LVL04_CD
                              WHEN 8             THEN  ITEM_LVL04_CD
                              WHEN 9             THEN  ITEM_LVL05_CD
                              WHEN 10            THEN  ITEM_LVL05_CD
                              WHEN 11            THEN  ITEM_LVL06_CD
                              WHEN 12            THEN  ITEM_LVL06_CD
                              WHEN 13            THEN  ITEM_LVL07_CD
                              WHEN 14            THEN  ITEM_LVL07_CD
                              WHEN 15            THEN  ITEM_LVL08_CD
                              WHEN 16            THEN  ITEM_LVL08_CD
                              WHEN 17            THEN  ITEM_LVL09_CD
                              WHEN 18            THEN  ITEM_LVL09_CD
                              WHEN 19            THEN  ITEM_LVL10_CD
                              WHEN 20            THEN  ITEM_LVL10_CD
							  ELSE NULL
							  END	                            
        , CASE v_LAST_ACCT_LV WHEN 21           THEN  ACCOUNT_LVL01_CD
                              WHEN 22            THEN  ACCOUNT_LVL01_CD
                              WHEN 23            THEN  ACCOUNT_LVL02_CD
                              WHEN 24            THEN  ACCOUNT_LVL02_CD
                              WHEN 25            THEN  ACCOUNT_LVL03_CD
                              WHEN 26            THEN  ACCOUNT_LVL03_CD
                              WHEN 27            THEN  ACCOUNT_LVL04_CD
                              WHEN 28            THEN  ACCOUNT_LVL04_CD
                              WHEN 29            THEN  ACCOUNT_LVL05_CD
                              WHEN 30            THEN  ACCOUNT_LVL05_CD
                              WHEN 31            THEN  ACCOUNT_LVL06_CD
                              WHEN 32            THEN  ACCOUNT_LVL06_CD
                              WHEN 33            THEN  ACCOUNT_LVL07_CD
                              WHEN 34            THEN  ACCOUNT_LVL07_CD
                              WHEN 35            THEN  ACCOUNT_LVL08_CD
                              WHEN 36            THEN  ACCOUNT_LVL08_CD
                              WHEN 37            THEN  ACCOUNT_LVL09_CD
                              WHEN 38            THEN  ACCOUNT_LVL09_CD
                              WHEN 39            THEN  ACCOUNT_LVL10_CD
                              WHEN 40            THEN  ACCOUNT_LVL10_CD
							  ELSE NULL
                END
		;
    ELSE
        OPEN pRESULT FOR
        SELECT 
		  CASE WHEN v_DIMENSION_01_ACTV_YN = 'Y' THEN ITEM_LVL01_CD	   ELSE NULL END AS DIMENSION_01
		, CASE WHEN v_DIMENSION_02_ACTV_YN = 'Y' THEN ITEM_LVL01_NM       ELSE NULL END AS DIMENSION_02
		, CASE WHEN v_DIMENSION_03_ACTV_YN = 'Y' THEN ITEM_LVL02_CD	   ELSE NULL END AS DIMENSION_03
		, CASE WHEN v_DIMENSION_04_ACTV_YN = 'Y' THEN ITEM_LVL02_NM       ELSE NULL END AS DIMENSION_04
		, CASE WHEN v_DIMENSION_05_ACTV_YN = 'Y' THEN ITEM_LVL03_CD       ELSE NULL END AS DIMENSION_05
		, CASE WHEN v_DIMENSION_06_ACTV_YN = 'Y' THEN ITEM_LVL03_NM       ELSE NULL END AS DIMENSION_06
		, CASE WHEN v_DIMENSION_07_ACTV_YN = 'Y' THEN ITEM_LVL04_CD       ELSE NULL END AS DIMENSION_07
		, CASE WHEN v_DIMENSION_08_ACTV_YN = 'Y' THEN ITEM_LVL04_NM       ELSE NULL END AS DIMENSION_08
		, CASE WHEN v_DIMENSION_09_ACTV_YN = 'Y' THEN ITEM_LVL05_CD	   ELSE NULL END AS DIMENSION_09
		, CASE WHEN v_DIMENSION_10_ACTV_YN = 'Y' THEN ITEM_LVL05_NM       ELSE NULL END AS DIMENSION_10
		, CASE WHEN v_DIMENSION_11_ACTV_YN = 'Y' THEN ITEM_LVL06_CD       ELSE NULL END AS DIMENSION_11
		, CASE WHEN v_DIMENSION_12_ACTV_YN = 'Y' THEN ITEM_LVL06_NM       ELSE NULL END AS DIMENSION_12
		, CASE WHEN v_DIMENSION_13_ACTV_YN = 'Y' THEN ITEM_LVL07_CD       ELSE NULL END AS DIMENSION_13
		, CASE WHEN v_DIMENSION_14_ACTV_YN = 'Y' THEN ITEM_LVL07_NM       ELSE NULL END AS DIMENSION_14
		, CASE WHEN v_DIMENSION_15_ACTV_YN = 'Y' THEN ITEM_LVL08_CD       ELSE NULL END AS DIMENSION_15
		, CASE WHEN v_DIMENSION_16_ACTV_YN = 'Y' THEN ITEM_LVL08_NM       ELSE NULL END AS DIMENSION_16
		, CASE WHEN v_DIMENSION_17_ACTV_YN = 'Y' THEN ITEM_LVL09_CD       ELSE NULL END AS DIMENSION_17
		, CASE WHEN v_DIMENSION_18_ACTV_YN = 'Y' THEN ITEM_LVL09_NM       ELSE NULL END AS DIMENSION_18
		, CASE WHEN v_DIMENSION_19_ACTV_YN = 'Y' THEN ITEM_LVL10_CD       ELSE NULL END AS DIMENSION_19
		, CASE WHEN v_DIMENSION_20_ACTV_YN = 'Y' THEN ITEM_LVL10_NM       ELSE NULL END AS DIMENSION_20

        -- ACCOUNT
		, CASE WHEN v_DIMENSION_21_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_CD       ELSE NULL END AS DIMENSION_21
		, CASE WHEN v_DIMENSION_22_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_NM       ELSE NULL END AS DIMENSION_22
		, CASE WHEN v_DIMENSION_23_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_CD       ELSE NULL END AS DIMENSION_23
		, CASE WHEN v_DIMENSION_24_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_NM	      ELSE NULL END AS DIMENSION_24
		, CASE WHEN v_DIMENSION_25_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_CD       ELSE NULL END AS DIMENSION_25
		, CASE WHEN v_DIMENSION_26_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_NM       ELSE NULL END AS DIMENSION_26
		, CASE WHEN v_DIMENSION_27_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_CD       ELSE NULL END AS DIMENSION_27
		, CASE WHEN v_DIMENSION_28_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_NM       ELSE NULL END AS DIMENSION_28
		, CASE WHEN v_DIMENSION_29_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_CD       ELSE NULL END AS DIMENSION_29
		, CASE WHEN v_DIMENSION_30_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_NM       ELSE NULL END AS DIMENSION_30
		, CASE WHEN v_DIMENSION_31_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_CD       ELSE NULL END AS DIMENSION_31
		, CASE WHEN v_DIMENSION_32_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_NM       ELSE NULL END AS DIMENSION_32        
		, CASE WHEN v_DIMENSION_33_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_CD       ELSE NULL END AS DIMENSION_33
		, CASE WHEN v_DIMENSION_34_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_NM       ELSE NULL END AS DIMENSION_34
		, CASE WHEN v_DIMENSION_35_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_CD       ELSE NULL END AS DIMENSION_35
		, CASE WHEN v_DIMENSION_36_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_NM       ELSE NULL END AS DIMENSION_36
		, CASE WHEN v_DIMENSION_37_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_CD       ELSE NULL END AS DIMENSION_37
		, CASE WHEN v_DIMENSION_38_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_NM       ELSE NULL END AS DIMENSION_38
		, CASE WHEN v_DIMENSION_39_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_CD       ELSE NULL END AS DIMENSION_39
		, CASE WHEN v_DIMENSION_40_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_NM       ELSE NULL END AS DIMENSION_40
        , CASE v_LAST_ITEM_LV WHEN 1             THEN  ITEM_LVL01_CD
                               WHEN 2             THEN  ITEM_LVL01_CD
                               WHEN 3             THEN  ITEM_LVL02_CD
                               WHEN 4             THEN  ITEM_LVL02_CD
                               WHEN 5             THEN  ITEM_LVL03_CD
                               WHEN 6             THEN  ITEM_LVL03_CD
                               WHEN 7             THEN  ITEM_LVL04_CD
                               WHEN 8             THEN  ITEM_LVL04_cD
                               WHEN 9             THEN  ITEM_LVL05_CD
                               WHEN 10            THEN  ITEM_LVL05_cD
                               WHEN 11            THEN  ITEM_LVL06_CD
                               WHEN 12            THEN  ITEM_LVL06_CD
                               WHEN 13            THEN  ITEM_LVL07_CD
                               WHEN 14            THEN  ITEM_LVL07_CD
                               WHEN 15            THEN  ITEM_LVL08_CD
                               WHEN 16            THEN  ITEM_LVL08_CD
                               WHEN 17            THEN  ITEM_LVL09_CD
                               WHEN 18            THEN  ITEM_LVL09_cD
                               WHEN 19            THEN  ITEM_LVL10_CD
                               WHEN 20            THEN  ITEM_LVL10_CD
							  END	AS ITEM

        , CASE v_LAST_ACCT_LV WHEN 21            THEN  ACCOUNT_LVL01_CD
                               WHEN 22            THEN  ACCOUNT_LVL01_CD
                               WHEN 23            THEN  ACCOUNT_LVL02_CD
                               WHEN 24            THEN  ACCOUNT_LVL02_CD
                               WHEN 25            THEN  ACCOUNT_LVL03_CD
                               WHEN 26            THEN  ACCOUNT_LVL03_CD
                               WHEN 27            THEN  ACCOUNT_LVL04_CD
                               WHEN 28            THEN  ACCOUNT_LVL04_CD
                               WHEN 29            THEN  ACCOUNT_LVL05_CD
                               WHEN 30            THEN  ACCOUNT_LVL05_CD
                               WHEN 31            THEN  ACCOUNT_LVL06_CD
                               WHEN 32            THEN  ACCOUNT_LVL06_cD
                               WHEN 33            THEN  ACCOUNT_LVL07_CD
                               WHEN 34            THEN  ACCOUNT_LVL07_CD
                               WHEN 35            THEN  ACCOUNT_LVL08_CD
                               WHEN 36            THEN  ACCOUNT_LVL08_CD
                               WHEN 37            THEN  ACCOUNT_LVL09_CD
                               WHEN 38            THEN  ACCOUNT_LVL09_cD
                               WHEN 39            THEN  ACCOUNT_LVL10_CD
                               WHEN 40            THEN  ACCOUNT_LVL10_cD
                END AS ACCOUNT
               , 'COMMON'                  AS SALES		
               ,M.BUCKET_START_DATE   AS "CATEGORY"  
               ,M.BUCKET_START_DATE   AS "DATE"  
			   -- MEASURE
			   , SUM( COALESCE(T_FINAL_DP.AMT, 0))										AS MEASURE_01
			   , SUM( COALESCE(T_RTF.ON_TIME_QTY, 0))										AS MEASURE_02
				/* 0으로 나누는 경우 예외처리 */
			   , CASE WHEN	SUM( COALESCE(T_FINAL_DP.AMT, 0)) = 0 THEN 0
					  ELSE	SUM( COALESCE(T_RTF.ON_TIME_QTY, 0) ) / SUM( COALESCE(T_FINAL_DP.AMT, 0) ) * 100
					  END	AS MEASURE_03			
         FROM		    (
							SELECT         
									  IH.LVL01_ID				AS ITEM_LVL01_ID 	
									, IH.LVL01_CD				AS ITEM_LVL01_CD 	
									, IH.LVL01_NM				AS ITEM_LVL01_NM 	
									, IH.LVL02_ID				AS ITEM_LVL02_ID 	
									, IH.LVL02_CD				AS ITEM_LVL02_CD 	
									, IH.LVL02_NM				AS ITEM_LVL02_NM 	
									, IH.LVL03_ID				AS ITEM_LVL03_ID 	
									, IH.LVL03_CD				AS ITEM_LVL03_CD 	
									, IH.LVL03_NM				AS ITEM_LVL03_NM 	
									, IH.LVL04_ID				AS ITEM_LVL04_ID 	
									, IH.LVL04_CD				AS ITEM_LVL04_CD 	
									, IH.LVL04_NM				AS ITEM_LVL04_NM 	
									, IH.LVL05_ID				AS ITEM_LVL05_ID 	
									, IH.LVL05_CD				AS ITEM_LVL05_CD 	
									, IH.LVL05_NM				AS ITEM_LVL05_NM 	
									, IH.LVL06_ID				AS ITEM_LVL06_ID 	
									, IH.LVL06_CD				AS ITEM_LVL06_CD 	
									, IH.LVL06_NM				AS ITEM_LVL06_NM 	
									, IH.LVL07_ID				AS ITEM_LVL07_ID 	
									, IH.LVL07_CD				AS ITEM_LVL07_CD 	
									, IH.LVL07_NM				AS ITEM_LVL07_NM 	
									, IH.LVL08_ID				AS ITEM_LVL08_ID 	
									, IH.LVL08_CD				AS ITEM_LVL08_CD 	
									, IH.LVL08_NM				AS ITEM_LVL08_NM 	
									, IH.LVL09_ID				AS ITEM_LVL09_ID 	
									, IH.LVL09_CD				AS ITEM_LVL09_CD 	
									, IH.LVL09_NM				AS ITEM_LVL09_NM 	
									, IH.LVL10_ID				AS ITEM_LVL10_ID 	
									, IH.LVL10_CD				AS ITEM_LVL10_CD 	
									, IH.LVL10_NM				AS ITEM_LVL10_NM 	
									, IH.ITEM_ID				AS ITEM_ID 			
									, IH.ITEM_CD				AS ITEM_CD 			
									, IH.ITEM_NM 				AS ITEM_NM  		
									, AH.LVL01_ID				AS ACCOUNT_LVL01_ID 
									, AH.LVL01_CD				AS ACCOUNT_LVL01_CD 
									, AH.LVL01_NM				AS ACCOUNT_LVL01_NM 
									, AH.LVL02_ID				AS ACCOUNT_LVL02_ID 
									, AH.LVL02_CD				AS ACCOUNT_LVL02_CD 
									, AH.LVL02_NM				AS ACCOUNT_LVL02_NM 
									, AH.LVL03_ID				AS ACCOUNT_LVL03_ID 
									, AH.LVL03_CD				AS ACCOUNT_LVL03_CD 
									, AH.LVL03_NM				AS ACCOUNT_LVL03_NM 
									, AH.LVL04_ID				AS ACCOUNT_LVL04_ID 
									, AH.LVL04_CD				AS ACCOUNT_LVL04_CD 
									, AH.LVL04_NM				AS ACCOUNT_LVL04_NM 
									, AH.LVL05_ID				AS ACCOUNT_LVL05_ID 
									, AH.LVL05_CD				AS ACCOUNT_LVL05_CD 
									, AH.LVL05_NM				AS ACCOUNT_LVL05_NM 
									, AH.LVL06_ID				AS ACCOUNT_LVL06_ID 
									, AH.LVL06_CD				AS ACCOUNT_LVL06_CD 
									, AH.LVL06_NM				AS ACCOUNT_LVL06_NM 
									, AH.LVL07_ID				AS ACCOUNT_LVL07_ID 
									, AH.LVL07_CD				AS ACCOUNT_LVL07_CD 
									, AH.LVL07_NM				AS ACCOUNT_LVL07_NM 
									, AH.LVL08_ID				AS ACCOUNT_LVL08_ID 
									, AH.LVL08_CD				AS ACCOUNT_LVL08_CD 
									, AH.LVL08_NM				AS ACCOUNT_LVL08_NM 
									, AH.LVL09_ID				AS ACCOUNT_LVL09_ID 
									, AH.LVL09_CD				AS ACCOUNT_LVL09_CD 
									, AH.LVL09_NM				AS ACCOUNT_LVL09_NM 
									, AH.LVL10_ID				AS ACCOUNT_LVL10_ID 
									, AH.LVL10_CD				AS ACCOUNT_LVL10_CD 
									, AH.LVL10_NM				AS ACCOUNT_LVL10_NM 
									, AH.ACCOUNT_ID				AS ACCOUNT_ID 		
									, AH.ACCOUNT_CD				AS ACCOUNT_CD 		
									, AH.ACCOUNT_NM				AS ACCOUNT_NM 		
									, CA.BUCKET_START_DATE		AS BUCKET_START_DATE
									, CA.BUCKET_END_DATE		AS BUCKET_END_DATE 	                     
								FROM (
											SELECT DO.ITEM_MST_ID ,DO.ACCOUNT_ID 
											  FROM TB_DP_ENTRY DO
											 WHERE 1=1  
											   AND DO. VER_ID = p_VER_ID
											   AND DO.AUTH_TP_ID = p_AUTH_TP_ID
										  GROUP BY DO.ITEM_MST_ID ,DO.ACCOUNT_ID 
									   ) DO
									  INNER JOIN -- FN_Dp_TEMp_CAL : 버킷별로 CALENDAR 정보 가져오는 함수
									   FN_DP_TEMP_CAL(p_STRT_DATE, p_END_DATE, p_BUCK) CA ON(1=1)
									  INNER JOIN
									  TB_DPD_ITEM_HIERACHY2 IH                                  
								 ON   IH.ITEM_ID = DO.ITEM_MST_ID
									  INNER JOIN
									  TB_DPD_ACCOUNT_HIERACHY2 AH
								 ON   AH.ACCOUNT_ID = DO.ACCOUNT_ID                    
								 WHERE   1=1      -- ( ) [ ]
                                   AND (REGEXP_LIKE(UPPER(AH.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                                        OR v_ACCT_CD IS NULL
                                  )
-- 								   AND (  ( v_ACCT_CD LIKE '%|%' 
--											AND AH.ACCOUNT_CD IN (
--                                                SELECT TRIM(REGEXP_SUBSTR(v_ACCT_CD, '[^|]+', 1, LEVEL)) AS ACCT_CD
--                                                    FROM DUAL
--                                                CONNECT BY INSTR(v_ACCT_CD, '|', 1, LEVEL - 1) > 0
--                                            )
-- 					 					)OR(COALESCE(v_ACCT_CD,'') NOT LIKE '%|%' 
--											AND COALESCE(AH.ACCOUNT_CD,'')  LIKE  '%' || COALESCE(v_ACCT_CD,'') || '%'  ))

                                   AND (REGEXP_LIKE(UPPER(IH.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                                        OR v_ITEM_CD IS NULL
                                  )
-- 								   AND (  ( v_ITEM_CD LIKE '%|%' 
--											AND IH.ITEM_CD IN (
--                                                SELECT TRIM(REGEXP_SUBSTR(v_ITEM_CD, '[^|]+', 1, LEVEL)) AS ITEM_CD
--                                                    FROM DUAL
--                                                CONNECT BY INSTR(v_ITEM_CD, '|', 1, LEVEL - 1) > 0
--                                            )
-- 										)OR(COALESCE(v_ITEM_CD,'') NOT LIKE '%|%' 
--											AND COALESCE(IH.ITEM_CD,'')  LIKE  '%' || COALESCE(v_ITEM_CD,'') || '%'   ))
								 AND ( v_ITEM_LV_CD = 
									 CASE WHEN v_SEARCH_LV_SEQ = 1  THEN  IH.LVL01_CD		    
										  WHEN v_SEARCH_LV_SEQ = 2  THEN  IH.LVL02_CD		    
										  WHEN v_SEARCH_LV_SEQ = 3  THEN  IH.LVL03_CD      
										  WHEN v_SEARCH_LV_SEQ = 4  THEN  IH.LVL04_CD      
										  WHEN v_SEARCH_LV_SEQ = 5  THEN  IH.LVL05_CD	     
										  WHEN v_SEARCH_LV_SEQ = 6  THEN  IH.LVL06_CD      
										  WHEN v_SEARCH_LV_SEQ = 7  THEN  IH.LVL07_CD      
										  WHEN v_SEARCH_LV_SEQ = 8  THEN  IH.LVL08_CD      
										  WHEN v_SEARCH_LV_SEQ = 9  THEN  IH.LVL09_CD      
										  WHEN v_SEARCH_LV_SEQ = 10 THEN  IH.LVL10_CD      
										  ELSE NULL END
									OR v_ITEM_LV_CD IS NULL
								 )
								 AND ( v_ACCT_LV_CD =  
										 CASE WHEN v_SEARCH_LV_SEQ_02 = 1  THEN  AH.LVL01_CD		    
											  WHEN v_SEARCH_LV_SEQ_02 = 2  THEN  AH.LVL02_CD		    
											  WHEN v_SEARCH_LV_SEQ_02 = 3  THEN  AH.LVL03_CD      
											  WHEN v_SEARCH_LV_SEQ_02 = 4  THEN  AH.LVL04_CD      
											  WHEN v_SEARCH_LV_SEQ_02 = 5  THEN  AH.LVL05_CD	     
											  WHEN v_SEARCH_LV_SEQ_02 = 6  THEN  AH.LVL06_CD      
											  WHEN v_SEARCH_LV_SEQ_02 = 7  THEN  AH.LVL07_CD      
											  WHEN v_SEARCH_LV_SEQ_02 = 8  THEN  AH.LVL08_CD      
											  WHEN v_SEARCH_LV_SEQ_02 = 9  THEN  AH.LVL09_CD       
											  WHEN v_SEARCH_LV_SEQ_02 = 10 THEN  AH.LVL10_CD      
											  ELSE NULL END
									OR v_ACCT_LV_CD IS NULL
								 )     			 
						) M            
				  LEFT OUTER JOIN (
									SELECT ITEM_MST_ID
										 , ACCOUNT_ID
										 , BUCKET_START_DATE
										 , sum(amt) amt 
									  FROM TB_DP_ENTRY A 
										  ,FN_DP_TEMP_CAL( v_STRT_DATE, v_END_DATE, v_BUCK ) CA
									WHERE A.AMT > 0 
									  AND A.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
									  AND A.VER_ID = v_DP_VERSION_ID
									  AND A.AUTH_TP_ID = v_AUTH_TP_ID
								 GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE
								) T_FINAL_DP 
								ON  M.ITEM_ID = T_FINAL_DP.ITEM_MST_ID 
								AND M.ACCOUNT_ID = T_FINAL_DP.ACCOUNT_ID
								AND T_FINAL_DP.BUCKET_START_DATE = M.BUCKET_START_DATE
                 LEFT OUTER JOIN (
									SELECT ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE, sum(ON_TIME_QTY) ON_TIME_QTY 
									  FROM TB_RT_DMND_ORD_TRACKING_MST A, 
									   FN_DP_TEMP_CAL( v_STRT_DATE, v_END_DATE, v_BUCK ) CA
									WHERE A.ON_TIME_QTY > 0 
									  AND A.CONBD_MAIN_VER_DTL_ID IN (  SELECT CONBD_MAIN_VER_DTL_ID
                                                                           FROM ( SELECT CONBD_MAIN_VER_DTL_ID
                                                                                    FROM TB_RT_DMND_ORD_TRACKING_MST 
                                                                                   ORDER BY CREATE_DTTM DESC	 
                                                                                )
                                                                          WHERE ROWNUM=1
																	  )
									  AND A.DELIVY_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
									GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE
								  ) T_RTF 
                  ON T_RTF.ITEM_MST_ID = M.ITEM_ID
                  AND T_RTF.ACCOUNT_ID = M.ACCOUNT_ID
                  AND T_RTF.BUCKET_START_DATE = M.BUCKET_START_DATE

GROUP BY 	  
          M.BUCKET_START_DATE
		, CASE WHEN v_DIMENSION_01_ACTV_YN = 'Y' THEN ITEM_LVL01_CD	    ELSE NULL END 
		, CASE WHEN v_DIMENSION_02_ACTV_YN = 'Y' THEN ITEM_LVL01_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_03_ACTV_YN = 'Y' THEN ITEM_LVL02_CD	   ELSE NULL END 
		, CASE WHEN v_DIMENSION_04_ACTV_YN = 'Y' THEN ITEM_LVL02_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_05_ACTV_YN = 'Y' THEN ITEM_LVL03_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_06_ACTV_YN = 'Y' THEN ITEM_LVL03_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_07_ACTV_YN = 'Y' THEN ITEM_LVL04_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_08_ACTV_YN = 'Y' THEN ITEM_LVL04_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_09_ACTV_YN = 'Y' THEN ITEM_LVL05_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_10_ACTV_YN = 'Y' THEN ITEM_LVL05_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_11_ACTV_YN = 'Y' THEN ITEM_LVL06_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_12_ACTV_YN = 'Y' THEN ITEM_LVL06_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_13_ACTV_YN = 'Y' THEN ITEM_LVL07_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_14_ACTV_YN = 'Y' THEN ITEM_LVL07_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_15_ACTV_YN = 'Y' THEN ITEM_LVL08_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_16_ACTV_YN = 'Y' THEN ITEM_LVL08_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_17_ACTV_YN = 'Y' THEN ITEM_LVL09_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_18_ACTV_YN = 'Y' THEN ITEM_LVL09_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_19_ACTV_YN = 'Y' THEN ITEM_LVL10_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_20_ACTV_YN = 'Y' THEN ITEM_LVL10_NM       ELSE NULL END

        -- ACCOUNT
		, CASE WHEN v_DIMENSION_21_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_22_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_23_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_24_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_NM	      ELSE NULL END 
		, CASE WHEN v_DIMENSION_25_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_26_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_27_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_28_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_29_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_30_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_NM	      ELSE NULL END 
		, CASE WHEN v_DIMENSION_31_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_32_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_33_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_34_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_35_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_36_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_NM	      ELSE NULL END 
		, CASE WHEN v_DIMENSION_37_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_38_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_39_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_40_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_NM       ELSE NULL END 
        , CASE v_LAST_ITEM_LV WHEN 1             THEN  ITEM_LVL01_CD
                              WHEN 2             THEN  ITEM_LVL01_CD
                              WHEN 3             THEN  ITEM_LVL02_CD
                              WHEN 4             THEN  ITEM_LVL02_CD
                              WHEN 5             THEN  ITEM_LVL03_CD
                              WHEN 6             THEN  ITEM_LVL03_CD
                              WHEN 7             THEN  ITEM_LVL04_CD
                              WHEN 8             THEN  ITEM_LVL04_CD
                              WHEN 9             THEN  ITEM_LVL05_CD
                              WHEN 10            THEN  ITEM_LVL05_CD
                              WHEN 11            THEN  ITEM_LVL06_CD
                              WHEN 12            THEN  ITEM_LVL06_CD
                              WHEN 13            THEN  ITEM_LVL07_CD
                              WHEN 14            THEN  ITEM_LVL07_CD
                              WHEN 15            THEN  ITEM_LVL08_CD
                              WHEN 16            THEN  ITEM_LVL08_CD
                              WHEN 17            THEN  ITEM_LVL09_CD
                              WHEN 18            THEN  ITEM_LVL09_CD
                              WHEN 19            THEN  ITEM_LVL10_CD
                              WHEN 20            THEN  ITEM_LVL10_CD
							  END	

        , CASE v_LAST_ACCT_LV WHEN 21            THEN  ACCOUNT_LVL01_CD
                              WHEN 22            THEN  ACCOUNT_LVL01_CD
                              WHEN 23            THEN  ACCOUNT_LVL02_CD
                              WHEN 24            THEN  ACCOUNT_LVL02_CD
                              WHEN 25            THEN  ACCOUNT_LVL03_CD
                              WHEN 26            THEN  ACCOUNT_LVL03_CD
                              WHEN 27            THEN  ACCOUNT_LVL04_CD
                              WHEN 28            THEN  ACCOUNT_LVL04_CD
                              WHEN 29            THEN  ACCOUNT_LVL05_CD
                              WHEN 30            THEN  ACCOUNT_LVL05_CD
                              WHEN 31            THEN  ACCOUNT_LVL06_CD
                              WHEN 32            THEN  ACCOUNT_LVL06_CD
                              WHEN 33            THEN  ACCOUNT_LVL07_CD
                              WHEN 34            THEN  ACCOUNT_LVL07_CD
                              WHEN 35            THEN  ACCOUNT_LVL08_CD
                              WHEN 36            THEN  ACCOUNT_LVL08_CD
                              WHEN 37            THEN  ACCOUNT_LVL09_CD
                              WHEN 38            THEN  ACCOUNT_LVL09_CD
                              WHEN 39            THEN  ACCOUNT_LVL10_CD
                              WHEN 40            THEN  ACCOUNT_LVL10_CD
                END
		;
    END IF;

    P_RT_MSG := 'MSG_0003';

    EXCEPTION WHEN OTHERS THEN
              IF(SQLCODE = -20001)
              THEN
                  P_RT_MSG := sqlerrm;
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;   	
--     	   SET p_RT_MSG = 'MSG_0003'  --조회 되었습니다.
--END TRY
--BEGIN CATCH
--	IF (ERROR_MESSAGE() LIKE 'MSG_%')
--		BEGIN
--			SET v_ERR_MSG = ERROR_MESSAGE()
--			SET p_RT_MSG = v_ERR_MSG
--		END
--	ELSE 
----			THROW
--			EXEC SP_COMM_RAISE_ERR

END;

/

