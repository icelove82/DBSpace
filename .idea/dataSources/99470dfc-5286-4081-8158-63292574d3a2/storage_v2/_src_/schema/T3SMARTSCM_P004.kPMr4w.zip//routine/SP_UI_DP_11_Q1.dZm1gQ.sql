create PROCEDURE "SP_UI_DP_11_Q1" (p_PARENT_SALES_LV_ID  IN VARCHAR2 := ''
                                    ,P_ACCOUNT_CD  IN VARCHAR2 := ''
                                    ,P_ACCOUNT_NM  IN VARCHAR2 := ''
                                    ,p_SOLD_TO_CD  IN VARCHAR2 := ''
                                    ,p_SOLD_TO_NM  IN VARCHAR2 := ''
                                    ,p_SHIP_TO_CD  IN VARCHAR2 := ''
                                    ,p_SHIP_TO_NM  IN VARCHAR2 := ''
                                    ,p_BILL_TO_CD  IN VARCHAR2 := ''
                                    ,p_BILL_TO_NM  IN VARCHAR2 := ''
                                    ,P_DEL_YN      IN VARCHAR2 := '' 
                                             ,pRESULT       OUT SYS_REFCURSOR ) IS 


BEGIN

        OPEN pRESULT
        FOR
        SELECT AM.ID
              ,AM.ACCOUNT_CD
              ,AM.ACCOUNT_NM
              ,AM.PARENT_SALES_LV_ID
              ,SL.SALES_LV_CD AS PARENT_SALES_LV_CD
              ,SL.SALES_LV_NM AS PARENT_SALES_LV_NM
              ,AM.CURCY_CD_ID
              , CUR.COMN_CD  AS CURCY_CD
              , CUR.COMN_CD_NM  AS CURCY_NM
              ,AM.COUNTRY_ID
              , CON.CONF_CD  AS COUNTRY_CD
              , CON.CONF_NM  AS COUNTRY_NM
              ,AM.CHANNEL_ID
              , CHA.CONF_CD  AS CHANNEL_CD
              , CHA.CONF_NM  AS CHANNEL_NM
              ,AM.SOLD_TO_ID
              , SO.CUST_CD AS SOLD_TO_CD              
              , SO.CUST_NM AS SOLD_TO_NM
              ,AM.SHIP_TO_ID
              , SH.CUST_CD AS SHIP_TO_CD
              , SH.CUST_NM AS SHIP_TO_NM
              ,AM.BILL_TO_ID
              , BI.CUST_CD AS BILL_TO_CD
              , BI.CUST_NM AS BILL_TO_NM
              ,AM.SRP_YN
              ,AM.INCOTERMS_ID
              , INC.INCOTERMS  AS INCOTERMS_CD
              ,AM.VMI_YN
              ,AM.DIRECT_SHPP_YN
              ,AM.ACTV_YN
              ,AM.DEL_YN
              ,AM.ATTR_01
              ,AM.ATTR_02
              ,AM.ATTR_03
              ,AM.ATTR_04
              ,AM.ATTR_05
              ,AM.ATTR_06
              ,AM.ATTR_07
              ,AM.ATTR_08
              ,AM.ATTR_09
              ,AM.ATTR_10
              ,AM.ATTR_11
              ,AM.ATTR_12
              ,AM.ATTR_13
              ,AM.ATTR_14
              ,AM.ATTR_15
              ,AM.ATTR_16
              ,AM.ATTR_17
              ,AM.ATTR_18
              ,AM.ATTR_19
              ,AM.ATTR_20
              ,AM.CREATE_BY
              ,AM.CREATE_DTTM
              ,AM.MODIFY_BY
              ,AM.MODIFY_DTTM
          FROM TB_DP_ACCOUNT_MST AM
                 LEFT OUTER JOIN ( SELECT CD.ID, CD.COMN_CD, CD.COMN_CD_NM 
                                 FROM TB_AD_COMN_GRP CM
                                    , TB_AD_COMN_CODE CD 
                                 WHERE CM.ID = CD.SRC_ID AND CM.GRP_CD = 'CURRENCY' 
                             ) CUR ON AM.CURCY_CD_ID = CUR.ID 
               LEFT OUTER JOIN (
                                SELECT  B.ID  AS ID
                                      , B.CONF_CD 
                                      , B.CONF_NM 
                                  FROM   TB_CM_CONFIGURATION A
                                      , TB_CM_COMM_CONFIG B
                                         where  A.ID = B.CONF_ID
                                           AND B.CONF_GRP_CD = 'CM_COUNTRY'
                                           AND B.ACTV_YN = 'Y'
                                ) CON  ON AM.COUNTRY_ID = CON.ID 
               LEFT OUTER JOIN (
                                SELECT  B.ID  AS ID
                                      , B.CONF_CD 
                                      , B.CONF_NM 
                                  FROM   TB_CM_CONFIGURATION A
                                      , TB_CM_COMM_CONFIG B
                                         where  A.ID = B.CONF_ID
                                           AND B.CONF_GRP_CD = 'DP_CHANNEL_TP'
                                           AND B.ACTV_YN = 'Y'
                                ) CHA  ON AM.CHANNEL_ID = CON.ID  
               LEFT OUTER JOIN (
                                 SELECT B.ID  AS ID
                                      , B.INCOTERMS
                                  FROM   TB_CM_CONFIGURATION A
                                      , TB_CM_INCOTERMS B
                                         where  A.ID = B.CONF_ID
                                           AND A.CONF_NM = 'INCOTERMS'
                                           AND B.ACTV_YN = 'Y'
                               ) INC  ON AM.INCOTERMS_ID = INC.ID  
              LEFT OUTER JOIN  TB_DP_SALES_LEVEL_MGMT SL ON  AM.PARENT_SALES_LV_ID = SL.ID 
              LEFT OUTER JOIN TB_CM_CUSTOMER SO ON SO.ID = AM.SOLD_TO_ID
              LEFT OUTER JOIN TB_CM_CUSTOMER SH ON SH.ID = AM.SHIP_TO_ID
              LEFT OUTER JOIN TB_CM_CUSTOMER BI ON BI.ID = AM.BILL_TO_ID              
          WHERE (NVL(AM.DEL_YN,'N') = P_DEL_YN OR TRIM(P_DEL_YN) IS NULL)
            AND (RTRIM(SL.ID)  LIKE '%' || LTRIM(RTRIM(p_PARENT_SALES_LV_ID)) || '%'  OR p_PARENT_SALES_LV_ID IS NULL)   
            /*CUST_CD*/
              AND  (  REGEXP_LIKE (UPPER(SO.CUST_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_SOLD_TO_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  p_SOLD_TO_CD IS NULL
                )
              AND  (  REGEXP_LIKE (UPPER(SH.CUST_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_SHIP_TO_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  p_SHIP_TO_CD IS NULL
                )
              AND  (  REGEXP_LIKE (UPPER(BI.CUST_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_BILL_TO_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  p_BILL_TO_CD IS NULL
                )
              AND  (  REGEXP_LIKE (UPPER(SO.CUST_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_SOLD_TO_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  p_SOLD_TO_NM IS NULL
                )
              AND  (  REGEXP_LIKE (UPPER(SH.CUST_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_SHIP_TO_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  p_SHIP_TO_NM IS NULL
                )
              AND  (  REGEXP_LIKE (UPPER(BI.CUST_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_BILL_TO_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  p_BILL_TO_NM IS NULL
                )
              AND  (  REGEXP_LIKE (UPPER(AM.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ACCOUNT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  P_ACCOUNT_CD IS NULL
                )
              AND  (  REGEXP_LIKE (UPPER(AM.ACCOUNT_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ACCOUNT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR  P_ACCOUNT_NM IS NULL
                )

        ORDER BY  SL.SEQ, SL.SALES_LV_CD, AM.ACCOUNT_CD                
        ;

END
;

/

