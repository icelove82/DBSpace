create PROCEDURE "SP_UI_DP_23_TAB_Q2" 
( pRESULT       OUT SYS_REFCURSOR
) 
IS  
/*
        ？？？？ : ？ι？° Tab？？ DP Control Board Gathering ？？？？？？ measure ？？？？？？ ？？？？？
*/
BEGIN
    OPEN pRESULT
    FOR
    SELECT   'ALL'  AS CD
            ,'ALL'  AS CD_NM
            ,'ALL'  AS TBL_NM
      FROM DUAL
    UNION ALL
    SELECT  MEASURE_CD   AS CD
           ,MEASURE_CD   AS CD_NM
           ,TBL_NM       AS TBL_NM
     FROM TB_DP_MEASURE_MST MM
		  INNER JOIN
		  TB_DP_MEASURE_SETTING MS
	   ON MM.ID = MS.MEASURE_MST_ID
    WHERE DP_YN = 'Y'
      AND MS.UI_ID LIKE 'UI_DP_25%'
    GROUP BY  MEASURE_CD   
             ,TBL_NM     
    ;
END
;

/

