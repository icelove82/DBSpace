create PROCEDURE "SP_UI_DP_41_POP_S1" (
    p_MEASURE			VARCHAR2
   ,p_RT_ROLLBACK_FLAG  OUT VARCHAR2
   ,p_RT_MSG            OUT VARCHAR2	   
)IS

p_SQL1 VARCHAR2(4000) := 'ALTER TABLE TB_DP_MEASURE_DATA ADD '||REPLACE(REPLACE(UPPER(p_MEASURE),'_QTY',''),'_AMT','')||'_QTY decimal(20,3)';
p_SQL2 VARCHAR2(4000) := 'ALTER TABLE TB_DP_MEASURE_DATA ADD '||REPLACE(REPLACE(UPPER(p_MEASURE),'_QTY',''),'_AMT','')||'_AMT decimal(20,3)';
p_ERR_STATUS VARCHAR2(2);
p_ERR_MSG VARCHAR2(4000):='';

BEGIN
--	IF(p_MEASURE LIKE 'ACT_SALES%')
--	BEGIN
--		SET p_RT_MSG = 'Actual sales cannot be managed with this UI.'
--	END
--	ELSE 
    SELECT CASE WHEN EXISTS ( SELECT COLUMN_NAME
                                FROM ALL_TAB_COLUMNS
                               WHERE OWNER = (SELECT USER FROM DUAL)
                                 AND TABLE_NAME = 'TB_DP_MEASURE_DATA'
                                 AND COLUMN_NAME LIKE UPPER(p_MEASURE)||'_%'
                            ) THEN '1' ELSE '0' END 
           INTO p_ERR_STATUS
      FROM DUAL;

	IF COALESCE(p_MEASURE,'') = ''
	THEN
		p_RT_MSG := 'Column Name is unclear';
	ELSIF (p_ERR_STATUS='0')
	THEN
		--EXEC SP_EXECUTESQL p_SQL1
		--EXEC SP_EXECUTESQL p_SQL2
        EXECUTE IMMEDIATE p_SQL1;
        EXECUTE IMMEDIATE p_SQL2;
	    p_RT_MSG := 'MSG_0003';
	ELSE
	    p_RT_MSG := 'MSG_0013';
	END IF;

    p_RT_ROLLBACK_FLAG := 'true';

    EXCEPTION WHEN OTHERS THEN
      IF(SQLCODE = -20001)
      THEN
          P_RT_MSG := SQLERRM;   
          p_RT_ROLLBACK_FLAG := 'false';
      ELSE
        RAISE;
      END IF;   	

--END TRY
--BEGIN CATCH
--	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
--		   BEGIN
--			   SET p_ERR_MSG = ERROR_MESSAGE()
--			   SET p_RT_ROLLBACK_FLAG = 'false'
--			   SET p_RT_MSG = p_ERR_MSG
--			END
--	   ELSE 
--				THROW;
----				EXEC SP_COMM_RAISE_ERR
END;

/

