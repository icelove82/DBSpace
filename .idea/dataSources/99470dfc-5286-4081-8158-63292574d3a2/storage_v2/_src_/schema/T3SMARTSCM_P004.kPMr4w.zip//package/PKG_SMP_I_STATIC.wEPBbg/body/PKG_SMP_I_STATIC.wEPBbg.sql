create PACKAGE BODY                 PKG_SMP_I_STATIC
IS 
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved. 
************************************************************************** 
* Name    : PKG_SMP_I_STATIC
* Purpose : MP Static 정보 생성.
* Notes   :
  CORPORATION
  SITE 
  LOCATION
  CUSTOMER
  
  PLAN_MST 
  PLAN_DTL
  
  ITEM
  INVENTORY
  ROUTE
  BOM_ROUTING
  RESOURCE
  BOR
***************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/ 
PRAGMA SERIALLY_REUSABLE;
-----------------------------
-- Public type declarations -
-----------------------------

---------------------------------
-- Public constant declarations -
---------------------------------

---------------------------------
-- Public variable declarations -
---------------------------------
  G_nLOG_SEQ      NUMBER;
  G_sPKG_ID       NVARCHAR2(1000) := 'PKG_SMP_I_STATIC';
  G_sPROGRAMN_ID  NVARCHAR2(50);
  G_sSTEP_SEQ     NVARCHAR2(50);
  G_sSTEP_DESC    NVARCHAR2(50);
  --G_sVERSION_ID   NVARCHAR2(50);
  G_sUSER_ID      NVARCHAR2(50);
  G_nSQL_CNT      NUMBER(20);
  G_sLOGMSG       VARCHAR2(4000);
---------------------------------
-- Public function declarations -
---------------------------------

----------------------------------
-- Public procedure declarations -
----------------------------------

PROCEDURE SP_SET_ORG (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_IN_ORG
* Purpose : 조직 정보 생성.
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 AIS Created 
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_ORG';

  --* Corporation LOG-----------------------------------------------------------------------------------
  G_sSTEP_SEQ := '1.0';  
  G_sSTEP_DESC := 'Set Corporation';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);    
  INSERT INTO CORPORATION(
         ENGINE_ID
       , CORPORATION_ID
       , CORPORATION_NAME
       , DESCRIPTION)
  VALUES(P_tPLAN_OPTION.ENGINE_ID
       , 'SKI'
       , 'SK Innovation'
       , 'SK Innovation-Battery')
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --*Site-----------------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Set Site(Continent)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO SITE(ENGINE_ID, SITE_ID, SITE_NAME, CORPORATION_ID)
  SELECT P_tPLAN_OPTION.ENGINE_ID       AS ENGINE_ID
        ,CCC.CONF_CD         AS SITE_ID
        ,CCC.CONF_NM         AS SITE_NAME
        ,'SKI'               AS CORPORATION_ID      
    FROM TB_CM_COMM_CONFIG   CCC
        ,TB_CM_CONFIGURATION CFG
   WHERE CCC.CONF_GRP_CD     = 'CONTINENT'
     AND CCC.USE_YN          = 'Y'
     AND CCC.ACTV_YN         = 'Y'
     AND CCC.CONF_ID         = CFG.ID(+)
     AND CFG.MODULE_CD(+)    = 'SMP'
     AND CFG.ACTV_YN  (+)    = 'Y'     
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --*Location-------------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '3.0';   
  G_sSTEP_DESC := 'Set Location(Site)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO LOCATION(ENGINE_ID, LOCATION_ID, LOCATION_NAME, SITE_ID)
  SELECT P_tPLAN_OPTION.ENGINE_ID       
                           AS ENGINE_ID
        ,SSM.SITE_CD       AS LOCATION_ID
        ,SSM.SITE_NM       AS LOCATION_NAME
        ,SSM.CONTINENT_CD  AS SITE_ID
    FROM TB_SMP_SITE_MST   SSM
   WHERE SSM.USE_YN        = 'Y'
     AND SSM.CONTINENT_CD  IS NOT NULL
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);

  --대륙별 location
  G_sSTEP_SEQ := '4.0';   
  G_sSTEP_DESC := 'Set Location(Continent)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);   
  INSERT INTO LOCATION(ENGINE_ID, LOCATION_ID, LOCATION_NAME, SITE_ID)
  SELECT P_tPLAN_OPTION.ENGINE_ID       AS ENGINE_ID
        ,CCC.CONF_CD         AS LOCATION_ID
        ,CCC.CONF_NM         AS LOCATION_NAME
        ,CCC.CONF_CD         AS SITE_ID
    FROM TB_CM_COMM_CONFIG   CCC
        ,TB_CM_CONFIGURATION CFG
   WHERE CCC.CONF_GRP_CD     = 'CONTINENT'
     AND CCC.USE_YN          = 'Y'
     AND CCC.ACTV_YN         = 'Y'
     AND CCC.CONF_ID         = CFG.ID(+)
     AND CFG.MODULE_CD(+)    = 'SMP'
     AND CFG.ACTV_YN  (+)    = 'Y'        
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --*Customer-------------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '5.0';   
  G_sSTEP_DESC := 'Set Customer';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO CUSTOMER (ENGINE_ID, CUSTOMER_ID, CUSTOMER_NAME)
  SELECT DISTINCT 
         P_tPLAN_OPTION.ENGINE_ID      AS ENGINE_ID
        ,PGM_D_CD         AS CUSTOMER_ID
        ,PGM_D_CD         AS CUSTOMER_NAME
    FROM TB_SMP_WK_DEMAND 
   WHERE VERSION_ID       = P_tPLAN_OPTION.VERSION_ID
     AND USE_FLAG         = 'Y'
   UNION
  SELECT DISTINCT
         P_tPLAN_OPTION.ENGINE_ID      AS ENGINE_ID
        ,PGM_D_CD         AS CUSTOMER_ID
        ,PGM_D_CD         AS CUSTOMER_NAME
    FROM TB_SMP_DEMAND_PGM_MST
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  
  ------------------------------------------------------------------------------------------------------
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);  
END;

PROCEDURE SP_SET_CALENDAR (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_IN_CALENDAR
* Purpose : .
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 HGD Created
**************************************************************************/
IS
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_CALENDAR';

  --* Plan Master LOG-----------------------------------------------------------------------------------
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Set Plan Master';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO PLAN_MST(ENGINE_ID , PLAN_ID , START_DATE , END_DATE , DESCRIPTION )
  SELECT P_tPLAN_OPTION.ENGINE_ID 
        ,P_tPLAN_OPTION.VERSION_ID AS PLAN_ID     
        ,P_tPLAN_OPTION.START_DATE AS START_DATE 
        ,P_tPLAN_OPTION.END_DATE   AS END_DATE 
        ,P_tPLAN_OPTION.PLAN_DESC  AS DESCRIPTION 
    FROM DUAL
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------

  --* Plan Detail LOG-----------------------------------------------------------------------------------
  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Set Plan Detail';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  PKG_SMP_LOGGER.stepDEBUG (G_nLOG_SEQ
                          , 'START_DATE=' || TO_CHAR(P_tPLAN_OPTION.START_DATE, 'YYYY-MM-DD HH24:MI:SS')
                          , P_tPLAN_OPTION.VERSION_ID
                          , G_sUSER_ID);
  INSERT INTO PLAN_DTL (ENGINE_ID , PLAN_ID , ZONE_START , TIME_BUCKET , TIME_UOM )
  SELECT P_tPLAN_OPTION.ENGINE_ID 
        ,P_tPLAN_OPTION.VERSION_ID AS PLAN_ID 
        ,P_tPLAN_OPTION.START_DATE AS START_DATE 
        ,1                         AS TIME_BUCKET 
        ,'DAY'                     AS TIME_UOM
    FROM DUAL
  UNION ALL 
  
  SELECT P_tPLAN_OPTION.ENGINE_ID 
        ,P_tPLAN_OPTION.VERSION_ID AS PLAN_ID 
        ,P_tPLAN_OPTION.BUCKET_2_START_DATE 
                                   AS START_DATE 
        ,1                         AS TIME_BUCKET 
--*[V2 AIS]**************************************************************************************        
        --,'MONTH'                   AS TIME_UOM
        ,'PARTIAL_WEEK'            AS TIME_UOM
--*[V2 AIS]**************************************************************************************        
        
    FROM DUAL
  UNION ALL   
  
  SELECT P_tPLAN_OPTION.ENGINE_ID 
        ,P_tPLAN_OPTION.VERSION_ID AS PLAN_ID 
        ,P_tPLAN_OPTION.BUCKET_3_START_DATE
                                   AS START_DATE 
        --,12                        AS TIME_BUCKET 
        ,1 AS TIME_BUCKET
        --,'MONTH'                   AS TIME_UOM
        ,'YEAR' AS TIME_UOM
    FROM DUAL 
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);  
END;

PROCEDURE SP_SET_RES_AVAIL (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION 
, O_sFLAG        OUT VARCHAR2
)

/**************************************************************************
* Name    : SP_SET_RES_AVAIL
* Purpose : .
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 HGD Created
**************************************************************************/
IS
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_RES_AVAIL';

  --* Duaration-------------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Set Duaration';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO DURATION(ENGINE_ID, DURATION_ID, START_DATE, END_DATE, CYCLE_TYPE, DESCRIPTION)
  SELECT P_tPLAN_OPTION.ENGINE_ID 
        ,'DUR_WORK'                    AS DURATION_ID
        ,P_tPLAN_OPTION.START_DATE     AS START_DATE
        ,P_tPLAN_OPTION.START_DATE + 1 AS END_DATE
        ,'D'                           AS CYCLE_TYPE
        ,'작업이 가능한 DURATION'          AS DESCRIPTION
    FROM DUAL
  UNION ALL 
  SELECT P_tPLAN_OPTION.ENGINE_ID 
        ,'DUR_HOLIDAY'                 AS DURATION_ID
        ,P_tPLAN_OPTION.START_DATE     AS START_DATE
        ,P_tPLAN_OPTION.START_DATE + 1 AS END_DATE
        ,'D'                           AS CYCLE_TYPE
        ,'작업이 불가능한 DURATION'         AS DESCRIPTION
    FROM DUAL
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------

  --* Holiday Master------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Set Holiday Master';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO HOLIDAY_MST(ENGINE_ID, HOLIDAY_ID, DESCRIPTION)
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,'HOL_'  || SITE_CD || '-' || LINE_CD  AS HOLIDAY_ID
        ,LINE_CD || ' Working/Holiday'         AS DESCRIPTION
    FROM TB_SMP_LINE_MST   SLM    
   WHERE USE_YN            = 'Y'
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_WK_BOR    SWB
          WHERE SWB.VERSION_ID   = P_tPLAN_OPTION.VERSION_ID
            AND SWB.SITE_CD      = SLM.SITE_CD
            AND SWB.LINE_CD      = SLM.LINE_CD)            
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------

  --* Holiday Detail------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '3.0';   
  G_sSTEP_DESC := 'Set Holiday Detail';   
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO HOLIDAY_DTL(ENGINE_ID, HOLIDAY_ID, DURATION_ID, APPLY_START_DATE, APPLY_END_DATE, HOLIDAY_TYPE, PRIORITY, DESCRIPTION)
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,'HOL_' || SITE_CD || '-' || LINE_CD             AS HOLIDAY_ID
        ,'DUR_WORK'                                      AS DURATION_ID
        -- 확정구간 오더 계획을 위하여 계획 시작일로 변경,  라인 가동 시작일은  ORDER별 PST로 제어처리함.
        --,TO_DATE(SLM.VALID_START_DATE , 'YYYYMMDD')      AS APPLY_START_DATE
        ,P_tPLAN_OPTION.START_DATE                       AS APPLY_START_DATE 
        ,TO_DATE(SLM.VALID_FINISH_DATE, 'YYYYMMDD')      AS APPLY_END_DATE 
        ,'A'                                             AS HOLIDAY_TYPE
        ,2                                               AS PRIORITY
        ,LINE_CD || ' Working'                           AS DESCRIPTION
    FROM TB_SMP_LINE_MST   SLM
   WHERE USE_YN            = 'Y'
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_WK_BOR    SWB
          WHERE SWB.VERSION_ID   = P_tPLAN_OPTION.VERSION_ID
            AND SWB.SITE_CD      = SLM.SITE_CD
            AND SWB.LINE_CD      = SLM.LINE_CD)     
  UNION ALL
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,'HOL_' || SITE_CD || '-' || LINE_CD             AS HOLIDAY_ID
        ,'DUR_HOLIDAY'                                   AS DURATION_ID
        ,P_tPLAN_OPTION.START_DATE                       AS APPLY_START_DATE
        ,P_tPLAN_OPTION.END_DATE                         AS APPLY_END_DATE 
        ,'D'                                             AS HOLIDAY_TYPE        
        ,3                                               AS PRIORITY
        ,LINE_CD || ' Holiday'                           AS DESCRIPTION
    FROM TB_SMP_LINE_MST   SLM
   WHERE USE_YN            = 'Y'  
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_WK_BOR    SWB
          WHERE SWB.VERSION_ID   = P_tPLAN_OPTION.VERSION_ID
            AND SWB.SITE_CD      = SLM.SITE_CD
            AND SWB.LINE_CD      = SLM.LINE_CD)     
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);  
END;

PROCEDURE SP_SET_ITEM (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_IN_CALENDAR
* Purpose : .
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 HGD Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S';   
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_ITEM';
  
  --* Item LOG-----------------------------------------------------------------------------------
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Set Item';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO ITEM(ENGINE_ID, ITEM_ID, ITEM_NAME, ITEM_CLASS)
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,MST.ITEM_CD
        ,MST.ITEM_CD
        ,CASE WHEN SIM.ITEM_TYPE_CD = 'FERT'                       THEN 'P' 
              WHEN CCC.ATTR_01      = P_tPLAN_OPTION.ASSY_ROUTE_CD THEN 'P' -- 조립공정 품목이 반제품이지만 PLANNED ORDER에 올리기 위해 'P'으로 정의해야 함.
              WHEN SIM.ITEM_TYPE_CD = 'HALB'                       THEN 'I'
              ELSE                                                      'M'
         END ITEM_CLASS
    FROM (SELECT DISTINCT P_ITEM_CD AS ITEM_CD
            FROM TB_SMP_WK_BOM
           WHERE VERSION_ID = P_tPLAN_OPTION.VERSION_ID
          UNION
          SELECT DISTINCT C_ITEM_CD AS ITEM_CD
            FROM TB_SMP_WK_BOM
           WHERE VERSION_ID = P_tPLAN_OPTION.VERSION_ID
         ) MST
        ,TB_SMP_ITEM_MST       SIM
        ,TB_SMP_ITEM_BASE_INFO IBI 
        ,TB_CM_COMM_CONFIG     CCC
        ,TB_CM_CONFIGURATION   CFG         
   WHERE MST.ITEM_CD           = SIM.ITEM_CD (+)
     AND SIM.PN_CD             = IBI.PN_CD   (+)  
     AND IBI.ATTR_01           = CCC.ATTR_02 (+)
     AND CCC.CONF_GRP_CD(+)    = 'ITEM_ROUTE_MAP'
     AND CCC.USE_YN     (+)    = 'Y'
     AND CCC.CONF_ID           = CFG.ID(+)
     AND CFG.MODULE_CD(+)      = 'SMP'
     AND CFG.ACTV_YN  (+)      = 'Y'        
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);

  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Set Item Class';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  UPDATE ITEM  I
     SET I.ITEM_CLASS = 'P'
   WHERE I.ENGINE_ID  = P_tPLAN_OPTION.ENGINE_ID
     AND EXISTS (
         SELECT 1 
           FROM TB_SMP_DEMAND_PGM_MST P 
          WHERE P.ITEM_CD             = I.ITEM_ID
          )
  ;     
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);

  G_sSTEP_SEQ := '3.0';   
  G_sSTEP_DESC := 'Set Assy Item Size, Thick.';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  UPDATE ITEM ITM
     SET (ITM.ITEM_SIZE, THICKNESS) 
         =
         (SELECT S.WIDTH_VAL || '*'  || S.LENGTH_VAL, S.THICKNESS_VAL
            FROM TB_SMP_CELL_MST S
           WHERE S.ITEM_CD       = ITM.ITEM_ID)         
   WHERE ITM.ENGINE_ID = P_tPLAN_OPTION.ENGINE_ID
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_CELL_MST SCM
          WHERE SCM.ITEM_CD     = ITM.ITEM_ID
            AND SCM.ITEM_CD     IS NOT NULL
         )
     
  ;     
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --* Inventory LOG-------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '4.0';   
  G_sSTEP_DESC := 'Set Inventory';
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO INVENTORY (ENGINE_ID, INVENTORY_ID , INVENTORY_NAME, ITEM_ID, LOCATION_ID, ITEM_TYPE)
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,MST.INVENTORY_ID 
        ,MST.INVENTORY_ID AS INVENTORY_NAME
        ,MST.ITEM_ID
        ,MST.LOCATION_ID
        ,MST.ITEM_TYPE
    FROM (SELECT DISTINCT 
                  P_INVENTORY_ID AS INVENTORY_ID 
                --,'F'             AS ITEM_TYPE -- F : 무한
                ,NULL            AS ITEM_TYPE
                ,P_ITEM_CD       AS ITEM_ID   
                ,DECODE(P_ROUTE_CD, P_tPLAN_OPTION.BOD_ROUTE_CD, T_CONTINENT_CD, SITE_CD)         
                                 AS LOCATION_ID 
            FROM TB_SMP_WK_BOM
           WHERE VERSION_ID      = P_tPLAN_OPTION.VERSION_ID 
          UNION
          SELECT DISTINCT    
                 C_INVENTORY_ID  AS INVENTORY_ID 
                --,'F'             AS ITEM_TYPE -- F : 무한
                ,CASE WHEN C_ITEM_CD LIKE 'DUMMY%' THEN 'I' END 
                                 AS ITEM_TYPE
                ,C_ITEM_CD       AS ITEM_ID   
                ,SITE_CD         AS LOCATION_ID 
            FROM TB_SMP_WK_BOM
           WHERE VERSION_ID      = P_tPLAN_OPTION.VERSION_ID
         )                      MST
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --* Inventory Item type-------------------------------------------------------------------------------
  IF P_tPLAN_OPTION.CONSTRAINT_MAT_YN = 'Y' THEN 
    G_sSTEP_SEQ := '5.0';   
    G_sSTEP_DESC := 'Set Inventory-Item type';    
    PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
    UPDATE INVENTORY I
       SET ITEM_TYPE        = 'S'
          ,LIMIT_FENCE_TIME = (SELECT ADD_MONTHS(P_tPLAN_OPTION.START_DATE, SIM.CONS_MONTH) - P_tPLAN_OPTION.START_DATE
                                 FROM TB_SMP_ITEM_MST  SIM
                                WHERE SIM.ITEM_CD      = I.ITEM_ID)
          ,TIME_UOM         = 'DAY' 
     WHERE EXISTS (
           SELECT 1
             FROM TB_SMP_VENDOR_CAPA SVC
            WHERE SVC.ITEM_CD        = I.ITEM_ID)     
    ;
    PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  END IF;
  ------------------------------------------------------------------------------------------------------
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);  
END;

PROCEDURE SP_SET_BOM (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_IN_CALENDAR
* Purpose : .
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 HGD Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_BOM';

  --* Route LOG-----------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Set Route';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO ROUTE (ENGINE_ID, ROUTE_ID, ROUTE_NAME, ROUTE_GRP_ID, DISCRETE, ALTERNATE_RESOURCE_POLICY,  DESCRIPTION, SITE_CD )
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,ROUTE_ID 
        ,ROUTE_ID                                   AS ROUTE_NAME
        ,ROUTE_GRP                                  AS ROUTE_GRP_ID
        ,DECODE(ROUTE_GRP, 'BEL', 'N', 'Y')         AS DISCRETE
        ,CASE WHEN RES_CNT > 1 THEN 'PRIORITY' END  AS ALTERNATE_RESOURCE_POLICY -- 1건인 경우 엔진 DATA LOAD시 VALIDATION 경고로 처리됨.
        ,SITE_CD                                    AS DESCRIPTION
        ,SITE_CD                                    AS SITE_CD
    FROM (     
          SELECT BOM.ROUTE_ID 
                ,BOM.P_ROUTE_CD
                ,BOM.SITE_CD
                ,CASE WHEN IMP.ITEM_ELETRODE_GRP IS NOT NULL THEN 'BEL' ELSE BOM.P_ROUTE_CD END AS ROUTE_GRP
                ,COUNT(DISTINCT BOR.LINE_CD) RES_CNT
            FROM TB_SMP_WK_BOM   BOM
                ,TB_SMP_WK_BOR   BOR
                ,(SELECT SIM.ITEM_CD
                        ,CCC.CONF_CD           AS ITEM_ELETRODE_GRP
                    FROM TB_SMP_ITEM_MST       SIM 
                        ,TB_SMP_ITEM_BASE_INFO IBI
                        ,TB_CM_COMM_CONFIG     CCC
                        ,TB_CM_CONFIGURATION   CFG    
                   WHERE SIM.PN_CD             = IBI.PN_CD   
                     AND IBI.ATTR_01           = CCC.CONF_CD
                     AND CCC.CONF_GRP_CD       = 'ITEM_ELETRODE_GRP'
                     AND CCC.USE_YN            = 'Y'
                     AND CCC.CONF_ID           = CFG.ID
                     AND CFG.MODULE_CD         = 'SMP'
                     AND CFG.ACTV_YN           = 'Y'    ) IMP  
           WHERE BOM.VERSION_ID  = P_tPLAN_OPTION.VERSION_ID  
             AND BOM.VERSION_ID  = BOR.VERSION_ID(+)
             AND BOM.ROUTE_ID    = BOR.ROUTE_ID  (+)
             AND BOM.P_ITEM_CD   = BOR.ITEM_CD   (+)
             AND BOM.P_ITEM_CD   = IMP.ITEM_CD   (+)
           GROUP BY 
                 BOM.ROUTE_ID
                ,BOM.P_ROUTE_CD
                ,BOM.SITE_CD
                ,CASE WHEN IMP.ITEM_ELETRODE_GRP IS NOT NULL THEN 'BEL' ELSE BOM.P_ROUTE_CD END                
         ) SWB
/*         
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,ROUTE_ID 
        ,ROUTE_ID                                   AS ROUTE_NAME
        ,DECODE(CCC.ATTR_01, '전극', 'N', 'Y' )      AS DISCRETE 
        ,CASE WHEN RES_CNT > 1 THEN 'PRIORITY' END  AS ALTERNATE_RESOURCE_POLICY -- 1건인 경우 엔진 DATA LOAD시 VALIDATION 경고로 처리됨.
        ,SITE_CD                                    AS DESCRIPTION
    FROM (SELECT BOM.ROUTE_ID
                ,BOM.P_ROUTE_CD
                ,BOM.SITE_CD
                ,COUNT(DISTINCT BOR.LINE_CD) RES_CNT
            FROM TB_SMP_WK_BOM   BOM
                ,TB_SMP_WK_BOR   BOR
           WHERE BOM.VERSION_ID  = P_tPLAN_OPTION.VERSION_ID  
             AND BOM.VERSION_ID  = BOR.VERSION_ID(+)
             AND BOM.ROUTE_ID    = BOR.ROUTE_ID  (+)
             AND BOM.P_ITEM_CD   = BOR.ITEM_CD   (+)
           GROUP BY 
                 BOM.ROUTE_ID
                ,BOM.P_ROUTE_CD
                ,BOM.SITE_CD
         ) SWB
        ,TB_CM_COMM_CONFIG   CCC
        ,TB_CM_CONFIGURATION CFG
  WHERE SWB.P_ROUTE_CD       = CONF_CD(+) 
    AND CCC.CONF_GRP_CD(+)   = 'ROUTE'   
    AND CCC.USE_YN     (+)   = 'Y'
    AND CCC.ACTV_YN    (+)   = 'Y'
    AND CCC.CONF_ID          = CFG.ID(+)
    AND CFG.MODULE_CD  (+)   = 'SMP'
    AND CFG.ACTV_YN    (+)   = 'Y'       
*/    
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --* ROUTE GROUP -- -----------------------------------------------------------------------------------
  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Set Route Group';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO ROUTE_GRP(ENGINE_ID, ROUTE_GRP_ID, ROUTE_GRP_NAME, DESCRIPTION)
  SELECT DISTINCT
         ENGINE_ID
        ,ROUTE_GRP_ID
        ,ROUTE_GRP_ID
        ,ROUTE_GRP_ID
    FROM ROUTE
   WHERE ENGINE_ID    = P_tPLAN_OPTION.ENGINE_ID
     AND ROUTE_GRP_ID IS NOT NULL
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------  

  --* BOM_ROUTING LOG-----------------------------------------------------------------------------------
  G_sSTEP_SEQ := '3.0';   
  G_sSTEP_DESC := 'SEt BOM_Routing';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO BOM_ROUTING( ENGINE_ID, ROUTE_ID, INVENTORY_ID, BOM_TYPE, BOM_RATE )
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,ROUTE_ID 
        ,INVENTORY_ID 
        ,BOM_TYPE 
        ,BOM_RATE
    FROM (SELECT DISTINCT 
                 ROUTE_ID
                ,P_INVENTORY_ID  AS INVENTORY_ID     
                ,'P'             AS BOM_TYPE
                ,P_UNIT_QTY      AS BOM_RATE
            FROM TB_SMP_WK_BOM
           WHERE VERSION_ID = P_tPLAN_OPTION.VERSION_ID  
             AND USE_FLAG   = 'Y'
          UNION 
          SELECT ROUTE_ID
                ,C_INVENTORY_ID  AS INVENTORY_ID 
                ,'C'             AS BOM_TYPE
                ,SUM(C_UNIT_QTY) AS BOM_RATE
            FROM TB_SMP_WK_BOM
           WHERE VERSION_ID = P_tPLAN_OPTION.VERSION_ID   
             AND USE_FLAG   = 'Y'
           GROUP BY 
                 ROUTE_ID
                ,C_INVENTORY_ID
         )    
  ;    
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);  
END;

PROCEDURE SP_SET_BOR (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_IN_CALENDAR
* Purpose : .
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History : 
* 2020-02-17 HGD Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_BOR';

  --* Resource LOG--------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Set Resources';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO RESOURCES(ENGINE_ID, RESOURCE_ID, RESOURCE_NAME, LOCATION_ID, RESOURCE_TYPE, CAPACITY, HOLIDAY_ID, JC_DYNAMIC_VALUE_ID, DEFAULT_JC_DYNAMIC_RATE_ID)
  SELECT DISTINCT 
         P_tPLAN_OPTION.ENGINE_ID
        ,LINE_CD                 AS RESOURCE_ID 
        ,LINE_CD                 AS RESOURCE_NAME 
        ,SITE_CD                 AS LOCATION_ID 
        --,'F'                     AS RESOURCE_TYPE
        ,CASE WHEN ROUTE_CD = P_tPLAN_OPTION.ELEC_ROUTE_CD THEN 'F'
              ELSE                                              'F'
         END                     AS RESOURCE_TYPE
        ,CASE WHEN BUILDING_NO = 'DUMMY' THEN 100000000000000
              ELSE                            31 * 24 * 60            
         END                     AS CAPACITY
        ,CASE WHEN ROUTE_CD IN (P_tPLAN_OPTION.ASSY_ROUTE_CD, P_tPLAN_OPTION.ELEC_ROUTE_CD) 
                   AND NVL(BUILDING_NO, '_') <> 'DUMMY' THEN 
                   'HOL_'  || SITE_CD || '-' || LINE_CD END
                                 AS HOLIDAY_ID
        ,CASE WHEN ROUTE_CD = P_tPLAN_OPTION.ASSY_ROUTE_CD THEN LINE_CD                   END JC_DYNAMIC_VALUE_ID
        ,CASE WHEN ROUTE_CD = P_tPLAN_OPTION.ASSY_ROUTE_CD THEN LINE_CD || '-' || TO_CHAR(P_tPLAN_OPTION.START_DATE, 'YYYY') || '-F-1-366' END DEFAULT_JC_DYNAMIC_RATE_ID
    FROM TB_SMP_WK_BOR           
   WHERE VERSION_ID              = P_tPLAN_OPTION.VERSION_ID
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);

  -- dummy
  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Set Resource(Dummy)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID);   
  INSERT INTO RESOURCES(ENGINE_ID, RESOURCE_ID, RESOURCE_NAME, LOCATION_ID, RESOURCE_TYPE, CAPACITY)
  SELECT P_tPLAN_OPTION.ENGINE_ID             AS ENGINE_ID
        ,'RES_DUMMY@' || SITE_CD AS RESOURCE_ID 
        ,'RES_DUMMY@' || SITE_CD AS RESOURCE_NAME     
        ,SITE_CD                 AS LOCATION_ID
        ,'F'                     AS RESOURCE_TYPE
        ,9999999999              AS CAPACITY
    FROM TB_SMP_SITE_MST X 
   WHERE X.USE_YN       = 'Y'
     AND X.CONTINENT_CD  IS NOT NULL
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------

  --* BOR LOG-------------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '3.0';   
  G_sSTEP_DESC := 'Set BOR';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO BOR(ENGINE_ID, ROUTE_ID, RESOURCE_ID, EFFICIENCY, PROCESS_CAPACITY, MOVE_TIME, TIME_UOM, ALTERNATE_VALUE)
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,ROUTE_ID 
        ,LINE_CD            AS RESOURCE_ID 
        ,EFFICIENCY         AS EFFICIENCY 
        ,PROCESS_CAPACITY   AS PROCESS_CAPACITY 
        ,CASE WHEN LEAD_TIME IS NULL THEN 0 ELSE (LEAD_TIME) * 33 END   
                            AS MOVE_TIME
        ,'DAY'              AS TIME_UOM 
        ,RANK() OVER ( PARTITION BY ROUTE_ID 
                           ORDER BY DECODE(BUILDING_NO, 'DUMMY', 9, 1) --DUMMY 우선순위 마지막
                                  , PROCESS_CAPACITY
                                  , LINE_CD ) 
                            AS ALTERNATE_VALUE
    FROM TB_SMP_WK_BOR
   WHERE VERSION_ID         = P_tPLAN_OPTION.VERSION_ID
  ; 
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);

  G_sSTEP_SEQ := '4.0';   
  G_sSTEP_DESC := 'Set BOR(Dummy)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO BOR(ENGINE_ID, ROUTE_ID, RESOURCE_ID, EFFICIENCY, PROCESS_CAPACITY)
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,ROUTE_ID 
        ,'RES_DUMMY@' || DESCRIPTION AS RESOURCE_ID
        ,1         AS EFFICIENCY 
        ,0         AS PROCESS_CAPACITY 
    FROM ROUTE RT
   WHERE RT.ENGINE_ID = P_tPLAN_OPTION.ENGINE_ID
     AND NOT EXISTS (
         SELECT 1
           FROM BOR BOR
          WHERE BOR.ENGINE_ID = RT.ENGINE_ID
            AND BOR.ROUTE_ID  = RT.ROUTE_ID)
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------
  
  --* SO BOR LOG----------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '5.0';   
  G_sSTEP_DESC := 'Set SO BOR';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO SO_BOR(ENGINE_ID, SALESORDER_ID, ROUTE_ID, RESOURCE_ID, MOVE_TIME, TIME_UOM )
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,SWD.DEMAND_ID AS SALESORDER_ID
        ,SWB.ROUTE_ID  AS ROUTE_ID
        ,SWB.LINE_CD   AS RESOURCE_ID
        ,SWD.DUE_DATE - ADD_MONTHS(SWD.DUE_DATE, -1 * SWB.LEAD_TIME) AS MOVE_TIME
        ,'DAY'         AS TIME_UOM
    FROM TB_SMP_WK_DEMAND      SWD
        ,TB_SMP_WK_BOR         SWB
   WHERE SWD.VERSION_ID        = P_tPLAN_OPTION.VERSION_ID
     AND SWD.VERSION_ID        = SWB.VERSION_ID
     AND SWD.ITEM_CD           = SWB.ITEM_CD
     AND SWB.ROUTE_CD          = 'BOD'
     AND SWD.DUE_DATE          < ADD_MONTHS(P_tPLAN_OPTION.BUCKET_2_START_DATE, 2) --월 버켓 2월까지만.
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_WK_BOM      BOM
          WHERE BOM.VERSION_ID     = SWB.VERSION_ID
            AND BOM.P_ITEM_CD      = SWB.ITEM_CD
            AND BOM.ROUTE_ID       = SWB.ROUTE_ID
            AND BOM.T_CONTINENT_CD = SWD.T_CONTINENT_CD
         )     
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------          
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG);  
END;

END PKG_SMP_I_STATIC;
/

