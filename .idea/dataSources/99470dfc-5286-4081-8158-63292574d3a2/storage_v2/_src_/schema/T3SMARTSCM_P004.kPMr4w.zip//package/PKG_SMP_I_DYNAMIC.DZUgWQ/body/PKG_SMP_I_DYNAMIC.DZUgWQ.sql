create PACKAGE BODY                 PKG_SMP_I_DYNAMIC
IS
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved.
**************************************************************************
* Name    : PKG_SMP_I_DYNAMIC
* Purpose : MP Static 정보 생성.
* Notes   : 
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
PRAGMA SERIALLY_REUSABLE;
-----------------------------
-- Public type declarations -
-----------------------------

---------------------------------
-- Public constant declarations -
---------------------------------

---------------------------------
-- Public variable declarations -
---------------------------------
  G_nLOG_SEQ      NUMBER;
  G_sPKG_ID       NVARCHAR2(1000) := 'PKG_SMP_I_DYNAMIC';
  G_sPROGRAMN_ID  NVARCHAR2(50);
  G_sSTEP_SEQ     NVARCHAR2(50);
  G_sSTEP_DESC    NVARCHAR2(50);
  --G_sVERSION_ID   NVARCHAR2(50);
  G_sUSER_ID      NVARCHAR2(50);
  G_nSQL_CNT      NUMBER(20);
  G_sLOGMSG       VARCHAR2(4000);

---------------------------------
-- Public function declarations -
---------------------------------

----------------------------------
-- Public procedure declarations -
----------------------------------
PROCEDURE SP_SET_STOCK (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_STOCK
* Purpose : .
* Notes   : 
*           1. Site Onhand
*           2. Intransit (to Site, from Vendor)
*           3. VMI Onhand
*           4. Intransit (to VMI, from Site)
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S'; 
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_STOCK';
 
  --* Stock LOG------------------------------------------------------------------------------------------  
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Set Stock (Site Onhand)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO STOCK(ENGINE_ID, STOCK_ID, INVENTORY_ID, RECEIPT_DATE, USABLE_DATE, QTY, USABLE, SITE_CD)
  SELECT P_tPLAN_OPTION.ENGINE_ID            AS ENGINE_ID
        ,'ST_SITE_' || LPAD(ROWNUM, 10, '0') AS STOCK_ID
        ,ITEM_CD || '@' || SITE_CD           AS INVENTORY_ID
        ,TO_DATE(CUTOFF_DATE, 'YYYYMMDD')    AS RECEIPT_DATE
        ,TO_DATE(CUTOFF_DATE, 'YYYYMMDD')    AS USABLE_DATE
        ,STOCK_QTY                           AS QTY
        ,'Y'                                 AS USABLE
        ,SITE_CD                             AS SITE_CD
    FROM ( 
          SELECT BOH.CUTOFF_DATE    
                ,SSM.SITE_CD      
                ,BOH.ITEM_CD
                ,SUM(BOH.STOCK_QTY) AS STOCK_QTY
            FROM TB_SMP_BOH     BOH
                ,TB_SMP_SL_MST  SSM
           WHERE BOH.CUTOFF_DATE = (SELECT MAX(B.CUTOFF_DATE)
                                      FROM TB_SMP_BOH B
                                     WHERE B.CUTOFF_DATE <= P_tPLAN_OPTION.START_DATE)    
             AND BOH.PLANT_CD    = SSM.PLANT_CD
             AND BOH.SL_CD       = SSM.SL_CD
             AND SSM.VMI_YN      = 'N'
             AND EXISTS ( 
                 SELECT 1
                   FROM TB_SMP_WK_BOM  SWB
                  WHERE SWB.VERSION_ID = P_tPLAN_OPTION.VERSION_ID 
                    AND ( 
                            (SWB.SITE_CD = SSM.SITE_CD AND SWB.P_ITEM_CD = BOH.ITEM_CD)
                         OR (SWB.SITE_CD = SSM.SITE_CD AND SWB.C_ITEM_CD = BOH.ITEM_CD)
                        )
                 )
              --* 전극 반제품은 제외함. (전극 반제품 재고는 확정기간내 CELL에 모두 사용되는 것으로 확정 계획 이후 계획에 반영하면 안됨.)
              AND NOT EXISTS ( --전극 품목
                    SELECT SIM.ITEM_CD
                      FROM TB_SMP_ITEM_MST       SIM 
                          ,TB_SMP_ITEM_BASE_INFO IBI
                          ,TB_CM_COMM_CONFIG     CCC
                          ,TB_CM_CONFIGURATION   CFG    
                     WHERE SIM.PN_CD             = IBI.PN_CD   
                       AND IBI.ATTR_01           = CCC.CONF_CD
                       AND CCC.CONF_GRP_CD       = 'ITEM_ELETRODE_GRP'
                       AND CCC.USE_YN            = 'Y'
                       AND CCC.CONF_ID           = CFG.ID
                       AND CFG.MODULE_CD         = 'SMP'
                       AND CFG.ACTV_YN           = 'Y'   
                       AND SIM.ITEM_CD           = BOH.ITEM_CD
                   )                         
           GROUP BY 
                 BOH.CUTOFF_DATE    
                ,SSM.SITE_CD
                ,BOH.ITEM_CD
         ) M   
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT); 
  ------------------------------------------------------------------------------------------------------
  
  --* Instransit(from Vendor)---------------------------------------------------------------------------  
  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Set Stock(Instransit, from Vendor)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO STOCK(ENGINE_ID, STOCK_ID, INVENTORY_ID, RECEIPT_DATE, USABLE_DATE, QTY, USABLE, SITE_CD)
  SELECT P_tPLAN_OPTION.ENGINE_ID               AS ENGINE_ID
        ,'ST_INTR_' || LPAD(ROWNUM, 10, '0')    AS STOCK_ID
        ,ITEM_CD || '@' || SITE_CD              AS INVENTORY_ID
        ,TO_DATE(CUTOFF_DATE, 'YYYYMMDD')       AS RECEIPT_DATE
        ,TO_DATE(ETA_MONTH ||'01', 'YYYYMMDD')  AS USABLE_DATE
        ,STOCK_QTY                              AS QTY
        ,'Y'                                    AS USABLE
        ,SITE_CD                                AS SITE_CD
    FROM (
          SELECT CUTOFF_DATE
                ,SITE_CD
                ,ITEM_CD
                ,ETA_MONTH
                ,SUM(STOCK_QTY) AS STOCK_QTY
            FROM TB_SMP_VENDOR_INTRANSIT S
           WHERE S.CUTOFF_DATE   = (SELECT MAX(B.CUTOFF_DATE)
                                      FROM TB_SMP_VENDOR_INTRANSIT B
                                     WHERE B.CUTOFF_DATE <= P_tPLAN_OPTION.START_DATE) 
             AND EXISTS ( 
                 SELECT 1
                   FROM TB_SMP_WK_BOM SWB
                  WHERE SWB.VERSION_ID = P_tPLAN_OPTION.VERSION_ID
                    AND (
                            (SWB.SITE_CD = S.SITE_CD AND SWB.P_ITEM_CD = S.ITEM_CD)
                         OR (SWB.SITE_CD = S.SITE_CD AND SWB.C_ITEM_CD = S.ITEM_CD) 
                        )
                 )                                     
           GROUP BY 
                 CUTOFF_DATE
                ,SITE_CD
                ,ITEM_CD
                ,ETA_MONTH
         )
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT); 
  ------------------------------------------------------------------------------------------------------

  --* Stock VMI-----------------------------------------------------------------------------------------  
  G_sSTEP_SEQ := '3.0';   
  G_sSTEP_DESC := 'Set Stock (VMI Onhand)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO STOCK(ENGINE_ID, STOCK_ID, INVENTORY_ID, CUSTOMER_ID, RECEIPT_DATE, USABLE_DATE, QTY, USABLE, SITE_CD)
  SELECT P_tPLAN_OPTION.ENGINE_ID            AS ENGINE_ID
        ,'ST_VMI_' || LPAD(ROWNUM, 10, '0')  AS STOCK_ID
        ,ITEM_CD || '@' || OEM_TO_SITE_CD    AS INVENTORY_ID
        ,PGM_D_CD                            AS CUSTOMER_ID
        ,TO_DATE(CUTOFF_DATE, 'YYYYMMDD')    AS RECEIPT_DATE
        ,TO_DATE(CUTOFF_DATE, 'YYYYMMDD')    AS USABLE_DATE
        ,STOCK_QTY                           AS QTY
        ,'Y'                                 AS USABLE
        ,SITE_CD                             AS SITE_CD
    FROM ( 
          SELECT DPM.OEM_TO_SITE_CD
                ,SVB.CUTOFF_DATE
                ,SVB.ITEM_CD
                ,SVB.PGM_D_CD
                ,SVB.STOCK_QTY
                ,SVB.SITE_CD
            FROM TB_SMP_VMI_BOH        SVB
                ,TB_SMP_DEMAND_PGM_MST DPM
           WHERE SVB.PGM_D_CD          = DPM.PGM_D_CD  
             AND SVB.CUTOFF_DATE       = (SELECT MAX(B.CUTOFF_DATE)
                                            FROM TB_SMP_VMI_BOH B
                                           WHERE B.CUTOFF_DATE <= P_tPLAN_OPTION.START_DATE) 
             AND EXISTS ( 
                 SELECT 1
                   FROM TB_SMP_WK_BOM SWB
                  WHERE SWB.VERSION_ID     = P_tPLAN_OPTION.VERSION_ID
                    AND SWB.T_CONTINENT_CD = DPM.OEM_TO_SITE_CD
                    AND SWB.P_ITEM_CD      = SVB.ITEM_CD 
                 )                                            
         )
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT); 
  ------------------------------------------------------------------------------------------------------

  --* Instransit(from Site)---------------------------------------------------------------------------  
  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Set VMI Stock(Instransit, from Site)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO STOCK(ENGINE_ID, STOCK_ID, INVENTORY_ID, CUSTOMER_ID, RECEIPT_DATE, USABLE_DATE, QTY, USABLE, SITE_CD)
  SELECT P_tPLAN_OPTION.ENGINE_ID                AS ENGINE_ID
        ,'ST_VMI_MOVE_' || LPAD(ROWNUM, 10, '0') AS STOCK_ID
        ,ITEM_CD || '@' || OEM_TO_SITE_CD        AS INVENTORY_ID
        ,PGM_D_CD                                AS CUSTOMER_ID
        ,TO_DATE(CUTOFF_DATE, 'YYYYMMDD')        AS RECEIPT_DATE
        ,TO_DATE(ETA_MONTH ||'01', 'YYYYMMDD')   AS USABLE_DATE
        ,STOCK_QTY                               AS QTY
        ,'Y'                                     AS USABLE
        ,SITE_CD                                 AS SITE_CD
    FROM ( 
          SELECT DPM.OEM_TO_SITE_CD
                ,SVB.CUTOFF_DATE
                ,SVB.ITEM_CD
                ,SVB.PGM_D_CD
                ,SVB.STOCK_QTY
                ,SVB.ETA_MONTH
                ,SVB.SITE_CD 
            FROM TB_SMP_VMI_INTRANSIT  SVB
                ,TB_SMP_DEMAND_PGM_MST DPM
           WHERE SVB.PGM_D_CD          = DPM.PGM_D_CD  
             AND SVB.CUTOFF_DATE       = (SELECT MAX(B.CUTOFF_DATE) 
                                            FROM TB_SMP_VMI_INTRANSIT B
                                           --WHERE B.CUTOFF_DATE       <= P_tPLAN_OPTION.START_DATE
                                           ) 
             AND EXISTS ( 
                 SELECT 1
                   FROM TB_SMP_WK_BOM SWB
                  WHERE SWB.VERSION_ID     = P_tPLAN_OPTION.VERSION_ID
                    AND SWB.T_CONTINENT_CD = DPM.OEM_TO_SITE_CD
                    AND SWB.P_ITEM_CD      = SVB.ITEM_CD  
                 )
         )
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT); 
  ------------------------------------------------------------------------------------------------------
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

PROCEDURE SP_SET_SO (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION --TB_SMP_WK_PLAN_OPTION%ROWTYPE
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_SO
* Purpose : .
* Notes   : <프로시져에 대한 추가 기재 사항을 기록한다.>
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :
* 2020-02-17 AIS Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S'; 
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_SO';

  --* Sales Order LOG-----------------------------------------------------------------------------------
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Set Sales Order';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  PKG_SMP_LOGGER.stepDEBUG (G_nLOG_SEQ, P_tPLAN_OPTION.ENGINE_ID, TO_CHAR(P_tPLAN_OPTION.START_DATE, 'YYYY-MM-DD HH24:MI:SS'));
  INSERT INTO SALESORDER(
         ENGINE_ID
        ,SALESORDER_ID 
        ,CUSTOMER_ID
        ,INVENTORY_ID
        ,QTY
        ,REGISTER_DATE
        ,DUE_DATE
        ,PST
        ,DELIVERY_POLICY
        ,PRIORITY
        ,USABLE 
        ,PARTIAL_PLAN
        ,CONTINU_PROD_MODE
        ,PLAN_TYPE
        ,ORDER_GRP_ID 
        ,COLOR 
        ,SKI_JC_SHORT_TYPE )
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,DEMAND_ID                       AS SALESORDER_ID
        ,PGM_D_CD                        AS CUSTOMER_ID
        ,INVENTORY_ID
        ,QTY                             AS QTY
        ,P_tPLAN_OPTION.START_DATE       AS REGISTER_DATE
        ,DUE_DATE                        AS DUE_DATE
        ,PST                             AS PST      
        ,'SHORT'                         AS DELIVERY_POLICY
        ,PRIORITY
        ,'Y'                             AS USABLE
        ,'Y'                             AS PARTIAL_PLAN
        ,'N'                             AS CONTINU_PROD_MODE
        --,DECODE(P_tPLAN_OPTION.CONSTRAINT_MAT_YN, 'Y', 'FCFM', NULL) AS PLAN_TYPE
        ,NULL                            AS PLAN_TYPE
        ,TO_CHAR(DUE_DATE , 'YYYYMM') || CASE WHEN DEMAND_ID LIKE '%(1)' THEN 'A' ELSE 'B' END AS ORDER_GRP_ID
        ,COLOR
        ,CASE WHEN DEMAND_ID LIKE '%(2)' THEN 'A' END SKI_JC_SHORT_TYPE
    FROM TB_SMP_WK_DEMAND 
   WHERE VERSION_ID = P_tPLAN_OPTION.VERSION_ID
     AND USE_FLAG   = 'Y'
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT); 
  ------------------------------------------------------------------------------------------------------
  --[] 아래 본사 임시 코딩
  INSERT INTO ORDER_GRP (ENGINE_ID , ORDER_GRP_ID , ORDER_GRP_NAME )
  SELECT DISTINCT 
         P_tPLAN_OPTION.ENGINE_ID
        ,TO_CHAR(DUE_DATE , 'YYYYMM') || CASE WHEN DEMAND_ID LIKE '%(1)' THEN 'A' ELSE 'B' END AS ORDER_GRP_ID
        ,TO_CHAR(DUE_DATE , 'YYYYMM') || CASE WHEN DEMAND_ID LIKE '%(1)' THEN 'A' ELSE 'B' END AS ORDER_GRP_ID
    FROM TB_SMP_WK_DEMAND 
   WHERE VERSION_ID = P_tPLAN_OPTION.VERSION_ID
     AND USE_FLAG   = 'Y'
  ;

 
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

PROCEDURE SP_SET_FIXED_ZONE (
  P_tPLAN_OPTION IN  TP_SMP_PLAN_OPTION --TB_SMP_WK_PLAN_OPTION%ROWTYPE
, O_sFLAG        OUT VARCHAR2
)
/**************************************************************************
* Name    : SP_SET_FIXED_ZONE
* Purpose : .
* Notes   : 
*           [Special Logic]
*           [Parameters]
**************************************************************************
* History :  
* 2020-02-17 AIS Created
**************************************************************************/
IS  
BEGIN
  O_sFLAG := 'S';
  G_sPROGRAMN_ID := G_sPKG_ID ||'.'|| 'SP_SET_FIXED_ZONE';
  --* Planned Order ------------------------------------------------------------------------------------
  G_sSTEP_SEQ := '1.0';   
  G_sSTEP_DESC := 'Set Planned Order';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO PLANNEDORDER(ENGINE_ID, PLANNEDORDER_ID, INVENTORY_ID, QTY, DUE_DATE, DUE_DATE_FENCE, PST, PRIORITY, TO_STOCK, PLAN_TYPE, PARTIAL_PLAN, DESCRIPTION
                          ,JC_DYNAMIC_VALUE_ID, JC_TYPE, CONTINU_NUM)
  SELECT P_tPLAN_OPTION.ENGINE_ID
        ,FIXED_ORDER_ID                          AS PLANNEDORDER_ID
        ,ITEM_CD || '@' || SITE_CD               AS INVENTORY_ID
        ,QTY       
        ,ADD_MONTHS(TO_DATE(PLAN_MONTH || '01', 'YYYYMMDD'), 1) AS DUE_DATE
--[AIS_TODO]        
        ,NULL                                    AS DUE_DATE_FENCE
        ,TO_DATE(PLAN_MONTH || '01', 'YYYYMMDD') AS PST
        ,ROW_NUMBER() OVER (PARTITION BY SITE_CD, LINE_CD, PLAN_MONTH ORDER BY ITEM_CD) AS PRIORITY
        ,'Y'                                     AS TO_STOCK
        ,'ICIM'                                  AS PLAN_TYPE
        ,'N'                                     AS PARTIAL_PLAN
        ,LINE_CD                                 AS DESCRIPTION
        ,LINE_CD                                 AS JC_DYNAMIC_VALUE_ID
--[AIS_TODO]          
        ,'F'                                     AS JC_TYPE
        ,2                                       AS CONTINU_NUM
    FROM TB_SMP_WK_FIXED_PROD
   WHERE VERSION_ID            = P_tPLAN_OPTION.VERSION_ID
   ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------  
  
  --* PO RESOURCE ASSIGN--------------------------------------------------------------------------------
  G_sSTEP_SEQ := '2.0';   
  G_sSTEP_DESC := 'Set PO Resource assign (Usable = N)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  INSERT INTO PO_RESOURCE_ASSIGN(ENGINE_ID, PLANNEDORDER_ID, RESOURCE_ID, ROUTE_ID, USABLE, PRIORITY) 
  SELECT DISTINCT
         P_tPLAN_OPTION.ENGINE_ID       
                              AS ENGINE_ID
        ,SWD.FIXED_ORDER_ID   AS PLANNEDORDER_ID
        ,BOR.LINE_CD          AS RESOURCE_ID
        ,BOM.ROUTE_ID         AS ROUTE_ID
        ,'N'                  AS USABLE
        ,NULL                 AS PRIORITY
    FROM TB_SMP_WK_BOM     BOM
        ,TB_SMP_WK_BOR     BOR
        ,TB_SMP_WK_FIXED_PROD  SWD
   WHERE BOM.VERSION_ID    = P_tPLAN_OPTION.VERSION_ID
     AND BOM.P_ROUTE_CD    = P_tPLAN_OPTION.ASSY_ROUTE_CD -- 'BAS' 
     AND BOM.VERSION_ID    = BOR.VERSION_ID 
     AND BOM.ROUTE_ID      = BOR.ROUTE_ID 
     AND BOM.USE_FLAG      = 'Y'
     AND BOR.VERSION_ID    = SWD.VERSION_ID 
     AND BOR.ITEM_CD       = SWD.ITEM_CD
  ;
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);

  G_sSTEP_SEQ := '3.0';   
  G_sSTEP_DESC := 'Set PO Resource assign (Usable = Y)';    
  PKG_SMP_LOGGER.stepSTART (G_nLOG_SEQ, G_sPROGRAMN_ID, G_sSTEP_SEQ, G_sSTEP_DESC, P_tPLAN_OPTION.VERSION_ID, G_sUSER_ID); 
  UPDATE PO_RESOURCE_ASSIGN PRA
     SET PRA.USABLE = 'Y'
   WHERE ENGINE_ID  = P_tPLAN_OPTION.ENGINE_ID
     AND EXISTS (
         SELECT 1
           FROM TB_SMP_WK_FIXED_PROD WFP
          WHERE VERSION_ID           = P_tPLAN_OPTION.VERSION_ID
            AND WFP.FIXED_ORDER_ID   = PRA.PLANNEDORDER_ID
            AND WFP.LINE_CD          = PRA.RESOURCE_ID
         )
  ; 
  PKG_SMP_LOGGER.stepFINISH (G_nLOG_SEQ, SQL%ROWCOUNT);
  ------------------------------------------------------------------------------------------------------      
EXCEPTION
  WHEN OTHERS     THEN
    ROLLBACK;
    O_sFLAG    := 'F';
    G_sLOGMSG := '['||G_sSTEP_SEQ||']';
    G_sLOGMSG := G_sLOGMSG || ' ####ERROR RECORD[ ' || SQLCODE;
    G_sLOGMSG := G_sLOGMSG || ' : ' || SQLERRM || ' ]';
    PKG_SMP_LOGGER.stepERROR(G_nLOG_SEQ, G_sLOGMSG); 
END;

END PKG_SMP_I_DYNAMIC;
/

