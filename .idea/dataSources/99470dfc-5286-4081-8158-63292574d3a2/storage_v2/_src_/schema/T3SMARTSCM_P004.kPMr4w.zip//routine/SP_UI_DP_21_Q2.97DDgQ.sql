create PROCEDURE "SP_UI_DP_21_Q2" (
    P_FROM_DATE         DATE
  , P_TO_DATE           DATE
  , P_ITEM_CD       IN  VARCHAR2
  , P_ITEM_NM       IN  VARCHAR2
  , P_ACCT_CD       IN  VARCHAR2
  , P_ACCT_NM       IN  VARCHAR2
  , P_PRICE_TP_ID   IN  VARCHAR2
  , P_BUCKET_CD     IN  VARCHAR2
  , pRESULT         OUT SYS_REFCURSOR        
) IS
/*************************************************************************************************************************
    Price Management ？？？ ？？？ ？？？？？ ？？？ ？？？ν？？？ 
    - ？？？？？ : ？？？？？？
    - ？？？？？￥ : 2018.06.26
    -REGEXP_LIKE : '|' ？？ ？？？？？？？ ？？？？ ？？？
*************************************************************************************************************************/
    -- ？？？？？ ？？？？
    V_BUCKET            VARCHAR2(10)    := '';
    V_FROM_DATE         DATE            := NULL;
    V_TO_DATE           DATE            := NULL;
    V_PARTIAL_DATE_CAL  DATE            := NULL;
    V_PARTIAL_DATE      DATE            := NULL;
    V_PARTIAL_BUCKET    VARCHAR2(10)    := '';
    V_PARTIAL_HORIZON   INT             := 0;
BEGIN
    --------------------------------------------
        --01 BUCKET ？？？？？
    --------------------------------------------
/*
     SELECT COUNT(PP.POLICY_VAL)     INTO P_BUCKET_CD   
      FROM TB_DP_PLAN_POLICY PP
           LEFT OUTER JOIN
           TB_CM_COMM_CONFIG BK
        ON(PP.POLICY_ID = BK.ID)
           LEFT OUTER JOIN
           TB_CM_COMM_CONFIG PT
        ON(PP.PLAN_TP_ID = PT.ID)   
     WHERE 1=1
       AND BK.CONF_GRP_CD = 'DP_POLICY'
       AND BK.CONF_CD     = 'B'
       AND PT.CONF_GRP_CD = 'DP_PLAN_TYPE'
       AND PT.CONF_CD     = TRIM(P_BUCKET_CD)    -- 'DP_PLAN_MONTHLY'
       ;     
    IF(P_BUCKET_CD != 0)
        THEN

    SELECT TRIM(PP.POLICY_VAL)     INTO P_BUCKET_CD   
      FROM TB_DP_PLAN_POLICY PP
           LEFT OUTER JOIN
           TB_CM_COMM_CONFIG BK
        ON(PP.POLICY_ID = BK.ID)
           LEFT OUTER JOIN
           TB_CM_COMM_CONFIG PT
        ON(PP.PLAN_TP_ID = PT.ID)   
     WHERE 1=1
       AND BK.CONF_GRP_CD = 'DP_POLICY'
       AND BK.CONF_CD     = 'B'
       AND PT.CONF_GRP_CD = 'DP_PLAN_TYPE'
       AND PT.CONF_CD     = TRIM(P_BUCKET_CD)    -- 'DP_PLAN_MONTHLY'
       ;
    ELSE
        P_BUCKET_CD := 'NONE';
    END IF;
--       P_BUCKET_CD := 'PW'; 
*/  
    ----------------------------------------------------------------------------------------------------------------------
        --02 ？？？？？？, ？？？？？？ BUCKET ？？？？？？ ？？？？？？
    ----------------------------------------------------------------------------------------------------------------------

    V_FROM_DATE := P_FROM_DATE;
    V_TO_DATE   := P_TO_DATE;

    ----------------------------------------------------------------------------------------------------------------------
        --03 ？？？？？ ？？？？ ？？￥？？ UNIT PRICE ？？？ν？？？ (M/W/PW/D)
    ----------------------------------------------------------------------------------------------------------------------
    IF (P_BUCKET_CD = 'YEAR')     --？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
    THEN 
        OPEN pRESULT
        FOR
        SELECT M.ITEM_MST_ID
             , ITEM_CD
             , ITEM_NM
             , M.ACCOUNT_ID
             , ACCOUNT_CD
             , ACCOUNT_NM
             , DAT
             , UTPIC
          FROM TB_DP_UNIT_PRICE M
         INNER JOIN (
            SELECT P.ITEM_MST_ID
                 , I.ITEM_CD
                 , I.ITEM_NM
                 , P.ACCOUNT_ID
                 , A.ACCOUNT_CD
                 , A.ACCOUNT_NM
                 , DAT
                 , MAX(P.BASE_DATE) AS BASE_DATE
              FROM TB_CM_CALENDAR C
                   LEFT OUTER JOIN TB_DP_UNIT_PRICE P ON (C.DAT >= P.BASE_DATE)-- AND ADD_MONTHS(P.BASE_DATE, 1)> C.DAT) 
                   LEFT OUTER JOIN TB_CM_ITEM_MST I ON (P.ITEM_MST_ID = I.ID)
                   LEFT OUTER JOIN TB_DP_ACCOUNT_MST A ON (P.ACCOUNT_ID = A.ID)
             WHERE 1=1
               AND DAT BETWEEN V_FROM_DATE AND V_TO_DATE
               AND DD = TO_NUMBER(TO_CHAR(V_FROM_DATE,'DD'))   -- ？？？ BUCKET
               AND MM = TO_NUMBER(TO_CHAR(V_FROM_DATE,'MM'))   -- ？？？ BUCKET
               AND P.PRICE_TP_ID = P_PRICE_TP_ID
               AND (REGEXP_LIKE (UPPER(A.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR p_ACCT_CD IS NULL
               )
               AND (REGEXP_LIKE (UPPER(I.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR P_ITEM_CD IS NULL
               )
               AND (REGEXP_LIKE (UPPER(A.ACCOUNT_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ACCT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR p_ACCT_NM IS NULL
               )
               AND (REGEXP_LIKE (UPPER(I.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR P_ITEM_NM IS NULL
               )
             GROUP BY ITEM_MST_ID, ITEM_CD, ITEM_NM, ACCOUNT_ID, ACCOUNT_CD, ACCOUNT_NM, DAT
         ) B ON (M.ACCOUNT_ID = B.ACCOUNT_ID AND M.ITEM_MST_ID = B.ITEM_MST_ID AND M.BASE_DATE = B.BASE_DATE)
         ORDER BY ITEM_CD, ACCOUNT_CD, DAT
        ;
    ELSIF (P_BUCKET_CD = 'MONTH')     --？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
    THEN  
        OPEN pRESULT
        FOR
        SELECT M.ITEM_MST_ID
             , ITEM_CD
             , ITEM_NM
             , M.ACCOUNT_ID
             , ACCOUNT_CD
             , ACCOUNT_NM
             , DAT
             , UTPIC
          FROM TB_DP_UNIT_PRICE M
         INNER JOIN (
            SELECT P.ITEM_MST_ID 
                 , I.ITEM_CD
                 , I.ITEM_NM
                 , P.ACCOUNT_ID
                 , A.ACCOUNT_CD
                 , A.ACCOUNT_NM
                 , C.DAT
                 , MAX(P.BASE_DATE) AS BASE_DATE
              FROM TB_CM_CALENDAR C
              LEFT OUTER JOIN TB_DP_UNIT_PRICE P
                ON (C.DAT >= P.BASE_DATE)
              LEFT OUTER JOIN TB_CM_ITEM_MST I
                ON (P.ITEM_MST_ID = I.ID)
              LEFT OUTER JOIN TB_DP_ACCOUNT_MST A
                ON (P.ACCOUNT_ID = A.ID)
             WHERE 1=1
               AND DAT BETWEEN V_FROM_DATE AND V_TO_DATE
               AND DD = TO_NUMBER(TO_CHAR(V_FROM_DATE,'DD'))   -- ？？？ BUCKET
               AND P.PRICE_TP_ID = P_PRICE_TP_ID
               AND (REGEXP_LIKE (UPPER(A.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR p_ACCT_CD IS NULL
               )
               AND (REGEXP_LIKE (UPPER(I.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR P_ITEM_CD IS NULL
               )
               AND (REGEXP_LIKE (UPPER(A.ACCOUNT_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ACCT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR p_ACCT_NM IS NULL
               )
               AND (REGEXP_LIKE (UPPER(I.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR P_ITEM_NM IS NULL
               )
             GROUP BY ITEM_MST_ID, ITEM_CD, ITEM_NM, ACCOUNT_ID, ACCOUNT_CD, ACCOUNT_NM, DAT
         ) B ON (M.ACCOUNT_ID = B.ACCOUNT_ID AND M.ITEM_MST_ID = B.ITEM_MST_ID AND M.BASE_DATE = B.BASE_DATE) 
         ORDER BY ITEM_MST_ID, ACCOUNT_ID, DAT
        ;
    ELSIF (P_BUCKET_CD = 'WEEK') --？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
    THEN
        OPEN pRESULT
        FOR
        SELECT M.ITEM_MST_ID
             , ITEM_CD
             , ITEM_NM
             , M.ACCOUNT_ID
             , ACCOUNT_CD
             , ACCOUNT_NM
             , DAT
             , UTPIC
          FROM TB_DP_UNIT_PRICE M
         INNER JOIN (
            SELECT P.ITEM_MST_ID
                 , I.ITEM_CD
                 , I.ITEM_NM
                 , P.ACCOUNT_ID
                 , A.ACCOUNT_CD
                 , A.ACCOUNT_NM
                 , C.DAT
                 , MAX(P.BASE_DATE) AS BASE_DATE
              FROM TB_CM_CALENDAR C 
              LEFT OUTER JOIN TB_DP_UNIT_PRICE P ON (C.DAT >= P.BASE_DATE)
              LEFT OUTER JOIN TB_CM_ITEM_MST I ON (P.ITEM_MST_ID = I.ID)
              LEFT OUTER JOIN TB_DP_ACCOUNT_MST A ON (P.ACCOUNT_ID = A.ID)
             WHERE 1=1
               AND DAT BETWEEN V_FROM_DATE AND V_TO_DATE
               AND DOW_NM = (SELECT UPPER(CONF_CD) FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_STD_WEEK' AND ACTV_YN = 'Y' AND USE_YN = 'Y') -- COLLATE DATABASE_DEFAULT conversion required
               AND P.PRICE_TP_ID = P_PRICE_TP_ID -- COLLATE DATABASE_DEFAULT conversion required
               AND (REGEXP_LIKE (UPPER(A.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR p_ACCT_CD IS NULL
               )
               AND (REGEXP_LIKE (UPPER(I.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR P_ITEM_CD IS NULL
               )
               AND (REGEXP_LIKE (UPPER(A.ACCOUNT_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ACCT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR p_ACCT_NM IS NULL
               )
               AND (REGEXP_LIKE (UPPER(I.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR P_ITEM_NM IS NULL
               )
             GROUP BY ITEM_MST_ID, ITEM_CD, ITEM_NM, ACCOUNT_ID, ACCOUNT_CD, ACCOUNT_NM, DAT -- COLLATE DEFAULT_DATABASE conversion required
         ) B ON (M.ACCOUNT_ID = B.ACCOUNT_ID AND M.ITEM_MST_ID = B.ITEM_MST_ID AND M.BASE_DATE = B.BASE_DATE)
         ORDER BY ITEM_CD, ACCOUNT_CD, DAT
        ;
    ELSIF (P_BUCKET_CD = 'PAR_WEEK') --？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
    THEN
        OPEN pRESULT
        FOR
        SELECT M.ITEM_MST_ID
             , ITEM_CD
             , ITEM_NM
             , M.ACCOUNT_ID
             , ACCOUNT_CD
             , ACCOUNT_NM
             , DAT
             , UTPIC
          FROM TB_DP_UNIT_PRICE M
         INNER JOIN (
            SELECT P.ITEM_MST_ID
                 , I.ITEM_CD
                 , I.ITEM_NM
                 , P.ACCOUNT_ID
                 , A.ACCOUNT_CD
                 , A.ACCOUNT_NM
                 , C.DAT
                 , MAX(P.BASE_DATE) AS BASE_DATE
              FROM TB_CM_CALENDAR C 
              LEFT OUTER JOIN TB_DP_UNIT_PRICE P ON (C.DAT >= P.BASE_DATE)
              LEFT OUTER JOIN TB_CM_ITEM_MST I ON (P.ITEM_MST_ID = I.ID)
              LEFT OUTER JOIN TB_DP_ACCOUNT_MST A ON (P.ACCOUNT_ID = A.ID)
             WHERE 1=1
               AND DAT BETWEEN V_FROM_DATE AND V_TO_DATE
               AND (DOW_NM = (SELECT UPPER(CONF_CD) FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_STD_WEEK' AND ACTV_YN = 'Y' AND USE_YN = 'Y')
                    OR DD = 1)
               AND P.PRICE_TP_ID = P_PRICE_TP_ID
               AND (REGEXP_LIKE (UPPER(A.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR p_ACCT_CD IS NULL
               )
               AND (REGEXP_LIKE (UPPER(I.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR P_ITEM_CD IS NULL
               )
               AND (REGEXP_LIKE (UPPER(A.ACCOUNT_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ACCT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR p_ACCT_NM IS NULL
               )
               AND (REGEXP_LIKE (UPPER(I.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR P_ITEM_NM IS NULL
               )
             GROUP BY ITEM_MST_ID, ITEM_CD, ITEM_NM, ACCOUNT_ID, ACCOUNT_CD, ACCOUNT_NM, DAT
         ) B ON (M.ACCOUNT_ID = B.ACCOUNT_ID AND M.ITEM_MST_ID = B.ITEM_MST_ID AND M.BASE_DATE = B.BASE_DATE)
         ORDER BY ITEM_CD, ACCOUNT_CD, DAT
        ;
    ELSIF (P_BUCKET_CD = 'DAY')     --？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
    THEN
        OPEN pRESULT
        FOR
        SELECT M.ITEM_MST_ID 
             , ITEM_CD
             , ITEM_NM
             , M.ACCOUNT_ID
             , ACCOUNT_CD
             , ACCOUNT_NM
             , DAT
             , UTPIC
          FROM TB_DP_UNIT_PRICE M
         INNER JOIN (
            SELECT P.ITEM_MST_ID
                 , I.ITEM_CD
                 , I.ITEM_NM
                 , P.ACCOUNT_ID
                 , A.ACCOUNT_CD
                 , A.ACCOUNT_NM
                 , C.DAT
                 , MAX(P.BASE_DATE) AS BASE_DATE
              FROM TB_CM_CALENDAR C
              LEFT OUTER JOIN TB_DP_UNIT_PRICE P ON (C.DAT >= P.BASE_DATE)
              LEFT OUTER JOIN TB_CM_ITEM_MST I ON (P.ITEM_MST_ID = I.ID)
              LEFT OUTER JOIN TB_DP_ACCOUNT_MST A ON (P.ACCOUNT_ID = A.ID)
             WHERE 1=1
               AND DAT BETWEEN V_FROM_DATE AND V_TO_DATE
               AND P.PRICE_TP_ID = P_PRICE_TP_ID
               AND (REGEXP_LIKE (UPPER(A.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR p_ACCT_CD IS NULL
               )
               AND (REGEXP_LIKE (UPPER(I.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR P_ITEM_CD IS NULL
               )
               AND (REGEXP_LIKE (UPPER(A.ACCOUNT_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ACCT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR p_ACCT_NM IS NULL
               )
               AND (REGEXP_LIKE (UPPER(I.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR P_ITEM_NM IS NULL
               )
               GROUP BY ITEM_MST_ID, ITEM_CD, ITEM_NM, ACCOUNT_ID, ACCOUNT_CD, ACCOUNT_NM, DAT
         ) B ON (M.ACCOUNT_ID = B.ACCOUNT_ID AND M.ITEM_MST_ID = B.ITEM_MST_ID AND M.BASE_DATE = B.BASE_DATE)
         ORDER BY ITEM_CD, ACCOUNT_CD, DAT
        ;
    ELSE
        OPEN pRESULT
        FOR
        SELECT 'NO BUCKET' FROM DUAL;
    END IF;
END;
/

