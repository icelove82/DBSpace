create PROCEDURE "SP_UI_CM_15_S3" (
    P_ID                 IN CHAR := NULL,
    P_CON_ID             IN VARCHAR2 := '',
    P_ACTV_YN            IN VARCHAR2 := NULL,
    P_PRIORT             IN VARCHAR2 := NULL,
    P_APPY_SEQ           IN VARCHAR2 := NULL,
    P_VAL_04             IN VARCHAR2 := NULL,
    P_VAL_05             IN VARCHAR2 := NULL,
    P_PLAN_POLICY_VAL_ID IN CHAR :=  NULL,
    P_USER_ID            IN VARCHAR2 := NULL,
    P_RT_ROLLBACK_FLAG OUT VARCHAR2,
    P_RT_MSG   OUT VARCHAR2            
)
    IS
    /* PP_CON_03	Confirmed Planning Level	                	    */
    /* PP_CON_04	Infinite Planning Level			                    */
    /* PP_CON_06	Plan Priority					                    */
    /* PP_CON_07	Sub Plan Priority                                   */
    /* PP_CON_08	Half-finished Goods Integration Plan Priority       */
    /* PP_CON_09	Half-finished Goods Integration Sub Plan Priority   */
    /* PP_CON_12	Allocation Rule (Resource)                          */

    /*
     M00210000	Confirmed Planning Level Grid
     M00230000	Infinite Planning Level Grid
     M00320000	Plan Priority
                Sub Plan Priority --> PP_CON_07
     M00330000	Half-finished Goods Integration Plan Priority
                Half-finished Goods Integration Sub Plan Priority --> PP_CON_09
     M00430000	Multi-Level Allocation Rule
    */
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG  VARCHAR2(4000) :='';   
BEGIN

   
    -- PP_CON_03	Confirmed Planning Level
    -- PP_CON_04	Infinite Planning Level
    IF P_CON_ID IN (
            'PP_CON_03',
            'PP_CON_04'
    ) THEN
        MERGE INTO TB_CM_GRID_VALUE TARGET
        USING (
            SELECT
                P_ID        AS ID
            FROM DUAL
        )SOURCE
        ON (TARGET.ID = SOURCE.ID)
        WHEN MATCHED THEN
        UPDATE 
        SET
            TARGET.ACTV_YN = P_ACTV_YN,
            TARGET.MODIFY_BY = P_USER_ID,
            TARGET.MODIFY_DTTM = SYSDATE
        WHEN NOT MATCHED THEN
        INSERT
        (ID, PLAN_POLICY_VAL_ID, PLAN_POLICY_DTL_ID,
         GRID_VAL_01, GRID_VAL_02, GRID_VAL_03, GRID_VAL_04, GRID_VAL_05,
         GRID_VAL_06, GRID_VAL_07, GRID_VAL_08, GRID_VAL_09, GRID_VAL_10,
         PRIORT, ACTV_YN, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM)
        VALUES
        (TO_SINGLE_BYTE(SYS_GUID()), P_PLAN_POLICY_VAL_ID, NULL,
         P_VAL_04, P_VAL_05, NULL, NULL, NULL,
         NULL, NULL, NULL, NULL, NULL, NULL, P_ACTV_YN, P_USER_ID, SYSDATE, NULL, NULL);
        

        P_RT_ROLLBACK_FLAG := 'true';
		P_RT_MSG := 'MSG_0001';                   
    -- PP_CON_06	Plan Priority
    -- PP_CON_08	Half-finished Goods Integration Plan Priority
    ELSIF P_CON_ID IN (
        'PP_CON_06',
        'PP_CON_08'
    ) THEN
        UPDATE TB_CM_GRID_VALUE W
        SET
            W.ACTV_YN = P_ACTV_YN,
            W.PRIORT = TO_NUMBER(P_PRIORT),
            W.MODIFY_BY = P_USER_ID,
            W.MODIFY_DTTM = SYSDATE            
        WHERE
            1 = 1
            AND W.ID = P_ID;
           
        P_RT_ROLLBACK_FLAG := 'true';
		P_RT_MSG := 'MSG_0001';                     

   -- PP_CON_07	    Sub Plan Priority
   -- PP_CON_09	    Half-finished Goods Integration Sub Plan Priority
    ELSIF P_CON_ID IN (
        'PP_CON_07',
        'PP_CON_09'
    ) THEN
        UPDATE TB_CM_SUB_PRIORITY W
        SET
            W.ACTV_YN = P_ACTV_YN,
            W.PRIORT = TO_NUMBER(P_PRIORT),
            W.MODIFY_BY = P_USER_ID,
            W.MODIFY_DTTM = SYSDATE        
        WHERE
            1 = 1
            AND W.ID = P_ID;
           
        P_RT_ROLLBACK_FLAG := 'true';
		P_RT_MSG := 'MSG_0001';

    -- PP_CON_12	Allocation Rule (Resource)
    ELSIF P_CON_ID = 'PP_CON_12'
    THEN
        UPDATE TB_CM_MULTI_LV_ALLOC_RULE W
        SET
            W.ACTV_YN = P_ACTV_YN,
            W.APPY_SEQ = TO_NUMBER(P_APPY_SEQ),
            W.MODIFY_BY = P_USER_ID,
            W.MODIFY_DTTM = SYSDATE        
        WHERE
            1 = 1
            AND W.ID = P_ID;
           
        P_RT_ROLLBACK_FLAG := 'true';
		P_RT_MSG := 'MSG_0001';           

    END IF;
    EXCEPTION
    WHEN OTHERS THEN
        IF(SQLCODE = -20012)
          THEN 
              P_RT_ROLLBACK_FLAG := 'false';
              P_RT_MSG := P_ERR_MSG;
          ELSE
              RAISE;
          END IF;          
          
           END;

/

