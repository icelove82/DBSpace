create PROCEDURE "SP_UI_DP_00_POPUP_ACC_TREE_Q1" (
    p_USER_ID           VARCHAR2    := NULL	
  , p_AUTH_TP_ID        CHAR        := NULL 
  , p_ACCT_CD       IN  VARCHAR2    := ''
  , p_ACCT_NM       IN  VARCHAR2    := ''
  , p_ACCT_LV       IN  VARCHAR2    := ''
  , pRESULT         OUT SYS_REFCURSOR
) IS 

/*************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 

************************************************************************/
    P_EMP_ID    CHAR(32);
    p_CNT       INT;
    P_TOP_LV_YN INT;    -- True : 1, False : 0
BEGIN

    SELECT COUNT(ID)
      INTO P_CNT
      FROM TB_AD_USER
     WHERE USERNAME = P_USER_ID;

    IF P_CNT != 0 THEN
        SELECT ID INTO P_EMP_ID
          FROM TB_AD_USER
         WHERE USERNAME = P_USER_ID;
    END IF;

    SELECT COUNT(EMP_ID) INTO P_CNT
      FROM TB_DP_USER_ACCOUNT_MAP UA
           INNER JOIN
           TB_DP_ACCOUNT_MST AC
        ON AC.ID = UA.ACCOUNT_ID
       AND AC.DEL_YN != 'Y'
       AND AC.ACTV_YN = 'Y'
     WHERE AUTH_TP_ID = P_AUTH_TP_ID
       AND EMP_ID = P_EMP_ID
    ;
    SELECT P_CNT + COUNT(EMP_ID) INTO P_CNT
      FROM TB_DP_USER_ACCOUNT_MAP UA
           INNER JOIN
           TB_DP_SALES_LEVEL_MGMT SL
        ON SL.ID = UA.SALES_LV_ID
       AND SL.DEL_YN != 'Y'
       AND SL.ACTV_YN = 'Y'
     WHERE AUTH_TP_ID = P_AUTH_TP_ID
       AND EMP_ID = P_EMP_ID
    ;

    SELECT P_CNT+COUNT(EMP_ID) INTO P_CNT
      FROM TB_DP_USER_ITEM_ACCOUNT_MAP UA
--           INNER JOIN
--           TB_CM_ITEM_MST IT
--        ON IT.ID = UA.ITEM_MST_ID
--       AND IT.DP_PLAN_YN = 'Y'
--       AND IT.DEL_YN != 'Y'
           INNER JOIN
           TB_DP_ACCOUNT_MST AC
        ON AC.ID = UA.ACCOUNT_ID
       AND AC.DEL_YN != 'Y'
       AND AC.ACTV_YN = 'Y'
     WHERE EMP_ID = P_EMP_ID
       AND AUTH_TP_ID = P_AUTH_TP_ID
    ;
/**********************************************************
    -- MAIN PROCEDURE
**********************************************************/
    IF(P_USER_ID IS NULL) 
    THEN
		OPEN pRESULT          
		FOR 
		SELECT AM.ID
		     , AM.ACCOUNT_CD
			 , AM.ACCOUNT_NM
			 , AM.PARENT_SALES_LV_ID
             , TR.LEAF_SALES_LV_CD   AS PARENT_SALES_LV_CD
             , TR.LEAF_SALES_LV_NM   AS PARENT_SALES_LV_NM
			 , AM.CURCY_CD_ID
             , AC.COMN_CD       AS CURCY_CD
             , AC.COMN_CD_NM    AS CURCY_NM
			 , AM.COUNTRY_ID
             , CU.CONF_NM       AS COUNTRY_NM
			 , AM.CHANNEL_ID
             , CH.CHANNEL_NM
			 , AM.SOLD_TO_ID
			 , (SELECT CUST_CD FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SOLD_TO_ID) AS SOLD_TO_CD			  
			 , (SELECT CUST_NM FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SOLD_TO_ID) AS SOLD_TO_NM
			 , AM.SHIP_TO_ID
			 , (SELECT CUST_CD FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SHIP_TO_ID) AS SHIP_TO_CD
			 , (SELECT CUST_NM FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SHIP_TO_ID) AS SHIP_TO_NM
			 , AM.BILL_TO_ID
			 , (SELECT CUST_CD FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.BILL_TO_ID) AS BILL_TO_CD
			 , (SELECT CUST_NM FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.BILL_TO_ID) AS BILL_TO_NM
			 , AM.SRP_YN
			 , AM.INCOTERMS_ID
			 , AM.VMI_YN
			 , AM.DIRECT_SHPP_YN
			 , AM.ACTV_YN
			 , AM.ATTR_01
			 , AM.ATTR_02
			 , AM.ATTR_03
			 , AM.ATTR_04
			 , AM.ATTR_05
			 , AM.ATTR_06
			 , AM.ATTR_07
			 , AM.ATTR_08
			 , AM.ATTR_09
			 , AM.ATTR_10
			 , AM.ATTR_11
			 , AM.ATTR_12
			 , AM.ATTR_13
			 , AM.ATTR_14
			 , AM.ATTR_15
			 , AM.ATTR_16
			 , AM.ATTR_17
			 , AM.ATTR_18
			 , AM.ATTR_19
			 , AM.ATTR_20
			 , AM.CREATE_BY
			 , AM.CREATE_DTTM
			 , AM.MODIFY_BY
			 , AM.MODIFY_DTTM
	      FROM TB_DP_ACCOUNT_MST AM
	           INNER JOIN
               TABLE(FN_DP_TEMP_ACCT_TREE()) TR
            ON TR.PATH_CD LIKE '%/' || P_ACCT_LV || '%'
           AND TR.LEAF_SALES_LV_ID = AM.PARENT_SALES_LV_ID
               LEFT OUTER JOIN
               TB_AD_COMN_CODE AC 
            ON AC.ID = AM.CURCY_CD_ID
               LEFT OUTER JOIN
               TB_CM_COMM_CONFIG CU
            ON CU.ID = AM.COUNTRY_ID
               LEFT OUTER JOIN
               TB_CM_CHANNEL_TYPE CH
            ON CH.ID = AM.CHANNEL_ID           
         WHERE 1=1
           AND COALESCE(AM.DEL_YN, 'N') = 'N'
           AND UPPER(AM.ACCOUNT_CD)  LIKE '%' || UPPER(RTRIM(p_ACCT_CD)) || '%'	
           AND UPPER(AM.ACCOUNT_NM)  LIKE '%' || UPPER(RTRIM(p_ACCT_NM)) || '%'
	     ORDER BY TR.SEQ, TR.LEAF_SALES_LV_CD, AM.ACCOUNT_CD			    
        ;
    ELSIF (P_CNT = 0)
    THEN    -- FN_DP_tEMP_ACCT_TREE : 최상위 레벨일 때만 PATH로, 나머지 레벨은 LEAF_SALES_LV로 매핑?
        OPEN pRESULT
        FOR
        SELECT AM.ID
    		 , AM.ACCOUNT_CD
    		 , AM.ACCOUNT_NM
    		 , AM.PARENT_SALES_LV_ID
    		 , TA.SEQ
    		 , TA.LEAF_SALES_LV_CD			AS PARENT_SALES_LV_CD
    		 , TA.LEAF_SALES_LV_NM			AS PARENT_SALES_LV_NM		
    		 , AM.CURCY_CD_ID
    		 , AM.COUNTRY_ID
    		 , AM.CHANNEL_ID
    		 , AM.SOLD_TO_ID
    		 , AM.SHIP_TO_ID
    		 , AM.BILL_TO_ID 
    		 , AM.SRP_YN
    		 , AM.INCOTERMS_ID
    		 , AM.VMI_YN
    		 , AM.DIRECT_SHPP_YN
    		 , AM.ACTV_YN
    		 , AM.ATTR_01
    		 , AM.ATTR_02
    		 , AM.ATTR_03
    		 , AM.ATTR_04
    		 , AM.ATTR_05
    		 , AM.ATTR_06
    		 , AM.ATTR_07
    		 , AM.ATTR_08
    		 , AM.ATTR_09
    		 , AM.ATTR_10
    		 , AM.ATTR_11
    		 , AM.ATTR_12
    		 , AM.ATTR_13
    		 , AM.ATTR_14
    		 , AM.ATTR_15
    		 , AM.ATTR_16
    		 , AM.ATTR_17
    		 , AM.ATTR_18
    		 , AM.ATTR_19
    		 , AM.ATTR_20
    		 , AM.CREATE_BY
    		 , AM.CREATE_DTTM
    		 , AM.MODIFY_BY
    		 , AM.MODIFY_DTTM
          FROM TB_DP_USER_ACCOUNT_MAP UA
               INNER JOIN
               TABLE(FN_DP_TEMP_ACCT_TREE()) TA
            ON TA.PATH_ID LIKE '%' || UA.SALES_LV_ID || '%'
           AND TA.PATH_CD LIKE '%' || P_ACCT_LV || '%'
               INNER JOIN
               TB_DP_ACCOUNT_MST AM
            ON TA.LEAF_SALES_LV_ID = AM.PARENT_SALES_LV_ID
               INNER JOIN
               TB_DP_SALES_AUTH_MAP SA
            ON TA.PATH_ID LIKE '%' || SA.SALES_LV_ID || '%'
         WHERE SA.EMP_ID = P_EMP_ID
           AND SYSDATE BETWEEN COALESCE(SA.STRT_DATE_AUTH, SYSDATE) AND COALESCE(SA.END_DATE_AUTH, SYSDATE)
       	   AND AM.ID NOT IN (
            SELECT ACCOUNT_ID
       	      FROM TB_DP_USER_ITEM_ACCOUNT_EXCLUD
       	     WHERE EMP_ID = UA.EMP_ID
       	       AND AUTH_TP_ID = UA.AUTH_TP_ID
       	   )
           AND UPPER(AM.ACCOUNT_CD)  LIKE '%' || UPPER(TRIM(NVL(p_ACCT_CD,''))) || '%'	
           AND UPPER(AM.ACCOUNT_NM)  LIKE '%' || UPPER(TRIM(NVL(P_ACCT_NM,''))) || '%'
         GROUP BY AM.ID
                , AM.ACCOUNT_CD
                , AM.ACCOUNT_NM
                , AM.PARENT_SALES_LV_ID
                , TA.SEQ
                , TA.LEAF_SALES_LV_NM
                , TA.LEAF_SALES_LV_CD
                , AM.CURCY_CD_ID
                , AM.COUNTRY_ID
                , AM.CHANNEL_ID
                , AM.SOLD_TO_ID
                , AM.SHIP_TO_ID
                , AM.BILL_TO_ID 
                , AM.SRP_YN
                , AM.INCOTERMS_ID
                , AM.VMI_YN
                , AM.DIRECT_SHPP_YN
                , AM.ACTV_YN
                , AM.ATTR_01
                , AM.ATTR_02
                , AM.ATTR_03
                , AM.ATTR_04
                , AM.ATTR_05
                , AM.ATTR_06
                , AM.ATTR_07
                , AM.ATTR_08
                , AM.ATTR_09
                , AM.ATTR_10
                , AM.ATTR_11
                , AM.ATTR_12
                , AM.ATTR_13
                , AM.ATTR_14
                , AM.ATTR_15
                , AM.ATTR_16
                , AM.ATTR_17
                , AM.ATTR_18
                , AM.ATTR_19
                , AM.ATTR_20
                , AM.CREATE_BY
                , AM.CREATE_DTTM
                , AM.MODIFY_BY
                , AM.MODIFY_DTTM
        UNION
    	SELECT AM.ID
    		 , AM.ACCOUNT_CD
    		 , AM.ACCOUNT_NM
    		 , AM.PARENT_SALES_LV_ID
    		 , TA.SEQ
    		 , TA.LEAF_SALES_LV_CD			AS PARENT_SALES_LV_CD
    		 , TA.LEAF_SALES_LV_NM			AS PARENT_SALES_LV_NM		
    		 , AM.CURCY_CD_ID
    		 , AM.COUNTRY_ID
    		 , AM.CHANNEL_ID
    		 , AM.SOLD_TO_ID
    		 , AM.SHIP_TO_ID
    		 , AM.BILL_TO_ID 
    		 , AM.SRP_YN
    		 , AM.INCOTERMS_ID
    		 , AM.VMI_YN
    		 , AM.DIRECT_SHPP_YN
    		 , AM.ACTV_YN
    		 , AM.ATTR_01
    		 , AM.ATTR_02
    		 , AM.ATTR_03
    		 , AM.ATTR_04
    		 , AM.ATTR_05
    		 , AM.ATTR_06
    		 , AM.ATTR_07
    		 , AM.ATTR_08
    		 , AM.ATTR_09
    		 , AM.ATTR_10
    		 , AM.ATTR_11
    		 , AM.ATTR_12
    		 , AM.ATTR_13
    		 , AM.ATTR_14
    		 , AM.ATTR_15
    		 , AM.ATTR_16
    		 , AM.ATTR_17
    		 , AM.ATTR_18
    		 , AM.ATTR_19
    		 , AM.ATTR_20
    		 , AM.CREATE_BY
    		 , AM.CREATE_DTTM
    		 , AM.MODIFY_BY
    		 , AM.MODIFY_DTTM
          FROM (
            SELECT ACCOUNT_ID
              FROM TB_DP_USER_ACCOUNT_MAP UA
             WHERE UA.ACCOUNT_ID NOT IN (
                SELECT ACCOUNT_ID
                  FROM TB_DP_USER_ITEM_ACCOUNT_EXCLUD
                 WHERE EMP_ID = UA.EMP_ID
                   AND AUTH_TP_ID = UA.AUTH_TP_ID
             )
             GROUP BY ACCOUNT_ID
    		UNION
            SELECT ACCOUNT_ID
              FROM TB_DP_USER_ITEM_ACCOUNT_MAP		   
             GROUP BY ACCOUNT_ID
          ) UA
    	       INNER JOIN
    		   TB_DP_ACCOUNT_MST AM
    		ON UA.ACCOUNT_ID = AM.ID 
    		   INNER JOIN
    		   TABLE(FN_DP_TEMP_ACCT_TREE()) TA
    		ON TA.LEAF_SALES_LV_ID = AM.PARENT_SALES_LV_ID 
           AND TA.PATH_CD LIKE '%' || P_ACCT_LV || '%'
               INNER JOIN
               TB_DP_SALES_AUTH_MAP SA
            ON TA.PATH_ID LIKE '%' || SA.SALES_LV_ID || '%'
    	 WHERE SA.EMP_ID  = P_EMP_ID
    	   AND SYSDATE BETWEEN COALESCE(SA.STRT_DATE_AUTH, SYSDATE) AND COALESCE(SA.END_DATE_AUTH, SYSDATE)		         
           AND UPPER(AM.ACCOUNT_CD)  LIKE '%' || UPPER(TRIM(NVL(p_ACCT_CD,''))) || '%'	
     	   AND UPPER(AM.ACCOUNT_NM)  LIKE '%' || UPPER(TRIM(NVL(P_ACCT_NM,''))) || '%'
     	 ORDER BY SEQ, PARENT_SALES_LV_CD, ACCOUNT_CD
        ; 
    ELSE
        OPEN pRESULT
        FOR
        SELECT AM.ID
             , AM.ACCOUNT_CD
             , AM.ACCOUNT_NM
             , AM.PARENT_SALES_LV_ID
             , SL.SALES_LV_CD       AS PARENT_SALES_LV_CD
             , SL.SALES_LV_NM       AS PARENT_SALES_LV_NM
             , AM.CURCY_CD_ID
             , AC.COMN_CD           AS CURCY_CD
             , AC.COMN_CD_NM        AS CURCY_NM
             , AM.COUNTRY_ID
             , CU.CONF_NM           AS COUNTRY_NM
             , AM.CHANNEL_ID
             , CH.CHANNEL_NM
             , AM.SOLD_TO_ID
             , (SELECT CUST_CD FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SOLD_TO_ID) AS SOLD_TO_CD              
             , (SELECT CUST_NM FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SOLD_TO_ID) AS SOLD_TO_NM
             , AM.SHIP_TO_ID
             , (SELECT CUST_CD FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SHIP_TO_ID) AS SHIP_TO_CD
             , (SELECT CUST_NM FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SHIP_TO_ID) AS SHIP_TO_NM
             , AM.BILL_TO_ID
             , (SELECT CUST_CD FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.BILL_TO_ID) AS BILL_TO_CD
             , (SELECT CUST_NM FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.BILL_TO_ID) AS BILL_TO_NM
             , AM.SRP_YN
             , AM.INCOTERMS_ID
             , AM.VMI_YN
             , AM.DIRECT_SHPP_YN
             , AM.ACTV_YN
             , AM.ATTR_01
             , AM.ATTR_02
             , AM.ATTR_03
             , AM.ATTR_04
             , AM.ATTR_05
             , AM.ATTR_06
             , AM.ATTR_07
             , AM.ATTR_08
             , AM.ATTR_09
             , AM.ATTR_10
             , AM.ATTR_11
             , AM.ATTR_12
             , AM.ATTR_13
             , AM.ATTR_14
             , AM.ATTR_15
             , AM.ATTR_16
             , AM.ATTR_17
             , AM.ATTR_18
             , AM.ATTR_19
             , AM.ATTR_20
             , AM.CREATE_BY
             , AM.CREATE_DTTM
             , AM.MODIFY_BY
             , AM.MODIFY_DTTM
          FROM FN_DP_TEMP_FIND_ACCOUNT(P_EMP_ID, P_AUTH_TP_ID, P_ACCT_LV) M
               INNER JOIN
               TB_DP_ACCOUNT_MST AM
            ON M.ACCOUNT_ID = AM.ID
               INNER JOIN
               TB_DP_SALES_LEVEL_MGMT SL
            ON M.PARENT_SALES_LV_ID = SL.ID
               LEFT OUTER JOIN
               TB_AD_COMN_CODE AC
            ON AC.ID = AM.CURCY_CD_ID
               LEFT OUTER JOIN
               TB_CM_COMM_CONFIG CU
            ON CU.ID = AM.COUNTRY_ID
               LEFT OUTER JOIN
               TB_CM_CHANNEL_TYPE CH
            ON CH.ID = AM.CHANNEL_ID
         WHERE 1=1
           AND COALESCE(AM.DEL_YN, 'N') = 'N'
           AND AM.ACTV_YN = 'Y'
           AND UPPER(AM.ACCOUNT_CD) LIKE '%' || UPPER(RTRIM(COALESCE(P_ACCT_CD, ''))) || '%'
           AND UPPER(AM.ACCOUNT_NM) LIKE '%' || UPPER(RTRIM(COALESCE(P_ACCT_NM, ''))) || '%'
         ORDER BY SL.SEQ, PARENT_SALES_LV_CD, ACCOUNT_CD
        ;
    END IF;
END
;
/

