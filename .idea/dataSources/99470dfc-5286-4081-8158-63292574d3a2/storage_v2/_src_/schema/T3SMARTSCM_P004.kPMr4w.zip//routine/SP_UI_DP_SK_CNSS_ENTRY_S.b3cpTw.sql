create PROCEDURE                 "SP_UI_DP_SK_CNSS_ENTRY_S" 
(
     P_C_VER_CD     VARCHAR2 -- New Version ID
    ,P_USER_ID      VARCHAR2
    ,P_AUTH_TP_ID   VARCHAR2
	  ,P_ACCOUNT_ID   VARCHAR2
    ,P_DATE         DATE
    ,P_QTY_2        NUMBER 
    ,P_RT_ROLLBACK_FLAG  OUT VARCHAR2   
    ,P_RT_MSG            OUT VARCHAR2 
) IS
/************************************************************************************************
    Consensus Version Save

    History (date / writer / comment)
    - 2021.05.13 / Kimsohee / Draft
*************************************************************************************************/ 
	    P_ERR_STATUS INT := 0;
        P_ERR_MSG VARCHAR2(4000) :='';   
BEGIN 
        -- Main 
        UPDATE TB_SDP_CONSENSUS_ENTRY
          SET QTY_2 = P_QTY_2
             ,EMP_ID = (SELECT ID FROM TB_AD_USER WHERE USERNAME = P_USER_ID) 
             ,MODIFY_BY = P_USER_ID
             ,MODIFY_DTTM = SYSDATE
         WHERE C_VER_CD = P_C_VER_CD 
           AND ACCOUNT_ID = P_ACCOUNT_ID
           AND BASE_DATE = P_DATE
           ;

 	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  --
       /*  ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN  -- : e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF; 

END
;

/

