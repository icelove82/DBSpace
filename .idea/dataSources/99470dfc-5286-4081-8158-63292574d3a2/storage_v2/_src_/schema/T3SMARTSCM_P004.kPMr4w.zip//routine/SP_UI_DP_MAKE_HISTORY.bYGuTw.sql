create PROCEDURE                 "SP_UI_DP_MAKE_HISTORY" (
     p_VER_ID			VARCHAR2
    ,p_AUTH_TP_ID		CHAR
)IS 

/******************************************************************************************
	-- Make Entry History
	-- for report
	-- History ( date / writer / comment)
	-- 2019.11.08 / draft
	-- 2020.03.20 / Make Annual DP (�냼�닔 諛섏삱由� 泥섎━�븿)
    -- 2020.12.23 / 誘쇨꼍�썕 / MSSQL -> ORACLE
  -- 2021.06.25 / 源��슜�닔 / TB_DP_MEASURE_DATA MERGE臾� 留됱쓬 : ANNUAL_QTY, ANNUAL_AMT 而щ읆�쓣 DROP  
******************************************************************************************/
v_VER_ID	    CHAR(32):= NULL;
p_MM_BUKT		VARCHAR2(2);
p_STRT_DATE		DATE ;
p_END_DATE		DATE ;
p_PLAN_TP_ATTR	CHAR(1);

BEGIN
    v_VER_ID := p_VER_ID;

    SELECT FROM_DATE
         , TO_DATE
         , ATTR_01
         , ID
           INTO
           p_STRT_DATE
         , p_END_DATE
         , p_PLAN_TP_ATTR
         , v_VER_ID
      FROM (
        SELECT FROM_DATE
             , TO_DATE
             , C.ATTR_01
             , V.ID
          FROM TB_DP_CONTROL_BOARD_VER_MST V
               INNER JOIN
               TB_CM_COMM_CONFIG C
               ON C.ID = V.PLAN_TP_ID
         WHERE VER_ID = p_VER_ID
     )
     WHERE ROWNUM = 1
	;
/***********************************************************************************************************************************
	-- make Entry History
************************************************************************************************************************************/
	merge INTO TB_DP_ENTRY_HISTORY tar
	using (select e.PLAN_TP_ID
				, ITEM_MST_ID
				, ACCOUNT_ID
				, BASE_DATE 
				, EMP_ID
				, QTY
				, AMT 
	       from TB_DP_ENTRY e
		  where auth_tp_id = p_AUTH_TP_ID
		    and ver_id = v_VER_ID
		   ) src
	   on (src.PLAN_TP_ID  = tar.PLAN_TP_ID 
	  and src.ITEM_MST_ID = tar.ITEM_MST_ID 
	  and src.ACCOUNT_ID  = tar.ACCOUNT_ID 
	  and src.BASE_DATE   = tar.BASE_DATE)
	WHEN MATCHED THEN 
		UPDATE SET QTY = src.QTY
				 , AMT = src.AMT
				 , MODIFY_DTTM = SYSDATE
	WHEN NOT MATCHED THEN  
			INSERT (Id
				  , PLAN_TP_ID
				  , ITEM_MST_ID
				  , ACCOUNT_ID
				  , BASE_DATE
				  , EMP_ID
				  , QTY
				  , AMT
				  , CREATE_DTTM
				  )
			VALUES (TO_SINGLE_BYTE(SYS_GUID())
				  , src.PLAN_TP_ID
				  , src.ITEM_MST_ID
				  , src.ACCOUNT_ID
				  , src.BASE_DATE
				  , src.EMP_ID
				  , src.QTY
				  , src.AMT
				  , SYSDATE
				  );

/***********************************************************************************************************************************
	-- make Annual DP when attribute of plan type is "Y"
************************************************************************************************************************************/

    SELECT BUKT
           INTO
           p_MM_BUKT
      FROM (
        SELECT BUKT
          FROM TB_DP_CONTROL_BOARD_VER_MST
         WHERE PLAN_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01 = 'M' AND ACTV_YN = 'Y')
         ORDER BY CREATE_DTTM DESC
      )
     WHERE ROWNUM=1
	;	

/*
    IF(p_PLAN_TP_ATTR = 'Y') 
	THEN
        MERGE INTO TB_DP_MEASURE_DATA SRC
        USING ( SELECT YY.ITEM_MST_ID
                      ,YY.ACCOUNT_ID
                      ,CA.STRT_DATE							AS BASE_DATE
                      ,ROUND(YY.QTY * CA.DAT_CNT  / SUM(CA.DAT_CNT) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID, MM),0)	AS QTY
                      ,ROUND(YY.AMT * CA.DAT_CNT  / SUM(CA.DAT_CNT) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID, MM),0)	AS AMT
                  FROM (SELECT MIN(DAT)				AS STRT_DATE
                             , MAX(DAT)				AS END_DATE
                             , MIN(YYYYMM)			AS YYYYMM
                             , COUNT(DAT)			AS DAT_CNT
                             , MIN(MM)				AS MM
                          FROM TB_CM_CALENDAR	
                         WHERE DAT BETWEEN p_STRT_DATE AND p_END_DATE 
                      GROUP BY TO_CHAR(YYYY)
                             , CASE WHEN p_MM_BUKT IN ('M', 'PW') THEN TO_CHAR(MM)    ELSE '1' END
                             , CASE WHEN p_MM_BUKT IN ('PW', 'W') THEN TO_CHAR(DP_WK) ELSE '1' END 
                    ) CA 
                   INNER JOIN
                   (SELECT ITEM_MST_ID
                         , ACCOUNT_ID
                         , BASE_DATE		AS STRT_DATE
                         , COALESCE(LEAD(BASE_DATE, 1) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID ORDER BY BASE_DATE ASC)-1, p_END_DATE) AS END_DATE
                         , QTY
                         , AMT		
                      FROM TB_DP_ENTRY
                     WHERE VER_ID = v_VER_ID
                       AND AUTH_TP_ID = p_AUTH_TP_ID
                    ) YY 	
                ON CA.STRT_DATE BETWEEN YY.STRT_DATE AND YY.END_DATE	-- �뿰媛� Bucket �떒�쐞媛� �썡媛� Bucket �떒�쐞蹂대떎 臾댁“嫄� 而ㅼ빞 �븿
          ) TGT
         ON (SRC.ITEM_MST_ID = TGT.ITEM_MST_ID
        AND SRC.ACCOUNT_ID  = TGT.ACCOUNT_ID
        AND SRC.BASE_DATE   = TGT.BASE_DATE	)
        WHEN MATCHED THEN 
        UPDATE 
          SET ANNUAL_QTY =   TGT.QTY
            , ANNUAL_AMT = 	 TGT.AMT
        WHEN NOT MATCHED THEN
        INSERT 
        (  ITEM_MST_ID
         , ACCOUNT_ID
         , BASE_DATE
         , ANNUAL_QTY
         , ANNUAL_AMT
         , CREATE_BY
         , CREATE_DTTM
        ) VALUES
        (  TGT.ITEM_MST_ID
         , TGT.ACCOUNT_ID
         , TGT.BASE_DATE
         , TGT.QTY
         , TGT.AMT
         , 'System'
         , SYSDATE
        )
        ;
	END IF;

*/

END;

/

