create PROCEDURE "SP_COMM_DATE_LIST_Q" (
     P_TYPE IN VARCHAR2 :=''
    ,pResult OUT SYS_REFCURSOR
)
IS
BEGIN

OPEN pResult FOR
    SELECT  A.DATE_VALUE
      FROM  (
				SELECT	 SYSDATE					 AS DATE_VALUE
						,'TODAY'					 AS TYPE
                    FROM DUAL
            UNION
				SELECT	 ADD_MONTHS(SYSDATE,-1) AS DATE_VALUE
						,'ONE_MONTH_BEFORE'			 AS TYPE
                    FROM DUAL
            UNION
				SELECT	 ADD_MONTHS(SYSDATE,-12)  AS DATE_VALUE
						,'ONE_YEAR_BEFORE'			 AS TYPE
                    FROM DUAL
			) A
		WHERE 1=1	
		  AND A.TYPE = P_TYPE;

END;

/

