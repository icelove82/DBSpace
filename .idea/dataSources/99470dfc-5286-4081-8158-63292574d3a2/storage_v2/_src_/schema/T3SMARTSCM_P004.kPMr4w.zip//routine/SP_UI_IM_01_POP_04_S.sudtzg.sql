create PROCEDURE SP_UI_IM_01_POP_04_S (
	 P_ID							IN VARCHAR2 := ''
	,P_LOCAT_ID					    IN VARCHAR2 := ''
	,P_CATAGY_VAL					IN VARCHAR2
	,P_INV_ANLY_PRIOD_ID		    IN VARCHAR2 := ''
	,P_ACTV_YN						IN CHAR := ''
	,P_PERIOD_VAL					IN NUMBER := ''
    ,P_UOM_NM_ID					IN CHAR := ''
	,P_WTFAR						IN NUMBER := ''
	,P_USER_ID						IN VARCHAR2 := ''
	,P_WRK_TYPE					    IN VARCHAR2 := ''
	,P_RT_ROLLBACK_FLAG		        OUT VARCHAR2
	,P_RT_MSG					    OUT VARCHAR2
)
/*****************************************************************************
 * System Name : T3Enterprise IM
 * Business Name : Inventory Grade Analysis
 * Program Name(ID) :SP_UI_IM_01_POP_04_S
 * Program Description : 
 *
 * Create Date : 2017.11.14
 * Author : Jo Aram
 *
 * Modifier    Modified Date    Revision History
 * --------    -------------    ----------------------------------------------
 * RSK         2019/03/11       Use COMN_CD instead of COMN_CD_NM & Formatting
 *
 *****************************************************************************/
IS
    P_ERR_STATUS NUMBER := 0;
    P_ERR_MSG VARCHAR2(4000) := '';
    P_TEMP VARCHAR2(32) := '';
    
BEGIN
    IF P_WRK_TYPE = 'SAVE' THEN
        SELECT A.ID INTO P_TEMP 
        FROM 
            TB_AD_COMN_CODE A 
            INNER JOIN TB_AD_COMN_GRP B ON A.SRC_ID = B.ID 
        WHERE 
            A.COMN_CD = 'DEMAND_PLAN' AND B.GRP_CD = 'INV_ANLY_PRIOD';

		IF P_INV_ANLY_PRIOD_ID = P_TEMP THEN
            P_ERR_MSG := 'MSG_0008'; -- 'Negative numbers can not be entered.'
			IF P_PERIOD_VAL < 0 THEN 
                RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;			
		ELSE
            P_ERR_MSG := 'MSG_0011'; -- 'Positive numbers can not be entered.'
			IF P_PERIOD_VAL > 0 THEN 
                RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); 
            END IF;
        END IF;

		P_ERR_MSG := 'MSG_0012'; -- 'You have entered a value that exceeds the percentage range.'
        IF (P_WTFAR < 0 OR P_WTFAR > 100) THEN 
            RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); 
        END IF;

		MERGE INTO TB_IM_INV_ANLY_PRIOD B 
            USING (SELECT P_ID AS ID FROM DUAL) A ON (B.ID = A.ID)
		WHEN MATCHED THEN
			UPDATE 
			   SET ACTV_YN			= P_ACTV_YN
				 , PERIOD_VAL		= P_PERIOD_VAL
                 , UOM_ID			= P_UOM_NM_ID
				 , WTFAR			= P_WTFAR
				 , MODIFY_BY		= P_USER_ID
				 , MODIFY_DTTM		= SYSDATE
		WHEN NOT MATCHED THEN
			INSERT (
				ID, LOCAT_ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
                ,CATAGY_VAL
				,INV_ANLY_PRIOD_ID
				,PERIOD_VAL
                ,UOM_ID
				,WTFAR
				,ACTV_YN
				)
			VALUES
				(
				TO_SINGLE_BYTE(SYS_GUID()),P_LOCAT_ID,P_USER_ID, SYSDATE, P_USER_ID, SYSDATE
                ,P_CATAGY_VAL
				,P_INV_ANLY_PRIOD_ID
				,P_PERIOD_VAL
                ,P_UOM_NM_ID
				,P_WTFAR
				,P_ACTV_YN
				);

		  P_RT_ROLLBACK_FLAG := 'true';
	      P_RT_MSG := 'MSG_0001';  -- Saved successfully.

    ELSIF P_WRK_TYPE = 'DELETE' THEN
        DELETE FROM TB_IM_INV_ANLY_PRIOD WHERE ID = P_ID;
        P_RT_ROLLBACK_FLAG := 'true';
		P_RT_MSG := 'MSG_0002';
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        P_RT_ROLLBACK_FLAG := 'false';
        IF(SQLCODE = -20012) THEN
            P_RT_MSG := P_ERR_MSG;   
        ELSE
            P_RT_MSG := SQLERRM;
        END IF;
END;


/

