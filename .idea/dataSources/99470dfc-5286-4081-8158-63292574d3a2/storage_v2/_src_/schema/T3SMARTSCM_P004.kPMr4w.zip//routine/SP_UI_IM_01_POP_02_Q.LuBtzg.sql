create PROCEDURE "SP_UI_IM_01_POP_02_Q" (
    P_TAB_INDEX IN VARCHAR2:=''
   ,pResult OUT SYS_REFCURSOR
)
/*****************************************************************************
 * System Name : T3Enterprise IM
 * Business Name : Inventory Grade Management Base
 * Program Name(ID) :SP_UI_IM_01_POP_02_Q
 * Program Description : Config Key 305, Search operation
 *
 * Create Date :
 * Author :
 *
 * Modifier    Modified Date    Revision History
 * --------    -------------    ----------------------------------------------
 * RSK         2019/03/12        Formatting & Comments
 *
 *****************************************************************************/
IS
BEGIN
   IF P_TAB_INDEX IN ('1','2')
   THEN
      OPEN pResult
      FOR 
		   SELECT  F.ID
				 ,E.LOCAT_ID
				 ,E.LOCAT_TP_NM
      			 ,E.LOCAT_LV
      			 ,E.LOCAT_CD
      			 ,E.LOCAT_NM
				 ,E.INV_CLSS_TP
				 ,F.ACTV_YN
				 ,F.UPPR_VAL
				 ,F.LOWR_VAL
				 ,F.SVC_LV
      			 ,F.CREATE_BY
      			 ,F.CREATE_DTTM
      			 ,F.MODIFY_BY
      			 ,F.MODIFY_DTTM
			FROM  (
					SELECT  A.COMN_CD_NM AS LOCAT_TP_NM
						   ,B.LOCAT_LV
        				   ,C.LOCAT_CD
        				   ,C.LOCAT_NM
						   ,C.ID AS LOCAT_ID
        				   ,D.ID AS LOCAT_MGMT_ID
        				   ,D.ACTV_YN
						   ,A.SEQ			AS LOC_SEQ
						   ,E.MGMT_NM	    AS INV_CLSS_TP
						   ,E.SEQ
					  FROM TB_AD_COMN_CODE A
						   INNER JOIN TB_CM_LOC_MST B ON (A.ID = B.LOCAT_TP_ID)
        				   INNER JOIN TB_CM_LOC_DTL C ON (B.ID = C.LOCAT_MST_ID)
        				   INNER JOIN TB_CM_LOC_MGMT D ON (C.ID = D.LOCAT_ID)
						  ,(SELECT B.ID, B.MGMT_NM, B.SEQ
							FROM   TB_IM_SEGMT_DIM_MST A
								   INNER JOIN TB_IM_SEGMT_DIM_DTL B
								   ON A.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
							WHERE  A.SEGMT_DIM_CD = 'VAL_02') E
					 WHERE 1=1
					   AND B.ACTV_YN = 'Y'
					   AND C.ACTV_YN = 'Y'
					   AND D.ACTV_YN = 'Y'
				   ) E
					LEFT OUTER JOIN TB_IM_STOCK_CLASS_MGMT F ON E.LOCAT_ID = F.LOCAT_ID
						AND E.INV_CLSS_TP = F.INV_CLSS_TP
						AND F.CATAGY_VAL = CASE WHEN P_TAB_INDEX = '1' THEN 'QTY_BASE'
												ELSE 'REVENUE_BASE'
												END
		    WHERE 1=1
			ORDER BY E.LOC_SEQ, E.LOCAT_LV, E.LOCAT_CD, E.SEQ;

   ELSE
      OPEN pResult
      FOR SELECT  E.ID
				 ,D.ID			AS LOCAT_ID
				 ,B.COMN_CD_NM	AS LOCAT_TP_NM
      			 ,C.LOCAT_LV
      			 ,D.LOCAT_CD
      			 ,D.LOCAT_NM
				 ,E.SABC_CAL_BASE_ID
				 ,F.COMN_CD_NM	AS SABC_CAL_BASE
				 ,E.ACTV_YN
      			 ,E.CREATE_BY
      			 ,E.CREATE_DTTM
      			 ,E.MODIFY_BY
      			 ,E.MODIFY_DTTM
			FROM  TB_AD_COMN_GRP A
				  INNER JOIN TB_AD_COMN_CODE B ON A.ID = B.SRC_ID
				  INNER JOIN TB_CM_LOC_MST C ON B.ID = C.LOCAT_TP_ID
				  INNER JOIN TB_CM_LOC_DTL D ON C.ID = D.LOCAT_MST_ID
                  LEFT OUTER JOIN TB_IM_SABC_CAL_BASE E ON D.ID = E.LOCAT_ID
                  LEFT OUTER JOIN 
					(SELECT G.ID, G.COMN_CD, G.COMN_CD_NM
						FROM TB_AD_COMN_GRP F
							,TB_AD_COMN_CODE G
						WHERE F.GRP_CD = 'SABC_CAL_BASE'
						AND F.ID = G.SRC_ID) F
					ON E.SABC_CAL_BASE_ID = F.ID
		   WHERE 1=1
			 AND A.GRP_CD = 'LOC_TP'
			 AND B.USE_YN = 'Y'
             AND D.ACTV_YN = 'Y';
	END IF;

END;

/

