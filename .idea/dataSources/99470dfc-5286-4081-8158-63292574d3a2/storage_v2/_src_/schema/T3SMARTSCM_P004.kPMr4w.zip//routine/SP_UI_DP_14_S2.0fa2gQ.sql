create PROCEDURE                 "SP_UI_DP_14_S2" (
	P_EMP_NO                IN VARCHAR2    := '' 
  , P_AUTH_TP_ID            IN VARCHAR2    := ''   
  , P_LV_CD                 IN VARCHAR2    := '' 
  , P_ACCOUNT_CD            IN VARCHAR2    := '' 	
  , P_ACTV_YN               IN CHAR        := ''                                          
  , P_USER_ID               IN VARCHAR2    := '' 
  , P_MAIN_LV_YN            IN CHAR        := ''
  , P_RT_ROLLBACK_FLAG      OUT VARCHAR2		 
  , P_RT_MSG                OUT VARCHAR2	
) 
/*************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 
    - 2021.04.07 / 源��슜�닔 / �궗�슜�옄蹂� �젣�뭹 �뀒�씠釉� �뜲�씠�꽣(TB_DP_USER_ITEM_MAP) �깮�꽦
************************************************************************/
IS  

    P_ERR_STATUS	INT            := 0;
    P_ERR_MSG       VARCHAR2(4000) :='';
    V_EMP_ID        VARCHAR2(32)   := NULL;    
    V_ACCT_YN       CHAR(1);
    V_ACCT_LV_ID    VARCHAR2(32);
    V_LV_MGMT_ID    VARCHAR2(32)   := NULL;            
    V_ACCOUNT_ID    VARCHAR2(32)   := NULL;    

    V_ACTV_YN       CHAR(1) := '';

    V_ITEM_LV_ID    VARCHAR2(32)   := NULL;
    V_ITEM_MGMT_ID  VARCHAR2(32)   := NULL;
    V_CNT           NUMBER         := 0;

BEGIN
    V_ACTV_YN := COALESCE(P_ACTV_YN, 'Y');

    SELECT ID
      INTO V_EMP_ID
      FROM TB_AD_USER
     WHERE USERNAME = P_EMP_NO;

    SELECT ID
        ,  LEAF_YN
      INTO V_LV_MGMT_ID, V_ACCT_YN
      FROM TB_CM_LEVEL_MGMT
     WHERE LV_CD = p_LV_CD;

    IF (V_ACCT_YN = 'Y') THEN
        SELECT ID INTO V_ACCOUNT_ID
          FROM TB_DP_ACCOUNT_MST
         WHERE ACCOUNT_CD = P_ACCOUNT_CD;
    ELSE
        SELECT ID, ID INTO V_ACCOUNT_ID, V_ACCT_LV_ID
          FROM TB_DP_SALES_LEVEL_MGMT
         WHERE SALES_LV_CD = P_ACCOUNT_CD
           AND LV_MGMT_ID = V_LV_MGMT_ID;
    END IF;

    IF (V_LV_MGMT_ID IS NULL) THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_ERR_MSG := 'MSG_5029';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

    IF (V_ACCOUNT_ID IS NULL) THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_ERR_MSG := 'MSG_0015';				
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); 
    END IF;

     IF (P_AUTH_TP_ID IS NULL) THEN 
        P_RT_ROLLBACK_FLAG := 'false';
        P_ERR_MSG := 'MSG_5044' ;           
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);  
    END IF;

        -- 以묐났
    SELECT COUNT(*) INTO P_ERR_STATUS
      FROM TB_DP_USER_ACCOUNT_MAP
     WHERE 1=1
       AND CASE V_ACCT_YN WHEN 'Y' THEN ACCOUNT_ID ELSE SALES_LV_ID END = V_ACCOUNT_ID
       AND EMP_ID = V_EMP_ID
       AND ACTV_YN = V_ACTV_YN
       AND MAIN_LV_YN = P_MAIN_LV_YN;

    IF (P_ERR_STATUS != 0) THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_ERR_MSG := 'MSG_0013';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

	MERGE INTO TB_DP_USER_ACCOUNT_MAP TGT
	USING ( 
			SELECT  TO_SINGLE_BYTE(SYS_GUID())                            AS ID 
				   ,V_EMP_ID                                              AS  EMP_ID
			       ,p_AUTH_TP_ID                                          AS  AUTH_TP_ID
				   ,V_LV_MGMT_ID                                          AS  LV_MGMT_ID
                   ,CASE V_ACCT_YN WHEN 'N' THEN V_ACCOUNT_ID   END       AS  SALES_LV_ID
                   ,CASE V_ACCT_YN WHEN 'Y' THEN V_ACCOUNT_ID   END       AS  ACCOUNT_ID
				   ,V_ACTV_YN                                             AS  ACTV_YN
				   ,P_USER_ID                                             AS  USER_ID
                   ,P_MAIN_LV_YN    AS MAIN_LV_YN
		  FROM dual ) SRC
	ON      (TGT.EMP_ID = SRC.EMP_ID
    AND      TGT.AUTH_TP_ID = SRC.AUTH_TP_ID
    AND      TGT.LV_MGMT_ID = SRC.LV_MGMT_ID
    AND      COALESCE(TGT.SALES_LV_ID, ' ') = COALESCE(SRC.SALES_LV_ID, ' ')
    AND      COALESCE(TGT.ACCOUNT_ID , ' ') = COALESCE(SRC.ACCOUNT_ID, ' ')
            ) 
	WHEN MATCHED THEN
		 UPDATE 
		   SET   TGT.ACTV_YN     = SRC.ACTV_YN 
				,TGT.MODIFY_BY   = SRC.USER_ID       
				,TGT.MODIFY_DTTM = SYSDATE       
                ,TGT.MAIN_LV_YN  = SRC.MAIN_LV_YN
	WHEN NOT MATCHED THEN 
		 INSERT (
		            ID
				  , EMP_ID
				  , AUTH_TP_ID
				  , LV_MGMT_ID
				  , SALES_LV_ID
				  , ACCOUNT_ID
				  , ACTV_YN
                  , MAIN_LV_YN
				  , CREATE_BY
				  , CREATE_DTTM
				) 
		 VALUES (
		            SRC.ID 
				  , SRC.EMP_ID
				  , SRC.AUTH_TP_ID
				  , SRC.LV_MGMT_ID
				  , SRC.SALES_LV_ID
				  , SRC.ACCOUNT_ID
				  , 'Y' --SRC.ACTV_YN
                  , SRC.MAIN_LV_YN
				  , SRC.USER_ID 
				  , SYSDATE           
				) 
				;    	

/*-----------------------------------------------
  2021.04.07 源��슜�닔 異붽� 
-------------------------------------------------*/

  BEGIN

    -- 理쒖긽�쐞�쓽 ITEM LEVEL �젙蹂대�� 媛�吏�怨� �삷  
    SELECT ID, LV_MGMT_ID
      INTO V_ITEM_LV_ID, V_ITEM_MGMT_ID
      FROM TB_CM_ITEM_LEVEL_MGMT 
     WHERE PARENT_ITEM_LV_ID IS NULL AND ACTV_YN = 'Y'
    ;

    SELECT COUNT(*)
      INTO V_CNT
      FROM TB_DP_USER_ITEM_MAP
     WHERE EMP_ID     = V_EMP_ID
       AND AUTH_TP_ID = P_AUTH_TP_ID
    ;

    IF V_CNT = 0 THEN

        INSERT INTO TB_DP_USER_ITEM_MAP T
        (
          T.ID, T.AUTH_TP_ID, T.EMP_ID, T.LV_MGMT_ID, T.ITEM_LV_ID, T.ACTV_YN, T.CREATE_BY, T.CREATE_DTTM
        )
        SELECT   TO_SINGLE_BYTE(SYS_GUID()) NEW_ID, P_AUTH_TP_ID, V_EMP_ID, V_ITEM_MGMT_ID, V_ITEM_LV_ID, 'Y', P_USER_ID, SYSDATE
          FROM   DUAL        
        ;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

/*-----------------------------------------------
  源��슜�닔 異붽� END 
-------------------------------------------------*/



    -- OEM 蹂꾨줈 �떞�떦�옄媛� 臾댁“嫄� �븳紐낆� ���몴濡�.
/*    
        SELECT COUNT(EMP_ID) INTO P_ERR_STATUS  -- Main Level YN is Only 1 
         FROM TB_DP_USER_ACCOUNT_MAP
        WHERE CASE V_ACCT_YN WHEN 'Y' THEN ACCOUNT_ID ELSE SALES_LV_ID END = V_ACCOUNT_ID
          AND MAIN_LV_YN = 'Y'
        ;            
        IF (P_ERR_STATUS != 1)
            THEN
                P_RT_ROLLBACK_FLAG := 'false';
                P_ERR_MSG := 'Main Level YN is Only 1';
                RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);            
            END IF;
*/
    FOR CUR IN (
        SELECT VER_ID
          FROM (
            SELECT M.ID AS VER_ID
                 , DENSE_RANK () OVER (PARTITION BY M.PLAN_TP_ID ORDER BY M.CREATE_DTTM DESC) AS RW
              FROM TB_DP_CONTROL_BOARD_VER_MST M
             INNER JOIN TB_DP_CONTROL_BOARD_VER_DTL D
                ON M.ID = D.CONBD_VER_MST_ID 
             INNER JOIN TB_CM_COMM_CONFIG W
                ON W.ID = D.WORK_TP_ID
               AND W.CONF_CD = 'CL'
             INNER JOIN TB_CM_COMM_CONFIG C
                ON D.CL_STATUS_ID = C.ID
               AND C.CONF_CD != 'CLOSE'
             WHERE EXISTS (SELECT DISTINCT VER_ID FROM TB_DP_ENTRY WHERE VER_ID = M.ID)
          ) A
         WHERE RW = 1
    ) LOOP
        IF (V_ACCT_YN = 'N') THEN 
            V_ACCOUNT_ID := NULL;
        END IF;

        SP_UI_DP_93_ITEM_ACCT_CREATE(
            NULL
          , NULL
          , V_ACCOUNT_ID
          , V_ACCT_LV_ID
          , P_USER_ID 
          , P_AUTH_TP_ID
          , CUR.VER_ID
        );
    END LOOP;

    SP_UI_DP_00_MAKE_USER_GROUP ( V_EMP_ID  , P_EMP_NO, P_AUTH_TP_ID );
    SP_UI_DPD_MAKE_HIER_USER;

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';  
       /*============================================================================*/
EXCEPTION WHEN OTHERS THEN  --  e_products_invalid    
    IF(SQLCODE = -20001)
    THEN
        P_ERR_MSG := SQLERRM;
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
--        SP_COMM_RAISE_ERR();              
        RAISE;
    END IF;
END;

/

