create PROCEDURE "SP_UI_DP_17_SYS_YN_COMBO" 
(
 pRESULT       OUT SYS_REFCURSOR 
)
IS 


BEGIN

OPEN pRESULT          
FOR 
  SELECT	A.ID, A.CD_NM
  FROM	(
		SELECT  '' AS ID , 'ALL' AS CD_NM, 0 AS SEQ
        FROM dual
		UNION 
		SELECT	'Y' AS ID, 'Y' AS CD_NM, 1 AS SEQ
        FROM dual
		UNION  
		SELECT	'N' AS ID, 'N' AS CD_NM, 2 AS SEQ
        FROM dual
  ) A
  ORDER BY A.SEQ;

END;




/

