create PROCEDURE SP_UI_CM_03_S1(
         P_ITEM_SCOPE_MST_ID IN CHAR  :=''       
        ,P_ITEM_CLASS_VAL    IN VARCHAR2 :=''     
		,P_DESCRIP           IN VARCHAR2 := ''
		,P_CONTINU_PRDUCT_YN IN CHAR     := ''
		,P_PROD_MIX_YN       IN CHAR     := ''
		/*==========ID INS PARAMETER 20============*/
		,P_ATTR_01           IN CHAR     := ''
		,P_ATTR_02           IN CHAR     := ''
		,P_ATTR_03           IN CHAR     := ''
		,P_ATTR_04           IN CHAR     := ''
		,P_ATTR_05           IN CHAR     := ''
		,P_ATTR_06           IN CHAR     := ''
		,P_ATTR_07           IN CHAR     := ''
		,P_ATTR_08           IN CHAR     := ''
		,P_ATTR_09           IN CHAR     := ''
		,P_ATTR_10           IN CHAR     := ''
		,P_ATTR_11           IN CHAR     := ''
		,P_ATTR_12           IN CHAR     := ''
		,P_ATTR_13           IN CHAR     := ''
		,P_ATTR_14           IN CHAR     := ''
		,P_ATTR_15           IN CHAR     := ''
		,P_ATTR_16           IN CHAR     := ''
		,P_ATTR_17           IN CHAR     := ''
		,P_ATTR_18           IN CHAR     := ''
		,P_ATTR_19           IN CHAR     := ''
		,P_ATTR_20           IN CHAR     := ''
		/*=========================================*/
        ,P_ACTV_YN           IN CHAR     := ''
		,P_USER_ID           IN VARCHAR2 := ''
        ,P_RT_ROLLBACK_FLAG OUT VARCHAR2
        ,P_RT_MSG            OUT VARCHAR2
        )
IS
    P_ERR_STATUS            NUMBER :=0;
    P_ERR_MSG               VARCHAR2(4000) :='';
    P_ITEM_SCOPE_MST_ID_TEMP    CHAR(32) := LTRIM(RTRIM(P_ITEM_SCOPE_MST_ID));
    P_ITEM_CLASS_VAL_TEMP       VARCHAR2(100) := LTRIM(RTRIM(P_ITEM_CLASS_VAL));
    P_ITEM_CLASS_CNT			NUMBER :=0;	
    P_ITEM_CLASS_CNT_FOR_ATTR   NUMBER :=0; 
    P_ATTR_01_TEMP CHAR(32) := P_ATTR_01;
    P_ATTR_02_TEMP CHAR(32) := P_ATTR_02;
    P_ATTR_03_TEMP CHAR(32) := P_ATTR_03;
    P_ATTR_04_TEMP CHAR(32) := P_ATTR_04;
    P_ATTR_05_TEMP CHAR(32) := P_ATTR_05;
    P_ATTR_06_TEMP CHAR(32) := P_ATTR_06;
    P_ATTR_07_TEMP CHAR(32) := P_ATTR_07;
    P_ATTR_08_TEMP CHAR(32) := P_ATTR_08;
    P_ATTR_09_TEMP CHAR(32) := P_ATTR_09;
    P_ATTR_10_TEMP CHAR(32) := P_ATTR_10;
    P_ATTR_11_TEMP CHAR(32) := P_ATTR_11;
    P_ATTR_12_TEMP CHAR(32) := P_ATTR_12;
    P_ATTR_13_TEMP CHAR(32) := P_ATTR_13;
    P_ATTR_14_TEMP CHAR(32) := P_ATTR_14;
    P_ATTR_15_TEMP CHAR(32) := P_ATTR_15;
    P_ATTR_16_TEMP CHAR(32) := P_ATTR_16;
    P_ATTR_17_TEMP CHAR(32) := P_ATTR_17;
    P_ATTR_18_TEMP CHAR(32) := P_ATTR_18;
    P_ATTR_19_TEMP CHAR(32) := P_ATTR_19;
    P_ATTR_20_TEMP CHAR(32) := P_ATTR_20;


   BEGIN

            IF(LTRIM(RTRIM(P_ATTR_01)) = '') THEN P_ATTR_01_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_02)) = '') THEN P_ATTR_02_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_03)) = '') THEN P_ATTR_03_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_04)) = '') THEN P_ATTR_04_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_05)) = '') THEN P_ATTR_05_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_06)) = '') THEN P_ATTR_06_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_07)) = '') THEN P_ATTR_07_TEMP := NULL; END IF; 
            IF(LTRIM(RTRIM(P_ATTR_08)) = '') THEN P_ATTR_08_TEMP := NULL; END IF; 
            IF(LTRIM(RTRIM(P_ATTR_09)) = '') THEN P_ATTR_09_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_10)) = '') THEN P_ATTR_10_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_11)) = '') THEN P_ATTR_11_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_12)) = '') THEN P_ATTR_12_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_13)) = '') THEN P_ATTR_13_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_14)) = '') THEN P_ATTR_14_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_15)) = '') THEN P_ATTR_15_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_16)) = '') THEN P_ATTR_16_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_17)) = '') THEN P_ATTR_17_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_18)) = '') THEN P_ATTR_18_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_19)) = '') THEN P_ATTR_19_TEMP := NULL; END IF;
            IF(LTRIM(RTRIM(P_ATTR_20)) = '') THEN P_ATTR_20_TEMP := NULL; END IF;

MERGE INTO TB_CM_ITEM_CLASS_MST A
     USING (
            SELECT  
                    P_ITEM_SCOPE_MST_ID    AS ITEM_SCOPE_MST_ID
            	   ,P_ITEM_CLASS_VAL	   AS ITEM_CLASS_VAL
                   FROM DUAL
	       ) B
		ON (A.ITEM_SCOPE_MST_ID = P_ITEM_SCOPE_MST_ID_TEMP AND A.ITEM_CLASS_VAL = P_ITEM_CLASS_VAL_TEMP)
WHEN MATCHED THEN 
			UPDATE SET
				 DESCRIP				= P_DESCRIP
				,CONTINU_PRDUCT_YN		= P_CONTINU_PRDUCT_YN
				,PROD_MIX_YN			= P_PROD_MIX_YN
                ,ACTV_YN                = P_ACTV_YN
				,ATTR_01				= P_ATTR_01_TEMP			
				,ATTR_02				= P_ATTR_02_TEMP			
				,ATTR_03				= P_ATTR_03_TEMP			
				,ATTR_04				= P_ATTR_04_TEMP			
				,ATTR_05				= P_ATTR_05_TEMP			
				,ATTR_06				= P_ATTR_06_TEMP		
				,ATTR_07				= P_ATTR_07_TEMP			
				,ATTR_08				= P_ATTR_08_TEMP			
				,ATTR_09				= P_ATTR_09_TEMP			
				,ATTR_10				= P_ATTR_10_TEMP			
				,ATTR_11				= P_ATTR_11_TEMP			
				,ATTR_12				= P_ATTR_12_TEMP			
				,ATTR_13				= P_ATTR_13_TEMP			
				,ATTR_14				= P_ATTR_14_TEMP			
				,ATTR_15				= P_ATTR_15_TEMP			
				,ATTR_16				= P_ATTR_16_TEMP			
				,ATTR_17				= P_ATTR_17_TEMP			
				,ATTR_18				= P_ATTR_18_TEMP			
				,ATTR_19				= P_ATTR_19_TEMP			
				,ATTR_20				= P_ATTR_20_TEMP	
				,MODIFY_BY				= P_USER_ID
				,MODIFY_DTTM			= SYSDATE
WHEN NOT MATCHED THEN 
             INSERT (
                      ID
                     ,ITEM_SCOPE_MST_ID
                     ,ITEM_CLASS_VAL
                     ,DESCRIP
                     ,CONTINU_PRDUCT_YN
                     ,PROD_MIX_YN
                     ,ATTR_01
                     ,ATTR_02
                     ,ATTR_03
                     ,ATTR_04
                     ,ATTR_05
                     ,ATTR_06
                     ,ATTR_07
                     ,ATTR_08
                     ,ATTR_09
                     ,ATTR_10
                     ,ATTR_11
                     ,ATTR_12
                     ,ATTR_13
                     ,ATTR_14
                     ,ATTR_15
                     ,ATTR_16
                     ,ATTR_17
                     ,ATTR_18
                     ,ATTR_19
                     ,ATTR_20
                     ,ACTV_YN
                     ,CREATE_BY
                     ,CREATE_DTTM
			        )			
			 VALUES (
                      TO_SINGLE_BYTE(SYS_GUID())
                     ,P_ITEM_SCOPE_MST_ID 
                     ,P_ITEM_CLASS_VAL	 
                     ,P_DESCRIP			
                     ,P_CONTINU_PRDUCT_YN
                     ,P_PROD_MIX_YN
                     ,P_ATTR_01_TEMP			
                     ,P_ATTR_02_TEMP			
                     ,P_ATTR_03_TEMP			
                     ,P_ATTR_04_TEMP			
                     ,P_ATTR_05_TEMP			
                     ,P_ATTR_06_TEMP			
                     ,P_ATTR_07_TEMP			
                     ,P_ATTR_08_TEMP			
                     ,P_ATTR_09_TEMP			
                     ,P_ATTR_10_TEMP			
                     ,P_ATTR_11_TEMP			
                     ,P_ATTR_12_TEMP			
                     ,P_ATTR_13_TEMP			
                     ,P_ATTR_14_TEMP			
                     ,P_ATTR_15_TEMP			
                     ,P_ATTR_16_TEMP			
                     ,P_ATTR_17_TEMP			
                     ,P_ATTR_18_TEMP			
                     ,P_ATTR_19_TEMP			
                     ,P_ATTR_20_TEMP			
                     ,'Y'
                     ,P_USER_ID
                     ,SYSDATE
			        );
			SELECT COUNT(B.ITEM_CLASS_VAL) INTO P_ITEM_CLASS_CNT_FOR_ATTR
			FROM TB_CM_ITEM_CLASS_MST A 
				 INNER JOIN
				 TB_CM_ITEM_CLASS_MST B 
				 ON( NVL(A.ATTR_01,' ') = NVL(B.ATTR_01,' ')
				 AND NVL(A.ATTR_02,' ') = NVL(B.ATTR_02,' ')
				 AND NVL(A.ATTR_03,' ') = NVL(B.ATTR_03,' ')
				 AND NVL(A.ATTR_04,' ') = NVL(B.ATTR_04,' ')
				 AND NVL(A.ATTR_05,' ') = NVL(B.ATTR_05,' ')
				 AND NVL(A.ATTR_06,' ') = NVL(B.ATTR_06,' ')
				 AND NVL(A.ATTR_07,' ') = NVL(B.ATTR_07,' ')
				 AND NVL(A.ATTR_08,' ') = NVL(B.ATTR_08,' ')
				 AND NVL(A.ATTR_09,' ') = NVL(B.ATTR_09,' ')
				 AND NVL(A.ATTR_10,' ') = NVL(B.ATTR_10,' ')
				 AND NVL(A.ATTR_11,' ') = NVL(B.ATTR_11,' ')
				 AND NVL(A.ATTR_12,' ') = NVL(B.ATTR_12,' ')
				 AND NVL(A.ATTR_13,' ') = NVL(B.ATTR_13,' ')
				 AND NVL(A.ATTR_14,' ') = NVL(B.ATTR_14,' ')
				 AND NVL(A.ATTR_15,' ') = NVL(B.ATTR_15,' ')
				 AND NVL(A.ATTR_16,' ') = NVL(B.ATTR_16,' ')
				 AND NVL(A.ATTR_17,' ') = NVL(B.ATTR_17,' ')
				 AND NVL(A.ATTR_18,' ') = NVL(B.ATTR_18,' ')
				 AND NVL(A.ATTR_19,' ') = NVL(B.ATTR_19,' ')
				 AND NVL(A.ATTR_20,' ') = NVL(B.ATTR_20,' ')
				 )
         			AND A.ITEM_SCOPE_MST_ID = B.ITEM_SCOPE_MST_ID
		WHERE 1=1
			AND A.ITEM_CLASS_VAL    = P_ITEM_CLASS_VAL
			AND A.ITEM_SCOPE_MST_ID = P_ITEM_SCOPE_MST_ID;

	IF(P_ITEM_CLASS_CNT_FOR_ATTR > 1)
		THEN
			 P_RT_ROLLBACK_FLAG := 'false';
			 P_RT_MSG := 'MSG_5022'; 
	ELSE
            P_RT_ROLLBACK_FLAG := 'true';
			P_RT_MSG := 'MSG_0001';

        END IF;

    EXCEPTION
    WHEN OTHERS THEN
        IF(SQLCODE = -20012)
          THEN 
              P_RT_ROLLBACK_FLAG := 'false';
              P_RT_MSG := P_ERR_MSG;
          ELSE
              RAISE;
          END IF;
   END;

/

