create PROCEDURE SP_UI_CM_17_Q1 (
    P_Q_TYPE                  IN VARCHAR2 := '',
    P_MODULE_ID               IN CHAR := '',
    P_SNRIO_VER_ID            IN VARCHAR2 := '',
    PRESULT                   OUT SYS_REFCURSOR
)
IS
    P_MAX_VER_ID               VARCHAR2(50) := '';
    P_PLAN_SNRIO_MGMT_MST_ID   CHAR(32) := '';
    P_DMND_MODULE_ID           VARCHAR2(50) := '';
    P_DP_CONBD_VER_ID          VARCHAR2(50) := '';
    
BEGIN
    IF P_Q_TYPE = 'MAIN_INFO' THEN
        BEGIN
            SELECT MAX(A.MAIN_VER_ID) INTO P_MAX_VER_ID
              FROM TB_CM_CONBD_MAIN_VER_MST A,
                   TB_CM_PLAN_SNRIO_MGMT_MST B
             WHERE 1 = 1
               AND A.PLAN_SNRIO_MGMT_MST_ID = B.ID
               AND A.MODULE_ID = P_MODULE_ID
               AND 1 = CASE WHEN P_SNRIO_VER_ID IS NULL OR P_SNRIO_VER_ID = '' THEN 1
                            ELSE CASE WHEN B.SNRIO_VER_ID = P_SNRIO_VER_ID THEN 1
                       END END;
        EXCEPTION WHEN NO_DATA_FOUND
            THEN NULL;
        END;

        BEGIN
            SELECT B.COMN_CD INTO P_DMND_MODULE_ID
              FROM TB_CM_CONBD_MAIN_VER_MST C,
                   TB_CM_PLAN_SNRIO_MGMT_MST A
                    LEFT OUTER JOIN TB_AD_COMN_CODE B
                    ON A.DMND_MODULE_ID = B.ID
             WHERE 1 = 1
               AND C.PLAN_SNRIO_MGMT_MST_ID = A.ID
               AND C.MAIN_VER_ID = P_MAX_VER_ID
               AND C.MODULE_ID = P_MODULE_ID;
        EXCEPTION WHEN NO_DATA_FOUND
            THEN NULL;
        END;
        
        IF P_DMND_MODULE_ID = 'DP' THEN
            BEGIN
                SELECT X.VER_ID INTO P_DP_CONBD_VER_ID
                  FROM TB_CM_CONBD_MAIN_VER_MST A
                      ,TB_DP_CONTROL_BOARD_VER_MST X
                 WHERE 1=1
                   AND X.ID = A.DMND_VER_ID
                   AND A.MODULE_ID = P_MODULE_ID
                   AND A.MAIN_VER_ID = P_MAX_VER_ID;
            EXCEPTION WHEN NO_DATA_FOUND
                THEN NULL;
            END;
                
        ELSIF P_DMND_MODULE_ID = 'RP' THEN
            BEGIN        
                SELECT Y.SIMUL_VER_ID INTO P_DP_CONBD_VER_ID
                  FROM TB_CM_CONBD_MAIN_VER_MST A,
                       TB_CM_CONBD_MAIN_VER_DTL Y
                 WHERE 1=1
                   AND A.DMND_VER_ID = Y.ID
                   AND A.MODULE_ID = P_MODULE_ID
                   AND A.MAIN_VER_ID = P_MAX_VER_ID;
            EXCEPTION WHEN NO_DATA_FOUND
                THEN NULL;
            END;
        END IF;

        OPEN PRESULT FOR
        WITH TEMP_RST_DATA AS (
            SELECT 'ID' AS CONTROL_ITEM			,NULL AS VAL FROM DUAL UNION ALL
            SELECT 'MODULE_ID'					,NULL FROM DUAL UNION ALL
            SELECT 'MAIN_VER_ID'				,NULL FROM DUAL UNION ALL
            SELECT 'VER_DATE'					,NULL FROM DUAL UNION ALL
            SELECT 'DESCRIP'					,NULL FROM DUAL UNION ALL
            SELECT 'PLAN_HORIZ_STRT'			,NULL FROM DUAL UNION ALL
            SELECT 'PLAN_HORIZ_END'				,NULL FROM DUAL UNION ALL
            SELECT 'TIME_BUKT'					,NULL FROM DUAL UNION ALL
            SELECT 'DP_CONBD_VER'				,NULL FROM DUAL UNION ALL
            SELECT 'SRP_CONBD_VER'				,NULL FROM DUAL UNION ALL
            SELECT 'PLAN_SNRIO_MGMT_VER'		,NULL FROM DUAL UNION ALL
            SELECT 'PLAN_SNRIO_MGMT_MST_DESCP'	,NULL FROM DUAL
       )
       SELECT  NVL(B.CONTROL_ITEM, A.CONTROL_ITEM) AS CONTROL_ITEM
              ,NVL(B.VAL, A.VAL) AS VAL
         FROM TEMP_RST_DATA A
              LEFT OUTER JOIN 
              (
              SELECT  UNPVT.CONTROL_ITEM
                     ,TO_CHAR(UNPVT.VAL) AS VAL
                FROM (
                        SELECT
                            TO_CHAR(A.ID)                                       AS ID,
                            TO_CHAR(B.COMN_CD)                                  AS MODULE_ID,
                            TO_CHAR(A.MAIN_VER_ID)                              AS MAIN_VER_ID,
                            TO_CHAR(A.VER_DATE, 'YYYY-MM-DD HH24:MI:SS')        AS VER_DATE,
                            TO_CHAR(NVL(A.DESCRIP, ''))                         AS DESCRIP,
                            TO_CHAR(A.PLAN_HORIZ_STRT, 'YYYY-MM-DD HH24:MI:SS') AS PLAN_HORIZ_STRT,
                            TO_CHAR(A.PLAN_HORIZ_END, 'YYYY-MM-DD HH24:MI:SS')  AS PLAN_HORIZ_END,
                            TO_CHAR(A.TIME_BUKT)                                AS TIME_BUKT,
                            TO_CHAR(P_DP_CONBD_VER_ID)                          AS DP_CONBD_VER,
                            TO_CHAR((
                                SELECT X.VER_ID
                                  FROM TB_SRP_CNTRL_BOARD_VER_MST X
                                 WHERE X.ID = A.SRP_CONBD_VER_MST_ID
                            ))                                                  AS SRP_CONBD_VER,
                            TO_CHAR((
                                SELECT X.SNRIO_VER_ID
                                  FROM TB_CM_PLAN_SNRIO_MGMT_MST X
                                 WHERE X.ID = A.PLAN_SNRIO_MGMT_MST_ID
                            ))                                                  AS PLAN_SNRIO_MGMT_VER,
                            TO_CHAR(NVL(C.DESCRIP, ''))                         AS PLAN_SNRIO_MGMT_MST_DESCP
						FROM TB_CM_CONBD_MAIN_VER_MST A 
							 LEFT OUTER JOIN TB_AD_COMN_CODE B 
						  ON (A.MODULE_ID = B.ID)
							 LEFT OUTER JOIN TB_CM_PLAN_SNRIO_MGMT_MST C 
						  ON (A.PLAN_SNRIO_MGMT_MST_ID = C.ID)
					   WHERE 1=1
						 AND A.MODULE_ID = P_MODULE_ID
						 AND A.MAIN_VER_ID = P_MAX_VER_ID
                    ) A 
                    UNPIVOT ( 
                            VAL FOR CONTROL_ITEM IN ( 
                                                     ID,
                                                     MODULE_ID,
                                                     MAIN_VER_ID,
                                                     VER_DATE,
                                                     DESCRIP,
                                                     PLAN_HORIZ_STRT,
                                                     PLAN_HORIZ_END,
                                                     TIME_BUKT,
                                                     DP_CONBD_VER,
                                                     SRP_CONBD_VER,
                                                     PLAN_SNRIO_MGMT_VER,
                                                     PLAN_SNRIO_MGMT_MST_DESCP 
                                                    ) 
                            ) UNPVT
            ) B 
            ON (A.CONTROL_ITEM = B.CONTROL_ITEM);

    ELSIF P_Q_TYPE = 'MODULE' THEN
        OPEN PRESULT FOR
        SELECT  B.ID
               ,B.COMN_CD
          FROM  TB_AD_COMN_GRP A   
               ,TB_AD_COMN_CODE B  
         WHERE 1=1
           AND A.ID = B.SRC_ID
           AND A.GRP_CD = 'MODULE_TP'
           AND A.USE_YN = 'Y';
                
    ELSIF P_Q_TYPE = 'MAX_MAIN_VER' THEN
        OPEN PRESULT FOR
	    SELECT C.SNRIO_VER_ID, C.MAIN_VER_ID, C.DESCRIP 
	    FROM   (
               SELECT A.SNRIO_VER_ID,
                      ROW_NUMBER() OVER(PARTITION BY A.SNRIO_VER_ID ORDER BY B.MAIN_VER_ID DESC) AS ROW_INDEX,
                      B.MAIN_VER_ID,
                      A.DESCRIP,
                      A.ID	AS SNRIO_MGMT_MST_ID,
                      B.ID	AS CONBD_MAIN_VER_ID
                 FROM TB_CM_PLAN_SNRIO_MGMT_MST A,
                      TB_CM_CONBD_MAIN_VER_MST B
                WHERE 1 = 1
                  AND B.PLAN_SNRIO_MGMT_MST_ID = A.ID
                  AND A.ACTV_YN = 'Y'
                  AND A.MODULE_ID = P_MODULE_ID
               ) C
	   WHERE  ROW_INDEX = 1;
        
    ELSIF P_Q_TYPE = 'SNRIO_VER' THEN
        OPEN PRESULT FOR
        SELECT A.SNRIO_VER_ID
	          ,A.DESCRIP
	  	  	  ,A.ID
          FROM TB_CM_PLAN_SNRIO_MGMT_MST A
	     WHERE 1=1
		   AND A.ACTV_YN = 'Y'
		   AND A.MODULE_ID = P_MODULE_ID
        ORDER BY A.SNRIO_VER_ID;

    ELSIF P_Q_TYPE = 'STEP_INFO' THEN
        BEGIN
            SELECT MAX(A.MAIN_VER_ID) INTO P_MAX_VER_ID
              FROM TB_CM_CONBD_MAIN_VER_MST A
                  ,TB_CM_PLAN_SNRIO_MGMT_MST B
             WHERE 1=1
               AND A.PLAN_SNRIO_MGMT_MST_ID = B.ID
               AND A.MODULE_ID = P_MODULE_ID
               AND B.SNRIO_VER_ID = P_SNRIO_VER_ID;
        EXCEPTION WHEN NO_DATA_FOUND 
            THEN NULL;
        END;

        BEGIN
            SELECT A.PLAN_SNRIO_MGMT_MST_ID INTO P_PLAN_SNRIO_MGMT_MST_ID
              FROM TB_CM_CONBD_MAIN_VER_MST A 
             WHERE 1=1
               AND A.MODULE_ID = P_MODULE_ID
               AND A.MAIN_VER_ID = P_MAX_VER_ID;
        EXCEPTION WHEN NO_DATA_FOUND 
            THEN P_PLAN_SNRIO_MGMT_MST_ID := NULL;
        END;
        
        DELETE FROM TEMP_CONBD_STEP_HIST;
		INSERT INTO TEMP_CONBD_STEP_HIST
		(
			PLAN_SNRIO_MGMT_MST_ID
		   ,PLAN_SNRIO_MGMT_DTL_ID
		   ,STEP
		   ,PROCESS_TP_ID
		   ,SIMUL_VER_ID
		   ,CONFRM_YN
		   ,STRT_DTTM
		   ,END_DTTM
		   ,ELAPSED_TIME
		   ,STEP_STATUS_ID
		   ,STEP_STATUS_NM
		   ,EXE_STATUS_ID
		   ,EXE_STATUS_NM
		   ,CONBD_MAIN_VER_DTL_ID
		   ,CONBD_MAIN_VER_MST_ID
		   ,MODULE_CD
		   ,MAIN_VER_ID
		   ,MAIN_VER_DESCRIP
		   ,UI_ID_01
		   ,UI_ID_02
		   ,UI_ID_03
		   ,UI_ID_04
		   ,UI_ID_05
		)
		SELECT  A.PLAN_SNRIO_MGMT_MST_ID
			   ,B.PLAN_SNRIO_MGMT_DTL_ID
			   ,C.STEP
			   ,C.PROCESS_TP_ID
			   ,B.SIMUL_VER_ID
			   ,B.CONFRM_YN
			   ,B.STRT_DTTM
			   ,B.END_DTTM
			   ,B.ELAPSED_TIME
			   ,B.STEP_STATUS_ID
			   ,D.COMN_CD_NM AS STEP_STATUS_NM
			   ,B.EXE_STATUS_ID
			   ,E.COMN_CD_NM AS EXE_STATUS_NM
			   ,B.ID AS CONBD_MAIN_VER_DTL_ID
			   ,B.CONBD_MAIN_VER_MST_ID
			   ,F.COMN_CD MODULE_CD
			   ,A.MAIN_VER_ID
			   ,A.DESCRIP AS MAIN_VER_DESCRIP
			   ,C.UI_ID_01
			   ,C.UI_ID_02
			   ,C.UI_ID_03
			   ,C.UI_ID_04
			   ,C.UI_ID_05
		  FROM  TB_CM_CONBD_MAIN_VER_MST A
			   ,TB_CM_CONBD_MAIN_VER_DTL B
			   ,TB_CM_PLAN_SNRIO_MGMT_DTL C
			   ,TB_AD_COMN_CODE D
			   ,TB_AD_COMN_CODE E
			   ,TB_AD_COMN_CODE F
		 WHERE 1=1
		   AND A.MODULE_ID = P_MODULE_ID
		   AND A.MAIN_VER_ID = P_MAX_VER_ID
		   AND A.ID = B.CONBD_MAIN_VER_MST_ID
		   AND B.PLAN_SNRIO_MGMT_DTL_ID = C.ID
		   AND B.STEP_STATUS_ID = D.ID
		   AND B.EXE_STATUS_ID = E.ID
		   AND A.MODULE_ID = F.ID;

        DELETE FROM TEMP_PROCESS_STEP_INFO;
		INSERT INTO TEMP_PROCESS_STEP_INFO
		(
			PLAN_SNRIO_MGMT_MST_ID
		   ,PLAN_SNRIO_MGMT_DTL_ID
		   ,STEP
		   ,PROCESS_TP
		   ,PROCESS_TP_ID
		   ,PROCESS_DESCRIP
		   ,PROCESS_TP_NM
		   ,CONFRM_MTD_ID
		   ,CONFRM_MTD_NM
		   ,PLAN_POLICY_MGMT_ID
		   ,UI_ID
		   ,PROC_NM
		   ,SNRIO_VER_ID
		   ,SNRIO_VER_DESCRIP
		)
		SELECT  A.ID AS PLAN_SNRIO_MGMT_MST_ID
			   ,B.ID AS PLAN_SNRIO_MGMT_DTL_ID
			   ,B.STEP
			   ,C.COMN_CD
			   ,B.PROCESS_TP_ID
			   ,B.PROCESS_DESCRIP
			   ,C.COMN_CD_NM AS PROCESS_TP_NM
			   ,B.CONFRM_MTD_ID
			   ,(
				 SELECT X.COMN_CD_NM
				   FROM TB_AD_COMN_CODE X
				  WHERE 1=1
					AND X.ID = B.CONFRM_MTD_ID
				) AS CONFRM_MTD_NM
			   ,B.PLAN_POLICY_MGMT_ID
			   ,B.UI_ID
			   ,B.PROC AS PROC_NM
			   ,A.SNRIO_VER_ID
			   ,A.DESCRIP AS SNRIO_VER_DESCRIP
		  FROM  TB_CM_PLAN_SNRIO_MGMT_MST A
			   ,TB_CM_PLAN_SNRIO_MGMT_DTL B
			   ,TB_AD_COMN_CODE           C
		 WHERE 1=1
		   AND A.ID = B.PLAN_SNRIO_MGMT_MST_ID
		   AND A.ID = P_PLAN_SNRIO_MGMT_MST_ID
		   AND B.PROCESS_TP_ID = C.ID;

        DELETE FROM TEMP_PLAN_POLCY_INFO;
		INSERT INTO TEMP_PLAN_POLCY_INFO
		(
			PLAN_POLICY_MGMT_ID    
		   ,PLAN_POLICY_VER_ID		
		   ,PLAN_POLICY_VER_DESCRIP
		)
		SELECT  A.ID AS PLAN_POLICY_MGMT_ID
			   ,A.VER_ID AS PLAN_POLICY_VER_ID
			   ,B.PLAN_POLICY_VAL_01 AS PLAN_POLICY_VER_DESCRIP
		  FROM  TB_CM_PLAN_POLICY_MGMT A
			   ,TB_CM_PLAN_POLICY_VALUE B
			   ,TB_CM_PLAN_POLICY_MST C
		 WHERE 1=1
		   AND A.ID = B.PLAN_POLICY_MGMT_ID
		   AND B.PLAN_POLICY_MST_ID = C.ID
		   AND C.PLAN_POLICY_ITEM_ID = 'M00020000'
		   AND A.ACTV_YN = 'Y';

        DELETE FROM TEMP_CONBD_STEP_HIST_RST;
		INSERT INTO TEMP_CONBD_STEP_HIST_RST
		(
			PLAN_SNRIO_MGMT_MST_ID
		   ,PLAN_SNRIO_MGMT_DTL_ID
		   ,STEP                  
		   ,PROCESS_TP_ID         
		   ,SIMUL_VER_ID          
		   ,CONFRM_YN  
		   ,STRT_DTTM
		   ,END_DTTM
		   ,ELAPSED_TIME
		   ,STEP_STATUS_ID 
		   ,STEP_STATUS_NM        
		   ,EXE_STATUS_ID    
		   ,EXE_STATUS_NM  
		   ,SNRIO_CNT
		   ,MAX_SIMUL_VER_ID
		   ,CONFRM_SIMUL_VER_ID
		   ,CONBD_MAIN_VER_DTL_ID
		   ,CONBD_MAIN_VER_MST_ID
		   ,MODULE_CD
		   ,MAIN_VER_ID
		   ,MAIN_VER_DESCRIP
		   ,UI_ID_01
		   ,UI_ID_02
		   ,UI_ID_03
		   ,UI_ID_04
		   ,UI_ID_05
		)
		SELECT  A.PLAN_SNRIO_MGMT_MST_ID
			   ,A.PLAN_SNRIO_MGMT_DTL_ID
			   ,A.STEP                  
			   ,A.PROCESS_TP_ID         
			   ,A.SIMUL_VER_ID
			   ,A.CONFRM_YN  
			   ,A.STRT_DTTM
			   ,A.END_DTTM
			   ,A.ELAPSED_TIME
			   ,A.STEP_STATUS_ID 
			   ,A.STEP_STATUS_NM     
			   ,A.EXE_STATUS_ID    
			   ,A.EXE_STATUS_NM
			   ,A.SNRIO_CNT
			   ,A.SIMUL_VER_ID
			   ,B.CONFRM_SIMUL_VER_ID
			   ,A.CONBD_MAIN_VER_DTL_ID
			   ,A.CONBD_MAIN_VER_MST_ID
			   ,A.MODULE_CD
			   ,A.MAIN_VER_ID
			   ,A.MAIN_VER_DESCRIP
			   ,A.UI_ID_01
			   ,A.UI_ID_02
			   ,A.UI_ID_03
			   ,A.UI_ID_04
			   ,A.UI_ID_05
		  FROM (
				SELECT  A.PLAN_SNRIO_MGMT_MST_ID
					   ,A.PLAN_SNRIO_MGMT_DTL_ID
					   ,A.STEP
					   ,A.PROCESS_TP_ID
					   ,A.SIMUL_VER_ID
					   ,A.CONFRM_YN
					   ,A.STRT_DTTM
					   ,A.END_DTTM
					   ,A.ELAPSED_TIME
					   ,A.STEP_STATUS_ID
					   ,A.STEP_STATUS_NM
					   ,A.EXE_STATUS_ID
					   ,A.EXE_STATUS_NM
					   ,ROW_NUMBER() OVER (PARTITION BY A.PLAN_SNRIO_MGMT_MST_ID, A.PLAN_SNRIO_MGMT_DTL_ID ORDER BY A.SIMUL_VER_ID DESC) AS RN
					   ,COUNT(*) OVER (PARTITION BY A.PLAN_SNRIO_MGMT_MST_ID, A.PLAN_SNRIO_MGMT_DTL_ID) AS SNRIO_CNT
					   ,A.CONBD_MAIN_VER_DTL_ID
					   ,A.CONBD_MAIN_VER_MST_ID
					   ,A.MODULE_CD
					   ,A.MAIN_VER_ID
					   ,A.MAIN_VER_DESCRIP
					   ,A.UI_ID_01
					   ,A.UI_ID_02
					   ,A.UI_ID_03
					   ,A.UI_ID_04
					   ,A.UI_ID_05
				  FROM TEMP_CONBD_STEP_HIST A
			   ) A
			   LEFT OUTER JOIN 
			   (
				SELECT  A.PLAN_SNRIO_MGMT_MST_ID
					   ,A.PLAN_SNRIO_MGMT_DTL_ID
					   ,MAX(A.SIMUL_VER_ID) AS CONFRM_SIMUL_VER_ID
				  FROM TEMP_CONBD_STEP_HIST A
				 WHERE 1=1
				   AND A.CONFRM_YN = 'Y'
				 GROUP BY  A.PLAN_SNRIO_MGMT_MST_ID
						,A.PLAN_SNRIO_MGMT_DTL_ID
			   ) B
			   ON ( A.PLAN_SNRIO_MGMT_MST_ID = B.PLAN_SNRIO_MGMT_MST_ID
				AND A.PLAN_SNRIO_MGMT_DTL_ID = B.PLAN_SNRIO_MGMT_DTL_ID
			   )
         WHERE 1=1
           AND A.RN = 1;

        OPEN PRESULT FOR
		SELECT   A.PLAN_SNRIO_MGMT_MST_ID
				,A.PLAN_SNRIO_MGMT_DTL_ID
				,A.PROC_NM
				,A.STEP
				,A.PROCESS_TP_ID
				,A.PROCESS_TP
				,A.PROCESS_DESCRIP
				,A.PROCESS_TP_NM
				,A.CONFRM_MTD_ID
				,A.CONFRM_MTD_NM
				,B.PLAN_POLICY_MGMT_ID
				,B.PLAN_POLICY_VER_ID
				,B.PLAN_POLICY_VER_DESCRIP
				,C.EXE_STATUS_ID
				,C.EXE_STATUS_NM
				,A.UI_ID
				,C.STRT_DTTM
				,C.END_DTTM
				,C.ELAPSED_TIME AS ING_DTTM
				,C.STEP_STATUS_ID 
				,C.STEP_STATUS_NM
				,C.SNRIO_CNT
				,C.MAX_SIMUL_VER_ID
				,C.CONFRM_SIMUL_VER_ID
				,C.CONBD_MAIN_VER_DTL_ID
				,C.CONBD_MAIN_VER_MST_ID
				,C.UI_ID_01
				,C.UI_ID_02
				,C.UI_ID_03
				,C.UI_ID_04
				,C.UI_ID_05
				,D.UI_NM		AS UI_NM_01
				,D.URL			AS URL_01
				,E.UI_NM		AS UI_NM_02
				,E.URL			AS URL_02
				,F.UI_NM		AS UI_NM_03
				,F.URL			AS URL_03
				,G.UI_NM		AS UI_NM_04
				,G.URL			AS URL_04
				,H.UI_NM		AS UI_NM_05
				,H.URL			AS URL_05
			FROM TEMP_PROCESS_STEP_INFO A
				LEFT OUTER JOIN 
				TEMP_PLAN_POLCY_INFO B
			ON (A.PLAN_POLICY_MGMT_ID = B.PLAN_POLICY_MGMT_ID)
				LEFT OUTER JOIN
				TEMP_CONBD_STEP_HIST_RST C
			ON (A.PLAN_SNRIO_MGMT_MST_ID = C.PLAN_SNRIO_MGMT_MST_ID
				AND A.PLAN_SNRIO_MGMT_DTL_ID = C.PLAN_SNRIO_MGMT_DTL_ID)
				LEFT OUTER JOIN
				UI_MGMT D
			ON (C.UI_ID_01 = D.UI_ID)
				LEFT OUTER JOIN
				UI_MGMT E
			ON (C.UI_ID_02 = E.UI_ID)
				LEFT OUTER JOIN
				UI_MGMT F
			ON (C.UI_ID_03 = F.UI_ID)
				LEFT OUTER JOIN
				UI_MGMT G
			ON (C.UI_ID_04 = G.UI_ID)
				LEFT OUTER JOIN
				UI_MGMT H
			ON (C.UI_ID_05 = H.UI_ID)
		ORDER BY A.STEP;
        
    END IF;
    
END;

/

