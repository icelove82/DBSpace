create PROCEDURE SP_COMM_SRH_COMBO_LIST_Q (
    P_TYPE			IN VARCHAR2 :=''
    ,pResult OUT SYS_REFCURSOR
)
IS
BEGIN

	IF P_TYPE = 'ITEM_TP'
    THEN
        OPEN pResult FOR
        SELECT  'ALL'		AS ITEM_TP_ID
               , NULL       AS ITEM_TP_CD
               ,'ALL'		AS ITEM_TP_NM
          FROM DUAL
         WHERE P_TYPE = 'ITEM_TP' 
         UNION ALL
         SELECT  A.ID       AS ITEM_TP_ID
                ,A.ITEM_TP  AS ITEM_TP_CD
                ,A.CONVN_NM AS ITEM_TP_NM
           FROM TB_CM_ITEM_TYPE A
          WHERE 1=1
            AND A.ACTV_YN = 'Y';
	END IF;

	IF P_TYPE = 'PLAN_HORIZON'
    THEN
        OPEN pResult FOR
        SELECT STRT_DATE
             , END_DATE
          FROM TB_CM_HORIZON_TIME_BUCKET;
	END IF;

	IF P_TYPE = 'CHANNEL_TP'	
    THEN
        OPEN pResult FOR
        SELECT 'ALL'		AS CHANNEL_ID
              ,'ALL'		AS CHANNEL_NM
        FROM DUAL
         UNION ALL
        SELECT CHANNEL_ID
             , CHANNEL_NM
          FROM TB_CM_CHANNEL_TYPE;
	END IF;

	IF P_TYPE = 'INCOTERM'
    THEN
        OPEN pResult FOR
        SELECT 'ALL'		AS INCOTERMS_CD
              ,'ALL'		AS INCOTERMS_NM
          FROM DUAL
         UNION ALL
        SELECT INCOTERMS	AS INCOTERMS_CD
             , INCOTERMS	AS INCOTERMS_NM
          FROM TB_CM_INCOTERMS;
	END IF;

	IF P_TYPE ='WAREHOUSE_TP'
    THEN
        OPEN pResult FOR
        SELECT 'ALL'		    AS WAREHOUSE_TP
              ,'ALL'		    AS WAREHOUSE_TP_NM
          FROM DUAL
         UNION ALL
        SELECT DISTINCT 
               WAREHOUSE_TP		AS WAREHOUSE_TP
             , WAREHOUSE_TP_NM	AS WAREHOUSE_TP_NM
          FROM TB_CM_WAREHOUSE_TYPE;
	END IF;

	IF P_TYPE = 'MAINTENCE_APPCAT_TIME'
    THEN
        OPEN pResult FOR
        SELECT 'ALL'		AS CD
              ,'ALL'		AS CD_NM
        FROM DUAL
         UNION ALL
        SELECT B.COMN_CD		        AS CD
             , TO_CHAR(B.COMN_CD_NM)	AS CD_NM
          FROM TB_AD_COMN_GRP A
             , TB_AD_COMN_CODE B
         WHERE A.ID = B.SRC_ID
           AND GRP_CD ='MAINTENCE_APPCAT_CONST_TIME';
	END IF;

	IF P_TYPE = 'BOD_TP'
    THEN
        OPEN pResult FOR
        SELECT 'ALL'		AS CD
              ,'ALL'		AS CD_NM
          FROM DUAL
         UNION ALL
        SELECT B.COMN_CD		        AS CD
             , TO_CHAR(B.COMN_CD_NM)	AS CD_NM
          FROM TB_AD_COMN_GRP A
             , TB_AD_COMN_CODE B
         WHERE A.ID = B.SRC_ID
           AND GRP_CD ='BOD_TP';
	END IF;

	IF P_TYPE = 'VEHICL_TP'
    THEN
        OPEN pResult FOR
        SELECT 'ALL'		AS CD
              ,'ALL'		AS CD_NM
        FROM DUAL
         UNION ALL
        SELECT VEHICL_TP	AS CD
             , VEHICL_TP	AS CD_NM
          FROM TB_CM_VEHICLE;
	END IF;

	IF P_TYPE = 'BASE_ALLOC_RULE'
    THEN
        OPEN pResult FOR
        SELECT 'ALL'		AS CD
              ,'ALL'		AS CD_NM
          FROM DUAL
         UNION ALL
        SELECT B.ID				        AS CD
             , TO_CHAR(B.COMN_CD_NM)	AS CD_NM
          FROM TB_AD_COMN_GRP A
             , TB_AD_COMN_CODE B
         WHERE A.ID = B.SRC_ID
           AND GRP_CD ='BASE_ALLOC_RULE';
	END IF;

	IF P_TYPE = 'CYCL_TP'
    THEN
        OPEN pResult FOR
        SELECT 'ALL'		AS CD
              ,'ALL'		AS CD_NM
          FROM DUAL
         UNION ALL
        SELECT B.COMN_CD		        AS CD
             , TO_CHAR(B.COMN_CD_NM)	AS CD_NM
          FROM TB_AD_COMN_GRP A
             , TB_AD_COMN_CODE B
         WHERE A.ID = B.SRC_ID
           AND GRP_CD ='CALENDAR_CYCL_TP';			 
	END IF;
    
	IF P_TYPE ='SCENARIO_PROCESS_TP'
	THEN
        OPEN pResult FOR
        SELECT
             A.ID				AS ID
            ,A.COMN_CD_NM		AS CD_NM
            ,B.GRP_CD			AS "GROUP"
         FROM TB_AD_COMN_CODE A
                 INNER JOIN
                 TB_AD_COMN_GRP B
           ON (A.SRC_ID = B.ID)
        WHERE 1=1
         AND B.GRP_CD = P_TYPE;
	END IF;
    
	IF P_TYPE ='WAREHOUSE_STOCK_CUTOFF_DATE'
	THEN
        OPEN pResult FOR
        SELECT NVL(MAX(CUTOFF_DATE), SYSDATE) AS BASE_DATE
          FROM TB_CM_WAREHOUSE_STOCK_MST;
	END IF;
    
	IF P_TYPE ='INTANSIT_STOCK_CUTOFF_DATE'
	THEN
        OPEN pResult FOR
        SELECT NVL(MAX(CUTOFF_DATE), SYSDATE) AS BASE_DATE
          FROM TB_CM_INTRANSIT_STOCK_MST;
	END IF;
    
	IF P_TYPE ='MAT_SUPPLY_CAL_CUTOFF_DATE'
	THEN
        OPEN pResult FOR
        SELECT NVL(MAX(CUTOFF_DATE), SYSDATE) AS BASE_DATE
          FROM TB_MP_MAT_SUPPLY_CALENDAR;
	END IF;
END;

/

