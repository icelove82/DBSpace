create PROCEDURE "SP_UI_DP_19_MEASURE_TP_COMBO" (
     pRESULT OUT SYS_REFCURSOR
)
IS 


BEGIN 

    OPEN pRESULT 
    FOR 
    SELECT A.MEASURE_TP_ID AS MEASURE_CONF_TP_ID
         , A.MEASURE_TP_CD
         , A.MEASURE_TP_NM
         , A.MEASURE_CD_ID AS MEASURE_CD
         , A.MEASURE_CD_CD
--         , A.MEASURE_CD_NM
         , A.MEASURE_VAL_TP_ID
         , A.MEASURE_VAL_TP_NM
         , A.MEASURE_VER_TP_ID AS VER_APPY_BASE_ID
         , A.MEASURE_VER_TP_NM
      FROM (
        SELECT GRP_1.ID         AS MEASURE_TP_ID
             , GRP_1.CONF_CD    AS MEASURE_TP_CD
             , GRP_1.CONF_NM    AS MEASURE_TP_NM
             , LV.ID            AS MEASURE_CD_ID
             , LV.LV_CD         AS MEASURE_CD_CD
             , LV.LV_NM         AS MEASURE_CD_NM    
             , GRP_3.ID         AS MEASURE_VAL_TP_ID
    --          ,LANG_3.LANG_VALUE    AS MEASURE_VAL_TP_NM                
             , GRP_3.CONF_NM    AS MEASURE_VAL_TP_NM
             , GRP_4.ID         AS MEASURE_VER_TP_ID
    --          ,LANG_4.LANG_VALUE    AS MEASURE_VER_TP_NM                
             , GRP_4.CONF_NM    AS MEASURE_VER_TP_NM
          FROM TB_CM_CONFIGURATION CON 
               INNER JOIN TB_CM_COMM_CONFIG GRP_1  ON CON.ID = GRP_1.CONF_ID AND CON.CONF_NM = GRP_1.CONF_GRP_CD
               INNER JOIN TB_CM_COMM_CONFIG GRP_2  ON 1=1
               INNER JOIN TB_CM_COMM_CONFIG GRP_3  ON 1=1    
               INNER JOIN TB_CM_COMM_CONFIG GRP_4  ON 1=1    
               INNER JOIN TB_CM_LEVEL_MGMT LV      ON GRP_2.ID = LV.LV_TP_ID                 
    --                LEFT OUTER JOIN LANG_PACK LANG_3 ON LANG_3.LANG_KEY = GRP_3.CONF_NM AND LANG_3.LOCALE = 'en'
    --                LEFT OUTER JOIN LANG_PACK LANG_4 ON LANG_4.LANG_KEY = GRP_4.CONF_NM AND LANG_4.LOCALE = 'en'                
         WHERE CON.MODULE_CD        = 'DP'
           AND GRP_1.CONF_GRP_CD    = 'DP_MS_INPUT_TP'
           AND GRP_1.ACTV_YN        = 'Y'
           AND GRP_1.CONF_CD        = 'DEMAND'
           AND GRP_2.CONF_GRP_CD    = 'DP_LV_TP'
           AND GRP_2.CONF_CD        = 'S'
           AND GRP_3.CONF_GRP_CD    = 'DP_MS_VAL_TP'
           AND GRP_3.ACTV_YN        = 'Y'
           AND GRP_4.CONF_GRP_CD    = 'DP_MS_VER_TP'
           AND GRP_4.ACTV_YN        = 'Y'
           AND LV.ACTV_YN           = 'Y'
           AND COALESCE(LV.DEL_YN,'N') = 'N'
           AND LV.SALES_LV_YN       = 'Y'
        UNION ALL 
        SELECT GRP_1.ID             AS MEASURE_TP_ID
             , GRP_1.CONF_CD        AS MEASURE_TP_CD
             , GRP_1.CONF_NM        AS MEASURE_TP_NM
             , MM.ID                AS MEASURE_CD_ID
             , MM.MEASURE_CD        AS MEASURE_CD_CD
             , MM.MEASURE_NM        AS MEASURE_CD_NM     
             , MM.MEASURE_VAL_TP_ID AS MEASURE_VAL_TP_ID    
--                  ,LANG_2.LANG_VALUE    AS MEASURE_VAL_TP_NM
             , GRP_2.CONF_NM        AS MEASURE_VAL_TP_NM
             , GRP_3.ID             AS MEASURE_VER_TP_ID
--                  ,LANG_3.LANG_VALUE    AS MEASURE_VER_TP_NM                    
             , GRP_3.CONF_NM        AS MEASURE_VER_TP_NM
          FROM TB_CM_CONFIGURATION CON  
               INNER JOIN TB_CM_COMM_CONFIG GRP_1    ON CON.ID = GRP_1.CONF_ID AND CON.CONF_NM = GRP_1.CONF_GRP_CD
               INNER JOIN TB_DP_MEASURE_MST MM       ON 1=1 
               INNER JOIN TB_CM_COMM_CONFIG GRP_2    ON MM.MEASURE_VAL_TP_ID = GRP_2.ID
               INNER JOIN TB_CM_COMM_CONFIG GRP_3    ON 1=1
--                    LEFT OUTER JOIN LANG_PACK LANG_2 ON LANG_2.LANG_KEY = GRP_2.CONF_NM AND LANG_2.LOCALE = 'en'
--                    LEFT OUTER JOIN LANG_PACK LANG_3 ON LANG_3.LANG_KEY = GRP_3.CONF_NM AND LANG_3.LOCALE = 'en'                
         WHERE CON.MODULE_CD        = 'DP'
           AND GRP_1.CONF_GRP_CD    = 'DP_MS_INPUT_TP'
           AND GRP_1.ACTV_YN        = 'Y'
           AND GRP_1.CONF_CD        = 'ADDITION'
           AND GRP_2.CONF_GRP_CD    = 'DP_MS_VAL_TP'
           AND GRP_2.ACTV_YN        = 'Y'
           AND GRP_3.CONF_GRP_CD    = 'DP_MS_VER_TP'
           AND GRP_3.ACTV_YN        = 'Y'
           AND GRP_3.CONF_CD        = 'NN'
           AND NVL(MM.DEL_YN,'N')      = 'N'
           AND MM.DP_YN = 'Y'
    ) A;


END;

/

