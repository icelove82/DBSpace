create PROCEDURE SP_UI_CM_15_S4(
    P_PP_ID IN CHAR := NULL
   ,P_CON_ID IN VARCHAR2 := NULL
   ,P_ID IN CHAR := NULL
   ,P_USER_ID IN VARCHAR2 := NULL
)IS
    P_PP_VALUE_ID CHAR(32):= NULL;
    BEGIN
       SELECT A.ID INTO P_PP_VALUE_ID
       FROM TB_CM_PLAN_POLICY_VALUE A
           ,(SELECT X.ID AS P_P_MGMT_ID,
                    Z.ID AS P_P_MST_ID
                FROM
                    TB_CM_PLAN_POLICY_MGMT X,
                    TB_CM_PLAN_POLICY_MST Z
                WHERE 1 = 1
                AND X.ID = P_PP_ID
                AND Z.PLAN_POLICY_ITEM_ID =
                    CASE
                        WHEN P_CON_ID = 'PP_CON_03'  THEN 'M00200000'
                        WHEN P_CON_ID = 'PP_CON_04'  THEN 'M00220000'
                        ELSE NULL END)B
            WHERE A.PLAN_POLICY_MGMT_ID = B.P_P_MGMT_ID
            AND A.PLAN_POLICY_MST_ID = B.P_P_MST_ID;
        UPDATE TB_CM_PLAN_POLICY_VALUE
        SET PLAN_POLICY_VAL_01 = NULL
           ,PLAN_POLICY_VAL_02 = NULL
           ,PLAN_POLICY_VAL_06 = NULL
           ,MODIFY_BY = P_USER_ID
           ,MODIFY_DTTM = SYSDATE
        WHERE ID = P_PP_VALUE_ID;

        UPDATE TB_CM_GRID_VALUE
        SET 
            ACTV_YN = 'N'
           ,MODIFY_BY = P_USER_ID
           ,MODIFY_DTTM = SYSDATE
        WHERE ID = P_ID;

    END;

/

