create PROCEDURE                SP_UI_DP_07_Q1 (
    p_GB                  IN VARCHAR2   := ''
  , p_VER_ID              IN VARCHAR2   := ''
  , p_FROM_DATE           IN DATE       := NULL
  , p_TO_DATE             IN DATE       := NULL
  , p_FROM_CURCY_CD_ID    IN VARCHAR2   := '' 
  , p_TO_CURCY_CD_ID      IN VARCHAR2   := '' 
  , p_CURCY_TP_ID         IN VARCHAR2   := ''
  , pRESULT               OUT SYS_REFCURSOR
) IS 

/*  
    - History ( date / writer / comment )
    - 2021.01.20 / Kim sohee / add Currency code name
*/
BEGIN

      --,CONVERT(DATETIME, SA.STRT_DATE_AUTH,112)  AS STRT_DATE_AUTH
    IF (p_GB = 'DATE') THEN
        OPEN pRESULT         
        FOR
        SELECT A.VER_ID, A.FROM_DATE, A."TO_DATE", A.SEQ
          FROM ( 
            SELECT '' AS VER_ID 
                 , TRUNC(SYSDATE, 'MM')         AS FROM_DATE
                 , LAST_DAY(TRUNC (SYSDATE))    AS "TO_DATE"  
                 , 0 AS SEQ
              FROM dual
             WHERE rownum <= 1
             UNION ALL 
            SELECT VER_ID 
                 , TO_DATE(FROM_DATE,'YYYY-mm-dd hh:ss')    AS FROM_DATE
                 , TO_DATE("TO_DATE",'YYYY-mm-dd hh:ss')    AS "TO_DATE" 
                 , 1 AS SEQ 
              FROM TB_DP_CONTROL_BOARD_VER_MST 
             WHERE rownum <= 1 
             ORDER BY VER_ID DESC
          ) A
         ORDER BY SEQ DESC;
	ELSE 
        OPEN pRESULT          
        FOR 
        SELECT ER.ID
             , ER.FROM_CURCY_CD_ID
             , CD.COMN_CD               AS FROM_CURCY_CD
             , CD.COMN_CD_NM            AS FROM_CURCY_NM
             , ER.TO_CURCY_CD_ID 
             , ER.CURCY_TP_ID
             , CTP.CONF_CD              AS CURCY_TP_CD
             , CD2.COMN_CD              AS TO_CURCY_CD
             , CD2.COMN_CD_NM           AS TO_CURCY_NM
             , ER.BASE_DATE             AS BASE_DATE
             , ER.EXCHANGE_RATE
             , ER.UNIT_UOM_VAL
             , p_FROM_DATE              AS FROM_DATE 
             , p_TO_DATE                AS "TO_DATE"
          FROM TB_AD_COMN_GRP CM
             , TB_AD_COMN_CODE CD 
             , TB_AD_COMN_GRP CM2
             , TB_AD_COMN_CODE CD2 
             , TB_CM_COMM_CONFIG CTP
             , TB_DP_EXCHANGE_RATE ER 
          WHERE  CM.ID = CD.SRC_ID 
            AND  CM.GRP_CD = 'CURRENCY'  
            AND  CD.ID = ER.FROM_CURCY_CD_ID
            AND  CM2.ID = CD2.SRC_ID 
            AND  CM2.GRP_CD = 'CURRENCY'  
            AND  CD2.ID = ER.TO_CURCY_CD_ID
            AND  CTP.id = er.CURCY_TP_ID
            AND  EXISTS 
                ( 
                 SELECT ID 
                  FROM ( 
                      SELECT ID, ROW_NUMBER () OVER(PARTITION BY ER.FROM_CURCY_CD_ID, ER.TO_CURCY_CD_ID, ER.CURCY_TP_ID ORDER BY BASE_DATE DESC) ROW_NUM
                        FROM TB_DP_EXCHANGE_RATE ER 
                       WHERE ER.BASE_DATE <=  p_FROM_DATE         
                         AND ER.FROM_CURCY_CD_ID LIKE  '%' || LTRIM(RTRIM(p_FROM_CURCY_CD_ID)) || '%'
                         AND ER.TO_CURCY_CD_ID LIKE  '%' || LTRIM(RTRIM(p_TO_CURCY_CD_ID)) || '%'   
                         AND ER.CURCY_TP_ID LIKE '%'||LTRIM(RTRIM(P_CURCY_TP_ID))||'%' 
                        ) A 
                  WHERE A.ROW_NUM = 1 
                    AND A.ID = ER.ID 
                 ) 
        UNION  
		SELECT ER.ID
			 , ER.FROM_CURCY_CD_ID
			 , CD.COMN_CD AS FROM_CURCY_CD
             , CD.COMN_CD_NM            AS FROM_CURCY_NM
			 , ER.TO_CURCY_CD_ID
             , ER.CURCY_TP_ID
             , CTP.CONF_CD as CURCY_TP_CD            
			 , CD2.COMN_CD AS TO_CURCY_CD
             , CD2.COMN_CD_NM            AS TO_CURCY_NM
			 , ER.BASE_DATE  AS BASE_DATE
			 , ER.EXCHANGE_RATE
			 , ER.UNIT_UOM_VAL
			 , p_FROM_DATE AS FROM_DATE 
			 , p_TO_DATE AS "TO_DATE"
		  FROM TB_AD_COMN_GRP CM
			 , TB_AD_COMN_CODE CD 
			 , TB_AD_COMN_GRP CM2
			 , TB_AD_COMN_CODE CD2 
             , TB_CM_COMM_CONFIG CTP
		     , TB_DP_EXCHANGE_RATE ER 
		 WHERE CM.ID = CD.SRC_ID 
		   AND CM.GRP_CD = 'CURRENCY'  
		   AND CD.ID = ER.FROM_CURCY_CD_ID
           AND CM2.ID = CD2.SRC_ID 
		   AND CM2.GRP_CD = 'CURRENCY'  
		   AND CD2.ID = ER.TO_CURCY_CD_ID
           AND CTP.id = ER.CURCY_TP_ID
		   AND ER.FROM_CURCY_CD_ID LIKE  '%' || LTRIM(RTRIM(p_FROM_CURCY_CD_ID)) || '%'
		   AND ER.TO_CURCY_CD_ID LIKE  '%' || LTRIM(RTRIM(p_TO_CURCY_CD_ID)) || '%'   
		   AND ER.CURCY_TP_ID LIKE '%' || LTRIM(RTRIM(P_CURCY_TP_ID)) || '%'
           AND (P_FROM_DATE != P_TO_DATE) 
        ;
    END IF;
END;
/

