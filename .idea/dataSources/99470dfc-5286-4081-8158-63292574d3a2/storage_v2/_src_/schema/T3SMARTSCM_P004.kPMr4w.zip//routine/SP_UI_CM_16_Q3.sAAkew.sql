create PROCEDURE "SP_UI_CM_16_Q3" (
  		P_MST_ID		IN VARCHAR2 := '' ,
        pResult OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN pResult FOR 
        SELECT  A.ID 															  AS MST_ID
		       ,B.ID  									 						  AS DTL_ID
			   ,B.STEP															  AS STEP				
			   ,B.PROCESS_DESCRIP												  AS PROCESS_DESCRIP	
			   ,B.PROCESS_TP_ID													  AS PROCESS_TP_ID		
			   ,C.COMN_CD_NM               										  AS PROCESS_TP_NM
			   ,B.CONFRM_MTD_ID													  AS CONFRM_MTD_ID	
			   ,E.COMN_CD_NM                  									  AS CONFRM_MTD_NM
			   ,B.LOWR_DMND_CREATE_YN											  AS LOWR_DMND_CREATE_YN				
			   ,B.UI_ID															  AS UI_ID								
			   ,B."PROC"													      AS PROC_NM							
			   ,B.CONFRM_PLAN_SNRIO_MGMT_DTL_ID									  AS CONFRM_PLAN_SNRIO_MGMT_DTL_ID		
			   ,F.STEP									                          AS CONFRM_PLAN_SNRIO_STEP
			   ,F.PROCESS_DESCRIP 							                      AS CONFRM_PLAN_SNRIO_PROCESS
			   ,B.PLAN_POLICY_MGMT_ID											  AS PLAN_POLICY_MGMT_ID
			   ,G.VER_ID 									                      AS PLAN_POLICY_MGMT_VER
			   ,G.PLAN_POLICY_VAL_01 						                      AS PLAN_POLICY_MGMT_DESC
			   ,B.ACTV_YN														  AS ACTV_YN		
			   ,B.CREATE_BY														  AS CREATE_BY		
			   ,B.CREATE_DTTM							                      	  AS CREATE_DTTM	
			   ,B.MODIFY_BY											 			  AS MODIFY_BY		
			   ,B.MODIFY_DTTM													  AS MODIFY_DTTM
  FROM TB_CM_PLAN_SNRIO_MGMT_MST A
       INNER JOIN 
       TB_CM_PLAN_SNRIO_MGMT_DTL B 
    ON (A.ID = B.PLAN_SNRIO_MGMT_MST_ID)
       LEFT OUTER JOIN 
       TB_AD_COMN_CODE C 
    ON (B.PROCESS_TP_ID = C.ID)
       LEFT OUTER JOIN 
       TB_AD_COMN_CODE E
    ON (B.CONFRM_MTD_ID = E.ID)       
       LEFT OUTER JOIN 
       TB_CM_PLAN_SNRIO_MGMT_DTL F
    ON (B.CONFRM_PLAN_SNRIO_MGMT_DTL_ID = F.ID) 
       LEFT OUTER JOIN 
       (
	    SELECT  X.ID
	           ,Y.PLAN_POLICY_VAL_01
	           ,X.VER_ID
		  FROM TB_CM_PLAN_POLICY_MGMT X  	  
		       INNER JOIN 
		       TB_CM_PLAN_POLICY_VALUE Y
            ON (X.ID = Y.PLAN_POLICY_MGMT_ID)
               INNER JOIN TB_CM_PLAN_POLICY_MST Z   			  
            ON (Y.PLAN_POLICY_MST_ID = Z.ID)	
		  WHERE 1=1																  						  								  
			AND Z.PLAN_POLICY_ITEM_ID = 'M00020000'	
       ) G 
    ON (B.PLAN_POLICY_MGMT_ID= G.ID) 
 WHERE 1=1    
   AND A.ID = P_MST_ID
ORDER BY B.STEP;

/*      SELECT  A.ID                                                                AS MST_ID
       ,B.ID                                                                      AS DTL_ID
	   ,A.MODULE_ID                                                               AS MODULE_ID
	   ,(
	     SELECT X.COMN_CD_NM
		   FROM TB_AD_COMN_CODE X 
		  WHERE 1=1
		    AND X.ID = A.MODULE_ID
	    )                                                                         AS MODULE_NM
	   ,(
	     SELECT X.SEQ
		   FROM TB_AD_COMN_CODE X 
		  WHERE 1=1
		    AND X.ID = A.MODULE_ID
	    )                                                                         AS MODULE_SEQ
	   ,A.SNRIO_VER_ID                                                            AS SNRIO_VER_ID
	   ,A.DESCRIP																  AS DESCRIP
	   ,A.AUTO_REGIST_YN														  AS AUTO_REGIST_YN
	   ,A.CYCL_TP_ID															  AS CYCL_TP_ID
	   ,(																		  
	     SELECT  X.COMN_CD_NM													  
		   FROM TB_AD_COMN_CODE X					  
		  WHERE 1=1																  
		    AND X.ID = A.CYCL_TP_ID												  
	    )           															  AS CYCL_TP_NM
	   ,A.ACTV_YN																  AS SCENARIO_ACTV_YN			
	   ,B.STEP																	  AS STEP				
	   ,B.PROCESS_DESCRIP														  AS PROCESS_DESCRIP	
	   ,B.PROCESS_TP_ID															  AS PROCESS_TP_ID		
	   ,(																		 
	     SELECT  X.COMN_CD_NM													 
		   FROM TB_AD_COMN_CODE X						 
		  WHERE 1=1																 
		    AND X.ID = B.PROCESS_TP_ID											 
	    )               														  AS PROCESS_TP_NM
	   ,B.IM_SNRIO_PLAN_TP_ID                                                     AS IM_SNRIO_PLAN_TP_ID
	   ,(																		 
	     SELECT  X.COMN_CD_NM													 
		   FROM TB_AD_COMN_CODE X						 
		  WHERE 1=1																 
		    AND X.ID = B.IM_SNRIO_PLAN_TP_ID											 
	    )               														  AS IM_SNRIO_PLAN_TP_NM
	   ,B.AUTO_EXE_YN															  AS AUTO_EXE_YN		
	   ,B.EXE_TIME																  AS EXE_TIME			
	   ,B.CONFRM_MTD_ID														  AS CONFRM_MTD_ID	
	   ,(																		  
	     SELECT  X.COMN_CD_NM													  
		   FROM TB_AD_COMN_CODE X						  
		  WHERE 1=1																  
		    AND X.ID = B.CONFRM_MTD_ID										  
	    )                   													  AS CONFRM_MTD_NM
	   ,B.LOWR_DMND_CREATE_YN													  AS LOWR_DMND_CREATE_YN				
	   ,B.UI_ID																	  AS UI_ID								
	   ,B.PROC																      AS PROC_NM							
	   ,B.CONFRM_PLAN_SNRIO_MGMT_DTL_ID											  AS CONFRM_PLAN_SNRIO_MGMT_DTL_ID		
	   ,(																		  
	     SELECT  X.STEP															  
		   FROM TB_CM_PLAN_SNRIO_MGMT_DTL X 		  
		  WHERE 1=1																  
		    AND X.ID = B.CONFRM_PLAN_SNRIO_MGMT_DTL_ID							  
	    ) 									                                      AS CONFRM_PLAN_SNRIO_STEP
	   ,(																		  
	     SELECT  X.PROCESS_DESCRIP												  
		   FROM TB_CM_PLAN_SNRIO_MGMT_DTL X 			  
		  WHERE 1=1																  
		    AND X.ID = B.CONFRM_PLAN_SNRIO_MGMT_DTL_ID							  
	    ) 									                                      AS CONFRM_PLAN_SNRIO_PROCESS
	   ,B.PLAN_POLICY_MGMT_ID													  AS PLAN_POLICY_MGMT_ID
	   ,(																		  
	     SELECT  X.VER_ID														  
		   FROM TB_CM_PLAN_POLICY_MGMT X 				  
		  WHERE 1=1																  
		    AND X.ID = B.PLAN_POLICY_MGMT_ID									  
	    ) 									                                      AS PLAN_POLICY_MGMT_VER
	   ,(																		  
	     SELECT  Y.PLAN_POLICY_VAL_01											  
		   FROM  TB_CM_PLAN_POLICY_MGMT X  	  
		     INNER JOIN TB_CM_PLAN_POLICY_VALUE Y
               ON X.ID = Y.PLAN_POLICY_MGMT_ID
             INNER JOIN TB_CM_PLAN_POLICY_MST Z   			  
               ON Y.PLAN_POLICY_MST_ID = Z.ID	
		  WHERE 1=1																  
		    AND X.ID = B.PLAN_POLICY_MGMT_ID									  								  
			AND Z.PLAN_POLICY_ITEM_ID = 'M00020000'								  
	    ) 									                                      AS PLAN_POLICY_MGMT_DESC
	   ,B.ACTV_YN																  AS ACTV_YN		
	   ,B.CREATE_BY																  AS CREATE_BY		
	   ,B.CREATE_DTTM							                            	  AS CREATE_DTTM	
	   ,B.MODIFY_BY																  AS MODIFY_BY		
	   ,B.MODIFY_DTTM															  AS  MODIFY_DTTM
  FROM  TB_CM_PLAN_SNRIO_MGMT_MST A
        LEFT OUTER JOIN 
       TB_CM_PLAN_SNRIO_MGMT_DTL B 
  ON ( A.ID = B.PLAN_SNRIO_MGMT_MST_ID)
WHERE A.MODULE_ID LIKE '%'||P_MODULE_ID||'%'
ORDER BY 5, A.SNRIO_VER_ID DESC, b.STEP;*/



END;

/

