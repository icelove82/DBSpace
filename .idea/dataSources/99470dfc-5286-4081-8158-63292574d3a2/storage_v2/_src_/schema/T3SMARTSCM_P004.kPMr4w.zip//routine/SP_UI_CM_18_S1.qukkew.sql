create PROCEDURE SP_UI_CM_18_S1 (
     p_ID                 IN VARCHAR2     := ''         
    ,p_ITEM_CD            IN VARCHAR      := ''         
    ,p_ITEM_NM            IN VARCHAR      := ''         
    ,p_UOM_ID             IN VARCHAR2     := ''      
    ,p_ITEM_TP_ID         IN VARCHAR2     := ''   
    ,P_MIN_ORDER_SIZE     IN INT          := NULL
    ,P_MAX_ORDER_SIZE     IN INT          := NULL
    ,p_DESCRIP            IN VARCHAR2     := ''      
    ,p_DP_PLAN_YN         IN CHAR            := ''      
    ,p_PARENT_ITEM_LV_ID  IN VARCHAR2     := ''      
    ,p_RTS                IN DATE         := NULL
    ,p_EOS                IN DATE         := NULL 
    ,p_DEL_YN             IN CHAR         := ''   
    ,p_ATTR_01            IN VARCHAR2     := '' 
    ,p_ATTR_02            IN  VARCHAR2    := ''
    ,p_ATTR_03            IN  VARCHAR2    := ''
    ,p_ATTR_04            IN  VARCHAR2    := ''
    ,p_ATTR_05            IN  VARCHAR2    := ''
    ,p_ATTR_06            IN  VARCHAR2    := ''
    ,p_ATTR_07            IN  VARCHAR2    := ''
    ,p_ATTR_08            IN  VARCHAR2    := ''
    ,p_ATTR_09            IN  VARCHAR2    := ''
    ,p_ATTR_10            IN  VARCHAR2    := ''
    ,p_ATTR_11            IN  VARCHAR2    := ''
    ,p_ATTR_12            IN  VARCHAR2    := ''
    ,p_ATTR_13            IN  VARCHAR2    := ''
    ,p_ATTR_14            IN  VARCHAR2    := ''
    ,p_ATTR_15            IN  VARCHAR2    := ''
    ,p_ATTR_16            IN  VARCHAR2    := ''
    ,p_ATTR_17            IN  VARCHAR2    := ''
    ,p_ATTR_18            IN  VARCHAR2    := ''
    ,p_ATTR_19            IN  VARCHAR2    := ''
    ,p_ATTR_20            IN  VARCHAR2    := ''
    ,p_DISPLAY_COLOR      IN  VARCHAR2    := ''
    ,p_USER_ID            IN  VARCHAR2    := ''  
    ,P_RT_ROLLBACK_FLAG   OUT VARCHAR2    
    ,P_RT_MSG             OUT VARCHAR2
) 
IS
    P_ERR_STATUS INT := 0; 
    P_ERR_MSG VARCHAR2(4000) :='';
    V_RTS DATE;
    V_EOS DATE;
/*****************************************************************************
History (date / writer / comment)
- 2021.02.23 / kimsohee / RTS, EOS date re-arrange 
*****************************************************************************/
BEGIN
    P_RT_ROLLBACK_FLAG := 'true';
    IF(p_PARENT_ITEM_LV_ID IS NULL AND P_DP_PLAN_YN = 'Y')
    THEN
       P_ERR_MSG := 'MSG_5045' ;
       RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);            
    END IF;

    SELECT COUNT(*) INTO P_ERR_STATUS
      FROM TB_CM_ITEM_MST
     WHERE 1=1
       AND ITEM_CD = P_ITEM_CD
       AND ID != P_ID;
    IF (P_ERR_STATUS >0)
        THEN
       P_ERR_MSG := 'MSG_0013' ;
       RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);	           
    END IF;

    IF NVL(p_ITEM_CD, ' ') = ' '
    THEN
        P_ERR_MSG := 'Item Code is empty.';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;
    IF NVL(p_ITEM_NM, ' ') = ' '
    THEN
        P_ERR_MSG := 'Item Name is empty.';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

	IF (P_RTS = TO_DATE('1900-01-01'))
    THEN
        V_RTS := NULL;
    ELSIF(P_RTS IS NOT NULL AND P_RTS != TO_DATE('1900-01-01'))
	THEN
		WITH CAL
		 AS (
				SELECT YYYY, DP_WK 
				  FROM TB_CM_CALENDAR
				 WHERE DAT = P_RTS 
	 		 )		 
			SELECT MIN(DAT) INTO V_RTS
			 FROM TB_CM_CALENDAR M
				  INNER JOIN 
				  CAL W
			  ON M.YYYY = W.YYYY AND M.DP_WK = W.DP_WK 
              ;
	END IF; 
    IF (P_EOS = TO_DATE('1900-01-01'))
    THEN
        V_EOS := NULL;
    ELSIF(P_EOS IS NOT NULL AND P_EOS != TO_DATE('1900-01-01'))    
	THEN
		WITH CAL
		 AS (
				SELECT YYYY, DP_WK 
				  FROM TB_CM_CALENDAR
				 WHERE DAT = P_EOS 
	 		 )		 
			SELECT MAX(DAT) INTO V_EOS
			 FROM TB_CM_CALENDAR M
				  INNER JOIN 
				  CAL W
			  ON M.YYYY = W.YYYY AND M.DP_WK = W.DP_WK 
              ;
	END IF; 

    IF (V_RTS > V_EOS)
        THEN
            P_ERR_MSG := 'MSG_5149';
            RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);                    
        END IF;

    MERGE INTO TB_CM_ITEM_MST TGT
    USING ( 
            SELECT   p_ID                      AS ID                
                    ,p_ITEM_CD                 AS ITEM_CD           
                    ,p_ITEM_NM                 AS ITEM_NM           
                    ,p_UOM_ID                  AS UOM_ID
                    ,CASE WHEN p_ITEM_TP_ID IS NOT NULL THEN p_ITEM_TP_ID
                          ELSE (SELECT CT.ID FROM TB_CM_ITEM_TYPE CT WHERE ITEM_TP = 'FERT')
                     END		       		   AS ITEM_TP_ID
                    ,p_DESCRIP                 AS DESCRIP           
                    ,p_DP_PLAN_YN              AS DP_PLAN_YN        
                    ,p_PARENT_ITEM_LV_ID       AS PARENT_ITEM_LV_ID 
                    ,V_RTS                     AS RTS               
                    ,V_EOS                     AS EOS               
                    ,CASE WHEN p_DEL_YN = 'Y' THEN 'Y' ELSE 'N' END   AS DEL_YN            
                    ,p_ATTR_01                 AS ATTR_01           
                    ,p_ATTR_02                 AS ATTR_02            
                    ,p_ATTR_03                 AS ATTR_03            
                    ,p_ATTR_04                 AS ATTR_04            
                    ,p_ATTR_05                 AS ATTR_05            
                    ,p_ATTR_06                 AS ATTR_06            
                    ,p_ATTR_07                 AS ATTR_07            
                    ,p_ATTR_08                 AS ATTR_08            
                    ,p_ATTR_09                 AS ATTR_09            
                    ,p_ATTR_10                 AS ATTR_10            
                    ,p_ATTR_11                 AS ATTR_11            
                    ,p_ATTR_12                 AS ATTR_12            
                    ,p_ATTR_13                 AS ATTR_13            
                    ,p_ATTR_14                 AS ATTR_14            
                    ,p_ATTR_15                 AS ATTR_15            
                    ,p_ATTR_16                 AS ATTR_16            
                    ,p_ATTR_17                 AS ATTR_17            
                    ,p_ATTR_18                 AS ATTR_18            
                    ,p_ATTR_19                 AS ATTR_19            
                    ,p_ATTR_20                 AS ATTR_20            
                    ,p_DISPLAY_COLOR           AS DISPLAY_COLOR
                    ,p_USER_ID                 AS USER_ID
                    ,P_MIN_ORDER_SIZE          AS MIN_ORDER_SIZE
                    ,P_MAX_ORDER_SIZE          AS MAX_ORDER_SIZE

          FROM dual ) SRC
    ON     (TGT.ID = SRC.ID)
    WHEN MATCHED THEN
         UPDATE 
           SET   TGT.ITEM_CD              = SRC.ITEM_CD           
                ,TGT.ITEM_NM              = SRC.ITEM_NM           
                ,TGT.UOM_ID               = SRC.UOM_ID            
                ,TGT.ITEM_TP_ID           = SRC.ITEM_TP_ID        
                ,TGT.DESCRIP              = SRC.DESCRIP           
                ,TGT.DP_PLAN_YN           = SRC.DP_PLAN_YN        
                ,TGT.GRADE_YN             = SRC.DP_PLAN_YN
                ,TGT.PARENT_ITEM_LV_ID    = SRC.PARENT_ITEM_LV_ID 
                ,TGT.RTS                  = SRC.RTS               
                ,TGT.EOS                  = SRC.EOS               
                ,TGT.DEL_YN               = SRC.DEL_YN            
                ,TGT.ATTR_01              = SRC.ATTR_01           
                ,TGT.ATTR_02              = SRC.ATTR_02            
                ,TGT.ATTR_03              = SRC.ATTR_03            
                ,TGT.ATTR_04              = SRC.ATTR_04            
                ,TGT.ATTR_05              = SRC.ATTR_05            
                ,TGT.ATTR_06              = SRC.ATTR_06            
                ,TGT.ATTR_07              = SRC.ATTR_07            
                ,TGT.ATTR_08              = SRC.ATTR_08            
                ,TGT.ATTR_09              = SRC.ATTR_09            
                ,TGT.ATTR_10              = SRC.ATTR_10            
                ,TGT.ATTR_11              = SRC.ATTR_11            
                ,TGT.ATTR_12              = SRC.ATTR_12            
                ,TGT.ATTR_13              = SRC.ATTR_13            
                ,TGT.ATTR_14              = SRC.ATTR_14            
                ,TGT.ATTR_15              = SRC.ATTR_15            
                ,TGT.ATTR_16              = SRC.ATTR_16            
                ,TGT.ATTR_17              = SRC.ATTR_17            
                ,TGT.ATTR_18              = SRC.ATTR_18            
                ,TGT.ATTR_19              = SRC.ATTR_19             
                ,TGT.ATTR_20              = SRC.ATTR_20             
                ,TGT.DISPLAY_COLOR        = SRC.DISPLAY_COLOR
                ,TGT.MODIFY_BY            = SRC.USER_ID       
                ,TGT.MODIFY_DTTM          = SYSDATE()   
                ,TGT.MIN_ORDER_SIZE       = SRC.MIN_ORDER_SIZE
                ,TGT.MAX_ORDER_SIZE       = SRC.MAX_ORDER_SIZE

    WHEN NOT MATCHED THEN 
         INSERT (
                     ID                
                    ,ITEM_CD           
                    ,ITEM_NM           
                    ,UOM_ID            
                    ,ITEM_TP_ID        
                    ,DESCRIP           
                    ,DP_PLAN_YN        
                    ,GRADE_YN
                    ,PARENT_ITEM_LV_ID 
                    ,RTS               
                    ,EOS               
                    ,DEL_YN            
                    ,ATTR_01           
                    ,ATTR_02            
                    ,ATTR_03            
                    ,ATTR_04            
                    ,ATTR_05            
                    ,ATTR_06            
                    ,ATTR_07            
                    ,ATTR_08            
                    ,ATTR_09            
                    ,ATTR_10            
                    ,ATTR_11            
                    ,ATTR_12            
                    ,ATTR_13            
                    ,ATTR_14            
                    ,ATTR_15            
                    ,ATTR_16            
                    ,ATTR_17            
                    ,ATTR_18            
                    ,ATTR_19            
                    ,ATTR_20            
                    ,DISPLAY_COLOR
                    ,CREATE_BY
                    ,CREATE_DTTM
                    ,MIN_ORDER_SIZE
                    ,MAX_ORDER_SIZE
                ) 
         VALUES (
                     TO_SINGLE_BYTE(SYS_GUID())
                    ,SRC.ITEM_CD           
                    ,SRC.ITEM_NM           
                    ,SRC.UOM_ID            
                    ,SRC.ITEM_TP_ID        
                    ,SRC.DESCRIP           
                    ,SRC.DP_PLAN_YN           
                    ,SRC.DP_PLAN_YN       
                    ,SRC.PARENT_ITEM_LV_ID 
                    ,SRC.RTS               
                    ,SRC.EOS               
                    ,SRC.DEL_YN            
                    ,SRC.ATTR_01           
                    ,SRC.ATTR_02            
                    ,SRC.ATTR_03            
                    ,SRC.ATTR_04            
                    ,SRC.ATTR_05            
                    ,SRC.ATTR_06            
                    ,SRC.ATTR_07            
                    ,SRC.ATTR_08            
                    ,SRC.ATTR_09            
                    ,SRC.ATTR_10            
                    ,SRC.ATTR_11            
                    ,SRC.ATTR_12            
                    ,SRC.ATTR_13            
                    ,SRC.ATTR_14            
                    ,SRC.ATTR_15            
                    ,SRC.ATTR_16            
                    ,SRC.ATTR_17            
                    ,SRC.ATTR_18            
                    ,SRC.ATTR_19            
                    ,SRC.ATTR_20 
                    ,SRC.DISPLAY_COLOR
                    ,SRC.USER_ID 
                    ,SYSDATE        
                    ,SRC.MIN_ORDER_SIZE
                    ,SRC.MAX_ORDER_SIZE                                
                 );

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';

EXCEPTION
WHEN OTHERS THEN
      IF(SQLCODE = -20001)
      THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;   
      ELSE
          RAISE;
      END IF;
END;
/

