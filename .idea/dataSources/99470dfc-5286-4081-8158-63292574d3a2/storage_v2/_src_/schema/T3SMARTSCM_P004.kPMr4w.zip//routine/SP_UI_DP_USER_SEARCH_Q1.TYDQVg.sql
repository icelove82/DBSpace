create PROCEDURE "SP_UI_DP_USER_SEARCH_Q1" 
(
 p_LOGIN_ID	    IN VARCHAR2 := ''
 , pRESULT       OUT SYS_REFCURSOR
) 
IS 
/************************************************************
    History ( Date  / Writer / Comment )
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID
*********************************************************/
BEGIN

OPEN pRESULT 
FOR SELECT	USER_ID, EMP_NO, EMP_NM
FROM	TB_DP_EMPLOYEE 
WHERE	USER_ID	LIKE '%' || p_LOGIN_ID || '%'
AND		ACTV_YN = 'Y';


END
;


/

