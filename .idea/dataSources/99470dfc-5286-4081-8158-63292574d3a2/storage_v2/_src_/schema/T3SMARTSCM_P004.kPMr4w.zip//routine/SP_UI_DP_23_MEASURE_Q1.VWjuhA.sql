create PROCEDURE "SP_UI_DP_23_MEASURE_Q1" 
(
 p_VERSION_ID  IN VARCHAR2 := ''
,p_START_DATE IN DATE
,p_END_DATE IN DATE
, pRESULT       OUT SYS_REFCURSOR
) 
IS 

    V_START_MONTH               CHAR(2);
    V_START_YEAR                CHAR(4);
    V_PLAN_TP_ID                CHAR(32);


BEGIN

       SELECT TO_CHAR(FROM_DATE,'YYYY') 
            , PLAN_TP_ID
         INTO V_START_YEAR
            , V_PLAN_TP_ID
         FROM TB_DP_CONTROL_BOARD_VER_MST 
        WHERE VER_ID = p_VERSION_ID             
        ; 

        SELECT LPAD(TO_NUMBER(A.POLICY_VAL), 2, '0') INTO V_START_MONTH
        FROM TB_DP_PLAN_POLICY A
        INNER JOIN TB_CM_COMM_CONFIG B ON B.CONF_GRP_CD ='DP_POLICY' AND B.CONF_CD = 'SM' AND A.POLICY_ID = B.ID       
        where PLAN_TP_ID = V_PLAN_TP_ID
        ;

OPEN pRESULT          
FOR 
    SELECT ITEM_CD
		             		 , ACCOUNT_CD
		             		 , BASE_DATE AS BASE_DATE
		             		 --, BUCKET
				             , SUM(BF_MEAS_QTY) AS BF_MEAS_QTY
				             , SUM(ACT_QTY) AS ACT_SALES_QTY
				             , SUM(ACT_AMT) AS ACT_SALES_AMT
				             , SUM(ANN_QTY) AS ANNUAL_QTY
				             , SUM(ANN_AMT) AS ANNUAL_AMT
				             , SUM(RTF_QTY) AS RTF_QTY
				             , SUM(YOY_QTY) AS YOY_QTY
				             , SUM(YTD_QTY) AS YTD_QTY
				             , SUM(IN_TRAN) AS IN_TRAN
				             , SUM(STOCK) AS STOCK
				             , SUM(ISSUED_PO) AS ISSUED_PO
		          		  FROM
					          (
					            SELECT EX.ITEM_CD AS ITEM_CD
					                 , EX.ACCOUNT_CD AS ACCOUNT_CD
					                 --, H.ATTR_01 AS BUCKET
					                 , EX.BASE_DATE AS BASE_DATE
					                 , EX.BF_MEAS_QTY
					                 , NVL(S.QTY,0) AS ACT_QTY
					                 , NVL(S.AMT,0) AS ACT_AMT
					                 , B.QTY AS ANN_QTY
					                 , B.AMT AS ANN_AMT
					                 , EX.RTF_QTY
					                 , EX.YOY_QTY
					                 , EX.YTD_QTY
					                 , EX.IN_TRAN
					                 , EX.STOCK
					                 , EX.ISSUED_PO
					              FROM TB_DP_EX_MEASURE EX
					          --INNER JOIN TB_CM_COMM_CONFIG        h  on h.CONF_GRP_CD = 'DP_POLICY' AND H.CONF_CD = 'B'
					          LEFT OUTER JOIN TB_CM_ACTUAL_SALES         S  ON (S.ACCOUNT_ID = EX.ACCOUNT_ID AND S.ITEM_MST_ID = EX.ITEM_MST_ID AND S.BASE_DATE = EX.BASE_DATE)
					          LEFT OUTER JOIN TB_DP_MEASURE_ANNU_BUDG    B  ON (B.ACCOUNT_ID = EX.ACCOUNT_ID AND B.ITEM_MST_ID = EX.ITEM_MST_ID AND B.BASE_DATE = EX.BASE_DATE)
					          WHERE 1=1
					          AND EX.BASE_DATE BETWEEN p_START_DATE AND p_END_DATE
					          )
		          	 GROUP BY ITEM_CD, ACCOUNT_CD, base_date
                          ;

END
;


/

