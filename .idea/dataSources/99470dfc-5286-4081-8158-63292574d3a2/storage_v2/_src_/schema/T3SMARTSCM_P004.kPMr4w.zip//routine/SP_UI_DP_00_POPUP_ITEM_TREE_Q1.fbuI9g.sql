create PROCEDURE "SP_UI_DP_00_POPUP_ITEM_TREE_Q1" (
    p_EMP_NO	   VARCHAR2 := NULL
  , p_AUTH_TP_ID   CHAR     := NULL
  , p_ITEM_CD   IN VARCHAR2 := ''
  , p_ITEM_NM   IN VARCHAR2 := ''
  , p_ITEM_LV   IN VARCHAR2 := ''
  , pRESULT     OUT SYS_REFCURSOR
) IS
                                                     
/*************************************************************************
      ITEM LEVEL  
    USED UI : UI_DP_POPUP_ITEM_TREE

    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 

************************************************************************/
    P_EMP_ID CHAR(32) := NULL;
    P_ITEM_CNT   INT;
    P_CNT        INT;
BEGIN

    SELECT COUNT(ID)
      INTO P_CNT
      FROM TB_AD_USER
     WHERE USERNAME = P_EMP_NO;

    IF P_CNT != 0 THEN
        SELECT ID INTO P_EMP_ID
          FROM TB_AD_USER
         WHERE USERNAME = P_EMP_NO;
    END IF;

    SELECT COUNT(*) INTO P_ITEM_CNT
      FROM (
        SELECT EMP_ID 
          FROM TB_DP_USER_ITEM_MAP
         WHERE EMP_ID = p_EMP_ID
           AND AUTH_TP_ID = p_AUTH_TP_ID
        UNION
        SELECT EMP_ID
          FROM TB_DP_USER_ITEM_ACCOUNT_MAP
         WHERE EMP_ID = p_EMP_ID
           AND AUTH_TP_ID = p_AUTH_TP_ID
      )
    ;
-- ITEM이 없을 경우에는 전체 조회
    IF(P_ITEM_CNT = 0)
    THEN
        P_EMP_ID := NULL;
    END IF; 
/*****************************************************************
    MAIN PROCEDURE
*****************************************************************/
    IF (P_EMP_ID IS NULL OR p_AUTH_TP_ID IS NULL)
	THEN
        OPEN pRESULT   
        FOR
        SELECT A.ID 
             , A.ITEM_CD
             , A.ITEM_NM
             , A.EOS  AS EOS      
             , A.RTS  AS RTS  
             , C.UOM_CD
             , C.UOM_NM
             , A.DESCRIP
             , A.PARENT_ITEM_LV_ID 
             , E.LEAF_ITEM_LV_CD   AS PARENT_ITEM_LV_CD
             , E.LEAF_ITEM_LV_NM   AS PARENT_ITEM_LV_NM
		  FROM TB_CM_ITEM_MST A
		       INNER JOIN    
               TABLE(FN_DP_TEMP_ITEM_TREE()) E
            ON E.LEAF_ITEM_LV_ID = A.PARENT_ITEM_LV_ID
           AND E.PATH_CD LIKE '%' || COALESCE(P_ITEM_LV, '') || '%'
               LEFT OUTER JOIN
               TB_CM_UOM C
            ON A.UOM_ID = C.ID
           AND C.ACTV_YN = 'Y'	    
         WHERE 1=1 
		   AND COALESCE(A.DEL_YN,'N') = 'N'
		   AND A.DP_PLAN_YN = 'Y'
           AND UPPER(A.ITEM_CD) LIKE '%' || UPPER(RTRIM(p_ITEM_CD)) || '%'			
           AND UPPER(A.ITEM_NM) LIKE '%' || UPPER(RTRIM(p_ITEM_NM)) || '%'	
		 ORDER BY E.SEQ, E.LEAF_ITEM_LV_CD, A.ITEM_CD
		;
    ELSE
        OPEN pRESULT   
        FOR    
 		SELECT IM.ID
 		     , IM.ITEM_CD
 		     , IM.ITEM_NM
 		     , IM.EOS
 		     , IM.RTS
 		     , UM.UOM_CD
 		     , UM.UOM_NM
 		     , IM.DESCRIP
 		     , IM.PARENT_ITEM_LV_ID
 		     , IL.ITEM_LV_CD AS PARENT_ITEM_LV_CD
 		     , IL.ITEM_LV_NM AS PARENT_ITEM_LV_NM
		  FROM TABLE(FN_DP_TEMP_FIND_ITEM(P_EMP_ID,P_AUTH_TP_ID, P_ITEM_LV)) FI
			   INNER JOIN
			   TB_CM_ITEM_MST IM
			ON IM.ID = FI.ITEM_ID
			   LEFT OUTER JOIN
			   TB_CM_UOM UM
			ON IM.UOM_ID = UM.ID
			   LEFT OUTER JOIN
			   TB_CM_ITEM_LEVEL_MGMT IL
			ON IL.ID = IM.PARENT_ITEM_LV_ID
	     WHERE FI.ITEM_CD LIKE '%'|| COALESCE(P_ITEM_CD, '')|| '%'
		   AND FI.ITEM_NM LIKE '%'|| COALESCE(P_ITEM_NM, '')|| '%'
		 ORDER BY IL.SEQ, IL.ITEM_LV_CD, IM.ITEM_CD
        ;
END IF;
END
;

/

