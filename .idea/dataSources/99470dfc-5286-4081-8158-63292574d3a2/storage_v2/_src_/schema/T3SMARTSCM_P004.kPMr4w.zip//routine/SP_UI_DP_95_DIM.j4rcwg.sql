create PROCEDURE                 "SP_UI_DP_95_DIM" (
     p_USER_ID   VARCHAR2
    ,p_AUTH_TP   VARCHAR2
    ,p_UI_ID     VARCHAR2
    ,p_GRID_ID	 VARCHAR2
    ,pRESULT     OUT SYS_REFCURSOR
)IS
/*
    history (date / writer / comment)
    - 2021.01.04 / kim sohee / By Character 1 type, convert hard coding to level type of TB_CM_COMM_CONFIG
*/
BEGIN
     OPEN pRESULT FOR
WITH DP_LEVEL
 AS (
           select L.ID, L.LV_CD, L.SALES_LV_YN, L.ACCOUNT_LV_YN, L.LEAF_YN, ROW_NUMBER() over (order by L.seq) as IDX 
                , C.CONF_CD AS LV_TP_CD
            from TB_CM_LEVEL_MGMT L
                 INNER JOIN 
                 TB_CM_COMM_CONFIG C
              ON L.LV_TP_ID = C.ID 
           where ACCOUNT_LV_YN = 'Y'   and DEL_YN = 'N' and L.ACTV_YN = 'Y'						                
            union					
            select L.ID, LV_CD, SALES_LV_YN,ACCOUNT_LV_YN,LEAF_YN,  ROW_NUMBER() over (order by seq) as IDX 	
                 , C.CONF_CD AS LV_TP_CD
            from TB_CM_LEVEL_MGMT L
                 INNER JOIN TB_CM_COMM_CONFIG C 
              ON L.LV_TP_ID = C.Id and c.CONF_CD = 'I' 
            WHERE l.DEL_YN = 'N'				
 )
	SELECT A.FLD_CD AS DISPLAY					
         , LV_TP_CD AS TYPE		
         , (case when (V.SALES_LV_YN = 'Y' and V.LEAF_YN = 'N') then 'SALES_LV' 					
                 when (V.ACCOUNT_LV_YN = 'Y' and V.LEAF_YN = 'Y') then 'ACCOUNT'  					
                 when (V.SALES_LV_YN = 'N' and V.LEAF_YN = 'N') then 'ITEM_LV'  					
                 when (V.SALES_LV_YN = 'N' and V.LEAF_YN = 'Y') then 'ITEM'					
                 else 'NONE' end ) AS "LEVEL"		
         , V.LV_CD as LEVEL_CD 
         , case when (SUBSTR(B.COL_NM, -2) = 'CD' or  SUBSTR(B.COL_NM, -2) = 'NM') then B.DISP_NM  else B.COL_NM end  as FIELD					
         , V.IDX					
	  FROM TB_AD_USER_PREF_DTL A 
	 inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = p_UI_ID and m.GRID_CD = p_GRID_ID 
	 inner join TB_AD_GROUP g on g.ID = A.GRP_ID and GRP_CD = p_AUTH_TP
	 inner join TB_AD_USER u on u.USERNAME = p_USER_ID
	 inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
	 INNER JOIN TB_DP_DIM_SETTING B on  A.REFER_VALUE = B.ID	
	 INNER JOIN DP_LEVEL V	 on 		V.ID = B.LV_MGMT_ID	
	LEFT OUTER JOIN TB_AD_USER_PREF up ON	m.id = up.USER_PREF_MST_ID AND A.GRP_ID = up.GRP_ID	AND	A.FLD_CD = up.FLD_CD	AND up.USER_ID = u.ID					
	WHERE A.DIM_MEASURE_TP = 'DIMENSION'			
      AND COALESCE(up.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N')) = 'Y'		
	;
END;

/

