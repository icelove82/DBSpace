create FUNCTION                 FN_SMP_PLAN_VALIDATION(
 P_sPLAN_TYPE      IN VARCHAR2
,P_sBASE_MONTH     IN VARCHAR2
,P_sVERSION_ID     IN VARCHAR2
)
/**************************************************************************
* Copyrightⓒ2020 ZIONEX, All rights reserved. 
**************************************************************************
* Name    : FN_PLAN_VALIDATION
* Purpose : Plan Type 기준 현재 계획 실행이 가능한지 Check 하기 위함
* Notes   : 
* <호출>
**************************************************************************
* History : 
* 2020-03-31 JMS Created
**************************************************************************/
RETURN VARCHAR2
IS

O_sVALID_FLAG     CHAR(1);
P_sPRE_PLAN_TYPE  VARCHAR2(50);

    BEGIN
        
        -- 기준월 별 Plan Type 상관없이 계획수립중인 버전이 있는지 확인.
        SELECT CASE WHEN COUNT(*) > 0 THEN 'N' ELSE 'Y' END -- 'N' : 수립중인 계획이 있음으로 계획수립 불가, 'Y' : 계획수립 가능
          INTO O_sVALID_FLAG
          FROM TB_SMP_VER_MST
         WHERE VERSION_ID <> P_sVERSION_ID
           AND BASE_MONTH = P_sBASE_MONTH
           AND STATUS_CD NOT IN ('C', 'E', 'W')
        ;
      
        /*IF O_sVALID_FLAG = 'Y' THEN
            
            SELECT CFG.PRE_PLAN_TYPE
              INTO P_sPRE_PLAN_TYPE
              FROM (
                    SELECT CONF_CD, PRIORT, LAG(CONF_CD) OVER (PARTITION BY CONF_GRP_CD  ORDER BY PRIORT) AS PRE_PLAN_TYPE
                      FROM TB_CM_COMM_CONFIG
                     WHERE CONF_GRP_CD = 'PLAN_STEP_CFG'
                       AND ACTV_YN = 'Y'
                       AND USE_YN = 'Y'
                   ) CFG
             WHERE 1=1
               AND CFG.CONF_CD = P_sPLAN_TYPE
            ;
            
            IF P_sPRE_PLAN_TYPE IS NOT NULL THEN
            
                -- 기준월 - Plan Type 별로 그 전에 수립되어야 할 Plan Type 의 승인된 버전이 있는지 확인.
                SELECT CASE WHEN COUNT(*) > 0 THEN 'Y' ELSE 'X' END -- 'X' : 이전 Approved Version 없음으로 계획수립 불가, 'Y' : 계획수립 가능
                  INTO O_sVALID_FLAG
                  FROM TB_SMP_VER_MST
                 WHERE 1=1
                   AND PLAN_TYPE  = P_sPRE_PLAN_TYPE
                   AND BASE_MONTH = P_sBASE_MONTH
                   AND STATUS_CD  = 'C'
                   AND APPR_FLAG  = 'Y'
                ;
            
            END IF;
        
        END IF;*/
        
        RETURN O_sVALID_FLAG;

    END;


/

