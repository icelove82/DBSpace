create PROCEDURE SP_UI_BF_02_S1 (
                     P_ID			IN   CHAR		:= ''
                    ,P_ENGINE_TP_CD     IN   VARCHAR2  := ''
                    ,P_POLICY_CD		IN   VARCHAR2	:= ''
                    ,P_POLICY_NM		IN   VARCHAR2	:= ''
                    ,P_POLICY_VAL		IN   VARCHAR2	:= ''
                    ,P_DESCRIP	     IN   VARCHAR2	:= ''
                    ,P_USER_ID		IN   VARCHAR2	:= ''
                    ,P_RT_ROLLBACK_FLAG OUT  VARCHAR2     
                    ,P_RT_MSG           OUT  VARCHAR2    		
)
IS
        P_ERR_STATUS INT := 0;
        P_ERR_MSG VARCHAR2(4000):='';



BEGIN 
/* MESSAGE VALIDATION	*/
	SELECT COUNT(*) INTO P_ERR_STATUS
	  FROM TB_BF_PLAN_POLICY
	WHERE 1=1
	  AND POLICY_CD = P_POLICY_CD   
	  AND ID != P_ID;
	IF(P_ERR_STATUS > 0)
		THEN
            P_ERR_MSG := 'MSG_0013';
            RAISE_APPLICATION_ERROR(-20000, P_ERR_MSG);  
    END IF;

				MERGE INTO TB_BF_PLAN_POLICY TGT
				USING ( 
						SELECT
						 P_ID			          AS ID
                              ,P_ENGINE_TP_CD               AS ENGINE_TYPE_CD
						,UPPER(RTRIM(P_POLICY_CD))	AS POLICY_CD	
                              ,RTRIM(P_POLICY_NM)	          AS POLICY_NM
						,RTRIM(P_POLICY_VAL)	     AS POLICY_VAL	
						,RTRIM(P_DESCRIP)		     AS DESCRIP		
						,P_USER_ID			     AS USER_ID	
                        FROM dual
					  ) SRC
				ON (TGT.ID = SRC.ID)
				WHEN MATCHED THEN
					 UPDATE 
					   SET   		
							 TGT.POLICY_CD	     = SRC.POLICY_CD	
                                   ,TGT.ENGINE_TYPE_CD = SRC.ENGINE_TYPE_CD
                                   ,TGT.POLICY_NM	     = SRC.POLICY_NM
							,TGT.POLICY_VAL     = SRC.POLICY_VAL	
							,TGT.DESCRIP	     = SRC.DESCRIP			
							,TGT.MODIFY_BY	     = SRC.USER_ID	
							,TGT.MODIFY_DTTM = SYSDATE		
				WHEN NOT MATCHED THEN 
					 INSERT (
								 ID
                                        ,ENGINE_TYPE_CD
								,POLICY_CD
                                        ,POLICY_NM
								,POLICY_VAL
								,DESCRIP
								,CREATE_BY
								,CREATE_DTTM
								,MODIFY_BY
								,MODIFY_DTTM
							) 
					 VALUES (
							 TO_SINGLE_BYTE(SYS_GUID())	
                                   ,SRC.ENGINE_TYPE_CD
							,SRC.POLICY_CD	
                                   ,SRC.POLICY_NM
							,SRC.POLICY_VAL	
							,SRC.DESCRIP		
							,SRC.USER_ID 
							,SYSDATE  
							,NULL
							,NULL          
 							) 
							;    
	   P_RT_ROLLBACK_FLAG := 'true';
	   P_RT_MSG := 'MSG_0001';
       
       EXCEPTION   
        WHEN OTHERS THEN
--          P_ERR_MSG := SQLERRM; -- SYS.DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
          P_RT_ROLLBACK_FLAG := 'false';
              IF(SQLCODE = -20000)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF;

END;

/

