create PROCEDURE SP_UI_BF_03_S1  (
									   p_ID               IN  VARCHAR2 := ''      
									  ,P_ENGINE_TYPE_CD	  IN  VARCHAR2 := ''
									  ,P_ACCOUNT_CD	  IN  VARCHAR2 := ''
									  ,P_ITEM_CD		  IN	 VARCHAR2 := ''
									  ,P_MODEL_CD	       IN  VARCHAR2 := ''
									  ,P_USER_ID		  IN  VARCHAR2 := ''
									  ,P_RT_ROLLBACK_FLAG OUT VARCHAR2
									  ,P_RT_MSG           OUT VARCHAR2
				                   ) 
IS

        P_ERR_MSG VARCHAR2(4000):='';
        P_ERR_STATUS INT := 0;

-- 프로시저 시작 
BEGIN
     SELECT COUNT(*) INTO P_ERR_STATUS
       FROM TB_BF_PLAN_POLICY 
      WHERE ENGINE_TYPE_CD = P_ENGINE_TYPE_CD;

     -- EMPLOYEE 가 선택되지 않은 경우
     IF (P_ENGINE_TYPE_CD IS NULL OR P_ENGINE_TYPE_CD = '' OR P_ERR_STATUS=0)
     THEN
        P_ERR_MSG := 'MSG_0014';
          RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);	
     END IF;

     ---- Account 체크
     --IF (@P_ACCOUNT_CD IS NULL OR @P_ACCOUNT_CD = '')
     --BEGIN
     --	   P_ERR_MSG := 'MSG_0015';
     --      RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);	
     --END

     -- item 체크
     IF (P_ITEM_CD IS NULL OR P_ITEM_CD = '')
     THEN
          P_ERR_MSG := 'MSG_0017';
          RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);	
     END IF;

	MERGE INTO TB_BF_ITEM_ACCOUNT_MODEL_MAP TGT   
	USING ( 
			SELECT P_ID				AS ID 
				 , P_ENGINE_TYPE_CD	AS ENGINE_TYPE_CD
				 , P_ACCOUNT_CD		AS ACCOUNT_CD
				 , P_ITEM_CD			AS ITEM_CD
				 , P_MODEL_CD			AS MODEL_CD
				 , P_USER_ID			AS USER_ID
                  FROM DUAL
			) SRC
	ON      (TGT.ID = SRC.ID)
	WHEN MATCHED THEN
			UPDATE 
			SET   TGT.ENGINE_TYPE_CD  = SRC.ENGINE_TYPE_CD
				 ,TGT.ACCOUNT_CD = SRC.ACCOUNT_CD 
				 ,TGT.ITEM_CD = SRC.ITEM_CD
				 ,TGT.MODEL_CD = SRC.MODEL_CD
				 ,TGT.MODIFY_BY   = SRC.USER_ID
				 ,TGT.MODIFY_DTTM = SYSDATE
	WHEN NOT MATCHED THEN 
			INSERT (
					ID 
					, ENGINE_TYPE_CD
					, ACCOUNT_CD
					, ITEM_CD
					, MODEL_CD
					, CREATE_BY
					, CREATE_DTTM
				) 
			VALUES (
					TO_SINGLE_BYTE(SYS_GUID())
					, SRC.ENGINE_TYPE_CD
					, SRC.ACCOUNT_CD
					, SRC.ITEM_CD
					, SRC.MODEL_CD
					, SRC.USER_ID 
					, SYSDATE
 				) 
     ;    	

     P_RT_ROLLBACK_FLAG := 'true';
     P_RT_MSG := 'MSG_0001'; 

       EXCEPTION
        WHEN OTHERS THEN   
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;     

END;

/

