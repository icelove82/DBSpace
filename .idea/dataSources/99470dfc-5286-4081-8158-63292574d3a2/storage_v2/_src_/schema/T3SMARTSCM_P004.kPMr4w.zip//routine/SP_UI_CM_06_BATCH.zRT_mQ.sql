create PROCEDURE SP_UI_CM_06_BATCH (
	P_APPLY_POINT_CD		VARCHAR2 := ''
   ,P_CHECK_LOCAT			CHAR := ''
   ,P_LOCAT_MGMT_ID		    CHAR := ''
   ,P_OVERWRITE_DATA_YN	    CHAR := ''
   ,P_USER_ID				VARCHAR2 := ''
   ,P_RT_ROLLBACK_FLAG      OUT VARCHAR2
   ,P_RT_MSG                OUT VARCHAR2
)
IS
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG VARCHAR2(4000) :='';

BEGIN
	/***************************************************************************************************************************************************************************
	BOD L/T 정보 기준의 거점 BOD MAPPING 데이터 생성
	***************************************************************************************************************************************************************************/
	INSERT INTO TEMP_LOC_BOD_MAP
	(
		BOD_TP_ID,
		CONSUME_LOCAT_ID,
		SUPPLY_LOCAT_ID
	)
	SELECT	DISTINCT
			(SELECT ID FROM TB_AD_COMN_CODE WHERE COMN_CD = 'SITE_BOD') AS BOD_TP_ID,
			G.ID AS CONSUME_LOCAT_ID,
			D.ID AS SUPPLY_LOCAT_ID
	FROM	TB_CM_BOD_LT A
			INNER JOIN TB_CM_LOC_MST B
			ON B.ID = A.FROM_LOCAT_MST_ID
			INNER JOIN TB_CM_LOC_DTL C
			ON B.ID = C.LOCAT_MST_ID
			INNER JOIN TB_CM_LOC_MGMT D
			ON C.ID = D.LOCAT_ID
			INNER JOIN TB_CM_LOC_MST E
			ON E.ID = A.TO_LOCAT_MST_ID
			INNER JOIN TB_CM_LOC_DTL F
			ON E.ID = F.LOCAT_MST_ID
			INNER JOIN TB_CM_LOC_MGMT G
			ON F.ID = G.LOCAT_ID
	WHERE	NVL(A.ACTV_YN, 'N') = 'Y'
	AND		NVL(C.ACTV_YN, 'N') = 'Y'
	AND		NVL(F.ACTV_YN, 'N') = 'Y'
	AND		(
			D.ID	= CASE WHEN P_APPLY_POINT_CD = 'PARTIAL' AND P_CHECK_LOCAT = 'Y'
						   THEN P_LOCAT_MGMT_ID
						   ELSE D.ID
					  END
		OR	G.ID	= CASE WHEN P_APPLY_POINT_CD = 'PARTIAL' AND P_CHECK_LOCAT = 'Y'
						   THEN P_LOCAT_MGMT_ID
						   ELSE G.ID
					  END
			);

	IF P_APPLY_POINT_CD = 'ALL' AND P_OVERWRITE_DATA_YN = 'Y' THEN
        DELETE FROM TB_CM_LOC_BOD_MAP;

	ELSIF P_APPLY_POINT_CD = 'PARTIAL' AND P_OVERWRITE_DATA_YN = 'Y' THEN
        DELETE
        FROM    TB_CM_LOC_BOD_MAP A
        WHERE   1=1
        AND     EXISTS  (
                        SELECT  1
                        FROM    TEMP_LOC_BOD_MAP B
                        WHERE	B.CONSUME_LOCAT_ID = A.CONSUME_LOCAT_ID
                        AND		B.SUPPLY_LOCAT_ID = A.SUPPLY_LOCAT_ID
                        );
    END IF;

    MERGE INTO TB_CM_LOC_BOD_MAP A
    USING
        (
		SELECT	BOD_TP_ID,
				CONSUME_LOCAT_ID,
				SUPPLY_LOCAT_ID
		FROM	TEMP_LOC_BOD_MAP A
        ) B
    ON (A.CONSUME_LOCAT_ID = B.CONSUME_LOCAT_ID
      AND A.SUPPLY_LOCAT_ID = B.SUPPLY_LOCAT_ID)
    WHEN NOT MATCHED THEN 
		INSERT 
		(
			ID
		   ,BOD_TP_ID
		   ,CONSUME_LOCAT_ID
		   ,SUPPLY_LOCAT_ID
		   ,ACTV_YN
		   ,CREATE_BY
		   ,CREATE_DTTM
		)  
		VALUES
		(
			TO_SINGLE_BYTE(SYS_GUID())
		   ,B.BOD_TP_ID
		   ,B.CONSUME_LOCAT_ID
		   ,B.SUPPLY_LOCAT_ID
		   ,'Y'
		   ,P_USER_ID
		   ,SYSDATE
		);

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0003';

    EXCEPTION
	WHEN OTHERS THEN
		P_RT_ROLLBACK_FLAG := 'false';
		IF(SQLCODE = -20012)
		  THEN
			  P_RT_MSG := P_ERR_MSG;
		  ELSE
			  P_RT_MSG := SQLERRM;
		END IF;
END;

/

