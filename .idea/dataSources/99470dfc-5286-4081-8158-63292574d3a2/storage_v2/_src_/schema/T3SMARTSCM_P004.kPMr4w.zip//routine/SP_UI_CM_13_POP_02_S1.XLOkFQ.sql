create PROCEDURE "SP_UI_CM_13_POP_02_S1" (
     P_WRK_TYPE			    IN VARCHAR2 :=''
	,P_ID					IN VARCHAR2 := null
	,P_LOC_MGMT_ID			IN VARCHAR2 := null
	,P_WAREHOUSE_TP_ID		IN VARCHAR2 := null
	,P_CAPA_LIMIT_VAL		IN VARCHAR2 := null
	,P_ACTV_YN				IN CHAR  := null
	,P_USER_ID				IN VARCHAR2 := null
    ,P_RT_ROLLBACK_FLAG		OUT VARCHAR2
    ,P_RT_MSG				OUT VARCHAR2
)IS
    
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG  VARCHAR2(4000) :='';

    P_CAPA_LIMIT_VAL_TEMP VARCHAR2(100) := P_CAPA_LIMIT_VAL;
BEGIN
        P_RT_ROLLBACK_FLAG := 'true';
    IF LTRIM(RTRIM(P_CAPA_LIMIT_VAL)) IS NULL		THEN P_CAPA_LIMIT_VAL_TEMP := NULL; END IF;


    IF P_WRK_TYPE = 'SAVE'
	THEN

		MERGE INTO TB_CM_SITE_WAREHOUSE_MGMT B 
		USING (SELECT P_ID AS ID FROM DUAL) A
				ON    ( B.ID = A.ID)

		WHEN MATCHED THEN
			UPDATE 
			SET    CAPA_LIMIT_VAL	= TO_NUMBER(P_CAPA_LIMIT_VAL_TEMP)
				 , ACTV_YN			= P_ACTV_YN
				 , MODIFY_BY		= P_USER_ID
				 , MODIFY_DTTM		= SYSDATE

		WHEN NOT MATCHED THEN			
			INSERT (
					-- ？？？？？？
					ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
					-- ？？？？？？？？
					,LOCAT_MGMT_ID
					,WAREHOUSE_TP_ID
					,WAREHOUSE_NM
					,CAPA_LIMIT_VAL
					,ACTV_YN
				  )
			VALUES 
		  	      (
					-- ？？？？？？
					TO_SINGLE_BYTE(SYS_GUID()), P_USER_ID, SYSDATE, P_USER_ID, SYSDATE
					-- ？？？？？？？？
					,P_LOC_MGMT_ID
					,P_WAREHOUSE_TP_ID
					,(SELECT WAREHOUSE_TP_NM 
						FROM TB_CM_WAREHOUSE_TYPE 
					   WHERE ID = P_WAREHOUSE_TP_ID)
					,TO_NUMBER(P_CAPA_LIMIT_VAL_TEMP)
					,P_ACTV_YN
				);

			 P_RT_ROLLBACK_FLAG := 'true';
			 P_RT_MSG := 'MSG_0001';  --？？？？ ？？？？？？？？.


	ELSIF P_WRK_TYPE = 'DELETE'
		THEN
			DELETE FROM TB_CM_SITE_WAREHOUSE_MGMT 
			WHERE ID = P_ID  ;

   			 P_RT_ROLLBACK_FLAG := 'true';
   			 P_RT_MSG := 'MSG_0002' ; --？？？？ ？？？？？？？？.

		END IF;


                 P_RT_ROLLBACK_FLAG := 'true';
    			 P_RT_MSG := 'MSG_0001';  --？？？？ ？？？？？？？？.
EXCEPTION
        WHEN OTHERS THEN
            IF(SQLCODE = -20012)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
              RAISE;
              END IF; 

END;

/

