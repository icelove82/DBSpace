create PROCEDURE        "SP_UI_CM_01_POP_111_S" (
	 P_ID                       IN VARCHAR2 := ''
    ,P_ACTV_YN		            IN VARCHAR2 := ''
    ,P_USER_ID	                IN VARCHAR2 := ''
    ,P_WRK_TYPE	                IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG         OUT VARCHAR2 
    ,P_RT_MSG                   OUT VARCHAR2
    
)
IS

    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';

BEGIN
IF P_WRK_TYPE = 'SAVE'
THEN

    UPDATE TB_CM_COMM_CONFIG
		   SET ACTV_YN		= P_ACTV_YN
             , MODIFY_BY		= P_USER_ID
             , MODIFY_DTTM		= SYSDATE()
		 WHERE ID = P_ID;

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';  --???？？????？？

END IF;

        EXCEPTION
        WHEN OTHERS THEN
            P_RT_ROLLBACK_FLAG := 'false';
            IF(SQLCODE = -20012)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF; 

END;

/

