create PACKAGE                 PKG_SMP_LOGGER IS

  /**************************************************************************
   * Copyrightⓒ2020 ZIONEX, All rights reserved.
   **************************************************************************
   * Name : PKG_SMP_LOGGER
   * Purpose : 시스템 내부에서 발생하는 로그 정보를 기록하기 위함이다.
   * Notes :
   **************************************************************************
   * History :
   *  2020-02-27 JMS created
   **************************************************************************/
  
  -----------------------------
  -- Public type declarations -
  -----------------------------

  ---------------------------------
  -- Public constant declarations -
  ---------------------------------

  ---------------------------------
  -- Public variable declarations -
  ---------------------------------

  ---------------------------------
  -- Public function declarations -
  ---------------------------------
  
  /* Start log  */
  PROCEDURE stepSTART (
    P_nLOG_SEQ          IN OUT NUMBER
  , P_sPROGRAM_ID       IN NVARCHAR2
  , P_sSTEP_SEQ         IN NVARCHAR2
  , P_sSTEP_DESC        IN NVARCHAR2
  , P_sVERSION_ID       IN NVARCHAR2
  , P_sUSER_ID          IN NVARCHAR2
  );
  
  /* Finish log  */
  PROCEDURE stepFINISH (
    P_nLOG_SEQ          IN OUT NUMBER
  , P_nSQL_CNT          IN NUMBER
  );
  
  /* Error log  */
  PROCEDURE stepERROR (
    P_nLOG_SEQ          IN OUT NUMBER
  , P_sLOG_MSG          IN VARCHAR2 DEFAULT NULL
  , P_sVERSION_ID       IN VARCHAR2 DEFAULT NULL
  );
  
  /* Debug log  */
  PROCEDURE stepDEBUG (
    P_nLOG_SEQ          IN OUT NUMBER
  , P_sATTR_01          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_02          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_03          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_04          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_05          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_06          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_07          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_08          IN NVARCHAR2 DEFAULT NULL
  , P_sATTR_09          IN NVARCHAR2 DEFAULT NULL 
  , P_sATTR_10          IN NVARCHAR2 DEFAULT NULL
  );

END PKG_SMP_LOGGER;

/

