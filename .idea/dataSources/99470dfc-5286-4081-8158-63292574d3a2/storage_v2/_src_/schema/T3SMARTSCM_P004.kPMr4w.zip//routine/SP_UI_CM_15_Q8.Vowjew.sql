create PROCEDURE        "SP_UI_CM_15_Q8" (
        pResult OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN pResult FOR 
      SELECT  A.ID AS LOCAT_ID
             ,B.COMN_CD_NM AS LOCAT_NM
             ,A.LOCAT_LV
      FROM  TB_CM_LOC_MST A  
        INNER JOIN TB_AD_COMN_CODE B 
          ON A.LOCAT_TP_ID = B.ID
      WHERE 1=1
        AND A.ACTV_YN = 'Y';

END;

/

