create PROCEDURE "SP_UI_DP_30_CHART_Q1" (
     p_PLAN_TP_ID	VARCHAR2
    ,p_BUCK			VARCHAR2
    ,p_STRT_DATE	DATE
    ,p_END_DATE		DATE
    ,p_OPTION		CHAR
    ,p_USER_ID		VARCHAR2
    ,p_ITEM_CD		VARCHAR2
    ,p_ACCT_CD		VARCHAR2
    ,p_ITEM_LV_CD	VARCHAR2
    ,p_ACCT_LV_CD	VARCHAR2
    ,p_RT_MSG		OUT VARCHAR2
    ,pRESULT        OUT SYS_REFCURSOR
)IS

/*****************************************************************************
Title : [SP_UI_DP_30_CHART_Q1]
최초 작성자 : 한영석
최초 생성일 : 2017.06.20
 
설명 
 - Compare Sales & DP 그리드 조회 쿼리
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 한영석 / 최초 작성
- 2018.12.21 / 김소희 / MAIN SELECT문 컨버팅 
- 2020.12.22 / 민경훈 / MSSQL -> ORACLE
 
*****************************************************************************/

v_ERR_MSG		VARCHAR2(4000):='';
v_ERR_STATUS	INT  := NULL;

v_BUCK			VARCHAR2(50) :='';
v_STRT_DATE	    DATE := '';
v_END_DATE		DATE := '';
v_PLAN_TP_ID	VARCHAR2(100) :='';
v_ITEM_CD		VARCHAR2(4000) :='';
v_ACCT_CD		VARCHAR2(4000) :='' ;
v_OPTION		CHAR(1) := '';

BEGIN
	v_BUCK			:= p_BUCK;
	v_STRT_DATE	    := p_STRT_DATE;
	v_END_DATE		:= p_END_DATE;
	v_PLAN_TP_ID	:= p_PLAN_TP_ID;
	v_ITEM_CD		:= p_ITEM_CD;
	v_ACCT_CD		:= p_ACCT_CD;
	v_OPTION		:= p_OPTION;
--------------------------------------------------------------------------------
	-- 본 프로시저
--------------------------------------------------------------------------------
    OPEN pRESULT FOR
    WITH VER AS (
        SELECT DISTINCT DO.ITEM_MST_ID ,DO.ACCOUNT_ID 
          FROM TB_DP_ENTRY_HISTORY DO
         INNER JOIN (SELECT DISTINCT DESCENDANT_ID
                       FROM TB_DPD_ITEM_HIER_CLOSURE 
                      WHERE LEAF_YN = 'Y' 
                        AND (REGEXP_LIKE(UPPER(ANCESTER_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(v_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                            OR v_ITEM_CD IS NULL
                      )
--                        AND CASE WHEN v_ITEM_CD LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(v_ITEM_CD,'') END IN (
--                            SELECT TRIM(REGEXP_SUBSTR(v_ITEM_CD, '[^|]+', 1, LEVEL)) AS ITEM_CD
--                                FROM DUAL
--                            CONNECT BY INSTR(v_ITEM_CD, '|', 1, LEVEL - 1) > 0
--                        )
--                        AND CASE WHEN v_ITEM_CD NOT LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(v_ITEM_CD,'') END LIKE '%' || COALESCE(v_ITEM_CD,'') || '%'
        ) IT  ON IT.DESCENDANT_ID = DO.ITEM_MST_ID
         INNER JOIN (SELECT DISTINCT DESCENDANT_ID 
                       FROM TB_DPD_SALES_HIER_CLOSURE 
                      WHERE LEAF_YN = 'Y' 
                        AND (REGEXP_LIKE(UPPER(ANCESTER_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                            OR p_ACCT_CD IS NULL
                      )
--                        AND CASE WHEN p_ACCT_CD LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(p_ACCT_CD,'') END IN (
--                            SELECT TRIM(REGEXP_SUBSTR(v_ACCT_CD, '[^|]+', 1, LEVEL)) AS ACCT_CD
--                                FROM DUAL
--                            CONNECT BY INSTR(v_ACCT_CD, '|', 1, LEVEL - 1) > 0
--                        )
--                        AND CASE WHEN p_ACCT_CD NOT LIKE '%|%' THEN ANCESTER_CD ELSE COALESCE(p_ACCT_CD,'') END LIKE '%'+COALESCE(p_ACCT_CD,'')+'%'
		) AM ON AM.DESCENDANT_ID = DO.ACCOUNT_ID   
           WHERE 1=1  
             AND BASE_DATE BETWEEN v_STRT_DATE AND v_END_DATE
             AND PLAN_TP_ID = p_PLAN_TP_ID
    ), 
    CAL AS (
        SELECT MIN(DAT) AS STRT_DATE
             , MAX(DAT) AS END_DATE
          FROM TB_CM_CALENDAR
         WHERE DAT BETWEEN v_STRT_DATE AND v_END_DATE
      GROUP BY TO_CHAR(YYYY)
             , CASE WHEN v_BUCK IN ('MONTH', 'PAR_WEEK') THEN TO_CHAR(MM) ELSE '1' END 
             , CASE WHEN v_BUCK IN ('PAR_WEEK', 'WEEK') THEN TO_CHAR(DP_WK) ELSE '1' END 
    ) 
    SELECT   M.STRT_DATE										AS "DATE"
           , M.STRT_DATE										AS "CATEGORY"
           , COALESCE(T_ACTUAL_SALES.QTY, 0) 				AS ACT_SALES_QTY
           , COALESCE(T_ANNUAL_DP.QTY, 0) 					AS ANNUAL_QTY
           , COALESCE(T_FINAL_DP.QTY, 0 ) 					AS FINAL_DP_QTY
        FROM CAL M	
			-------------------------------------- 
			--  MEASURE 1 ACTUAL_SALES
			-------------------------------------- 
        LEFT OUTER JOIN (
            SELECT STRT_DATE
                 , CASE WHEN v_OPTION = 'Q' THEN sum(QTY) ELSE sum(AMT) END QTY 
              FROM TB_CM_ACTUAL_SALES A 
                   INNER JOIN VER 
                ON A.ITEM_MST_ID = VER.ITEM_MST_ID
               AND A.ACCOUNT_ID = VER.ACCOUNT_ID
                   INNER JOIN CAL CA
                ON A.QTY > 0 
               AND A.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
          GROUP BY STRT_DATE
        ) T_ACTUAL_SALES ON T_ACTUAL_SALES.STRT_DATE = M.STRT_DATE-- AND M.END_DATE
			-------------------------------------- 
			-- MEASURE 2 Annual DP 
			-------------------------------------- 
        LEFT OUTER JOIN  (
            SELECT STRT_DATE
                 , CASE WHEN v_OPTION = 'Q' THEN SUM(ANNUAL_QTY) ELSE SUM(ANNUAL_AMT) END QTY 
              FROM TB_DP_MEASURE_DATA A 
                   INNER JOIN VER 
                ON A.ITEM_MST_ID = VER.ITEM_MST_ID
               AND A.ACCOUNT_ID = VER.ACCOUNT_ID
                   INNER JOIN 
                   CAL CA
                ON A.ANNUAL_QTY > 0 
               AND A.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
          GROUP BY STRT_DATE
        ) T_ANNUAL_DP  ON T_ANNUAL_DP.STRT_DATE = M.STRT_DATE
			-------------------------------------- 
			--  MEASURE 4 Final DP 
			-------------------------------------- 
        LEFT OUTER JOIN (
            SELECT STRT_DATE
                 , CASE WHEN v_OPTION = 'Q' THEN sum(QTY) ELSE SUM(AMT) END AS QTY 
              FROM TB_DP_ENTRY_HISTORY A 
                       INNER JOIN VER 
                    ON A.ITEM_MST_ID = VER.ITEM_MST_ID
                   AND A.ACCOUNT_ID = VER.ACCOUNT_ID
                   INNER JOIN 
                   CAL CA
                ON A.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
            WHERE A.QTY > 0 
              AND BASE_DATE BETWEEN p_STRT_DATE AND p_END_DATE	
              AND PLAN_TP_ID = p_PLAN_TP_ID								 
         GROUP BY STRT_DATE
        ) T_FINAL_DP  ON T_FINAL_DP.STRT_DATE = M.STRT_DATE
        ;

        p_RT_MSG := 'MSG_0001';

        EXCEPTION WHEN OTHERS THEN  -- ?？? ???？？? ?？? ???？?？ : e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_MSG := sqlerrm;
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;   	
--END TRY
--BEGIN CATCH
--IF (ERROR_MESSAGE() LIKE 'MSG_%')
--	BEGIN
--		SET v_ERR_MSG = ERROR_MESSAGE()
--		SET p_RT_MSG = v_ERR_MSG
--	END
--ELSE 
--		THROW;
----		EXEC SP_COMM_RAISE_ERR

END;

/

