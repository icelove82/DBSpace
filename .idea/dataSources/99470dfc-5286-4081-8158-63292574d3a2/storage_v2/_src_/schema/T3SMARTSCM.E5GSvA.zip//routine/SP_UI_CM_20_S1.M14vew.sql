create PROCEDURE SP_UI_CM_20_S1(
	 p_ITEM_CD				VARCHAR2
	,p_ACCT_CD				VARCHAR2
	,p_BASE_DATE			DATE
	,p_QTY					decimal
	,p_AMT					decimal
	,p_SO_STATUS_ID	        CHAR
	,p_USER_ID				VARCHAR2
	,p_RT_ROLLBACK_FLAG		OUT VARCHAR2
	,p_RT_MSG				OUT VARCHAR2
)IS

p_ERR_STATUS    INT := 0;
p_ERR_MSG       VARCHAR2(4000):='';
p_ITEM_MST_ID	CHAR(32);
p_ACCOUNT_ID    CHAR(32);

BEGIN 
	-- Find ID
	SELECT ID INTO p_ITEM_MST_ID FROM TB_CM_ITEM_MST WHERE ITEM_CD = p_ITEM_CD;
	SELECT ID INTO p_ACCOUNT_ID FROM TB_DP_ACCOUNT_MST WHERE ACCOUNT_CD = p_ACCT_CD;

	-- VALIDATION ABOUT ID 
	IF(p_ITEM_MST_ID IS NULL)
	THEN
		p_ERR_MSG := 'Item Code is not valid';
		RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG);
	END IF;

	IF(p_ACCOUNT_ID IS NULL)
	THEN
		p_ERR_MSG := 'Account Code is not valid';
		RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG);
	END IF;

	MERGE INTO TB_CM_ACTUAL_SALES TGT
		 USING ( SELECT p_ITEM_MST_ID		AS ITEM_MST_ID	
                       ,p_ACCOUNT_ID		AS ACCOUNT_ID	
                       ,p_BASE_DATE		    AS BASE_DATE	
                       ,p_QTY				AS QTY			
                       ,p_AMT				AS AMT			
                       ,p_SO_STATUS_ID	    AS SO_STATUS_ID
                       ,p_USER_ID			AS USER_ID
                       ,SYSDATE			    AS DTTM	
                   FROM DUAL
		 	   ) SRC
			ON (SRC.ITEM_MST_ID = TGT.ITEM_MST_ID
		   AND SRC.ACCOUNT_ID = TGT.ACCOUNT_ID
		   AND SRC.BASE_DATE = TGT.BASE_DATE
		   AND SRC.SO_STATUS_ID = TGT.SO_STATUS_ID)
	WHEN MATCHED THEN 
		 UPDATE SET QTY		    = SRC.QTY
			       ,AMT		    = SRC.AMT
				   ,MODIFY_BY   = SRC.USER_ID
				   ,MODIFY_DTTM = SRC.DTTM
	WHEN NOT MATCHED THEN
		   INSERT  ( ID
				    ,ITEM_MST_ID
				    ,ACCOUNT_ID
				    ,BASE_DATE
				    ,SO_STATUS_ID
				    ,QTY
				    ,AMT
				    ,CREATE_BY
				    ,CREATE_DTTM
				   ) VALUES
				  ( TO_SINGLE_BYTE(SYS_GUID())
				   ,SRC.ITEM_MST_ID
				   ,SRC.ACCOUNT_ID
				   ,SRC.BASE_DATE
				   ,SRC.SO_STATUS_ID
				   ,SRC.QTY
				   ,SRC.AMT
				   ,SRC.USER_ID
				   ,SRC.DTTM
				  );

    p_RT_MSG := 'MSG_0001';
    p_RT_ROLLBACK_FLAG := 'true';

    EXCEPTION WHEN OTHERS THEN
    IF(SQLCODE = -20001)
    THEN
        P_RT_MSG := SQLERRM;   
        p_RT_ROLLBACK_FLAG :='false';
    ELSE
        RAISE;
    END IF; 
--END TRY
--BEGIN CATCH
--	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
--		   BEGIN
--			   SET p_ERR_MSG = ERROR_MESSAGE()
--			   SET p_RT_ROLLBACK_FLAG = 'false'
--			   SET p_RT_MSG = p_ERR_MSG
--			END
--	   ELSE 
--				THROW;
----				EXEC SP_COMM_RAISE_ERR
END;
/

