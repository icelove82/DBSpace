create PROCEDURE                SP_UI_DP_01_D2 (
                                         P_ID            IN  VARCHAR2        
                                          ,P_USER_ID        IN  VARCHAR2
                                        ,P_RT_ROLLBACK_FLAG OUT VARCHAR2   
                                          ,P_RT_MSG           OUT VARCHAR2
                                   ) IS 

  P_ERR_STATUS INT := 0;
        P_ERR_MSG VARCHAR2(4000):='';    
        v_LANG_CONF_GRP_CD VARCHAR2(50) :='';
        v_CONF_GRP_CD      VARCHAR2(50) :='';
BEGIN


        SELECT CONF_GRP_CD||'_'||CONF_CD 
            ,  CONF_GRP_CD
            INTO v_LANG_CONF_GRP_CD, v_CONF_GRP_CD
        FROM TB_CM_COMM_CONFIG
        WHERE ID = p_ID;

        DELETE
        FROM TB_AD_LANG_PACK
        WHERE 1=1
        AND LANG_CD = 'en'
        AND LANG_KEY LIKE 'CF_'||v_LANG_CONF_GRP_CD||'%';

       DELETE 
         FROM TB_CM_COMM_CONFIG 
        WHERE ID = P_ID;

	IF(v_CONF_GRP_CD = 'DP_MS_VAL_TP')
	THEN
        SELECT COUNT(CONF_CD) INTO P_ERR_STATUS
          FROM TB_CM_COMM_CONFIG
         WHERE CONF_GRP_CD = 'DP_MS_VAL_TP'
           AND ACTV_YN = 'Y'
           AND USE_YN = 'Y'
           AND REPLACE(CONF_CD,'QTY','AMT') IN (SELECT CONF_CD 
                                                  FROM TB_CM_COMM_CONFIG 
                                                  WHERE CONF_GRP_CD = 'DP_MS_VAL_TP'
                                                    AND CONF_CD LIKE 'AMT%'
                                                    AND ACTV_YN = 'Y' 
                                                    AND USE_YN = 'Y'
                                               )
     GROUP BY REPLACE(CONF_CD,'QTY','AMT')    
            ;
		IF P_ERR_STATUS = 1 
		THEN
			P_ERR_MSG := 'A pair of quantity codes must also be activated.';
			RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);       	
		END IF
        ;
	END IF		
    ;
/********************************************************************
	-- Measure Setting Data Handling
*********************************************************************/
IF (v_CONF_GRP_CD = 'DP_MS_VAL_TP')
	THEN
		DELETE FROM TB_DP_MEASURE_SETTING
		 WHERE MEASURE_VAL_TP_ID = P_ID
         ;
	END IF
    ;

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0002';

        EXCEPTION
        WHEN OTHERS THEN
              IF(SQLCODE = -20001)
              THEN
                  P_ERR_MSG := SQLERRM;
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;       

END 
;
/

