create PROCEDURE                "SP_UI_DP_15_POP_S1" (
									   P_EMP_NO           IN VARCHAR2      := ''      									 
									  ,P_AUTH_TP_ID       IN VARCHAR2      := ''   
									  ,p_ACCOUNT_ID         IN VARCHAR2      := '' 
									  ,p_ITEM_MST_ID        IN VARCHAR2      := ''     
                                      ,P_UI_ID              IN VARCHAR2    
									  ,P_RT_MSG             OUT VARCHAR2 
				                   ) 
IS
/*************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 
    -                        / Mssql converting
************************************************************************/
      p_ERR_STATUS_1 INT;
      p_ERR_STATUS_2 INT;
BEGIN 
    P_RT_MSG := 'MSG_0003';  

IF (P_EMP_NO IS NULL)
	THEN
	   P_RT_MSG := 'MSG_0014' ;
	END IF;
IF (P_AUTH_TP_ID IS NULL)
    THEN
        P_RT_MSG :='Authority type is necessary';    
    END IF;
IF (P_ACCOUNT_ID IS NULL)
    THEN
        P_RT_MSG :='MSG_0015';
    END IF;
IF (P_ITEM_MST_ID IS NULL)
    THEN
        P_RT_MSG :='MSG_0017';
    END IF;
-- Account + Item 의 1개의 값은 1명의 User만 담당할 수 있다. 중복된 데이터가 있는 경우 msg
SELECT COUNT(1) INTO P_ERR_STATUS_1
  FROM TB_DP_USER_ITEM_ACCOUNT_MAP UI 
 WHERE UI.ACCOUNT_ID = p_ACCOUNT_ID 
   AND UI.ITEM_MST_ID = p_ITEM_MST_ID 
   AND UI.AUTH_TP_ID = P_AUTH_TP_ID 
   ;

SELECT COUNT(1) INTO P_ERR_STATUS_2
  FROM TB_DP_USER_ITEM_ACCOUNT_EXCLUD UI 
 WHERE UI.ACCOUNT_ID = p_ACCOUNT_ID 
   AND UI.ITEM_MST_ID = p_ITEM_MST_ID 
   AND UI.AUTH_TP_ID = P_AUTH_TP_ID 
   ;

IF P_ERR_STATUS_1 > 0 AND p_UI_ID like 'UI_DP_15%'
	THEN
        P_RT_MSG := 'MSG_0013'  ;
        RAISE_APPLICATION_ERROR(-20001, P_RT_MSG);
ELSIF P_ERR_STATUS_2 > 0 AND p_UI_ID like 'UI_DP_37%'	
    THEN
        P_RT_MSG := 'MSG_0013' ;
        RAISE_APPLICATION_ERROR(-20001, P_RT_MSG);
	END IF;	

EXCEPTION WHEN OTHERS THEN
    IF SQLCODE = -20001 THEN
        P_RT_MSG := P_RT_MSG;
    ELSE
        RAISE;
    END IF;
END;
/

