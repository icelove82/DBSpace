create PROCEDURE                  "SP_UI_BF_54_CHART_Q1" 
(
    p_ITEM_CD		VARCHAR2
   ,p_ITEM_NM		VARCHAR2
   ,p_ACCOUNT_CD    VARCHAR2
   ,p_ACCOUNT_NM    VARCHAR2
   ,p_VER_CNT		INT		 := 4
   ,p_ENGINE_TP_CD	VARCHAR2 := 'RF'
   ,p_ERR_TP		VARCHAR2
   ,pRESULT         OUT SYS_REFCURSOR
)
IS 
/***************************************************************************************************************
	-- MSSQL 2020.06.19 / KSH / draft
    -- 2020.12.07 / MKH / CONVERSION
**************************************************************************************************************/

p_FROM_DATE	    DATE :='';
p_TO_DATE		DATE :='';
p_BUKT		    VARCHAR2(2):='';
p_VER_CD		VARCHAR2(30):='';
p_PREV_TO_DATE  DATE :='';	
v_ERR_TP        VARCHAR2(10):='';

BEGIN
--	DECLARE TB_TMP_CB TABLE
--	(  VER_CD NVARCHAR(30)
--	 , RW     INT 
--	)
	WITH TB_TMP_CB AS (
        SELECT DISTINCT 
               VER_CD 
             , RW 	  
          FROM (
                SELECT VER_CD 
                     , ROW_NUMBER() OVER (ORDER BY VER_CD DESC) AS RW
                  FROM TB_BF_CONTROL_BOARD_VER_DTL
                 WHERE PROCESS_NO = '990000'
                   AND STATUS = 'Completed'
           ) A
         WHERE RW BETWEEN 2 AND p_VER_CNT+1 --<= p_VER_CNT  
    )
    SELECT MIN(TARGET_FROM_DATE)	 
         , MAX(TARGET_BUKT_CD)
           INTO
           p_FROM_DATE
         , p_BUKT
      FROM TB_BF_CONTROL_BOARD_VER_DTL A
     WHERE VER_CD IN (SELECT VER_CD FROM TB_TMP_CB)
       AND ENGINE_TP_CD = p_ENGINE_TP_CD
     ;

    p_TO_DATE := SYSDATE;

    SELECT COALESCE(p_ERR_TP,CONF_CD) INTO v_ERR_TP
      FROM TB_CM_COMM_CONFIG
    WHERE CONF_GRP_CD = 'BF_SELECT_CRITERIA'
      AND DEFAT_VAL = 'Y'
      AND ACTV_YN = 'Y' 
      ;
	/*************************************************************************************************************
		-- ???? ???? ???? ????? ??? ?????? ???? ??? ???? ???? ???
	************************************************************************************************************/
	IF (p_BUKT = 'W')
	THEN
		SELECT MAX(END_DATE) INTO p_TO_DATE
		  FROM (
				SELECT --YYYY
					   DP_WK
					 , MIN(DAT) AS STRT_DATE
					 , MAX(DAT) AS END_DATE
				  FROM TB_CM_CALENDAR C
				 WHERE DAT BETWEEN p_FROM_dATE AND p_TO_DATE
			  GROUP BY DP_WK
			  HAVING COUNT(DP_WK) >= 7
			  ) A
            ;
	END IF; 

    OPEN pRESULT FOR
    WITH TB_TMP_CB AS (
        SELECT DISTINCT 
               VER_CD 
             , RW 	  
          FROM (
                SELECT VER_CD 
                     , ROW_NUMBER() OVER (ORDER BY VER_CD DESC) AS RW
                  FROM TB_BF_CONTROL_BOARD_VER_DTL
                 WHERE PROCESS_NO = '990000'
                   AND STATUS = 'Completed'
           ) A
         WHERE RW BETWEEN 2 AND p_VER_CNT+1 --<= p_VER_CNT  
    )
    , CB AS (
        SELECT DTL.VER_CD	
             , DTL.TARGET_FROM_DATE	 
             , DTL.TARGET_TO_DATE	 
             , CB.RW
          FROM TB_BF_CONTROL_BOARD_VER_DTL DTL
               INNER JOIN
               TB_TMP_CB  CB
            ON CB.VER_CD = DTL.VER_CD
         WHERE ENGINE_TP_CD = p_ENGINE_TP_CD
    ), 
    CALENDAR AS (
        SELECT DAT
--             , YYYY
--             , YYYYMM
--             , CASE p_BUKT
--                 WHEN 'W' THEN TO_NUMBER(TO_CHAR(DAT,'IW'))
--                 WHEN 'PW' THEN TO_NUMBER(TO_CHAR(DAT,'IW'))
--                 WHEN 'M' THEN TO_NUMBER(YYYYMM)
--               END AS BUKT
             , CASE p_BUKT
                --WHEN 'W' THEN YYYY+' w'+CONVERT(NVARCHAR(2),DP_WK)
                --WHEN 'PW'THEN YYYYMM+' w'+CONVERT(NVARCHAR(2),DP_WK) 
                WHEN 'W'   THEN YYYY || ' w' || DP_WK --LPAD(DP_WK, 2, '0')
                WHEN 'PW'  THEN YYYYMM || ' w' || DP_WK --LPAD(DP_WK, 2, '0')
                WHEN 'M' THEN YYYYMM
               END AS BUKT	
          FROM TB_CM_CALENDAR
         WHERE DAT BETWEEN p_FROM_DATE AND p_TO_DATE
    ), 
    CAL AS (
        SELECT MIN(DAT)	 AS STRT_DATE
             , MAX(DAT)  AS END_DATE
             , COUNT(DAT) AS CNT
             , BUKT
--             , CASE p_BUKT
--                 WHEN 'W' THEN MIN(YYYY) || '-' || LPAD(BUKT, 2, '0')
--                 WHEN 'PW' THEN MIN(YYYYMM) || '-' || LPAD(BUKT, 2, '0')
--                 WHEN 'M' THEN MIN(YYYYMM)
--               END AS BUKT
          FROM CALENDAR
      GROUP BY BUKT
    )
    , 
--    VER_CAL AS(
--        SELECT STRT_DATE
--             , END_DATE
--             , CNT
--             , BUKT
--             , VER_CD
--        FROM CAL CA
--            INNER JOIN
--            CB
--          ON CA.STRT_DATE BETWEEN CB.TARGET_FROM_DATE AND CB.TARGET_TO_DATE 
--    )
    VER_CAL AS (
        SELECT MIN(DAT)	  AS STRT_DATE
             , MAX(DAT)	  AS END_DATE
             , count(DAT) AS CNT
             , BUKT
             , VER_CD 
          FROM CALENDAR CA
               INNER JOIN
               CB 
            ON CA.DAT BETWEEN CB.TARGET_FROM_DATE AND CB.TARGET_TO_DATE
      GROUP BY VER_CD, BUKT
    )
    ,RT AS (
         SELECT BASE_DATE
              , ENGINE_TP_CD
              , QTY
              , CA.BUKT
              , VER_CD
           FROM TB_BF_RT  RH
                INNER JOIN
               CALENDAR CA 
           ON  RH.BASE_DATE = CA.DAT 
          WHERE ITEM_CD = p_ITEM_CD
            AND ACCOUNT_CD = p_ACCOUNT_CD 
            AND VER_CD IN (SELECT VER_CD FROM CB)
            AND ENGINE_TP_CD = p_ENGINE_TP_CD
       )
    ,SA AS (
        SELECT  CAL.BUKT
              , SUM(COALESCE(CASE CORRECTION_YN WHEN 'Y' THEN QTY_CORRECTION ELSE QTY END,0 ))		AS QTY
              , AVG(COALESCE(CASE CORRECTION_YN WHEN 'Y' THEN QTY_CORRECTION ELSE QTY END,0 ))		AS AVG_QTY
              , SUM(COALESCE(CASE CORRECTION_YN WHEN 'Y' THEN AMT_CORRECTION ELSE AMT END,0 ))		AS AMT  
          FROM TB_CM_ACTUAL_SALES S
               INNER JOIN
               TB_CM_ITEM_MST I
            ON S.ITEM_MST_ID = I.ID
           AND COALESCE(I.DEL_YN, 'N') = 'N'
           AND ITEM_CD = p_ITEM_CD
               INNER JOIN
               TB_DP_ACCOUNT_MST A
            ON A.ID = S.ACCOUNT_ID
           AND A.ACTV_YN = 'Y' 
           AND COALESCE(A.DEL_YN, 'N') = 'N'
           AND ACCOUNT_CD = p_ACCOUNT_CD 
           	  INNER JOIN
              CALENDAR MCA 
           ON S.BASE_DATE = MCA.DAT 
              INNER JOIN
              CAL 
           ON MCA.BUKT = CAL.BUKT
         WHERE BASE_DATE BETWEEN p_FROM_DATE AND p_TO_DATE	
      GROUP BY I.ITEM_CD
             , A.ACCOUNT_CD
             , CAL.BUKT	
    ), M
    AS (
        SELECT ROW_NUMBER() OVER (PARTITION BY VC.VER_CD ORDER BY VC.BUKT) AS BUKT
            ,  VC.VER_CD
            ,  ABS(SA.QTY - RT.QTY)								AS ERR
            ,  RT.QTY											AS FCS
            ,  COALESCE(TO_NUMBER(SA.QTY), 0.00000000001) AS SALES_QTY
            ,  TO_NUMBER(SA.AVG_QTY)				AS SALES_AVG
          FROM VER_CAL VC
               LEFT OUTER JOIN
               RT
            ON VC.BUKT = RT.BUKT
           AND VC.VER_CD = RT.VER_CD
               LEFT OUTER JOIN
               SA    
            ON VC.BUKT = SA.BUKT 
           AND SA.QTY != 0
    )
	SELECT BUKT 
		 , VER_CD 
		,  CASE v_ERR_TP
				--WHEN 'MAPE'		THEN (CASE WHEN COALESCE(SALES_QTY,0) = 0 THEN NULL ELSE ABS(ERR)/SALES_QTY	/ DATE_CNT*100			END	)
				WHEN 'MAPE'		THEN (CASE WHEN COALESCE(SALES_QTY,0) = 0 THEN NULL ELSE ABS(ERR)/SALES_QTY * 100 END	 )
				WHEN 'MAE'		THEN ABS(ERR)					 
				WHEN 'MAE_P'	THEN (CASE WHEN COALESCE(SALES_QTY,0) = 0 THEN NULL ELSE ABS(ERR)/ SALES_QTY * 100						END)
				WHEN 'RMSE'		THEN SQRT(ABS(ERR)*ABS(ERR))			 
				WHEN 'RMSE_P'	THEN (CASE WHEN COALESCE(SALES_QTY,0) = 0 THEN NULL ELSE SQRT(ABS(ERR)*ABS(ERR))/SALES_QTY * 100		END)
				--WHEN 'WAPE'		THEN ABS(SALES_AVG-FCS)/SALES_AVG	/ DATE_CNT*100 
				WHEN 'WAPE'		THEN  CASE WHEN FCS IS NULL 							   THEN NULL
										   WHEN ABS(SALES_QTY-FCS) = 0 AND SALES_QTY = 0   THEN 1
										   WHEN ABS(SALES_QTY-FCS) = 0 					   THEN 1/SALES_QTY
										   WHEN SALES_QTY = 0							   THEN 1/ABS(SALES_QTY-FCS)
										   ELSE (CASE WHEN ABS(SALES_QTY-FCS)/SALES_QTY<=1 THEN ABS(SALES_QTY-FCS)/SALES_QTY ELSE 1 END) 
										   END * 100
		    END		AS ERROR
	  FROM M	
    ;
END;

/

