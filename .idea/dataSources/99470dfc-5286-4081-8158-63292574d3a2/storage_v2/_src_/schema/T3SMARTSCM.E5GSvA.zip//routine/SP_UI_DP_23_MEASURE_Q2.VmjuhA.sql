create PROCEDURE "SP_UI_DP_23_MEASURE_Q2" 
(
 p_VERSION_ID  IN VARCHAR2 := ''
,P_MEASURE_CD  IN VARCHAR2 := ''
,p_START_DATE IN DATE
,p_END_DATE IN DATE
, pRESULT       OUT SYS_REFCURSOR
, P_RT_MSG      OUT VARCHAR2
) 
IS 

    V_START_MONTH               CHAR(2);
    V_START_YEAR                CHAR(4);
    V_PLAN_TP_ID                CHAR(32);
		P_ERR_STATUS INT := 0;
        P_ERR_MSG VARCHAR2(4000) :='';    
BEGIN

        IF (UPPER(P_MEASURE_CD) NOT LIKE 'ACT_SALES%' AND UPPER(P_MEASURE_CD) NOT LIKE 'YTD%' AND UPPER(P_MEASURE_CD) NOT LIKE 'YOY%' AND UPPER(P_MEASURE_CD) NOT LIKE 'YOY2%' AND UPPER(P_MEASURE_CD) NOT LIKE 'ANNUAL%')
         THEN
            P_ERR_MSG := 'Can not find this Message Code';				
            OPEN pRESULT FOR SELECT '' FROM DUAL;
            RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);                  
        END IF;

       SELECT TO_CHAR(FROM_DATE,'yyyy') 
            , PLAN_TP_ID
         INTO V_START_YEAR
            , V_PLAN_TP_ID
       FROM   TB_DP_CONTROL_BOARD_VER_MST 
       WHERE  VER_ID = p_VERSION_ID             
        ; 

        SELECT LPAD(TO_NUMBER(A.POLICY_VAL), 2, '0') INTO V_START_MONTH
        FROM TB_DP_PLAN_POLICY A
        INNER JOIN TB_CM_COMM_CONFIG B ON B.CONF_GRP_CD ='DP_POLICY' AND B.CONF_CD = 'SM' AND A.POLICY_ID = B.ID       
        where PLAN_TP_ID = V_PLAN_TP_ID
        ;

OPEN pRESULT          
FOR 
    SELECT 
                     ITEM_CD
                    , ACCOUNT_CD
                    , MIN(BASE_DATE) AS BASE_DATE 
                    --, BUCKET
                    , SUM(ACT_QTY) AS ACT_SALES_QTY 
                    , SUM(ACT_AMT) AS ACT_SALES_AMT
                    , SUM(ANN_QTY) AS ANNUAL_QTY
                    , SUM(ANN_AMT) AS ANNUAL_AMT
                    , SUM(YoY_QTY) AS YOY_QTY
                    , SUM(YoY_AMT) AS YOY_AMT
                    , SUM(YoY2_QTY) AS YOY2_QTY
                    --, SUM(YoY2_AMT) AS YOY2_AMT
                    --, SUM(YoY3_QTY) AS YOY3_QTY
                    --, SUM(YoY3_AMT) AS YOY3_AMT
                    , SUM(YTD_QTY)  AS YTD_QTY
                    , SUM(YTD_AMT)  AS YTD_AMT
                    FROM    (
                                -- Actual Sales @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                                SELECT /*+ Use index (TB_CM_ACTUAL_SALES  IDX_TB_CM_ACTUAL_SALES2*/ 
                                     i.ITEM_CD
                                    ,a.ACCOUNT_CD
                                    ,H.POLICY_VAL  AS BUCKET 
                                    ,CA.YYYY, CA.YYYYMM,CA.YYYYMMDD, CA.WK52, CA.PARTWK 
                                    ,s.BASE_DATE AS BASE_DATE
                                    ,QTY    AS ACT_QTY
                                    ,AMT    AS ACT_AMT 
                                    , 0     AS ANN_QTY
                                    , 0     AS ANN_AMT    
                                    , 0     AS YoY_QTY
                                    , 0     AS YoY_AMT
                                    , 0     AS YoY2_QTY
                                    , 0     AS YoY2_AMT
                                    , 0     AS YoY3_QTY
                                    , 0     AS YoY3_AMT
                                    , 0     AS YTD_QTY
                                    , 0     AS YTD_AMT
                                    , 'ACT_SALES' AS MEASURE_CD
                                FROM TB_CM_ACTUAL_SALES s
                                inner join TB_CM_ITEM_MST i on s.ITEM_MST_ID = i.ID and (i.DEL_YN = 'N' or i.DEL_YN is null) AND i.DP_PLAN_YN = 'Y'
                                inner join TB_DP_ACCOUNT_MST a on s.ACCOUNT_ID = a.ID and (a.DEL_YN = 'N' or a.DEL_YN is null)
                                inner JOIN (
                                            SELECT A.POLICY_VAL
                                            FROM TB_DP_PLAN_POLICY A
                                            INNER JOIN TB_CM_COMM_CONFIG B ON B.CONF_GRP_CD ='DP_POLICY' AND B.CONF_CD = 'B' AND A.POLICY_ID = B.ID
                                             ) H ON 1=1 -- BUCKET 
                                inner JOIN TB_CM_CALENDAR CA ON s.base_DATE = CA.DAT 
                                where 1=1
                                and qty > 0
                                and s.base_DATE BETWEEN p_START_DATE AND p_END_DATE
                                 UNION ALL                                
                                -- YTD ( ~ Start date) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                                SELECT 
                                     i.ITEM_CD
                                    ,a.ACCOUNT_CD
                                    ,H.POLICY_VAL  AS BUCKET -- BUCKET
                                    ,CA.YYYY, CA.YYYYMM,CA.YYYYMMDD, CA.WK52, CA.PARTWK 
                                    ,p_START_DATE  AS BASE_DATE --'2018-06-01' AS BASE_DATE
                                    , 0     AS ACT_QTY
                                    , 0     AS ACT_AMT 
                                    , 0     AS ANN_QTY
                                    , 0     AS ANN_AMT    
                                    , 0     AS YoY_QTY
                                    , 0     AS YoY_AMT
                                    , 0     AS YoY2_QTY
                                    , 0     AS YoY2_AMT
                                    , 0     AS YoY3_QTY
                                    , 0     AS YoY3_AMT
                                    , SUM(QTY)   AS YTD_QTY
                                    , SUM(AMT)   AS YTD_AMT
                                    , 'YTD'   AS MEASURE_CD                                    
                                FROM TB_CM_ACTUAL_SALES s
                                inner join TB_CM_ITEM_MST i on s.ITEM_MST_ID = i.ID and (i.DEL_YN = 'N' or i.DEL_YN is null) AND i.DP_PLAN_YN = 'Y'
                                inner join TB_DP_ACCOUNT_MST a on s.ACCOUNT_ID = a.ID and (a.DEL_YN = 'N' or a.DEL_YN is null)
                                inner JOIN (
                                            SELECT A.POLICY_VAL
                                            FROM TB_DP_PLAN_POLICY A
                                            INNER JOIN TB_CM_COMM_CONFIG B ON B.CONF_GRP_CD ='DP_POLICY' AND B.CONF_CD = 'B' AND A.POLICY_ID = B.ID
                                             ) H ON 1=1 -- BUCKET 
                                inner JOIN TB_CM_CALENDAR CA ON CA.DAT = p_START_DATE --'2018-06-01' -- 
                                where 1=1
                                and qty > 0
                                --AND i.ITEM_CD = '21131-52910'
                                AND s.base_DATE >= TO_DATE(V_START_YEAR||'-'||V_START_MONTH||'-01', 'yy-MM-dd')
                                AND s.base_DATE < p_START_DATE --'2018-06-01'
                                --and BASE_DATE BETWEEN '2016-06-01' AND '2017-06-01'
                                GROUP BY i.ITEM_CD
                                    ,a.ACCOUNT_CD
                                    ,H.POLICY_VAL   
                                    ,CA.YYYY, CA.YYYYMM,CA.YYYYMMDD, CA.WK52, CA.PARTWK
                                UNION ALL                                
                                -- 1year yoy @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                                SELECT /*+ Use index (TB_CM_ACTUAL_SALES  IDX_TB_CM_ACTUAL_SALES2*/ 
                                     i.ITEM_CD
                                    ,a.ACCOUNT_CD
                                    ,H.POLICY_VAL  AS BUCKET -- BUCKET
                                    ,CA.YYYY, CA.YYYYMM,CA.YYYYMMDD, CA.WK52, CA.PARTWK 
                                    , CA.DAT
                                    , 0     AS ACT_QTY
                                    , 0     AS ACT_AMT  
                                    , 0     AS ANN_QTY
                                    , 0     AS ANN_AMT      
                                    , QTY   AS YoY_QTY
                                    , AMT   AS YoY_AMT
                                    , 0     AS YoY2_QTY
                                    , 0     AS YoY2_AMT
                                    , 0     AS YoY3_QTY
                                    , 0     AS YoY3_AMT
                                    , 0     AS YTD_QTY
                                    , 0     AS YTD_AMT
                                    , 'YOY'   AS MEASURE_CD                                    
                                FROM TB_CM_ACTUAL_SALES s
                                inner join TB_CM_ITEM_MST i on s.ITEM_MST_ID = i.ID and (i.DEL_YN = 'N' or i.DEL_YN is null) AND i.DP_PLAN_YN = 'Y'
                                inner join TB_DP_ACCOUNT_MST a on s.ACCOUNT_ID = a.ID and (a.DEL_YN = 'N' or a.DEL_YN is null)
                                inner JOIN (
                                            SELECT A.POLICY_VAL
                                            FROM TB_DP_PLAN_POLICY A
                                            INNER JOIN TB_CM_COMM_CONFIG B ON B.CONF_GRP_CD ='DP_POLICY' AND B.CONF_CD = 'B' AND A.POLICY_ID = B.ID
                                             ) H ON 1=1 -- BUCKET 
                                inner JOIN TB_CM_CALENDAR CA ON TO_DATE(ADD_MONTHS(s.base_DATE, 12), 'yy-MM-dd') = CA.DAT -- TO_DATE(BASE_DATE, 'yy-MM-dd')
                                where 1=1
                                and qty > 0
                                and TO_DATE(ADD_MONTHS(s.BASE_DATE, 12), 'yy-MM-dd') BETWEEN p_START_DATE AND p_END_DATE
                                UNION ALL                                
                                -- 2year yoy @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                                SELECT /*+ Use index (TB_CM_ACTUAL_SALES  IDX_TB_CM_ACTUAL_SALES2*/ 
                                     i.ITEM_CD
                                    ,a.ACCOUNT_CD
                                    ,H.POLICY_VAL  AS BUCKET -- BUCKET 
                                    ,CA.YYYY, CA.YYYYMM,CA.YYYYMMDD, CA.WK52, CA.PARTWK 
                                    , CA.DAT
                                    , 0     AS ACT_QTY
                                    , 0     AS ACT_AMT  
                                    , 0     AS ANN_QTY
                                    , 0     AS ANN_AMT      
                                    , 0     AS YoY_QTY
                                    , 0     AS YoY_AMT
                                    , QTY   AS YoY2_QTY
                                    , AMT   AS YoY2_AMT
                                    , 0     AS YoY3_QTY
                                    , 0     AS YoY3_AMT
                                    , 0     AS YTD_QTY
                                    , 0     AS YTD_AMT
                                    , 'YOY2'  AS MEASURE_CD
                                FROM TB_CM_ACTUAL_SALES s
                                inner join TB_CM_ITEM_MST i on s.ITEM_MST_ID = i.ID and (i.DEL_YN = 'N' or i.DEL_YN is null) AND i.DP_PLAN_YN = 'Y'
                                inner join TB_DP_ACCOUNT_MST a on s.ACCOUNT_ID = a.ID and (a.DEL_YN = 'N' or a.DEL_YN is null)
                                inner JOIN (
                                            SELECT A.POLICY_VAL
                                            FROM TB_DP_PLAN_POLICY A
                                            INNER JOIN TB_CM_COMM_CONFIG B ON B.CONF_GRP_CD ='DP_POLICY' AND B.CONF_CD = 'B' AND A.POLICY_ID = B.ID
                                             ) H ON 1=1 -- BUCKET 
                                inner JOIN TB_CM_CALENDAR CA ON TO_DATE(ADD_MONTHS(s.base_DATE, 24), 'yy-MM-dd') = CA.DAT 
                                where 1=1
                                and qty > 0
                                --AND i.ITEM_CD = '21131-52910'
                                and TO_DATE(ADD_MONTHS(s.BASE_DATE, 24), 'yy-MM-dd') BETWEEN p_START_DATE AND p_END_DATE
                              )
                                   A
                    WHERE 1=1
                      AND (A.MEASURE_CD||'_QTY' = UPPER(P_MEASURE_CD) OR A.MEASURE_CD||'_AMT' = UPPER(P_MEASURE_CD))
                    GROUP BY  ITEM_CD, ACCOUNT_CD, BUCKET ,  CASE BUCKET WHEN 'Y' THEN YYYY 
                                                                        WHEN 'M' THEN YYYYMM 
                                                                        WHEN 'W' THEN WK52 
                                                                        WHEN 'PW' THEN PARTWK 
                                                                        ELSE YYYYMMDD END
                    ;


	    P_RT_MSG := 'MSG_0002';  
       /* ===========================================================================*/

       EXCEPTION   
        WHEN OTHERS THEN  --  e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF; 
END
;
/

