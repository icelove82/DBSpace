create PROCEDURE                "SP_UI_CM_12_BATCH" (
     P_CHK_ITEM_LV          IN CHAR := NULL
    ,P_ITEM_LV_ID           IN CHAR := NULL
    ,P_CHK_SALES_LV         IN CHAR := NULL
    ,P_SALES_LV_ID          IN CHAR := NULL
    ,P_CHK_ITEM             IN CHAR := NULL
    ,P_ITEM_MST_ID          IN CHAR := NULL
    ,P_CHK_ACCOUNT          IN CHAR := NULL
    ,P_ACCOUNT_ID           IN CHAR := NULL
    ,P_LOCAT_MGMT_ID        IN CHAR := NULL
    ,P_TRANSP_LOTSIZE       IN NUMBER := NULL
    ,P_LOAD_UOM_ID          IN CHAR := NULL
    ,P_OVERWRITE_DATA_YN    IN CHAR := NULL
    ,P_USER_ID              IN VARCHAR2
    ,P_RT_ROLLBACK_FLAG     OUT VARCHAR2
    ,P_RT_MSG               OUT VARCHAR2
)
IS
    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';
    P_LOAD_UOM VARCHAR2(100) := '';
    V_CNT INT :=0;

BEGIN
    P_ERR_MSG := 'MSG_0006';
    IF P_CHK_ITEM_LV = 'Y' AND NVL(P_ITEM_LV_ID, ' ') = ' ' THEN 
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    IF P_CHK_SALES_LV = 'Y' AND NVL(P_SALES_LV_ID, ' ') = ' ' THEN 
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    IF P_CHK_ITEM = 'Y' AND NVL(P_ITEM_MST_ID, ' ') = ' ' THEN 
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
    IF P_CHK_ACCOUNT = 'Y' AND NVL(P_ACCOUNT_ID, ' ') = ' ' THEN 
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
	IF NVL(P_LOCAT_MGMT_ID, ' ') = ' ' THEN
        SELECT COUNT(1) INTO V_CNT FROM TB_IF_DMND_SHPP_MAP;
        IF V_CNT > 0 THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;
    END IF;
    
/********************************************************************************************************************************************************************************
	DP item, account 조합 정보 가져오기
********************************************************************************************************************************************************************************/    
INSERT INTO TEMP_ITEM_ACCOUNT
(
	ITEM_MST_ID,
	ACCOUNT_ID
)
 WITH USERS_INFO
	AS (-- 나와 내 하위 사용자 정보 찾기
        SELECT ANCS_ID 
             , ANCS_ROLE_ID
             , DESC_ID
             , DESC_ROLE_ID 
             , USER_ACCT_YN
         FROM TB_DPD_USER_HIER_CLOSURE US -- 내 매핑 정보가 있으면 내 하위 사용자 매핑 정보는 안본다.  
        WHERE MAPPING_SELF_YN = 'Y'
	 ), ITEM_HIER
	AS (
		SELECT ANCESTER_ID, ANCESTER_CD, DESCENDANT_ID, DESCENDANT_CD FROM TB_DPD_ITEM_HIER_CLOSURE WHERE LEAF_YN = 'Y'
	), SALES_HIER
	AS (
		SELECT ANCESTER_ID, ANCESTER_CD, DESCENDANT_ID, DESCENDANT_CD FROM TB_DPD_SALES_HIER_CLOSURE WHERE LEAF_YN = 'Y'
	), ITEM
	AS (  SELECT CASE WHEN CL.LEAF_YN = 'Y' THEN IM.ITEM_MST_ID ELSE IM.ITEM_LV_ID END	AS ID
						 , CL.LEAF_YN
						 , IM.AUTH_TP_ID 
						 , IM.EMP_ID
				FROM TB_DP_USER_ITEM_MAP IM 
					  INNER JOIN 
					  TB_CM_LEVEL_MGMT CL ON (IM.LV_MGMT_ID = CL.ID 
							  			 AND CL.ACTV_YN = 'Y'
							  			 AND CL.DEL_YN = 'N')
			   WHERE IM.ACTV_YN = 'Y'   
	), ACCT
	AS (-- 내 매핑 ACCT 찾기
			SELECT CASE WHEN CL.LEAF_YN = 'Y' THEN AM.ACCOUNT_ID ELSE AM.SALES_LV_ID END	AS ID
				 , AM.AUTH_TP_ID 
				 , AM.EMP_ID
				 , CL.LEAF_YN
			  FROM TB_DP_USER_ACCOUNT_MAP AM 
				   INNER JOIN
				   TB_CM_LEVEL_MGMT CL
				ON AM.LV_MGMT_ID = CL.ID 
			   AND CL.ACTV_YN = 'Y'
			   AND NVL(CL.DEL_YN, 'N') = 'N'
			 WHERE AM.ACTV_YN = 'Y'	 
	), IA_LEAF
	AS (	
	   SELECT  ACCT.AUTH_TP_ID
			 , ACCT.EMP_ID 
			 , CASE WHEN ITEM.LEAF_YN = 'Y' THEN ITEM.ID ELSE IH.DESCENDANT_ID END		AS ITEM_ID
			 , CASE WHEN ACCT.LEAF_YN = 'Y' THEN ACCT.ID ELSE SH.DESCENDANT_ID END		AS ACCT_ID
		  FROM ACCT		-- ACCT_SH
			   INNER JOIN
			   ITEM		-- ITEM_SH 
			ON ACCT.AUTH_TP_ID = ITEM.AUTH_TP_ID
		   AND ACCT.EMP_ID  = ITEM.EMP_ID
			   INNER JOIN 
			   ITEM_HIER IH ON ( ITEM.ID = IH.ANCESTER_ID )
			   INNER JOIN
			   SALES_HIER SH
			ON ACCT.ID = SH.ANCESTER_ID
	), IA
	AS ( 
        SELECT  
			   USIF.ANCS_ROLE_ID 	ROLE_ID 
			  ,ACCT_ID	ACCOUNT_ID
			  ,ITEM_ID ITEM_MST_ID           
		  FROM IA_LEAF UIAM
			   INNER JOIN
			   USERS_INFO USIF
			ON UIAM.EMP_ID = USIF.DESC_ID
		   AND UIAM.AUTH_TP_ID = USIF.DESC_ROLE_ID
		   AND USIF.USER_ACCT_YN = 'Y' 
		UNION
		SELECT  
			   USIF.ANCS_ROLE_ID  ROLE_ID
			 , ACCOUNT_ID
			 , ITEM_MST_ID           
		  FROM TB_DP_USER_ITEM_ACCOUNT_MAP UIAM	 
			   INNER JOIN
			   USERS_INFO USIF
			ON UIAM.EMP_ID = USIF.DESC_ID
		   AND UIAM.AUTH_TP_ID = USIF.DESC_ROLE_ID
		   AND USIF.USER_ACCT_YN = 'N' 
   
	)
	SELECT DISTINCT
           ITEM_MST_ID
         , ACCOUNT_ID
	  FROM IA			  
		   ;
           
--	/***************************************************************************************************************************************************************************
--	1. TB_DP_USER_ACCOUNT_MAP 기준의 최하단 ACCOUNT 등록
--	***************************************************************************************************************************************************************************/
--    INSERT INTO TEMP_ACCOUNT
--	(
--		ACCOUNT_ID,
--		ACCOUNT_CD
--	)
--    WITH TEMP_SALES_TARGET (LV, P_SALES, C_SALES, SALES_LV_NM, LV_PATH) AS (
--        SELECT	0									AS LV,
--                CAST(NULL AS CHAR(32))              AS P_SALES,
--                A.ID                                AS C_SALES,
--                A.SALES_LV_NM,
--                CAST(A.SALES_LV_NM AS VARCHAR(4000)) AS LV_PATH
--        FROM	TB_DP_SALES_LEVEL_MGMT A
--        WHERE	1 = 1
--        AND		A.ID IN	(
--                        SELECT	ID
--                        FROM	TB_DP_SALES_LEVEL_MGMT
--                        WHERE	ID IN	(
--                                        SELECT	SALES_LV_ID 
--                                        FROM	TB_DP_USER_ACCOUNT_MAP 
--                                        WHERE	SALES_LV_ID IS NOT NULL
--                                        UNION
--                                        SELECT	B.PARENT_SALES_LV_ID
--                                        FROM	TB_DP_USER_ACCOUNT_MAP A
--                                                INNER JOIN TB_DP_ACCOUNT_MST B
--                                                ON B.ID = A.ACCOUNT_ID
--                                        WHERE	A.ACCOUNT_ID IS NOT NULL
--                                        )
--                        AND		ID = CASE WHEN P_CHK_SALES_LV = 'Y' THEN P_SALES_LV_ID ELSE ID END
--                        )
--    ),
--    TEMP_SALES_LV (LV, P_SALES, C_SALES, SALES_LV_NM, LV_PATH) AS (
--        SELECT  LV, P_SALES, C_SALES, SALES_LV_NM, LV_PATH
--        FROM    TEMP_SALES_TARGET
--        UNION   ALL
--        SELECT  A.LV + 1												 AS LV,
--                B.PARENT_SALES_LV_ID									 AS P_SALES,
--                B.ID													 AS C_SALES,
--                B.SALES_LV_NM,
--                CAST(A.LV_PATH || ' / ' || B.SALES_LV_NM AS VARCHAR2(4000)) AS LV_PATH
--        FROM	TEMP_SALES_LV A,
--                TB_DP_SALES_LEVEL_MGMT B
--        WHERE	1 = 1
--        AND		A.C_SALES = B.PARENT_SALES_LV_ID
--    )
--	SELECT	B.ID, B.ACCOUNT_CD
--	FROM	TEMP_SALES_LV A,
--			TB_DP_ACCOUNT_MST B
--	WHERE	A.LV = (SELECT MAX(LV) FROM TEMP_SALES_LV)
--	AND		A.C_SALES = B.PARENT_SALES_LV_ID
--	AND		B.ACTV_YN = 'Y';
--
--	/***************************************************************************************************************************************************************************
--	2. TB_DP_USER_ITEM_MAP 기준의 최하단 ITEM 등록
--	***************************************************************************************************************************************************************************/
--	INSERT INTO TEMP_ITEM
--	(
--		ITEM_MST_ID,
--		ITEM_CD
--	)
--    WITH TEMP_ITEM_TARGET (LV, P_ITEM, C_ITEM, ITEM_LV_NM, LV_PATH) AS (
--        SELECT	0									AS LV,
--                CAST(NULL AS CHAR(32))              AS P_ITEM,
--                A.ID                                AS C_ITEM,
--                A.ITEM_LV_NM,
--                CAST(A.ITEM_LV_NM AS VARCHAR2(4000)) AS LV_PATH
--        FROM	TB_CM_ITEM_LEVEL_MGMT A
--        WHERE	1 = 1
--        AND		A.ID IN	(
--                        SELECT	ID
--                        FROM	TB_CM_ITEM_LEVEL_MGMT
--                        WHERE	ID IN	(
--                                        SELECT	ITEM_LV_ID 
--                                        FROM	TB_DP_USER_ITEM_MAP 
--                                        WHERE	ITEM_LV_ID IS NOT NULL
--                                        UNION
--                                        SELECT	B.PARENT_ITEM_LV_ID
--                                        FROM	TB_DP_USER_ITEM_MAP A
--                                                INNER JOIN TB_CM_ITEM_MST B
--                                                ON B.ID = A.ITEM_MST_ID
--                                        WHERE	A.ITEM_MST_ID IS NOT NULL
--                                        )
--                        AND		ID = CASE WHEN P_CHK_ITEM_LV = 'Y' THEN P_ITEM_LV_ID ELSE ID END
--                        )
--    )
--    ,
--    TEMP_ITEM_LV (LV, P_ITEM, C_ITEM, ITEM_LV_NM, LV_PATH) AS (
--        SELECT  LV, P_ITEM, C_ITEM, ITEM_LV_NM, LV_PATH
--        FROM    TEMP_ITEM_TARGET
--        UNION   ALL
--        SELECT  A.LV + 1                                              AS LV,
--                B.PARENT_ITEM_LV_ID                                   AS P_ITEM,
--                B.ID                                                  AS C_ITEM,
--                B.ITEM_LV_NM,
--                CAST(A.LV_PATH || ' / ' || B.ITEM_LV_NM AS VARCHAR2(4000)) AS LV_PATH 
--        FROM	TEMP_ITEM_LV A,
--                TB_CM_ITEM_LEVEL_MGMT B
--        WHERE	1 = 1
--        AND		A.C_ITEM = B.PARENT_ITEM_LV_ID
--    )
--	SELECT	B.ID, B.ITEM_CD
--    FROM	TEMP_ITEM_LV A,
--			TB_CM_ITEM_MST B
--	WHERE	A.LV = (SELECT MAX(LV) FROM TEMP_ITEM_LV)
--	AND		A.C_ITEM = B.PARENT_ITEM_LV_ID
--	AND		B.DEL_YN = 'N'
--	AND		B.DP_PLAN_YN = 'Y';
--
--	/***************************************************************************************************************************************************************************
--	3. DEMAND 대상 ITEM, ACCOUNT 등록
--	 - 최하단의 ITEM, ACCOUNT의 조합과 TB_DP_USER_ITEM_ACCOUNT_MAP 데이터
--	 - ITEM, ACCOUNT 매핑 정보가 없으면 전체 조합으로 생성
--	***************************************************************************************************************************************************************************/
--	INSERT INTO TEMP_ITEM_ACCOUNT
--	(
--		ITEM_MST_ID,
--		ACCOUNT_ID
--	)
--	SELECT	A.ITEM_MST_ID,
--			A.ACCOUNT_ID
--	FROM	(
--			SELECT	A.ITEM_MST_ID, 
--					B.ACCOUNT_ID
--			FROM	TEMP_ITEM A,
--					TEMP_ACCOUNT B
--			UNION
--			SELECT	A.ITEM_MST_ID, 
--					A.ACCOUNT_ID
--			FROM	TB_DP_USER_ITEM_ACCOUNT_MAP A,
--					TB_DP_ACCOUNT_MST B,
--					TB_CM_ITEM_MST C
--			WHERE	B.ID = A.ACCOUNT_ID
--			AND		C.ID = A.ITEM_MST_ID
--			AND		B.ACTV_YN = 'Y'
--			AND		C.DEL_YN = 'N'
--			AND		C.DP_PLAN_YN = 'Y'
--			) A
--	WHERE	1=1
--	AND		A.ITEM_MST_ID = CASE WHEN P_CHK_ITEM = 'Y' THEN P_ITEM_MST_ID ELSE A.ITEM_MST_ID END
--	AND		A.ACCOUNT_ID  = CASE WHEN P_CHK_ACCOUNT = 'Y' THEN P_ACCOUNT_ID ELSE A.ACCOUNT_ID END
--	GROUP	BY A.ITEM_MST_ID, A.ACCOUNT_ID;
--    
--    SELECT  1 INTO V_CNT
--    FROM    TEMP_ITEM_ACCOUNT;
--    
--    IF V_CNT > 0 THEN
--		INSERT INTO TEMP_ITEM_ACCOUNT
--		(
--			ITEM_MST_ID,
--			ACCOUNT_ID
--		)
--		SELECT	A.ITEM_MST_ID,
--				A.ACCOUNT_ID
--		FROM	(
--				SELECT	B.ID AS ITEM_MST_ID,
--						A.ID AS ACCOUNT_ID
--				FROM	TB_DP_ACCOUNT_MST A,
--						TB_CM_ITEM_MST B
--				WHERE	A.ACTV_YN = 'Y'
--				AND		B.DEL_YN = 'N'
--				AND		B.DP_PLAN_YN = 'Y'
--				) A
--		WHERE	1=1
--		AND		A.ITEM_MST_ID = CASE WHEN P_CHK_ITEM = 'Y' THEN P_ITEM_MST_ID ELSE A.ITEM_MST_ID END
--		AND		A.ACCOUNT_ID  = CASE WHEN P_CHK_ACCOUNT = 'Y' THEN P_ACCOUNT_ID ELSE A.ACCOUNT_ID END
--		GROUP	BY A.ITEM_MST_ID, A.ACCOUNT_ID;    
--    END IF;

	/***************************************************************************************************************************************************************************
	4. 데이터 덮어쓰기 
	 - 옵션 설정된 경우 관련 데이터 모두 삭제
	***************************************************************************************************************************************************************************/
	IF P_OVERWRITE_DATA_YN = 'Y' THEN
		DELETE FROM TB_CM_DMND_SHPP_MAP_MST;
	END IF;

	/***************************************************************************************************************************************************************************
	5. TB_CM_DMND_SHPP_MAP_MST 데이터 생성
	 - ITEM, ACCOUNT 매핑과 출하지 거점 정보 등록
	 - P_LOCAT_MGMT_ID 파라미터 값이 NULL인 경우
	  : TB_IF_DMND_SHPP_MAP : IF 정보 참조하여 등록
	  : ITEM, ACCOUNT 매핑되는 출하지 거점 정보가 없는 경우 등록 안함
	***************************************************************************************************************************************************************************/
	INSERT INTO TEMP_DMND_SHPP_MAP_MST
	(
		ID,
		ITEM_MST_ID,
		ACCOUNT_ID,
		LOCAT_MGMT_ID
	)
	SELECT	TO_SINGLE_BYTE(SYS_GUID()),
			A.ITEM_MST_ID,
			A.ACCOUNT_ID,
            CASE WHEN NVL(P_LOCAT_MGMT_ID, ' ') = ' ' THEN B.LOCAT_MGMT_ID ELSE P_LOCAT_MGMT_ID END
	FROM	TEMP_ITEM_ACCOUNT A
			LEFT OUTER JOIN 
			(
			SELECT	B.ID AS ITEM_MST_ID,
					C.ID AS ACCOUNT_ID,
					E.ID AS LOCAT_MGMT_ID
			FROM	TB_IF_DMND_SHPP_MAP A,
					TB_CM_ITEM_MST B,
					TB_DP_ACCOUNT_MST C,
					TB_CM_LOC_DTL D,
					TB_CM_LOC_MGMT E
			WHERE	B.ITEM_CD = A.ITEM_CD
			AND		C.ACCOUNT_CD = A.ACCOUNT_CD
			AND		D.LOCAT_CD = A.LOCAT_CD
			AND		D.ID = E.LOCAT_ID
			) B
			ON B.ITEM_MST_ID = A.ITEM_MST_ID
			AND B.ACCOUNT_ID = A.ACCOUNT_ID
	WHERE	NOT EXISTS	(
						SELECT	1
						FROM	TB_CM_DMND_SHPP_MAP_MST X
						WHERE	X.ITEM_MST_ID = A.ITEM_MST_ID
						AND		X.ACCOUNT_ID = A.ACCOUNT_ID
						);
    
    V_CNT :=0;
    SELECT COUNT(1) INTO V_CNT FROM TEMP_DMND_SHPP_MAP_MST;
    IF (V_CNT > 0)
    THEN
		INSERT INTO TEMP_DMND_SHPP_MAP_MST
		(
			ID,
			ITEM_MST_ID,
			ACCOUNT_ID,
			LOCAT_MGMT_ID
		)
		SELECT	TO_SINGLE_BYTE(SYS_GUID()),
				B.ID AS ITEM_MST_ID,
				C.ID AS ACCOUNT_ID,
				CASE WHEN NVL(P_LOCAT_MGMT_ID, ' ') = ' ' THEN E.ID ELSE P_LOCAT_MGMT_ID END
		FROM	TB_IF_DMND_SHPP_MAP A,
				TB_CM_ITEM_MST B,
				TB_DP_ACCOUNT_MST C,
				TB_CM_LOC_DTL D,
				TB_CM_LOC_MGMT E
		WHERE	B.ITEM_CD = A.ITEM_CD
		AND		C.ACCOUNT_CD = A.ACCOUNT_CD
		AND		D.LOCAT_CD = A.LOCAT_CD
		AND		D.ID = E.LOCAT_ID
		AND 	NOT EXISTS	(
							SELECT	1
							FROM	TB_CM_DMND_SHPP_MAP_MST X
							WHERE	X.ITEM_MST_ID = B.ID
							AND		X.ACCOUNT_ID = C.ID
							);
    END IF;

	INSERT INTO TB_CM_DMND_SHPP_MAP_MST
	(
		ID,
		ITEM_MST_ID,
		ACCOUNT_ID,
		LOCAT_MGMT_ID,
		ACTV_YN,
		CREATE_BY,
		CREATE_DTTM
	)
	SELECT	A.ID,
			A.ITEM_MST_ID,
			A.ACCOUNT_ID,
			A.LOCAT_MGMT_ID,
			'Y',
			P_USER_ID,
			SYSDATE
	FROM	TEMP_DMND_SHPP_MAP_MST A
	WHERE	A.LOCAT_MGMT_ID IS NOT NULL;

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0003';

EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;
      ELSE
        RAISE;
      END IF;

END;
/

