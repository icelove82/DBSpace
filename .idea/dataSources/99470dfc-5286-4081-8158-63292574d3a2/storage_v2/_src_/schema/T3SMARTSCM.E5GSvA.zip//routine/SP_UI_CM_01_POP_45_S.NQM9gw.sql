create PROCEDURE        "SP_UI_CM_01_POP_45_S" (
	 P_ID                       IN VARCHAR2 := ''
    ,P_INCOTERMS                IN VARCHAR2 := ''
    ,P_CUST_DELIVY_MODELING_YN  IN VARCHAR2 := ''
    ,P_ACTV_YN                  IN VARCHAR2 := ''
    ,P_USER_ID	                IN VARCHAR2 := ''
    ,P_WRK_TYPE	                IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG         OUT VARCHAR2 
    ,P_RT_MSG                   OUT VARCHAR2
    
)
IS

    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';
    P_CONF_ID VARCHAR2(32) := '';

BEGIN
IF P_WRK_TYPE = 'SAVE'
THEN

    SELECT ID INTO P_CONF_ID FROM TB_CM_CONFIGURATION WHERE CONF_KEY='045';

        P_ERR_MSG := 'MSG_0005'; --'？？？？ ？？ ？？？？？？ ？？？？？？？ ？？？ ？？？？？？？？.'
		   SELECT COUNT(*) INTO P_ERR_STATUS
			 FROM TB_CM_INCOTERMS A
			WHERE 1=1
			  AND A.ID <> P_ID
			  AND A.INCOTERMS = P_INCOTERMS;
		   IF P_ERR_STATUS > 0 THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
           END IF;

        P_ERR_MSG := 'MSG_0006'; --'？？？ ？？？ ？？？？ ？？μ？？？ ？？？？？？？.'
            IF NVL(P_INCOTERMS,'') ='' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;           

    MERGE INTO TB_CM_INCOTERMS B 
			USING (SELECT P_ID AS ID FROM DUAL) A
					ON     (B.ID = A.ID)

			WHEN MATCHED THEN

				UPDATE 
				   SET ACTV_YN						= P_ACTV_YN
					 , CUST_DELIVY_MODELING_YN		= P_CUST_DELIVY_MODELING_YN
					 , INCOTERMS					= P_INCOTERMS
					 , MODIFY_BY					= P_USER_ID
					 , MODIFY_DTTM					= SYSDATE()

			WHEN NOT MATCHED THEN
			INSERT (
				-- ？？？？？？
				ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
				-- ？？？？？？？？
				, ACTV_YN
				, CUST_DELIVY_MODELING_YN
				, INCOTERMS
				, CONF_ID
				)
			VALUES 
		  	    (
				-- ？？？？？？
				TO_SINGLE_BYTE(SYS_GUID()), P_USER_ID, SYSDATE(), P_USER_ID, SYSDATE()
				-- ？？？？？？？？
				, P_ACTV_YN
				, P_CUST_DELIVY_MODELING_YN
				, P_INCOTERMS	
				, P_CONF_ID	
			);

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';  --？？？？ ？？？？？？？？.

ELSIF P_WRK_TYPE = 'DELETE'
THEN

    DELETE FROM TB_CM_INCOTERMS
			WHERE ID = P_ID;

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0002';

END IF;

        EXCEPTION
        WHEN OTHERS THEN
            P_RT_ROLLBACK_FLAG := 'false';
            IF(SQLCODE = -20012)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF; 

END;

/

