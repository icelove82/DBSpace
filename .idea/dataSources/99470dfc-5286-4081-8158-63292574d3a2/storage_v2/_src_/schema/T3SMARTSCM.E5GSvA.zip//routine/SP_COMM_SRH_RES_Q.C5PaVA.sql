create PROCEDURE "SP_COMM_SRH_RES_Q" (

     P_LOCAT_TP	    IN VARCHAR2 :=''
    ,P_LOCAT_CD	    IN VARCHAR2 :=''
    ,P_LOCAT_NM	    IN VARCHAR2 :=''
    ,P_RES_CD	    IN VARCHAR2 :=''
    ,pResult OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN pResult FOR
        SELECT  A.COMN_CD_NM	AS LOCAT_TP_NM
			,B.LOCAT_LV
			,C.LOCAT_CD
			,C.LOCAT_NM
			,E.ROUTE_GRP
			,E.WC
			,F.ID			    AS RES_DTL_ID
			,F.RES_CD
			,F.RES_DESCRIP      
		FROM TB_AD_COMN_CODE A
			INNER JOIN 
			TB_CM_LOC_MST B
		ON (A.ID = B.LOCAT_TP_ID)
			INNER JOIN 
			TB_CM_LOC_DTL C
		ON (B.ID = C.LOCAT_MST_ID)
			INNER JOIN 
			TB_CM_LOC_MGMT D
		ON (C.ID = D.LOCAT_ID)
			INNER JOIN 
			TB_MP_RES_MGMT_MST E
		ON (D.ID = E.LOCAT_MGMT_ID)
			INNER JOIN 
			TB_MP_RES_MGMT_DTL F
		ON (E.ID = F.RES_MGMT_MST_ID)
	 ------------------------------------------
	 -- ？？？ ？？？？
	 ------------------------------------------
	  WHERE UPPER(A.COMN_CD_NM) LIKE '%' || P_LOCAT_TP || '%'
	    AND C.LOCAT_CD LIKE '%' || P_LOCAT_CD || '%'
		AND C.LOCAT_NM LIKE '%' || P_LOCAT_NM || '%'
		AND F.RES_CD LIKE '%' || P_RES_CD || '%'
      ORDER BY A.SEQ, B.LOCAT_LV, C.LOCAT_CD, F.RES_CD;

END;
/

