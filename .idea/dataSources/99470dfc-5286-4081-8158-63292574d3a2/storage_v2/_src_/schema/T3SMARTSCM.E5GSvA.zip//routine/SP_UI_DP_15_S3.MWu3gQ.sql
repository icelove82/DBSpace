create PROCEDURE          SP_UI_DP_15_S3  (
									    p_FROM_EMP_NO	     VARCHAR2      
									  , p_TO_EMP_NO			 VARCHAR2  
									  , p_AUTH_TP_ID         CHAR 
									  , p_TRANFER_TYPE       VARCHAR2 
									  , p_USER_ID            VARCHAR2 
									  , P_RT_ROLLBACK_FLAG OUT   VARCHAR2  
									  , P_RT_MSG           OUT   VARCHAR2  
				                   ) 
IS

/*****************************************************************************
Title : SP_DP_15_S3
 
설명 
 - DP User Mapping(Item&Account)
 
History (수정일자 / 수정자 / 수정내용)
- 2022.11.22 /hanguls / create
*****************************************************************************/
    P_ERR_TYPE                 VARCHAR2(32)      := NULL   ;
   P_FROM_EMP_ID                   VARCHAR2(32)      := NULL ;
   P_TO_EMP_ID                   VARCHAR2(32)      := NULL ;

  P_ERR_STATUS INT := 0;
  P_ERR_MSG VARCHAR2(4000) :='';


BEGIN 

-- EMPLOYEE 가 선택되지 않은 경우
IF (p_FROM_EMP_NO IS NULL OR p_FROM_EMP_NO = '' OR p_TO_EMP_NO IS NULL OR p_TO_EMP_NO = '')
	THEN
	   P_ERR_MSG := 'MSG_0014';
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); 
	END IF
    ;


  -- 프로시저 시작 

    -- EMP_ID Setting 
	SELECT  ID INTO P_FROM_EMP_ID
	  FROM TB_AD_USER
	WHERE USERNAME = p_FROM_EMP_NO
	;
	SELECT ID INTO P_TO_EMP_ID
	  FROM TB_AD_USER
	WHERE USERNAME = p_TO_EMP_NO
	;

	IF (p_TRANFER_TYPE = 'MOVE')
		THEN
		UPDATE TB_DP_USER_ITEM_ACCOUNT_MAP 
           SET EMP_ID = P_TO_EMP_ID 
         WHERE AUTH_TP_ID = P_AUTH_TP_ID AND EMP_ID = P_FROM_EMP_ID
        ;
	ELSE 
		MERGE INTO TB_DP_USER_ITEM_ACCOUNT_MAP  TGT   
		USING ( 							   
				 SELECT DISTINCT P_TO_EMP_ID AS EMP_ID , AUTH_TP_ID,  ACCOUNT_ID,  ITEM_MST_ID, P_USER_ID AS USER_ID, ACTV_YN
				 FROM TB_DP_USER_ITEM_ACCOUNT_MAP TDUIAM 
				 WHERE AUTH_TP_ID = P_AUTH_TP_ID
				   AND EMP_ID = P_FROM_EMP_ID							   
			  ) SRC
		ON   (TGT.ACCOUNT_ID = SRC.ACCOUNT_ID 
       AND TGT.ITEM_MST_ID = SRC.ITEM_MST_ID 
       AND TGT.AUTH_TP_ID = SRC.AUTH_TP_ID 
       AND TGT.EMP_ID = SRC.EMP_ID)
		WHEN MATCHED THEN
			 UPDATE 
			   SET   TGT.MODIFY_BY   = SRC.USER_ID
					,TGT.ACTV_YN     = SRC.ACTV_YN 
					,TGT.MODIFY_DTTM = SYSDATE 
		WHEN NOT MATCHED THEN 
			 INSERT (
			            ID 
					  , AUTH_TP_ID
					  , ACCOUNT_ID
					  , ITEM_MST_ID
					  , EMP_ID
					  , ACTV_YN
					  , CREATE_BY
					  , CREATE_DTTM
					) 
			 VALUES (   TO_SINGLE_BYTE(SYS_GUID()) 
                	  , SRC.AUTH_TP_ID
                	  , SRC.ACCOUNT_ID
                	  , SRC.ITEM_MST_ID
                	  , SRC.EMP_ID
                	  , SRC.ACTV_YN
                	  , SRC.USER_ID 
                	  , SYSDATE           
						) 
						;    	

		END IF ;

 	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001'; 
       /*  ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN   
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;    
END ;
/

