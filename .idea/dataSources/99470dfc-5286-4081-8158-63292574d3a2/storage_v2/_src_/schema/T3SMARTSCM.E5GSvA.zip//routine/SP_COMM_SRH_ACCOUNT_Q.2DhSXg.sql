create PROCEDURE "SP_COMM_SRH_ACCOUNT_Q" (
    pResult OUT SYS_REFCURSOR
)
IS
BEGIN

    OPEN pResult FOR
    SELECT  A.ID					AS ACCOUNT_ID
            ,A.ACCOUNT_CD
            ,A.ACCOUNT_NM
            ,B.CHANNEL_ID
            ,B.CHANNEL_NM
            ,A.INCOTERMS_ID
            ,C.INCOTERMS
            ,A.VMI_YN
            ,A.DIRECT_SHPP_YN
			,C.CUST_DELIVY_MODELING_YN
            ,D.CUST_NM				AS BILL_TO_NM
            ,E.CUST_NM				AS SHIP_TO_NM
            ,F.CUST_NM				AS SOLD_TO_NM
        FROM TB_DP_ACCOUNT_MST A
            LEFT OUTER JOIN TB_CM_CHANNEL_TYPE B
        ON (A.CHANNEL_ID = B.ID)
            LEFT OUTER JOIN TB_CM_INCOTERMS C
        ON (A.INCOTERMS_ID = C.ID)
            LEFT OUTER JOIN TB_CM_CUSTOMER D
        ON (A.BILL_TO_ID = D.ID)
            LEFT OUTER JOIN TB_CM_CUSTOMER E
        ON (A.SHIP_TO_ID = E.ID)
            LEFT OUTER JOIN TB_CM_CUSTOMER F
        ON (A.SOLD_TO_ID = F.ID)
      ORDER BY A.ACCOUNT_CD;

END;
/

