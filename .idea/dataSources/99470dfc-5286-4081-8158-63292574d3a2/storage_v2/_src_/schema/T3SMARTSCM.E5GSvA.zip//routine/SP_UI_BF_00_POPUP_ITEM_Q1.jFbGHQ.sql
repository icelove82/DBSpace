create PROCEDURE                "SP_UI_BF_00_POPUP_ITEM_Q1" (
    P_LV_MGMT_ID CHAR
  , P_ITEM_CD    VARCHAR2
  , P_ITEM_NM	 VARCHAR2
  , P_ACCT_CD	 VARCHAR2
  , pRESULT OUT SYS_REFCURSOR
) IS
    V_LV_ID_COUNT NUMBER;
BEGIN
/******************************************************************************************
    Item & Item level

    history ( date / writer / comment)
    - 2020.09.01 / ksh / draft 
******************************************************************************************/
    
    SELECT COUNT(*)
      INTO V_LV_ID_COUNT
      FROM TB_CM_LEVEL_MGMT
     WHERE P_LV_MGMT_ID IS NULL OR ID = P_LV_MGMT_ID
       AND LEAF_YN = 'Y';
    
    IF (V_LV_ID_COUNT > 0) THEN
        OPEN pRESULT
        FOR
        SELECT IM.ID
             , IM.ITEM_CD  
             , IM.ITEM_NM 
          FROM TB_CM_ITEM_MST IM
--          INNER JOIN TB_BF_ITEM_ACCOUNT_MODEL_MAP IAM 
--          	ON IAM.ITEM_CD = IM.ITEM_CD 
--          	AND IAM.ACTV_YN = 'Y'
--          	AND 'Y' = CASE WHEN P_ACCT_CD IS NULL THEN 'Y'
--          				   ELSE (CASE WHEN P_ACCT_CD = IAM.ACCOUNT_CD THEN 'Y' ELSE 'N' END) END
         WHERE DEL_YN = 'N'
           AND DP_PLAN_YN = 'Y' 
           AND PARENT_ITEM_LV_ID IS NOT NULL
           AND  ( REGEXP_LIKE (UPPER(IM.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                  OR 
                   P_ITEM_CD IS NULL
                )
           AND  ( REGEXP_LIKE (UPPER(IM.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                  OR 
                   P_ITEM_NM IS NULL
                )
          ;
    ELSE
        OPEN pRESULT
        FOR
        SELECT ID
              ,ITEM_LV_CD   AS ITEM_CD  
              ,ITEM_LV_NM   AS ITEM_NM 
          FROM TB_CM_ITEM_LEVEL_MGMT IL
         WHERE LV_MGMT_ID = P_LV_MGMT_ID 
           AND ACTV_YN = 'Y'
           AND DEL_YN = 'N'
           AND  ( REGEXP_LIKE (UPPER(ITEM_LV_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                  OR 
                   P_ITEM_CD IS NULL
                )
           AND  ( REGEXP_LIKE (UPPER(ITEM_LV_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                  OR 
                   P_ITEM_NM IS NULL
                )
          ;
    END IF;
END;
/

