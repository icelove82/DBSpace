create PROCEDURE SP_UI_CM_18_S1 (
     P_WRK_TYPE           IN VARCHAR2     := ''
    ,P_ID                 IN VARCHAR2     := ''
    ,P_ITEM_CD            IN VARCHAR      := ''
    ,P_ITEM_NM            IN VARCHAR      := ''
    ,P_UOM_ID             IN VARCHAR2     := ''
    ,P_ITEM_TP_ID         IN VARCHAR2     := ''
    ,P_MIN_ORDER_SIZE     IN INT          := NULL
    ,P_MAX_ORDER_SIZE     IN INT          := NULL
    ,P_DESCRIP            IN VARCHAR2     := ''
    ,P_DP_PLAN_YN         IN CHAR         := ''
    ,P_PARENT_ITEM_LV_ID  IN VARCHAR2     := ''
    ,P_RTS                IN DATE         := NULL
    ,P_EOS                IN DATE         := NULL
    ,P_DEL_YN             IN CHAR         := ''
    ,P_ATTR_01            IN VARCHAR2     := ''
    ,P_ATTR_02            IN  VARCHAR2    := ''
    ,P_ATTR_03            IN  VARCHAR2    := ''
    ,P_ATTR_04            IN  VARCHAR2    := ''
    ,P_ATTR_05            IN  VARCHAR2    := ''
    ,P_ATTR_06            IN  VARCHAR2    := ''
    ,P_ATTR_07            IN  VARCHAR2    := ''
    ,P_ATTR_08            IN  VARCHAR2    := ''
    ,P_ATTR_09            IN  VARCHAR2    := ''
    ,P_ATTR_10            IN  VARCHAR2    := ''
    ,P_ATTR_11            IN  VARCHAR2    := ''
    ,P_ATTR_12            IN  VARCHAR2    := ''
    ,P_ATTR_13            IN  VARCHAR2    := ''
    ,P_ATTR_14            IN  VARCHAR2    := ''
    ,P_ATTR_15            IN  VARCHAR2    := ''
    ,P_ATTR_16            IN  VARCHAR2    := ''
    ,P_ATTR_17            IN  VARCHAR2    := ''
    ,P_ATTR_18            IN  VARCHAR2    := ''
    ,P_ATTR_19            IN  VARCHAR2    := ''
    ,P_ATTR_20            IN  VARCHAR2    := ''
	,P_ATTR_21			  IN  VARCHAR2    := ''
	,P_ATTR_22			  IN  VARCHAR2    := ''
	,P_ATTR_23			  IN  VARCHAR2    := ''
	,P_ATTR_24			  IN  VARCHAR2    := ''
	,P_ATTR_25			  IN  VARCHAR2    := ''
    ,P_DISPLAY_COLOR      IN  VARCHAR2    := ''
    ,P_USER_ID            IN  VARCHAR2    := ''
    ,P_RT_ROLLBACK_FLAG   OUT VARCHAR2
    ,P_RT_MSG             OUT VARCHAR2
) 
IS
    P_ERR_STATUS INT := 0; 
    P_ERR_MSG VARCHAR2(4000) :='';
    V_RTS DATE := P_RTS;
    V_EOS DATE := P_EOS;
    V_ITEM_ID  CHAR(32);
    V_ITEM_YN CHAR(1);
    V_ENTRY_COUNT INT;
    V_NULL_DATE DATE := TO_DATE('1900-01-01', 'yyyy-MM-dd');
    
BEGIN
    IF P_WRK_TYPE = 'SAVE'
    THEN 
        SELECT COUNT(*) INTO P_ERR_STATUS
          FROM TB_CM_ITEM_MST
         WHERE 1=1
           AND ITEM_CD = P_ITEM_CD
           AND ID != P_ID;
        IF (P_ERR_STATUS >0)
            THEN
           P_ERR_MSG := 'MSG_0013' ;
           RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
        END IF;
    
        -- Set ID
        V_ITEM_ID := COALESCE(P_ID,TO_SINGLE_BYTE(SYS_GUID()));
    
        IF NVL(P_ITEM_CD, ' ') = ' '
        THEN
            P_ERR_MSG := 'Item Code is empty.';
            RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
        END IF;
        IF NVL(P_ITEM_NM, ' ') = ' '
        THEN
            P_ERR_MSG := 'Item Name is empty.';
            RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
        END IF;
    
        IF (P_RTS = V_NULL_DATE)
        THEN
            V_RTS := NULL;
        END IF; 
        IF (P_EOS = V_NULL_DATE)
        THEN
            V_EOS := NULL;
        END IF; 
    
        IF (V_RTS > V_EOS)
            THEN
                P_ERR_MSG := 'MSG_5149';
                RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);                    
            END IF;
    
        MERGE INTO TB_CM_ITEM_MST TGT
        USING ( 
                SELECT   P_ID                      AS ID                
                        ,P_ITEM_CD                 AS ITEM_CD           
                        ,P_ITEM_NM                 AS ITEM_NM           
                        ,P_UOM_ID                  AS UOM_ID
                        ,CASE WHEN P_ITEM_TP_ID IS NOT NULL THEN P_ITEM_TP_ID
                              ELSE (SELECT CT.ID FROM TB_CM_ITEM_TYPE CT WHERE ITEM_TP = 'FERT')
                         END		       		   AS ITEM_TP_ID
                        ,P_DESCRIP                 AS DESCRIP           
                        ,P_DP_PLAN_YN              AS DP_PLAN_YN        
                        ,P_PARENT_ITEM_LV_ID       AS PARENT_ITEM_LV_ID 
                        ,V_RTS                     AS RTS               
                        ,V_EOS                     AS EOS               
                        ,CASE WHEN P_DEL_YN = 'Y' THEN 'Y' ELSE 'N' END   AS DEL_YN            
                        ,P_ATTR_01                 AS ATTR_01           
                        ,P_ATTR_02                 AS ATTR_02            
                        ,P_ATTR_03                 AS ATTR_03            
                        ,P_ATTR_04                 AS ATTR_04            
                        ,P_ATTR_05                 AS ATTR_05            
                        ,P_ATTR_06                 AS ATTR_06            
                        ,P_ATTR_07                 AS ATTR_07            
                        ,P_ATTR_08                 AS ATTR_08            
                        ,P_ATTR_09                 AS ATTR_09            
                        ,P_ATTR_10                 AS ATTR_10            
                        ,P_ATTR_11                 AS ATTR_11            
                        ,P_ATTR_12                 AS ATTR_12            
                        ,P_ATTR_13                 AS ATTR_13            
                        ,P_ATTR_14                 AS ATTR_14            
                        ,P_ATTR_15                 AS ATTR_15            
                        ,P_ATTR_16                 AS ATTR_16            
                        ,P_ATTR_17                 AS ATTR_17            
                        ,P_ATTR_18                 AS ATTR_18            
                        ,P_ATTR_19                 AS ATTR_19            
                        ,P_ATTR_20                 AS ATTR_20            
                        ,P_ATTR_21                 AS ATTR_21
                        ,P_ATTR_22                 AS ATTR_22
                        ,P_ATTR_23                 AS ATTR_23
                        ,P_ATTR_24                 AS ATTR_24
                        ,P_ATTR_25                 AS ATTR_25
                        ,P_DISPLAY_COLOR           AS DISPLAY_COLOR
                        ,P_USER_ID                 AS USER_ID
                        ,P_MIN_ORDER_SIZE          AS MIN_ORDER_SIZE
                        ,P_MAX_ORDER_SIZE          AS MAX_ORDER_SIZE
              FROM dual ) SRC
        ON     (TGT.ID = SRC.ID)
        WHEN MATCHED THEN
             UPDATE 
               SET   TGT.ITEM_CD              = SRC.ITEM_CD           
                    ,TGT.ITEM_NM              = SRC.ITEM_NM           
                    ,TGT.UOM_ID               = SRC.UOM_ID            
                    ,TGT.ITEM_TP_ID           = SRC.ITEM_TP_ID        
                    ,TGT.DESCRIP              = SRC.DESCRIP           
                    ,TGT.DP_PLAN_YN           = SRC.DP_PLAN_YN        
                    ,TGT.GRADE_YN             = SRC.DP_PLAN_YN
                    ,TGT.PARENT_ITEM_LV_ID    = SRC.PARENT_ITEM_LV_ID
                    ,TGT.RTS                  = SRC.RTS               
                    ,TGT.EOS                  = SRC.EOS               
                    ,TGT.DEL_YN               = SRC.DEL_YN            
                    ,TGT.ATTR_01              = SRC.ATTR_01           
                    ,TGT.ATTR_02              = SRC.ATTR_02            
                    ,TGT.ATTR_03              = SRC.ATTR_03            
                    ,TGT.ATTR_04              = SRC.ATTR_04            
                    ,TGT.ATTR_05              = SRC.ATTR_05            
                    ,TGT.ATTR_06              = SRC.ATTR_06            
                    ,TGT.ATTR_07              = SRC.ATTR_07            
                    ,TGT.ATTR_08              = SRC.ATTR_08            
                    ,TGT.ATTR_09              = SRC.ATTR_09            
                    ,TGT.ATTR_10              = SRC.ATTR_10            
                    ,TGT.ATTR_11              = SRC.ATTR_11            
                    ,TGT.ATTR_12              = SRC.ATTR_12            
                    ,TGT.ATTR_13              = SRC.ATTR_13            
                    ,TGT.ATTR_14              = SRC.ATTR_14            
                    ,TGT.ATTR_15              = SRC.ATTR_15            
                    ,TGT.ATTR_16              = SRC.ATTR_16            
                    ,TGT.ATTR_17              = SRC.ATTR_17            
                    ,TGT.ATTR_18              = SRC.ATTR_18            
                    ,TGT.ATTR_19              = SRC.ATTR_19
                    ,TGT.ATTR_20              = SRC.ATTR_20
                    ,TGT.ATTR_21              = SRC.ATTR_21
                    ,TGT.ATTR_22              = SRC.ATTR_22
                    ,TGT.ATTR_23              = SRC.ATTR_23
                    ,TGT.ATTR_24              = SRC.ATTR_24
                    ,TGT.ATTR_25              = SRC.ATTR_25
                    ,TGT.DISPLAY_COLOR        = SRC.DISPLAY_COLOR
                    ,TGT.MODIFY_BY            = SRC.USER_ID       
                    ,TGT.MODIFY_DTTM          = SYSDATE()   
                    ,TGT.MIN_ORDER_SIZE       = SRC.MIN_ORDER_SIZE
                    ,TGT.MAX_ORDER_SIZE       = SRC.MAX_ORDER_SIZE
    
        WHEN NOT MATCHED THEN 
             INSERT (
                         ID                
                        ,ITEM_CD           
                        ,ITEM_NM           
                        ,UOM_ID            
                        ,ITEM_TP_ID        
                        ,DESCRIP           
                        ,DP_PLAN_YN        
                        ,GRADE_YN
                        ,PARENT_ITEM_LV_ID
                        ,RTS               
                        ,EOS               
                        ,DEL_YN            
                        ,ATTR_01           
                        ,ATTR_02            
                        ,ATTR_03            
                        ,ATTR_04            
                        ,ATTR_05            
                        ,ATTR_06            
                        ,ATTR_07            
                        ,ATTR_08            
                        ,ATTR_09            
                        ,ATTR_10            
                        ,ATTR_11            
                        ,ATTR_12            
                        ,ATTR_13            
                        ,ATTR_14            
                        ,ATTR_15            
                        ,ATTR_16            
                        ,ATTR_17            
                        ,ATTR_18            
                        ,ATTR_19
                        ,ATTR_20
                        ,ATTR_21
                        ,ATTR_22
                        ,ATTR_23
                        ,ATTR_24
                        ,ATTR_25
                        ,DISPLAY_COLOR
                        ,CREATE_BY
                        ,CREATE_DTTM
                        ,MIN_ORDER_SIZE
                        ,MAX_ORDER_SIZE
                    ) 
             VALUES (
                         V_ITEM_ID
                        ,SRC.ITEM_CD           
                        ,SRC.ITEM_NM           
                        ,SRC.UOM_ID            
                        ,SRC.ITEM_TP_ID        
                        ,SRC.DESCRIP           
                        ,SRC.DP_PLAN_YN           
                        ,SRC.DP_PLAN_YN       
                        ,SRC.PARENT_ITEM_LV_ID
                        ,SRC.RTS               
                        ,SRC.EOS               
                        ,SRC.DEL_YN            
                        ,SRC.ATTR_01           
                        ,SRC.ATTR_02            
                        ,SRC.ATTR_03            
                        ,SRC.ATTR_04            
                        ,SRC.ATTR_05            
                        ,SRC.ATTR_06            
                        ,SRC.ATTR_07            
                        ,SRC.ATTR_08            
                        ,SRC.ATTR_09            
                        ,SRC.ATTR_10            
                        ,SRC.ATTR_11            
                        ,SRC.ATTR_12            
                        ,SRC.ATTR_13            
                        ,SRC.ATTR_14            
                        ,SRC.ATTR_15            
                        ,SRC.ATTR_16            
                        ,SRC.ATTR_17            
                        ,SRC.ATTR_18            
                        ,SRC.ATTR_19
                        ,SRC.ATTR_20
                        ,SRC.ATTR_21
                        ,SRC.ATTR_22
                        ,SRC.ATTR_23
                        ,SRC.ATTR_24
                        ,SRC.ATTR_25
                        ,SRC.DISPLAY_COLOR
                        ,SRC.USER_ID 
                        ,SYSDATE        
                        ,SRC.MIN_ORDER_SIZE
                        ,SRC.MAX_ORDER_SIZE                                
                     );
    
        P_RT_MSG := 'MSG_0001';
    
    ELSIF P_WRK_TYPE = 'DELETE'
    THEN
         UPDATE  TB_CM_ITEM_MST
         SET     DEL_YN = 'Y'
               , MODIFY_BY = P_USER_ID
               , MODIFY_DTTM = SYSDATE
         WHERE ID = P_ID;
         
        P_RT_MSG := 'MSG_0002';
    END IF;

    P_RT_ROLLBACK_FLAG := 'true';

EXCEPTION
WHEN OTHERS THEN
      IF(SQLCODE = -20001)
      THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;   
      ELSE
          RAISE;
      END IF;
END;
/

