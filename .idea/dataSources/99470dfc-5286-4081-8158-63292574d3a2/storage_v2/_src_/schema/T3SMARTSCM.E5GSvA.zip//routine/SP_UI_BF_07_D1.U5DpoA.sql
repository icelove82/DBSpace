create PROCEDURE                "SP_UI_BF_07_D1"  (
    p_ID                     CHAR  := ''     
  , P_RT_ROLLBACK_FLAG   OUT VARCHAR2
  , P_RT_MSG             OUT VARCHAR2          
) 
IS
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
    P_ERR_STATUS    NUMBER          := 0;
    P_ERR_MSG       VARCHAR2(4000)  :='';

BEGIN
    DELETE FROM TB_BF_SALES_FACTOR
     WHERE ID = P_ID;

    P_RT_ROLLBACK_FLAG  := 'true';
    P_RT_MSG            := 'MSG_0002';  --삭제 되었습니다.

EXCEPTION WHEN OTHERS THEN
    P_ERR_MSG            := SQLERRM;
    P_RT_ROLLBACK_FLAG   := 'false';
    P_RT_MSG             := P_ERR_MSG;
END;
/

