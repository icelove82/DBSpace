create PROCEDURE                "SP_UI_BF_15_S1"
(
         P_ID                  CHAR
        ,P_ENGINE_TP_CD        VARCHAR2           
        ,P_DESCRIP             VARCHAR2
        ,P_SEQ                 NUMBER
        ,P_BF_DIST_RULE_CD     VARCHAR2
        ,P_INPUT_HORIZ         VARCHAR2
        ,P_INPUT_BUKT_CD       VARCHAR2
        ,P_TARGET_HORIZ        VARCHAR2
        ,P_TARGET_BUKT_CD      VARCHAR2
        ,P_SALES_LV_CD         VARCHAR2
        ,P_ITEM_LV_CD          VARCHAR2
        ,P_VAL_TP              VARCHAR2
        ,P_ATTR_01             VARCHAR2
        ,P_ATTR_02             VARCHAR2
        ,P_ATTR_03             VARCHAR2
        ,P_ATTR_04             VARCHAR2
        ,P_ATTR_05             VARCHAR2
        ,P_ATTR_06             VARCHAR2
        ,P_ATTR_07             VARCHAR2
        ,P_ATTR_08             VARCHAR2
        ,P_ATTR_09             VARCHAR2
        ,P_ATTR_10             VARCHAR2
        ,P_USER_ID             VARCHAR2
        ,P_RT_ROLLBACK_FLAG    OUT VARCHAR2
        ,P_RT_MSG              OUT VARCHAR2    
)
IS
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
    P_ERR_STATUS NUMBER := 0;
    P_ERR_MSG VARCHAR2(4000) := '';
    P_DEFAT_ITEM_CD    VARCHAR2(100);
    P_DEFAT_ACCT_CD    VARCHAR2(100);
    
    V_SALES_LV_CD   VARCHAR2(32);
    V_ITEM_LV_CD    VARCHAR2(32);
    V_SALES_LV_CNT  NUMBER;
    V_ITEM_LV_CNT   NUMBER;

BEGIN
    IF(P_SALES_LV_CD  IS NULL) THEN
        SELECT LV_CD
          INTO V_SALES_LV_CD
          FROM TB_CM_LEVEL_MGMT
        WHERE 1=1
          AND ACTV_YN = 'Y'
          AND NVL(DEL_YN,'N') = 'N'
          AND ACCOUNT_LV_YN = 'Y'
          AND LEAF_YN = 'Y';
    ELSE
        V_SALES_LV_CD := P_SALES_LV_CD;
    END IF;

    IF(P_ITEM_LV_CD   IS NULL) THEN
        SELECT LV_CD
          INTO V_ITEM_LV_CD
          FROM TB_CM_LEVEL_MGMT
        WHERE ACTV_YN = 'Y'
          AND NVL(DEL_YN,'N') = 'N'
          AND ACCOUNT_LV_YN = 'N'
          AND SALES_LV_YN = 'N'
          AND LEAF_YN = 'Y';
    ELSE
        V_ITEM_LV_CD := P_ITEM_LV_CD;
    END IF;

    SELECT COUNT(LV_CD)
      INTO V_SALES_LV_CNT
      FROM TB_CM_LEVEL_MGMT
     WHERE 1=1
       AND ACTV_YN = 'Y'
       AND NVL(DEL_YN,'N') = 'N'
       AND ACCOUNT_LV_YN = 'Y'
       AND LV_CD = V_SALES_LV_CD;

    IF (V_SALES_LV_CNT = 0) THEN
        P_ERR_MSG := 'Sales Level Code is not valid';
        RAISE_APPLICATION_ERROR (SQLCODE, P_ERR_MSG);
    END IF;

    SELECT COUNT(LV_CD)
      INTO V_ITEM_LV_CNT
      FROM TB_CM_LEVEL_MGMT
     WHERE ACTV_YN = 'Y'
       AND NVL(DEL_YN,'N') = 'N'
       AND ACCOUNT_LV_YN = 'N'
       AND SALES_LV_YN = 'N'
       AND LV_CD = V_ITEM_LV_CD;

    IF (V_ITEM_LV_CNT = 0) THEN
        P_ERR_MSG := 'Item Level Code is not valid';
        RAISE_APPLICATION_ERROR (SQLCODE, P_ERR_MSG);
    END IF;

    IF(P_seq               IS NULL) THEN    P_ERR_MSG := 'Sequence is empty';           RAISE_APPLICATION_ERROR (SQLCODE, P_ERR_MSG); END IF;
    IF(P_INPUT_HORIZ       IS NULL) THEN    P_ERR_MSG := 'Input Horizon is empty';      RAISE_APPLICATION_ERROR (SQLCODE, P_ERR_MSG); END IF;
    IF(P_INPUT_BUKT_CD     IS NULL) THEN    P_ERR_MSG := 'Input Bucket is empty';       RAISE_APPLICATION_ERROR (SQLCODE, P_ERR_MSG); END IF;
    IF(P_TARGET_HORIZ      IS NULL) THEN    P_ERR_MSG := 'Target Horizon is empty';     RAISE_APPLICATION_ERROR (SQLCODE, P_ERR_MSG); END IF;
    IF(P_TARGET_BUKT_CD    IS NULL) THEN    P_ERR_MSG := 'Target Bucket is empty';      RAISE_APPLICATION_ERROR (SQLCODE, P_ERR_MSG); END IF;
    
    /******************************************************************
        -- Main Procedure
    *******************************************************************/
    MERGE INTO TB_BF_CONTROL_BOARD_MST TGT
    USING ( SELECT P_ID                    AS  ID              
                  ,P_ENGINE_TP_CD          AS  ENGINE_TP_CD        
                  ,P_DESCRIP               AS  DESCRIP         
                  ,P_SEQ                   AS  SEQ             
                  ,P_BF_DIST_RULE_CD       AS  BF_DIST_RULE_CD 
                  ,P_INPUT_HORIZ           AS  INPUT_HORIZ     
                  ,P_INPUT_BUKT_CD         AS  INPUT_BUKT_CD       
                  ,P_TARGET_HORIZ          AS  TARGET_HORIZ        
                  ,P_TARGET_BUKT_CD        AS  TARGET_BUKT_CD  
                  ,V_SALES_LV_CD           AS  SALES_LV_CD     
                  ,V_ITEM_LV_CD            AS  ITEM_LV_CD      
                  ,P_VAL_TP                AS  VAL_TP
                  ,P_ATTR_01               AS  ATTR_01         
                  ,P_ATTR_02               AS  ATTR_02         
                  ,P_ATTR_03               AS  ATTR_03         
                  ,P_ATTR_04               AS  ATTR_04         
                  ,P_ATTR_05               AS  ATTR_05         
                  ,P_ATTR_06               AS  ATTR_06         
                  ,P_ATTR_07               AS  ATTR_07         
                  ,P_ATTR_08               AS  ATTR_08         
                  ,P_ATTR_09               AS  ATTR_09         
                  ,P_ATTR_10               AS  ATTR_10         
                  ,P_USER_ID               AS  USER_ID
                  ,(SELECT SYSDATE FROM DUAL)  AS  DTTM
            FROM DUAL
          ) SRC 
        ON (TGT.ENGINE_TP_CD = SRC.ENGINE_TP_CD)
    WHEN MATCHED THEN
        UPDATE SET DESCRIP          = SRC.DESCRIP           
                  ,SEQ              = SRC.SEQ               
                  ,BF_DIST_RULE_CD  = SRC.BF_DIST_RULE_CD   
                  ,INPUT_HORIZ      = SRC.INPUT_HORIZ       
                  ,INPUT_BUKT_CD    = SRC.INPUT_BUKT_CD         
                  ,TARGET_HORIZ     = SRC.TARGET_HORIZ      
                  ,TARGET_BUKT_CD   = SRC.TARGET_BUKT_CD    
                  ,SALES_LV_CD      = SRC.SALES_LV_CD       
                  ,ITEM_LV_CD       = SRC.ITEM_LV_CD    
                  ,VAL_TP           = SRC.VAL_TP
                  ,ATTR_01          = SRC.ATTR_01           
                  ,ATTR_02          = SRC.ATTR_02           
                  ,ATTR_03          = SRC.ATTR_03           
                  ,ATTR_04          = SRC.ATTR_04           
                  ,ATTR_05          = SRC.ATTR_05           
                  ,ATTR_06          = SRC.ATTR_06           
                  ,ATTR_07          = SRC.ATTR_07           
                  ,ATTR_08          = SRC.ATTR_08           
                  ,ATTR_09          = SRC.ATTR_09           
                  ,ATTR_10          = SRC.ATTR_10           
                  ,MODIFY_BY        = SRC.USER_ID
                  ,MODIFY_DTTM      = SRC.DTTM
    WHEN NOT MATCHED THEN
        INSERT ( ID             
                ,ENGINE_TP_CD       
                ,DESCRIP            
                ,SEQ                
                ,BF_DIST_RULE_CD    
                ,INPUT_HORIZ        
                ,INPUT_BUKT_CD      
                ,TARGET_HORIZ       
                ,TARGET_BUKT_CD 
                ,SALES_LV_CD        
                ,ITEM_LV_CD    
                ,VAL_TP
                ,ATTR_01            
                ,ATTR_02            
                ,ATTR_03            
                ,ATTR_04            
                ,ATTR_05            
                ,ATTR_06            
                ,ATTR_07            
                ,ATTR_08            
                ,ATTR_09            
                ,ATTR_10            
                ,CREATE_BY
                ,CREATE_DTTM
               ) VALUES (
                RAWTOHEX(SYS_GUID())
               ,SRC.ENGINE_TP_CD
               ,SRC.DESCRIP         
               ,SRC.SEQ             
               ,SRC.BF_DIST_RULE_CD 
               ,SRC.INPUT_HORIZ     
               ,SRC.INPUT_BUKT_CD           
               ,SRC.TARGET_HORIZ        
               ,SRC.TARGET_BUKT_CD  
               ,SRC.SALES_LV_CD     
               ,SRC.ITEM_LV_CD      
               ,SRC.VAL_TP
               ,SRC.ATTR_01         
               ,SRC.ATTR_02         
               ,SRC.ATTR_03         
               ,SRC.ATTR_04         
               ,SRC.ATTR_05         
               ,SRC.ATTR_06         
               ,SRC.ATTR_07         
               ,SRC.ATTR_08         
               ,SRC.ATTR_09         
               ,SRC.ATTR_10         
               ,SRC.USER_ID
               ,SRC.DTTM
               )
    ;
    
    P_RT_MSG := 'MSG_0001';
    P_RT_ROLLBACK_FLAG := 'true';

EXCEPTION WHEN OTHERS THEN
    IF (SQLERRM = P_ERR_MSG) THEN
        P_ERR_MSG := SQLERRM;
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
    ELSE
        RAISE;
--        RAISE_APPLICATION_ERROR(SQLCODE, SQLERRM);
--              EXEC SP_COMM_RAISE_ERR
    END IF;
END;


/*

SELECT *
 FROM  TB_CM_CONFIGURATION CF
         INNER JOIN
         TB_CM_COMM_CONFIG CC   
      ON CF.ID = CC.CONF_ID 
     AND CF.CONF_NM = 'BF_ENGINE_TP'
     AND CF.MODULE_CD = 'BF'
      -- lang_pack 문서에 반영하기!!!
      SELECT *
        FROM LANG_PACK
      WHERE LANG_KEY LIKE '%ENGINE_TP%'
        OR LANG_KEY = 'INPUT'
*/
/

