create PROCEDURE SP_UI_CM_17_S4 (
    P_SIMUL_VER_ID 		        IN VARCHAR2 :='',
    P_SIMUL_VER_DESCRIP         IN VARCHAR2 :='',
	P_REVISION_ID				IN CHAR,
    P_PLAN_SNRIO_MGMT_DTL_ID	IN CHAR,
    P_USER_ID 			        IN VARCHAR2 :=''
)
IS
    V_CHG_PROC VARCHAR2(10) := '';

BEGIN
	SELECT	COMN_CD INTO V_CHG_PROC
	FROM	TB_CM_PLAN_SNRIO_MGMT_DTL A
			INNER JOIN TB_AD_COMN_CODE B
			ON B.ID = A.PROCESS_TP_ID
	WHERE	A.ID = P_PLAN_SNRIO_MGMT_DTL_ID;

    UPDATE TB_CM_CONBD_MAIN_VER_DTL A 
       SET A.SIMUL_VER_DESCRIP = P_SIMUL_VER_DESCRIP
	      ,A.REVISION_ID = P_REVISION_ID
          ,A.PLAN_SNRIO_MGMT_DTL_ID = CASE WHEN V_CHG_PROC = 'SPROC_03' OR V_CHG_PROC = 'SPROC_05' THEN P_PLAN_SNRIO_MGMT_DTL_ID ELSE A.PLAN_SNRIO_MGMT_DTL_ID END
          ,A.REFER_CONBD_MAIN_VER_DTL_ID = CASE WHEN V_CHG_PROC = 'SPROC_03' THEN NULL ELSE A.REFER_CONBD_MAIN_VER_DTL_ID END
          ,A.EXE_STATUS_ID = 
				           (SELECT B.ID  
				              FROM TB_AD_COMN_GRP A
				                   INNER JOIN TB_AD_COMN_CODE B
				                   ON A.ID = B.SRC_ID
				                   AND B.COMN_CD = 'EXE_02'
				             WHERE 1=1
				               AND A.GRP_CD = 'EXE_STATUS')
          ,A.STEP_STATUS_ID = 
	  		               (SELECT B.ID
				              FROM TB_AD_COMN_GRP A 
				                   INNER JOIN 
				                   TB_AD_COMN_CODE B
				                   ON A.ID = B.SRC_ID
				                   AND B.COMN_CD = 'RUNNING'
				             WHERE 1=1
				               AND A.GRP_CD = 'STEP_STATUS')
          ,A.MODIFY_BY = P_USER_ID
          ,A.MODIFY_DTTM = SYSDATE
     WHERE 1=1
       AND A.SIMUL_VER_ID = P_SIMUL_VER_ID;

END;
/

