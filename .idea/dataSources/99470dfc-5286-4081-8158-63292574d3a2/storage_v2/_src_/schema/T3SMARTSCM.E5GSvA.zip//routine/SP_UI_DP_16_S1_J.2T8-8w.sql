create PROCEDURE SP_UI_DP_16_S1_J (
                                       P_JSON			    CLOB
                                     , P_DIM				VARCHAR2
                                     , P_USER_ID            VARCHAR2
                                     , P_RT_ROLLBACK_FLAG   OUT VARCHAR2
                                     , P_RT_MSG             OUT VARCHAR2						        
--                                     , pRESULT              OUT SYS_REFCURSOR
) IS

    p_SQL		    VARCHAR2(4000);
    p_ERR_MSG       VARCHAR2(4000);
    P_DATA_TYPE     VARCHAR2(20);
/************************************************************************************************V*********
Title : SP_UI_DP_16_S1_J
  - DP Dimension Data Management

설명 
  - OPENJSON : https://docs.microsoft.com/ko-kr/sql/t-sql/functions/openjson-transact-sql?view=sql-server-ver15

 
History (수정일자 / 수정자 / 수정내용)
- 2022.01.13 / kim sohee / json bulk insert draft
******************************************************************************************************************/
BEGIN 
/*
	-- Find ID
	SELECT ID INTO p_ITEM_MST_ID FROM TB_CM_ITEM_MST WHERE ITEM_CD =p_ITEM_CD;
	SELECT ID INTO p_ACCOUNT_ID FROM TB_DP_ACCOUNT_MST WHERE ACCOUNT_CD = p_ACCT_CD;
	-- VALIDATION ABOUT ID 
	IF(p_ITEM_MST_ID IS NULL)
	THEN
		p_ERR_MSG := 'Item Code is not valid';
        RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG);
	END IF;
	IF(p_ACCOUNT_ID IS NULL)
	THEN
		p_ERR_MSG := 'Account Code is not valid';
        RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG);
	END IF;
*/
	   SELECT CASE ATTR_01 
                WHEN 'double' THEN 'DIM_DOUBLE'
                WHEN 'integer'	THEN 'DIM_INTEGER'
                WHEN 'string'	THEN 'DIM_STRING'
                WHEN 'boolean'	THEN 'DIM_BOOL'
                WHEN 'date'		THEN 'DIM_DATE'
				  ELSE 'NULL' END INTO P_DATA_TYPE
	    FROM TB_CM_COMM_CONFIG
	   WHERE CONF_GRP_CD = 'DP_DMND_CUSTOM'
	     AND CONF_CD = P_DIM
		 ;

    INSERT INTO TEMP_DP_DIMENSION_DATA
    (      ITEM_CD
         , ACCOUNT_CD
         , DIM_DOUBLE 
         , DIM_INTEGER
         , DIM_STRING
         , DIM_BOOL
         , DIM_DATE    
    )
    SELECT ITEM_CD
         , ACCOUNT_CD
         , CASE WHEN P_DATA_TYPE = 'DIM_DOUBLE' THEN DIM_VALUE ELSE NULL END 
         , CASE WHEN P_DATA_TYPE = 'DIM_INTEGER' THEN DIM_VALUE ELSE NULL END
         , CASE WHEN P_DATA_TYPE = 'DIM_STRING' THEN DIM_VALUE ELSE NULL END
         , CASE WHEN P_DATA_TYPE = 'DIM_BOOL' THEN DIM_VALUE ELSE NULL END
         , CASE WHEN P_DATA_TYPE = 'DIM_DATE' THEN DIM_VALUE ELSE NULL END
      FROM JSON_TABLE ( P_JSON,  '$[*]'  
                COLUMNS (    ITEM_CD		PATH	'$.ITEM_CD'
                           , ACCOUNT_CD		PATH	'$.ACCOUNT_CD'
                           , DIM_VALUE		PATH	'$.DIM_VALUE'
                        )                                      
                ) ;

				P_SQL := 'MERGE INTO TB_DP_DIMENSION_DATA TGT '
				||'USING ( SELECT   A.ID	AS  ACCOUNT_ID '    
								||',I.ID	AS  ITEM_MST_ID '     
                                || ',M.'||P_DATA_TYPE||' AS DIM_VALUE '
					   ||'FROM TEMP_DP_DIMENSION_DATA M '					  
						     ||'INNER JOIN '
							 ||'TB_CM_ITEM_MST I '
						  ||'ON M.ITEM_CD = I.ITEM_CD '
						     ||'INNER JOIN '
							 ||'TB_DP_ACCOUNT_MST A '
						  ||'ON M.ACCOUNT_CD = A.ACCOUNT_CD '
					  ||') SRC '
					||'ON (TGT.ACCOUNT_ID = SRC.ACCOUNT_ID '
				   ||'AND TGT.ITEM_MST_ID = SRC.ITEM_MST_ID) '
				||'WHEN MATCHED THEN '
					 ||'UPDATE '
					   ||'SET   '||P_DIM||' = SRC.DIM_VALUE '
--							||',MODIFY_BY = '''+P_USER_ID||''' '     
--							||',MODIFY_DTTM = SYSDATE '      
				||'WHEN NOT MATCHED THEN '
					 ||'INSERT (ID '         
							||',ACCOUNT_ID '
							||',ITEM_MST_ID '
							||','||P_DIM||' '   
							||',CREATE_BY '
							||',CREATE_DTTM '
							||') '
					 ||'VALUES ( '
							 ||'TO_SINGLE_BYTE(SYS_GUID()) '
							||',SRC.ACCOUNT_ID '   
							||',SRC.ITEM_MST_ID '  
							||',SRC.DIM_VALUE '   
							||','''||P_USER_ID||''' '
							||',SYSDATE '           
 							||')' 
							;  

--    OPEN pRESULT FOR SELECT P_SQL FROM DUAL ;
--    OPEN pRESULT FOR SELECT * FROM TEMP_DP_DIMENSION_DATA;
    
    EXECUTE IMMEDIATE P_SQL ;

    DELETE FROM TEMP_DP_DIMENSION_DATA;

    p_RT_MSG := 'MSG_0001';
    p_RT_ROLLBACK_FLAG := 'true';

     EXCEPTION WHEN OTHERS THEN
              IF(SQLCODE = -20001)
              THEN
                  P_RT_MSG := SQLERRM; 
                  p_RT_ROLLBACK_FLAG := 'false';
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;   	

END;
/

