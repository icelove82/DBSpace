create FUNCTION                FN_DP_TEMP_FIND_ITEM
(
    P_EMP_ID     CHAR
  , P_AUTH_TP_ID CHAR
  , P_ITEM_LV_CD VARCHAR2 := NULL
)
RETURN DP_TEMP_FIND_ITEM IS
C_DP_TEMP_FIND_ITEM DP_TEMP_FIND_ITEM := DP_TEMP_FIND_ITEM();
CURSOR C_DATA_IMPORT IS     

SELECT TP_DP_TEMP_FIND_ITEM
    (  ITEM_ID           => ID
     , ITEM_CD           => ITEM_CD
     , ITEM_NM           => ITEM_NM
     , PARENT_ITEM_LV_ID => PARENT_ITEM_LV_ID
      )
  FROM(
  
        WITH TB_PR_ITEM_LEVEL_MGMT (
            ID
          , PARENT_ITEM_LV_ID
          , ITEM_LV_CD
          , ORG_LEVEL
        ) AS (
            SELECT ID, PARENT_ITEM_LV_ID, ITEM_LV_CD, 1 AS ORG_LEVEL
              FROM TB_CM_ITEM_LEVEL_MGMT
             WHERE ID IN (
                SELECT M.ITEM_LV_ID
                  FROM TB_DP_USER_ITEM_MAP M
                 WHERE M.EMP_ID = P_EMP_ID
                   AND M.AUTH_TP_ID = P_AUTH_TP_ID
             )
            UNION ALL
            SELECT A.ID, A.PARENT_ITEM_LV_ID, A.ITEM_LV_CD, B.ORG_LEVEL + 1 AS ORG_LEVEL
              FROM TB_CM_ITEM_LEVEL_MGMT A, TB_PR_ITEM_LEVEL_MGMT B
             WHERE B.ID = A.PARENT_ITEM_LV_ID
        )
  
        SELECT IM.ID, IM.ITEM_CD, IM.ITEM_NM , IM.PARENT_ITEM_LV_ID  
          FROM TB_PR_ITEM_LEVEL_MGMT LV
               INNER JOIN
               TB_CM_ITEM_MST IM
            ON LV.ID = IM.PARENT_ITEM_LV_ID 
           AND IM.DP_PLAN_YN = 'Y'
           AND COALESCE(IM.DEL_YN,'N') = 'N'	  
               INNER JOIN
               TABLE(FN_DP_TEMP_ITEM_TREE()) TR
            ON TR.LEAF_ITEM_LV_ID = IM.PARENT_ITEM_LV_ID
         WHERE (TR.PATH_CD LIKE '%/'||P_ITEM_LV_CD||'%' OR P_ITEM_LV_CD IS NULL)
        UNION
        SELECT IM.ID, IM.ITEM_CD, IM.ITEM_NM , IM.PARENT_ITEM_LV_ID
          FROM (
                SELECT ITEM_MST_ID
                  FROM TB_DP_USER_ITEM_MAP UI
                WHERE UI.EMP_ID = P_EMP_ID
                  AND UI.AUTH_TP_ID = P_AUTH_TP_ID
                UNION
                SELECT ITEM_MST_ID
                  FROM TB_DP_USER_ITEM_ACCOUNT_MAP UI
                WHERE UI.EMP_ID = P_EMP_ID
                  AND UI.AUTH_TP_ID = P_AUTH_TP_ID
                GROUP BY ITEM_MST_ID
                ) UI
            INNER JOIN TB_cM_ITEM_MST IM		   
            ON (UI.ITEM_MST_ID = IM.ID
           AND IM.DP_PLAN_YN = 'Y'
           AND COALESCE(IM.DEL_YN,'N') = 'N')
            INNER JOIN TABLE(FN_DP_TEMP_ITEM_TREE()) TR
            ON TR.LEAF_ITEM_LV_ID = IM.PARENT_ITEM_LV_ID
         WHERE 1=1
           AND (TR.PATH_CD LIKE '%/'||P_ITEM_LV_CD||'%' OR P_ITEM_LV_CD IS NULL)
)
;


BEGIN
        OPEN C_DATA_IMPORT;
        FETCH C_DATA_IMPORT BULK COLLECT INTO C_DP_TEMP_FIND_ITEM;
        CLOSE C_DATA_IMPORT;    
    RETURN C_DP_TEMP_FIND_ITEM;
END;
/

