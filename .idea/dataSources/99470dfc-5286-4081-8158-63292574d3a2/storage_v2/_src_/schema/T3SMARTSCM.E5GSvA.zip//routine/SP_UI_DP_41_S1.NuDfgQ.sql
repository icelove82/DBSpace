create PROCEDURE                SP_UI_DP_41_S1 (
     p_MEASURE				VARCHAR2 := 'ACT_SALES' 
    ,p_ITEM_CD				VARCHAR2
    ,p_ACCT_CD				VARCHAR2
    ,p_BASE_DATE			DATE
    ,p_QTY					decimal
    ,p_AMT					decimal
    ,p_USER_ID				VARCHAR2
    ,p_RT_ROLLBACK_FLAG		OUT VARCHAR2
    ,p_RT_MSG				OUT VARCHAR2
)IS

p_SQL		    VARCHAR2(4000);
p_ERR_STATUS    VARCHAR(2);
p_ERR_MSG       VARCHAR2(4000):='';

p_ITEM_MST_ID	CHAR(32);
p_ACCOUNT_ID    CHAR(32);

BEGIN 
	-- Find ID
	SELECT ID INTO p_ITEM_MST_ID FROM TB_CM_ITEM_MST WHERE ITEM_CD =p_ITEM_CD;
	SELECT ID INTO p_ACCOUNT_ID FROM TB_DP_ACCOUNT_MST WHERE ACCOUNT_CD = p_ACCT_CD;
	-- VALIDATION ABOUT ID 
	IF(p_ITEM_MST_ID IS NULL)
	THEN
		p_ERR_MSG := 'Item Code is not valid';
        RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG);
	END IF;
	IF(p_ACCOUNT_ID IS NULL)
	THEN
		p_ERR_MSG := 'Account Code is not valid';
        RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG);
	END IF;

	SELECT CASE WHEN EXISTS (SELECT 1
                               FROM TB_DP_MEASURE_DATA
                              WHERE ITEM_MST_ID = p_ITEM_MST_ID
                                AND ACCOUNT_ID = p_ACCOUNT_ID
                                AND BASE_DATE = p_BASE_DATE 
           ) THEN '1' ELSE '0' END INTO p_ERR_STATUS
      FROM DUAL;

    IF (p_ERR_STATUS='1')
    THEN
        -- UPDATE	
        p_SQL := 
        'UPDATE TB_DP_MEASURE_DATA'
			  ||' SET '||p_MEASURE||'_QTY ='||COALESCE(TO_CHAR(p_QTY),'NULL')
			  ||','||p_MEASURE||'_AMT ='||COALESCE(TO_CHAR(p_AMT),'NULL')
			  ||', MODIFY_BY ='''||p_USER_ID||''''
			  ||', MODIFY_DTTM = SYSDATE'
			  ||' WHERE ITEM_MST_ID ='''|| p_ITEM_MST_ID||''''
			  ||' AND ACCOUNT_ID ='''|| p_ACCOUNT_ID||''''
			  ||' AND BASE_DATE =:p_BASE_DATE'
        ;
    ELSE
        -- INSERT
        p_SQL := 
			'INSERT INTO TB_DP_MEASURE_DATA '
			||'( ID, ITEM_MST_ID'
			||',ACCOUNT_ID'
			||',BASE_DATE'
			||','||p_MEASURE||'_QTY'
			||','||p_MEASURE||'_AMT'
			||',CREATE_BY, CREATE_DTTM'
			||') VALUES ('
			||'TO_SINGLE_BYTE(SYS_GUID())'
			|| ','''||p_ITEM_MST_ID||''''
			||','''||p_ACCOUNT_ID||''''
			||',:p_BASE_DATE'
			||','||COALESCE(TO_CHAR(p_QTY),'NULL')
			||','||COALESCE(TO_CHAR(p_AMT),'NULL')
			||','''||p_USER_ID||''''
			||',SYSDATE'
			||')'
        ;
    END IF;

    --EXEC SP_EXECUTESQL p_SQL, N'p_BASE_DATE AS DATE', p_BASE_DATE
    EXECUTE IMMEDIATE p_SQL USING p_BASE_DATE;


    p_RT_MSG := 'MSG_0001';
    p_RT_ROLLBACK_FLAG := 'true';

     EXCEPTION WHEN OTHERS THEN
              IF(SQLCODE = -20001)
              THEN
                  P_RT_MSG := SQLERRM; 
                  p_RT_ROLLBACK_FLAG := 'false';
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;   	

END;
/

