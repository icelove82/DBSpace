create PROCEDURE "SP_UI_DP_18_S1" (
    p_ID                   IN     VARCHAR2    := ''            
  , p_UI_ID                IN     VARCHAR2    := ''         
  , p_GRID_ID              IN     VARCHAR2    := ''           
  , p_GRP_ID               IN     VARCHAR2    := ''    
  , p_LV_MGMT_ID           IN     VARCHAR2    := ''   
  , p_COL_NM               IN     VARCHAR     := ''      
  , p_DISP_NM              IN     VARCHAR     := ''      
  , p_SEQ                  IN     INT         := ''  
  , p_ACTV_YN              IN     CHAR        := ''     
  , p_USER_ID              IN     VARCHAR2    := ''     
  , P_RT_ROLLBACK_FLAG     OUT    VARCHAR2 
  , P_RT_MSG               OUT    VARCHAR2 
) 
IS
/**********************************************************************************************************************
    History
    - 2020.01.07 / kimsohee / exception during level mgmt id is null by custom dimension
    - 2021.03.1* / kimshoee / about comment
                            / add a exception about BF view
    - 2021.06.07 / KSH / dimension code : comment key                       
   -- 2021.06.16 / Kim sohee / keep Preference Data by user  
   - 2021.10.21 / kimsohee / Crosstab apply yn = actv yn
   - 2021.11.30 / KSH / SALES Key only UI_DP_25,26 (UI_DP_28 crosstab bug fix)
**********************************************************************************************************************/
    P_ERR_STATUS        INT  := 0;
    P_ERR_MSG           VARCHAR2(4000)  :='';
    V_DIM_CD            VARCHAR2(50);  --Dimension Code 
    V_FILD_VAL          VARCHAR2(50);
    V_SEQ               INT             := 0;
    V_DISP_NM           VARCHAR2(50);
    V_USER_PREF_MST_ID  CHAR(32);
    V_USER_PREF_CNT     INT;
    V_NEW_ID            CHAR(32);

BEGIN
    /************************************************************************************************
        -- Validation
    ************************************************************************************************/
    IF P_UI_ID IS NULL THEN
        P_ERR_MSG := 'UI ID is empty.';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

    IF P_GRID_ID IS NULL THEN
        P_ERR_MSG := 'Grid ID is empty.';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

    IF P_GRP_ID IS NULL THEN
        P_ERR_MSG := 'Group Code is empty.';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

    IF P_LV_MGMT_ID IS NULL THEN
        P_ERR_MSG := 'Level Code is empty.';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

    IF P_COL_NM IS NULL THEN
        P_ERR_MSG := 'Column Name is empty.';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

    IF P_SEQ IS NULL THEN
        P_ERR_MSG := 'Sequence is empty.';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;


    -- get PREF_MST_ID
    SELECT ID INTO V_USER_PREF_MST_ID
      FROM TB_AD_USER_PREF_MST
     WHERE VIEW_CD = P_UI_ID
       AND GRID_CD = P_GRID_ID;

    SELECT count(1) INTO P_ERR_STATUS
      FROM TB_CM_LEVEL_MGMT LM
     INNER JOIN TB_CM_COMM_CONFIG CF
        ON CF.ID = LM.LV_TP_ID AND CF.CONF_GRP_CD = 'DP_LV_TP'
     WHERE LM.ID = P_LV_MGMT_ID;   

    IF(P_ERR_STATUS > 0)
        THEN
            SELECT LV_CD || '_'
                         || CASE WHEN  LM.SALES_LV_YN  = 'Y'                                                   THEN REPLACE(P_COL_NM, 'SALES_LV_', '')
                                 WHEN  LM.SALES_LV_YN != 'Y' AND LM.ACCOUNT_LV_YN  = 'Y'                       THEN REPLACE(P_COL_NM, 'ACCOUNT_', '')
                                 WHEN  LM.SALES_LV_YN != 'Y' AND LM.ACCOUNT_LV_YN != 'Y' AND LM.LEAF_YN != 'Y' THEN REPLACE(P_COL_NM, 'ITEM_LV_', '')
                                 WHEN  LM.SALES_LV_YN != 'Y' AND LM.ACCOUNT_LV_YN != 'Y' AND LM.LEAF_YN  = 'Y' THEN REPLACE(P_COL_NM, 'ITEM_', '')
                            END
              INTO V_DISP_NM
              FROM TB_CM_LEVEL_MGMT LM
             INNER JOIN TB_CM_COMM_CONFIG CF
                ON CF.ID = LM.LV_TP_ID AND CF.CONF_GRP_CD = 'DP_LV_TP'
             WHERE LM.ID = P_LV_MGMT_ID;        
        ELSE
            V_DISP_NM := P_COL_NM;        
        END IF
        ;
    /************************************************************************************************
        -- Make Dimension Data
    ************************************************************************************************/
    --01.DIMENSION SETTING DATA
    MERGE INTO TB_DP_DIM_SETTING TARGET
    USING ( 
            SELECT
                 p_ID               AS ID
                ,p_UI_ID            AS UI_ID            
                ,p_GRID_ID          AS GRID_ID    
                ,p_GRP_ID           AS GRP_ID                    
                ,p_LV_MGMT_ID       AS LV_MGMT_ID                
                ,p_COL_NM           AS COL_NM                
                ,V_DISP_NM          AS DISP_NM            
                ,p_SEQ              AS SEQ        
                --,CASE WHEN p_ACTV_YN = 1 THEN 'Y' ELSE 'N'END     AS ACTV_YN    
                ,p_ACTV_YN          AS ACTV_YN            
                ,p_USER_ID          AS USER_ID    
            FROM DUAL
                ) SOURCE
    ON      (TARGET.ID            = SOURCE.ID    ) 
    WHEN NOT MATCHED THEN 
        INSERT (
                 ID
                ,UI_ID    
                ,GRID_ID    
                ,GRP_ID
                ,LV_MGMT_ID
                ,COL_NM    
                ,DISP_NM    
                ,SEQ        
                ,ACTV_YN        
                ,CREATE_BY
                ,CREATE_DTTM
                ) 
        VALUES (
                 TO_SINGLE_BYTE(SYS_GUID()) 
                ,SOURCE.UI_ID        
                ,SOURCE.GRID_ID    
                ,SOURCE.GRP_ID    
                ,SOURCE.LV_MGMT_ID    
                ,SOURCE.COL_NM        
                ,SOURCE.DISP_NM        
                ,SOURCE.SEQ    
                ,SOURCE.ACTV_YN       
                ,SOURCE.USER_ID       
                ,SYSDATE
                 )
    WHEN MATCHED THEN
            UPDATE 
            SET  TARGET.LV_MGMT_ID = SOURCE.LV_MGMT_ID
                ,TARGET.COL_NM      = SOURCE.COL_NM                              
                ,TARGET.DISP_NM     = SOURCE.DISP_NM                                        
                ,TARGET.SEQ         = SOURCE.SEQ    
                ,TARGET.ACTV_YN     = SOURCE.ACTV_YN                                      
                ,TARGET.MODIFY_BY   = SOURCE.USER_ID       
                ,TARGET.MODIFY_DTTM = SYSDATE     
    ;

    SELECT COUNT(ID) INTO P_ERR_STATUS
      FROM TB_DP_DIM_SETTING
     WHERE 1=1
       AND UI_ID = P_UI_ID
       AND GRP_ID = P_GRP_ID
       AND GRID_ID = P_GRID_ID
       AND ID = P_ID
    ;
    /************************************************************************************************
        -- Make Preference Data
    ************************************************************************************************/
    -- Insert New Data
    IF (P_ERR_STATUS = 0)   
    THEN           
        SP_UI_DP_18_PERSON_AUTO_CREATE(
            P_GRP_ID
          , P_UI_ID
          , P_GRID_ID
          , P_USER_ID
          , P_RT_ROLLBACK_FLAG
          , P_RT_MSG);

    ELSE    
        -- make Defult data (ex. item, account, date,....)
        SELECT COUNT(*) INTO V_USER_PREF_CNT
          FROM TB_AD_USER_PREF_DTL
         WHERE USER_PREF_MST_ID = V_USER_PREF_MST_ID
           AND GRP_ID = P_GRP_ID
           AND DATA_KEY_YN = 'Y'
        ;
        IF V_USER_PREF_CNT = 0
        THEN
            INSERT INTO TB_AD_USER_PREF_DTL (
                ID
              , USER_PREF_MST_ID 
              , GRP_ID 
              , FLD_CD
              , FLD_APPLY_CD
              , FLD_WIDTH
              , FLD_SEQ
              , FLD_ACTIVE_YN
              , APPLY_YN
              , CROSSTAB_ITEM_CD
              , DIM_MEASURE_TP
              , SUMMARY_YN
              , EDIT_MEASURE_YN
              , EDIT_TARGET_YN 
              , DATA_KEY_YN
              , CROSSTAB_YN
              , CREATE_BY
              , CREATE_DTTM
            )
            WITH
            MAIN 
             AS (
                SELECT V_USER_PREF_MST_ID   AS USER_PREF_MST_ID
                     , P_GRP_ID             AS GRP_ID
                     , 0                    AS SEQ
                     , 100                  AS FIELD_WDTH
                     , 'N'                  AS PSNZ_APPY_YN
                     , 'DEFAULT'            AS DIM_MEASURE_TP
                     , 'Y'                  AS PIVOT_APPY_YN
                     , P_USER_ID            AS CREATE_BY
                     , SYSDATE              AS CREATE_DTTM
                  FROM DUAL
            ),
            DATA_KEY AS (
                SELECT 'ITEM'           AS FIELD_ID
                     ,  NULL			AS FLD_APPLY_CD                
                     , 'GROUP-COLUMNS'  AS PIVOT_ITEM_CD
                     , 'N'              AS ACTV_YN
                     , 'Y'              AS DATA_KEY_YN
                     , 'N'              AS DAT_FIELD_YN
                     , 'N'              AS EDIT_TARGET 
                FROM dual
                UNION  
                SELECT 'SALES'          AS FIELD_ID
                     ,  NULL			AS FLD_APPLY_CD                
                     , 'GROUP-COLUMNS'  AS PIVOT_ITEM_CD
                     , 'N'              AS ACTV_YN
                     , 'Y'              AS DATA_KEY_YN
                     , 'N'              AS DAT_FIELD_YN
                     , 'N'              AS EDIT_TARGET 
                FROM dual
               WHERE P_UI_ID IN ('UI_DP_25', 'UI_DP_26')
                UNION  
                SELECT 'ACCOUNT'        AS FIELD_ID
                     ,  NULL			AS FLD_APPLY_CD                
                     , 'GROUP-COLUMNS'  AS PIVOT_ITEM_CD
                     , 'N'              AS ACTV_YN
                     , 'Y'              AS DATA_KEY_YN
                     , 'N'              AS DAT_FIELD_YN
                     , 'N'              AS EDIT_TARGET
                FROM dual
                UNION  
                SELECT 'DATE'           AS FIELD_ID
                     ,  NULL			AS FLD_APPLY_CD                
                     , 'GROUP-ROWS'     AS PIVOT_ITEM_CD
                     , 'Y'              AS ACTV_YN
                     , 'N'              AS DATA_KEY_YN
                     , 'Y'              AS DAT_FIELD_YN
                     , 'Y'              AS EDIT_TARGET
                FROM dual
                UNION  
                SELECT 'PERIOD'                   AS FIELD_ID
                     ,  NULL			AS FLD_APPLY_CD                
                     , 'GROUP-HORIZONTAL-VALUES'  AS PIVOT_ITEM_CD
                     , 'N'                        AS ACTV_YN
                     , 'N'                        AS DATA_KEY_YN
                     , 'N'                        AS DAT_FIELD_YN
                     , 'N'                        AS EDIT_TARGET -- UI ?솕硫댁뿉?꽌 蹂댁뿬吏?吏? ?븡?룄濡? N 泥섎━
                FROM dual
               WHERE P_UI_ID IN ('UI_DP_25', 'UI_DP_26')      
                UNION  
                SELECT 'CATEGORY'     AS FIELD_ID
                     ,  NULL			AS FLD_APPLY_CD
                     , NULL           AS PIVOT_ITEM_CD
                     , 'Y'            AS ACTV_YN
                     , 'N'            AS DATA_KEY_YN
                     , 'N'            AS DAT_FIELD_YN 
                     , 'N'            AS EDIT_TARGET
                FROM dual
                UNION  
                SELECT 'BUCK_TP'     AS FIELD_ID
                     ,  NULL			AS FLD_APPLY_CD
                     , 'GROUP-COLUMNS'           AS PIVOT_ITEM_CD
                     , 'N'            AS ACTV_YN
                     , 'N'            AS DATA_KEY_YN
                     , 'N'            AS DAT_FIELD_YN 
                     , 'N'            AS EDIT_TARGET
                FROM dual 
               where P_UI_ID like 'UI_DP_95%' or P_UI_ID like 'UI_BP_95%'
               UNION
              SELECT  CONF_CD		AS FIELD_ID
                    ,  '_'||CONF_CD		AS FLD_APPLY_CD
                    ,  'GROUP-HORIZONTAL-VALUES' AS PIVOT_ITEM_CD
                    , 'N'				AS ACTV_YN
                    , 'N'				AS DATA_KEY_YN
                    , 'N'				AS DAT_FIELD_YN
                    , ACTV_YN			AS EDIT_TARGET 
               FROM TB_CM_COMM_CONFIG 
              where CONF_GRP_CD = 'DP_USE_COMMENT'
               AND (P_UI_ID LIKE 'UI_DP_9%' OR P_UI_ID LIKE 'UI_BP_9%'	 )
            )
            SELECT TO_SINGLE_BYTE(SYS_GUID())
                 , A.USER_PREF_MST_ID
                 , A.GRP_ID
                 , B.FIELD_ID
                 , B.FLD_APPLY_CD
                 , A.FIELD_WDTH
                 , A.SEQ
                 , B.ACTV_YN
                 , A.PSNZ_APPY_YN
                 , B.PIVOT_ITEM_CD
                 , A.DIM_MEASURE_TP
                 , 'N'
                 , 'N'
                 , B.EDIT_TARGET
                 , B.DATA_KEY_YN
                 , A.PIVOT_APPY_YN
                 , A.CREATE_BY
                 , A.CREATE_DTTM
              FROM MAIN A
                   CROSS JOIN 
                   DATA_KEY B
            ;

        END IF;

                SELECT COUNT(FLD_CD)
                  INTO P_ERR_STATUS
                  FROM TB_AD_USER_PREF_DTL PER
                 WHERE PER.DIM_MEASURE_TP = 'DIMENSION'
                   AND PER.USER_PREF_MST_ID = V_USER_PREF_MST_ID
                   AND PER.GRP_ID = P_GRP_ID
                   AND PER.REFER_VALUE = P_ID;

                IF P_ERR_STATUS = 0 
                THEN
                    P_ERR_MSG := 'NO DATA FOR: [' || V_USER_PREF_MST_ID || ', ' || P_GRP_ID || ', ' || P_ID || ']';
                    RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
                ELSE
                    SELECT FLD_CD
                      INTO V_DIM_CD
                      FROM TB_AD_USER_PREF_DTL PER
                     WHERE PER.DIM_MEASURE_TP = 'DIMENSION'
                       AND PER.USER_PREF_MST_ID = V_USER_PREF_MST_ID
                       AND PER.GRP_ID = P_GRP_ID
                       AND PER.REFER_VALUE = P_ID;
                END IF;

                MERGE INTO TB_AD_USER_PREF_DTL TARGET
                USING (
                    SELECT V_USER_PREF_MST_ID   AS USER_PREF_MST_ID
                         , V_DIM_CD             AS FLD_CD
                         , P_GRP_ID             AS GRP_ID
                         , P_ID                 AS REFER_VALUE
                         , V_DISP_NM            AS FLD_APPLY_CD
                         , P_ACTV_YN            AS FLD_ACTIVE_YN
                         , P_SEQ                AS FLD_SEQ
                         , 100                  AS FLD_WIDTH
                         , 'Y'                  AS APPLY_YN
                         , 'GROUP-COLUMNS'      AS CROSSTAB_ITEM_CD
                         , 'DIMENSION'          AS DIM_MEASURE_TP
                         , P_USER_ID            AS USER_ID
                      FROM DUAL
                ) SOURCE
                ON (TARGET.USER_PREF_MST_ID = SOURCE.USER_PREF_MST_ID
                    AND TARGET.GRP_ID       = SOURCE.GRP_ID
                    AND TARGET.REFER_VALUE  = SOURCE.REFER_VALUE
                )
                WHEN MATCHED THEN
                    UPDATE
                    SET TARGET.FLD_APPLY_CD     = SOURCE.FLD_APPLY_CD
                      , TARGET.FLD_ACTIVE_YN    = SOURCE.FLD_ACTIVE_YN
                      , TARGET.FLD_SEQ          = SOURCE.FLD_SEQ
                      , TARGET.FLD_WIDTH        = SOURCE.FLD_WIDTH
                      , TARGET.APPLY_YN         = SOURCE.APPLY_YN
                      , TARGET.MODIFY_BY        = SOURCE.USER_ID
                      , TARGET.MODIFY_DTTM      = SYSDATE
                      , TARGET.CROSSTAB_YN      = SOURCE.FLD_ACTIVE_YN -- CASE WHEN REPLACE(P_UI_ID, 'BP', 'DP') LIKE 'UI_DP_9%' THEN SOURCE.FLD_ACTIVE_YN ELSE 'Y' END 
                        ;            




        UPDATE TB_AD_USER_PREF_DTL TAR
           SET TAR.FLD_SEQ = (
                SELECT CASE WHEN FLD_CD = 'CATEGORY'    THEN A.NEW_SEQ + 1
                            WHEN FLD_CD = 'DATE'        THEN A.NEW_SEQ + 2
                            WHEN FLD_CD = 'PERIOD'      THEN A.NEW_SEQ + 3
                            ELSE 0 END
                  FROM (
                    SELECT USER_PREF_MST_ID
                         , GRP_ID
                         , MAX(COALESCE(FLD_SEQ, 0)) AS NEW_SEQ
                      FROM TB_AD_USER_PREF_DTL A
                     WHERE A.USER_PREF_MST_ID = V_USER_PREF_MST_ID
                       AND A.GRP_ID = P_GRP_ID
                       AND A.DIM_MEASURE_TP != 'MEASURE'
                     GROUP BY USER_PREF_MST_ID, GRP_ID
                  ) A
--                 WHERE TAR.USER_PREF_MST_ID = A.USER_PREF_MST_ID
--                   AND TAR.GRP_ID = A.GRP_ID
--                   AND TAR.FLD_CD IN ('CATEGORY', 'DATE', 'PERIOD')
           )
       WHERE USER_PREF_MST_ID = V_USER_PREF_MST_ID 
       AND GRP_ID = P_GRP_ID
       AND FLD_CD IN ('CATEGORY', 'DATE', 'PERIOD')
        ;

				   /************************************************************************************************************************
						-- Re-make TB_AD_USER_PREF
				   *************************************************************************************************************************/
				   -- TB_AD_USER_PREF 테이블에 데이터 생길때, 한번에 다 생기나? 아니면 .. FIELD 단위로 생기나?? 전자인것같긴한데

				   INSERT INTO TEMP_AD_USER_PREF 
				   (  USER_ID			
					, GRP_ID			
					, FLD_CD			
					, FLD_APPLY_CD		
					, FLD_WIDTH		
					, FLD_SEQ			
					, FLD_ACTIVE_YN	
					, APPLY_YN			
--					, REFER_VALUE		
					, DIM_MEASURE_TP 
					, CROSSTAB_ITEM_CD	
					, CATEGORY_GROUP	
					, SUMMARY_TP		
					, SUMMARY_YN		
					, EDIT_MEASURE_YN	
					, EDIT_TARGET_YN	
					, DATA_KEY_YN		
					, CROSSTAB_YN		
					, CREATE_BY	
					, CREATE_DTTM					
					)		 
					SELECT USER_ID
						 , GRP_ID
						 , FLD_CD
						 , FLD_APPLY_CD
						 , FLD_WIDTH
						 , FLD_SEQ
						 , FLD_ACTIVE_YN
						 , APPLY_YN
--						 , REFER_VALUE
						 , DIM_MEASURE_TP 
						 , CROSSTAB_ITEM_CD
						 , CATEGORY_GROUP
						 , SUMMARY_TP
						 , SUMMARY_YN
						 , EDIT_MEASURE_YN
						 , EDIT_TARGET_YN
						 , DATA_KEY_YN
						 , CROSSTAB_YN
						 , CREATE_BY	
						 , CREATE_DTTM	
					 FROM TB_AD_USER_PREF
					WHERE USER_PREF_MST_ID = V_USER_PREF_MST_ID
					  AND DIM_MEASURE_TP != 'MEASURE'
					  AND REFER_VALUE = P_ID
					  ;
				DELETE 
				  FROM TB_AD_USER_PREF
				 WHERE USER_PREF_MST_ID = V_USER_PREF_MST_ID
				   AND DIM_MEASURE_TP != 'MEASURE'
				   AND REFER_VALUE = P_ID
				   ;

				INSERT INTO TB_AD_USER_PREF
				( ID
				, USER_ID
				, USER_PREF_MST_ID
				, GRP_ID
				, FLD_CD
				, FLD_APPLY_CD
				, FLD_WIDTH
				, FLD_SEQ
				, FLD_ACTIVE_YN
				, APPLY_YN
				, REFER_VALUE
				, CROSSTAB_ITEM_CD
				, CATEGORY_GROUP
				, DIM_MEASURE_TP
				, SUMMARY_TP
				, SUMMARY_YN
				, EDIT_MEASURE_YN
				, EDIT_TARGET_YN
				, DATA_KEY_YN
				, CROSSTAB_YN
				, CREATE_BY
				, CREATE_DTTM
				, MODIFY_BY
				, MODIFY_DTTM
				)                   
				WITH PREF_USER
				 AS (
					SELECT DISTINCT USER_ID FROM TEMP_AD_USER_PREF 
				 ), NEW_USER_PREF
				AS ( 
					 SELECT D.GRP_ID
						  , D.FLD_CD
						  , D.FLD_APPLY_CD
						  , D.FLD_WIDTH
						  , D.FLD_SEQ
						  , D.FLD_ACTIVE_YN
						  , D.APPLY_YN
--						  , D.REFER_VALUE
						  , D.CROSSTAB_ITEM_CD
						  , D.CATEGORY_GROUP
						  , D.DIM_MEASURE_TP
						  , D.SUMMARY_TP
						  , D.SUMMARY_YN
						  , D.EDIT_MEASURE_YN
						  , D.EDIT_TARGET_YN
						  , D.DATA_KEY_YN
						  , D.CROSSTAB_YN	
						  , P.USER_ID 				 
					   FROM TB_AD_USER_PREF_DTL D
							CROSS JOIN
							PREF_USER P 
					  WHERE D.USER_PREF_MST_ID = V_USER_PREF_MST_ID
						AND D.DIM_MEASURE_TP != 'MEASURE'
						AND REFER_VALUE = P_ID
				   )
				SELECT	TO_SINGLE_BYTE(SYS_GUID()) AS ID 
					  , M.USER_ID 	
					  , V_USER_PREF_MST_ID
					  , M.GRP_ID
					  , M.FLD_CD
					  , M.FLD_APPLY_CD
					  , COALESCE(S.FLD_WIDTH		, M.FLD_WIDTH		)
					  , COALESCE(S.FLD_SEQ			, M.FLD_SEQ			)
					  , COALESCE(S.FLD_ACTIVE_YN	, M.FLD_ACTIVE_YN	)
					  , M.APPLY_YN
					  , P_ID REFER_VALUE
					  , M.CROSSTAB_ITEM_CD
					  , M.CATEGORY_GROUP
					  , M.DIM_MEASURE_TP
					  , M.SUMMARY_TP
					  , M.SUMMARY_YN
					  , M.EDIT_MEASURE_YN
					  , M.EDIT_TARGET_YN
					  , M.DATA_KEY_YN
					  , M.CROSSTAB_YN	
					  , COALESCE(S.CREATE_BY   ,	'system')  CREATE_BY
					  , COALESCE(S.CREATE_DTTM ,SYSDATE)	   CREATE_DTTM
					  , CASE WHEN S.FLD_CD IS NULL THEN NULL ELSE 'system'	END
					  , CASE WHEN S.FLD_CD IS NULL THEN NULL ELSE SYSDATE END
				  FROM NEW_USER_PREF M 
					   LEFT OUTER JOIN 
					   TEMP_AD_USER_PREF S
					ON M.GRP_ID = S.GRP_ID
				   AND M.USER_ID = S.USER_ID 
				   AND M.DIM_MEASURE_TP = S.DIM_MEASURE_TP
				  ;

					DELETE FROM TEMP_AD_USER_PREF;

    END IF; -- DIMENSION IF



    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';  --.

EXCEPTION WHEN OTHERS THEN  --  e_products_invalid    
    IF(SQLCODE = -20001)
    THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
    SP_COMM_RAISE_ERR();              
    --    RAISE;
    END IF;   
 END;
/

