create PROCEDURE                "SP_UI_DP_20_S1_J" (
                                       P_JSON			    CLOB
                                     , P_USER_ID            VARCHAR2
                                     , P_RT_ROLLBACK_FLAG   OUT VARCHAR2
                                     , P_RT_MSG             OUT VARCHAR2		
	  								   ) 
IS
    P_ERR_MSG       VARCHAR2(4000);
/*****************************************************************************************************************
Title : SP_UI_DP_20_S1_J
  - DP Sales price Management Save (Json Param Bulk Insert)

설명 
  - OPENJSON : https://docs.microsoft.com/ko-kr/sql/t-sql/functions/openjson-transact-sql?view=sql-server-ver15

 
History (수정일자 / 수정자 / 수정내용)
- 2022.01.13 / kim sohee / json bulk insert draft
******************************************************************************************************************/         
BEGIN
/*** MESSAGE VALIDATION *******************************************************************************************
-- Price type
    IF(p_PRICE_TP_ID IS NULL)
    THEN
    	SELECT ID INTO P_PRICE_TP_ID
    	  FROM TB_CM_COMM_CONFIG
    	 WHERE CONF_CD = p_PRICE_TP_CD;
    END IF;
-- Employee 
	SELECT ID INTO p_EMP_ID 
	  FROM TB_AD_USER
	WHERE USERNAME = p_EMP_NO
    ;

    IF (p_ACCOUNT_ID IS NULL)
    THEN
        SELECT ID  INTO p_ACCOUNT_ID
          FROM TB_DP_ACCOUNT_MST
         WHERE ACCOUNT_CD = p_ACCOUNT_CD;
    END IF;


    IF (p_ITEM_MST_ID IS NULL)
    THEN
        SELECT ID  INTO P_ITEM_MST_ID
          FROM TB_CM_ITEM_MST
         WHERE ITEM_CD = P_ITEM_CD;
    END IF;


    IF (P_ACCOUNT_ID IS NULL)
	THEN
	    P_ERR_MSG := 'MSG_0015'; 
	    RAISE_APPLICATION_ERROR(-20000, P_ERR_MSG);		
	END IF;

    IF (P_ITEM_MST_ID IS NULL)
	THEN
	    P_ERR_MSG := 'MSG_0017'; 
	    RAISE_APPLICATION_ERROR(-20000, P_ERR_MSG);		
	END IF;

    SELECT count(*) INTO P_ERR_STATUS
      FROM TABLE(FN_DP_TEMP_USER_ITEM_ACCOUNT(P_EMP_ID, P_AUTH_TP_ID))
     WHERE ITEM_ID = P_ITEM_MST_ID
       AND ACCOUNT_ID = P_ACCOUNT_ID;

    IF P_ERR_STATUS = 0 THEN
        P_ERR_MSG := 'This Item, Account Mapping is not valid.';
        RAISE_APPLICATION_ERROR(-20000, P_ERR_MSG);
    END IF;
*/	

 /*** 본 프로시저 시작 *************************************************************************************************/
            INSERT INTO TEMP_DP_SALES_PRICE(ITEM_CD, ACCOUNT_CD, BASE_DATE, UTPIC, PRICE_TP_CD)
                    SELECT M.ITEM_CD, M.ACCOUNT_CD                                   
                        ,M.BASE_DATE				 AS  BASE_DATE       
                        ,M.UTPIC					 AS  UTPIC    
                        ,M.PRICE_TP_CD						 AS  PRICE_TP_ID  
                 FROM JSON_TABLE ( P_JSON,  '$[*]'  
                              COLUMNS (   ITEM_CD		    PATH	    '$.ITEM_CD'
                                        , ACCOUNT_CD		PATH	    '$.ACCOUNT_CD'
                                        , BASE_DATE			DATE PATH	'$.BASE_DATE'
                                        , UTPIC		        PATH	    '$.UTPIC'
                                        , PRICE_TP_CD		PATH	    '$.PRICE_TP_CD'
                                        , ROW_STATUS		PATH	    '$.ROW_STATUS'
                                      )                                      
                                ) M
                                ;

				MERGE INTO TB_DP_UNIT_PRICE TGT
				USING (
                        WITH PRICE_TYPE
                          AS (SELECT ID, CONF_CD 
                              FROM TB_CM_COMM_CONFIG 
                             WHERE CONF_GRP_CD = 'DP_PRICE_TYPE'				 
                           )                
                            SELECT   A.ID						 AS  ACCOUNT_ID      
                                    ,I.ID						 AS  ITEM_MST_ID     
                                    ,M.BASE_DATE				 AS  BASE_DATE       
                                    ,M.UTPIC					 AS  UTPIC    
                                    ,P.ID						 AS  PRICE_TP_ID  
                             FROM TEMP_DP_SALES_PRICE M
                                 INNER JOIN 
                                 PRICE_TYPE P
                              ON M.PRICE_TP_CD = P.CONF_CD 
                                 INNER JOIN 
                                 TB_CM_ITEM_MST I
                              ON M.ITEM_CD = I.ITEM_CD
                                 INNER JOIN 
                                 TB_DP_ACCOUNT_MST A
                              ON M.ACCOUNT_CD = A.ACCOUNT_CD
					  ) SRC
				ON (    TGT.ACCOUNT_ID  = SRC.ACCOUNT_ID
    				AND TGT.ITEM_MST_ID = SRC.ITEM_MST_ID
    				AND TGT.BASE_DATE   = SRC.BASE_DATE
    				AND TGT.PRICE_TP_ID = SRC.PRICE_TP_ID
				)
				WHEN MATCHED THEN
					 UPDATE 
					   SET   UTPIC         = SRC.UTPIC      
							,MODIFY_BY     = P_USER_ID       
							,MODIFY_DTTM   = SYSDATE      
				WHEN NOT MATCHED THEN 
					 INSERT (    ID          
                                ,ACCOUNT_ID 
                                ,ITEM_MST_ID
                                ,BASE_DATE  
                                ,UTPIC     
                                ,PRICE_TP_ID  -- CURCY_CD_ID
                                ,CREATE_BY
                                ,CREATE_DTTM
							) 
					 VALUES (    TO_SINGLE_BYTE(SYS_GUID())
                                ,SRC.ACCOUNT_ID    
                                ,SRC.ITEM_MST_ID   
                                ,SRC.BASE_DATE     
                                ,SRC.UTPIC    
                                ,SRC.PRICE_TP_ID     
                                ,P_USER_ID 
                                ,SYSDATE           
 							) 
		          ;    

 
                              
    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';  
   DELETE FROM TEMP_DP_SALES_PRICE;
       /* ============================================================================*/
EXCEPTION WHEN OTHERS THEN  --  e_products_invalid    
    IF(SQLCODE = -20001)
    THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
    --SP_COMM_RAISE_ERR();              
        RAISE;
    END IF; 	

END;
/

