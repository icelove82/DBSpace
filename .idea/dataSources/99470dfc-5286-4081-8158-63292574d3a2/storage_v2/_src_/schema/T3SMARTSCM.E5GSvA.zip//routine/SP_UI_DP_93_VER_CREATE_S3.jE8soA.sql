create PROCEDURE "SP_UI_DP_93_VER_CREATE_S3"  (
			P_VER_CD					VARCHAR2 
		  , P_PLAN_TP_ID				CHAR 
          , pRESULT        OUT SYS_REFCURSOR
)
IS 
   
		   P_VER_ID			CHAR(32);
		   P_FROM_DATE		DATE ;
		   P_TO_DATE		DATE ;
		   P_SM_DATE		DATE ;		   
           P_ORA_STR    VARCHAR2(4000);           
		   -- For Loop 
		   P_STR	VARCHAR2(4000); 
           p_SELECT_STR    NVARCHAR2(4000);
		   P_VAL_CNT  INT ;
/*
    SP_UI_DP_93_VER_CREATE_S3

    History ( date / writer / comment)
    - 2022-07-04 / kim sohee / literal does not match format string bug fix : + date format, yyyy-MM-dd
    - 2023.01.14 / KIM SOHEE / QTY_I
    - 2023.02.02 / Kim sohee / Function => Temp Table
    
*/           
BEGIN 
	-- Make Function : #VER_INFO_DTL => TABLE(FN_DP_TEMP_VER_INFO_DTL (P_VER_ID)) , #VER_INFO_INIT => TABLE(FN_DP_TEMP_VER_INFO_INIT (P_VER_ID)), #IAC => TABLE(FN_DP_TEMP_ITEM_ACCT_ROLE_DATE (P_VER_ID))
    -- Mkae Temp table : #PR => FN_DP_TEMP_PR_VER , #RT => TEMP_DP_RT
/************************************************************************************************************
	-- Get Version Config
************************************************************************************************************/
	 SELECT   ID 
			, FROM_DATE	
			, TO_DATE		
	    INTO  P_VER_ID		
	   	    , P_FROM_DATE	
	   	    , P_TO_DATE		
	   FROM TB_DP_CONTROL_BOARD_VER_MST 
	  WHERE VER_ID = P_VER_CD 
	   ;
	--------------- 1. Get Versison Detail Info (Initial value type by authority type)




/**************************************************************************************************************************************
	-- Close 하지 않은 이전 버전 정리
*************************************************************************************************************************************/
/*
	DELETE FROM TB_DP_ENTRY
	WHERE VER_ID 
      IN (SELECT CONBD_VER_MST_ID
	  FROM TB_DP_CONTROL_BOARD_VER_DTL D
	 WHERE D.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_cD = 'DP_WK_TP' AND CONF_CD = 'CL')
	  AND D.CL_STATUS_ID != (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
	  AND PLAN_TP_ID = P_PLAN_TP_ID
	  AND CONBD_VER_MST_ID != P_VER_ID)
	;  
	DELETE FROM TB_DP_CONTROL_BOARD_VER_DTL
	WHERE CONBD_VER_MST_ID IN (
	SELECT CONBD_VER_MST_ID
	  FROM TB_DP_CONTROL_BOARD_VER_DTL D
	 WHERE D.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_cD = 'DP_WK_TP' AND CONF_CD = 'CL')
	  AND D.CL_STATUS_ID != (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
	  AND PLAN_TP_ID = P_PLAN_TP_ID
	  AND CONBD_VER_MST_ID != P_VER_ID
      )
	; 
	DELETE FROM TB_DP_CONTROL_BOARD_VER_MST
	WHERE ID IN (
	SELECT CONBD_VER_MST_ID
	  FROM TB_DP_CONTROL_BOARD_VER_DTL D
	 WHERE D.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_cD = 'DP_WK_TP' AND CONF_CD = 'CL')
	  AND D.CL_STATUS_ID != (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
	  AND PLAN_TP_ID = P_PLAN_TP_ID
	  AND CONBD_VER_MST_ID != P_VER_ID
      )
	;
*/
/**********************************************************************************************************
    get user mapping data 
**********************************************************************************************************/

 INSERT INTO TEMP_DP_ITEM_ACCT_ROLE_DATE (ITEM_ID, ACCT_ID, ROLE_ID, EMP_ID, BASE_DATE)
 WITH VER_INFO
	AS (SELECT	 ID
                ,FROM_DATE 
                ,TO_DATE
                ,BUKT	
                ,PRICE_TP_ID				 
		 FROM TB_DP_CONTROL_BOARD_VER_MST 
	    WHERE ID = P_VER_ID 
	), CAL
	AS (
		SELECT MIN(DAT)	AS STRT_DT
			 , MAX(DAT) AS END_DT
		  FROM TB_CM_CALENDAR CAL
			   INNER JOIN
			   VER_INFO VER
			ON CAL.DAT BETWEEN VER.FROM_DATE AND VER.TO_DATE 
	  GROUP BY CASE VER.BUKT
						WHEN 'Y' THEN YYYY
						WHEN 'Q' THEN YYYY||'-'||TO_CHAR(QTR)
						WHEN 'M' THEN YYYYMM
						WHEN 'PW' THEN MM||'-'||DP_WK
						WHEN 'W' THEN DP_WK
					ELSE YYYYMMDD END    	
		), ITEM_HIER
	AS (
		SELECT ANCESTER_ID, ANCESTER_CD, DESCENDANT_ID, DESCENDANT_CD FROM TB_DPD_ITEM_HIER_CLOSURE WHERE LEAF_YN = 'Y' AND USE_YN = 'Y'
	), SALES_HIER
	AS (
		SELECT ANCESTER_ID, ANCESTER_CD, DESCENDANT_ID, DESCENDANT_CD FROM TB_DPD_SALES_HIER_CLOSURE WHERE LEAF_YN = 'Y' AND USE_YN = 'Y'
	), ITEM
	AS (  SELECT CASE WHEN CL.LEAF_YN = 'Y' THEN IM.ITEM_MST_ID ELSE IM.ITEM_LV_ID END	AS ID
						 , CL.LEAF_YN
						 , IM.AUTH_TP_ID 
						 , IM.EMP_ID
				FROM TB_DP_USER_ITEM_MAP IM 
					  INNER JOIN 
					  TB_CM_LEVEL_MGMT CL ON (IM.LV_MGMT_ID = CL.ID 
							  			 AND CL.ACTV_YN = 'Y'
							  			 AND CL.DEL_YN = 'N')
			   WHERE IM.ACTV_YN = 'Y'   
	), ACCT
	AS (-- 내 매핑 ACCT 찾기
			SELECT CASE WHEN CL.LEAF_YN = 'Y' THEN AM.ACCOUNT_ID ELSE AM.SALES_LV_ID END	AS ID
				 , AM.AUTH_TP_ID 
				 , AM.EMP_ID
				 , CL.LEAF_YN
			  FROM TB_DP_USER_ACCOUNT_MAP AM 
				   INNER JOIN
				   TB_CM_LEVEL_MGMT CL
				ON AM.LV_MGMT_ID = CL.ID 
			   AND CL.ACTV_YN = 'Y'
			   AND NVL(CL.DEL_YN, 'N') = 'N'
			 WHERE AM.ACTV_YN = 'Y'	 
	), IA_LEAF
	AS (	
	   SELECT  ACCT.AUTH_TP_ID
			 , ACCT.EMP_ID 
			 , CASE WHEN ITEM.LEAF_YN = 'Y' THEN ITEM.ID ELSE IH.DESCENDANT_ID END		AS ITEM_ID
			 , CASE WHEN ACCT.LEAF_YN = 'Y' THEN ACCT.ID ELSE SH.DESCENDANT_ID END		AS ACCT_ID
		  FROM ACCT		-- ACCT_SH
			   INNER JOIN
			   ITEM		-- ITEM_SH 
			ON ACCT.AUTH_TP_ID = ITEM.AUTH_TP_ID
		   AND ACCT.EMP_ID  = ITEM.EMP_ID
			   INNER JOIN 
			   ITEM_HIER IH ON ( ITEM.ID = IH.ANCESTER_ID )
			   INNER JOIN
			   SALES_HIER SH
			ON ACCT.ID = SH.ANCESTER_ID
	), IA
	AS (
    SELECT ACCOUNT_ID, ITEM_MST_ID, MAX(EMP_ID) AS EMP_ID 
      FROM (
            SELECT ACCT_ID  ACCOUNT_ID
                 , ITEM_ID  ITEM_MST_ID
                 , EMP_ID AS EMP_ID
              FROM IA_LEAF UIAM           
            UNION
            SELECT ACCOUNT_ID
                 , ITEM_MST_ID
                 , EMP_ID
              FROM TB_DP_USER_ITEM_ACCOUNT_MAP UIAM	-- item, account 각각의 매핑 정보가 있으면, 이 매핑 정보는 안본다.
                   INNER JOIN 
                   TB_CM_ITEM_MST IT 
                ON UIAM.ITEM_MST_ID = IT.ID
               AND IT.DEL_YN != 'Y' AND IT.DP_PLAN_YN = 'Y'
                  INNER JOIN 
                  TB_DP_ACCOUNT_MST AC
               ON UIAM.ACCOUNT_ID = AC.ID 
              AND AC.ACTV_YN = 'Y' 
              AND AC.DEL_YN != 'Y'
      )      
     GROUP BY ACCOUNT_ID, ITEM_MST_ID 
	), CONBD_VER
	AS (
        SELECT LV_MGMT_ID FROM TB_DP_CONTROL_BOARD_VER_DTL WHERE CONBD_VER_MST_ID = P_VER_ID AND LV_MGMT_ID IS NOT NULL 
        )
	SELECT ITEM_MST_ID
        , ACCOUNT_ID
        , LV_MGMT_ID
        , EMP_ID
        , STRT_DT
	  FROM IA	
		   CROSS JOIN
		   CAL 
           CROSS JOIN
           CONBD_VER 
		   ;


/************************************************************************************************************
	-- Initial Value
************************************************************************************************************/
    -- get previous DP version data
    SP_UI_DP_93_VER_CREATE_S3_01 (P_VER_ID, P_PLAN_TP_ID, pRESULT);  
    -- get measure data
    SP_UI_DP_93_VER_CREATE_S3_02 (P_VER_ID, P_FROM_DATE, P_TO_DATE, pRESULT);  --P_PLAN_TP_ID, 

--    OPEN pRESULT     FOR     SELECT * FROM TEMP_DP_RT;

 	 SELECT TO_DATE(CASE WHEN EXTRACT(MONTH FROM SYSDATE)>=PP.POLICY_VAL 
			 		THEN TO_CHAR(EXTRACT(YEAR FROM SYSDATE))
			 		ELSE TO_CHAR(EXTRACT(YEAR FROM SYSDATE)-1) 
			 END ||'-'||PP.POLICY_VAL||'-01', 'YYYY-MM-DD')
			 INTO P_SM_DATE 
	   FROM TB_DP_PLAN_POLICY  PP
		    INNER JOIN 
			TB_CM_COMM_CONFIG CC
		 ON PP.POLICY_ID = CC.ID 
	  WHERE PLAN_TP_ID = P_PLAN_TP_ID
	    AND CC.CONF_CD = 'SM'
		;
/************************************************************************************************************
	-- Result
************************************************************************************************************/


INSERT INTO TB_DP_ENTRY
		 (    ID
			, VER_ID
			, AUTH_TP_ID
			, EMP_ID
			, ITEM_MST_ID
			, ACCOUNT_ID
--			, SALES_LV_ID
			, BASE_DATE
			, QTY
			, QTY_I
			, AMT
			, CREATE_BY
			, CREATE_DTTM
			, PLAN_TP_ID
			, QTY_1
			, AMT_1
			, QTY_2
			, AMT_2
			, QTY_3
			, AMT_3		 
		    , QTY_A
			, AMT_A 
		 )
	WITH UNIT_PRICE
	AS (
		SELECT  ITEM_MST_ID
			   ,ACCOUNT_ID
			   ,BASE_DATE	AS STRT_DATE 
			   ,coalesce(-1+LEAD(BASE_DATE) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID ORDER BY  BASE_DATE ), P_TO_DATE)	AS END_DATE  
			   ,UTPIC
		  FROM TB_DP_UNIT_PRICE UP
			   INNER JOIN
			   TABLE(FN_DP_TEMP_VER_INFO_DTL (P_VER_ID)) VD
			ON UP.PRICE_TP_ID = VD.PRICE_TP_ID 
		   AND UP.BASE_DATE <= P_TO_DATE  
	), ENTRY_HIS
	AS (   SELECT  SUM(QTY)			AS QTY
				 , SUM(AMT)			AS AMT
				 , ITEM_MST_ID
				 , ACCOUNT_ID
			  FROM TB_DP_ENTRY_HISTORY 
			 WHERE BASE_dATE BETWEEN P_SM_DATE AND (P_FROM_DATE-1)
		GROUP BY ITEM_MST_ID, ACCOUNT_ID
	)

		 SELECT TO_SINGLE_BYTE(SYS_GUID())					AS ID
			  , P_VER_ID										AS VER_ID 
			  , MN.ROLE_ID 
              , MN.EMP_ID
			  , MN.ITEM_ID	
			  , MN.ACCT_ID	
			  , MN.BASE_DATE 
			  , coalesce(RT.QTY , 0)						AS QTY 
			  , coalesce(RT.QTY , 0)						AS QTY 
			  , NULL 										AS AMT
			  , 'system'
			  , SYSDATE
			  , P_PLAN_TP_ID 
			  , RT.QTY_1-- coalesce(RT.QTY_1,0)
			  , NULL  
			  , RT.QTY_2 -- coalesce(RT.QTY_2,0)
			  , NULL 
			  , RT.QTY_3-- coalesce(RT.QTY_3,0)
			  , NULL 
			  , EH.QTY
			  , EH.AMT               
		   FROM TEMP_DP_ITEM_ACCT_ROLE_DATE MN
--				INNER JOIN
--				UNIT_PRICE UP
--			 ON IA.ITEM_ID = UP.ITEM_MST_ID 
--			AND IA.ACCT_ID = UP.ACCOUNT_ID
--			AND CAL.STRT_DT BETWEEN UP.STRT_DATE AND UP.END_DATE
			    LEFT OUTER JOIN 
				TEMP_DP_RT		RT 
		     ON MN.ITEM_ID = RT.ITEM_MST_ID 
			AND MN.ACCT_ID = RT.ACCOUNT_ID 
			AND RT.BASE_DATE = MN.BASE_DATE  
			AND RT.AUTH_TP_ID = MN.ROLE_ID  
				LEFT OUTER JOIN
				ENTRY_HIS EH 
			ON  MN.ITEM_ID = EH.ITEM_MST_ID
		   AND  MN.ACCT_ID = EH.ACCOUNT_ID
           ;				
    
    DELETE FROM TEMP_DP_ITEM_ACCT_ROLE_DATE;



END
;
/

