create PROCEDURE                SP_UI_BF_16_S1
(
		 p_BF_VER				VARCHAR2
		,p_ENGINE_TP_CD		    VARCHAR2
		,p_DESCRIP				VARCHAR2
		,p_SEQ					INT
		,p_INPUT_HORIZ			VARCHAR2
		,p_INPUT_BUKT_CD		VARCHAR2
		,p_TARGET_HORIZ		    VARCHAR2
		,p_TARGET_BUKT_CD		VARCHAR2
		,p_SALES_LV_CD			VARCHAR2
		,p_ITEM_LV_CD			VARCHAR2
		,p_RULE_01		        VARCHAR2
		,p_INPUT_FROM_DATE		DATE
		,p_INPUT_TO_DATE		DATE
		,p_TARGET_FROM_DATE	    DATE
		,p_TARGET_TO_DATE		DATE
		,p_VAL_TP               VARCHAR2
		,p_ATTR_01				VARCHAR2
		,p_ATTR_02				VARCHAR2
		,p_ATTR_03				VARCHAR2
		,p_ATTR_04				VARCHAR2
		,p_ATTR_05				VARCHAR2
		,p_ATTR_06				VARCHAR2
		,p_ATTR_07				VARCHAR2
		,p_ATTR_08				VARCHAR2
		,p_ATTR_09				VARCHAR2
		,p_ATTR_10				VARCHAR2
		,p_USER_ID				VARCHAR2
		,p_RT_ROLLBACK_FLAG		OUT VARCHAR2
		,p_RT_MSG				OUT VARCHAR2
)
IS

p_ERR_STATUS    INT :=0;
p_ERR_MSG       VARCHAR2(4000):='';
p_READY_CD      VARCHAR2(30) :='Ready';
p_COMP_CD       VARCHAR2(30) :='Completed';
p_EXTIST_NUM    VARCHAR(2) :='';

BEGIN
    SELECT CASE WHEN NOT EXISTS ( SELECT LV_CD
                                FROM TB_CM_LEVEL_MGMT
                               WHERE 1=1
                                 AND ACTV_YN = 'Y'
                                 AND COALESCE(DEL_YN,'N') = 'N'
                                 AND ACCOUNT_LV_YN = 'Y'
                                 AND LV_CD = p_SALES_LV_CD ) THEN '1' ELSE '0' END
           INTO
           p_EXTIST_NUM
      FROM DUAL;

    IF (p_EXTIST_NUM = '1')
    THEN
        p_ERR_MSG := 'Sales Level Code is not valid';
        RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG);
    END IF;

    SELECT CASE WHEN NOT EXISTS ( SELECT LV_CD
                                    FROM TB_CM_LEVEL_MGMT
                                   WHERE ACTV_YN = 'Y'
                                     AND COALESCE(DEL_YN,'N') = 'N'
                                     AND ACCOUNT_LV_YN = 'N'
                                     AND SALES_LV_YN = 'N'
                                     AND LV_CD = p_ITEM_LV_CD ) THEN '1' ELSE '0' END
           INTO
           p_EXTIST_NUM
      FROM DUAL;

    IF (p_EXTIST_NUM='1')
    THEN
        p_ERR_MSG := 'Item Level Code is not valid';
        RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG);
    END IF;

    IF (p_seq           IS NULL) THEN	p_ERR_MSG := 'Sequence is empty';           RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG); END IF;
    IF(p_INPUT_HORIZ	IS NULL) THEN	p_ERR_MSG := 'Input Horizon is empty';	    RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG); END IF;
    IF(p_INPUT_BUKT_CD	IS NULL) THEN	p_ERR_MSG := 'Input Bucket is empty';	    RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG); END IF;
    IF(p_TARGET_HORIZ	IS NULL) THEN	p_ERR_MSG := 'Target Horizon is empty';	    RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG); END IF;
    IF(p_TARGET_BUKT_CD	IS NULL) THEN   p_ERR_MSG := 'Target Bucket is empty';	    RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG); END IF;
--    IF(p_RULE_01	    IS NULL) THEN   p_ERR_MSG := 'Disaggregate Rule is empty';  RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG); END IF;

/****************************************************************************************
	-- 1. Version Create & Close status 생성
*****************************************************************************************/
    SELECT CASE WHEN NOT EXISTS ( SELECT *
                                    FROM TB_BF_CONTROL_BOARD_VER_DTL
                                   WHERE VER_CD = p_BF_VER ) THEN '1' ELSE '0' END
           INTO
           p_EXTIST_NUM
      FROM DUAL;

	IF (p_EXTIST_NUM='1')
	THEN
        INSERT INTO TB_BF_CONTROL_BOARD_VER_DTL ( 
              ID
             ,VER_CD
             ,PROCESS_NO
             ,ENGINE_TP_CD
             ,STATUS
             ,RUN_STRT_DATE
             ,RUN_END_DATE
             ,DESCRIP
             ,RULE_01
             ,TARGET_BUKT_CD
             ,CREATE_BY
             ,CREATE_DTTM
        )
		WITH M
		AS (
			SELECT 'Version Create' AS "PROCESS"
				,   p_COMP_CD		AS "STAT"
				,   1				AS PROCESS_NO
				,   SYSDATE 		AS RUN_DT
				,   NULL			AS RULE_01
				,   NULL			AS TARGET_BUKT_CD
              FROM  DUAL
			UNION
			SELECT 'Close'			AS "PROCESS"
				,   p_READY_CD		AS "STAT"
				,   1000000		    AS PROCESS_NO
				,   NULL			AS RUN_DT
				,   NULL			AS RULE_01
			    , (SELECT POLICY_VAL
				     FROM TB_DP_PLAN_POLICY 
				    WHERE PLAN_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND DEFAT_VAL = 'Y' AND ACTV_YN = 'Y')		
				      AND POLICY_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_POLICY' AND CONF_CD = 'B' AND ACTV_YN = 'Y')		
                ) AS TARGET_BUKT_CD
               FROM DUAL
		    UNION
			SELECT 'Select Best Value'  AS "PROCESS"
				,  	p_READY_CD		    AS "STAT"
				,   990000				    AS PROCESS_NO
				,   NULL			    AS RUN_DT 
				,   (SELECT CONF_CD 
					   FROM TB_CM_COMM_CONFIG
					  WHERE CONF_GRP_CD = 'BF_SELECT_CRITERIA' 
					    AND DEFAT_VAL='Y'
                )   AS RULE_01
				,   NULL                AS TARGET_BUKT_CD
               FROM DUAL
		  ) 
            SELECT TO_SINGLE_BYTE(SYS_GUID())   AS ID
                ,  p_BF_VER			            AS VER_CD
                ,  M.PROCESS_NO			        AS PROCESS_NO
                ,  NULL					        AS ENGINE_TP_CD
                ,  M.STAT				        AS STATUS
                ,  M.RUN_DT				        AS RUN_STRT_DATE
                ,  M.RUN_DT				        AS RUN_END_DATE
                ,  M.PROCESS			        AS DESCRIP
                ,  M.RULE_01	                AS RULE_01
                ,  M.TARGET_BUKT_CD		        AS TARGET_BUKT_CD
                ,  p_USER_ID			        AS CREATE_BY
                ,  SYSDATE  			        AS CREATE_DTTM
              FROM M 
		;
	END IF;
/****************************************************************************************
	-- 2. Model별 process 생성 (grid changes 파라미터에 의해 Engine Type별로 프로시저 실행)
*****************************************************************************************/
    INSERT INTO TB_BF_CONTROL_BOARD_VER_DTL
	 (    ID
		, VER_CD
		, PROCESS_NO				
		, ENGINE_TP_CD
		, STATUS
		, RUN_STRT_DATE
		, RUN_END_DATE
		, DESCRIP
		, RULE_01		
		, INPUT_HORIZ			
		, INPUT_BUKT_CD		
		, TARGET_HORIZ		
		, TARGET_BUKT_CD		
		, INPUT_FROM_DATE		
		, INPUT_TO_DATE		
		, TARGET_FROM_DATE	
		, TARGET_TO_DATE
		, SALES_LV_CD			
		, ITEM_LV_CD
		, VAL_TP 
		, ATTR_01				
		, ATTR_02				
		, ATTR_03				
		, ATTR_04				
		, ATTR_05				
		, ATTR_06				
		, ATTR_07				
		, ATTR_08				
		, ATTR_09				
		, ATTR_10				
		, CREATE_BY
		, CREATE_DTTM
		, MODIFY_BY
		, MODIFY_DTTM
		, SHARD_NO
	 )
	WITH MST AS (
        SELECT  p_BF_VER				    AS VER_CD
               ,p_SEQ						AS SEQ
               ,p_ENGINE_TP_CD				AS ENGINE_TP_CD
               ,p_DESCRIP					AS DESCRIP
               ,p_INPUT_HORIZ				AS INPUT_HORIZ			
               ,p_INPUT_BUKT_CD			    AS INPUT_BUKT_CD		
               ,p_TARGET_HORIZ				AS TARGET_HORIZ		
               ,p_TARGET_BUKT_CD			AS TARGET_BUKT_CD		
               ,p_SALES_LV_CD				AS SALES_LV_CD			
               ,p_ITEM_LV_CD				AS ITEM_LV_CD		
               ,NULL						AS RULE_01
               ,p_INPUT_FROM_DATE			AS INPUT_FROM_DATE		
               ,p_INPUT_TO_DATE			    AS INPUT_TO_DATE		
               ,p_TARGET_FROM_DATE			AS TARGET_FROM_DATE	
               ,p_TARGET_TO_DATE			AS TARGET_TO_DATE	
               ,p_VAL_TP                    AS VAL_TP
               ,p_ATTR_01					AS ATTR_01				
               ,p_ATTR_02					AS ATTR_02				
               ,p_ATTR_03					AS ATTR_03				
               ,p_ATTR_04					AS ATTR_04				
               ,p_ATTR_05					AS ATTR_05				
               ,p_ATTR_06					AS ATTR_06				
               ,p_ATTR_07					AS ATTR_07				
               ,p_ATTR_08					AS ATTR_08				
               ,p_ATTR_09					AS ATTR_09				
               ,p_ATTR_10					AS ATTR_10				
               ,p_USER_ID					AS USER_ID				
           FROM DUAL
	 ), 
     PROCESS AS (	
		   SELECT ''				AS TP
		   		, 0					AS SEQ
				, NULL				AS STRT_DATE
				, NULL 		  		AS END_DATE 
             FROM DUAL
	 )
	 SELECT	  TO_SINGLE_BYTE(SYS_GUID())	AS ID
			, M.VER_CD						AS VER_CD
			, M.SEQ*10000+P.SEQ				AS PROCESS_NO				
			, M.ENGINE_TP_CD				AS ENGINE_TP_CD
			, CASE WHEN P.END_DATE	 IS NULL THEN p_READY_CD ELSE p_COMP_CD END AS STATUS
			, P.STRT_DATE						AS RUN_STRT_DATE
			, P.END_DATE						AS RUN_END_DATE
			, M.DESCRIP || P.TP				AS DESCRIP
			, M.RULE_01				AS RULE_01		
			, M.INPUT_HORIZ					AS INPUT_HORIZ			
			, M.INPUT_BUKT_CD				AS INPUT_BUKT_CD		
			, M.TARGET_HORIZ				AS TARGET_HORIZ		
			, M.TARGET_BUKT_CD				AS TARGET_BUKT_CD		
			, M.INPUT_FROM_DATE				AS INPUT_FROM_DATE		
			, M.INPUT_TO_DATE				AS INPUT_TO_DATE		
			, M.TARGET_FROM_DATE			AS TARGET_FROM_DATE	
			, M.TARGET_TO_DATE				AS TARGET_TO_DATE		
			, M.SALES_LV_CD					AS SALES_LV_CD			
			, M.ITEM_LV_CD					AS ITEM_LV_CD	
			, M.VAL_TP                      AS VAL_TP
			, M.ATTR_01						AS ATTR_01				
			, M.ATTR_02						AS ATTR_02				
			, M.ATTR_03						AS ATTR_03				
			, M.ATTR_04						AS ATTR_04				
			, M.ATTR_05						AS ATTR_05				
			, M.ATTR_06						AS ATTR_06				
			, M.ATTR_07						AS ATTR_07				
			, M.ATTR_08						AS ATTR_08				
			, M.ATTR_09						AS ATTR_09				
			, M.ATTR_10						AS ATTR_10				
			, M.USER_ID						AS CREATE_BY
			, SYSDATE						AS CREATE_DTTM
			, NULL							AS MODIFY_BY
			, NULL							AS MODIFY_DTTM
			, 0								AS SHARD_NO 
	   FROM MST M
		    CROSS JOIN
			PROCESS P
		;
/****************************************************************************************
	-- Master 데이터 변경
*****************************************************************************************/
    UPDATE TB_BF_CONTROL_BOARD_MST 
	   SET INPUT_HORIZ		= p_INPUT_HORIZ
	     , INPUT_BUKT_CD	= p_INPUT_BUKT_CD
		 , TARGET_HORIZ		= p_TARGET_HORIZ
		 , TARGET_BUKT_CD	= p_TARGET_BUKT_CD
		 , SALES_LV_CD		= p_SALES_LV_CD
		 , ITEM_LV_CD		= p_ITEM_LV_CD
		 , BF_DIST_RULE_CD  = p_RULE_01
		 , VAL_TP           = p_VAL_TP
		 , ATTR_01			= p_ATTR_01
		 , ATTR_02			= p_ATTR_02
		 , ATTR_03			= p_ATTR_03
		 , ATTR_04			= p_ATTR_04
		 , ATTR_05			= p_ATTR_05
		 , ATTR_06			= p_ATTR_06
		 , ATTR_07			= p_ATTR_07
		 , ATTR_08			= p_ATTR_08
		 , ATTR_09			= p_ATTR_09
		 , ATTR_10			= p_ATTR_10
	WHERE ENGINE_TP_CD = p_ENGINE_TP_CD
    ;
END;
/

