create PROCEDURE SP_UI_DP_23_VER_POP_Q3
(
     p_CHANGE_COM		VARCHAR2
    ,p_VER_FROM_DATE	DATE
    ,p_VER_TO_DATE		DATE
    ,p_DATE			    DATE
    ,p_PLAN_TP			VARCHAR2
    ,pRESULT            OUT SYS_REFCURSOR
)
IS

/*****************************************************************************
Title : SP_UI_DP_23_VER_POP_Q3
최초 작성자 : 이고은
최초 생성일 : 2017.08.09
?
설명 
 - DP Control Board 최신 버전 팝업(Horizon From/ To Date , DTF Date Change)
 ?
History (수정일자 / 수정자 / 수정내용)
-  2017.08.09 / 이고은 / 최초 작성
-  2019.06.26 / 김소희 / TO DATE Month 일 때, 계산 오류 수정 및 코드 정리?
-  2019.12.27 / 김소희 / Partial week에 대한 DTF& 시작일 처리 
-  2020.03.18 / 김소희 / Change Week Rule : DP_WK
-  2020.08.24 / 김소희 / DTF 마지막날짜로 세팅 
-  2020.12.23 / 민경훈 / MSSQL -> ORACLE
-  2021.01.25 / 서은하 / 3단 가변 구간 변경
- 2021.07.29 / kim sohee / add a case : bucket	
- 2022-09-16 / KIM SOHEE / add getiing values
*****************************************************************************/

v_VER_BUCKET		VARCHAR2(50);
v_VER_HORIZON		INT;
v_VER_DTF			INT;
v_VER_STAT_BUCKET   INT;
v_VER_FROM_DATE	    DATE;
v_VER_TO_DATE		DATE;
v_DTF_DATE		    DATE;
/* Partial Parameter Add*/
v_PAR_HORIZON       INT;
v_PAR_BUCKET        VARCHAR2(10);
v_PAR_DATE          DATE;
v_PAR_TO_DATE       DATE;
v_PAR_HORIZON2      INT;
v_PAR_BUCKET2       VARCHAR2(10);
v_PAR_DATE2         DATE;
v_PAR_TO_DATE2      DATE;
v_DATE              DATE := NULL;
v_TMP_ENDDATE       DATE := NULL ;

BEGIN

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	1. Setting Master Data
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	v_DATE := p_DATE;

	SELECT  "'B'"
           ,"'H'"
           ,"'DTF'"
           ,CASE WHEN p_CHANGE_COM = 'FROM_DT' THEN 0 ELSE TO_NUMBER("'SB'") END
           ,"'PB'"
           ,"'PH'"
           ,"'PB2'"
           ,"'PH2'"
            INTO
             v_VER_BUCKET		
           , v_VER_HORIZON	
           , v_VER_DTF		
           , v_VER_STAT_BUCKET
           , v_PAR_BUCKET		
           , v_PAR_HORIZON	
           , v_PAR_BUCKET2	
           , v_PAR_HORIZON2	
	  FROM (
			SELECT   PL.CONF_CD		AS POLICY_CD
				   , PP.POLICY_VAL	AS POLICY_VAL
			  FROM TB_DP_PLAN_POLICY PP
				   INNER JOIN
				   TB_CM_COMM_CONFIG PL
				ON(PP.POLICY_ID = PL.ID  AND PL.ACTV_YN = 'Y') -- PLAN POLICY VALUES
			WHERE 1=1
			  AND PP.MODULE_ID = 'DP'
			  AND PP.PLAN_TP_ID = p_PLAN_TP
			  AND (PL.CONF_CD = 'B' OR PL.CONF_CD = 'H' OR PL.CONF_CD ='DTF' OR PL.CONF_CD ='SB' OR PL.CONF_CD ='PB' OR PL.CONF_CD ='PH'OR PL.CONF_CD ='PB2' OR PL.CONF_CD ='PH2')			  
	      ) CONF PIVOT (MAX(POLICY_VAL) FOR POLICY_CD IN ('B','H','DTF','SB','PB', 'PH', 'PB2','PH2')) PVT 
		  ;
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	2. Change << From Date >> Datepicker
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	IF (p_CHANGE_COM = 'FROM_DT' OR p_CHANGE_COM = 'OPEN')
	THEN
	/************************************************************************************************************************
		-- Date Setting
	************************************************************************************************************************/
		WITH CAL
		AS (
			SELECT  MIN(DAT)	AS STRT_DATE
				  , MAX(DAT)	AS END_DATE
				  , DENSE_RANK () OVER (ORDER BY MIN(DAT) ASC) AS RW 
			  FROM TB_CM_CALENDAR
		  GROUP BY CASE v_VER_BUCKET
						WHEN 'Y' THEN YYYY
						WHEN 'Q' THEN YYYY||'-'||TO_CHAR(QTR)
						WHEN 'M' THEN YYYYMM
						WHEN 'PW' THEN MM||'-'||DP_WK
						WHEN 'W' THEN DP_WK
					ELSE YYYYMMDD END 
		), 
        RW
		AS (
			 SELECT RW+COALESCE(v_VER_STAT_BUCKET,0)										AS ST
				  , RW+COALESCE(v_VER_HORIZON	,0)+COALESCE(v_VER_STAT_BUCKET,0)-1		AS ED
				  , RW+COALESCE(v_VER_DTF		,0)+COALESCE(v_VER_STAT_BUCKET,0)-1		AS DT
				  , RW+COALESCE(v_PAR_HORIZON	,0)+COALESCE(v_VER_STAT_BUCKET,0)-1		AS PA
			  FROM CAL
			 WHERE v_DATE BETWEEN STRT_DATE AND END_DATE 
		), 
        RWP
		AS (	SELECT BASE, "NUM"
				  FROM RW
				       UNPIVOT ("NUM" FOR BASE IN (ST, ED, DT, PA)) UP
		), 
        M
		AS (
			SELECT  CASE RWP.BASE
					WHEN 'ST' THEN CAL.STRT_DATE
					WHEN 'ED' THEN CAL.END_DATE
					WHEN 'DT' THEN CAL.END_DATE 
					WHEN 'PA' THEN CAL.STRT_DATE
				   END		AS BASE_DATE
				 , RWP.BASE 				
			  FROM CAL
			       INNER JOIN
				   RWP
				ON CAL.RW = RWP."NUM"
		   )
		   SELECT "'ST'"
				, "'ED'"
				, "'DT'"
				, "'PA'"
                  INTO
                  v_VER_FROM_DATE
                , v_VER_TO_DATE
                , v_DTF_DATE
                , v_PAR_DATE
		     FROM M
				   PIVOT 
				   (MAX(BASE_DATE) FOR BASE IN ('ST', 'ED', 'DT', 'PA')) PVT 		
        ;
	/***********************************************************************************************************************
		-- Reflect Partial Date
	************************************************************************************************************************/ 
		IF (LENGTH(RTRIM(v_PAR_BUCKET)) > 0)
        THEN
            SELECT MAX(DAT)+1 INTO v_PAR_DATE
              FROM TB_CM_CALENDAR
             GROUP BY CASE v_PAR_BUCKET
						WHEN 'Y' THEN YYYY
						WHEN 'Q' THEN YYYY||'-'||TO_CHAR(QTR)
						WHEN 'M' THEN YYYYMM
						WHEN 'PW' THEN MM||'-'||DP_WK
						WHEN 'W' THEN DP_WK
					ELSE YYYYMMDD END 
            HAVING v_PAR_DATE BETWEEN MIN(DAT) AND MAX(DAT)
            ;

            IF (LENGTH(RTRIM(v_PAR_BUCKET2)) > 0 ) 
            THEN
                -- PARTIAL 2 START DATE 
                if (v_PAR_BUCKET = 'M')
                THEN
                    -- 최소 버킷 반영
                    SELECT ADD_MONTHS(v_PAR_DATE,v_PAR_HORIZON2) INTO v_PAR_DATE2
                      FROM DUAL
                      ;

                    -- 다음 버킷타입 시작 반영
                    SELECT MAX(DAT)+1 INTO v_PAR_DATE2
                        FROM TB_CM_CALENDAR
                    GROUP BY CASE v_PAR_BUCKET2
										WHEN 'Y' THEN YYYY
										WHEN 'Q' THEN YYYY||'-'||TO_CHAR(QTR)
										WHEN 'M' THEN YYYYMM
										WHEN 'PW' THEN MM||'-'||DP_WK
										WHEN 'W' THEN DP_WK
									ELSE YYYYMMDD END 
                    ;


                ELSIF ( v_PAR_BUCKET = 'Q')
                THEN
                  -- 최소버킷 반영
                    SELECT ADD_MONTHS(v_PAR_DATE,v_PAR_HORIZON2*3) INTO v_PAR_DATE2
                      FROM DUAL
                    ;

                  -- 다음 버킷 타입 시작 반영
                    SELECT MAX(DAT)+1 INTO v_PAR_DATE2
                        FROM TB_CM_CALENDAR
                    GROUP BY CASE v_PAR_BUCKET2
								WHEN 'Y' THEN YYYY
								WHEN 'Q' THEN YYYY||'-'||TO_CHAR(QTR)
								WHEN 'M' THEN YYYYMM
								WHEN 'PW' THEN MM||'-'||DP_WK
								WHEN 'W' THEN DP_WK
							ELSE YYYYMMDD END 
                    HAVING v_PAR_DATE2 BETWEEN MIN(DAT) AND MAX(DAT)
                    ;

                end IF;

                -- PARTIAL 1 END DATE 
                SELECT v_PAR_DATE2-1 INTO v_PAR_TO_DATE
                  FROM DUAL;

                -- PARTIAL 2 END DATE 
                -- to do total horizon 반영한 end date가 v_PAR_DATE2 보다 작다면 한버킷만 반영하기로..
                -- total horizon 반영한 end date 를 포함하는 최종 버킷타입의 마지막 날짜 구하기
                -- 날짜를 구하고 두번째 버킷타입의 마지막 날짜

                --select max(dat) INTO v_TMP_ENDDATE 
                 -- from TB_CM_CALENDAR
                 --where PARTWK_SEQ = (select PARTWK_SEQ from TB_CM_CALENDAR where DAT = v_VER_FROM_DATE) + 40
                --;

                SELECT MAX(DAT) INTO v_PAR_TO_DATE2
                  FROM TB_CM_CALENDAR
                 GROUP BY CASE v_PAR_BUCKET
						WHEN 'Y' THEN YYYY
						WHEN 'Q' THEN YYYY||'-'||TO_CHAR(QTR)
						WHEN 'M' THEN YYYYMM
						WHEN 'PW' THEN MM||'-'||DP_WK
						WHEN 'W' THEN DP_WK
                    ELSE YYYYMMDD END 
                HAVING v_VER_TO_DATE BETWEEN MIN(DAT) AND MAX(DAT)	
                ;	

                -- version end date
                SELECT v_PAR_TO_DATE2 INTO v_VER_TO_DATE
                  FROM DUAL
                  ;
            ELSE
                SELECT MAX(DAT)	INTO v_PAR_TO_DATE
                  FROM TB_CM_CALENDAR
              GROUP BY TO_CHAR(YYYY)
                     , CASE WHEN v_PAR_BUCKET IN ('M', 'PW') THEN TO_CHAR(MM) ELSE '1' END
                     , CASE WHEN v_PAR_BUCKET IN ('W', 'PW') THEN TO_CHAR(DP_WK) ELSE '1' END
                HAVING v_VER_TO_DATE BETWEEN MIN(DAT) AND MAX(DAT)	
                ;	

                -- version end date
                SELECT v_PAR_TO_DATE INTO v_VER_TO_DATE
                  FROM DUAL
                ;
            END IF;
		END IF;

	/************************************************************************************************************************
		-- Result
	*************************************************************************************************************************/ 
        OPEN pRESULT FOR
		SELECT    v_VER_FROM_DATE																	AS VER_FROM_DATE
		        , v_VER_TO_DATE		AS VER_TO_DATE
		        , CASE WHEN LENGTH(RTRIM(v_PAR_BUCKET)) = 0 OR v_PAR_BUCKET IS NULL THEN NULL ELSE v_PAR_DATE			  END		AS PAR_DATE
		        , v_PAR_BUCKET																		AS PAR_BUCKET
		        , v_PAR_HORIZON																	AS PAR_HORIZON 
		        , CASE WHEN v_VER_DTF = 0 THEN v_VER_FROM_DATE ELSE v_DTF_DATE END																		AS DTF_DATE
		        , CASE WHEN LENGTH(RTRIM(v_PAR_BUCKET2)) = 0 OR v_PAR_BUCKET2 IS NULL THEN NULL ELSE v_PAR_DATE2			  END		AS PAR_DATE2
		        , v_PAR_BUCKET2																		AS PAR_BUCKET2
		        , v_PAR_HORIZON2																	AS PAR_HORIZON2 
		        , v_PAR_TO_DATE																	AS PAR_TO_DATE 
		        , v_PAR_TO_DATE2																	AS PAR_TO_DATE2 
				, (select CONF_CD from TB_CM_COMM_CONFIG where CONF_GRP_CD = 'DP_STD_WEEK' )        AS STD_WEEK
                /*******************************************************************  2022-09-16 add  ***********************/
				,v_VER_BUCKET	as VER_BUCKET
				,v_VER_HORIZON	as VER_HORIZON
				,COALESCE(v_VER_DTF,0)		as VER_DTF	
				,v_VER_STAT_BUCKET as VER_STAT_BUCKET

          FROM    DUAL
        ;
	END IF;
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	3. Change << To Date >> Datepicker
	....
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
END ;
/

