create PROCEDURE "SP_UI_CM_13_POP_01_Q" (
    P_CONF_KEY              IN CHAR :='',
    pResult OUT SYS_REFCURSOR
)
IS

BEGIN

	IF P_CONF_KEY ='001' /* WAREHOUSE TYPE */
	THEN
		OPEN pResult FOR
        SELECT A.ID	
			 , A.WAREHOUSE_TP
			 , A.WAREHOUSE_TP_NM
			 , A.LOAD_CAPA_MGMT_BASE
			 , A.ACTV_YN
		  FROM TB_CM_WAREHOUSE_TYPE A;

	ELSIF P_CONF_KEY ='002' /* ?？？？- Pallet Layer / Location Limit */
	THEN
		OPEN pResult FOR 
        SELECT D.COMN_CD_NM AS LOCAT_TP
			 , B.LOCAT_LV
			 , C.LOCAT_CD
			 , C.ID         AS LOC_DTL_ID
			 , MGMT.ID      AS LOC_MGMT_ID
			 , C.LOCAT_NM
		  FROM TB_CM_CONFIGURATION A
	            INNER JOIN TB_CM_LOC_MST B
	              ON A.ID = B.CONF_ID
				INNER JOIN TB_CM_LOC_DTL C 
	              ON B.ID = C.LOCAT_MST_ID 
				INNER JOIN TB_CM_LOC_MGMT MGMT 
	              ON C.ID = MGMT.LOCAT_ID
				INNER JOIN TB_AD_COMN_CODE D
	              ON B.LOCAT_TP_ID = D.ID
         ORDER BY D.COMN_CD_NM, B.LOCAT_LV, C.LOCAT_CD;

	END IF;

END;

/

