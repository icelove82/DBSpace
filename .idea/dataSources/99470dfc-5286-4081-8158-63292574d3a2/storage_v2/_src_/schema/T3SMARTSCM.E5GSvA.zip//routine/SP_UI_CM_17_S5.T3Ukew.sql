create PROCEDURE "SP_UI_CM_17_S5" (
    P_SIMUL_VER_ID 	IN CHAR := '',
    P_USER_ID 		IN VARCHAR2 := '',
    pResult 		OUT SYS_REFCURSOR
)
IS
	P_MAX_SIMUL_SEQ NUMBER :=1;
    P_MAIN_VER_ID  VARCHAR2(30) :='';
    P_CONBD_MAIN_VER_MST_ID  CHAR(32):='';
    P_CONBD_MAIN_VER_DTL_ID  CHAR(32):='';
    P_NEW_CONBD_MAIN_VER_DTL_ID CHAR(32) :='';
    P_SNRIO_VER_ID VARCHAR2(30) :='';
    P_SNRIO_VER_DESCRIP VARCHAR2(4000) :='';

BEGIN
    SELECT B.CONBD_MAIN_VER_MST_ID, E.SNRIO_VER_ID, E.DESCRIP, B.ID
      INTO P_CONBD_MAIN_VER_MST_ID, P_SNRIO_VER_ID, P_SNRIO_VER_DESCRIP, P_CONBD_MAIN_VER_DTL_ID
      FROM TB_CM_CONBD_MAIN_VER_MST A,
           TB_CM_CONBD_MAIN_VER_DTL B
           INNER JOIN
           TB_CM_PLAN_SNRIO_MGMT_DTL C
           ON B.PLAN_SNRIO_MGMT_DTL_ID = C.ID
           INNER JOIN
           TB_CM_PLAN_SNRIO_MGMT_MST E
           ON  C.PLAN_SNRIO_MGMT_MST_ID = E.ID
     WHERE 1=1
       AND A.ID = B.CONBD_MAIN_VER_MST_ID
       AND B.SIMUL_VER_ID = P_SIMUL_VER_ID;

    BEGIN
        SELECT CASE WHEN MODIFY_DTTM IS NULL THEN A.ID END INTO P_NEW_CONBD_MAIN_VER_DTL_ID
          FROM TB_CM_CONBD_MAIN_VER_DTL A
         WHERE A.SIMUL_VER_ID = (SELECT MAX(SIMUL_VER_ID) FROM TB_CM_CONBD_MAIN_VER_DTL WHERE CONBD_MAIN_VER_MST_ID = P_CONBD_MAIN_VER_MST_ID);
        EXCEPTION
            WHEN NO_DATA_FOUND THEN P_NEW_CONBD_MAIN_VER_DTL_ID := NULL;
    END;

    IF P_NEW_CONBD_MAIN_VER_DTL_ID IS NULL THEN
        P_NEW_CONBD_MAIN_VER_DTL_ID := TO_SINGLE_BYTE(SYS_GUID());

        SELECT NVL(MAX(TO_NUMBER(LTRIM(REPLACE(REPLACE(B.SIMUL_VER_ID,A.MAIN_VER_ID,''),'-','')))) ,0) + 1  , A.MAIN_VER_ID
          INTO P_MAX_SIMUL_SEQ, P_MAIN_VER_ID
          FROM TB_CM_CONBD_MAIN_VER_MST A
               INNER JOIN
               TB_CM_CONBD_MAIN_VER_DTL B
               ON A.ID = B.CONBD_MAIN_VER_MST_ID
         WHERE 1=1
           AND A.ID = P_CONBD_MAIN_VER_MST_ID
         GROUP BY A.MAIN_VER_ID;

        INSERT INTO TB_CM_CONBD_MAIN_VER_DTL
            (
            ID
            ,CONBD_MAIN_VER_MST_ID
            ,PLAN_SNRIO_MGMT_DTL_ID
            ,EXE_STATUS_ID
            ,STEP_STATUS_ID
            ,SIMUL_VER_ID
            ,CONFRM_YN
            ,REFER_CONBD_MAIN_VER_DTL_ID
            ,CREATE_BY
            ,CREATE_DTTM
            )
            SELECT  P_NEW_CONBD_MAIN_VER_DTL_ID
                   ,P_CONBD_MAIN_VER_MST_ID AS CONBD_MAIN_VER_MST_ID
                   ,NULL AS PLAN_SNRIO_MGMT_DTL_ID
                   ,B.ID AS EXE_STATUS_ID
                   ,A.ID AS STEP_STATUS_ID
                   ,CONCAT(CONCAT(P_MAIN_VER_ID, '-'), RTRIM(LPAD(TO_CHAR(P_MAX_SIMUL_SEQ),'3','0'))) AS SIMUL_VER_ID
                   ,'N' AS CONFRM_YN
                   ,P_CONBD_MAIN_VER_DTL_ID
                   ,P_USER_ID
                   ,SYSDATE
               FROM (
                     SELECT A.ID
                       FROM  TB_AD_COMN_CODE A
                                    INNER JOIN
                                    TB_AD_COMN_GRP B
                                    ON A.SRC_ID = B.ID
                                    AND B.GRP_CD='STEP_STATUS'
                      WHERE 1=1
                        AND A.COMN_CD='READY'
                    )A,
                    (
                     SELECT A.ID
                       FROM  TB_AD_COMN_CODE A
                                    INNER JOIN
                                    TB_AD_COMN_GRP B
                                    ON A.SRC_ID = B.ID
                                    AND B.GRP_CD='EXE_STATUS'
                      WHERE 1=1
                        AND A.COMN_CD ='EXE_02'
                    ) B;
    END IF;

    OPEN pResult FOR
    SELECT  E.COMN_CD AS MODULE_CD
           ,A.MAIN_VER_ID
           ,A.DESCRIP AS MAIN_VER_DESCRIP
           ,P_SNRIO_VER_ID AS SNRIO_VER_ID
           ,P_SNRIO_VER_DESCRIP  AS SNRIO_VER_DESCRIP
           ,NULL AS STEP
           ,NULL AS PROCESS_DESCRIP
           ,(
             SELECT Y.COMN_CD_NM
               FROM  TB_AD_COMN_GRP X
                            INNER JOIN
                            TB_AD_COMN_CODE Y
                            ON X.ID = Y.SRC_ID
                            AND Y.COMN_CD='SPROC_05'
              WHERE 1=1
                AND X.GRP_CD='SCENARIO_PROCESS_TP'
            ) AS PROCESS_TP
		   ,F.ID					AS REFER_CONBD_MAIN_VER_DTL_ID
		   ,F.SIMUL_VER_ID			AS ORIGINAL_VER_ID
		   ,F.SIMUL_VER_DESCRIP		AS ORIGINAL_DESCRIP
		   ,B.SIMUL_VER_ID			AS MAX_SIMUL_VER_ID
		   ,B.SIMUL_VER_DESCRIP
		   ,B.PLAN_SNRIO_MGMT_DTL_ID
		   ,B.ID					AS NEW_CONBD_MAIN_VER_DTL_ID
		   ,NVL(B.REVISION_ID, F.REVISION_ID) AS REVISION_ID
		   ,NVL(G.REVISION_VER_ID, H.REVISION_VER_ID) AS REVISION_VER_ID
		   ,NVL(G.REVISION_VER_DESC, H.REVISION_VER_DESC) AS REVISION_VER_DESC
      FROM TB_CM_CONBD_MAIN_VER_MST A
           INNER JOIN
           TB_CM_CONBD_MAIN_VER_DTL B
        ON (A.ID = B.CONBD_MAIN_VER_MST_ID)
           INNER JOIN
           TB_AD_COMN_CODE E
        ON (A.MODULE_ID = E.ID)
			CROSS JOIN
			TB_CM_CONBD_MAIN_VER_DTL F
			LEFT OUTER JOIN TB_MP_MASTER_VER G
		ON G.ID = B.REVISION_ID
			LEFT OUTER JOIN TB_MP_MASTER_VER H
		ON H.ID = F.REVISION_ID
	WHERE	1=1
	AND		B.ID = P_NEW_CONBD_MAIN_VER_DTL_ID
	AND		F.ID = P_CONBD_MAIN_VER_DTL_ID;

END;
/

