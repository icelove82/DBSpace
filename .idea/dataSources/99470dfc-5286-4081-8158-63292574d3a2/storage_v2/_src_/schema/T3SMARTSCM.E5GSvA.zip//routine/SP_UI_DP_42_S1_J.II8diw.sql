create PROCEDURE SP_UI_DP_42_S1_J(
                                       P_JSON			    CLOB
                                     , P_USER_ID            VARCHAR2
                                     , P_RT_ROLLBACK_FLAG   OUT VARCHAR2
                                     , P_RT_MSG             OUT VARCHAR2						        
)IS
    p_ERR_MSG  VARCHAR2(4000):='';
/****************************************************************************************************************
Title : [SP_UI_CM_20_S1_J]
  - Actual Sales Save (Json Param Bulk Insert)


설명 
  - OPENJSON : https://docs.microsoft.com/ko-kr/sql/t-sql/functions/openjson-transact-sql?view=sql-server-ver15

History (수정일자 / 수정자 / 수정내용)
- 2022.01.11 / kim sohee / json bulk insert draft
*****************************************************************************************************************/
BEGIN 
/*
	-- Find ID
	SELECT ID INTO p_ITEM_MST_ID FROM TB_CM_ITEM_MST WHERE ITEM_CD = p_ITEM_CD;
	SELECT ID INTO p_ACCOUNT_ID FROM TB_DP_ACCOUNT_MST WHERE ACCOUNT_CD = p_ACCT_CD;

	-- VALIDATION ABOUT ID 
	IF(p_ITEM_MST_ID IS NULL)
	THEN
		p_ERR_MSG := 'Item Code is not valid';
		RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG);
	END IF;

	IF(p_ACCOUNT_ID IS NULL)
	THEN
		p_ERR_MSG := 'Account Code is not valid';
		RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG);
	END IF;
*/
    INSERT INTO TEMP_CM_ACTUAL_SALES
    SELECT ITEM_CD
         , ACCOUNT_CD
         , BASE_DATE 
         , QTY 
         , AMT
         , SO_STATUS_CD 
      FROM JSON_TABLE ( P_JSON,  '$[*]'  
                COLUMNS (    ITEM_CD		PATH	'$.ITEM_CD'
                           , ACCOUNT_CD		PATH	'$.ACCOUNT_CD'
                           , BASE_DATE		DATE PATH	'$.BASE_DATE'
                           , QTY		    PATH	'$.QTY'
                           , AMT		    PATH	'$.AMT'
                           , SO_STATUS_CD	PATH	'$.SO_STATUS_CD'
                        )                                      
            ) 
            ;

	MERGE INTO TB_CM_ACTUAL_SALES TGT
		 USING ( SELECT  I.ID		AS ITEM_MST_ID
                        ,A.ID		AS ACCOUNT_ID
                        ,BASE_DATE	AS BASE_DATE
                        ,QTY		AS QTY
                        ,AMT		AS AMT
                        ,C.ID		AS SO_STATUS_ID
                 FROM TEMP_CM_ACTUAL_SALES M
                      INNER JOIN 
				  	  TB_CM_ITEM_MST I
				   ON M.ITEM_CD = I.ITEM_CD 
					  INNER JOIN
					  TB_DP_ACCOUNT_MST A 
				   ON M.ACCOUNT_CD = A.ACCOUNT_CD 
					  INNER JOIN 
					  TB_CM_COMM_CONFIG C
				   ON M.SO_STATUS_CD = C.CONF_CD
				  AND C.CONF_GRP_CD = 'DP_SO_STATUS'                                                            
		 	   ) SRC
			ON (SRC.ITEM_MST_ID = TGT.ITEM_MST_ID
		   AND SRC.ACCOUNT_ID = TGT.ACCOUNT_ID
		   AND SRC.BASE_DATE = TGT.BASE_DATE
		   AND SRC.SO_STATUS_ID = TGT.SO_STATUS_ID)
	WHEN MATCHED THEN 
		 UPDATE SET QTY		    = SRC.QTY
			       ,AMT		    = SRC.AMT
				   ,MODIFY_BY   = P_USER_ID 
				   ,MODIFY_DTTM = SYSDATE
	WHEN NOT MATCHED THEN
		   INSERT  ( ID
				    ,ITEM_MST_ID
				    ,ACCOUNT_ID
				    ,BASE_DATE
				    ,SO_STATUS_ID
				    ,QTY
				    ,AMT
				    ,CREATE_BY
				    ,CREATE_DTTM
				   ) VALUES
				  ( TO_SINGLE_BYTE(SYS_GUID())
				   ,SRC.ITEM_MST_ID
				   ,SRC.ACCOUNT_ID
				   ,SRC.BASE_DATE
				   ,SRC.SO_STATUS_ID
				   ,SRC.QTY
				   ,SRC.AMT
				   ,P_USER_ID
				   ,SYSDATE 
				  );

    p_RT_MSG := 'MSG_0001';
    p_RT_ROLLBACK_FLAG := 'true';

    DELETE FROM TEMP_CM_ACTUAL_SALES
    ;
    EXCEPTION WHEN OTHERS THEN
    IF(SQLCODE = -20001)
    THEN
        P_RT_MSG := SQLERRM;   
        p_RT_ROLLBACK_FLAG :='false';
    ELSE
        RAISE;
    END IF; 
--END TRY
--BEGIN CATCH
--	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
--		   BEGIN
--			   SET p_ERR_MSG = ERROR_MESSAGE()
--			   SET p_RT_ROLLBACK_FLAG = 'false'
--			   SET p_RT_MSG = p_ERR_MSG
--			END
--	   ELSE 
--				THROW;
----				EXEC SP_COMM_RAISE_ERR
END;
/

