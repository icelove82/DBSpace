create PROCEDURE        "SP_UI_CM_01_POP_28_S" (
	 P_ID                   IN VARCHAR2 := ''
    ,P_LOCAT_MST_ID         IN VARCHAR2 := ''
    ,P_CATAGY_GRP       	IN VARCHAR2 := ''
    ,P_UOM_ID	            IN VARCHAR2 := ''
    ,P_GRP_NO	            IN VARCHAR2 := ''
    ,P_LOTSIZE_CD	        IN VARCHAR2 := ''
    ,P_FROM_QTY	            IN NUMBER := ''
    ,P_TO_QTY	            IN NUMBER := ''
    ,P_EFFICY	            IN NUMBER := ''
    ,P_ACTV_YN	            IN VARCHAR2 := ''
    ,P_USER_ID	            IN VARCHAR2 := ''
    ,P_WRK_TYPE	            IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG     OUT VARCHAR2 
    ,P_RT_MSG               OUT VARCHAR2
)
IS

    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';

BEGIN
IF P_WRK_TYPE = 'SAVE'
THEN

        P_ERR_MSG := 'MSG_0006'; --'？?? ?？？???？?？μ？? ?？？??？？'
            IF NVL(P_LOCAT_MST_ID,'') ='' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;

        P_ERR_MSG := 'MSG_0008'; -- '?????？?？？？ ?? ?????？？ '
            IF P_FROM_QTY < 0  THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;

        P_ERR_MSG := 'MSG_0012'; -- '?？?? ?????? ?？？???？?？μ？????？？'
            IF (P_EFFICY < 0 OR P_EFFICY > 100) THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;

    MERGE INTO TB_CM_LOT_SIZE_GROUP B 
			USING (SELECT P_ID AS ID FROM DUAL) A
					ON     (B.ID = P_ID)

			WHEN MATCHED THEN

				UPDATE 
				   SET B.ACTV_YN		= P_ACTV_YN
					 , B.CATAGY_GRP		= P_CATAGY_GRP
					 , B.LOCAT_MST_ID   = P_LOCAT_MST_ID
					 , B.UOM_ID			= P_UOM_ID
					 , B.GRP_NO			= P_GRP_NO
					 , B.LOTSIZE_CD		= P_LOTSIZE_CD
					 , B.FROM_QTY		= P_FROM_QTY
					 , B.TO_QTY			= P_TO_QTY
					 , B.EFFICY			= P_EFFICY
					 , MODIFY_BY			= P_USER_ID
					 , MODIFY_DTTM			= SYSDATE()
			WHEN NOT MATCHED THEN
				INSERT
					(
					ID, LOCAT_MST_ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM,
					CATAGY_GRP,
					GRP_NO,
					UOM_ID,
					LOTSIZE_CD,
					FROM_QTY,
					TO_QTY,
					EFFICY,
					ACTV_YN
					)
				VALUES
					(
					TO_SINGLE_BYTE(SYS_GUID()),P_LOCAT_MST_ID, P_USER_ID, SYSDATE(), P_USER_ID, SYSDATE(),
					P_CATAGY_GRP,
					P_GRP_NO,
					P_UOM_ID,
					P_LOTSIZE_CD,
					P_FROM_QTY,
					P_TO_QTY,
					P_EFFICY,
					P_ACTV_YN
					);

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';  --???？？????？？
        
ELSIF P_WRK_TYPE = 'DELETE'
THEN

    DELETE FROM TB_CM_LOT_SIZE_GROUP
		WHERE ID = P_ID;

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0002';

END IF;

        EXCEPTION
        WHEN OTHERS THEN
            P_RT_ROLLBACK_FLAG := 'false';
            IF(SQLCODE = -20012)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF; 

END;

/

