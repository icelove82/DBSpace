create procedure "SP_UI_DP_40_Q0"(  
               P_PLAN_TP_ID    IN     CHAR
              ,P_BUKT_CD       IN     VARCHAR2 
              ,pRESULT         OUT SYS_REFCURSOR 
)IS
/***************************************************
    -- History ( date / writer / comment)
    -- 2021.07.01 / ksh / add auth type id
****************************************************/
v_PLAN_TP_ID			VARCHAR2(50);

BEGIN
    v_PLAN_TP_ID	:= p_PLAN_TP_ID;

    IF (v_PLAN_TP_ID IS NULL)
    THEN
    SELECT ID INTO v_PLAN_TP_ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND CONF_CD = 'DP_PLAN_MONTHLY';
    END IF;

    OPEN pRESULT
    FOR
SELECT A.*
FROM (
    SELECT 
           VR.ID AS CD
         , VER_ID AS CD_NM
         , RANK() OVER (ORDER BY VER_ID DESC) AS ROWN
         , CASE P_BUKT_CD WHEN 'M' THEN ADD_MONTHS((LAST_DAY (TRUNC (VR.FROM_DATE))+1),-1) ELSE FROM_DATE END AS FROM_DATE
         , CASE P_BUKT_CD WHEN 'M' THEN LAST_DAY (TRUNC (VR.TO_DATE)) ELSE VR.TO_DATE END AS TO_DATE
         , DT.CL_LV_MGMT_ID AS AUTH_TP_ID
      FROM TB_DP_CONTROL_BOARD_VER_MST VR
           INNER JOIN
           TB_DP_CONTROL_BOARD_VER_DTL DT   
        ON VR.ID = DT.CONBD_VER_MST_ID
    WHERE 1=1
      AND VR.PLAN_TP_ID = v_PLAN_TP_ID
      AND DT.CL_STATUS_ID = ( SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE' )
) A
WHERE ROWN <=10
ORDER BY A.CD_NM DESC    
    ;


END
;
/

