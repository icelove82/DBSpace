create PROCEDURE "SP_UI_CM_15_Q6" (
    P_PLAN_POLICY_ID   IN VARCHAR2 := '',
    PRESULT            OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN PRESULT FOR 
        SELECT
            B.ID,
            C.PLAN_POLICY_NM,
            C.DESCRIP,
            B.ACTV_YN,
            NVL(C.DETAIL, ' ') AS SELECT_SEQ
         FROM
            TB_CM_PLAN_POLICY_MGMT A
            INNER JOIN TB_CM_MULTI_LV_ALLOC_RULE B ON A.ID = B.PLAN_POLICY_MGMT_ID
            INNER JOIN TB_CM_PLAN_POLICY_DTL C ON B.PLAN_POLICY_DTL_ID = C.ID
         WHERE
            1 = 1
            AND A.ID = P_PLAN_POLICY_ID
         ORDER BY C.SEQ;

END;

/

