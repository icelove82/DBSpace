create PROCEDURE                "SP_UI_DP_15_Q2" (      
                                             p_ITEM_LV          IN VARCHAR2 := ''
                                            ,p_ITEM_CD          IN VARCHAR2 := ''
                                            ,p_ITEM_NM          IN VARCHAR2 := ''
                                            ,P_RT_MSG           OUT VARCHAR2 
                                            ,pRESULT            OUT SYS_REFCURSOR 
                                            ) IS                                       
/* LEVEL MANAGEMENT NAME  */
        p_SEQ INT := NULL;
        p_COLUMN_CNT INT := 0;
        p_SQL VARCHAR2(3000) := 'SELECT ';
        p_WHILE_CNT INT := 1 ; 
        p_COLUMN_NM VARCHAR2(50) := NULL;
        p_COUNT    INT := 3;-- COLUMN  COUNT 
        p_COLUMN_NM_CNT INT := NULL;
        p_WHILE_CNT_02 INT := 1;
BEGIN 
/*LV_CD SEQ  ******************************************************************************************************************************************/
    SELECT MAX(ROWNUM) INTO p_SEQ
     FROM TB_CM_LEVEL_MGMT
    WHERE 1=1
     AND SALES_LV_YN = 'N'
     AND ACCOUNT_LV_YN = 'N'
     AND ACTV_YN = 'Y';
/*NULL  COLUMN COUNT ****************************************************************************************************************************/
    SELECT COUNT(*)    INTO p_COLUMN_CNT
    FROM(
    WITH T AS ( 
                SELECT 
                             MAIN.LVL01_NM     
                            ,MAIN.LVL02_NM     
                            ,MAIN.LVL03_NM     
                            ,MAIN.LVL04_NM     
                            ,MAIN.LVL05_NM     
                            ,MAIN.LVL06_NM    
                            ,MAIN.LVL07_NM     
                            ,MAIN.LVL08_NM     
                            ,MAIN.LVL09_NM     
                            ,MAIN.LVL10_NM    
                FROM TB_DPD_ITEM_HIERACHY2 MAIN   
                )
                SELECT NM FROM T
                UNPIVOT(VALUE FOR NM IN (
                                         LVL01_NM     
                                        ,LVL02_NM     
                                        ,LVL03_NM     
                                        ,LVL04_NM     
                                        ,LVL05_NM     
                                        ,LVL06_NM    
                                        ,LVL07_NM     
                                        ,LVL08_NM     
                                        ,LVL09_NM     
                                        ,LVL10_NM        
                                        )
                        )
                GROUP BY NM        
    ) RESULT;
/*ITEM_LV COUNT SET *******************************************************************************************************************************/

            SELECT MIN(ROWNUM) INTO p_COLUMN_NM_CNT
             FROM TB_CM_LEVEL_MGMT
            WHERE 1=1
             AND SALES_LV_YN = 'N'
             AND ACCOUNT_LV_YN = 'N'
             AND ACTV_YN = 'Y';


  SELECT A.LV_NM INTO p_COLUMN_NM
    FROM
            (
            SELECT LV_NM, ROW_NUMBER() OVER (ORDER BY SEQ) AS ROWNU
             FROM TB_CM_LEVEL_MGMT
            WHERE 1=1
             AND SALES_LV_YN = 'N'
             AND ACCOUNT_LV_YN = 'N'
             AND ACTV_YN = 'Y'
            ) A
    WHERE A.ROWNU = p_COLUMN_NM_CNT;


-- SELECT p_COLUMN_NM = LV_NM 
--   FROM TB_CM_LEVEL_MGMT 
--  WHERE 1=1
--  AND SALES_LV_YN = 'N'
--  AND ACCOUNT_LV_YN = 'N'
--  AND SEQ = p_COLUMN_NM_CNT
--  AND (LV_CD !=NULL OR LV_CD!='')


IF(p_COLUMN_CNT<=10)
    THEN
        p_COLUMN_CNT := p_SEQ-p_COLUMN_NM_CNT+1;

ELSE

        p_COLUMN_CNT := p_COLUMN_CNT;
END IF;

/*COUNT COLUMN SELECT ****************************************************************************************************************************************************************************/

        p_SQL := p_SQL || 'LVL'||LPAD(TO_CHAR(p_WHILE_CNT),2,'0')||'_CD    AS "I_SEQ001'||p_COLUMN_NM||',ITEM_CD", '
                       || 'LVL'||LPAD(TO_CHAR(p_WHILE_CNT),2,'0')||'_NM    AS "I_SEQ002'||p_COLUMN_NM||',ITEM_NM" ';

WHILE(p_WHILE_CNT < p_COLUMN_CNT)
    LOOP
        IF (p_WHILE_CNT < p_COLUMN_CNT)
            THEN
                 p_SQL         := p_SQL||', ';
        END IF;
         p_WHILE_CNT := p_WHILE_CNT+1;
         p_COLUMN_NM_CNT := p_COLUMN_NM_CNT+1;

          SELECT A.LV_NM INTO p_COLUMN_NM
            FROM
                    (
                    SELECT LV_NM, ROW_NUMBER() OVER (ORDER BY SEQ) AS R0WNU
                     FROM TB_CM_LEVEL_MGMT
                    WHERE 1=1
                     AND SALES_LV_YN = 'N'
                     AND ACCOUNT_LV_YN = 'N'
                     AND ACTV_YN = 'Y'
                    ) A
            WHERE A.R0WNU = p_COLUMN_NM_CNT;

         p_SQL := p_SQL || 'LVL'||LPAD(TO_CHAR(p_WHILE_CNT),2,'0')||'_CD    AS "I_SEQ'|| LPAD(TO_CHAR(p_COUNT),3,'0')||p_COLUMN_NM||',ITEM_CD", '
                        || 'LVL'||LPAD(TO_CHAR(p_WHILE_CNT),2,'0')||'_NM    AS "I_SEQ'|| LPAD(TO_CHAR(p_COUNT+1),3,'0')||p_COLUMN_NM||',ITEM_NM"';
         p_COUNT := p_COUNT+2;
    END LOOP;

--    IF((p_SEQ = (SELECT SEQ FROM TB_CM_LEVEL_MGMT WHERE 1=1 AND SALES_LV_YN = 'N' AND ACCOUNT_LV_YN = 'N' AND LEAF_YN = 'Y')) OR LTRIM(RTRIM(p_ITEM_LV)) = '' OR p_ITEM_LV = NULL)

           SELECT LV_NM INTO p_COLUMN_NM
             FROM TB_CM_LEVEL_MGMT
            WHERE 1=1
             AND SALES_LV_YN = 'N'
             AND ACCOUNT_LV_YN = 'N'
             AND ACTV_YN = 'Y'
             AND LEAF_YN = 'Y';
         p_SQL := p_SQL || ',LVL'||LPAD(TO_CHAR(p_WHILE_CNT),2,'0')||'_CD    AS KEY_ITEM_CD, '
                        ||  'LVL'||LPAD(TO_CHAR(p_WHILE_CNT),2,'0')||'_ID    AS KEY_ITEM_ID,'
                        ||  'LVL'||LPAD(TO_CHAR(p_WHILE_CNT),2,'0')||'_NM    AS KEY_ITEM_NM';


         p_SQL := p_SQL || ' FROM TB_DPD_ITEM_HIERACHY2'
                        || ' WHERE 1=1 '
                        || 'AND ( '''||p_ITEM_CD||''' IS NULL  '
                        || ' OR REGEXP_LIKE (UPPER(ITEM_CD), '''||REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[') ||''')) ' 
                        || 'AND ( '''||p_ITEM_NM||''' IS NULL  '
                        || ' OR REGEXP_LIKE (UPPER(ITEM_NM), '''||REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[') ||''')) ' 
--                      || 'AND ITEM_NM LIKE ''%'||p_ITEM_NM||'%'' '
                        || ' GROUP BY ';

/*GROUP BY ===============================================================================================================================================================================*/
WHILE(p_WHILE_CNT_02 <= p_COLUMN_CNT)
    LOOP
             p_SQL := p_SQL || 'LVL'||LPAD(TO_CHAR(p_WHILE_CNT_02),2,'0')||'_CD, '
                            || 'LVL'||LPAD(TO_CHAR(p_WHILE_CNT_02),2,'0')||'_NM';
            IF (p_WHILE_CNT_02 < p_COLUMN_CNT)
                THEN
                     p_SQL         := p_SQL || ', ';
            END IF;
             p_WHILE_CNT_02 := p_WHILE_CNT_02+1;                            
    END LOOP;

--    IF((p_SEQ = (SELECT SEQ FROM TB_CM_LEVEL_MGMT WHERE 1=1 AND SALES_LV_YN = 'N' AND ACCOUNT_LV_YN = 'N' AND LEAF_YN = 'Y')) OR p_ITEM_LV = '')
--        BEGIN
             p_SQL         := p_SQL || ' ,LVL'||LPAD(TO_CHAR(p_WHILE_CNT_02-1),2,'0')||'_ID ';
--        END
-- SELECT p_SQL
 
    BEGIN
  --       OPEN pRESULT FOR SELECT p_SQL FROM dual;
           OPEN pRESULT FOR p_SQL;
    --    p_SQL ;
           P_RT_MSG := 'SUCCESS';
    END;

EXCEPTION WHEN OTHERS THEN
    P_RT_MSG := 'FAIL';
END;
/

