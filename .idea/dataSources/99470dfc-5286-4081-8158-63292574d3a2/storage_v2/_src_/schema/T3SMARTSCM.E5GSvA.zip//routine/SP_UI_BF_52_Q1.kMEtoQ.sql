create PROCEDURE                SP_UI_BF_52_Q1(
	p_VER_CD        VARCHAR2 := NULL
  , p_ITEM_CD		VARCHAR2 := ''
  , p_ITEM_NM		VARCHAR2 := ''
  , p_ACCOUNT_CD	VARCHAR2 := ''
  , p_ACCOUNT_NM	VARCHAR2 := ''
  , pRESULT         OUT SYS_REFCURSOR
)IS
    v_ACCOUNT_CD VARCHAR2(50) := '';
    v_ACCOUNT_NM VARCHAR2(50) := '';
    v_ITEM_CD VARCHAR2(50) := '';
    v_ITEM_NM VARCHAR2(50) := '';
    p_ACCURACY VARCHAR2(30) :='';

BEGIN
    v_ACCOUNT_CD := CASE WHEN p_ACCOUNT_CD = '' THEN NULL ELSE p_ACCOUNT_CD END;
    v_ACCOUNT_NM := CASE WHEN p_ACCOUNT_NM = '' THEN NULL ELSE p_ACCOUNT_NM END;
    v_ITEM_CD := CASE WHEN p_ITEM_CD = '' THEN NULL ELSE p_ITEM_CD END;
    v_ITEM_NM := CASE WHEN p_ITEM_NM = '' THEN NULL ELSE p_ITEM_NM END;

    SELECT RULE_01 INTO p_ACCURACY
      FROM TB_BF_CONTROL_BOARD_VER_DTL
     WHERE VER_CD = p_VER_CD
       AND (PROCESS_NO = '990000' OR PROCESS_NO = '990')
    ;

    OPEN pRESULT FOR
    WITH RF
    AS (
        SELECT RF.ITEM_CD
             , IM.ITEM_NM 
             , IM.ATTR_05						 
             , RF.ACCOUNT_CD					 
             , AM.ACCOUNT_NM					 
             , ENGINE_TP_CD						 
             , CASE p_ACCURACY					 
                WHEN 'MAPE'		THEN MAPE		 
                WHEN 'MAE'		THEN MAE		 
                WHEN 'MAE_P'	THEN MAE_P		 
                WHEN 'RMSE'		THEN RMSE		 
                WHEN 'RMSE_P'	THEN RMSE_P
                WHEN 'MAPE_W'	THEN MAPE_W		
                WHEN 'WAPE'		THEN WAPE		
               END								AS ACCRY
             , RF.CREATE_BY
             , RF.CREATE_DTTM
             , RF.MODIFY_BY
             , RF.MODIFY_DTTM	
             , RF.SELECT_SEQ
             , RF.VER_CD						 
          FROM TB_BF_RT_ACCRCY RF
               INNER JOIN
               TB_CM_ITEM_MST IM
            ON RF.ITEM_CD = IM.ITEM_CD
               INNER JOIN
               TB_DP_ACCOUNT_MST AM
            ON RF.ACCOUNT_CD = AM.ACCOUNT_CD
         WHERE 1=1
            AND VER_CD = p_VER_CD
            AND  (  REGEXP_LIKE (UPPER(RF.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCOUNT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                OR 
                  p_ACCOUNT_CD IS NULL
                )
            AND  ( REGEXP_LIKE (UPPER(RF.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                OR 
                   p_ITEM_CD IS NULL
                )
            AND   ( REGEXP_LIKE (UPPER(AM.ACCOUNT_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCOUNT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                OR 
                  p_ACCOUNT_NM IS NULL
                )
            AND  ( REGEXP_LIKE (UPPER(IM.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                OR  
                   p_ITEM_NM IS NULL
                )
--            AND (  ( p_ACCOUNT_CD LIKE '%|%' AND UPPER(RF.ACCOUNT_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(p_ACCOUNT_CD),''),'|')) 
--                )OR(p_ACCOUNT_CD NOT LIKE '%|%' AND UPPER(RF.ACCOUNT_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCOUNT_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--                OR p_ACCOUNT_CD IS NULL 
--                )
--            AND (  ( p_ACCOUNT_NM LIKE '%|%' AND UPPER(AM.ACCOUNT_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(p_ACCOUNT_NM),''),'|')) 
--                )OR(p_ACCOUNT_NM NOT LIKE '%|%' AND UPPER(AM.ACCOUNT_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCOUNT_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--                OR p_ACCOUNT_NM IS NULL 
--                )
--            AND (  ( p_ITEM_CD LIKE '%|%' AND UPPER(RF.ITEM_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(p_ITEM_CD),''),'|')) 
--                )OR(p_ITEM_CD NOT LIKE '%|%' AND UPPER(RF.ITEM_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--                OR p_ITEM_CD IS NULL 
--                )
--            AND (  ( p_ITEM_NM LIKE '%|%' AND UPPER(IM.ITEM_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(p_ITEM_NM),''),'|')) 
--                )OR(p_ITEM_NM NOT LIKE '%|%' AND UPPER(IM.ITEM_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--                OR p_ITEM_NM IS NULL 
--                )
    ), RF_BEST 
    AS (
        SELECT ITEM_CD
             , ACCOUNT_CD
             , ENGINE_TP_CD 
          FROM RF 
         WHERE SELECT_SEQ = 1 
    )
	SELECT DISTINCT
		   RF.ITEM_CD
		 , RF.ITEM_NM 
		 , RF.ATTR_05						AS ITEM_GRADE
		 , RF.ACCOUNT_CD
		 , RF.ACCOUNT_NM
		 , RF.ENGINE_TP_CD					AS ENGINE_TP_CD 
		 , RF.ACCRY
		 , RF.CREATE_BY
		 , RF.CREATE_DTTM
		 , RF.MODIFY_BY
		 , RF.MODIFY_DTTM	
		 , 'ENGINE_TP_CD_'||RB.ENGINE_TP_CD					AS BEST_ENGINE
		 , RF.VER_CD						AS VER_ID 
	  FROM RF
		   LEFT OUTER JOIN
		   RF_BEST RB
		ON RF.ITEM_CD =  RB.ITEM_CD
	   AND RF.ACCOUNT_CD = RB.ACCOUNT_CD
       ;
END;
/

