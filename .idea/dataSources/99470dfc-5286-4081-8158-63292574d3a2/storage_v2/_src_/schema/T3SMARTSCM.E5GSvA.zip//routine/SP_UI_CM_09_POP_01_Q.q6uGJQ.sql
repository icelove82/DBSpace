create PROCEDURE "SP_UI_CM_09_POP_01_Q" (
    P_CONF_KEY IN VARCHAR2:='' ,
    P_LOCAT_CD IN VARCHAR2 :='',
    P_ITEM_CD IN VARCHAR2 :='',
    P_ITEM_NM IN VARCHAR2 :='',
    P_ITEM_TP IN VARCHAR2 :='',
    pResult OUT SYS_REFCURSOR
)
IS

BEGIN

	IF P_CONF_KEY ='001' /* WAREHOUSE TYPE */
	THEN
		OPEN pResult FOR
	        SELECT 
                       E.ID			    AS SITE_ITEM_ID
					  ,H.CONVN_NM	    AS ITEM_TP
					  ,F.ITEM_CD
					  ,F.ITEM_NM
					  ,G.UOM_NM
					FROM TB_AD_COMN_CODE A
	                  INNER JOIN TB_CM_LOC_MST B
	                    ON A.ID = B.LOCAT_TP_ID
					  INNER JOIN TB_CM_LOC_DTL C
	                    ON B.ID = C.LOCAT_MST_ID
					  INNER JOIN TB_CM_LOC_MGMT D
	                    ON C.ID = D.LOCAT_ID 
					  INNER JOIN TB_CM_SITE_ITEM E
	                    ON D.ID = E.LOCAT_MGMT_ID
					  INNER JOIN TB_CM_ITEM_MST F
	                    ON E.ITEM_MST_ID = F.ID
					  INNER JOIN TB_CM_UOM G
	                    ON F.UOM_ID = G.ID 
					  INNER JOIN TB_CM_ITEM_TYPE H
	                    ON F.ITEM_TP_ID = H.ID
	                   INNER JOIN TB_AD_COMN_CODE I
	                    ON I.ID = E.BOM_ITEM_TP_ID
	                WHERE 1=1
	                AND C.ID = RTRIM(LTRIM(P_LOCAT_CD))
	                AND F.ITEM_CD LIKE '%'||P_ITEM_CD||'%'
	                AND H.CONVN_NM LIKE '%'||P_ITEM_TP||'%'
                    AND F.ITEM_NM LIKE '%'||P_ITEM_NM||'%'
	                AND I.COMN_CD <>'SEMI_PRODUCT_GI_ITEM'
	                ORDER BY C.LOCAT_CD, F.ITEM_CD;
	
	ELSIF P_CONF_KEY ='002' /* ?？？？- Pallet Layer / Location Limit */
	THEN
		OPEN pResult FOR 
	        SELECT D.COMN_CD_NM AS LOCAT_TP
				 , B.LOCAT_LV
				 , C.LOCAT_CD
				 , C.ID AS LOC_DTL_ID
				 , C.LOCAT_NM
			  FROM TB_CM_CONFIGURATION A
	            INNER JOIN TB_CM_LOC_MST B
	              ON A.ID = B.CONF_ID
	            LEFT OUTER JOIN TB_AD_COMN_CODE D 
	              ON (B.LOCAT_TP_ID = D.ID)
	            INNER JOIN TB_CM_LOC_DTL C 
	              ON B.ID = C.LOCAT_MST_ID;
	
	END IF;

END;

/

