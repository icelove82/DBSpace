create PROCEDURE        "SP_UI_CM_01_POP_36_S" (
	 P_ID                   IN VARCHAR2 := ''
    ,P_PERIOD              IN VARCHAR2 := ''
    ,P_ACTV_YN              IN VARCHAR2 := ''
    ,P_USER_ID	            IN VARCHAR2 := ''
    ,P_WRK_TYPE	            IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG     OUT VARCHAR2 
    ,P_RT_MSG               OUT VARCHAR2
    
)
IS

    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';
    TIME_BULK VARCHAR2(10) := '';

BEGIN
IF P_WRK_TYPE = 'SAVE'
THEN

    SELECT A.UOM_NM INTO TIME_BULK FROM TB_CM_UOM A INNER JOIN TB_CM_HORIZON_TIME_BUCKET B ON A.ID = B.TIME_UOM_ID;

        IF TIME_BULK = 'Week'
        THEN
            P_ERR_MSG := 'MSG_5012'; --'Time Bucket？？ [Week]？？？？ ？？？？ ？？？？ WEEK？？ ？？？？ ？？？？？？？？.'
            IF (P_PERIOD = 'MONTH' AND P_ACTV_YN = 'Y') THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF; 
        END IF;

        IF TIME_BULK = 'Month'
        THEN
            P_ERR_MSG := 'MSG_5013'; --'Time Bucket？？ [Month]？？？？ ？？？？ ？？？？ MONTH？？ ？？？？ ？？？？？？？？.'
            IF (P_PERIOD = 'WEEK' AND P_ACTV_YN = 'Y') THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF; 
        END IF;

    MERGE INTO TB_CM_COMM_CONFIG B 
			USING (SELECT P_ID AS ID FROM DUAL) A
					ON     (B.ID = P_ID)

			WHEN MATCHED THEN

				UPDATE 
				   SET B.ACTV_YN		= P_ACTV_YN
					 , MODIFY_BY		= P_USER_ID
					 , MODIFY_DTTM		= SYSDATE();

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';  --？？？？ ？？？？？？？？.

END IF;

        EXCEPTION
        WHEN OTHERS THEN
            P_RT_ROLLBACK_FLAG := 'false';
            IF(SQLCODE = -20012)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF; 

END;

/

