create PROCEDURE SP_UI_DP_CONBD_MASTER_SET_GRID (
	 P_PLAN_TP_ID		IN	CHAR
	,P_ID				IN	CHAR
	,P_WORK_CD			IN	VARCHAR2
	,P_WORK_NM			IN	VARCHAR2
	,P_SEQ				IN	INT
	,P_DESCRIP			IN	VARCHAR2
	,P_WORK_TP_ID		IN	CHAR
	,P_LV_MGMT_ID		IN	CHAR
	,P_USER_ID			IN	VARCHAR2
	,P_RT_ROLLBACK_FLAG OUT	VARCHAR2   
	,P_RT_MSG			OUT	VARCHAR2   
)IS 

/*****************************************************************************
    SP_UI_DP_CONBD_MASTER_SET_GRID

    History (Date / Writer / Comment)
    - 2023.01.03 / kim sohee / oracle converting
*****************************************************************************/
   P_MODULE_ID CHAR(32);
   P_ERR_STATUS INT := 0;
   P_ERR_MSG VARCHAR2(4000) :='';
BEGIN

  SELECT C.ID INTO P_MODULE_ID
	FROM TB_AD_COMN_CODE C
		 INNER JOIN 
		 TB_AD_COMN_GRP G 
	   ON C.SRC_ID = G.ID 
	WHERE C.COMN_CD = 'DP' 
	  AND G.GRP_CD = 'MODULE_TP'
	  ;

	MERGE INTO TB_DP_CONTROL_BOARD_MST TGT
	USING ( 
			SELECT  P_ID				AS ID
				  , P_WORK_CD			AS WORK_CD	
				  , P_WORK_NM			AS WORK_NM			
				  , P_SEQ				AS SEQ				
				  , P_DESCRIP			AS DESCRIP
				  , P_LV_MGMT_ID	    AS LV_MGMT_ID
				  , P_USER_ID			AS USERNAME
                FROM DUAL
		  ) SRC
	ON (TGT.ID = SRC.ID)
	WHEN MATCHED THEN
		 UPDATE 
		   SET   TGT.WORK_NM		= SRC.WORK_NM						  
				,TGT.SEQ			= SRC.SEQ						  			  
				,TGT.DESCRIP		= SRC.DESCRIP					  
				,TGT.LV_MGMT_ID		= SRC.LV_MGMT_ID				  
				,TGT.MODIFY_BY		= SRC.USERNAME
				,TGT.MODIFY_DTTM	= SYSDATE
	WHEN NOT MATCHED THEN 
		 INSERT (
				 ID
				,MODULE_ID
				,WORK_CD
				,WORK_NM
				,SEQ
				,DESCRIP
				,WORK_TP_ID
				,LV_MGMT_ID
				,DEL_YN
				,PLAN_TP_ID
				,CREATE_BY
				,CREATE_DTTM
				) 
		 VALUES (
				 TO_SINGLE_BYTE(SYS_GUID())
				,P_MODULE_ID
				,SRC.WORK_CD	
				,SRC.WORK_NM				
				,SRC.SEQ	
				,SRC.DESCRIP				
				,COALESCE(P_WORK_TP_ID, (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_CD = 'DP' AND CONF_GRP_CD = 'DP_CL_WK_TP'))
				,SRC.LV_MGMT_ID
				,'N'			
				,P_PLAN_TP_ID
				,SRC.USERNAME
				,SYSDATE       
				) 
				;    
 	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  
       /*  ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN  
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF; 
END;
/

