create PROCEDURE                   "PR_SC_UI_COMMON_CODE_Q01" (
    P_CODE            IN  VARCHAR2:=    '' ,  /*구분 코드*/
    P_ATTR1           IN  VARCHAR2:=    '' ,  /*속성 1*/
    P_ATTR2           IN  VARCHAR2:=    '' ,  /*속성 2*/
    P_ATTR3           IN  VARCHAR2:=    '' ,  /*속성 3*/
    P_ATTR4           IN  VARCHAR2:=    '' ,  /*속성 4*/
    P_ATTR5           IN  VARCHAR2:=    '' ,  /*속성 5*/
    P_UI_ID           IN  VARCHAR2:=    '' ,  /*UI ID*/

    NEW_RESULT          OUT SYS_REFCURSOR
)IS
/*      실행
SET     SERVEROUTPUT ON; 
VAR     pRESULT REFCURSOR
EXEC    PR_SC_UI_COMMON_CODE_Q01('PLANT_LIST',NULL,NULL,NULL,NULL,NULL,NULL,:pRESULT)
PRINT   pRESULT
*/

BEGIN
    OPEN NEW_RESULT FOR
   select 'test' as code
   from DUAL;

END;
/

