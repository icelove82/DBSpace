create PROCEDURE                  "SP_UI_BF_53_CHART_Q1" 
(
    p_ITEM_CD		VARCHAR2:=''
   ,p_ITEM_NM		VARCHAR2:=''
   ,p_ACCOUNT_CD    VARCHAR2:=''
   ,p_ACCOUNT_NM    VARCHAR2:=''
   ,p_VER_CNT		INT	    := 4
   ,p_ENGINE_TP_CD	VARCHAR2:= 'RF'
   ,pRESULT         OUT SYS_REFCURSOR
)
IS

p_FROM_DATE	    DATE :='';
p_TO_DATE		DATE :='';
p_BUKT		    VARCHAR2(2):='';
p_VER_CD		VARCHAR2(30):='';
p_PREV_TO_DATE DATE :='';	
p_LAST_DATE DATE :='';

BEGIN
    WITH CB
	AS (
		SELECT VER_CD 
			 , ROW_NUMBER() OVER (ORDER BY VER_CD DESC) AS RW
		  FROM TB_BF_CONTROL_BOARD_VER_DTL
		 WHERE PROCESS_NO = '990000'
		   AND STATUS = 'Completed'
	)
	, TB_TMP_CB AS(
        SELECT DISTINCT 
               VER_cD , RW
          FROM CB 
         WHERE RW <= p_VER_CNT 
	)
    SELECT MIN(TARGET_FROM_DATE)	 
         , MAX(TARGET_TO_DATE)	 
         , MAX(TARGET_BUKT_CD)
           INTO
           p_FROM_DATE
         , p_TO_DATE
         , p_BUKT
      FROM TB_BF_CONTROL_BOARD_VER_DTL A
     WHERE VER_CD IN (SELECT VER_CD FROM TB_TMP_CB)
       AND ENGINE_TP_CD IS NOT NULL
     ;

    WITH CB
	AS (
		SELECT VER_CD 
			 , ROW_NUMBER() OVER (ORDER BY VER_CD DESC) AS RW
		  FROM TB_BF_CONTROL_BOARD_VER_DTL
		 WHERE PROCESS_NO = '990000'
		   AND STATUS = 'Completed'
	)
	, TB_TMP_CB AS(
        SELECT DISTINCT 
               VER_cD , RW
          FROM CB 
         WHERE RW <= p_VER_CNT 
	)
	SELECT TARGET_FROM_DATE	INTO p_LAST_DATE -- Month ?? ??쿡?? ??? ??????? ??...
	  FROM TB_BF_CONTROL_BOARD_VER_DTL
    WHERE VER_CD IN (SELECT VER_CD FROM TB_TMP_CB WHERE RW = 1)
      AND ENGINE_TP_CD IS NOT NULL
      AND ROWNUM=1
    ;
	/*************************************************************************************************************
		-- ???? ???? ???? ????? ??? ?????? ???? ??? ???? ???? ???
	************************************************************************************************************/
	IF (p_BUKT = 'W')
	THEN
		SELECT MAX(END_DATE) INTO p_TO_DATE
		  FROM (
				SELECT --YYYY
					   DP_WK
					 , MIN(DAT) AS STRT_DATE
					 , MAX(DAT) AS END_DATE
				  FROM TB_CM_CALENDAR C
				 WHERE DAT BETWEEN p_FROM_dATE AND p_TO_DATE
			  GROUP BY DP_WK
			  HAVING COUNT(DP_WK) >= 7
		) A;
	END IF;

    OPEN pRESULT FOR
    WITH M_CAL AS (
        SELECT DAT
             , YYYY
             , YYYYMM
             , CASE p_BUKT
                 WHEN 'W' THEN TO_NUMBER(TO_CHAR(DAT,'IW'))
--                 WHEN 'PW' THEN TO_NUMBER(TO_CHAR(DAT,'IW'))
                 WHEN 'M' THEN TO_NUMBER(YYYYMM)
               END AS BUKT
--              , CASE p_BUKT WHEN 'W' THEN SUBSTR( YYYY  ,-2) || ' w' || LPAD(DP_WK, 2, '0')
--                            WHEN 'PW'THEN SUBSTR( YYYYMM,-2) || ' w' || LPAD(DP_WK, 2, '0')
--                            WHEN 'M' THEN YYYYMM
--                            WHEN 'D' THEN YYYYMMDD 
--                            END		AS BUKT
--              , CASE WHEN DAT > p_LAST_DATE THEN '#AAc6d7ee' END AS COLOR 
          FROM TB_CM_CALENDAR
         WHERE DAT BETWEEN p_FROM_DATE AND p_TO_DATE
    ), 
    CA AS (
		SELECT MIN(DAT)	 STRT_DATE
			 , MAX(DAT)	 END_DATE
			 , TO_CHAR(MIN(DAT), 'YYYY-MM-DD') AS BUKT
--             , CASE p_BUKT
--                 WHEN 'W' THEN MIN(YYYY) || ' w' || LPAD(BUKT, 2, '0')
-- --                WHEN 'PW' THEN MIN(YYYYMM) || ' w' || BUKT
--                 WHEN 'M' THEN MIN(YYYYMM)
--               END AS BUKT
--             , MIN(COLOR) COLOR
			 , CASE WHEN MIN(DAT) > p_LAST_DATE THEN '#AAc6d7ee' END AS COLOR 
			 --, BUKT
		  FROM M_CAL
	   GROUP BY BUKT
	) 
	, 
    SA AS (
		SELECT  CA.STRT_DATE
			  , SUM(QTY)	QTY 
		  FROM TB_CM_ACTUAL_SALES S
		       INNER JOIN
			   CA
			ON S.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
			   INNER JOIN 
			   TB_CM_ITEM_MST IM 
			ON S.ITEM_MST_ID = IM.ID
		   AND COALESCE(IM.DEL_YN,'N') = 'N'
			   INNER JOIN 
			   TB_DP_ACCOUNT_MST AM
			ON S.ACCOUNT_ID = AM.ID
		   AND COALESCE(AM.DEL_YN,'N') = 'N'
		   AND AM.ACTV_YN = 'Y'
		 WHERE ITEM_CD = p_ITEM_CD
		   AND ACCOUNT_CD = p_ACCOUNT_CD
	  GROUP BY CA.STRT_DATE
	)
	, CB
	AS (
		SELECT VER_CD 
			 , ROW_NUMBER() OVER (ORDER BY VER_CD DESC) AS RW
		  FROM TB_BF_CONTROL_BOARD_VER_DTL
		 WHERE PROCESS_NO = '990000'
		   AND STATUS = 'Completed'
	)
	, TB_TMP_CB AS(
        SELECT DISTINCT 
               VER_cD , RW
          FROM CB 
         WHERE RW <= p_VER_CNT 
	)
	SELECT VER_CD 
		 , CA.BUKT AS BASE_DATE
		 , RH.QTY AS BF_QTY 
		 , SA.QTY AS ACT_SALES_QTY
		 , COLOR	 		  
--	 FROM M_CAL CA 
       FROM CA
            LEFT OUTER JOIN
            SA
        ON CA.STRT_DATE = SA.STRT_DATE
            LEFT OUTER JOIN
            TB_BF_RT_HISTORY RH
        ON RH.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
        AND RH.VER_CD IN (SELECT VER_CD FROM TB_TMP_CB)
        AND RH.ITEM_CD = p_ITEM_CD AND RH.ACCOUNT_CD = p_ACCOUNT_CD
        AND RH.ENGINE_TP_CD = 'PR'
	ORDER BY CA.STRT_DATE
      ;
END;

/

