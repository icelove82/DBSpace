create PROCEDURE                "SP_UI_BF_07_Q1"
(
    p_FROM_DATE    DATE
  , p_TO_DATE      DATE 
  , p_ITEM_CD      VARCHAR2 := ''
  , p_ITEM_NM      VARCHAR2 := ''
  , p_ACCOUNT_CD   VARCHAR2 := ''
  , p_ACCOUNT_NM   VARCHAR2 := ''
  , pRESULT OUT SYS_REFCURSOR
)

IS 
/*
    Factor Management by Item

    History (Date / Writer / Comment)
    -- 2020.02.23 / date parameter type change : Datetime => date
*/
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
--SET NOCOUNT ON
BEGIN
    OPEN pRESULT
    FOR
    SELECT SF.ID ID
         , SF.ACCOUNT_CD ACCOUNT_CD
         , A.ACCOUNT_NM  ACCOUNT_NM
         , SF.ITEM_CD    ITEM_CD
         , I.ITEM_NM     ITEM_NM
         , SF.BASE_DATE BASE_DATE
         , SF.SALES_FACTOR1
         , SF.SALES_FACTOR2
         , SF.SALES_FACTOR3
         , SF.SALES_FACTOR4
         , SF.SALES_FACTOR5
         , SF.SALES_FACTOR6
         , SF.SALES_FACTOR7
         , SF.SALES_FACTOR8
         , SF.SALES_FACTOR9
         , SF.SALES_FACTOR10
         , SF.SALES_FACTOR11
         , SF.SALES_FACTOR12
         , SF.SALES_FACTOR13
         , SF.SALES_FACTOR14
         , SF.SALES_FACTOR15
         , SF.SALES_FACTOR16
         , SF.SALES_FACTOR17
         , SF.SALES_FACTOR18
         , SF.SALES_FACTOR19
         , SF.SALES_FACTOR20
         , SF.MODIFY_BY MODIFY_BY
         , SF.MODIFY_DTTM MODIFY_DTTM
      FROM TB_BF_SALES_FACTOR SF
     INNER JOIN TB_DP_ACCOUNT_MST A ON SF.ACCOUNT_CD = A.ACCOUNT_CD
     INNER JOIN TB_CM_ITEM_MST I ON SF.ITEM_CD = I.ITEM_CD
     WHERE 1=1
       AND ( REGEXP_LIKE (UPPER(SF.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCOUNT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
             OR p_ACCOUNT_CD IS NULL
           )
       AND ( REGEXP_LIKE (UPPER(A.ACCOUNT_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCOUNT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
             OR  p_ACCOUNT_NM IS NULL
           )
       AND ( REGEXP_LIKE (UPPER(SF.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
             OR  p_ITEM_CD IS NULL
           )
       AND ( REGEXP_LIKE (UPPER(I.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
             OR  p_ITEM_NM IS NULL
           )
       AND BASE_DATE  BETWEEN p_FROM_DATE AND p_TO_DATE
    ORDER BY BASE_DATE ASC;
END;
/

