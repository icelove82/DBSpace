create PROCEDURE "SP_UI_CM_04_Q1" (
     P_LOCAT_TP             IN VARCHAR2:=''
    ,P_LOCAT_LV             IN VARCHAR2:=''
    ,P_LOCAT_CD             IN VARCHAR2:=''
    ,P_LOCAT_NM             IN VARCHAR2:=''
    ,P_ITEM_CD              IN VARCHAR2:=''
    ,P_ITEM_NM              IN VARCHAR2:=''
    ,P_ITEM_TP              IN VARCHAR2:=''
    ,P_BOM_ITEM_TP_ID       IN VARCHAR2:=''
    ,P_PROCUR_TP_ID       	IN VARCHAR2:=''
    ,P_DIFFER_GRADE         IN VARCHAR2:=''
    ,P_ACTV_YN              IN CHAR:=''
    ,pResult OUT SYS_REFCURSOR
)
IS
BEGIN
	
    OPEN pResult FOR
	SELECT E.ID
		 , A.COMN_CD_NM     AS LOCAT_TP               
		 , B.LOCAT_LV                           
		 , C.LOCAT_CD                           
		 , C.LOCAT_NM                           
		 , F.ITEM_CD                            
		 , F.ID				AS ITEM_MST_ID
		 , F.ITEM_NM
		 , F.DESCRIP                            
		 , F.ATTR_01
		 , F.ATTR_02
		 , F.ATTR_03
		 , F.ATTR_04
		 , F.ATTR_05
		 , F.ATTR_06
		 , F.ATTR_07
		 , F.ATTR_08
		 , F.ATTR_09
		 , F.ATTR_10
		 , F.ATTR_11
		 , F.ATTR_12
		 , F.ATTR_13
		 , F.ATTR_14
		 , F.ATTR_15
		 , F.ATTR_16
		 , F.ATTR_17
		 , F.ATTR_18
		 , F.ATTR_19
		 , F.ATTR_20
		 , M.ITEM_SCOPE_NM      AS ITEM_LV_NM
		 , G.ID                 AS ITEM_TP_ID
         , G.CONVN_NM           AS ITEM_TP
		 , E.BOM_ITEM_TP_ID
		 , E.PROCUR_TP_ID
		 , E.DIFFTD_CLSS_ID     AS DIFFTD_CLSS_CD
		 , H.CONF_NM            AS DIFFTD_CLSS_CD_NM
		 , F.MIN_ORDER_SIZE
		 , F.MAX_ORDER_SIZE
		 , K.ID		            AS UOM_CD
		 , K.UOM_NM             AS UOM_NM 
		 , E.CURCY_CD_ID        AS CURCY_CD
		 , I.COMN_CD_NM	        AS CURCY_CD_NM 
         , I.COMN_CD            
		 , E.SRA
		 , E.RTS
		 , E.EOP
		 , E.EOS 
		 , E.PARENT_ITEM_EOL
		 , E.INV_ONHAND_YN
		 , E.IMMEDIATE_SHIPMENT_YN
		 , J.ID                 AS INV_POLICY
		 , E.STD_UTPIC
		 , E.DIRECT_COST
		 , E.INDIRECT_COST
		 , E.MIN_LV
		 , E.MAX_LV
		 , E.ALLOWED_PUSH_YN
		 , E.PUSH_TP_ID
		 , E.ALTERNATE_PUSH_POLICY_ID
		 , E.ALLOWED_HOLIDAY_YN
		 , F.DEL_YN
		 , E.ACTV_YN
		 , E.CREATE_BY 
		 , E.CREATE_DTTM
		 , E.MODIFY_BY
		 , E.MODIFY_DTTM
	  FROM TB_AD_COMN_CODE A
	       INNER JOIN TB_CM_LOC_MST B 
		ON A.ID = B.LOCAT_TP_ID
		   INNER JOIN TB_CM_LOC_DTL C
		ON B.ID = C.LOCAT_MST_ID
		   INNER JOIN TB_CM_LOC_MGMT D
		ON C.ID = D.LOCAT_ID
		   INNER JOIN TB_CM_SITE_ITEM E 
		ON D.ID = E.LOCAT_MGMT_ID
		   INNER JOIN TB_CM_ITEM_MST F
		ON E.ITEM_MST_ID = F.ID
		   LEFT OUTER JOIN TB_CM_ITEM_TYPE G
		ON (F.ITEM_TP_ID = G.ID)
		   LEFT OUTER JOIN TB_CM_COMM_CONFIG H 
		ON (E.DIFFTD_CLSS_ID = H.ID)
		   LEFT OUTER JOIN TB_AD_COMN_CODE I 
		ON (E.CURCY_CD_ID = I.ID)
		   LEFT OUTER JOIN TB_CM_COMM_CONFIG J
		ON (E.INV_POLICY_ID = J.ID)
		   LEFT OUTER JOIN TB_CM_UOM K
		ON (F.UOM_ID = K.ID)
		   LEFT OUTER JOIN TB_CM_ITEM_SCOPE_DTL L
		ON (B.ID = L.LOCAT_MST_ID)
		   LEFT OUTER JOIN TB_CM_ITEM_SCOPE_MST M
		ON (L.ITEM_SCOPE_MST_ID = M.ID)
		   LEFT OUTER JOIN TB_AD_COMN_CODE N
		ON (E.BOM_ITEM_TP_ID = N.ID)
		   LEFT OUTER JOIN TB_AD_COMN_CODE O
		ON (E.PROCUR_TP_ID = O.ID)
	 WHERE 1=1
		   AND UPPER(NVL(A.COMN_CD_NM, ' ')) 	LIKE '%'||UPPER(P_LOCAT_TP)||'%'
		   AND B.LOCAT_LV 						LIKE '%'||P_LOCAT_LV||'%'
		   AND UPPER(NVL(C.LOCAT_CD, ' ')) 		LIKE '%'||UPPER(P_LOCAT_CD)||'%'
		   AND UPPER(NVL(F.ITEM_CD, ' ')) 		LIKE '%'||UPPER(P_ITEM_CD)||'%'
	       AND UPPER(NVL(C.LOCAT_NM, ' ')) 		LIKE '%'||UPPER(P_LOCAT_NM)||'%'
	       AND UPPER(NVL(F.ITEM_NM, ' ')) 		LIKE '%'||UPPER(P_ITEM_NM)||'%'
	       AND UPPER(NVL(G.CONVN_NM, ' ')) 		LIKE '%'||UPPER(P_ITEM_TP)||'%'
	       AND NVL(E.BOM_ITEM_TP_ID, ' ') 		LIKE '%'||UPPER(P_BOM_ITEM_TP_ID)||'%'
	       AND NVL(E.PROCUR_TP_ID, ' ') 		LIKE '%'||UPPER(P_PROCUR_TP_ID)||'%'
	       AND UPPER(NVL(H.CONF_NM, ' ')) 		LIKE '%'||RTRIM(P_DIFFER_GRADE)||'%'
	       AND E.ACTV_YN = CASE WHEN UPPER(P_ACTV_YN)='Y' THEN 'Y'
	                            WHEN UPPER(P_ACTV_YN)='N' THEN 'N'
	                            WHEN UPPER(P_ACTV_YN)='A' THEN E.ACTV_YN
	                        END
	ORDER BY A.SEQ, B.LOCAT_LV, C.LOCAT_CD, F.ITEM_CD, E.BOM_ITEM_TP_ID, E.PROCUR_TP_ID;
	
END;
/

