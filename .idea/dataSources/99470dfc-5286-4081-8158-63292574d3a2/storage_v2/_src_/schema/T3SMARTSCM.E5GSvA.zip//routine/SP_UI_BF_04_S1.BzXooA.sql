create PROCEDURE                "SP_UI_BF_04_S1"  (
      P_FACTOR_SET_CD		VARCHAR2
    , P_DESCRIPTION		    VARCHAR2
    , P_FACTOR_CD			VARCHAR2
    , P_USER_ID			    VARCHAR2
    , P_ACTV_YN			    CHAR
    , P_PREV_SET_CD		    VARCHAR2
    , P_CODE				VARCHAR2
    , P_RT_ROLLBACK_FLAG	OUT VARCHAR2
    , P_RT_MSG				OUT VARCHAR2
    ) 
IS

--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

    P_ERR_STATUS            NUMBER := 0;
    P_ERR_MSG               VARCHAR2(4000) := '';
    cnt                     PLS_INTEGER;

BEGIN
    -- 기존 FACTOR_SET 삭제
    SELECT COUNT(*) INTO cnt
    FROM TB_BF_FACTOR_SET
    WHERE FACTOR_SET_CD = P_PREV_SET_CD
        AND P_CODE = 'UPDATE';
    IF (cnt > 0) THEN
        DELETE FROM TB_BF_FACTOR_SET 
               WHERE 1=1
                     AND FACTOR_SET_CD = P_PREV_SET_CD
                     AND FACTOR_CD = P_FACTOR_CD;
    END IF;

    IF (P_ACTV_YN = 'Y') THEN
        INSERT INTO TB_BF_FACTOR_SET(
              ID
            , FACTOR_SET_CD
            , FACTOR_CD	
            , FACTOR_SET_DESCRIP
            , CREATE_BY
            , CREATE_DTTM
            )
        VALUES (
              RAWTOHEX(SYS_GUID())
            , P_FACTOR_SET_CD
            , P_FACTOR_CD
            , P_DESCRIPTION
            , P_USER_ID
            , SYSDATE
            );
    END IF;

    IF (P_PREV_SET_CD <> P_FACTOR_SET_CD) THEN
        UPDATE TB_BF_ITEM_ACCOUNT_MODEL_MAP
        SET FACTOR_SET_CD = P_FACTOR_SET_CD
        WHERE FACTOR_SET_CD = P_PREV_SET_CD;
    END IF;

     P_RT_ROLLBACK_FLAG := 'true';
     P_RT_MSG := 'MSG_0001';  --저장 되었습니다.

EXCEPTION WHEN OTHERS THEN
    IF (SQLERRM = P_ERR_MSG) THEN
        P_ERR_MSG := SQLERRM;
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
    ELSE 
        RAISE_APPLICATION_ERROR(SQLCODE, SQLERRM);
--              EXEC SP_COMM_RAISE_ERR
    END IF;
END;
/

