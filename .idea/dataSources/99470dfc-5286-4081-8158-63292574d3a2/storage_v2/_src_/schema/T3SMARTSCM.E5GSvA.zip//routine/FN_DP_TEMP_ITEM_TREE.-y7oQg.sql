create FUNCTION                FN_DP_TEMP_ITEM_TREE

RETURN DP_TEMP_ITEM_TREE IS
C_DP_TEMP_ITEM_TREE DP_TEMP_ITEM_TREE := DP_TEMP_ITEM_TREE();
CURSOR C_DATA_IMPORT IS     
    SELECT TP_DP_TEMP_ITEM_TREE (
        LEAF_ITEM_LV_ID  => LEAF_ITEM_LV_ID
      , PATH_ID          => PATH_ID
      , LEAF_ITEM_LV_CD  => LEAF_ITEM_LV_CD
      , PATH_CD          => PATH_CD
      , LEAF_ITEM_LV_NM  => LEAF_ITEM_LV_NM
      , SEQ              => SEQ
    )
      FROM (
        WITH 
        TB_PR_ITEM_LEVEL_MGMT (
            ID
          , "PATH"
          , PATH_ID
          , SEQ
          , ITEM_LV_NM
        ) AS (
            SELECT SL.ID
                 , CAST('/'||SL.ITEM_LV_CD AS VARCHAR2(4000)) AS "PATH"
                 , CAST('/'||SL.ID AS VARCHAR2(4000)) AS "PATH_ID"
                 , LM.SEQ AS SEQ
                 , SL.ITEM_LV_NM
             FROM TB_CM_ITEM_LEVEL_MGMT SL
                  INNER JOIN
                  TB_CM_LEVEL_MGMT LM
              ON SL.LV_MGMT_ID = LM.ID
				INNER JOIN TB_CM_COMM_CONFIG tccc 
				ON tccc.ID = LM.LV_TP_ID  AND tccc.CONF_CD = 'I'
              WHERE SL.PARENT_ITEM_LV_ID IS NULL  
              AND COALESCE(LM.DEL_YN,'N') = 'N'
              AND COALESCE(SL.DEL_YN,'N') = 'N'
              AND COALESCE(LM.SALES_LV_YN  ,'N') = 'N'    
              AND LM.ACTV_YN = 'Y'
              AND SL.ACTV_YN = 'Y'
            UNION ALL        
            SELECT SL.ID
                 , CAST("PATH"||'/'||SL.ITEM_LV_CD AS VARCHAR2(4000)) AS "PATH"      
                 , CAST("PATH_ID"||'/'||SL.ID AS VARCHAR2(4000)) AS "PATH_ID"        
                 , LM.SEQ
                 , SL.ITEM_LV_NM
              FROM TB_CM_ITEM_LEVEL_MGMT SL
                   INNER JOIN
                   TB_PR_ITEM_LEVEL_MGMT PL
                ON SL.PARENT_ITEM_LV_ID = PL.ID
                   INNER JOIN
                   TB_CM_LEVEL_MGMT LM
                ON SL.LV_MGMT_ID = LM.ID
				INNER JOIN TB_CM_COMM_CONFIG tccc 
				ON tccc.ID = LM.LV_TP_ID  AND tccc.CONF_CD = 'I'
             WHERE COALESCE(LM.DEL_YN,'N') = 'N'
               AND COALESCE(SL.DEL_YN,'N') = 'N'
               AND COALESCE(LM.SALES_LV_YN  ,'N') = 'N'
               AND LM.ACTV_YN = 'Y'
               AND SL.ACTV_YN = 'Y'
        )
        SELECT SUBSTR(M."PATH_ID", -INSTR(REVERSE(M.PATH_ID),'/')+1)        AS LEAF_ITEM_LV_ID
             , SUBSTR(M."PATH", -INSTR(REVERSE(M.PATH),'/')+1)          AS LEAF_ITEM_LV_CD
             , "PATH_ID"
             , M."PATH" AS PATH_CD
             , M.ITEM_LV_NM AS LEAF_ITEM_LV_NM
             , M.SEQ        
          FROM TB_PR_ITEM_LEVEL_MGMT M
          
         WHERE SEQ = (
            SELECT MAX(SEQ) 
              FROM TB_CM_LEVEL_MGMT LM
				INNER JOIN TB_CM_COMM_CONFIG tccc 
				ON tccc.ID = LM.LV_TP_ID  AND tccc.CONF_CD = 'I'
             WHERE COALESCE(SALES_LV_YN  ,'N') = 'N'
               AND COALESCE(ACCOUNT_LV_YN,'N') = 'N'
               AND LV_LEAF_YN = 'Y' 
               AND COALESCE(LM.DEL_YN,'N') = 'N' 
               AND LM.ACTV_YN = 'Y'
         )
         
      );

BEGIN
        OPEN C_DATA_IMPORT;
        FETCH C_DATA_IMPORT BULK COLLECT INTO C_DP_TEMP_ITEM_TREE;
        CLOSE C_DATA_IMPORT;    
    RETURN C_DP_TEMP_ITEM_TREE;
END;
/

