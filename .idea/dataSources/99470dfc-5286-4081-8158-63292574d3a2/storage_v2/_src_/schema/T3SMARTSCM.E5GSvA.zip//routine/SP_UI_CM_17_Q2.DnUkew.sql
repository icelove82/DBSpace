create PROCEDURE                "SP_UI_CM_17_Q2" (
    P_MODULE_ID           IN VARCHAR2 := '' ,
    pResult OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN pResult FOR 
    SELECT   A.MODULE_ID
            ,A.MODULE_NM
            ,A.VER_DATE
            ,A.MAIN_VER_ID
            ,A.MAIN_VER_DESCRIP
            ,B.SNRIO_VER_ID
            ,B.SNRIO_DESCRIP
            ,B.STEP
            ,B.PROCESS_TP_ID
            ,B.PROCESS_TP_NM
            ,B.PROCESS_DESCRIP
            ,A.SIMUL_VER_ID
            ,A.SIMUL_VER_DESCRIP
			,A.REVISION_VER_ID
			,A.REVISION_VER_DESC
            ,C.PLAN_POLICY_VER_ID
            ,C.PLAN_POLICY_VER_DESCRIP  AS PLAN_POLICY_DESCRIP
            ,(
            SELECT X.SIMUL_VER_ID
                FROM TB_CM_CONBD_MAIN_VER_DTL X
                WHERE 1=1
                AND X.ID = A.REFER_CONBD_MAIN_VER_DTL_ID
            ) AS REFER_SIMUL_VER_ID
			,A.LOAD_STRT_DTTM
			,A.LOAD_END_DTTM
			,A.PLAN_STRT_DTTM
			,A.PLAN_END_DTTM
            ,A.STRT_DTTM
            ,A.END_DTTM
            ,A.ING_DTTM
            ,A.EXE_USER
            ,A.CONFRM_YN
            ,A.CONFRM_DTTM
            ,A.CONFRM_EMP_ID
            ,A.ERR
        FROM (
            SELECT  A.PLAN_SNRIO_MGMT_MST_ID
                    ,B.PLAN_SNRIO_MGMT_DTL_ID
                    ,A.MODULE_ID
                    ,C.COMN_CD_NM AS MODULE_NM
                    ,A.VER_DATE
                    ,A.MAIN_VER_ID
                    ,A.DESCRIP AS MAIN_VER_DESCRIP
                    ,B.SIMUL_VER_ID
                    ,B.SIMUL_VER_DESCRIP
					,D.REVISION_VER_ID
					,D.REVISION_VER_DESC
                    ,B.REFER_CONBD_MAIN_VER_DTL_ID
					,B.LOAD_STRT_DTTM
					,B.LOAD_END_DTTM
					,B.PLAN_STRT_DTTM
					,B.PLAN_END_DTTM
                    ,B.STRT_DTTM
                    ,B.END_DTTM
                    ,B.ELAPSED_TIME AS ING_DTTM
                    ,NVL(B.MODIFY_BY, B.CREATE_BY) AS EXE_USER
                    ,B.CONFRM_YN
                    ,B.CONFRM_DTTM
                    ,B.CONFRM_EMP_ID
                    ,B.ERR
                FROM  TB_CM_CONBD_MAIN_VER_MST A
                INNER JOIN TB_CM_CONBD_MAIN_VER_DTL B
                    ON  A.ID = B.CONBD_MAIN_VER_MST_ID
                INNER JOIN TB_AD_COMN_CODE C
                    ON  A.MODULE_ID = C.ID
				LEFT OUTER JOIN TB_MP_MASTER_VER D
				ON D.ID = B.REVISION_ID
            WHERE 1=1
                AND C.ID = P_MODULE_ID
            ) A
            JOIN 
            (
            SELECT  A.ID AS PLAN_SNRIO_MGMT_MST_ID
                    ,B.ID AS PLAN_SNRIO_MGMT_DTL_ID
                    ,A.SNRIO_VER_ID
                    ,A.DESCRIP AS SNRIO_DESCRIP
                    ,B.STEP
                    ,B.PROCESS_DESCRIP
                    ,B.PROCESS_TP_ID
                    ,C.COMN_CD_NM AS PROCESS_TP_NM
                    ,B.PLAN_POLICY_MGMT_ID
                FROM  TB_CM_PLAN_SNRIO_MGMT_MST A
                INNER JOIN TB_CM_PLAN_SNRIO_MGMT_DTL B
                ON A.ID = B.PLAN_SNRIO_MGMT_MST_ID
                INNER JOIN TB_AD_COMN_CODE C
                ON B.PROCESS_TP_ID = C.ID
            ) B
        ON (
                A.PLAN_SNRIO_MGMT_MST_ID = B.PLAN_SNRIO_MGMT_MST_ID
            AND A.PLAN_SNRIO_MGMT_DTL_ID = B.PLAN_SNRIO_MGMT_DTL_ID
            )
            LEFT OUTER JOIN 
            (
            SELECT  A.ID AS PLAN_POLICY_MGMT_ID
                    ,A.VER_ID AS PLAN_POLICY_VER_ID
                    ,B.PLAN_POLICY_VAL_01 AS PLAN_POLICY_VER_DESCRIP
                FROM  TB_CM_PLAN_POLICY_MGMT A
                INNER JOIN TB_CM_PLAN_POLICY_VALUE B
                ON A.ID = B.PLAN_POLICY_MGMT_ID
                INNER JOIN TB_CM_PLAN_POLICY_MST C
                ON B.PLAN_POLICY_MST_ID = C.ID
            WHERE 1=1
                AND C.PLAN_POLICY_ITEM_ID = 'M00020000'
                AND A.ACTV_YN = 'Y'
            ) C
        ON (B.PLAN_POLICY_MGMT_ID = C.PLAN_POLICY_MGMT_ID)
        ORDER BY A.SIMUL_VER_ID DESC;
END;
/

