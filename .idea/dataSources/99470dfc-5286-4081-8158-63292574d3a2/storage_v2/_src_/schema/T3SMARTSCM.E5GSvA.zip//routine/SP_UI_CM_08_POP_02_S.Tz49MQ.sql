create PROCEDURE SP_UI_CM_08_POP_02_S (
     P_WRK_TYPE				IN VARCHAR2 := ''
	,P_ID	                IN CHAR := ''
	,P_SHPP_LEADTIME_DTL_ID	IN VARCHAR2 := ''
	,P_STRT_DATE			IN DATE := ''
	,P_END_DATE				IN DATE := ''
	,P_MON_YN				IN CHAR := 'N'
	,P_TUE_YN				IN CHAR := 'N'
	,P_WED_YN				IN CHAR := 'N'
	,P_THU_YN				IN CHAR := 'N'
	,P_FRI_YN				IN CHAR := 'N'
	,P_SAT_YN				IN CHAR := 'N'
	,P_SUN_YN				IN CHAR := 'N'
    ,P_ACTV_YN              IN CHAR := ''
	,P_USER_ID				IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG     OUT VARCHAR2
	,P_RT_MSG               OUT VARCHAR2
)
IS
    P_ERR_STATUS NUMBER := 0;
    P_ERR_MSG VARCHAR2(4000) := '';      

BEGIN

    IF P_WRK_TYPE = 'SAVE'
    THEN
        MERGE INTO TB_CM_SHIP_LT_EXCEPTION_SCH B 
        USING (SELECT P_ID AS ID
                 FROM DUAL
               ) A
           ON (B.ID = A.ID)
        WHEN MATCHED THEN
            UPDATE 
               SET STRT_DATE    = P_STRT_DATE
                 , END_DATE     = P_END_DATE
                 , MON_YN	    = P_MON_YN
                 , TUE_YN		= P_TUE_YN
                 , WED_YN		= P_WED_YN
                 , THU_YN		= P_THU_YN
                 , FRI_YN		= P_FRI_YN
                 , SAT_YN		= P_SAT_YN
                 , SUN_YN		= P_SUN_YN
                 , ACTV_YN      = P_ACTV_YN
                 , MODIFY_BY	= P_USER_ID
                 , MODIFY_DTTM	= SYSDATE
        WHEN NOT MATCHED THEN
            INSERT (
                ID
                ,SHPP_LEADTIME_DTL_ID
                ,STRT_DATE			
                ,END_DATE
                ,MON_YN
                ,TUE_YN
                ,WED_YN
                ,THU_YN
                ,FRI_YN
                ,SAT_YN
                ,SUN_YN
                ,ACTV_YN
                ,CREATE_BY
                ,CREATE_DTTM
                )
            VALUES 
                (
                TO_SINGLE_BYTE(SYS_GUID())
                ,P_SHPP_LEADTIME_DTL_ID
                ,P_STRT_DATE	
                ,P_END_DATE	
                ,P_MON_YN
                ,P_TUE_YN
                ,P_WED_YN
                ,P_THU_YN
                ,P_FRI_YN
                ,P_SAT_YN
                ,P_SUN_YN
                ,P_ACTV_YN
                ,P_USER_ID
                ,SYSDATE
            );

      P_RT_ROLLBACK_FLAG := 'true';
      P_RT_MSG := 'MSG_0001';

    ELSIF P_WRK_TYPE = 'DELETE'
    THEN
        DELETE 
          FROM TB_CM_SHIP_LT_EXCEPTION_SCH
         WHERE ID = P_ID;

        P_RT_ROLLBACK_FLAG := 'true';
		P_RT_MSG := 'MSG_0002';
        
    END IF;

    EXCEPTION
    WHEN OTHERS THEN
        IF(SQLCODE = -20012)
        THEN
              P_RT_ROLLBACK_FLAG := 'false';
              P_RT_MSG := P_ERR_MSG;
          ELSE
              RAISE;
          END IF;
END;

/

