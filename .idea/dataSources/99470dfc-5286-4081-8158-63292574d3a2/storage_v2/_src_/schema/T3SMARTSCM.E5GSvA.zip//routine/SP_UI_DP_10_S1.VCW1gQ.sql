create PROCEDURE                "SP_UI_DP_10_S1" (
                                       p_ID                     IN VARCHAR2      := NULL         
									  ,p_SALES_LV_CD            IN VARCHAR       := NULL         
									  ,p_SALES_LV_NM		    IN VARCHAR       := NULL         
									  ,p_LV_MGMT_ID             IN VARCHAR2      := NULL      
									  ,p_PARENT_SALES_LV_ID     IN VARCHAR2      := NULL   
									  ,p_SEQ				    IN INT			 := NULL 
									  ,p_VIRTUAL_YN			    IN CHAR          := NULL          
									  ,p_CURCY_CD_ID	        IN VARCHAR2      := NULL 
                                      ,P_SRP_YN                 IN CHAR      := NULL
									  ,p_ACTV_YN 			    IN CHAR          := NULL          
									  ,p_DEL_YN 			    IN CHAR          := NULL          
									  ,p_USER_ID                IN VARCHAR2           
								      ,P_RT_ROLLBACK_FLAG		OUT VARCHAR2    
								      ,P_RT_MSG					OUT VARCHAR2	
				                   ) 
IS
       P_ERR_STATUS INT := 0;
       P_ERR_STATUS_02 INT := 0;
       P_ERR_MSG VARCHAR2(4000) :='';
       V_SLM_COUNT INT := 0;
/*****************************************************************************************************************************************************************************************/
BEGIN
	P_RT_ROLLBACK_FLAG := 'true';
IF(p_SALES_LV_CD IS NULL)
	THEN
		   P_ERR_MSG := 'MSG_5034' ;
		   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
	END IF;
IF(p_LV_MGMT_ID IS NULL)
	THEN
		   P_ERR_MSG := 'MSG_5035' ;
		   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
	END IF;

	SELECT COUNT(*) INTO V_SLM_COUNT
	  FROM TB_DP_SALES_LEVEL_MGMT
	 WHERE 1 = 1
	   AND SALES_LV_CD = P_SALES_LV_CD
	   AND ID != P_ID;

    IF V_SLM_COUNT > 0 THEN
        P_ERR_MSG := 'MSG_0013';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

       SELECT SEQ INTO P_ERR_STATUS
         FROM TB_CM_LEVEL_MGMT 
        WHERE 1=1
          AND ID = P_LV_MGMT_ID;
   SELECT MIN(SEQ) INTO P_ERR_STATUS_02
     FROM TB_CM_LEVEL_MGMT
    WHERE 1=1
      AND ACTV_YN = 'Y'
      AND NVL(DEL_YN, 'N') = 'N'
      AND SALES_LV_YN = 'Y'
--      AND ACCOUNT_LV_YN = 'N'
;
/* ------------------------------ */
IF (P_ERR_STATUS = P_ERR_STATUS_02 AND p_PARENT_SALES_LV_ID IS NOT NULL)
    THEN
	   P_ERR_MSG := 'MSG_5154' ;
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;
/* ------------------------------ */
IF (P_ERR_STATUS != P_ERR_STATUS_02 AND p_PARENT_SALES_LV_ID IS NULL)
    THEN
	   P_ERR_MSG := 'MSG_5051' ;
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

				MERGE INTO TB_DP_SALES_LEVEL_MGMT TGT
				USING ( 
						SELECT    p_ID                      AS ID                
								, p_SALES_LV_CD             AS SALES_LV_CD       
								, p_SALES_LV_NM		        AS SALES_LV_NM		
								, p_LV_MGMT_ID              AS LV_MGMT_ID        
								, p_PARENT_SALES_LV_ID      AS PARENT_SALES_LV_ID
								, p_SEQ  				    AS SEQ 
								, p_VIRTUAL_YN			    AS VIRTUAL_YN		
								, p_CURCY_CD_ID	            AS CURCY_CD_ID
                                , COALESCE(P_SRP_YN, 'N')   AS SRP_YN
								, COALESCE(p_ACTV_YN, 'N')  AS ACTV_YN 	
                                , COALESCE(p_DEL_YN, 'N')   AS DEL_YN
							    , p_USER_ID                 AS USER_ID						
					  FROM dual ) SRC
				ON     (TGT.ID = SRC.ID)
				WHEN MATCHED THEN
					 UPDATE 
					   SET   TGT.SALES_LV_CD            = SRC.SALES_LV_CD              
							,TGT.SALES_LV_NM		    = SRC.SALES_LV_NM		
							,TGT.LV_MGMT_ID             = SRC.LV_MGMT_ID        
							,TGT.PARENT_SALES_LV_ID     = SRC.PARENT_SALES_LV_ID
							,TGT.SEQ                    = SRC.SEQ 
							,TGT.VIRTUAL_YN		        = SRC.VIRTUAL_YN		
							,TGT.CURCY_CD_ID	        = SRC.CURCY_CD_ID	
                            ,TGT.SRP_YN                 = SRC.SRP_YN
							,TGT.ACTV_YN 			    = SRC.ACTV_YN 	
                            ,TGT.DEL_YN                 = SRC.DEL_YN
							,TGT.MODIFY_BY              = SRC.USER_ID       
							,TGT.MODIFY_DTTM            = SYSDATE     
				WHEN NOT MATCHED THEN 
					 INSERT (
					            ID                
							  , SALES_LV_CD       
							  , SALES_LV_NM		
							  , LV_MGMT_ID        
							  , PARENT_SALES_LV_ID
							  , SEQ 
							  , VIRTUAL_YN		
							  , CURCY_CD_ID	 
                              , SRP_YN
							  , ACTV_YN
							  , DEL_YN 			
							  , CREATE_BY
							  , CREATE_DTTM
							) 
					 VALUES (
					            TO_SINGLE_BYTE(SYS_GUID()) --(SELECT   )
							  , SRC.SALES_LV_CD       
							  , SRC.SALES_LV_NM		
							  , SRC.LV_MGMT_ID        
							  , SRC.PARENT_SALES_LV_ID
							  , SRC.SEQ 
							  , SRC.VIRTUAL_YN		
							  , SRC.CURCY_CD_ID	 
                              , SRC.SRP_YN
							  , SRC.ACTV_YN 
							  , 'N'			
							  , SRC.USER_ID 
							  , SYSDATE    
 							) 
							;    	

	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  
       /* ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN  --  e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;  
     END;
/

