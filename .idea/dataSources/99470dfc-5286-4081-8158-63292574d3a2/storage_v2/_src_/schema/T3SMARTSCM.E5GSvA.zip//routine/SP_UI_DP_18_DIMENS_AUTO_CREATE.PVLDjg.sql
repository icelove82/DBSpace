create PROCEDURE                "SP_UI_DP_18_DIMENS_AUTO_CREATE" 
(
     P_GRP_ID       IN  VARCHAR2 :=''
    ,P_UI_ID            IN  VARCHAR2 :=''
    ,P_GRID_ID          IN  VARCHAR2 :=''
    ,P_USER_ID          IN  VARCHAR2 :=''
    ,P_ITEM_LV_TP_ID    IN VARCHAR2
    ,P_SALES_LV_TP_ID   IN VARCHAR2
    ,P_RT_ROLLBACK_FLAG OUT VARCHAR2      
    ,P_RT_MSG           OUT VARCHAR2  
)IS
    /*****************************************************************************************************************
        DP Dimension
        2018.06.01
        2021.06.09 / Kim sohee / Remove comment 
        2021.06.07 / KSH / dimension code : comment key        
        2021.06.16 / Kim sohee / keep Preference Data by user             
    *****************************************************************************************************************/
       P_ERR_STATUS INT := 0;
       P_ERR_MSG VARCHAR2(4000):='';
       V_SEQ INT := 0;
BEGIN
    -------- Validation -------------------------------------------------------------------------------------------
    SELECT COUNT(ID) INTO P_ERR_STATUS
      FROM TB_AD_GROUP
     WHERE ID = P_GRP_ID;

    IF P_ERR_STATUS = 0 THEN
        P_ERR_MSG := 'MSG_5049';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

    --------------------------------------------------------------------------------------------------

    DELETE 
      FROM TB_DP_DIM_SETTING
     WHERE 1=1
       AND UI_ID = P_UI_ID
       AND GRID_ID = P_GRID_ID
       AND RTRIM(GRP_ID) = P_GRP_ID
    ;
    -----1. ITEM LEVEL & ITEM ---------------------------------------------------------------------------------------------
    -------------CODE
    INSERT INTO TB_DP_DIM_SETTING
                ( ID
                , UI_ID
                , GRID_ID
                , GRP_ID
                , LV_MGMT_ID
                , COL_NM
                , DISP_NM
                , SEQ
                , ACTV_YN
                , CREATE_BY
                , CREATE_DTTM
                , MODIFY_BY
                , MODIFY_DTTM
                )
        SELECT   TO_SINGLE_BYTE(SYS_GUID()) AS ID
               , P_UI_ID                    AS UI_ID
               , P_GRID_ID                  AS GRID_ID
               , P_GRP_ID
               , ID                         AS LV_MGMT_ID
               , CASE WHEN LEAF_YN = 'N' 
                      THEN 'ITEM_LV_CD'
                      ELSE 'ITEM_CD'
                 END                        AS COL_NM
               , LV_CD||'_CD'               AS DISP_NM
               , 2*(ROW_NUMBER() OVER (ORDER BY SEQ))-1                 AS SEQ
               , 'Y'                        AS ACTV_YN
               , P_USER_ID                  AS CREATE_BY
               , SYSDATE                    AS CREATE_DTTM
               , NULL                       AS MODIFY_BY
               , NULL                       AS MODIFY_DTTM
          FROM TB_CM_LEVEL_MGMT
         WHERE 1=1
           AND SALES_LV_YN = 'N'
           AND ACCOUNT_LV_YN = 'N'
           AND COALESCE(DEL_YN,'N') = 'N'
           AND ACTV_YN = 'Y'
           AND LV_TP_ID = P_ITEM_LV_TP_ID
         ORDER BY SEQ
    ;
            --------------NAME
    INSERT INTO TB_DP_DIM_SETTING
                ( ID
                , UI_ID
                , GRID_ID
                , GRP_ID
                , LV_MGMT_ID
                , COL_NM
                , DISP_NM
                , SEQ
                , ACTV_YN
                , CREATE_BY
                , CREATE_DTTM
                , MODIFY_BY
                , MODIFY_DTTM
                )
        SELECT   TO_SINGLE_BYTE(SYS_GUID()) AS ID
               , P_UI_ID                    AS UI_ID
               , P_GRID_ID                  AS GRID_ID
               , P_GRP_ID
               , ID                         AS LV_MGMT_ID
               , CASE WHEN LEAF_YN = 'N' 
                      THEN 'ITEM_LV_NM' 
                      ELSE 'ITEM_NM' 
                 END                        AS COL_NM
               , LV_CD||'_NM'               AS DISP_NM
               , 2*(ROW_NUMBER() OVER (ORDER BY SEQ))    AS SEQ
               , 'Y'                        AS ACTV_YN
               , P_USER_ID                  AS CREATE_BY
               , SYSDATE                    AS CREATE_DTTM
               , NULL                       AS MODIFY_BY
               , NULL                       AS MODIFY_DTTM
          FROM TB_CM_LEVEL_MGMT
         WHERE 1=1
           AND SALES_LV_YN = 'N'
           AND ACCOUNT_LV_YN = 'N'
           AND COALESCE(DEL_YN,'N') = 'N'
           AND ACTV_YN = 'Y'
           AND LV_TP_ID = P_ITEM_LV_TP_ID           
         ORDER BY SEQ
    ;                 
    -----2. SALES LEVEL & ACCOUNT ------------------------------------------------------------------------------------------
    -- ITEM LEVEL ???? COUNT
    SELECT COUNT(*) INTO V_SEQ 
      FROM TB_DP_DIM_SETTING
     WHERE 1=1 
       AND UI_ID = P_UI_ID
       AND GRID_ID = P_GRID_ID
       AND RTRIM(GRP_ID) = P_GRP_ID
    ;

    INSERT INTO TB_DP_DIM_SETTING
                ( ID
                , UI_ID
                , GRID_ID
                , GRP_ID
                , LV_MGMT_ID
                , COL_NM
                , DISP_NM
                , SEQ
                , ACTV_YN
                , CREATE_BY
                , CREATE_DTTM
                , MODIFY_BY
                , MODIFY_DTTM
                )
        SELECT
                 TO_SINGLE_BYTE(SYS_GUID()) AS ID
               , P_UI_ID                    AS UI_ID
               , P_GRID_ID                  AS GRID_ID
               , P_GRP_ID                   AS GRP_ID
               , ID                         AS LV_MGMT_ID
               , CASE WHEN SALES_LV_YN = 'Y' 
                      THEN 'SALES_LV_CD'  
                      ELSE 'ACCOUNT_CD'  
                 END                        AS COL_NM
               , LV_CD||'_CD'               AS DISP_NM
               , V_SEQ+2*(SEQ)-1            AS SEQ
               , 'Y'                        AS ACTV_YN
               , P_USER_ID                  AS CREATE_BY
               , SYSDATE                    AS CREATE_DTTM
               , NULL                       AS MODIFY_BY
               , NULL                       AS MODIFY_DTTM
         FROM TB_CM_LEVEL_MGMT
        WHERE 1=1
         AND ACCOUNT_LV_YN = 'Y'
         AND NVL(DEL_YN,'N') = 'N'
         AND ACTV_YN = 'Y'
         AND LV_TP_ID = P_SALES_LV_TP_ID
         ORDER BY SEQ
        ;

        INSERT INTO TB_DP_DIM_SETTING
                    ( ID
                    , UI_ID
                    , GRID_ID
                    , GRP_ID
                    , LV_MGMT_ID
                    , COL_NM
                    , DISP_NM
                    , SEQ
                    , ACTV_YN
                    , CREATE_BY
                    , CREATE_DTTM
                    , MODIFY_BY
                    , MODIFY_DTTM
                    )
            SELECT
                     TO_SINGLE_BYTE(SYS_GUID()) AS ID
                   , P_UI_ID                    AS UI_ID
                   , P_GRID_ID                  AS GRID_ID
                   , P_GRP_ID                   AS GRP_ID
                   , ID                         AS LV_MGMT_ID
                   , CASE WHEN SALES_LV_YN = 'Y' 
                          THEN 'SALES_LV_NM' 
                          ELSE 'ACCOUNT_NM' 
                     END                        AS COL_NM
                   , LV_CD||'_NM'               AS DISP_NM
                   , V_SEQ+2*(SEQ)              AS SEQ
                   , 'Y'                        AS ACTV_YN
                   , P_USER_ID                  AS CREATE_BY
                   , SYSDATE                    AS CREATE_DTTM
                   , NULL                       AS MODIFY_BY
                   , NULL                       AS MODIFY_DTTM
             FROM TB_CM_LEVEL_MGMT
            WHERE 1=1
             AND ACCOUNT_LV_YN = 'Y'
             AND NVL(DEL_YN,'N') = 'N'
             AND ACTV_YN = 'Y'
             AND LV_TP_ID = P_SALES_LV_TP_ID
             ORDER BY SEQ
             ;     

    -------------------------------------------------------------------------------------------------------------------------
            P_RT_ROLLBACK_FLAG := 'true';
            P_RT_MSG := 'MSG_0001';


EXCEPTION WHEN OTHERS THEN  -- e_products_invalid    
    IF(SQLCODE = -20001)
    THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
    ELSE
    --SP_COMM_RAISE_ERR();
        RAISE;
    END IF;    
END;
/

