create PROCEDURE                "SP_UI_DP_22_Q1" (     
    p_MODULE_ID     IN  VARCHAR2 := ''
  , P_PLAN_TP_ID    IN  VARCHAR2 := ''
  , pRESULT         OUT SYS_REFCURSOR
) IS 

BEGIN

    OPEN pRESULT          
    FOR 
    SELECT CB.ID
         , 'DP' AS MODULE_ID
         , CB.WORK_CD
         , CB.WORK_NM
         , CB.SEQ
         , CB.DESCRIP
         , CB.WORK_TP_ID 
         , CB.LINK
         , CB.LV_MGMT_ID AS LV_MGMT_ID
         , CB.INIT_VAL_TP_ID AS INIT_VAL_TP_ID
         --, CASE WHEN RTRIM(CB.INIT_FIXED_LV_MGMT_ID) = 'N' THEN  CD.COMN_CD  ELSE CB.INIT_FIXED_LV_MGMT_ID END AS INIT_FIXED_LV_MGMT_ID
         , CASE WHEN CB.INIT_FIXED_LV_MGMT_ID IS NULL AND CB.INIT_MEASURE_ID IS NOT NULL THEN CB.INIT_MEASURE_ID
                WHEN CB.INIT_FIXED_LV_MGMT_ID IS NOT NULL AND CB.INIT_MEASURE_ID IS NULL THEN CB.INIT_FIXED_LV_MGMT_ID
           ELSE NULL END AS INIT_FIXED_LV_MGMT_ID
         , CB.INPUT_TP_ID
         , C.CONF_CD as INIT_VAL_TP_CD
         --, CB.INIT_INPUT_STRT_VAL
         --, CB.INIT_INPUT_END_VAL
         , CB.CONST_INPUT_YN
         , CB.INIT_CONST_INPUT_VAL
         , CB.INIT_CONST_INPUT_TIME_VAL   -- 
         , CB.APPV_CONST_ID AS APPV_CONST_ID
         , CB.APPV_EVENT_ID AS APPV_EVENT_ID
         , CB.AUTO_APPV_YN
         , CB.INIT_AUTO_APPV_VAL
         , CB.INIT_AUTO_APPV_TIME_VAL
         , CB.CANC_CONST_ID
         , CB.CANC_EVENT_ID
         , CB.CL_TP_ID
         , CB.CL_LV_MGMT_ID AS CL_LV_MGMT_ID
         , CB.CREATE_BY
         , CB.CREATE_DTTM
         , CB.MODIFY_BY
         , CB.MODIFY_DTTM
         , CASE WHEN CB.WORK_TP_ID = ( 
              SELECT B.ID AS ID
                FROM TB_CM_CONFIGURATION A 
               INNER JOIN TB_CM_COMM_CONFIG B  ON A.ID = B.CONF_ID 
               WHERE A.MODULE_CD = 'DP'
                 AND B.ACTV_YN = 'Y'
                 AND B.CONF_GRP_CD = 'DP_WK_TP' and B.CONF_CD = 'DP'
           ) THEN 'Y'
           ELSE 'N' END AS WK_TP_DP_YN
      FROM TB_DP_CONTROL_BOARD_MST CB
      left outer join TB_CM_COMM_CONFIG c on c.id =  CB.INIT_VAL_TP_ID
     WHERE 1=1
       AND COALESCE(CB.DEL_YN,'N')     = 'N' --CB.MODULE_ID LIKE  '%' || p_MODULE_ID || '%'
       AND CB.PLAN_TP_ID = p_PLAN_TP_ID
     ORDER BY CB.MODULE_ID, CB.SEQ
    ;
END;
/

