create PROCEDURE SP_UI_CM_07_POP_Q3 (
    P_ACCOUNT_ID IN CHAR :='',
    pResult OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN pResult FOR
    SELECT     ACC.ACCOUNT_CD
             , ACC.ACCOUNT_NM
             , CUS1.CUST_NM			AS SHIP_TO_ID
             , CUS2.CUST_NM			AS SOLD_TO_ID
             , CUS3.CUST_NM			AS BILL_TO_ID
             , CTP.CHANNEL_NM		AS CHANNEL_TP
             , ICT.INCOTERMS		
          FROM TB_DP_ACCOUNT_MST ACC 
                LEFT OUTER JOIN TB_CM_CUSTOMER CUS1 
                    ON ACC.SHIP_TO_ID = CUS1.ID
                LEFT OUTER JOIN TB_CM_CUSTOMER CUS2 
                    ON ACC.SOLD_TO_ID = CUS2.ID
                LEFT OUTER JOIN TB_CM_CUSTOMER CUS3 
                    ON ACC.BILL_TO_ID = CUS3.ID
                LEFT OUTER JOIN TB_CM_CHANNEL_TYPE CTP 
                    ON ACC.CHANNEL_ID = CTP.ID
                LEFT OUTER JOIN TB_CM_INCOTERMS ICT
                    ON ACC.INCOTERMS_ID = ICT.ID
         WHERE ACC.ID = P_ACCOUNT_ID;
END;

/

