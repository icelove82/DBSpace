create PROCEDURE        "SP_UI_DP_23_TAB_S2" (
											 p_ID					IN VARCHAR2	:= ''  
											,p_SALES_LV_ID			IN VARCHAR2	:= ''  
											--,p_INPUT_STRT_DATE	IN 	DATE			= ''
											--,p_INPUT_END_DATE		IN DATE			= ''	
											,p_CONST_INPUT_YN       IN CHAR		:= ''  	
											,p_CONST_INPUT_DATE     IN DATE    :=NULL	
											,p_APPV_EVENT_ID		IN VARCHAR2	:= ''  		
											,p_AUTO_APPV_YN			IN CHAR			:= ''
											,p_AUTO_APPV_DATE		IN DATE			:= NULL
											,p_CANC_EVENT_ID		IN VARCHAR2	:= ''  	 
											,p_USER_ID				IN VARCHAR2   := ''      
	  										) 
IS 
/*********************************************************************
*********************************************************************/ 
BEGIN 


	UPDATE  TB_DP_CONTROL_BOARD_VER_DTL 
	SET		-- INPUT_STRT_DATE	= p_INPUT_STRT_DATE	
			--,INPUT_END_DATE		= p_INPUT_END_DATE	
			 CONST_INPUT_YN		= p_CONST_INPUT_YN				--CASE WHEN p_AUTO_APPV_YN = 'True' THEN 'Y' ELSE 'N' END 	
			,CONST_INPUT_DATE	= p_CONST_INPUT_DATE		
			,APPV_EVENT_ID		= p_APPV_EVENT_ID		
			,AUTO_APPV_YN		= p_AUTO_APPV_YN				--CASE WHEN p_AUTO_APPV_YN = 'True' THEN 'Y' ELSE 'N' END 	
			,AUTO_APPV_DATE		= p_AUTO_APPV_DATE		
			,CANC_EVENT_ID		= p_CANC_EVENT_ID		
			,MODIFY_BY			= p_USER_ID			 
			,MODIFY_DTTM		= SYSDATE()	
	WHERE	ID					= p_ID;

 END;
/

