create PROCEDURE                "SP_UI_DP_00_USER_SALES_LV_Q1" (
    p_EMP_NO        VARCHAR2    := NULL	
  , p_AUTH_TP_ID    CHAR        := NULL 
  , p_LEAF_YN       IN CHAR     := ''
  , p_TYPE          IN VARCHAR2 := ''
  , P_SRP_LV_YN     IN CHAR     := '' -- SALES LV COMBOBOX
  , pRESULT         OUT SYS_REFCURSOR
) IS 

/*
    작성자 : 김소희
    작성일 : 2019.05.20
    프로시저 오류를 막기위한 기본 기능만 우선 컨버팅    
*/

    P_EMP_ID    CHAR(32);
    P_CNT       INT;
BEGIN
    IF P_EMP_NO IS NULL
    THEN
        P_EMP_ID := NULL;
    ELSE
        SELECT ID INTO P_EMP_ID
          FROM TB_AD_USER
         WHERE USERNAME = P_EMP_NO;
     
        SELECT COUNT(EMP_ID)
          INTO P_CNT
          FROM TB_DP_USER_ACCOUNT_MAP
         WHERE EMP_ID = P_EMP_ID
           AND AUTH_TP_ID = P_AUTH_TP_ID;
       
        SELECT P_CNT + COUNT(EMP_ID)
          INTO P_CNT
          FROM TB_DP_USER_ITEM_ACCOUNT_MAP
         WHERE EMP_ID = P_EMP_ID
           AND AUTH_TP_ID = P_AUTH_TP_ID;
       
        IF P_CNT = 0 THEN
            P_EMP_ID := NULL;
        END IF;
    END IF;
    
    IF (P_EMP_ID IS NULL OR P_AUTH_TP_ID IS NULL) THEN
        OPEN pRESULT
        FOR 
    	SELECT SL.ID
    		  ,SL.SALES_LV_CD
    		  ,SL.SALES_LV_NM
    		  ,SL.LV_MGMT_ID
    		  ,SL.PARENT_SALES_LV_ID
    		  ,SL2.SALES_LV_CD  AS PARENT_SALES_LV_CD
    		  ,SL2.SALES_LV_NM  AS PARENT_SALES_LV_NM  
    		  ,SL.CURCY_CD_ID
    		  ,SL.SEQ
    		  ,SL.VIRTUAL_YN
    		  ,SL.ACTV_YN
    		  ,SL.DEL_YN
    		  ,SL.SRP_YN
    		  ,SL.CREATE_BY
    		  ,SL.CREATE_DTTM
    		  ,SL.MODIFY_BY
    		  ,SL.MODIFY_DTTM	  
    	  FROM TB_CM_CONFIGURATION A
    		 , TB_CM_COMM_CONFIG B
    		 , TB_CM_LEVEL_MGMT  LM
    		 , TB_DP_SALES_LEVEL_MGMT SL 
    	  LEFT OUTER JOIN TB_DP_SALES_LEVEL_MGMT SL2 
    	    ON SL.PARENT_SALES_LV_ID = SL2.ID
    	   AND NVL(SL2.DEL_YN,'N') = 'N'
    	   AND SL2.ACTV_YN = 'Y'
         WHERE A.MODULE_CD = 'DP'
           AND A.ID = B.CONF_ID
           AND B.CONF_GRP_CD = 'DP_LV_TP'
           AND B.CONF_CD = 'S'
           AND B.ID = LM.LV_TP_ID  -- S/C/I
           AND NVL(LM.DEL_YN,'N') = 'N'
           AND LM.ACTV_YN = 'Y'
           AND LM.ID = SL.LV_MGMT_ID 
           AND (LM.SRP_LV_YN LIKE '%' || P_SRP_LV_YN ||'%'	OR P_SRP_LV_YN IS NULL)
           AND SL.ACTV_YN = 'Y'
         ORDER BY LM.SEQ, SL.SEQ
    	;
    ELSE
        OPEN pRESULT
        FOR
        SELECT NULL AS ID
             , 'ALL' AS SALES_LV_NM
             , 'ALL' AS SALES_LV_CD
          FROM DUAL
         WHERE P_TYPE = 'ALL'
        UNION
        SELECT IL.ID
             , IL.SALES_LV_NM
             , IL.SALES_LV_CD
          FROM TABLE(FN_DP_TEMP_FIND_ACCOUNT(P_EMP_ID, P_AUTH_TP_ID, NULL)) FI
         INNER JOIN TB_DP_SALES_LEVEL_MGMT IL
            ON IL.ID = FI.PARENT_SALES_LV_ID
         GROUP BY IL.ID, SALES_LV_CD, SALES_LV_NM
        ;
    END IF;
END;
/

