create PROCEDURE        "SP_UI_CM_01_POP_47_S" (
	 P_ID                       IN VARCHAR2 := ''
    ,P_WAREHOUSE_TP_NM	        IN VARCHAR2 := ''
    ,P_LOAD_CAPA_MGMT_BASE	    IN VARCHAR2 := ''
    ,P_ACTV_YN                  IN VARCHAR2 := ''
    ,P_USER_ID	                IN VARCHAR2 := ''
    ,P_WRK_TYPE	                IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG         OUT VARCHAR2 
    ,P_RT_MSG                   OUT VARCHAR2
    
)
IS

    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';
    NUMB VARCHAR2(3) := '';
    P_WAREHOUSE_TP VARCHAR2(50) := '';
    P_CONF_ID VARCHAR2(32) := '';

BEGIN
	IF P_WRK_TYPE = 'SAVE'
		THEN
		    SELECT ID INTO P_CONF_ID FROM TB_CM_CONFIGURATION WHERE CONF_KEY = '047';
		    SELECT CONCAT('WH_',LPAD(TO_CHAR(TO_NUMBER(NVL(MAX(SUBSTR(WAREHOUSE_TP,-2)),'0'))+1),2,'0')) INTO P_WAREHOUSE_TP FROM TB_CM_WAREHOUSE_TYPE;

        	P_ERR_MSG := 'MSG_0006';
            
        	IF NVL(P_WAREHOUSE_TP_NM,' ') ='' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;
		    MERGE INTO TB_CM_WAREHOUSE_TYPE B 
			USING (SELECT P_ID AS ID FROM DUAL) A
			ON    (B.ID = A.ID)
			WHEN MATCHED THEN
				UPDATE 
				   SET ACTV_YN				= P_ACTV_YN
                    	 , WAREHOUSE_TP_NM		= P_WAREHOUSE_TP_NM
                		 , LOAD_CAPA_MGMT_BASE	= P_LOAD_CAPA_MGMT_BASE
                    	 , MODIFY_BY			= P_USER_ID
                		 , MODIFY_DTTM			= SYSDATE
			WHEN NOT MATCHED THEN
			INSERT (
				ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
                    , LOAD_CAPA_MGMT_BASE
                    , WAREHOUSE_TP_NM
                    , WAREHOUSE_TP
                    , CONF_ID
                    , ACTV_YN
				)
			VALUES 
		  	    (
				TO_SINGLE_BYTE(SYS_GUID()), P_USER_ID, SYSDATE, P_USER_ID, SYSDATE
				, P_LOAD_CAPA_MGMT_BASE
				, P_WAREHOUSE_TP_NM
				, P_WAREHOUSE_TP
				, P_CONF_ID
				, P_ACTV_YN
			);

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';

	ELSIF P_WRK_TYPE = 'DELETE'
		THEN

    		DELETE FROM TB_CM_WAREHOUSE_TYPE
				   WHERE ID = P_ID;

	        P_RT_ROLLBACK_FLAG := 'true';
    	    P_RT_MSG := 'MSG_0002';
	END IF;

EXCEPTION
        WHEN OTHERS THEN
            IF(SQLCODE = -20012)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
              RAISE;
              END IF; 

END;

/

