create PROCEDURE                "SP_UI_DP_13_Q2" (
    p_EMP_CD        IN VARCHAR2 := ''
  , p_AUTH_TP_ID    IN VARCHAR2 := ''
  , pRESULT         OUT SYS_REFCURSOR 
)
IS
/*************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID
    - 2020.03.12 / Kim sohee / MSSQL Converting     
************************************************************************/
BEGIN
    OPEN pRESULT
    FOR 
    SELECT UI.ID
         , UI.AUTH_TP_ID 
         , LM2.LV_CD AS  AUTH_TYPE
         , LM2.LV_NM AS  AUTH_TYPE_NM
         , UI.EMP_ID
         , DE.USERNAME AS USER_ID
         , DE.USERNAME AS EMP_NO
         , DE.DISPLAY_NAME AS EMP_NM
         , UI.LV_MGMT_ID
         , LM.LV_CD
         , LM.LV_NM
         , COALESCE(UI.ITEM_LV_ID ,UI.ITEM_MST_ID) AS ITEM_ID
         , COALESCE(IL.ITEM_LV_CD ,IM.ITEM_CD) AS ITEM_CD
         , COALESCE(IL.ITEM_LV_NM, CAST(IM.ITEM_NM AS VARCHAR2(255))) AS ITEM_NM
         , CASE WHEN IM.ID IS NULL THEN (CASE WHEN IL.DEL_YN = 'Y' OR COALESCE(IL.ACTV_YN, 'N')   = 'N' THEN 'N' ELSE 'Y' END)
                WHEN IL.ID IS NULL THEN (CASE WHEN IM.DEL_YN = 'Y' OR COALESCE(IM.DP_PLAN_YN,'N') = 'N' THEN 'N' ELSE 'Y' END)
           END          AS DP_PLAN_YN
         , UI.ACTV_YN
         , UI.CREATE_BY
         , UI.CREATE_DTTM
         , UI.MODIFY_BY
         , UI.MODIFY_DTTM
      FROM TB_CM_COMM_CONFIG B
         , TB_CM_LEVEL_MGMT LM
         , TB_CM_COMM_CONFIG B2
         , TB_CM_LEVEL_MGMT LM2
         , TB_DP_USER_ITEM_MAP UI
           LEFT OUTER JOIN TB_CM_ITEM_LEVEL_MGMT IL ON UI.ITEM_LV_ID = IL.ID
           LEFT OUTER JOIN TB_CM_ITEM_MST IM ON UI.ITEM_MST_ID = IM.ID
         , TB_AD_USER DE
     WHERE B.CONF_GRP_CD = 'DP_LV_TP'
       AND B.CONF_CD = 'I'
       AND B.ACTV_YN = 'Y'
       AND B.ID = LM.LV_TP_ID
       AND COALESCE(LM.DEL_YN, 'N') = 'N'
       AND LM.ID = UI.LV_MGMT_ID
       AND B2.CONF_GRP_CD = 'DP_LV_TP'
       AND B2.CONF_CD = 'S'
       AND B2.ACTV_YN = 'Y'
       AND B2.ID = LM2.LV_TP_ID
       AND COALESCE(LM2.DEL_YN,'N') = 'N'
       AND LM2.ID = UI.AUTH_TP_ID -- Auth Type
       AND UI.EMP_ID = DE.ID
       AND DE.USERNAME = p_EMP_CD   --'admin'
       AND UI.AUTH_TP_ID = p_AUTH_TP_ID
     ORDER BY LM.SEQ, IL.SEQ, IM.ITEM_CD
    ;
END
;
/

