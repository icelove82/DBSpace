create PROCEDURE                "SP_UI_DP_18_Q1" 
(
    P_GRP_ID IN VARCHAR2  := ''
  , P_UI_ID IN VARCHAR2 := ''
  , P_GRID_ID IN VARCHAR2  := ''
  , pRESULT OUT SYS_REFCURSOR
) IS
BEGIN
/*****************************************************************************
Title : SP_UI_DP_18_Q1
 
설명 
 - DP Dimension Set Management 조회
 
History (수정일자 / 수정자 / 수정내용)
- 2022.01.04 / kim sohee / level ltype 
*****************************************************************************/
    OPEN pRESULT
    FOR
WITH CUSTOM_DMND
AS (
	SELECT ID, CONF_NM 
	  FROM TB_CM_CONFIGURATION		  
	 WHERE CONF_NM = 'DP_DMND_CUSTOM'
), LV
AS (
	SELECT LV.ID
		 , LV_TP_ID
		 , C.CONF_CD AS LV_TP_CD 
	 FROM TB_CM_LEVEL_MGMT LV 
		  INNER JOIN
		  TB_CM_COMM_CONFIG C 
		ON C.ID = LV.LV_TP_ID
	UNION
	SELECT C.ID
		 , C.ID 
		 , C.CONF_NM
	  FROM CUSTOM_DMND C
--		   INNER JOIN 
--		   TB_CM_COMM_CONFIG L
--		ON L.CONF_GRP_CD = 'DP_LV_TP'
)    
    SELECT DI.ID
         , DI.UI_ID
         , DI.GRID_ID
         , DI.GRP_ID
         , DI.LV_MGMT_ID
         , DI.COL_NM
         , DI.DISP_NM
         , DI.DISP_NM   AS DISP_NM_VAL
         , DI.SEQ
         , DI.ACTV_YN
         , DI.CREATE_BY
         , DI.CREATE_DTTM
         , DI.MODIFY_BY
         , DI.MODIFY_DTTM
		, LV_TP_CD
		, LV_TP_ID       AS LV_TP_ID         
      FROM TB_DP_DIM_SETTING DI
            INNER JOIN
            LV
         ON LV.ID = DI.LV_MGMT_ID      
     WHERE GRP_ID = P_GRP_ID
       AND UI_ID    = p_UI_ID
       AND GRID_ID  = p_GRID_ID
     ORDER BY DI.SEQ
      ;
END ;
/

