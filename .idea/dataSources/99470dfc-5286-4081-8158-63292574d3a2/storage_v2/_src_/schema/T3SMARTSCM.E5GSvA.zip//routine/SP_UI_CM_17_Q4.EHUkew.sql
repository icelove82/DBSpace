create PROCEDURE        "SP_UI_CM_17_Q4" (
        P_SIMUL_VER_ID IN VARCHAR2 := '' ,
        pResult OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN pResult FOR 
      SELECT  E.ID
             ,E.STEP
             ,E.PROCESS_DESCRIP
             ,G.VER_ID AS PLAN_POLICY_VER_ID
             ,H.PLAN_POLICY_VAL_01 AS PLAN_POLICY_DESCRIP
      FROM TB_CM_CONBD_MAIN_VER_MST A 
              INNER JOIN 
              TB_CM_CONBD_MAIN_VER_DTL B 
           ON (A.ID = B.CONBD_MAIN_VER_MST_ID)
              INNER JOIN
              TB_CM_PLAN_SNRIO_MGMT_DTL C 
           ON (B.PLAN_SNRIO_MGMT_DTL_ID = C.ID)
              INNER JOIN 
              TB_CM_PLAN_SNRIO_MGMT_MST D 
           ON (C.PLAN_SNRIO_MGMT_MST_ID = D.ID)
              INNER JOIN
              TB_CM_PLAN_SNRIO_MGMT_DTL E 
           ON (D.ID = E.PLAN_SNRIO_MGMT_MST_ID)
              INNER JOIN 
              TB_AD_COMN_CODE F
           ON (E.PROCESS_TP_ID = F.ID )
              LEFT OUTER JOIN 
              TB_CM_PLAN_POLICY_MGMT G
           ON (E.PLAN_POLICY_MGMT_ID = G.ID)
              LEFT OUTER JOIN 
              (
               SELECT  X.PLAN_POLICY_MGMT_ID
                      ,X.PLAN_POLICY_VAL_01
                 FROM TB_CM_PLAN_POLICY_VALUE X
                      INNER JOIN 
                      TB_CM_PLAN_POLICY_MST Y
                   ON (
                           X.PLAN_POLICY_MST_ID = Y.ID 
                       AND Y.PLAN_POLICY_ITEM_ID = 'M00020000'
                      )
              ) H
           ON ( G.ID = H.PLAN_POLICY_MGMT_ID)
        WHERE 1=1
          AND B.SIMUL_VER_ID = P_SIMUL_VER_ID
          AND F.COMN_CD = 'SPROC_05';
END;

/

