create FUNCTION "FN_DP_TEMP_THREE_CAL" 
(
   V_STRT_DATE IN DATE
  ,V_END_DATE  IN DATE
)
RETURN DP_TEMP_CALENDAR IS
C_DP_TEMP_CALENDAR DP_TEMP_CALENDAR := DP_TEMP_CALENDAR();
-- YEAR
CURSOR C_DATA_IMPORT IS
    SELECT TP_DP_TEMP_CALENDAR(    -- TB_SRP_CNTRL_BOARD_VER_MST ？？？？？？？？ ？？？？？？？？？？？？, ？？？？？？？？ ？？？？？？？？？？？？
						  BUCKET_START_DATE      =>  BUCKET_START_DATE  
                              , BUCKET_END_DATE        =>  BUCKET_END_DATE
                     )
    FROM (

    SELECT DAT                                                           AS BUCKET_START_DATE             
               , NVL ((LEAD(DAT,1)  OVER ( ORDER BY YYYYMMDD)) -1,V_END_DATE)  AS BUCKET_END_DATE
            FROM TB_CM_CALENDAR
           WHERE 1=1
             AND DAT BETWEEN V_STRT_DATE AND V_END_DATE
             AND DD = 1
          UNION
          SELECT BUCKET_START_DATE 
               , BUCKET_END_DATE
            FROM (
               SELECT DAT AS BUCKET_START_DATE
                    , DECODE( MOD(row_number() over (ORDER BY DAT ASC),3),1,  NVL ((LEAD(DAT,3)  OVER ( ORDER BY YYYYMMDD)) -1, V_END_DATE)) AS BUCKET_END_DATE
                    , row_number() over (ORDER BY DAT ASC) AS A
                 FROM TB_CM_CALENDAR
                WHERE 1=1
                  AND DAT BETWEEN V_STRT_DATE AND V_END_DATE
                  AND DD = 1
             ORDER BY DAT ASC
           )
           WHERE BUCKET_END_DATE IS NOT NULL
             AND ABS(EXTRACT(MONTH FROM BUCKET_START_DATE) - EXTRACT(MONTH FROM BUCKET_END_DATE)) != 1
             AND ABS(EXTRACT(MONTH FROM BUCKET_START_DATE) - EXTRACT(MONTH FROM BUCKET_END_DATE)) != 11
           ORDER BY BUCKET_END_DATE ASC, BUCKET_START_DATE DESC
       ) A
       ;

BEGIN

        OPEN C_DATA_IMPORT;
        FETCH C_DATA_IMPORT BULK COLLECT INTO C_DP_TEMP_CALENDAR;
        CLOSE C_DATA_IMPORT;    
    RETURN C_DP_TEMP_CALENDAR;
END;

/

