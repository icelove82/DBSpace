create PROCEDURE "SP_UI_CM_11_POP_Q1" (
    P_BOD_TP_ID IN CHAR :='',
    P_LOC_DTL_ID    IN CHAR :='',
    P_ITEM_MST_ID   IN CHAR:='',
    pResult OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN pResult FOR
    SELECT A.ID							AS GLOBAL_PLAN_BOM_ID,
           A.CONSUME_LOCAT_ITEM_ID		AS CONSUME_LOCAT_ITEM_ID,
           A.SUPPLY_LOCAT_ITEM_ID		AS SUPPLY_LOCAT_ITEM_ID,
           P_ITEM_MST_ID				AS ITEM_MST_ID,
           A.SRCING_POLICY_ID	        AS SRCING_POLICY_ID,
           A.SRCING_RULE			    AS SRCING_RULE,
           A.ACTV_YN					AS ACTV_YN,
           A.FIXED_YN                   AS FIXED_YN,
           G.COMN_CD_NM					AS LOCAT_TP,
           F.LOCAT_LV					AS LOCAT_LV,
           E.LOCAT_CD					AS LOCAT_CD,
           E.LOCAT_NM					AS LOCAT_NM
        FROM		 TB_CM_GLOBAL_PLAN_BOM A
          INNER JOIN TB_CM_SITE_ITEM B
            ON ( A.CONSUME_LOCAT_ITEM_ID = B.ID )
          INNER JOIN TB_CM_SITE_ITEM C
            ON ( A.SUPPLY_LOCAT_ITEM_ID = C.ID )
          INNER JOIN TB_CM_LOC_MGMT D
            ON ( C.LOCAT_MGMT_ID = D.ID )
          INNER JOIN TB_CM_LOC_DTL E
            ON ( D.LOCAT_ID = E.ID )
          INNER JOIN TB_CM_LOC_MST F
            ON ( E.LOCAT_MST_ID = F.ID )
          INNER JOIN TB_AD_COMN_CODE G
            ON ( F.LOCAT_TP_ID = G.ID )
        WHERE 
                B.LOCAT_MGMT_ID = (SELECT B.ID FROM TB_CM_LOC_DTL A, TB_CM_LOC_MGMT B WHERE A.ID = B.LOCAT_ID 
                                        AND A.ID = P_LOC_DTL_ID)
            AND B.ITEM_MST_ID = P_ITEM_MST_ID
            AND A.ACTV_YN = 'Y';
END;

/

