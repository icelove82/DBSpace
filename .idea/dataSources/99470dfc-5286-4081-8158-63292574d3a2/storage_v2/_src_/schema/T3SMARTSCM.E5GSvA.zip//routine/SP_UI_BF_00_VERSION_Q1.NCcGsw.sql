create PROCEDURE                "SP_UI_BF_00_VERSION_Q1"(
    P_CLOSE_YN  CHAR
  , pRESULT OUT SYS_REFCURSOR 
) IS 
/*
	BF Version 조회 
*/
BEGIN
    OPEN pRESULT          
    FOR 
	SELECT M.VER_CD 
         , M.RW
         , RULE_01
	  FROM (
		SELECT VER_CD
			 , ROW_NUMBER() OVER (ORDER BY VM.VER_CD DESC)  RW
			 , RULE_01
		  FROM TB_BF_CONTROL_BOARD_VER_DTL VM
		 WHERE VM.PROCESS_NO IN (990, 990000)
		   AND CASE WHEN NVL(P_CLOSE_YN, 'Y') = 'Y' THEN STATUS ELSE 'Completed' END = 'Completed'
			) M
	 WHERE RW <= 5
    ;
END;
/

