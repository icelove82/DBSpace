create PROCEDURE SP_UI_DP_36_D1 (
					P_ID	            IN CHAR := ''
				   ,P_USER_ID	        IN NVARCHAR2 := ''
				   ,P_RT_ROLLBACK_FLAG  OUT NVARCHAR2   
				   ,P_RT_MSG            OUT NVARCHAR2 		
)
AS
        P_ERR_STATUS INT := 0;
        P_ERR_MSG VARCHAR2(4000):='';
        P_IF_STATUS INT := 0;
BEGIN 
/*********************************************************************************************************
		Policy CD : PB
*********************************************************************************************************/
    SELECT COUNT(C.CONF_CD) INTO P_IF_STATUS
			  FROM TB_DP_PLAN_POLICY P
				   INNER JOIN
				   TB_CM_COMM_CONFIG C 
				ON P.POLICY_ID = C.ID 
			 WHERE P.ID = P_ID 
			   AND CONF_CD = 'PB'
               ;
	IF  P_IF_STATUS > 0
        THEN
        	UPDATE TB_CM_COMM_CONFIG
        	  SET ATTR_01 = NULL
            WHERE CONF_GRP_CD = 'DP_BUKT_TP'
        	  AND CONF_CD = 'PB'
            ;
		END IF
		;
/*********************************************************************************************************
		PLAN POLICY 삭제 프로시저
*********************************************************************************************************/
	DELETE FROM TB_DP_PLAN_POLICY
	WHERE ID = P_ID;

	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0002';  

       /* ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN  -- e_products_invalid       
          P_ERR_MSG := SQLERRM; -- SYS.DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;   

END ;
/

