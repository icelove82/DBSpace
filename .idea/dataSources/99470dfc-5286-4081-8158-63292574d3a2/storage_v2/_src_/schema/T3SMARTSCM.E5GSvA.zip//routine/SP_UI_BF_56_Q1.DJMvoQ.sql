create PROCEDURE                "SP_UI_BF_56_Q1" (
    P_S_DATE            DATE
  , P_E_DATE            DATE
  , P_FACTOR_CD         VARCHAR2 := ''
  , P_FACTOR_DESCRIP    VARCHAR2 := ''
  , P_FACTOR_SET        VARCHAR2 := ''
  , pRESULT             OUT SYS_REFCURSOR
) IS

    QUERY VARCHAR2(32767) := '';

BEGIN
    -- DATE FACTOR STATISTICS
    
    FOR FCTR_INFO IN (
        SELECT COL_NM AS COL
             , FACTOR_CD AS FCTR
             , DESCRIP
          FROM TB_BF_FACTOR_MGMT
         WHERE COALESCE(DEL_YN, 'Y') = 'N'
           AND ACTV_YN = 'Y'
           AND COL_NM IN (
            SELECT COLUMN_NAME
              FROM ALL_TAB_COLS
             WHERE TABLE_NAME = 'TB_BF_DATE_FACTOR'
           )
           -- FACTOR_SET FILTER
           AND (
            (FACTOR_CD IN (
                SELECT FACTOR_CD
                  FROM TB_BF_FACTOR_SET
                 WHERE FACTOR_SET_CD = P_FACTOR_SET
                )
            ) OR P_FACTOR_SET IS NULL
           )
           -- FACTOR_CD FILTER (MULTI SEARCH)
           AND (REGEXP_LIKE(
                    UPPER(FACTOR_CD)
                  , REPLACE(REPLACE(REPLACE(REPLACE(
                        UPPER(P_FACTOR_CD)
                      , ')', '\)'), '(', '\('), ']', '\]'), '[', '\['
                    )
                )
             OR P_FACTOR_CD IS NULL
           )
           -- FACTOR_DESCRIP FILTER (MULTI SEARCH)
           AND (REGEXP_LIKE(
                    UPPER(DESCRIP)
                  , REPLACE(REPLACE(REPLACE(REPLACE(
                        UPPER(P_FACTOR_DESCRIP)
                      , ')', '\)'), '(', '\('), ']', '\]'), '[', '\['
                    )
                )
             OR P_FACTOR_DESCRIP IS NULL
           )
    )
    LOOP
    QUERY := QUERY || '
            SELECT ''' || FCTR_INFO.COL    || '''    AS "FACTOR_COL"
				 , ''' || FCTR_INFO.FCTR || '''    AS "FACTOR_CD"
                 , ''' || FCTR_INFO.DESCRIP || '''    AS "DESCRIP"
                 , COUNT(DF.' || FCTR_INFO.COL || ') AS "COUNT"
                 , AVG(DF.'   || FCTR_INFO.COL || ') AS "AVG"
                 , COALESCE(STDDEV(DF.' || FCTR_INFO.COL || '), 0) AS "STDEV"
                 , MIN(DF.'   || FCTR_INFO.COL || ') AS "MIN"
                 , MAX(DF.'   || FCTR_INFO.COL || ') AS "MAX"
                 , MAX(MD.'   || FCTR_INFO.COL || ') AS "MODE"
                 , COALESCE(STDDEV(DF.' || FCTR_INFO.COL || '), 0) / (CASE WHEN AVG(DF.' || FCTR_INFO.COL || ') = 0 THEN 1 ELSE AVG(DF.' || FCTR_INFO.COL || ') END) AS "COV"
              FROM TB_BF_DATE_FACTOR DF
                   INNER JOIN (
                    SELECT ' || FCTR_INFO.COL || '
                         , CNT
                      FROM (
                        SELECT ' || FCTR_INFO.COL || '
                             , COUNT(1) CNT
                             , ROW_NUMBER() OVER (ORDER BY COUNT(1) DESC) RID
                          FROM TB_BF_DATE_FACTOR
                         WHERE BASE_DATE BETWEEN ''' || P_S_DATE || ''' AND ''' || P_E_DATE || '''
						   AND ' || FCTR_INFO.COL || ' is not null
                         GROUP BY ' || FCTR_INFO.COL || '
                      ) MD
                     WHERE RID = 1
                   ) MD
                ON 1=1
             WHERE BASE_DATE BETWEEN ''' || P_S_DATE || ''' AND ''' || P_E_DATE || '''
            UNION
           ';
    END LOOP;
 

    -- SALES_FACTOR STATISTICS
    FOR FCTR_INFO IN (
        SELECT COL_NM AS COL
             , FACTOR_CD AS FCTR
             , DESCRIP
          FROM TB_BF_FACTOR_MGMT
         WHERE COALESCE(DEL_YN, 'Y') = 'N'
           AND ACTV_YN = 'Y'
           AND COL_NM IN (
            SELECT COLUMN_NAME
              FROM ALL_TAB_COLS
             WHERE TABLE_NAME = 'TB_BF_SALES_FACTOR'
           )
           -- FACTOR_SET FILTER
           AND (
            (FACTOR_CD IN (
                SELECT FACTOR_CD
                  FROM TB_BF_FACTOR_SET
                 WHERE FACTOR_SET_CD = P_FACTOR_SET
                )
            ) OR P_FACTOR_SET IS NULL
           )
           -- FACTOR_CD FILTER (MULTI SEARCH)
           AND (REGEXP_LIKE(
                    UPPER(FACTOR_CD)
                  , REPLACE(REPLACE(REPLACE(REPLACE(
                        UPPER(P_FACTOR_CD)
                      , ')', '\)'), '(', '\('), ']', '\]'), '[', '\['
                    )
                )
             OR P_FACTOR_CD IS NULL
           )
           -- FACTOR_DESCRIP FILTER (MULTI SEARCH)
           AND (REGEXP_LIKE(
                    UPPER(DESCRIP)
                  , REPLACE(REPLACE(REPLACE(REPLACE(
                        UPPER(P_FACTOR_DESCRIP)
                      , ')', '\)'), '(', '\('), ']', '\]'), '[', '\['
                    )
                )
             OR P_FACTOR_DESCRIP IS NULL
           )
    )
    LOOP
    QUERY := QUERY || '
            SELECT ''' || FCTR_INFO.COL    || '''    AS "FACTOR_COL"
				 , ''' || FCTR_INFO.FCTR || '''    AS "FACTOR_CD"
                 , ''' || FCTR_INFO.DESCRIP || '''    AS "DESCRIP"
                 , COUNT(DF.' || FCTR_INFO.COL || ') AS "COUNT"
                 , AVG(DF.'   || FCTR_INFO.COL || ') AS "AVG"
                 , COALESCE(STDDEV(DF.' || FCTR_INFO.COL || '), 0) AS "STDEV"
                 , MIN(DF.'   || FCTR_INFO.COL || ') AS "MIN"
                 , MAX(DF.'   || FCTR_INFO.COL || ') AS "MAX"
                 , MAX(MD.'   || FCTR_INFO.COL || ') AS "MODE"
                 , COALESCE(STDDEV(DF.' || FCTR_INFO.COL || '), 0) / (CASE WHEN AVG(DF.' || FCTR_INFO.COL || ') = 0 THEN 1 ELSE AVG(DF.' || FCTR_INFO.COL || ') END) AS "COV"
              FROM TB_BF_SALES_FACTOR DF
                   INNER JOIN (
                    SELECT ' || FCTR_INFO.COL || '
                         , CNT
                      FROM (
                        SELECT ' || FCTR_INFO.COL || '
                             , COUNT(1) CNT
                             , ROW_NUMBER() OVER (ORDER BY COUNT(1) DESC) RID
                          FROM TB_BF_SALES_FACTOR
                         WHERE BASE_DATE BETWEEN ''' || P_S_DATE || ''' AND ''' || P_E_DATE || '''
						   AND ' || FCTR_INFO.COL || ' is not null
                         GROUP BY ' || FCTR_INFO.COL || '
                      ) MD
                     WHERE RID = 1
                   ) MD
                ON 1=1
             WHERE BASE_DATE BETWEEN ''' || P_S_DATE || ''' AND ''' || P_E_DATE || '''
            UNION
           ';
    END LOOP;

    -- NULL LINE TO HANDLE FINAL UNION
     QUERY := QUERY || '
            SELECT NULL AS "FACTOR_COL"
				 , NULL AS "FACTOR_CD"                                  
                 , NULL AS "DESCRIP"                                                                        
                 , NULL AS "COUNT"                                          
                 , NULL AS "AVG"                                            
                 , NULL AS "STDEV"                                          
                 , NULL AS "MIN"                                            
                 , NULL AS "MAX"                                            
                 , NULL AS "MODE"                                       
                 , NULL AS "COV"
              FROM DUAL                                        
             WHERE 1=0                                                      
             ORDER BY FACTOR_CD
           ';

    -- RUN THE DYNAMIC QUERY
    OPEN pRESULT FOR QUERY;
END;
/

