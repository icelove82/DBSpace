create PROCEDURE                "SP_UI_DP_93_ITEM_ACCT_CREATE" (
      P_ITEM_MST_ID		CHAR 	-- Item Account User Map / Item Master 
	, P_ITEM_LV_ID		CHAR 	
	, P_ACCOUNT_ID		CHAR 	-- Item Account User Map / Account Master 
	, P_ACCT_LV_ID		CHAR 
	, P_USER_ID			CHAR  	-- Mapping data
	, P_AUTH_TP_ID		CHAR  
	, P_VER_ID			CHAR     
--    , pRESULT        OUT SYS_REFCURSOR
)
IS
/***********************************************************************************************************************************
	[ History ( Date / Writer / Comment ) ]
		- 2020.12.02 / kim sohee / draft
		- 2020.12.04 / kim sohee / insert => merge 
		- 2021.02.15 / kim sohee / case : init qty value is none, bug fix
		- 2021.07.29 / kim sohee / add a case : bucket	
        - 2021.11.__ / kim sohee / add USE_YN
************************************************************************************************************************************/
           P_FROM_DATE	    DATE ;
		   P_TO_DATE		DATE ;
		   P_SM_DATE		DATE ;
		   P_BUKT			VARCHAR2(100);
		   P_PLAN_TP_ID	    CHAR(32);
           P_PREV_VER_ID    CHAR(32);
           P_STR	        VARCHAR2(4000);
           P_STR2           VARCHAR2(4000);
		   P_VAL_CNT        INT ;
           P_VAL_CNT_02     INT;
           P_IF_CHECK       INT;

BEGIN
	/***********************************************************************************************************************************
		-- (1) USER		
	************************************************************************************************************************************/
	IF (P_USER_ID IS NULL AND P_ITEM_MST_ID IS NULL)	-- Account
		THEN
			INSERT INTO TEMP_DP_USER (EMP_ID, AUTH_TP_ID) 
			SELECT DISTINCT EMP_ID, AUTH_TP_ID  
			  FROM TB_DP_USER_ACCOUNT_MAP UA
				   INNER JOIN
				   TB_DPD_SALES_HIER_CLOSURE SH
				ON UA.SALES_LV_ID = SH.ANCESTER_ID AND SH.USE_YN ='Y' AND UA.ACTV_YN = 'Y'
			 WHERE SH.DESCENDANT_ID = P_ACCOUNT_ID
			UNION
			SELECT DISTINCT EMP_ID, AUTH_TP_ID 
			  FROM TB_DP_USER_ACCOUNT_MAP
			 WHERE ACCOUNT_ID = P_ACCOUNT_ID AND ACTV_YN = 'Y'
			UNION
			SELECT DISTINCT EMP_ID, AUTH_TP_ID 
			  FROM TB_DP_USER_ITEM_ACCOUNT_MAP
			 WHERE ACCOUNT_ID = P_ACCOUNT_ID AND ACTV_YN = 'Y'
             ;
	ELSIF (P_USER_ID IS NULL AND p_ACCOUNT_ID IS NULL) -- Item
		THEN
			INSERT  INTO TEMP_DP_USER (EMP_ID, AUTH_TP_ID)
			SELECT DISTINCT EMP_ID, AUTH_TP_ID   
			  FROM TB_DP_USER_ITEM_MAP UA
				   INNER JOIN
				   TB_DPD_ITEM_HIER_CLOSURE SH
				ON UA.ITEM_LV_ID = SH.ANCESTER_ID AND SH.USE_YN = 'Y' AND UA.ACTV_YN = 'Y'
			 WHERE SH.DESCENDANT_ID = P_ITEM_MST_ID
			UNION
			SELECT DISTINCT EMP_ID, AUTH_TP_ID   
			  FROM TB_DP_USER_ITEM_MAP
			 WHERE ITEM_MST_ID = P_ITEM_MST_ID
			UNION
			SELECT DISTINCT EMP_ID, AUTH_TP_ID  
			  FROM TB_DP_USER_ITEM_ACCOUNT_MAP
			 WHERE ITEM_MST_ID = P_ITEM_MST_ID		
             ;
        ELSE -- P_USER_ID IS NOT NULL	-- Mapping
			INSERT INTO TEMP_DP_USER (EMP_ID, AUTH_TP_ID) 
			SELECT P_USER_ID, P_AUTH_TP_ID 
              FROM DUAL 
            ;
		END IF
        ;

--		SELECT * FROM TEMP_DP_USER; 
	/***********************************************************************************************************************************
		-- (2) Item		
	************************************************************************************************************************************/
	-- Item Master ID or Account ID가 Null이면, DPD 테이블에서 item level ID와 Account Level ID데이터로 DESC ID 찾아주기.
	IF (P_ITEM_MST_ID IS NULL AND P_ITEM_LV_ID IS NULL)
		THEN
			-- Account mapping by user
            INSERT INTO TEMP_DP_ITEM (ITEM_MST_ID, EMP_ID, AUTH_TP_ID)
			WITH ITEM
			  AS (
					SELECT CASE LV.LEAF_YN WHEN 'Y' THEN ITEM_MST_ID ELSE ITEM_LV_ID END AS ITEM_ID 
						  ,US.EMP_ID
						  ,US.AUTH_TP_ID
					  FROM TB_DP_USER_ITEM_MAP IM   
						   INNER JOIN 
						   TEMP_DP_USER US
						ON IM.AUTH_TP_ID = US.AUTH_TP_ID
					   AND IM.EMP_ID = US.EMP_ID
						   INNER JOIN 
						   TB_CM_LEVEL_MGMT LV 					   		   
						ON IM.LV_MGMT_ID = LV.ID
			     )
					SELECT IH.DESCENDANT_ID
						  ,IT.EMP_ID
						  ,IT.AUTH_TP_ID
					  FROM ITEM IT
					       INNER JOIN 
						   TB_DPD_ITEM_HIER_CLOSURE IH
						ON IT.ITEM_ID = IH.ANCESTER_ID
					   AND IH.LEAF_YN = 'Y'  AND IH.USE_YN ='Y'
                       ;
	ELSIF (P_ITEM_MST_ID IS NULL AND P_ITEM_LV_ID IS NOT NULL)	-- Item Level mapping by user
		THEN
			-- INSERT  leaf Item ID temp table
			INSERT  INTO TEMP_DP_ITEM (ITEM_MST_ID, EMP_ID, AUTH_TP_ID)
			SELECT DESCENDANT_ID
				 , P_USER_ID
				 , P_AUTH_TP_ID
			  FROM TB_DPD_ITEM_HIER_CLOSURE
			 WHERE ANCESTER_ID = P_ITEM_LV_ID
			   AND LEAF_YN = 'Y' AND USE_YN ='Y'
            ;
	ELSIF (P_ITEM_MST_ID IS NOT NULL AND P_ITEM_LV_ID IS NULL)
        THEN
			-- item master or item mapping by user 
			INSERT  INTO TEMP_DP_ITEM (ITEM_MST_ID, EMP_ID, AUTH_TP_ID)
 			SELECT P_ITEM_MST_ID 			  		
				  ,EMP_ID
				  ,AUTH_TP_ID 
			  FROM TEMP_DP_USER
              ;
		END IF
        ;
--		SELECT * FROM TEMP_DP_ITEM;
	/***********************************************************************************************************************************
	-- (3) Account		
	************************************************************************************************************************************/
	IF (P_ACCOUNT_ID IS NULL AND P_ACCT_LV_ID IS NULL)
		THEN
			-- When User Item map, find account info by user ID
            INSERT  INTO TEMP_DP_ACCT (ACCOUNT_ID, EMP_ID, AUTH_TP_ID) 
			WITH ACCT
			  AS ( SELECT CASE LV.LEAF_YN WHEN 'Y' THEN ACCOUNT_ID ELSE SALES_LV_ID END AS ACCOUNT_ID 
						 , US.EMP_ID
						 , US.AUTH_TP_ID
					  FROM TB_DP_USER_ACCOUNT_MAP AM 
						   INNER JOIN
						   TEMP_DP_USER US
						ON AM.AUTH_TP_ID = US.AUTH_TP_ID
					   AND AM.EMP_ID = US.EMP_ID
						   INNER JOIN 
						   TB_CM_LEVEL_MGMT LV 					   		   
						ON AM.LV_MGMT_ID = LV.ID
			  )
				SELECT SH.DESCENDANT_ID
					 , AC.EMP_ID
					 , AC.AUTH_TP_ID
				  FROM ACCT AC
					   INNER JOIN
					   TB_DPD_SALES_HIER_CLOSURE SH
					ON AC.ACCOUNT_ID = SH.ANCESTER_ID
				   AND SH.LEAF_YN = 'Y'			
                   ;
	ELSIF (p_ACCOUNT_ID IS NULL AND P_ACCT_LV_ID IS NOT NULL)
		THEN
			-- INSERT  leaf Account ID temp table
			INSERT  INTO TEMP_DP_ACCT (ACCOUNT_ID, EMP_ID, AUTH_TP_ID) 
			SELECT DESCENDANT_ID
				  ,P_USER_ID
				  ,P_AUTH_TP_ID
			  FROM TB_DPD_SALES_HIER_CLOSURE
			 WHERE ANCESTER_ID = P_ACCT_LV_ID
			   AND LEAF_YN = 'Y' 
               ;
	ELSIF (P_ACCOUNT_ID IS NOT NULL AND P_ACCT_LV_ID IS NULL)
		THEN
			INSERT INTO TEMP_DP_ACCT (ACCOUNT_ID, EMP_ID, AUTH_TP_ID) 
			SELECT P_ACCOUNT_ID
				  ,EMP_ID
				  ,AUTH_TP_ID 
			  FROM TEMP_DP_USER
              ;
		END IF
        ;
		--SELECT * FROM TEMP_DP_ACCT ;
	/***********************************************************************************************************************************
	-- (4) Item & Account	
	************************************************************************************************************************************/
	 SELECT   FROM_DATE	
			, TO_DATE	
			, BUKT 	
			, PLAN_TP_ID 
        INTO P_FROM_DATE, P_TO_DATE, P_BUKT, P_PLAN_TP_ID
	   FROM TB_DP_CONTROL_BOARD_VER_MST 
	 WHERE ID = P_VER_ID
	   ;

	INSERT  INTO TEMP_DP_ITEM_ACCT_CAL 
		  (ITEM_MST_ID
		 , ACCOUNT_ID         
		 , AUTH_TP_ID
         , EMP_ID
		 , BASE_DATE
		 ) 
  WITH CAL
	AS (
		SELECT MIN(DAT)	AS STRT_DT
			 , MAX(DAT) AS END_DT
		  FROM TB_CM_CALENDAR CAL
		WHERE DAT BETWEEN P_FROM_DATE AND P_TO_DATE  
	  GROUP BY CASE P_BUKT
						WHEN 'Y' THEN YYYY
						WHEN 'Q' THEN YYYY||'-'||TO_CHAR(QTR)
						WHEN 'M' THEN YYYYMM
						WHEN 'PW' THEN MM||'-'||DP_WK
						WHEN 'W' THEN DP_WK
					ELSE YYYYMMDD END    	
		), IA
	AS (
		SELECT IT.ITEM_MST_ID
			  ,AC.ACCOUNT_ID 
              ,AC.EMP_ID
		  FROM TEMP_DP_ITEM IT 
			   INNER JOIN
			   TEMP_DP_ACCT AC
			ON IT.EMP_ID = AC.EMP_ID
		   AND IT.AUTH_TP_ID = AC.AUTH_TP_ID
		MINUS 
		SELECT ITEM_MST_ID
			 , ACCOUNT_ID
             , EX.EMP_ID
		  FROM TB_DP_USER_ITEM_ACCOUNT_EXCLUD EX
			   INNER JOIN
			   TEMP_DP_USER US
			ON EX.EMP_ID = US.EMP_ID
		   AND EX.AUTH_TP_ID = US.AUTH_TP_ID	  
	), SALES_LV
AS (
	SELECT DISTINCT LV_MGMT_ID
	  FROM TB_DP_CONTROL_BOARD_VER_DTL
	 WHERE CONBD_VER_MST_ID = p_VER_ID 
	   AND LV_MGMT_ID IS NOT NULL 
   )
	SELECT ITEM_MST_ID
		  ,ACCOUNT_ID
		  ,LV_MGMT_ID
          ,EMP_ID
		  ,STRT_DT 
	  FROM IA 	
		   CROSS JOIN
		   CAL 
		   CROSS JOIN
		   SALES_LV 
		   ;

/************************************************************************************************************
	-- 2. Get Version Config
************************************************************************************************************/
	--------------- 1. Get Versison Detail Info (Initial value type by authority type)

    SELECT COUNT(CONBD_VER_MST_ID) INTO P_IF_CHECK
	  FROM TB_DP_CONTROL_BOARD_VER_DTL D  
	 WHERE CONBD_VER_MST_ID != P_VER_ID 
	   AND PLAN_TP_ID = P_PLAN_TP_ID 
	   AND D.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_cD = 'DP_WK_TP' AND CONF_CD = 'CL')
	   AND D.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
    ;
IF (P_IF_CHECK > 0)
    THEN
        SELECT CONBD_VER_MST_ID  INTO P_PREV_VER_ID
          FROM (
            SELECT CONBD_VER_MST_ID  
                 , ROW_NUMBER () OVER (ORDER BY  CREATE_DTTM DESC) AS RW 
              FROM TB_DP_CONTROL_BOARD_VER_DTL D  
             WHERE CONBD_VER_MST_ID != P_VER_ID 
               AND PLAN_TP_ID = P_PLAN_TP_ID 
               AND D.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_cD = 'DP_WK_TP' AND CONF_CD = 'CL')
               AND D.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
                ) A
        WHERE RW = 1         
          ; 
    END IF
    ;

/************************************************************************************************************
	-- 3. Get Initial Value
************************************************************************************************************/
--	SELECT *
--	  FROM TABLE(FN_DP_TEMP_VER_INFO_DTL(P_VER_ID))
	--------------- 2. Create and INSERT  Result Temporary Table

	BEGIN 
             SELECT DISTINCT COUNT(INIT_VAL_TP_CD) 
                    INTO P_VAL_CNT
               FROM TABLE(FN_DP_TEMP_VER_INFO_INIT(P_VER_ID))  
               WHERE INIT_VAL_TP_CD = 'PR' 
               ;	
--			  , P_LOOP_IDX	INT = 1

        SELECT COUNT(1) INTO P_VAL_CNT 
         FROM TABLE(FN_DP_TEMP_VER_INFO_DTL(P_VER_ID))
        WHERE INIT_TP_CD = 'PR'
         ;
        SELECT COUNT(1) INTO P_VAL_CNT_02
         FROM TABLE(FN_DP_TEMP_VER_INFO_INIT(P_VER_ID)) 
        WHERE INIT_VAL_TP_CD = 'PR'
        ;
		IF (P_VAL_CNT > 0 OR P_VAL_CNT_02 > 0)
			THEN					
                P_STR :=
				 'INSERT INTO TEMP_DP_RT  ( ITEM_MST_ID,ACCOUNT_ID,BASE_DATE,QTY,AUTH_TP_ID'
                ;
                IF (P_VAL_CNT_02 > 0)
                    THEN
                         SELECT NVL(','||LISTAGG(INIT_MS_VAL_TP_CD,',') WITHIN GROUP(ORDER BY INIT_MS_VAL_TP_CD) ,'')
                                INTO P_STR2
                          FROM ( SELECT DISTINCT INIT_MS_VAL_TP_CD 
                                   FROM TABLE(FN_DP_TEMP_VER_INFO_INIT(P_VER_ID))		
                                  WHERE INIT_VAL_TP_CD = 'PR' 	
                                ) A			
                                ;
                    END IF;
                P_STR := P_STR||P_STR2
                ||') '                     
				||'WITH INI_PR '
				||  'AS ( '
				||	'SELECT DTL_ID '
				||		 ', INIT_FIXED_LV_MGMT_ID '
				||		 ', INIT_MS_VAL_TP_CD '
				||	  'FROM TABLE(FN_DP_TEMP_VER_INFO_INIT('''||P_VER_ID||''')) '
				||	 'WHERE INIT_VAL_TP_CD = ''PR'' '
				||  ')'          				
				||'SELECT M.ITEM_MST_ID '
				||	  ', M.ACCOUNT_ID'
				||	  ', M.BASE_DATE  '
				||	CASE WHEN P_VAL_CNT > 0 THEN  ', DE.QTY ' ELSE ', 0' END
				||	  ', VE.AUTH_TP_ID '
                ;           
            IF (P_VAL_CNT_02 > 0)
                THEN                
                        SELECT NVL(', '||LISTAGG('DE'||TO_CHAR(IDX)||'.'||INIT_MS_VAL_TP_CD,',')  WITHIN GROUP(ORDER BY INIT_MS_VAL_TP_CD) ,' ')
                            INTO P_STR2
                                  FROM ( SELECT DISTINCT INIT_MS_VAL_TP_CD, IDX 
                                            FROM TABLE(FN_DP_TEMP_VER_INFO_INIT(P_VER_ID))		
                                           WHERE INIT_VAL_TP_CD = 'PR' 	
                                          ) A		
                         ;
                 END IF;
                 P_STR:= P_STR||P_STR2
				|| ' FROM TEMP_DP_ITEM_ACCT_CAL M '
				||' INNER JOIN'
				||' TABLE(FN_DP_TEMP_VER_INFO_DTL('''||P_VER_ID||''')) VE ON M.AUTH_TP_ID = VE.AUTH_TP_ID '
                ;

                 SELECT COUNT(1) INTO P_VAL_CNT 
                   FROM TABLE(FN_DP_TEMP_VER_INFO_DTL(P_VER_ID)) WHERE INIT_TP_CD = 'PR'
                   ;
				IF P_VAL_CNT > 0
					THEN
						 P_STR :=   P_STR || ' LEFT OUTER JOIN '
									||	   'TABLE(FN_DP_TEMP_VER_INFO_DTL('''||P_VER_ID||''')) VD'
									|| ' ON VE.DTL_ID = VD.DTL_ID AND VD.INIT_TP_CD = ''PR'''		
									||	   'LEFT OUTER JOIN '
									||	   'TABLE(FN_DP_TEMP_PR_VER('''||P_VER_ID||''', '''||P_PLAN_TP_ID||''')) DE '
									|| ' ON VD.INIT_VAL_ID = DE.AUTH_TP_ID '
									||' AND M.ITEM_MST_ID = DE.ITEM_MST_ID'
									||' AND M.ACCOUNT_ID = DE.ACCOUNT_ID'
									||' AND M.BASE_DATE = DE.BASE_DATE '
                                    ;
--                        P_STR := P_STR || P_STR2;
					END IF
                    ;
				IF (P_VAL_CNT_02 > 0)
					THEN
						P_STR := P_STR 
						||	   'INNER JOIN '		  
						||	   'INI_PR '
						||' PIVOT (MAX(INIT_FIXED_LV_MGMT_ID) FOR INIT_MS_VAL_TP_CD IN ('
                        ;

                        SELECT NVL(LISTAGG(INIT_MS_VAL_TP_CD,',') WITHIN GROUP(ORDER BY INIT_MS_VAL_TP_CD)  ,'')
                               INTO P_STR2
						  FROM ( SELECT DISTINCT INIT_MS_VAL_TP_CD
                                   FROM TABLE(FN_DP_TEMP_VER_INFO_INIT(P_VER_ID))		
                                 WHERE INIT_VAL_TP_CD = 'PR' 	
                               ) A			
                              ;
                        P_STR := P_STR||P_STR2||')) AS PVT ' 
						||' ON VE.DTL_ID = PVT.DTL_ID '		
                        ;
					SELECT    ' LEFT OUTER JOIN '
					||    ' TABLE(FN_DP_TEMP_PR_VER ('''||P_VER_ID||''', '''||P_PLAN_TP_ID||''')) DE'||TO_CHAR(IDX)
					|| ' ON PVT.'||INIT_MS_VAL_TP_CD||' = DE'||TO_CHAR(  IDX)||'.AUTH_TP_ID '
					|| ' AND M.ITEM_MST_ID = DE'||TO_CHAR(  IDX) ||'.ITEM_MST_ID '
					|| ' AND M.ACCOUNT_ID = DE'||TO_CHAR(  IDX) ||'.ACCOUNT_ID '
					|| ' AND M.BASE_DATE	= DE'||TO_CHAR(  IDX) ||'.BASE_DATE '
                    INTO P_STR2
				  FROM TABLE(FN_DP_TEMP_VER_INFO_INIT(P_VER_ID))
				 WHERE INIT_VAL_TP_CD = 'PR' 
				GROUP BY INIT_MS_VAL_TP_CD, IDX 
				;
				 END IF
                 ;

                P_STR := P_STR||P_STR2;

    			EXECUTE IMMEDIATE P_STR; -- USING P_VER_ID, P_PLAN_TP_ID;

			END IF
            ;
	END
		;

        SELECT COUNT(1) INTO P_VAL_CNT
          FROM TABLE(FN_DP_TEMP_VER_INFO_DTL(P_VER_ID)) 
         WHERE INIT_TP_CD = 'MS'
         ;
        SELECT COUNT(1) INTO P_VAL_CNT_02
         FROM TABLE(FN_DP_TEMP_VER_INFO_INIT(P_VER_ID)) 
        WHERE INIT_VAL_TP_CD = 'MS'        
        ;
		IF (P_VAL_CNT > 0 OR P_VAL_CNT_02 > 0)
			THEN	
				P_STR := '';		 
				WITH INI
				  AS (
					SELECT DTL_ID 
						 , AUTH_TP_ID 
						 , INIT_VAL_CD|| ' AS QTY' AS COL
						 , 'QTY' as VAL_COL
						 , 'SRC.QTY'  as IST_COL
						 , 'TGT.QTY = SRC.QTY' as UPT_COL

					 FROM TABLE(FN_DP_TEMP_VER_INFO_DTL(P_VER_ID)) 
					WHERE INIT_TP_CD = 'MS'
					UNION
					SELECT DTL_ID
						 , AUTH_TP_ID 
						 , LISTAGG(INIT_MEASURE_CD||' AS '||INIT_MS_VAL_TP_CD, ',') WITHIN GROUP (ORDER BY INIT_MS_VAL_TP_CD)  AS COL
--						 ,LISTAGG(INIT_MEASURE_CD, ',') AS MS_COL
						 , LISTAGG(INIT_MS_VAL_TP_CD, ',') WITHIN GROUP (ORDER BY INIT_MS_VAL_TP_CD) as VAL_COL
						 , LISTAGG('SRC.'||INIT_MS_VAL_TP_CD, ',') WITHIN GROUP (ORDER BY INIT_MS_VAL_TP_CD) as IST_COL
						 , LISTAGG('TGT.'||INIT_MS_VAL_TP_CD||'='||'SRC.'||INIT_MS_VAL_TP_CD, ',') WITHIN GROUP (ORDER BY INIT_MS_VAL_TP_CD) as UPT_COL
					  FROM TABLE(FN_DP_TEMP_VER_INFO_INIT(P_VER_ID)) 
					 WHERE INIT_VAL_TP_CD = 'MS' 
					 GROUP BY DTL_ID, AUTH_TP_ID
				  ) 
				SELECT ' MERGE INTO TEMP_DP_RT TGT'
					 || ' USING (			  '
					 || 'SELECT ITEM_MST_ID, ACCOUNT_ID, BASE_DATE '
--					 ||  INIT_VAL_CD
				     || ','''||AUTH_TP_ID||''' AS AUTH_TP_ID '
				     || ','''||DTL_ID||''' AS DTL_ID '
					 ||  ','||NVL(COL,' ')
					 || ' FROM TB_DP_MEASURE_DATA'
					 || ' WHERE BASE_DATE BETWEEN TO_DATE( '''||TO_CHAR(P_FROM_DATE)||''') AND TO_DATE( '''||TO_CHAR(P_TO_DATE)||''') '
					 || ' ) SRC '
					 || ' ON (SRC.ITEM_MST_ID = TGT.ITEM_MST_ID '
					 || ' AND SRC.ACCOUNT_ID = TGT.ACCOUNT_ID  '
					 || ' AND SRC.BASE_DATE = TGT.BASE_DATE	  '
					 || ' AND SRC.AUTH_TP_ID = TGT.AUTH_TP_ID ) '
					 || ' WHEN MATCHED THEN '
					 || ' UPDATE SET '||UPT_COL
					 || ' WHEN NOT MATCHED THEN '
					 || ' INSERT   ( '
					 || ' ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, AUTH_TP_ID ,'
					 ||  VAL_COL
					 || ' ) VALUES '
					 || ' (SRC.ITEM_MST_ID, SRC.ACCOUNT_ID, SRC.BASE_DATE, SRC.AUTH_TP_ID ,'
					 || IST_COL
					 || ' )'
                     INTO P_STR2
				 FROM INI 
				;	              
                P_STR := P_STR||P_STR2;
/*
                OPEN pRESULT
                 FOR 
                SELECT P_STR AS STR
                 FROM DUAL ;                
*/
				  EXECUTE IMMEDIATE P_STR;	
			END IF
			;

/************************************************************************************************************
	-- 3. Make Entry Data
************************************************************************************************************/

	 MERGE INTO TB_DP_ENTRY TGT
	  USING (
			 SELECT P_VER_ID				AS VER_ID 
				  , MN.AUTH_TP_ID 
				  , MN.ITEM_MST_ID	
				  , MN.ACCOUNT_ID
                  , MN.EMP_ID
				  , MN.BASE_DATE 
				  , NVL(TEMP_DP_RT.QTY , 0)		AS QTY 
				  , TEMP_DP_RT.QTY_1 -- NVL(TEMP_DP_RT.QTY_1,0)
				  , TEMP_DP_RT.QTY_2 -- NVL(TEMP_DP_RT.QTY_2,0)
				  , TEMP_DP_RT.QTY_3 -- NVL(TEMP_DP_RT.QTY_3,0)
				  , EH.QTY			AS QTY_A
				  , EH.AMT 			AS AMT_A 
			   FROM TEMP_DP_ITEM_ACCT_CAL MN
				    LEFT OUTER JOIN 
					TEMP_DP_RT		 
			     ON MN.ITEM_MST_ID = TEMP_DP_RT.ITEM_MST_ID 
				AND MN.ACCOUNT_ID = TEMP_DP_RT.ACCOUNT_ID 
				AND TEMP_DP_RT.BASE_DATE = MN.BASE_DATE  
				AND TEMP_DP_RT.AUTH_TP_ID = MN.AUTH_TP_ID  
					LEFT OUTER JOIN
					(
                        SELECT SUM(QTY)		    AS QTY
                             , SUM(AMT)			AS AMT
                             , ITEM_MST_ID
                             , ACCOUNT_ID
                          FROM TB_DP_ENTRY_HISTORY 
                         WHERE BASE_dATE BETWEEN P_SM_DATE AND (-1+P_FROM_DATE)
                    GROUP BY ITEM_MST_ID, ACCOUNT_ID                    
                    ) EH 
				ON  MN.ITEM_MST_ID = EH.ITEM_MST_ID
			   AND  MN.ACCOUNT_ID = EH.ACCOUNT_ID
			   ) SRC
			ON (TGT.VER_ID = SRC.VER_ID 
		   AND TGT.AUTH_TP_ID = SRC.AUTH_TP_ID
		   AND TGT.ITEM_MST_ID = SRC.ITEM_MST_ID
		   AND TGT.ACCOUNT_ID = SRC.ACCOUNT_ID
		   AND TGT.BASE_DATE = SRC.BASE_DATE)
		WHEN NOT MATCHED THEN
		INSERT  
	 (    ID
		, VER_ID
		, AUTH_TP_ID
		, EMP_ID
		, ITEM_MST_ID
		, ACCOUNT_ID
--		, SALES_LV_ID
		, BASE_DATE
		, QTY
		, AMT
		, CREATE_BY
		, CREATE_DTTM
		, PLAN_TP_ID
		, QTY_1
		, AMT_1
		, QTY_2
		, AMT_2
		, QTY_3
		, AMT_3		 
	    , QTY_A
		, AMT_A 
	 ) VALUES
	 (	TO_SINGLE_BYTE(SYS_GUID())
	  , SRC.VER_ID
	  , SRC.AUTH_TP_ID
      , SRC.EMP_ID
	  , SRC.ITEM_MST_ID
	  , SRC.ACCOUNT_ID
	  , SRC.BASE_DATE
	  , SRC.QTY
	  , NULL 
	  , p_user_ID
	  , SYSDATE
	  , P_PLAN_TP_ID 	 
	  , SRC.QTY_1
	  , NULL
	  , SRC.QTY_2
	  , NULL
	  , SRC.QTY_3
	  , NULL
	  , SRC.QTY_A 
	  , SRC.AMT_A  
	 )
    ;        


/************************************************************************************************************
	-- 3. Drop Temporary table
************************************************************************************************************/
	DELETE FROM  TEMP_DP_ITEM;
	DELETE FROM  TEMP_DP_ACCT;
	DELETE FROM  TEMP_DP_USER;
	DELETE FROM  TEMP_DP_RT;
	DELETE FROM  TEMP_DP_ITEM_ACCT_CAL ;

END
;
/

