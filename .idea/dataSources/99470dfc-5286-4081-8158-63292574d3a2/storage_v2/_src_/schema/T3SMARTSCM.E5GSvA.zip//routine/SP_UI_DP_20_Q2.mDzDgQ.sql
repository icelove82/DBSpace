create PROCEDURE                "SP_UI_DP_20_Q2" (
    P_FROM_DATE     DATE        := null
  , P_TO_DATE       DATE        := null
  , P_ITEM_CD       VARCHAR2    := null
  , P_ITEM_NM       VARCHAR2    := null
  , P_ACCT_CD       VARCHAR2    := null
  , P_ACCT_NM       VARCHAR2    := null
  , P_PRICE_TP_ID   CHAR		:= null
  , P_EMP_NO		VARCHAR2	:= NULL
  , P_AUTH_TP_ID    CHAR		:= NULL
  , P_BUCKET_CD	    VARCHAR2	:= NULL
  , pRESULT         OUT SYS_REFCURSOR 
)IS
/*************************************************************************************************************************
    Price Management 화면 하단 그리드 조회 프로시저 개발 중 

    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 
************************************************************************/
    -- 필요한 변수

     V_BUCKET           VARCHAR2(10) := '';
     V_FROM_DATE        DATE         := P_FROM_DATE;
     V_TO_DATE          DATE         := P_TO_DATE;
	 V_PARTIAL_DATE_CAL DATE         := NULL;
     V_PARTIAL_DATE     DATE         := null  ;
     V_PARTIAL_BUCKET   VARCHAR2(10) := ''  ;
     V_PARTIAL_HORIZON  INT          := 0 ;

     P_EMP_ID            CHAR(32);

BEGIN
   ----------------------------------------------------------------------------------------------------------------------
        --01 Item, Account 조합
   ----------------------------------------------------------------------------------------------------------------------

    SELECT ID INTO P_EMP_ID
      FROM TB_AD_USER
     WHERE USERNAME = P_EMP_NO;

    OPEN pRESULT
    FOR
    WITH USER_ITEM_ACCOUNT_MAP
    AS (
				SELECT CASE ITEM_YN 
							WHEN 'Y' THEN IM.ID
							ELSE IM2.ID
						END		AS ITEM_MST_ID
					  ,CASE ACCT_YN 
							WHEN 'Y' THEN AM.ID
							ELSE AM2.ID
						END		AS ACCOUNT_ID				 
				  FROM (
						SELECT IL.LEAF_YN		AS ITEM_YN
							 , UI.ITEM_LV_ID
							 , UI.ITEM_MST_ID
							 , AL.LEAF_YN		AS ACCT_YN
							 , UA.SALES_LV_ID
							 , UA.ACCOUNT_ID
						  FROM TB_DP_USER_ITEM_MAP UI
							   INNER JOIN
							   TB_DP_USER_ACCOUNT_MAP UA	
							ON UI.EMP_ID = UA.EMP_ID
						   AND UI.AUTH_TP_ID = UA.AUTH_TP_ID	
							   INNER JOIN
							   TB_CM_LEVEL_MGMT IL
							ON UI.LV_MGMT_ID = IL.ID
							   INNER JOIN
							   TB_CM_LEVEL_MGMT AL
							ON UA.LV_MGMT_ID = AL.ID					
						 WHERE UI.EMP_ID	 = P_EMP_ID
						   AND UI.AUTH_TP_ID = P_AUTH_TP_ID
							  UNION
						SELECT 'Y'			 AS ITEM_YN
							, NULL			 AS ITEM_LV_ID
							, IA.ITEM_MST_ID 
							, 'Y'			 AS ACCT_YN
							, NULL			 AS SALES_LV_ID
							, IA.ACCOUNT_ID
						  FROM TB_DP_USER_ITEM_ACCOUNT_MAP IA
						 WHERE IA.EMP_ID	 = P_EMP_ID
						   AND IA.AUTH_TP_ID = P_AUTH_TP_ID
					   ) IA
					   -- LEVEL
					   LEFT OUTER JOIN
					   TABLE(FN_DP_TEMP_ACCT_TREE()) AT
					ON AT.PATH_ID LIKE '%/' || IA.SALES_LV_ID || '%'
					   LEFT OUTER JOIN
					   TB_DP_ACCOUNT_MST AM2
					ON AT.LEAF_SALES_LV_ID = AM2.PARENT_SALES_LV_ID	
					   LEFT OUTER JOIN
					   TABLE(FN_DP_TEMP_ITEM_TREE()) IT
					ON IT.PATH_ID LIKE '%/' || IA.ITEM_LV_ID || '%'	 
					   LEFT OUTER JOIN
					   TB_CM_ITEM_MST IM2
					ON IT.LEAF_ITEM_LV_ID = IM2.PARENT_ITEM_LV_ID
					   -- LEAF
					   LEFT OUTER JOIN
					   TB_CM_ITEM_MST IM
					ON IM.ID = IA.ITEM_MST_ID
					   LEFT OUTER JOIN
					   TB_DP_ACCOUNT_MST AM
					ON AM.ID = IA.ACCOUNT_ID
				  WHERE COALESCE(IM.ID, '')||'/'||COALESCE(AM.ID, '') NOT IN (
																		SELECT ITEM_MST_ID||'/'||ACCOUNT_ID
																		  FROM TB_DP_USER_ITEM_ACCOUNT_EXCLUD
																		 WHERE EMP_ID = P_EMP_ID
																		   AND AUTH_TP_ID = P_AUTH_TP_ID
                                                                      )                
    ),
    CALENDER
    AS (
        SELECT DAT 
          FROM TB_CM_CALENDAR
         WHERE DAT BETWEEN V_FROM_DATE AND V_TO_DATE
           AND CASE P_BUCKET_CD
               WHEN 'YEAR'  THEN TO_NUMBER(MM)
               WHEN 'MONTH' THEN TO_NUMBER(DD)
               ELSE 1
               END = 1
           AND CASE P_BUCKET_CD
               WHEN 'YEAR'  THEN TO_NUMBER(DD) 
               ELSE 1
               END = 1
           AND CASE WHEN P_BUCKET_CD = 'WEEK' OR P_BUCKET_CD = 'PAR_WEEK' 
                            THEN (SELECT UPPER(CONF_CD) 
                                    FROM TB_CM_COMM_CONFIG 
                                   WHERE CONF_GRP_CD = 'DP_STD_WEEK' 
                                     AND ACTV_YN = 'Y' 
                                     AND USE_YN = 'Y'
                                 )
               ELSE DOW_NM
               END = DOW_NM
        UNION
        SELECT DAT
          FROM TB_CM_CALENDAR
         WHERE P_BUCKET_CD = 'PAR_WEEK'
           AND  DAT BETWEEN V_FROM_DATE AND V_TO_DATE
           AND TO_NUMBER(DD) = 1       
    )
    ----------------------------------------------------------------------------------------------------------------------
        --03 버킷에 의한 날짜별 UNIT PRICE 프로시저 (M/W/PW/D)
    ----------------------------------------------------------------------------------------------------------------------
            SELECT P.ITEM_MST_ID
                 , I.ITEM_CD
                 , I.ITEM_NM
                 , P.ACCOUNT_ID
                 , A.ACCOUNT_CD
                 , A.ACCOUNT_NM
                 , C.DAT
--                 , MAX(P.BASE_DATE)     
                 , MAX(P.UTPIC) KEEP(DENSE_RANK FIRST ORDER BY BASE_DATE DESC) AS UTPIC 
              FROM CALENDER C
                   LEFT OUTER JOIN 
                   (
                   SELECT IA.ITEM_MST_ID
                        , IA.ACCOUNT_ID
                        , UP.BASE_DATE
                        , UP.PRICE_TP_ID
                        , UP.UTPIC
                     FROM USER_ITEM_ACCOUNT_MAP IA
                          INNER JOIN
                          TB_DP_UNIT_PRICE UP
                       ON IA.ACCOUNT_ID = UP.ACCOUNT_ID
                      AND IA.ITEM_MST_ID = UP.ITEM_MST_ID
                   ) P
                   ON (C.DAT >= P.BASE_DATE) 
                   LEFT OUTER JOIN TB_CM_ITEM_MST I 
                ON (P.ITEM_MST_ID = I.ID and NVL(I.DEL_YN, 'N') = 'N' AND NVL(I.DP_PLAN_YN, 'Y') = 'Y')
                   LEFT OUTER JOIN TB_DP_ACCOUNT_MST A 
                ON (P.ACCOUNT_ID = A.ID AND NVL(A.DEL_YN, 'N') = 'N' AND A.ACTV_YN = 'Y')
             WHERE 1=1
               AND P.PRICE_TP_ID = P_PRICE_TP_ID
              AND  (  REGEXP_LIKE (UPPER(A.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR 
                      p_ACCT_CD IS NULL
                    )
               AND  ( REGEXP_LIKE (UPPER(I.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR 
                       P_ITEM_CD IS NULL
                    )
              AND   ( REGEXP_LIKE (UPPER(A.ACCOUNT_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ACCT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR 
                       p_ACCT_NM IS NULL
                    )
               AND  ( REGEXP_LIKE (UPPER(I.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR 
                       P_ITEM_NM IS NULL
                    )
               GROUP BY ITEM_MST_ID, ITEM_CD, ITEM_NM, ACCOUNT_ID, ACCOUNT_CD, ACCOUNT_NM, DAT
               ORDER BY ITEM_CD, ACCOUNT_CD, DAT
            ;
END
;
/

