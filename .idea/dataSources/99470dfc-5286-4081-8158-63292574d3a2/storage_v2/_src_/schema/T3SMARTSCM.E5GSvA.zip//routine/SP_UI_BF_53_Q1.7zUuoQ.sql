create PROCEDURE                  "SP_UI_BF_53_Q1" 
(
    p_ITEM_CD		VARCHAR2
   ,p_ITEM_NM		VARCHAR2
   ,p_ACCOUNT_CD    VARCHAR2
   ,p_ACCOUNT_NM    VARCHAR2
   ,p_VER_CNT		INT		 := 4
   ,p_ENGINE_TP_CD	VARCHAR2 :='RF'
   ,pRESULT         OUT SYS_REFCURSOR
)
IS 
/***************************************************************************************************************
	[BF Report]



	Hitory (date / writer / comment)
	-- 2020.01.21 / KSH / draft
	-- 2020.02.28 / kim sohee / change week rule : DP_WK (53 week per a year) 
**************************************************************************************************************/

p_FROM_DATE	DATE :='';
p_TO_DATE	DATE :='';
p_BUKT		VARCHAR2(2):='';

BEGIN
	WITH CB AS (
		SELECT VER_CD 
			 , ROW_NUMBER() OVER (ORDER BY VER_CD DESC) AS RW
		  FROM TB_BF_CONTROL_BOARD_VER_DTL
		 WHERE (PROCESS_NO = '990000' OR PROCESS_NO ='990')
		   AND STATUS = 'Completed'
	)
    SELECT MIN(TARGET_FROM_DATE)	 
         , MAX(TARGET_TO_DATE)	 
         , MAX(TARGET_BUKT_CD)
           INTO
           p_FROM_DATE
         , p_TO_DATE
         , p_BUKT
      FROM TB_BF_CONTROL_BOARD_VER_DTL A
     WHERE VER_CD IN (SELECT VER_CD FROM CB WHERE RW <= p_VER_CNT GROUP BY VER_CD)
       AND ENGINE_TP_CD IS NOT NULL
     ;

	/*************************************************************************************************************
		-- 주차 시작 요일 바꼈을 경우 대비해서 버전 날짜 범위 변경 처리
	************************************************************************************************************/

	IF (p_BUKT = 'W')
	THEN
		SELECT MAX(END_DATE) INTO p_TO_DATE
		  FROM (
				SELECT --YYYY
					   DP_WK
					 , MIN(DAT) AS STRT_DATE
					 , MAX(DAT) AS END_DATE
				  FROM TB_CM_CALENDAR C
				 WHERE DAT BETWEEN p_FROM_dATE AND p_TO_DATE
			  GROUP BY --YYYY, 
			  			DP_WK
			  HAVING COUNT(DP_WK) >= 7
			  ) A
            ;
	END IF; 

    OPEN pRESULT FOR
	WITH CB	AS (
		SELECT VER_CD 
		  FROM ( 	
			SELECT VER_CD 
				 , ROW_NUMBER() OVER (ORDER BY CREATE_DTTM DESC NULLS LAST) AS RW
			  FROM TB_BF_CONTROL_BOARD_VER_DTL
			 WHERE (PROCESS_NO = '990000' OR PROCESS_NO = '990')
			   AND STATUS = 'Completed'
			   ) A
		 WHERE RW <= p_VER_CNT
	), 
    RT AS (
		SELECT VER_CD
			 , BASE_DATE
			 , SUM(QTY) AS QTY
		  FROM TB_BF_RT
		WHERE 1=1
		  AND ENGINE_TP_CD = p_ENGINE_TP_CD
		  AND ITEM_CD	   = p_ITEM_CD
		  AND ACCOUNT_CD   = p_ACCOUNT_CD
		  AND VER_CD IN (SELECT VER_CD FROM CB)
	  GROUP BY VER_CD
			 , BASE_DATE
    ),  
  CALENDAR AS (
        SELECT DAT
             , YYYY
             , YYYYMM
             , CASE p_BUKT
                 WHEN 'W' THEN TO_NUMBER(TO_CHAR(DAT,'IW'))
                 WHEN 'PW' THEN TO_NUMBER(TO_CHAR(DAT,'IW'))
                 WHEN 'M' THEN TO_NUMBER(YYYYMM)
               END AS BUKT
--             , CASE p_BUKT
--                --WHEN 'W' THEN YYYY+' w'+CONVERT(NVARCHAR(2),DP_WK)
--                --WHEN 'PW'THEN YYYYMM+' w'+CONVERT(NVARCHAR(2),DP_WK) 
--                WHEN 'W'   THEN YYYY || ' w' || DP_WK --LPAD(DP_WK, 2, '0')
--                WHEN 'PW'  THEN YYYYMM || ' w' || DP_WK --LPAD(DP_WK, 2, '0')
--                WHEN 'M' THEN YYYYMM
--                WHEN 'D' THEN YYYYMMDD 
--               END AS BUKT	
          FROM TB_CM_CALENDAR
         WHERE DAT BETWEEN p_FROM_DATE AND p_TO_DATE
    ), 
    CA AS (
        SELECT MIN(DAT)	 AS STRT_DATE
             , MAX(DAT)  AS END_DATE
             , CASE p_BUKT
                 WHEN 'W' THEN MIN(YYYY) || ' w' || BUKT
                 WHEN 'PW' THEN MIN(YYYYMM) || ' w' || BUKT
                 WHEN 'M' THEN MIN(YYYYMM)
               END AS BUKT
            -- , BUKT		
          FROM CALENDAR
      GROUP BY BUKT
    ), 
    SA AS (
		SELECT  CA.STRT_DATE
			  , SUM(QTY)	QTY 
		  FROM TB_CM_ACTUAL_SALES S
		       INNER JOIN
			   CA
			ON S.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
			   INNER JOIN 
			   TB_CM_ITEM_MST IM 
			ON S.ITEM_MST_ID = IM.ID
		   AND COALESCE(IM.DEL_YN,'N') = 'N'
			   INNER JOIN 
			   TB_DP_ACCOUNT_MST AM
			ON S.ACCOUNT_ID = AM.ID
		   AND COALESCE(AM.DEL_YN,'N') = 'N'
		   AND AM.ACTV_YN = 'Y'
		 WHERE ITEM_CD = p_ITEM_CD
		   AND ACCOUNT_CD = p_ACCOUNT_CD
	  GROUP BY CA.STRT_DATE
	)
	  SELECT CA.STRT_DATE	AS BASE_DATE 
		   , CB.VER_CD
		   , SUM(RT.QTY)	AS QTY 
		   , SA.QTY			AS ACT_SALES_QTY
	    FROM CA
		 	 CROSS JOIN
		 	 CB	
		     LEFT OUTER JOIN
			 RT
		  ON RT.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE 
	 	 AND CB.VER_CD = RT.VER_CD
			 LEFT OUTER JOIN
			 SA 
		  ON SA.STRT_DATE = CA.STRT_DATE
	GROUP BY CA.STRT_DATE, CB.VER_CD, SA.QTY 
    ORDER BY CA.STRT_DATE
    ;
END;

/

