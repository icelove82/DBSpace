create PROCEDURE                SP_UI_DP_41_POP_D1 (
    p_MEASURE			VARCHAR2
   ,p_RT_ROLLBACK_FLAG  OUT VARCHAR2
   ,p_RT_MSG            OUT VARCHAR2
)AS
p_SQL1 VARCHAR2(4000) := 'ALTER TABLE TB_DP_MEASURE_DATA DROP COLUMN '||p_MEASURE||'_QTY';
p_SQL2 VARCHAR2(4000) := 'ALTER TABLE TB_DP_MEASURE_DATA DROP COLUMN '||p_MEASURE||'_AMT';
p_ERR_STATUS VARCHAR2(2);
p_ERR_MSG VARCHAR2(4000):='';

BEGIN 
    SELECT CASE WHEN EXISTS ( SELECT COLUMN_NAME
                                FROM ALL_TAB_COLUMNS
                               WHERE OWNER = (SELECT USER FROM DUAL)
                                 AND TABLE_NAME = 'TB_DP_MEASURE_DATA'
                                 AND COLUMN_NAME LIKE p_MEASURE||'_%' 
                            ) THEN '1' ELSE '0' END 
           INTO p_ERR_STATUS
      FROM DUAL;


	IF COALESCE(p_MEASURE,'') = ''
	THEN
		p_RT_MSG := 'Column Name is unclear';
	ELSIF (p_ERR_STATUS = '1')
	THEN
		--EXEC SP_EXECUTESQL p_SQL1
		--EXEC SP_EXECUTESQL p_SQL2
        EXECUTE IMMEDIATE p_SQL1;
        EXECUTE IMMEDIATE p_SQL2;
		p_RT_MSG := 'MSG_0002';  --저장 되었습니다. 
	END IF;

    p_RT_ROLLBACK_FLAG := 'true';

    EXCEPTION WHEN OTHERS THEN
              IF(SQLCODE = -20001)
              THEN
                  P_RT_MSG := SQLERRM;
                  p_RT_ROLLBACK_FLAG :='false';
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;   	

END;
/

