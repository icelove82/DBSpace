create PROCEDURE                "SP_UI_DP_00_POPUP_ITEM_Q1" (
    p_EMP_NO            VARCHAR2    := NULL	
  , p_AUTH_TP_ID        CHAR        := NULL 
  , p_ITEM_CD       IN  VARCHAR2    := ''
  , p_ITEM_NM       IN  VARCHAR2    := ''
  , P_ITEM_LV_CD    IN  VARCHAR2    := ''
  , pRESULT         OUT SYS_REFCURSOR
) IS 
/*************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 
    
************************************************************************/
    P_EMP_ID CHAR(32);
    P_EMP_CNT INT;
    P_PARENT_ITEM_LV_ID CHAR(32);
BEGIN
    IF P_EMP_NO IS NULL
    THEN   
        P_EMP_ID := NULL;
    ELSE
        SELECT ID
          INTO P_EMP_ID
          FROM TB_AD_USER
         WHERE USERNAME = P_EMP_NO;
     
        SELECT COUNT(EMP_ID) INTO P_EMP_CNT
          FROM TB_DP_USER_ITEM_MAP
         WHERE EMP_ID = P_EMP_ID
           AND AUTH_TP_ID = P_AUTH_TP_ID;
       
        SELECT P_EMP_CNT + COUNT(EMP_ID) INTO P_EMP_CNT
          FROM TB_DP_USER_ITEM_ACCOUNT_MAP
         WHERE EMP_ID = P_EMP_ID
           AND AUTH_TP_ID = P_AUTH_TP_ID;
    
        IF P_EMP_CNT = 0 THEN
            P_EMP_ID := NULL;
        END IF;
    END IF;
    
/*****************************************************************
    MAIN PROCEDURE
*****************************************************************/
    IF (P_EMP_ID IS NULL OR p_AUTH_TP_ID IS NULL)
	THEN
        OPEN pRESULT   
        FOR   
        SELECT A.ID 
             , A.ITEM_CD
             , A.ITEM_NM
             , A.EOS          AS EOS      
             , A.RTS          AS RTS  
             , A.UOM_ID
             , C.UOM_NM
             , C.UOM_CD
             , A.DESCRIP
             , A.DP_PLAN_YN
             , A.DEL_YN
             , A.PARENT_ITEM_LV_ID 
             , D.ITEM_LV_CD   AS PARENT_ITEM_LV_CD
             , D.ITEM_LV_NM   AS PARENT_ITEM_LV_NM
             , A.ATTR_01
             , A.ATTR_02
             , A.ATTR_03
             , A.ATTR_04
             , A.ATTR_05
             , A.ATTR_06
             , A.ATTR_07
             , A.ATTR_08
             , A.ATTR_09
             , A.ATTR_10
             , A.ATTR_11
             , A.ATTR_12
             , A.ATTR_13
             , A.ATTR_14
             , A.ATTR_15
             , A.ATTR_16
             , A.ATTR_17
             , A.ATTR_18
             , A.ATTR_19
             , A.ATTR_20
             , A.CREATE_BY
             , A.CREATE_DTTM
             , A.MODIFY_BY 
             , A.MODIFY_DTTM
          FROM TB_CM_ITEM_MST A 
               LEFT OUTER JOIN
               TB_CM_UOM C
            ON A.UOM_ID = C.ID AND C.ACTV_YN = 'Y'	
               INNER JOIN
               TB_CM_ITEM_LEVEL_MGMT D
            ON A.PARENT_ITEM_LV_ID = D.ID AND D.ACTV_YN = 'Y'
         WHERE 1=1
           AND COALESCE(A.DEL_YN, 'N') = 'N'
           AND A.DP_PLAN_YN = 'Y'
           AND A.ITEM_CD LIKE '%' || COALESCE(p_ITEM_CD, '') || '%'			
           AND A.ITEM_NM LIKE '%' || COALESCE(p_ITEM_NM, '') || '%'
           AND (D.ITEM_LV_CD = P_ITEM_LV_CD OR P_ITEM_LV_CD IS NULL)
         ORDER BY D.SEQ, D.ITEM_LV_CD, A.ITEM_CD
        ;        
    ELSE    
        OPEN pRESULT   
        FOR    
 		SELECT IM.ID, IM.ITEM_CD, IM.ITEM_NM, UM.UOM_CD, IL.ITEM_LV_NM AS PARENT_ITEM_LV_NM
		  FROM TABLE(FN_DP_TEMP_FIND_ITEM(P_EMP_ID,P_AUTH_TP_ID, P_ITEM_LV_CD)) FI
			   INNER JOIN
			   TB_CM_ITEM_MST IM
			ON IM.ID = FI.ITEM_ID
			   LEFT OUTER JOIN
			   TB_CM_UOM UM
			ON IM.UOM_ID = UM.ID
			   LEFT OUTER JOIN
			   TB_CM_ITEM_LEVEL_MGMT IL
			ON IL.ID = IM.PARENT_ITEM_LV_ID
	     WHERE FI.ITEM_CD LIKE '%'|| COALESCE(P_ITEM_CD, '')|| '%'
		   AND FI.ITEM_NM LIKE '%'|| COALESCE(P_ITEM_NM, '')|| '%'    
        ;
END IF;



END;
/

