create PROCEDURE SP_UI_DP_41_POP_Q1(
    pRESULT OUT SYS_REFCURSOR
)IS
    p_DATE DATE;
BEGIN
/*******************************************************************************************************************************
	[SP_UI_DP_41_POP_Q1]

	History (Date / Writer / Comment)
	-2023.02.10 / kim sohee / Base_date change 
*******************************************************************************************************************************/

    P_DATE := TRUNC(SYSDATE, 'MM');
    
-- 컬럼 생성 팝업창 조회
    OPEN pRESULT FOR
	SELECT REPLACE(REPLACE(COLUMN_NAME,'_QTY',''),'_AMT','') AS COL_NM
		,  REPLACE(REPLACE(COLUMN_NAME,'_QTY',''),'_AMT','')||'_QTY, '||REPLACE(REPLACE(COLUMN_NAME,'_QTY',''),'_AMT','')||'_AMT' AS DESCRIP
		,  'Y'	AS DEL_YN
		,  CAST (CASE SUBSTR(REPLACE(REPLACE(COLUMN_NAME,'_QTY',''),'_AMT','') ,0,3) 
				WHEN 'YTD'	  THEN 'Y' 
				WHEN 'YOY' THEN 'Y'
				WHEN 'ACT' THEN 'Y'
				ELSE 'N' END AS VARCHAR2(10))AS CAL_YN
		, CASE SUBSTR(REPLACE(REPLACE(COLUMN_NAME,'_QTY',''),'_AMT','') ,0,3) 
				WHEN 'YTD'	  THEN (SELECT TO_DATE(EXTRACT(YEAR FROM SYSDATE)||'-'||POLICY_VAL||'-1')
									  FROM TB_DP_PLAN_POLICY PP
										   INNER JOIN
										   TB_CM_COMM_CONFIG CF
										ON PP.POLICY_ID = CF.ID
									   AND CF.CONF_CD = 'SM'
										   INNER JOIN
										   TB_CM_COMM_CONFIG PT
										ON PP.PLAN_TP_ID = PT.ID
									   AND PT.ATTR_01 = 'M'
									) 
				WHEN 'YOY' THEN P_DATE -- (SELECT FROM_DATE FROM (SELECT FROM_DATE FROM TB_DP_CONTROL_BOARD_VER_MST ORDER BY CREATE_DTTM DESC) WHERE ROWNUM=1)
								-- (SELECT DATEADD(DAY, 1, MAX(BASE_DATE)) FROM TB_DP_MEASURE_DATA)
				WHEN 'ACT' THEN P_DATE -- (SELECT FROM_DATE FROM (SELECT FROM_DATE FROM TB_DP_CONTROL_BOARD_VER_MST ORDER BY CREATE_DTTM DESC) WHERE ROWNUM=1 )
				ELSE NULL  END AS CAL_BASE_DATE
	  FROM ALL_TAB_COLUMNS
	 WHERE OWNER = (SELECT USER FROM DUAL)
       AND TABLE_NAME = 'TB_DP_MEASURE_DATA'
	   AND COLUMN_NAME NOT IN ('ITEM_MST_ID', 'ACCOUNT_ID', 'BASE_DATE', 'CREATE_BY', 'CREATE_DTTM', 'MODIFY_BY', 'MODIFY_DTTM', 'ID')
	GROUP BY REPLACE(REPLACE(COLUMN_NAME,'_QTY',''),'_AMT','')
    ;
END;
/

