create PROCEDURE        "SP_UI_DP_35_Q11_A_ACCOUNT_CD" 
(	
	 p_OPERATOR_ID		VARCHAR2 := ''
	,p_AUTH_TP_ID	VARCHAR2 := ''
    ,pResult OUT SYS_REFCURSOR
)
IS 
/*************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / add USER_ID 
************************************************************************/

BEGIN
    OPEN pResult FOR 
    SELECT	B.USERNAME as USER_ID, B.USERNAME as EMP_NO,B.DISPLAY_NAME as EMP_NM, 
	        A.AUTH_TP_ID, L.LV_NM AS AUTH_TP_NM, A.ACCOUNT_ID, C.ACCOUNT_NM, CASE WHEN COALESCE(C.DEL_YN,'N') = 'Y'	THEN 'MASTER DATA 삭제'
																			   WHEN C.ACTV_YN = 'N' THEN 'MASTER DATA 비활성화'
																			   ELSE '그외(I/F문제등)' END ERR_DESC
	FROM	TB_DP_USER_ACCOUNT_MAP				A 
			INNER JOIN TB_AD_USER			B  ON A.EMP_ID = B.ID
			LEFT OUTER JOIN TB_DP_ACCOUNT_MST	C  ON A.ACCOUNT_ID = C.ID
            LEFT OUTER JOIN TB_CM_LEVEL_MGMT L
            ON A.AUTH_TP_ID = L.ID            
	WHERE	A.LV_MGMT_ID IN	(
								SELECT A.ID FROM TB_CM_LEVEL_MGMT	A 
								INNER JOIN  TB_CM_COMM_CONFIG		B  ON A.LV_TP_ID = B.ID AND B.CONF_GRP_CD = 'DP_LV_TP' AND B.CONF_CD = 'S'
								WHERE A.ACTV_YN = 'Y' AND A.LEAF_YN = 'Y' AND A.ACCOUNT_LV_YN = 'Y'
							)
	AND		NOT EXISTS	(
							SELECT 'X'
							FROM TB_DP_ACCOUNT_MST X 
							WHERE A.ACCOUNT_ID = X.ID
							AND COALESCE(X.DEL_YN, 'N') = 'N' 
						)
	AND		A.AUTH_TP_ID	LIKE '%' || p_AUTH_TP_ID || '%'
	AND		B.USERNAME		LIKE '%' || p_OPERATOR_ID || '%'
    ;


END;
/

