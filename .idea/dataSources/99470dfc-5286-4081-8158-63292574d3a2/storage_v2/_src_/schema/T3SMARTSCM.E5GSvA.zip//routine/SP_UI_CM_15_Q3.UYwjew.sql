create PROCEDURE SP_UI_CM_15_Q3 (
    P_PLAN_POLICY_ID    IN VARCHAR2 := '',
    pResult             OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN pResult FOR 
   SELECT  'M00000001'              AS ITEM_ID
          ,NULL AS DTL_ID
	      ,'Plan Policy Version'    AS PLAN_POLICY_NM
	      ,NULL                     AS CHECKED
          ,A.VER_ID                 AS VAL_01
		  ,NULL                     AS VAL_02
		  ,NULL                     AS VAL_03
		  ,NULL                     AS VAL_04
		  ,NULL                     AS VAL_05
		  ,NULL                     AS VAL_06
		  ,NULL                     AS VAL_07
		  ,NULL                     AS VAL_08
		  ,NULL                     AS VAL_09
		  ,NULL                     AS VAL_10
		  ,1 AS SEQ		  
     FROM TB_CM_PLAN_POLICY_MGMT A
    WHERE 1=1
      AND A.ID=P_PLAN_POLICY_ID
   UNION ALL
   SELECT  'M00000002'      AS PLAN_POLICY_ITEM_ID
          ,NULL             AS PLAN_POLICY_DTL_ID
	      ,'Active'
	      ,'N'              AS RADIO_CHECKED
          ,CASE WHEN A.ACTV_YN = 'N' THEN NULL ELSE A.ACTV_YN END AS PLAN_POLICY_VAL_01
		  ,NULL             AS PLAN_POLICY_VAL_02
		  ,NULL             AS PLAN_POLICY_VAL_03
		  ,NULL             AS PLAN_POLICY_VAL_04
		  ,NULL             AS PLAN_POLICY_VAL_05
		  ,NULL             AS PLAN_POLICY_VAL_06
		  ,NULL             AS PLAN_POLICY_VAL_07
		  ,NULL             AS PLAN_POLICY_VAL_08
		  ,NULL             AS PLAN_POLICY_VAL_09
		  ,NULL             AS PLAN_POLICY_VAL_10
		  ,1 AS SEQ		  
     FROM TB_CM_PLAN_POLICY_MGMT A
    WHERE 1=1
      AND A.ID=P_PLAN_POLICY_ID
   UNION ALL
   SELECT  A.PLAN_POLICY_ITEM_ID
	      ,CASE WHEN A.SINGLE_VAL_YN = 'N'  THEN A.PLAN_POLICY_DTL_ID
	       ELSE NULL
		   END AS PLAN_POLICY_DTL_ID
	      ,TO_CHAR(A.PLAN_POLICY_NM)
	      ,CASE WHEN A.SINGLE_VAL_YN = 'N'  AND A.PLAN_POLICY_DTL_ID = NVL(B.PLAN_POLICY_DTL_ID,'*') THEN 'Y'
	            WHEN A.SINGLE_VAL_YN = 'N'  AND A.PLAN_POLICY_DTL_ID = NVL(B.PLAN_POLICY_DTL_ID,'*') THEN NULL
		   ELSE NULL
		   END RADIO_CHECKED
          ,CASE WHEN A.PLAN_POLICY_ITEM_ID = 'M00390000' THEN DECODE(B.PLAN_POLICY_VAL_01, 'Y', B.PLAN_POLICY_VAL_01, NULL)
                ELSE B.PLAN_POLICY_VAL_01
           END AS PLAN_POLICY_VAL_01
		  ,B.PLAN_POLICY_VAL_02
		  ,B.PLAN_POLICY_VAL_03
		  ,B.PLAN_POLICY_VAL_04
		  ,NVL(B.PLAN_POLICY_VAL_05,A.REFER_ACTV_YN)     AS  PLAN_POLICY_VAL_05
		  ,B.PLAN_POLICY_VAL_06
		  ,B.PLAN_POLICY_VAL_07
		  ,B.PLAN_POLICY_VAL_08
		  ,B.PLAN_POLICY_VAL_09
		  ,B.PLAN_POLICY_VAL_10
		  ,A.SEQ
	 FROM (
           SELECT  A.ID         AS PLAN_POLICY_MST_ID
                  ,B.ID         AS PLAN_POLICY_DTL_ID
           	      ,A.PLAN_POLICY_ITEM_ID
           	      ,A.PLAN_POLICY_ITEM_NM
           	      ,B.PLAN_POLICY_VAL_ID
           	      ,B.PLAN_POLICY_NM
           	      ,A.SINGLE_VAL_YN
				  ,B.REFER_ACTV_YN
				  ,B.SEQ
             FROM  TB_CM_PLAN_POLICY_MST A
                  ,TB_CM_PLAN_POLICY_DTL B
            WHERE 1=1
              AND A.ID = B.PLAN_POLICY_MST_ID
              AND A.ACTV_YN = 'Y'
              AND B.ACTV_YN = 'Y'
              AND A.GRID_VAL_YN = 'N'
              AND A.PLAN_POLICY_ITEM_ID NOT IN ('M00010000' )
	      ) A
		  LEFT OUTER JOIN
		  (
           SELECT  B.ID AS VALUE_ID
                  ,C.PLAN_POLICY_ITEM_ID
                  ,C.PLAN_POLICY_ITEM_NM
           	      ,C.SINGLE_VAL_YN
           	      ,B.PLAN_POLICY_MST_ID
           	      ,B.PLAN_POLICY_DTL_ID
                  ,CASE WHEN C.PLAN_POLICY_ITEM_ID IN ('M00200000', 'M00220000','M00110000','M00350000','M00590000') THEN TO_CHAR(E.COMN_CD_NM)
                        ELSE TO_CHAR(B.PLAN_POLICY_VAL_01) END AS PLAN_POLICY_VAL_01
           		  ,B.PLAN_POLICY_VAL_02
           		  ,B.PLAN_POLICY_VAL_03
           		  ,B.PLAN_POLICY_VAL_04
           		  ,B.PLAN_POLICY_VAL_05
           		  ,B.PLAN_POLICY_VAL_06
           		  ,B.PLAN_POLICY_VAL_07
           		  ,B.PLAN_POLICY_VAL_08
           		  ,B.PLAN_POLICY_VAL_09
           		  ,B.PLAN_POLICY_VAL_10
             FROM  TB_CM_PLAN_POLICY_MGMT A
                  ,TB_CM_PLAN_POLICY_VALUE B
                   LEFT OUTER JOIN TB_CM_LOC_MST D
                   ON D.ID = B.PLAN_POLICY_VAL_02
                   LEFT OUTER JOIN TB_AD_COMN_CODE E
                   ON E.ID = D.LOCAT_TP_ID
           	      ,TB_CM_PLAN_POLICY_MST C
            WHERE 1=1
              AND A.ID = B.PLAN_POLICY_MGMT_ID
              AND B.PLAN_POLICY_MST_ID = C.ID
              AND A.ID = P_PLAN_POLICY_ID
		  ) B 
	   ON (A.PLAN_POLICY_MST_ID = B.PLAN_POLICY_MST_ID)
   UNION ALL
   SELECT  'M00010000' AS PLAN_POLICY_ITEM_ID
          ,A.ID AS PLAN_POLICY_DTL_ID
          ,TO_CHAR(A.COMN_CD)
	      ,CASE WHEN A.ID = B.PLAN_POLICY_VAL_01 THEN 'Y'
	       ELSE null
		   END
          ,NULL AS PLAN_POLICY_VAL_01
		  ,NULL AS PLAN_POLICY_VAL_02
		  ,NULL AS PLAN_POLICY_VAL_03
		  ,NULL AS PLAN_POLICY_VAL_04
		  ,NULL AS PLAN_POLICY_VAL_05
		  ,NULL AS PLAN_POLICY_VAL_06
		  ,NULL AS PLAN_POLICY_VAL_07
		  ,NULL AS PLAN_POLICY_VAL_08
		  ,NULL AS PLAN_POLICY_VAL_09
		  ,NULL AS PLAN_POLICY_VAL_10
		  ,1    AS SEQ		  
     FROM (
           SELECT  B.ID
                  ,B.COMN_CD
             FROM  TB_AD_COMN_GRP A
                  ,TB_AD_COMN_CODE B
            WHERE 1=1
              AND A.GRP_CD='MODULE_TP'
              AND A.ID = B.SRC_ID
	      ) A
		  LEFT OUTER JOIN 
		  (
           SELECT B.PLAN_POLICY_VAL_01
             FROM TB_CM_PLAN_POLICY_MGMT A
                 ,TB_CM_PLAN_POLICY_VALUE B
                 ,TB_CM_PLAN_POLICY_MST C
            WHERE 1=1
              AND A.ID = B.PLAN_POLICY_MGMT_ID
              AND B.PLAN_POLICY_MST_ID = C.ID
              AND A.ID=P_PLAN_POLICY_ID
              AND C.PLAN_POLICY_ITEM_ID='M00010000'
		  ) B
	   ON ( A.ID = B.PLAN_POLICY_VAL_01)
    ORDER BY 1,SEQ ;

END;

/

