create PROCEDURE SP_UI_CM_04_S1 (
    P_WRK_TYPE                  IN VARCHAR2 :='',
    P_ID                        IN VARCHAR2 :='',
    P_BOM_ITEM_TP_ID            IN VARCHAR2 :='',
    P_PROCUR_TP_ID              IN VARCHAR2 :='',
    P_DIFFTD_CLSS_CD            IN VARCHAR2 :='',
    P_MIN_ORDER_SIZE            IN NUMBER := NULL,
    P_MAX_ORDER_SIZE            IN NUMBER := NULL,
    P_UOM_CD                    IN VARCHAR2 :='',
    P_SRA                       IN DATE := NULL,
    P_EOP                       IN DATE := NULL,
    P_PARENT_ITEM_EOL           IN DATE := NULL,
    P_INV_ONHAND_YN             IN CHAR := '',
	P_IMMEDIATE_SHIPMENT_YN	    IN CHAR := NULL,
    P_INV_POLICY                IN VARCHAR2 :='',
    P_STD_UTPIC                 IN NUMBER := NULL,
    P_DIRECT_COST               IN NUMBER := NULL,
    P_INDIRECT_COST             IN NUMBER := NULL,
	P_MIN_LV					IN NUMBER := null,
	P_MAX_LV					IN NUMBER := null,
	P_ALLOWED_PUSH_YN			IN CHAR := null,
	P_PUSH_TP_ID				IN CHAR := null,
	P_ALTERNATE_PUSH_POLICY_ID	IN CHAR := null,
    P_ALLOWED_HOLIDAY_YN        IN CHAR := '',
    P_CURCY_CD                  IN VARCHAR2 := '',
    P_ACTV_YN                   IN CHAR := '',
    P_USER_ID                   IN VARCHAR2 :='',
    P_RT_ROLLBACK_FLAG          OUT VARCHAR2,
    P_RT_MSG                    OUT VARCHAR2
)
IS
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG  VARCHAR2(4000) :='';
    P_LOC_MGMT_ID  VARCHAR2(32) :='';

BEGIN
    IF P_WRK_TYPE = 'SAVE'
    THEN
        P_ERR_MSG := 'MSG_0008';
        IF (P_MIN_ORDER_SIZE < 0 OR P_MAX_ORDER_SIZE < 0 OR P_STD_UTPIC < 0)
        THEN
            RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
        END IF;

        P_ERR_MSG := 'MSG_5015';
		IF (P_MIN_ORDER_SIZE > P_MAX_ORDER_SIZE) THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;

		MERGE INTO TB_CM_SITE_ITEM B 
		USING (SELECT P_ID AS ID FROM DUAL) A
        ON    ( B.ID = P_ID)
		WHEN MATCHED THEN
			UPDATE 
			   SET 
				   BOM_ITEM_TP_ID		    = P_BOM_ITEM_TP_ID
				 , PROCUR_TP_ID			    = P_PROCUR_TP_ID
				 , DIFFTD_CLSS_ID		    = P_DIFFTD_CLSS_CD
                 , UOM_ID                   = P_UOM_CD
				 , CURCY_CD_ID			    = P_CURCY_CD
				 , SRA					    = P_SRA
				 , EOP					    = P_EOP
				 , PARENT_ITEM_EOL		    = P_PARENT_ITEM_EOL
				 , INV_ONHAND_YN		    = P_INV_ONHAND_YN
                 , IMMEDIATE_SHIPMENT_YN	= P_IMMEDIATE_SHIPMENT_YN
				 , INV_POLICY_ID		    = P_INV_POLICY
				 , STD_UTPIC			    = P_STD_UTPIC
                 , DIRECT_COST			    = P_DIRECT_COST
                 , INDIRECT_COST		    = P_INDIRECT_COST
                 , MIN_LV					= P_MIN_LV
                 , MAX_LV					= P_MAX_LV
                 , ALLOWED_PUSH_YN			= P_ALLOWED_PUSH_YN
                 , PUSH_TP_ID				= P_PUSH_TP_ID
                 , ALTERNATE_PUSH_POLICY_ID = P_ALTERNATE_PUSH_POLICY_ID
                 , ALLOWED_HOLIDAY_YN       = P_ALLOWED_HOLIDAY_YN
				 , ACTV_YN				    = P_ACTV_YN
				 , MODIFY_BY			    = P_USER_ID
				 , MODIFY_DTTM			    = SYSDATE;

		UPDATE TB_CM_ITEM_MST
        SET
             MIN_ORDER_SIZE = P_MIN_ORDER_SIZE
            ,MAX_ORDER_SIZE = P_MAX_ORDER_SIZE
            ,UOM_ID		    = P_UOM_CD
            ,MODIFY_BY      = P_USER_ID
            ,MODIFY_DTTM    = SYSDATE
        WHERE ID = (SELECT ITEM_MST_ID FROM TB_CM_SITE_ITEM WHERE ID = P_ID);

	    P_RT_MSG := 'MSG_0001';
        
	ELSIF P_WRK_TYPE = 'DELETE'
		THEN
			DELETE FROM TB_CM_SITE_ITEM 
            WHERE ID = P_ID;
                
	    P_RT_MSG := 'MSG_0002';
    END IF;
    
    P_RT_ROLLBACK_FLAG := 'true';

EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN 
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;
      ELSE
          RAISE;
      END IF;
END;
/

