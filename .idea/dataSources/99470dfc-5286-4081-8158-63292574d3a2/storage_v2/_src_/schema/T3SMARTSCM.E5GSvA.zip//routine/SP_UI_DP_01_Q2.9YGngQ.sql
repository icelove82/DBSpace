create PROCEDURE        "SP_UI_DP_01_Q2" (
										p_CONF_ID     IN  VARCHAR2      := ''
                                       ,pRESULT       OUT SYS_REFCURSOR 
                                             ) IS 

BEGIN

OPEN pRESULT          
FOR 
SELECT  A.ID			        AS ID			
	   ,A.CONF_ID		        AS CONF_ID		
	   ,A.CONF_GRP_CD	        AS CONF_GRP_CD	
	   ,A.CONF_CD		        AS CONF_CD		
	   , 'CF_'||UPPER(A.CONF_GRP_CD)
       ||'_'||UPPER(A.CONF_CD)	AS LANG_CONF_NM
       ,A.CONF_NM               AS CONF_NM   	
	   ,NVL(A.DEFAT_VAL,'N')	AS DEFAT_VAL		
	   ,NVL(A.ACTV_YN,'N')		AS ACTV_YN		
       ,A.PRIORT        AS PRIORT
	   ,NVL(A.USE_YN,'N')		AS USE_YN		
	   , 'CF_'||UPPER(A.CONF_GRP_CD)
       ||'_'||UPPER(A.CONF_CD)
       ||'_DESCRIP'	            AS LANG_DESCRIP
	   , A.DESCRIP	            AS DESCRIP	
	   ,A.ATTR_01		        AS ATTR_01		
	   ,A.ATTR_02		        AS ATTR_02		
	   ,A.ATTR_03		        AS ATTR_03		
	   ,A.ATTR_04		        AS ATTR_04		
	   ,A.ATTR_05		        AS ATTR_05		
	   ,A.ATTR_06		        AS ATTR_06		
	   ,A.ATTR_07		        AS ATTR_07		
	   ,A.ATTR_08		        AS ATTR_08		
	   ,A.ATTR_09		        AS ATTR_09		
	   ,A.ATTR_10		        AS ATTR_10		
	   ,A.CREATE_BY		        AS CREATE_BY		
	   ,A.CREATE_DTTM	        AS CREATE_DTTM	
	   ,A.MODIFY_BY		        AS MODIFY_BY		
	   ,A.MODIFY_DTTM	        AS MODIFY_DTTM	
 FROM TB_CM_COMM_CONFIG A 
      INNER JOIN
  	  TB_CM_CONFIGURATION B
   ON (A.CONF_ID = B.ID)
WHERE 1=1
 AND B.ID = p_CONF_ID
order by  PRIORT;



END
;

/

