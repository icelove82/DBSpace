create PROCEDURE        SP_UI_DP_23_UNION_PRICE_TP
(
     P_CHK_PRICE_TP     IN VARCHAR      :=''
    ,P_USER_ID          IN VARCHAR      :=''
--    ,P_LOCALE           IN VARCHAR      :=''
    ,P_RT_ROLLBACK_FLAG OUT VARCHAR2   
    ,P_RT_MSG           OUT VARCHAR2    
)IS
/***********************************************************************************
    Price Type : 2018.10.01    
***********************************************************************************/
		P_ERR_STATUS INT := 0;
        P_PRICE_TP_LIST VARCHAR2(300) :='';
        P_ERR_MSG VARCHAR2(4000):=''; 
        V_VER_ID  VARCHAR2(100) :='';
BEGIN
---------------------------------- Validation --------------------------------------
-- 1. Price Type
  SELECT COUNT(PRICE_TP2), LISTAGG(PRICE_TP2,', ') WITHIN GROUP (ORDER BY PRICE_TP2) INTO P_ERR_STATUS, P_PRICE_TP_LIST
          FROM (
                 SELECT  SUBSTR(regexp_substr(A.PRICE_TP, '[^|]+', 1, LEVEL),0,1) PRICE_TP1
                        ,SUBSTR(regexp_substr(A.PRICE_TP, '[^|]+', 1, LEVEL),-2)  PRICE_TP2
                        , COUNT(SUBSTR(regexp_substr(A.PRICE_TP, '[^|]+', 1, LEVEL),-2)) AS CNT
                   FROM (SELECT P_CHK_PRICE_TP PRICE_TP FROM dual) A
                CONNECT BY LEVEL <= length(regexp_replace(A.PRICE_TP, '[^|]+',''))+1
               GROUP BY SUBSTR(regexp_substr(A.PRICE_TP, '[^|]+', 1, LEVEL),0,1), SUBSTR(regexp_substr(A.PRICE_TP, '[^|]+', 1, LEVEL),-2)                         
                ) M
        WHERE CNT > 1
        ;
IF (P_ERR_STATUS > 0)    
    THEN
	    P_ERR_MSG := 'MSG_0005';
END IF;
 -- 2.  Price Type 

            SELECT COUNT(DESCRIP) INTO P_ERR_STATUS
              FROM TB_CM_COMM_CONFIG
             WHERE 1=1
               AND CONF_GRP_CD = 'DP_PRICE_TYPE'
               AND REPLACE(DESCRIP,', ','|') = P_CHK_PRICE_TP
               AND USE_YN ='Y'
               AND ACTV_YN ='Y'   
               ;
            IF (P_ERR_STATUS >= 1)
                THEN
                    P_ERR_MSG := 'MSG_0013';
                    RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);        
            END IF;
-------------------------------- VERSION NAMING ----------------------------------------
SELECT COUNT(CONF_CD) INTO P_ERR_STATUS
  FROM TB_CM_COMM_CONFIG
 WHERE 1=1
   AND CONF_GRP_CD = 'DP_PRICE_TYPE'
   AND CONF_CD LIKE '%T'||TO_CHAR(SYSDATE,'YYYYMMDD')||'%'  
   AND USE_YN ='Y'
   AND ACTV_YN ='Y'
   ;
IF(P_ERR_STATUS = 0)
    THEN
         V_VER_ID := 'T'||TO_CHAR(SYSDATE,'YYYYMMDD')||'-'||
               '01' ;
    ELSE
        SELECT 'T'||TO_CHAR(SYSDATE,'YYYYMMDD')||'-'||
               LPAD(MAX(SUBSTR(CONF_CD, INSTR(CONF_CD, '-')+1,2))+1,2,'0') INTO V_VER_ID    
          FROM TB_CM_COMM_CONFIG
         WHERE 1=1
           AND CONF_GRP_CD = 'DP_PRICE_TYPE'
           AND CONF_CD LIKE '%T'||TO_CHAR(SYSDATE,'YYYYMMDD')||'%'  
           AND USE_YN ='Y'
           AND ACTV_YN ='Y'
           ;
END IF;
------------------------------------------------------------------------------------
            -- CONFIG 
                INSERT INTO TB_CM_COMM_CONFIG 
                (CONF_GRP_CD
                ,CONF_ID
                ,ID
                ,CONF_CD
                ,CONF_NM
                ,USE_YN
                ,DESCRIP
                ,CREATE_BY
                ,CREATE_DTTM
                ,MODIFY_BY
                ,MODIFY_DTTM
                ,PRIORT
                ,ACTV_YN
                ,DEFAT_VAL
                )VALUES
                (
                'DP_PRICE_TYPE' 
                ,(SELECT ID FROM TB_CM_CONFIGURATION WHERE CONF_NM = 'DP_PRICE_TYPE' )
                ,TO_SINGLE_BYTE(SYS_GUID()) 
                ,V_VER_ID
                ,V_VER_ID
                ,'Y'
                ,REPLACE(P_CHK_PRICE_TP,'|', ', ')
                ,P_USER_ID
                ,SYSDATE
                ,NULL
                ,NULL
                ,NULL
                ,'Y'
                ,NULL                
                );
            -- UNIT PRICE 
            INSERT INTO TB_DP_UNIT_PRICE
            (
                ID, ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, UTPIC, CURCY_CD_ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM, PRICE_TP_ID, ATTR_01            
            )
            SELECT TO_SINGLE_BYTE(SYS_GUID())  AS ID
                 , UP.ITEM_MST_ID
                 , UP.ACCOUNT_ID
                 , UP.BASE_DATE
                 , UP.UTPIC
                 , UP.CURCY_CD_ID
                 , P_USER_ID AS CREATE_BY
                 , SYSDATE   AS CREATE_DTTM
                 , NULL
                 , NULL
                 , (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_CD = V_VER_ID) AS PRICE_TP_ID
                 , PT.CONF_CD          
             FROM TB_DP_UNIT_PRICE UP
                  INNER JOIN
                  TB_CM_COMM_CONFIG PT
              ON  UP.PRICE_TP_ID = PT.ID 
            WHERE 1=1
              AND PT.CONF_GRP_CD = 'DP_PRICE_TYPE'            
              AND PT.ACTV_YN = 'Y'
              AND PT.USE_YN = 'Y'
              AND REGEXP_LIKE(PT.CONF_CD, P_CHK_PRICE_TP)
              ;
        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0003';  
       /* ============================================================================*/
        EXCEPTION
        WHEN OTHERS THEN  --  e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                SP_COMM_RAISE_ERR();              
               -- RAISE;
              END IF;  
END;
/

