create PROCEDURE SP_UI_DP_41_POP_S2(
     p_MEASURE_CD		VARCHAR2
    ,p_BASE_DATE		DATE
    ,p_RT_ROLLBACK_FLAG OUT VARCHAR2
    ,p_RT_MSG           OUT VARCHAR2
) IS
/*************************************************************************************************************
    SP_UI_DP_41_POP_S2

	History (Date / Writer / Comment)
		-- 2020.03.19 / Kimsohee / draft
		-- 2020.12.21 / kim sohee/ relocate code to set mm bukt 
        -- 2020.12.22 / 민경훈 / MSSQL -> ORACLE
        - 2023.02.10 / Kim sohee / YOY 계산방식 변경 & MEASURE 별 날짜 범위 지정 코드 정리 
*************************************************************************************************************/

p_STRT_DATE	DATE := '';
p_END_DATE  DATE := '';

-- For ANNUAL_DP 
p_MM_BUKT	    VARCHAR2(2);
p_YY_BUKT	    VARCHAR2(2);
p_YY_VER_ID	    CHAR(32);
p_CL_LV_MGMT_ID CHAR(32);
P_SM  VARCHAR2(2);

p_ERR_STATUS VARCHAR2(2);
p_ERR_MSG VARCHAR2(4000):='';

BEGIN 
    IF (p_BASE_DATE IS NULL)
	THEN
		p_STRT_DATE := SYSDATE;
    ELSE
        p_STRT_DATE := p_BASE_DATE;
	END IF;

        P_END_DATE := p_STRT_DATE + (INTERVAL '1' YEAR);

/**********************************************************************************************************************
	-- Config Setting
**********************************************************************************************************************/
    SELECT POLICY_VAL INTO p_MM_BUKT
      FROM TB_DP_PLAN_POLICY PP
           INNER JOIN
           TB_CM_COMM_CONFIG CF
        ON PP.POLICY_ID = CF.ID
       AND CF.CONF_CD = 'B'
           INNER JOIN
           TB_CM_COMM_CONFIG PT
        ON PP.PLAN_TP_ID = PT.ID
       AND PT.ATTR_01 = 'M'
       ;
    IF (p_MEASURE_CD LIKE 'YTD%')
	THEN
		SELECT POLICY_VAL INTO P_SM
		  FROM TB_DP_PLAN_POLICY PP
			   INNER JOIN
			   TB_CM_COMM_CONFIG CF
			ON PP.POLICY_ID = CF.ID
		   AND CF.CONF_CD = 'SM'
			   INNER JOIN
			   TB_CM_COMM_CONFIG PT
			ON PP.PLAN_TP_ID = PT.ID
		   AND PT.ATTR_01 = 'M'
		   ;
    ELSIF (p_MEASURE_CD = 'YOY')
	THEN
        P_STRT_DATE := P_STRT_DATE - (INTERVAL '1' YEAR);
        P_END_DATE := P_END_DATE - (INTERVAL '1' YEAR);

	END IF;
/**********************************************************************************************************************
    -- Get Version Data
**********************************************************************************************************************/    
    INSERT INTO TEMP_DP_ITEM_ACCOUNT_DATE 
    (  ITEM_MST_ID
     , ACCOUNT_ID
     , BASE_DATE
     , STRT_DATE
     , END_DATE )
	WITH USER_ACCT_MAP
     AS (
        SELECT AUTH_TP_ID, EMP_ID, SH.DESCENDANT_ID AS ACCOUNT_ID
          FROM TB_DP_USER_ACCOUNT_MAP M
               INNER JOIN 
               TB_CM_LEVEL_MGMT L
            ON M.LV_MGMT_ID = L.ID    
               INNER JOIN 
               TB_DPD_SALES_HIER_CLOSURE SH
            ON SH.LEAF_YN = 'Y' 
		   AND SH.LV_TP_CD = 'S'            
           AND CASE WHEN L.LEAF_YN = 'Y' THEN ACCOUNT_ID ELSE SALES_LV_ID END = SH.ANCESTER_ID 
    GROUP BY  AUTH_TP_ID, EMP_ID, SH.DESCENDANT_ID 
     ), USER_ITEM_MAP
     AS (
        SELECT AUTH_TP_ID, EMP_ID, IH.DESCENDANT_ID AS ITEM_ID
          FROM TB_DP_USER_ITEM_MAP M
               INNER JOIN 
               TB_CM_LEVEL_MGMT L
            ON M.LV_MGMT_ID = L.ID    
               INNER JOIN 
               TB_DPD_ITEM_HIER_CLOSURE IH
            ON IH.LEAF_YN = 'Y' 
		   AND IH.LV_TP_CD = 'I'            
           AND CASE WHEN L.LEAF_YN = 'Y' THEN ITEM_MST_ID ELSE ITEM_LV_ID END = IH.ANCESTER_ID 
    GROUP BY  AUTH_TP_ID, EMP_ID, IH.DESCENDANT_ID 

     ), ITEM_ACCT 
    AS (
        SELECT A.ACCOUNT_ID 
              ,I.ITEM_ID 
          FROM USER_ACCT_MAP A
               INNER JOIN 
               USER_ITEM_MAP I
            ON A.AUTH_TP_ID = I.AUTH_TP_ID
           AND A.EMP_ID = I.EMP_ID
        GROUP BY A.ACCOUNT_ID, I.ITEM_ID 
        UNION 
		SELECT UA.ACCOUNT_ID
			 , UA.ITEM_MST_ID    AS ITEM_ID
		  FROM TB_DP_USER_ITEM_ACCOUNT_MAP UA
			   INNER JOIN
			   TB_DP_ACCOUNT_MST AM
			ON UA.ACCOUNT_ID = AM.ID
           AND AM.ACTV_YN = 'Y'
           AND AM.DEL_YN != 'Y' 
			   INNER JOIN
			   TB_CM_ITEM_MST IM
			ON UA.ITEM_MST_ID = IM.ID 
           AND IM.DP_PLAN_YN = 'Y'
           AND IM.DEL_YN != 'Y'
        WHERE UA.ACTV_YN = 'Y'
		GROUP BY UA.ACCOUNT_ID
			 , UA.ITEM_MST_ID 
		)
	,CAL
	AS (
			SELECT  MIN(DAT)	AS STRT_DATE
				  , MAX(DAT)	AS END_DATE
				  , MIN(DAT)	AS BASE_DATE 
			  FROM TB_CM_CALENDAR 
			 WHERE DAT BETWEEN p_STRT_DATE AND p_END_DATE 		
		  GROUP BY CASE WHEN p_MM_BUKT = 'D' THEN YYYYMMDD ELSE TO_CHAR(YYYY) END
				 , CASE WHEN p_MM_BUKT IN ('M', 'PW') THEN TO_CHAR(MM) ELSE '1' END
				 , CASE WHEN p_MM_BUKT IN ('W', 'PW') THEN DP_WK ELSE '1' END	  		 
		)        
    SELECT ITEM_ID  
         , ACCOUNT_ID 
         , BASE_DATE 
         , STRT_DATE
         , END_DATE
      FROM CAL 
           CROSS JOIN
           ITEM_ACCT 		                                                                                          
    ;
/**********************************************************************************************************************
	-- Main Proceure
**********************************************************************************************************************/
    SELECT CASE WHEN NOT EXISTS ( SELECT COLUMN_NAME
                                FROM ALL_TAB_COLUMNS
                               WHERE OWNER = (SELECT USER FROM DUAL)
                                 AND TABLE_NAME = 'TB_DP_MEASURE_DATA' 
                                 AND COLUMN_NAME = 'ANNUAL_QTY'                                 
                            ) THEN '1' ELSE '0' END INTO p_ERR_STATUS
      FROM DUAL;

    IF (p_ERR_STATUS='1' AND P_MEASURE_CD = 'YTD_ANNUAL'	)
	THEN
        p_ERR_MSG := 'Please, Create Annual column first.';
        RAISE_APPLICATION_ERROR(-20001,p_ERR_MSG);
	END IF;
/**********************************************************************************************************************
	-- YTD
**********************************************************************************************************************/
	IF (p_MEASURE_CD = 'YTD') 
    THEN					
             MERGE INTO TB_DP_MEASURE_DATA SRC
              USING (   
                        WITH SA
                        AS (
                            SELECT MM.ITEM_MST_ID
                                 , MM.ACCOUNT_ID
                                 , MM.STRT_DATE					AS BASE_DATE 
                                 , COALESCE(SUM(SA.QTY),0)		AS QTY 
                                 , COALESCE(SUM(SA.AMT),0)		AS AMT
                              FROM TEMP_DP_ITEM_ACCOUNT_DATE MM
                                   LEFT OUTER JOIN
                                   (SELECT ITEM_MST_ID
                                         , ACCOUNT_ID
                                         , BASE_DATE 
                                         ,  QTY
                                         ,  AMT
                                      FROM TB_CM_ACTUAL_SALES WHERE BASE_DATE BETWEEN p_STRT_DATE AND p_END_DATE
                                    ) SA
                                ON SA.BASE_DATE BETWEEN MM.STRT_DATE AND MM.END_DATE				
                               AND MM.ITEM_MST_ID = SA.ITEM_MST_ID
                               AND MM.ACCOUNT_ID = SA.ACCOUNT_ID   				
                            GROUP BY MM.ITEM_MST_ID
                                    ,MM.ACCOUNT_ID 
                                    ,MM.STRT_dATE
                        )
                        SELECT ITEM_MST_ID
                             , ACCOUNT_ID
                             , BASE_DATE
                             -- SO_STATUS_ID
                             , SUM(QTY) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID 
											  , CASE WHEN EXTRACT(MONTH FROM BASE_DATE) >= P_SM	THEN EXTRACT(YEAR FROM BASE_DATE) 
																			ELSE EXTRACT(YEAR FROM BASE_DATE)-1  END                            
                             ORDER BY BASE_DATE) AS QTY
                             , SUM(AMT) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID
											  , CASE WHEN EXTRACT(MONTH FROM BASE_DATE) >= P_SM	THEN EXTRACT(YEAR FROM BASE_DATE) END                             
                             ORDER BY BASE_DATE) AS AMT -- , DATEPART(YEAR, BASE_DATE)
                          FROM SA					  
                    ) TGT
                ON (SRC.ITEM_MST_ID = TGT.ITEM_MST_ID 
               AND SRC.ACCOUNT_ID  = TGT.ACCOUNT_ID  
               AND SRC.BASE_DATE   = TGT.BASE_DATE   )
               WHEN MATCHED THEN
               UPDATE SET YTD_QTY = TGT.QTY
                        , YTD_AMT = TGT.AMT
                ,CREATE_BY = 'system'
                 ,CREATE_DTTM = SYSDATE                                        
               WHEN NOT MATCHED THEN
               INSERT  
               ( ID
                ,ITEM_MST_ID
                ,ACCOUNT_ID
                ,BASE_DATE
                ,YTD_QTY
                ,YTD_AMT
                ,CREATE_BY
                ,CREATE_DTTM
               ) VALUES
               ( TO_SINGLE_BYTE(SYS_GUID())
                ,TGT.ITEM_MST_ID
                ,TGT.ACCOUNT_ID
                ,TGT.BASE_DATE
                ,TGT.QTY
                ,TGT.AMT
                ,'system'
                ,SYSDATE
               );
/**********************************************************************************************************************
	-- YTD Annual
**********************************************************************************************************************/
	ELSIF (p_MEASURE_CD = 'YTD_ANNUAL') 
    THEN	 
            MERGE INTO TB_DP_MEASURE_DATA SRC
            USING(	 
                    SELECT MM.ITEM_MST_ID
                         , MM.ACCOUNT_ID
                         , MM.BASE_DATE			AS BASE_DATE
                         , SUM(ANNUAL_QTY) OVER (PARTITION BY MM.ITEM_MST_ID, MM.ACCOUNT_ID  
											  , CASE WHEN EXTRACT(MONTH FROM MM.BASE_DATE) >= P_SM	THEN EXTRACT(YEAR FROM MM.BASE_DATE) END                           
                         ORDER BY MM.BASE_DATE) AS QTY -- , DATEPART(YEAR, MM.BASE_DATE)
                         , SUM(ANNUAL_AMT) OVER (PARTITION BY MM.ITEM_MST_ID, MM.ACCOUNT_ID  
											  , CASE WHEN EXTRACT(MONTH FROM MM.BASE_DATE) >= P_SM	THEN EXTRACT(YEAR FROM MM.BASE_DATE) END                           
                         ORDER BY MM.BASE_DATE) AS AMT -- , DATEPART(YEAR, MM.BASE_DATE)
                      FROM TEMP_DP_ITEM_ACCOUNT_DATE MM
                           LEFT OUTER JOIN
                           (SELECT ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, ANNUAL_QTY, ANNUAL_AMT
                              FROM TB_DP_MEASURE_DATA
                             WHERE BASE_DATE BETWEEN  p_STRT_DATE AND p_END_DATE
                           ) MD
                        ON MM.ITEM_MST_ID = MD.ITEM_MST_ID
                       AND MM.ACCOUNT_ID = MD.ACCOUNT_ID
                       AND MM.BASE_DATE = MD.BASE_DATE
                ) TGT
             ON (SRC.ITEM_MST_ID  = TGT.ITEM_MST_ID
            AND SRC.ACCOUNT_ID   = TGT.ACCOUNT_ID
            AND SRC.BASE_DATE    = TGT.BASE_DATE )
            WHEN MATCHED THEN
             UPDATE  SET SRC.YTD_ANNUAL_QTY = TGT.QTY
                        ,SRC.YTD_ANNUAL_AMT = TGT.AMT
                        ,SRC.CREATE_BY = 'system'
                        ,SRC.CREATE_DTTM = SYSDATE
            WHEN NOT MATCHED THEN
            INSERT (  ID
                    , ITEM_MST_ID
                    , ACCOUNT_ID
                    , BASE_DATE
                    , YTD_ANNUAL_QTY
                    , YTD_ANNUAL_AMT
                    , CREATE_BY
                    , CREATE_DTTM
                   ) 
            VALUES ( TO_SINGLE_BYTE(SYS_GUID())
                    ,TGT.ITEM_MST_ID
                    ,TGT.ACCOUNT_ID
                    ,TGT.BASE_DATE
                    ,TGT.QTY
                    ,TGT.AMT
                    ,'system'
                    ,SYSDATE
                   );						  				 								
/**********************************************************************************************************************
	-- YOY
**********************************************************************************************************************/
	ELSIF (p_MEASURE_CD = 'YOY')
    THEN
           MERGE INTO TB_DP_MEASURE_DATA TGT
           USING (      
                  WITH SA
                    AS (
                        SELECT ITEM_MST_ID
                             , ACCOUNT_ID
                             , BASE_DATE 
                             , QTY
                             , AMT 
                         FROM TB_CM_ACTUAL_SALES
                        WHERE BASE_DATE BETWEEN p_STRT_DATE AND p_END_DATE
                    )
                        SELECT SA.ITEM_MST_ID
                             , SA.ACCOUNT_ID
                             , MM.BASE_DATE + (INTERVAL '1' YEAR) AS BASE_DATE
                             , SUM(QTY)		AS QTY 
                             , SUM(AMT)		AS AMT 
                          FROM SA SA
                               INNER JOIN 
                               TEMP_DP_ITEM_ACCOUNT_DATE MM
                            ON SA.ITEM_MST_ID = MM.ITEM_MST_ID
                           AND SA.ACCOUNT_ID = MM.ACCOUNT_ID
                           AND SA.BASE_DATE BETWEEN MM.STRT_DATE AND MM.END_DATE 
                     GROUP BY SA.ITEM_MST_ID
                            , SA.ACCOUNT_ID
                            , MM.BASE_DATE
                 ) SRC
              ON (TGT.ITEM_MST_ID = SRC.ITEM_MST_ID
             AND TGT.ACCOUNT_ID = SRC.ACCOUNT_ID
             AND TGT.BASE_DATE = SRC.BASE_DATE)
           WHEN MATCHED THEN 
           UPDATE 
             SET YOY_QTY = SRC.QTY
                ,YOY_AMT = SRC.AMT 
                ,CREATE_BY = 'system'
                 ,CREATE_DTTM = SYSDATE                
           WHEN NOT MATCHED THEN
           INSERT ( ID
                  , ITEM_MST_ID
                  , ACCOUNT_ID
                  , BASE_DATE
                  , YOY_QTY
                  , YOY_AMT 
                  )
           VALUES (	TO_SINGLE_BYTE(SYS_GUID())
                  , SRC.ITEM_MST_ID
                  , SRC.ACCOUNT_ID
                  , SRC.BASE_DATE
                  , SRC.QTY
                  , SRC.AMT 
                  )
                  ;
/**********************************************************************************************************************
	-- Actual Sales
**********************************************************************************************************************/
    ELSIF (p_MEASURE_CD = 'ACT_SALES')
	THEN
		MERGE INTO TB_DP_MEASURE_DATA TGT
		USING (WITH SA
                    AS (
                        SELECT ITEM_MST_ID
                             , ACCOUNT_ID
                             , BASE_DATE 
                             , QTY
                             , AMT 
                         FROM TB_CM_ACTUAL_SALES
                        WHERE BASE_DATE BETWEEN p_STRT_DATE AND p_END_DATE
                    )
                        SELECT SA.ITEM_MST_ID
                             , SA.ACCOUNT_ID
                             , MM.BASE_DATE AS BASE_DATE
                             , SUM(QTY)		AS QTY 
                             , SUM(AMT)		AS AMT 
                          FROM SA SA
                               INNER JOIN 
                               TEMP_DP_ITEM_ACCOUNT_DATE MM
                            ON SA.ITEM_MST_ID = MM.ITEM_MST_ID
                           AND SA.ACCOUNT_ID = MM.ACCOUNT_ID
                           AND SA.BASE_DATE BETWEEN MM.STRT_DATE AND MM.END_DATE 
                     GROUP BY SA.ITEM_MST_ID
                            , SA.ACCOUNT_ID
                            , MM.BASE_DATE		
			 ) SRC
			ON (TGT.ITEM_MST_ID = SRC.ITEM_MST_ID
		   AND TGT.ACCOUNT_ID = SRC.ACCOUNT_ID
		   AND TGT.BASE_DATE = SRC.BASE_DATE)
		  WHEN MATCHED THEN
			UPDATE SET TGT.ACT_SALES_QTY = SRC.QTY
					 , TGT.ACT_SALES_AMT = SRC.AMT
					 , TGT.MODIFY_BY     = 'system'
					 , TGT.MODIFY_DTTM   = SYSDATE
		  WHEN NOT MATCHED THEN 
			INSERT
			(ID
			,ITEM_MST_ID
			,ACCOUNT_ID
			,BASE_DATE
			,ACT_SALES_QTY
			,ACT_SALES_AMT
			,CREATE_BY
			,CREATE_DTTM
			)
			VALUES
			(TO_SINGLE_BYTE(SYS_GUID())
			,SRC.ITEM_MST_ID
			,SRC.ACCOUNT_ID
			,SRC.BASE_DATE
			,SRC.QTY
			,SRC.AMT
			,'system'
			,SYSDATE
			);

	END IF;

    DELETE FROM TEMP_DP_ITEM_ACCOUNT_DATE;

   p_RT_ROLLBACK_FLAG := 'true';
   p_RT_MSG := 'MSG_0003';  --저장 되었습니다.

    EXCEPTION WHEN OTHERS THEN
              IF(SQLCODE = -20001)
              THEN
                  P_RT_MSG := SQLERRM; 
                  p_RT_ROLLBACK_FLAG := 'false';
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;   	


END ;
/

