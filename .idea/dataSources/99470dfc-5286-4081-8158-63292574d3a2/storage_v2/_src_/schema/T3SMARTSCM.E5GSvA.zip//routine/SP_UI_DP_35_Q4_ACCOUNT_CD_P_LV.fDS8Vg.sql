create PROCEDURE        "SP_UI_DP_35_Q4_ACCOUNT_CD_P_LV" 
(
    pResult OUT SYS_REFCURSOR
)
IS 


BEGIN

    OPEN pResult FOR 
	SELECT	ID, ACCOUNT_CD, ACCOUNT_NM
	FROM	TB_DP_ACCOUNT_MST 
	WHERE	NVL(DEL_YN, 'N') = 'N' AND ACTV_YN = 'Y'
	AND		NVL(PARENT_SALES_LV_ID, 'none') NOT IN	(
													SELECT ID FROM TB_DP_SALES_LEVEL_MGMT 
													)
                                                    ;

END;
/

