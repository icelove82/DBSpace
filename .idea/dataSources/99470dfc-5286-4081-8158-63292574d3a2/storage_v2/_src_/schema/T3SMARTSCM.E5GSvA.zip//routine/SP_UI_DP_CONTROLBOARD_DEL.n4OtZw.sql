create PROCEDURE SP_UI_DP_CONTROLBOARD_DEL  (
											   p_VER_ID				VARCHAR2 	    
											  ,p_USER_ID			VARCHAR2      
                                              ,P_RT_ROLLBACK_FLAG	OUT 	VARCHAR2 
                                        	  ,P_RT_MSG           	OUT 	VARCHAR2	 									   
	  										   ) 
AS
/*****************************************************************************

[SP_UI_DP_CONTROLBOARD_DEL]

설명 
 - DP VERSION Delete
 
History (수정일자 / 수정자 / 수정내용)
- 2023.02.15 / kim sohee /Draft
*****************************************************************************/

    P_ERR_STATUS INT := 0;
    P_ERR_MSG VARCHAR2(4000);

BEGIN  
	DELETE FROM TB_DP_CONTROL_BOARD_VER_MST WHERE VER_ID = P_VER_ID ;
	DELETE FROM TB_DP_CONTROL_BOARD_VER_INIT WHERE CONBD_VER_DTL_ID IN (SELECT ID FROM TB_DP_CONTROL_BOARD_VER_DTL WHERE CONBD_VER_MST_ID = P_VER_ID );
	DELETE FROM TB_DP_CONTROL_BOARD_VER_DTL WHERE CONBD_VER_MST_ID = P_VER_ID ;
	DELETE FROM TB_DP_ENTRY WHERE VER_ID = P_VER_ID ;

	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0002';  
       /*  ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN  
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF; 

END;
/

