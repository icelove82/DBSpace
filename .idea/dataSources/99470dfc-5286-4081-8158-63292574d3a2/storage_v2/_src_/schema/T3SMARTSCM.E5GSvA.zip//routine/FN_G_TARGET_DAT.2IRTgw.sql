create FUNCTION FN_G_TARGET_DAT (
    P_INPUT_VAL NUMBER,
    P_TYPE IN VARCHAR2,
    P_TIME_BUKT IN VARCHAR2
)
RETURN G_TARGET_DAT IS
C_G_TARGET_DAT G_TARGET_DAT := G_TARGET_DAT();

CURSOR C_DATA_IMPORT IS
SELECT TP_G_TARGET_DAT (
        VAL => A.VAL)
  FROM (
        SELECT CASE WHEN P_TYPE = 'START' THEN MIN(A.DAT) ELSE MIN(A.DAT) - 1 END AS VAL
        FROM TB_CM_CALENDAR A 
        WHERE 1=1
        AND CASE WHEN P_TIME_BUKT = 'DAY' THEN A.YYYYMMDD_SEQ
            WHEN P_TIME_BUKT = 'WEEK' THEN A.WK52_SEQ
            WHEN P_TIME_BUKT = 'PARTIAL_WEEK' THEN  A.PARTWK_SEQ
            WHEN P_TIME_BUKT = 'MONTH' THEN A.YYYYMM_SEQ
            WHEN P_TIME_BUKT = 'YEAR' THEN A.YYYY_SEQ
	    END = (
              SELECT CASE WHEN P_TIME_BUKT = 'DAY' THEN A.YYYYMMDD_SEQ
                          WHEN P_TIME_BUKT = 'WEEK' THEN A.WK52_SEQ
                          WHEN P_TIME_BUKT = 'PARTIAL_WEEK' THEN  A.PARTWK_SEQ
                          WHEN P_TIME_BUKT = 'MONTH' THEN A.YYYYMM_SEQ
                          WHEN P_TIME_BUKT = 'YEAR' THEN A.YYYY_SEQ
	                 END 
                	 + 
			    	 CASE WHEN P_TYPE = 'START'  AND P_INPUT_VAL >=0 THEN 0 
                	      WHEN P_TYPE = 'START'  AND P_INPUT_VAL < 0 THEN P_INPUT_VAL
                		  WHEN P_TYPE = 'END' AND P_INPUT_VAL < 0 THEN 0
                		  WHEN P_TYPE = 'END' AND P_INPUT_VAL >=0 THEN P_INPUT_VAL
                	 END
                FROM TB_CM_CALENDAR A
               WHERE 1=1
                 AND A.DAT_ID = (
                                 SELECT TO_CHAR(A.STRT_DATE, 'YYYYMMDD')
                                   FROM TB_CM_HORIZON_TIME_BUCKET A
                                        INNER JOIN 
	                                    TB_CM_UOM B
										ON A.TIME_UOM_ID = B.ID
										INNER JOIN TB_CM_PLAN_SNRIO_MGMT_MST C
										ON C.ID = A.PLAN_SNRIO_MGMT_MST_ID
										INNER JOIN TB_AD_COMN_CODE D
										ON D.ID = C.MODULE_ID
								  WHERE D.COMN_CD = 'IM'
                                )
              )
        ) A;

BEGIN
OPEN C_DATA_IMPORT;
FETCH C_DATA_IMPORT BULK COLLECT INTO C_G_TARGET_DAT;
CLOSE C_DATA_IMPORT;

RETURN C_G_TARGET_DAT;
END;

/

