create PROCEDURE SP_UI_CM_10_POP_S2 (
    P_BOD_TP_ID                 IN CHAR := NULL
   ,P_CONSUME_LOCAT_MGMT_ID     IN CHAR := NULL
   ,P_SUPPLY_LOCAT_MGMT_ID      IN CHAR := NULL
   ,P_ITEM_MST_ID               IN CHAR := NULL
   ,P_VEHICL_TP_ID              IN CHAR := NULL
   ,P_BOD_LEADTIME_ID           IN CHAR := NULL
   ,P_BOD_LEAD_TIME             IN VARCHAR2 := ''
   ,P_UOM                       IN VARCHAR2 := NULL
   ,P_USER_ID                   IN VARCHAR2 := NULL
   ,P_RT_ROLLBACK_FLAG          OUT VARCHAR2
   ,P_RT_MSG                    OUT VARCHAR2
)
IS
    P_ERR_STATUS NUMBER := 0;
    P_ERR_MSG VARCHAR2(4000) :='';
    V_TRANSP_MGMT_MST_ID CHAR(32) := '';
    V_TRANSP_MGMT_DTL_ID CHAR(32) :='';
    V_CONSUME_LOCAT_ITEM_ID CHAR(32):='';
    V_SUPPLY_LOCAT_ITEM_ID CHAR(32) :='';
    
BEGIN
    IF P_VEHICL_TP_ID IS NOT NULL THEN 
        SELECT A.ID INTO V_CONSUME_LOCAT_ITEM_ID
		FROM   TB_CM_SITE_ITEM A,
			   TB_AD_COMN_CODE B,
			   TB_CM_LOC_MGMT C
		WHERE  A.ITEM_MST_ID = P_ITEM_MST_ID
		AND    A.LOCAT_MGMT_ID = P_CONSUME_LOCAT_MGMT_ID
		AND	   A.LOCAT_MGMT_ID = C.ID
		AND    A.BOM_ITEM_TP_ID = B.ID
		AND    B.COMN_CD = (CASE WHEN C.SEMI_PRDUCT_GI_USE_YN = 'Y' THEN 'SEMI_PRODUCT_GI_ITEM' ELSE 'FINAL_PRODUCT_GR_ITEM' END);        
    
        SELECT A.ID INTO V_SUPPLY_LOCAT_ITEM_ID
        FROM   TB_CM_SITE_ITEM A,
               TB_AD_COMN_CODE B
        WHERE  A.ITEM_MST_ID = P_ITEM_MST_ID
        AND    A.LOCAT_MGMT_ID = P_SUPPLY_LOCAT_MGMT_ID
        AND    A.BOM_ITEM_TP_ID = B.ID
        AND    B.COMN_CD = 'FINAL_PRODUCT_GR_ITEM';
        
        BEGIN
            SELECT A.ID INTO V_TRANSP_MGMT_MST_ID
            FROM TB_CM_TRANSFER_MGMT_MST A
            WHERE A.CONSUME_LOCAT_ITEM_ID = V_CONSUME_LOCAT_ITEM_ID
            AND   A.SUPPLY_LOCAT_ITEM_ID = V_SUPPLY_LOCAT_ITEM_ID
            AND   A.BOD_TP_ID = P_BOD_TP_ID
            AND   A.VEHICL_TP_ID = P_VEHICL_TP_ID;
        EXCEPTION
        WHEN NO_DATA_FOUND
        THEN 
            P_ERR_MSG := 'MSG_0026';
            RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
        END;
        
        BEGIN
            SELECT A.ID INTO V_TRANSP_MGMT_DTL_ID
            FROM TB_CM_TRANSFER_MGMT_DTL A
            WHERE A.TRANSP_MGMT_MST_ID = V_TRANSP_MGMT_MST_ID
            AND A.BOD_LEADTIME_ID = P_BOD_LEADTIME_ID;
        EXCEPTION
        WHEN NO_DATA_FOUND
        THEN NULL;
        END;
                
        MERGE INTO TB_CM_TRANSFER_MGMT_DTL B
        USING (
               SELECT V_TRANSP_MGMT_DTL_ID  AS TRANSP_MGMT_DTL_ID,
                      V_TRANSP_MGMT_MST_ID  AS TRANSP_MGMT_MST_ID,
                      P_BOD_LEADTIME_ID	    AS BOD_LEADTIME_ID,
                      P_BOD_LEAD_TIME		AS LEADTIME,
                      P_UOM				    AS UOM_ID,
                      'Y'					AS ACTV_YN,
                      P_USER_ID			    AS USER_ID
                 FROM DUAL
              ) A
        ON (A.TRANSP_MGMT_DTL_ID = B.ID)
        WHEN MATCHED THEN
            UPDATE
                SET
                    B.LEADTIME = A.LEADTIME,
                    B.UOM_ID = A.UOM_ID,
                    B.MODIFY_BY = A.USER_ID,
                    B.MODIFY_DTTM = SYSDATE
        WHEN NOT MATCHED THEN
            INSERT (
                    ID,
                    TRANSP_MGMT_MST_ID,
                    BOD_LEADTIME_ID,
                    LEADTIME,
                    UOM_ID,
                    ACTV_YN,
                    CREATE_BY,
                    CREATE_DTTM
                   )
            VALUES (
                    TO_SINGLE_BYTE(SYS_GUID()),
                    A.TRANSP_MGMT_MST_ID,
                    A.BOD_LEADTIME_ID,
                    A.LEADTIME,
                    A.UOM_ID,
                    A.ACTV_YN,
                    A.USER_ID,
                    SYSDATE
                   );    
    END IF;
                    
    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';
    
EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;   
      ELSE
         RAISE;
      END IF;
END;

/

