create PROCEDURE                "SP_UI_DP_02_Q1" (
    p_LV_TP         IN  VARCHAR2 := ''
  , P_DEL_YN         IN VARCHAR2 := 'N'
  , pRESULT       OUT SYS_REFCURSOR
) IS 

BEGIN

/****** SSMS SelectTopNRows  ******/
    OPEN pRESULT FOR 
    SELECT LM.ID
          ,LM.LV_TP_ID 
          --,B.CONF_CD   AS  LV_TP
          --,B.CONF_NM   AS  LV_NM
          ,LM.LV_CD
          ,LM.LV_NM
          ,LM.SEQ
          ,LM.LV_LEAF_YN
          ,LM.SALES_LV_YN
          ,LM.ACCOUNT_LV_YN
          ,LM.SRP_LV_YN
          ,LM.LEAF_YN
          ,LM.ACTV_YN
          ,LM.DEL_YN
          ,LM.CREATE_BY
          ,LM.CREATE_DTTM
          ,LM.MODIFY_BY
          ,LM.MODIFY_DTTM
      FROM TB_CM_CONFIGURATION A
         , TB_CM_COMM_CONFIG B
         , TB_CM_LEVEL_MGMT LM
     WHERE A.MODULE_CD = 'DP'
       AND A.ID = B.CONF_ID
       AND B.CONF_GRP_CD = 'DP_LV_TP'
       AND B.ACTV_YN = 'Y'
       AND B.ID = LM.LV_TP_ID
       AND (LM.DEL_YN = P_DEL_YN OR TRIM(P_DEL_YN) IS NULL)
       AND LM.LV_TP_ID  LIKE '%' || LTRIM(RTRIM(P_LV_TP)) || '%'
     ORDER BY B.PRIORT ASC, LM.SEQ ASC
    ;

END;
/

