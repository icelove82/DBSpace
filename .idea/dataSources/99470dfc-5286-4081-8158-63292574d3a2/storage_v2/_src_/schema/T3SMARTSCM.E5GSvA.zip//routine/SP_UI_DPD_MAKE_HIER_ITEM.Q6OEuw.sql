create PROCEDURE                "SP_UI_DPD_MAKE_HIER_ITEM" 
IS          
/******************************************************************************************
	-- CREATE TABLE 
	-- 2020.12.09 / KIM SOHEE / ORACLE CONVETING
    -- 2021.07.16/ Kim sohee / Make DPD_HIERARCHY2 data
    -- 2021.12.16 / kim sohee / Add columns GRADE , COV 
    -- 2022.11.30 / kim sohee / add NM 
********************************************************************************************/

 P_CHECK INT ;
 CURSOR CUR_LOOP  IS
	SELECT LV_TP_ID, CC.CONF_CD AS LV_TP_CD, COALESCE(MAX(ATTR_01), 'PARENT_ITEM_LV_ID') AS LV_TP_COL,  COUNT(CL.SEQ) AS LV_CNT
      FROM TB_CM_LEVEL_MGMT CL
           INNER JOIN
           TB_CM_COMM_CONFIG CC
        ON CL.LV_TP_ID = CC.ID 
     WHERE NVL(CL.ACCOUNT_LV_YN ,'N') = 'N'
	   AND NVL(CL.SALES_LV_YN   ,'N') = 'N'
	   AND NVL(CL.DEL_YN	    ,'N') = 'N' 
	   AND CL.ACTV_YN = 'Y'
  GROUP BY LV_TP_ID, CC.CONF_CD 
        ; 
 CURSOR PLAN_TP_LOOP IS
	SELECT C2.ATTR_01 AS PLAN_TP_ATTR , P.POLICY_VAL AS BUKT 
	  FROM TB_DP_PLAN_POLICY P
		   INNER JOIN 
		   TB_CM_COMM_CONFIG C 
		ON C.ID = P.POLICY_ID AND C.CONF_CD = 'B'
		   INNER JOIN 
		   TB_CM_COMM_CONFIG C2 
	    ON C2.ID = P.PLAN_TP_ID
		;            
	P_TMP_CNT INT := 1;  
	P_SQL	VARCHAR2(4000);  
    P_MIN_RTS DATE;
    P_MAX_EOS DATE;
BEGIN
/***************************************************************************************************************************
    -- CREATE TABLE AND INDEX
    -- TABLE 재생성과 DATA변경을 프로시저에서 동시에 할 수는 없다.
    -- 프로시저 안에서 TABLE을 만들려면 사용자에 권한이 부여돼야 한다.
****************************************************************************************************************************/
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIER_CLOSURE_01' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIER_CLOSURE_01 ON TB_DPD_ITEM_HIER_CLOSURE (ANCESTER_ID)'; 
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIER_CLOSURE_02' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIER_CLOSURE_02 ON TB_DPD_ITEM_HIER_CLOSURE (ANCESTER_CD)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIER_CLOSURE_03' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIER_CLOSURE_03 ON TB_DPD_ITEM_HIER_CLOSURE (DESCENDANT_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIER_CLOSURE_04' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIER_CLOSURE_04 ON TB_DPD_ITEM_HIER_CLOSURE (DESCENDANT_CD)';
    END IF;
/* TB_DPD_ITEM_HIERARCHY2 */
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'PK_TB_DPD_ITEM_HIERACHY2' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN    -- PK
        EXECUTE IMMEDIATE  'ALTER TABLE TB_DPD_ITEM_HIERACHY2 ADD CONSTRAINT PK_TB_DPD_ITEM_HIERACHY2 PRIMARY KEY (ITEM_ID)';        
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'UK_TB_DPD_ITEM_HIERACHY2' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN    -- UK
        EXECUTE IMMEDIATE  'CREATE UNIQUE INDEX UK_TB_DPD_ITEM_HIERACHY2 ON TB_DPD_ITEM_HIERACHY2 (ITEM_CD)';                
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_01' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_01 ON TB_DPD_ITEM_HIERACHY2 (LVL01_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_02' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_02 ON TB_DPD_ITEM_HIERACHY2 (LVL02_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_03' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_03 ON TB_DPD_ITEM_HIERACHY2 (LVL03_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_04' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_04 ON TB_DPD_ITEM_HIERACHY2 (LVL04_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_05' AND OWNER = (SELECT USER FROM DUAL);
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_05 ON TB_DPD_ITEM_HIERACHY2 (LVL05_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_06' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_06 ON TB_DPD_ITEM_HIERACHY2 (LVL06_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_07' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_07 ON TB_DPD_ITEM_HIERACHY2 (LVL07_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_08' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_08 ON TB_DPD_ITEM_HIERACHY2 (LVL08_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_09' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_09 ON TB_DPD_ITEM_HIERACHY2 (LVL09_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ITEM_HIERACHY2_10' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ITEM_HIERACHY2_10 ON TB_DPD_ITEM_HIERACHY2 (LVL10_ID)';
    END IF;
/************************************************************************************************************************************************************************************************************
	-- MAIN QUERY
************************************************************************************************************************************************************************************************************/ 

	DELETE FROM TB_DPD_ITEM_HIER_CLOSURE;

    INSERT INTO TB_DPD_ITEM_HIER_CLOSURE 
		 ( ANCESTER_ID
		 , ANCESTER_CD
		 , ANCESTER_NM
--		 , ANCESTER_SEQ
		 , DESCENDANT_ID
		 , DESCENDANT_CD
		 , DESCENDANT_NM
--		 , DESCENDANT_SEQ
		 , DEPTH_NUM 
		 , LEAF_YN 
         , LV_TP_CD
         , USE_YN
 		  )
	WITH ITEM_HIER AS
	(SELECT IL.ID					AS DESCENDANT_ID 
		  , IL.ITEM_LV_CD			AS DESCENDANT_CD
		  , IL.ITEM_LV_NM			AS DESCENDANT_NM
		  , IL.PARENT_ITEM_LV_ID	AS ANCESTER_ID
		  , P.ITEM_LV_CD			AS ANCESTER_CD 
		  , P.ITEM_LV_NM			AS ANCESTER_NM 
		  , 'N'						AS LEAF_YN 
          , CL.LV_TP_ID
          , CC.CONF_CD AS LV_TP_CD
          , 'Y' AS USE_YN 
	   FROM TB_CM_ITEM_LEVEL_MGMT  IL
		    LEFT OUTER JOIN
			TB_CM_ITEM_LEVEL_MGMT P 
		 ON IL.PARENT_ITEM_LV_ID=P.ID 
		AND IL.ACTV_YN = 'Y' 
			INNER JOIN 
			TB_CM_LEVEL_MGMT CL
		 ON IL.LV_MGMT_ID = CL.ID 
		AND NVL(CL.DEL_YN,'N') = 'N'
		AND CL.ACTV_YN = 'Y'
	    AND IL.ACTV_YN = 'Y'
	    AND NVL(IL.DEL_YN,'N') = 'N'
			INNER JOIN 
			TB_CM_COMM_CONFIG CC
		 ON CL.LV_TP_ID = CC.ID            
			LEFT OUTER JOIN 
			TB_CM_LEVEL_MGMT PL
		 ON P.LV_MGMT_ID = PL.ID 
		AND NVL(PL.DEL_YN,'N') = 'N'
		AND PL.ACTV_YN = 'Y'
	    AND P.ACTV_YN = 'Y'
	    AND NVL(P.DEL_YN,'N') = 'N'
	)
	SELECT DESCENDANT_ID
		 , DESCENDANT_CD
         , DESCENDANT_NM         
		 , DESCENDANT_ID
		 , DESCENDANT_CD
		 , DESCENDANT_NM 
		 , 0				AS DEPTH_NUM  
		 , LEAF_YN				AS LEAF_YN
         , LV_TP_CD
         , USE_YN 
	   FROM ITEM_HIER
	  WHERE DESCENDANT_ID IS NOT NULL	   
	   ;

    FOR CLOSURE_LOOP IN CUR_LOOP LOOP
    P_TMP_CNT := 1;  
    -- (1) 상하위 계층 다 Item 정보를 level type에 따라 만들어주기        
	P_SQL := ' SELECT I.ID'
			||'	 , I.ITEM_CD' 
			||'	 , I.ITEM_NM' 
			||'	 , I.ID'
			||'	 , I.ITEM_CD' 
			||'	 , I.ITEM_NM' 
			||'  , 0' 
			||'	 , ''Y'' AS LEAF_YN'
			||'  , CASE WHEN COALESCE(I.DP_PLAN_YN,''N'') = ''N'' OR COALESCE(I.DEL_YN,''N'') = ''Y'' OR P.ACTV_YN = ''N'' OR COALESCE(P.DEL_YN,''N'') = ''Y'' THEN ''N''  ELSE ''Y'' END AS USE_YN' 
--			||'	 , PL.LV_TP_ID'
			||'	 , CC.CONF_CD AS LV_TP_CD'
			||' FROM TB_CM_ITEM_MST I'
			||' 	 INNER JOIN'
			||'      TB_CM_ITEM_LEVEL_MGMT P'
			||'	  ON I.'||CLOSURE_LOOP.LV_TP_COL||'=P.ID'	-- PARENT_ITEM_LV_ID
			||'		 INNER JOIN 	'
			||'		 TB_CM_LEVEL_MGMT PL'
			||'	  ON P.LV_MGMT_ID = PL.ID'
			||'	 AND NVL(PL.DEL_YN,''N'') = ''N'''
			||'	 AND PL.ACTV_YN = ''Y'''
			||'		 INNER JOIN'
			||'		 TB_CM_COMM_CONFIG CC'
			||'	  ON PL.LV_TP_ID = CC.ID '
			||'WHERE I.PARENT_ITEM_LV_ID IS NOT NULL'
		;				

	P_SQL := 'INSERT INTO TB_DPD_ITEM_HIER_CLOSURE '
            ||'(ANCESTER_ID '
            ||',ANCESTER_CD '
            ||',ANCESTER_NM '            
            ||',DESCENDANT_ID '
            ||',DESCENDANT_CD '
            ||',DESCENDANT_NM '
            ||',DEPTH_NUM '
            ||',LEAF_YN '
            ||',USE_YN '
            ||',LV_TP_CD ' 
            ||')'
            ||P_SQL
            ;

        DBMS_OUTPUT.PUT_LINE(P_SQL);
        EXECUTE IMMEDIATE  P_SQL;

	WHILE P_TMP_CNT <= CLOSURE_LOOP.LV_CNT
	LOOP
				P_SQL := ' SELECT C.ANCESTER_ID	'
				||'	  , C.ANCESTER_CD '
				||'	  , C.ANCESTER_NM '
				||'	  , H.ID		'
				||'	  , H.ITEM_CD 	'
				||'	  , H.ITEM_NM 	'
				||'	  , '||TO_CHAR(P_TMP_CNT)||'	AS DEPTH_NUM'
				||'	  , H.LEAF_YN 	'
				||'	  , H.USE_YN 	'
				||'	  ,'''||CLOSURE_LOOP.LV_TP_CD||''''
				||' FROM TB_DPD_ITEM_HIER_CLOSURE C '
				||'		 INNER JOIN '
				||'		(SELECT IL.ID'
				||'			  , IL.ITEM_LV_CD AS ITEM_CD'
				||'			  , IL.ITEM_LV_CD AS ITEM_NM'
				||'			  , IL.PARENT_ITEM_LV_ID' 
				||'			  , ''N''		AS LEAF_YN'
                ||'           , CASE WHEN  IL.ACTV_YN = ''N'' OR NVL(IL.DEL_YN,''N'') = ''Y'' THEN ''N'' ELSE ''Y'' END AS USE_YN'
				||'		   FROM TB_CM_ITEM_LEVEL_MGMT IL'
				||'				INNER JOIN 	'
				||'				TB_CM_LEVEL_MGMT CL'
				||'			 ON IL.LV_MGMT_ID = CL.ID '
				||'			AND NVL(CL.DEL_YN,''N'') = ''N'''
				||'			AND CL.ACTV_YN = ''Y'''
				||'		  WHERE CL.LV_TP_ID = '''||CLOSURE_LOOP.LV_TP_ID||''''
				||'		  UNION ALL'
				||'		 SELECT ID'
				||'			  , ITEM_CD    AS ITEM_CD'
				||'			  , ITEM_CD    AS ITEM_NM'
				||'			  , '||CLOSURE_LOOP.LV_TP_COL	-- AS PARENT_ITEM_LV_ID
				||'			  , ''Y'' AS LEAF_YN'
                ||'           , CASE WHEN NVL(DEL_YN,''N'') = ''Y'' OR NVL(DP_PLAN_YN,''N'') = ''N'' THEN ''N'' ELSE ''Y'' END AS USE_YN'
				||'		   FROM TB_CM_ITEM_MST'
				||'		  WHERE '||CLOSURE_LOOP.LV_TP_COL||' IS NOT NULL' -- PARENT_ITEM_LV_ID
				||'			AND PARENT_ITEM_LV_ID IS NOT NULL'
				||'	 ) H '
				||'	ON (C.DESCENDANT_ID = H.PARENT_ITEM_LV_ID '
				|| 'AND C.DEPTH_NUM = '|| TO_CHAR(P_TMP_CNT-1)||')'
				;

				 P_SQL :='INSERT INTO TB_DPD_ITEM_HIER_CLOSURE'
					||'(ANCESTER_ID'
					||',ANCESTER_CD'
					||',ANCESTER_NM'
					||',DESCENDANT_ID'
					||',DESCENDANT_CD'
					||',DESCENDANT_NM'
					||',DEPTH_NUM'
					||',LEAF_YN '
					||',USE_YN'
					||',LV_TP_CD'
					||' )' || P_SQL
                    ;

            DBMS_OUTPUT.PUT_LINE(P_SQL);

		 EXECUTE IMMEDIATE  P_SQL;

            P_TMP_CNT := P_TMP_CNT+1
            ;
        END LOOP;
        DBMS_OUTPUT.PUT_LINE('WHILE END');
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('END LOOP');    


/***********************************************************************************************************************************************
	CREATE TB_DPD_ITEM_HIERARCHY2
************************************************************************************************************************************************/
    DBMS_OUTPUT.PUT_LINE('CREATE TB_DPD_ACCOUNT_HIERACHY2');
    DELETE FROM TB_DPD_ITEM_HIERACHY2;
    FOR LOOP_HIERACHY2 IN CUR_LOOP 
    LOOP    
    INSERT INTO TB_DPD_ITEM_HIERACHY2
    (
          LVL01_ID
        , LVL02_ID
        , LVL03_ID
        , LVL04_ID
        , LVL05_ID
        , LVL06_ID
        , LVL07_ID
        , LVL08_ID
        , LVL09_ID
        , LVL10_ID
        , LVL01_CD
        , LVL02_CD
        , LVL03_CD
        , LVL04_CD
        , LVL05_CD
        , LVL06_CD
        , LVL07_CD
        , LVL08_CD
        , LVL09_CD
        , LVL10_CD
        , LVL01_NM
        , LVL02_NM
        , LVL03_NM
        , LVL04_NM
        , LVL05_NM
        , LVL06_NM
        , LVL07_NM
        , LVL08_NM
        , LVL09_NM
        , LVL10_NM
        , ITEM_ID
        , ITEM_CD
        , ITEM_NM	 
        , RTS
        , EOS
        , UOM
        , ITEM_TP
        , DESCRIP 	
        , GRADE
        , COV 
        , ATTR_01
        , ATTR_02
        , ATTR_03
        , ATTR_04
        , ATTR_05
        , ATTR_06
        , ATTR_07
        , ATTR_08
        , ATTR_09
        , ATTR_10
        , ATTR_11
        , ATTR_12
        , ATTR_13
        , ATTR_14
        , ATTR_15
        , ATTR_16
        , ATTR_17
        , ATTR_18
        , ATTR_19
        , ATTR_20
        , LV_TP_CD
        , USE_YN         
    )
    WITH ITEM_HIER 
     AS (
        SELECT ANCESTER_ID  
             , ANCESTER_CD
             , COALESCE(IL.ITEM_LV_NM, CAST(IT.ITEM_NM AS VARCHAR2(255))) AS ANCESTER_NM
             , DESCENDANT_ID 
             , DESCENDANT_CD
             , 'LVL'|| LPAD( DENSE_RANK () OVER ( ORDER BY DEPTH_NUM DESC ), 2, '0')  AS COL
             , USE_YN 
          FROM TB_DPD_ITEM_HIER_CLOSURE IH 
               LEFT OUTER JOIN 
               TB_CM_ITEM_LEVEL_MGMT IL 
            ON IH.ANCESTER_ID = IL.ID 
              LEFT OUTER JOIN 
              TB_CM_ITEM_MST IT
           ON IH.ANCESTER_ID = IT.ID 
         WHERE IH.LEAF_YN = 'Y' 
          AND IH.LV_TP_CD = LOOP_HIERACHY2.LV_TP_CD
       )
    SELECT  LVL01_ID
          , LVL02_ID
          , LVL03_ID
          , LVL04_ID
          , LVL05_ID
          , LVL06_ID
          , LVL07_ID
          , LVL08_ID
          , LVL09_ID
          , LVL10_ID
          , LVL01_CD
          , LVL02_CD
          , LVL03_CD
          , LVL04_CD
          , LVL05_CD
          , LVL06_CD
          , LVL07_CD
          , LVL08_CD
          , LVL09_CD
          , LVL10_CD
          , LVL01_NM
          , LVL02_NM
          , LVL03_NM
          , LVL04_NM
          , LVL05_NM
          , LVL06_NM
          , LVL07_NM
          , LVL08_NM
          , LVL09_NM
          , LVL10_NM
          , DESCENDANT_ID			AS ITEM_ID
          , DESCENDANT_CD			AS ITEM_CD
          , IM.ITEM_NM 
          , IM.RTS
          , IM.EOS
          , UM.UOM_CD
          , TP.ITEM_TP
          , IM.DESCRIP 	
          , GRADE
         , COV 
          , IM.ATTR_01
          , IM.ATTR_02
          , IM.ATTR_03
          , IM.ATTR_04
          , IM.ATTR_05
          , IM.ATTR_06
          , IM.ATTR_07
          , IM.ATTR_08
          , IM.ATTR_09
          , IM.ATTR_10
          , IM.ATTR_11
          , IM.ATTR_12
          , IM.ATTR_13
          , IM.ATTR_14
          , IM.ATTR_15
          , IM.ATTR_16
          , IM.ATTR_17
          , IM.ATTR_18
          , IM.ATTR_19
          , IM.ATTR_20
          , LOOP_HIERACHY2.LV_TP_CD
          , SH.USE_YN AS USE_YN     --CASE WHEN IM.DP_PLAN_YN = 'Y' AND COALESCE(IM.DEL_YN,'N') = 'N' THEN 'Y' ELSE 'N' END       
      FROM ITEM_HIER SH
           PIVOT (MAX(ANCESTER_ID) AS ID, MAX(ANCESTER_CD) AS CD, MAX(ANCESTER_NM) AS NM FOR COL IN ('LVL01' AS LVL01	
                                            , 'LVL02' AS LVL02
                                            , 'LVL03' AS LVL03
                                            , 'LVL04' AS LVL04
                                            , 'LVL05' AS LVL05
                                            , 'LVL06' AS LVL06
                                            , 'LVL07' AS LVL07
                                            , 'LVL08' AS LVL08
                                            , 'LVL09' AS LVL09
                                            , 'LVL10' AS LVL10)
                                            )  SH
           INNER JOIN
           TB_CM_ITEM_MST IM
        ON SH.DESCENDANT_ID = IM.ID 
           LEFT OUTER JOIN 
           TB_CM_UOM UM
        ON IM.UOM_ID = UM.ID 
           LEFT OUTER JOIN 
           TB_CM_ITEM_TYPE TP
        ON IM.ITEM_TP_ID = TP.ID 
    WHERE LVL01_ID IS NOT NULL
    ; 

 END LOOP;

	 SELECT MIN(RTS)
		  , MAX(EOS) + 32
         INTO P_MIN_RTS, P_MAX_EOS
	   FROM TB_CM_ITEM_MST 
	 ; 
    FOR LOOP_PLAN_TP IN PLAN_TP_LOOP 
    LOOP    
        INSERT INTO TEMP_CALENDAR ( STRT_DATE, END_DATE)
		   SELECT  MIN(DAT)  AS STRT_DATE
				 , MAX(DAT)	 AS END_DATE
			  FROM TB_CM_CALENDAR
			 WHERE DAT BETWEEN P_MIN_RTS AND P_MAX_EOS
		  GROUP BY CASE LOOP_PLAN_TP.BUKT  
                     WHEN 'M'  THEN YYYYMM
                     WHEN 'PW' THEN MM||'-'||DP_WK 
                     WHEN 'W'  THEN DP_WK 
                     WHEN 'Y'  THEN YYYY 
                     WHEN 'Q'  THEN YYYY||'-'||CAST(QTR AS CHAR(1))
					END
					;	        
		IF (LOOP_PLAN_TP.PLAN_TP_ATTR = 'Y')
			THEN                
				UPDATE TB_DPD_ITEM_HIERACHY2 H
				  SET H.RTS_Y = (SELECT CAL.STRT_DATE 
                                   FROM TEMP_CALENDAR CAL
                                  WHERE H.RTS BETWEEN CAL.STRT_DATE AND CAL.END_DATE 
                                 ) 
				WHERE H.RTS IS NOT NULL  
				  ;
				 
				UPDATE TB_DPD_ITEM_HIERACHY2 H
				  SET H.EOS_Y = ( SELECT CAL.END_DATE 
                                   FROM TEMP_CALENDAR CAL 
                                  WHERE H.EOS BETWEEN CAL.STRT_DATE AND CAL.END_DATE 
                                 )
                WHERE H.EOS IS NOT NULL
				  ;
				  
		ELSE 
				UPDATE TB_DPD_ITEM_HIERACHY2 H
				  SET H.RTS = (SELECT CAL.STRT_DATE 
                                 FROM TEMP_CALENDAR CAL
                                WHERE H.RTS BETWEEN CAL.STRT_DATE AND CAL.END_DATE 
                               )
				WHERE H.RTS IS NOT NULL  
				  ;
				 
				UPDATE TB_DPD_ITEM_HIERACHY2 H 
				  SET H.EOS = (SELECT CAL.END_DATE 
                               FROM TEMP_CALENDAR CAL 
                              WHERE H.EOS BETWEEN CAL.STRT_DATE AND CAL.END_DATE 
                             ) 
				WHERE H.EOS IS NOT NULL 
				  ;
				  
         END IF
         ;  
        DELETE FROM TEMP_CALENDAR;
    END LOOP 
    ;

END
;
/

