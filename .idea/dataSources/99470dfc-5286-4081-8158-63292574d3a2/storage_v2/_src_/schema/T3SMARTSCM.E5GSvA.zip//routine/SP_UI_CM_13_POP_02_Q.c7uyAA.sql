create PROCEDURE "SP_UI_CM_13_POP_02_Q" (
    P_SRC_ID                IN VARCHAR2:='' ,
    pResult OUT SYS_REFCURSOR
)IS
BEGIN	
	OPEN pResult FOR
        SELECT B.WAREHOUSE_TP_ID
			 , B.WAREHOUSE_NM           AS WAREHOUSE_TP_NM
			 , B.ID                     AS ID
			 , B.LOCAT_MGMT_ID          AS LOCAT_MGMT_ID
			 , A.ID                     AS WH_MGMT_DTL_ID
             , C.LOAD_CAPA_MGMT_BASE AS LOAD_CAPA_MGMT_BASE
			 , A.PALLET_LAYER
			 , A.LIMIT_VAL
			 , A.CREATE_BY
			 , A.CREATE_DTTM
			 , A.MODIFY_BY
			 , A.MODIFY_DTTM
		  FROM TB_CM_SITE_WH_MGMT_DTL A 
            INNER JOIN TB_CM_SITE_WAREHOUSE_MGMT B
              ON B.ID = A.SITE_WAREHOUSE_MGMT_ID
            INNER JOIN TB_CM_WAREHOUSE_TYPE C
                ON B.WAREHOUSE_TP_ID = C.ID
		 WHERE 1=1
		   AND B.ID = P_SRC_ID;  

END;


/

