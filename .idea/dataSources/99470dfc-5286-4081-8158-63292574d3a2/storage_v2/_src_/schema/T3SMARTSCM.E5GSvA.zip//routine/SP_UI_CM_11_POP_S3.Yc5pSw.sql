create PROCEDURE SP_UI_CM_11_POP_S3 (
     P_GLOBAL_PLAN_BOM_ID			  IN CHAR := ''
    ,P_RT_ROLLBACK_FLAG             OUT VARCHAR2
    ,P_RT_MSG                       OUT VARCHAR2 
)
IS
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG  VARCHAR2(4000) :='';

BEGIN
    UPDATE TB_CM_GLOBAL_PLAN_BOM
    SET ACTV_YN = 'N'
    WHERE ID = P_GLOBAL_PLAN_BOM_ID;
    
    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0002';

EXCEPTION
    WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;   
      ELSE
         RAISE;
      END IF;
END;

/

