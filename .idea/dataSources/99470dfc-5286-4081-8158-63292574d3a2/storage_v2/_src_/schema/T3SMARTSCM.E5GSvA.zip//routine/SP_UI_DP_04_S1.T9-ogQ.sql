create PROCEDURE                "SP_UI_DP_04_S1" (
    P_ID				IN  VARCHAR2    := NULL
  , p_CUST_CD           IN  VARCHAR2    := NULL         
  , p_CUST_NM           IN  VARCHAR2    := NULL         
  , p_COUNTRY_CD        IN  VARCHAR2    := NULL      
  , p_ADDR              IN  VARCHAR2    := NULL   -- cast(p_SEQ AS int)   AS  SEQ
  , p_USER_ID           IN  VARCHAR2         
  , P_RT_ROLLBACK_FLAG  OUT VARCHAR2 
  , P_RT_MSG            OUT VARCHAR2 										    
) 
IS 
       P_ERR_STATUS INT := 0;
       P_ERR_MSG VARCHAR2(4000):='';
       p_COUNTRY_ID VARCHAR2(32);

BEGIN 
    P_RT_ROLLBACK_FLAG := 'true';
/**** VALIDATION *********************************************************************************************************************************************************************/

    IF (    p_CUST_CD       IS NULL
        AND p_CUST_NM       IS NULL
        AND p_COUNTRY_CD    IS NULL
        AND p_ADDR          IS NULL) THEN
        P_ERR_MSG := 'MSG_0006';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);  
    END IF;

    IF(p_CUST_CD IS NULL) THEN
        P_ERR_MSG := 'MSG_5027';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);      
    END IF;

/*** CUSTOMER CODE *****************************************************************************************************************************************************************/
--SELECT P_ERR_STATUS = COUNT(*) FROM TB_CM_CUSTOMER WHERE ID = P_ID
--IF(P_ERR_STATUS=0)
--	BEGIN
	SELECT COUNT(CUST_CD) INTO P_ERR_STATUS
	  FROM TB_CM_CUSTOMER
	 WHERE 1=1
	   AND CUST_CD = p_CUST_CD
	   AND ID != P_ID;

	IF (P_ERR_STATUS >=1) THEN
	   P_ERR_MSG := 'MSG_5028'; 
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);                 
    END IF;
--	END
/*** COUNTRY CODE TO ID *****************************************************************************************************************************************************************/
    IF(p_COUNTRY_CD IS NOT NULL) THEN
	   SELECT A.ID INTO p_COUNTRY_ID
		 FROM TB_CM_COMM_CONFIG A
		WHERE conf_grp_cd = 'CM_COUNTRY'
	      AND A.CONF_CD = p_COUNTRY_CD;

    ELSE
	   p_COUNTRY_ID := NULL;
    END IF;

	MERGE INTO TB_CM_CUSTOMER TGT
	USING ( SELECT
			 p_CUST_CD       AS CUST_CD    
			,p_CUST_NM     	 AS CUST_NM    
			,p_COUNTRY_ID  	 AS COUNTRY_ID 
			,p_ADDR        	 AS ADDR       
			,p_USER_ID     	 AS USER_ID    
		    FROM dual 
          ) SRC
	ON    ( TGT.CUST_CD = SRC.CUST_CD )
	WHEN MATCHED THEN
		 UPDATE 
		   SET   TGT.CUST_NM      = SRC.CUST_NM   
				,TGT.COUNTRY_ID   = SRC.COUNTRY_ID
				,TGT.ADDR         = SRC.ADDR       
				,TGT. MODIFY_BY   = SRC.USER_ID       
				,TGT.MODIFY_DTTM  = SYSDATE
	WHEN NOT MATCHED THEN 
		 INSERT ( ID
		        , CUST_CD    
				, CUST_NM    
				, COUNTRY_ID 
				, ADDR       
				, CREATE_BY
				, CREATE_DTTM
				) 
		 VALUES (
				  TO_SINGLE_BYTE(SYS_GUID())
		        , SRC.CUST_CD    
				, SRC.CUST_NM    
				, SRC.COUNTRY_ID 
				, SRC.ADDR       
				, SRC.USER_ID 
				, SYSDATE
				) 
	;

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';  --
       /* ============================================================================*/
EXCEPTION WHEN OTHERS THEN  -- e_products_invalid    
    IF(SQLCODE = -20001) THEN
        P_ERR_MSG := SQLERRM;
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
    ELSE
    --SP_COMM_RAISE_ERR();
        RAISE;
    END IF;
END;
/

