create PROCEDURE SP_UI_DP_93_CUTOFF (
	 p_VERSION_CD		VARCHAR2
	,p_CUTOFF_VER_CD	VARCHAR2
	,p_USER_ID			VARCHAR2
	,p_CL_LV_MGMT_ID	CHAR
	,p_CL_TP_CD		    VARCHAR2
)IS
 
p_TO_DATE		DATE;
p_PRICE_TP_ID	CHAR(32);
p_VERSION_ID	CHAR(32);
p_DMND_TP_ID	CHAR(32);

BEGIN
/*************************************************************************************************
	-- Get Version Info
*************************************************************************************************/
	SELECT TO_DATE
		  ,PRICE_TP_ID
		  ,ID
           INTO
           p_TO_DATE
         , p_PRICE_TP_ID
         , p_VERSION_ID
	  FROM TB_DP_CONTROL_BOARD_VER_MST 
	 WHERE VER_ID = p_VERSION_CD
	 ;

	UPDATE TB_DP_ENTRY
	   SET AMT = QTY * (
            SELECT UTPIC
              FROM (
                SELECT ITEM_MST_ID
                      ,ACCOUNT_ID
                      ,BASE_DATE	AS STRT_DATE 
                      ,COALESCE(LEAD(BASE_DATE) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID ORDER BY  BASE_DATE )-1,p_TO_DATE)	AS END_DATE  
                      ,UTPIC
                  FROM TB_DP_UNIT_PRICE UP
                 WHERE BASE_DATE <= p_TO_DATE 
                   AND PRICE_TP_ID = p_PRICE_TP_ID
             ) UP
            WHERE ITEM_MST_ID = UP.ITEM_MST_ID  
              AND ACCOUNT_ID = UP.ACCOUNT_ID
              AND BASE_DATE BETWEEN UP.STRT_DATE  AND UP.END_DATE 
    ) 
	;	   		   


	if (p_CL_TP_CD != 'SRP' )
    THEN
		 --TB_DP_ENTRY_CUTOFF
		 insert into TB_DP_ENTRY_CUTOFF (ID,PLAN_TP_ID, VER_ID, CUTOFF_VER_CD, AUTH_TP_ID, ITEM_MST_ID, ACCOUNT_ID, EMP_ID, BASE_DATE, QTY, QTY_1, QTY_2, QTY_3, AMT, AMT_1, AMT_2, AMT_3, CREATE_BY, CREATE_DTTM)
		 select TO_SINGLE_BYTE(SYS_GUID()),PLAN_TP_ID, VER_ID,  p_CUTOFF_VER_CD as CUTOFF_VER_CD, AUTH_TP_ID, ITEM_MST_ID, ACCOUNT_ID,EMP_ID, BASE_DATE, QTY, QTY_1, QTY_2, QTY_3, AMT, AMT_1, AMT_2, AMT_3, p_USER_ID as  CREATE_BY, SYSDATE
		   from TB_DP_ENTRY 
		  where AUTH_TP_ID = p_CL_LV_MGMT_ID and VER_ID = p_VERSION_ID
         ;
	/*********************************************************************************************************
		-- Cutoff : Transfer a result for Demand Overview or Forecast of Sales RP
	*********************************************************************************************************/
			-- GET DMND_TP_ID
        SELECT B.ID INTO p_DMND_TP_ID
          FROM TB_AD_COMN_GRP A
              ,TB_AD_COMN_CODE B
         WHERE 1=1
           AND A.ID = B.SRC_ID
           AND A.GRP_CD = 'DEMAND_TYPE'
           AND COMN_CD_NM = 'Forecast'
           ;

		-- DELETE DEMAND_OVERVIEW
		DELETE FROM TB_CM_DEMAND_OVERVIEW
		  WHERE T3SERIES_VER_ID = p_VERSION_CD
        ;
		-- INSERT DEMAND_OVERVIEW 
		INSERT INTO TB_CM_DEMAND_OVERVIEW
				   (   ID
					 , MODULE_VAL
--					 , YYYYMMDD
--					 , MAIN_VER
--					 , REVISION_VER
					 , T3SERIES_VER_ID
					 , CONFRM_YN
					 , FINAL_CONFRM_YN
					 , DMND_ID
					 , DMND_TP_ID
					 , DMND_CLASS_ID
					 , ITEM_MST_ID
--					 , URGENT_ORDER_TP_ID
					 , DMND_QTY
					 , UOM_ID
					 , DUE_DATE
--					 , REQUEST_SITE_ID
					 , ACCOUNT_ID
					 , SALES_UNIT_PRIC
--					 , MARGIN
					 , CURCY_CD_ID
--					 , BOD_LEADTIME
--					 , TIME_UOM_ID
--					 , PRDUCT_DELIVY_DATE
--					 , ASSIGN_SITE_CNT
--					 , ASSIGN_RES_CNT
					 , DELIVY_PLAN_POLICY_CD_ID
					 , MAT_CONST_CD_ID
					 , EFFICY
					 , PARTIAL_PLAN_YN
					 , COST_OPTIMIZ_YN
--					 , PST
					 , DUE_DATE_FNC
--					 , DELIVY_DATE
--					 , DAYS_LATE
--					 , PLAN_QTY
--					 , LATE_QTY
--					 , DELIVY_QTY
--					 , ON_TIME_QTY
--					 , SHRT_QTY
					 , ACTV_YN
					 , CREATE_BY
					 , CREATE_DTTM
--					 , MODIFY_BY
--					 , MODIFY_DTTM
--					 , DESCRIP
--					 , NETTING_QTY
--					 , FORECAST_ID
--					 , FORECAST_QTY
--					 , SRC_DMND_ID
--					 , DMND_LOCAT_ID
--					 , HEURISTIC_YN
--					 , STRATEGY_METHD_ID
--					 , DISPLAY_COLOR
					)
				SELECT TO_SINGLE_BYTE(SYS_GUID())												ID
					 , 'DP'																		MODULE_VAL
		--			 , NULL																		YYYYMMDD
		--			 , NULL																		MAIN_VER
		--			 , NULL																		REVISION_VER
					 , p_VERSION_CD																T3SERIES_VER_ID
					 , 'Y'																		CONFRM_YN
					 , 'Y'																		FINAL_CONFRM_YN
					 --, 'DMND_' + REPLICATE('0', 15-LEN(CONVERT(VARCHAR2(15), ROW_NUMBER() OVER (ORDER BY DE.ID)))) + CONVERT(VARCHAR2(15), ROW_NUMBER() OVER (ORDER BY DE.ID))				DMND_ID
                     , 'DMND_' || LPAD(CAST(ROW_NUMBER() OVER (ORDER BY DE.ID) AS VARCHAR2(15)), 15, '0') DMND_ID
					 , p_DMND_TP_ID					   									    DMND_TP_ID
					 , (SELECT B.ID 
						  FROM TB_AD_COMN_GRP A
						      ,TB_AD_COMN_CODE B
						 WHERE 1=1
						   AND A.ID = B.SRC_ID
						   AND A.GRP_CD = 'DEMAND_CLASS'
						   AND COMN_CD = 'NEW')													DMND_CLASS_ID
					 , ITEM_MST_ID
		--			 , NULL																		URGENT_ORDER_TP_ID
					 , QTY																		DMND_QTY
					 , IT.UOM_ID																UOM_ID
					 , BASE_DATE																DUE_DATE
		--			 , REQUEST_SITE_ID
					 , ACCOUNT_ID
					 , AMT/QTY																	SALES_UNIT_PRIC
		--			 , MARGIN
					 , AC.CURCY_CD_ID															CURCY_CD_ID
		--			 , BOD_LEADTIME
		--			 , TIME_UOM_ID
		--			 , PRDUCT_DELIVY_DATE
		--			 , ASSIGN_SITE_CNT
		--			 , ASSIGN_RES_CNT
					 , (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'CM_BASE_ORD_DELIV_POLICY'
						   AND DEFAT_VAL = 'Y'			 
					   )																		DELIVY_PLAN_POLICY_CD_ID
					 , (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'MP_ORD_CAPA_MAT_COST'
						   AND DEFAT_VAL = 'Y')													MAT_CONST_CD_ID
					 , (SELECT CONF_CD  FROM TB_CM_COMM_CONFIG
					     WHERE CONF_GRP_CD = 'MP_BASE_EFFCIENCY')								EFFICY
					 , (SELECT CASE WHEN CONF_CD = 'TRUE' then 'Y' else 'N'  end FROM TB_CM_COMM_CONFIG
						 WHERE CONF_GRP_CD = 'MP_ORD_PARTIAL_PLN')								PARTIAL_PLAN_YN
					 , (SELECT (CASE WHEN CONF_CD = 'TRUE' then 'Y' else 'N'  end) FROM TB_CM_COMM_CONFIG
						 WHERE CONF_GRP_CD = 'CM_ORD_ROUT_COST_OPT')							COST_OPTIMIZ_YN
		--			 , PST
					 , ( SELECT CASE B.UOM_CD
									 --WHEN 'DAY'   THEN DATEADD(DD, CAST(A.CATAGY_VAL AS NUMERIC), BASE_DATE)   
									 --WHEN 'WEEK'  THEN DATEADD(WK, CAST(A.CATAGY_VAL AS NUMERIC), BASE_DATE)    
									 --WHEN 'MONTH' THEN DATEADD(MM, CAST(A.CATAGY_VAL AS NUMERIC), BASE_DATE)   
									 --WHEN 'YEAR'  THEN DATEADD(YY, CAST(A.CATAGY_VAL AS NUMERIC), BASE_DATE)    
                                     WHEN 'DAY'   THEN BASE_DATE + CAST(A.CATAGY_VAL AS NUMERIC)
									 WHEN 'WEEK'  THEN BASE_DATE + CAST(A.CATAGY_VAL AS NUMERIC) * 7
									 WHEN 'MONTH' THEN ADD_MONTHS(BASE_DATE, CAST(A.CATAGY_VAL AS NUMERIC))
									 WHEN 'YEAR'  THEN ADD_MONTHS(BASE_DATE, CAST(A.CATAGY_VAL AS NUMERIC)*12 )
								END			 
						  FROM TB_CM_BASE_ORDER A
							   INNER JOIN
						       TB_CM_UOM B
						    ON A.CATAGY_CD = 'BASE_ORDER_DUE_DATE_FENCE'
						   AND A.UOM_ID = B.ID AND  A.ACTV_YN = 'Y' )						    DUE_DATE_FNC
		--			 , DELIVY_DATE
		--			 , DAYS_LATE
		--			 , PLAN_QTY
		--			 , LATE_QTY
		--			 , DELIVY_QTY
		--			 , ON_TIME_QTY
		--			 , SHRT_QTY
					 , CASE WHEN p_DMND_TP_ID IS NULL THEN 'N' ELSE 'Y' END					ACTV_YN
					 , p_USER_ID																CREATE_BY
					 , SYSDATE																CREATE_DTTM
		--			 , NULL																		MODIFY_BY
		--			 , NULL																		MODIFY_DTTM
		--			 , DESCRIP
		--			 , NETTING_QTY
		--			 , FORECAST_ID
		--			 , FORECAST_QTY
		--			 , SRC_DMND_ID
		--			 , DMND_LOCAT_ID
		--			 , HEURISTIC_YN
		--			 , STRATEGY_METHD_ID
		--			 , DISPLAY_COLOR
			      FROM TB_DP_ENTRY  DE
					   INNER JOIN
					   TB_CM_ITEM_MST IT 
					ON DE.ITEM_MST_ID = IT.ID 
					   INNER JOIN
					   TB_DP_ACCOUNT_MST AC
					ON AC.id = DE.ACCOUNT_ID
				 WHERE VER_ID =  p_VERSION_ID  
				   AND AUTH_TP_ID = p_CL_LV_MGMT_ID
				   ;		    			   
		END IF;

END;
/

