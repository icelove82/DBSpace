create PROCEDURE                "SP_UI_DP_00_POPUP_ACC_TREE_Q1" (
    p_USER_ID           VARCHAR2    := NULL	
  , p_AUTH_TP_ID        CHAR        := NULL 
  , p_ACCT_CD       IN  VARCHAR2    := ''
  , p_ACCT_NM       IN  VARCHAR2    := ''
  , p_ACCT_LV       IN  VARCHAR2    := ''
  , p_LV_TP_CD      IN  VARCHAR2    := ''
  , pRESULT         OUT SYS_REFCURSOR
) IS 

/*************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 
    - 2021.12.13 / Kim sohee / get data by using DPD table (for performance)    
************************************************************************/
    P_EMP_ID    CHAR(32);
    p_CNT       INT;
    P_USER_ACCT_CNT INT := 0;
    P_MGR_SALES_CNT INT := 0; 
    V_ACCT_LV    VARCHAR2(100)   := P_ACCT_LV;
    V_LV_TP_CD    VARCHAR2(100)   := COALESCE(p_LV_TP_CD, 'S');
BEGIN

-- get Employee ID
    SELECT COUNT(ID)
      INTO P_CNT
      FROM TB_AD_USER
     WHERE USERNAME = P_USER_ID;

    IF P_CNT != 0 THEN
        SELECT ID INTO P_EMP_ID
          FROM TB_AD_USER
         WHERE USERNAME = P_USER_ID;
    END IF;

    IF V_LV_TP_CD is null or V_LV_TP_CD = '' THEN 
        V_LV_TP_CD := 'S';
    END IF;
    
    
-- Check the number of user account mapping data    
    SELECT COUNT(EMP_ID) INTO P_USER_ACCT_CNT
      FROM TB_DP_USER_ACCOUNT_MAP UA
           INNER JOIN
           TB_DP_ACCOUNT_MST AC
        ON AC.ID = UA.ACCOUNT_ID
       AND AC.DEL_YN != 'Y'
       AND AC.ACTV_YN = 'Y'
     WHERE AUTH_TP_ID = P_AUTH_TP_ID
       AND EMP_ID = P_EMP_ID
    ;
    SELECT P_USER_ACCT_CNT + COUNT(EMP_ID) INTO P_USER_ACCT_CNT
      FROM TB_DP_USER_ACCOUNT_MAP UA
           INNER JOIN
           TB_DP_SALES_LEVEL_MGMT SL
        ON SL.ID = UA.SALES_LV_ID
       AND SL.DEL_YN != 'Y'
       AND SL.ACTV_YN = 'Y'
     WHERE AUTH_TP_ID = P_AUTH_TP_ID
       AND EMP_ID = P_EMP_ID
    ;
    SELECT P_USER_ACCT_CNT+COUNT(EMP_ID) INTO P_USER_ACCT_CNT
      FROM TB_DP_USER_ITEM_ACCOUNT_MAP UA
           INNER JOIN
           TB_DP_ACCOUNT_MST AC
        ON AC.ID = UA.ACCOUNT_ID
       AND AC.DEL_YN != 'Y'
       AND AC.ACTV_YN = 'Y'
     WHERE EMP_ID = P_EMP_ID
       AND AUTH_TP_ID = P_AUTH_TP_ID
    ;
-- Check the number of user sales mapping data
    SELECT COUNT(1) INTO P_MGR_SALES_CNT
      FROM TB_DP_SALES_AUTH_MAP SA
           INNER JOIN  
           TB_DP_SALES_LEVEL_MGMT SL 
        ON SA.SALES_LV_ID = SL.ID 
     WHERE SA.EMP_ID = P_EMP_ID
       AND SL.LV_MGMT_ID = p_AUTH_TP_ID
       AND SYSDATE BETWEEN COALESCE(STRT_DATE_AUTH,SYSDATE) AND COALESCE(END_DATE_AUTH, SYSDATE)
       ;
-- convert null to top level
IF (P_ACCT_LV IS NULL)       
    THEN
    SELECT SALES_LV_CD INTO V_ACCT_LV
      FROM TB_DP_SALES_LEVEL_MGMT SL
           INNER JOIN 
           TB_CM_LEVEL_MGMT LV 
        ON SL.LV_MGMT_ID = LV.ID 
           INNER JOIN
           TB_CM_COMM_CONFIG CC
        ON LV.LV_TP_ID = CC.ID
       AND CC.CONF_CD = V_LV_TP_CD
     WHERE SL.PARENT_SALES_LV_ID IS NULL		
       ;
    END IF
    ;       
/**************************************************************************************************************************
    -- MAIN PROCEDURE
**************************************************************************************************************************/
    IF (P_USER_ACCT_CNT > 0)
    THEN
		-- Salesman Mapping (Only user mapping data)    
       OPEN pRESULT
        FOR
		WITH DP_LEVEL 
		  AS (
				SELECT LV.ID 
					 , LV.LEAF_YN
				  FROM TB_CM_LEVEL_MGMT LV
				       INNER JOIN 
					   TB_CM_COMM_CONFIG CC
					ON LV.LV_TP_ID = CC.ID
				 WHERE CC.CONF_CD = 'S'
				   AND LV.ACCOUNT_LV_YN = 'Y'
				   AND LV.ACTV_YN = 'Y'
				   AND COALESCE(LV.DEL_YN,'N') = 'N'
			 ), USER_MAP_ACCT_LV
		  AS ( SELECT DISTINCT SALES_LV_ID AS ID
				  FROM TB_DP_USER_ACCOUNT_MAP M
					   INNER JOIN 
					   DP_LEVEL L
					ON M.LV_MGMT_ID = L.ID 
				   AND COALESCE(L.LEAF_YN,'N') = 'N'
			     WHERE 1=1
				   AND M.AUTH_TP_ID = P_AUTH_TP_ID
				   AND M.EMP_ID = P_EMP_ID
				   AND M.ACTV_YN = 'Y' 
			 ), USER_MAP_ACCT
		  AS (
				SELECT DISTINCT ACCOUNT_ID AS ACCT_ID
				  FROM TB_DP_USER_ACCOUNT_MAP M
				       INNER JOIN 
					   DP_LEVEL L
					ON M.LV_MGMT_ID = L.ID 
				   AND L.LEAF_YN = 'Y'
				 WHERE M.EMP_ID = P_EMP_ID
				   AND M.AUTH_TP_ID = P_AUTH_TP_ID
				   AND M.ACTV_YN = 'Y'
				 UNION
				 SELECT DISTINCT ACCOUNT_ID
				   FROM TB_DP_USER_ITEM_ACCOUNT_MAP
				  WHERE EMP_ID = P_EMP_ID
				    AND AUTH_TP_ID = P_AUTH_TP_ID
					AND ACTV_YN = 'Y'
				 UNION
				 SELECT SH.DESCENDANT_ID
				   FROM USER_MAP_ACCT_LV AM
						INNER JOIN
						TB_DPD_SALES_HIER_CLOSURE SH	
					 ON AM.ID = SH.ANCESTER_ID
					AND USE_YN = 'Y'
					AND SH.LEAF_YN = 'Y'
                   
			) , SALES_HIER 
		  AS (	SELECT DISTINCT DESCENDANT_ID AS ID 
				  FROM TB_DPD_SALES_HIER_CLOSURE SH	
				 WHERE LEAF_YN = 'Y'
				   AND ANCESTER_CD = p_ACCT_LV 
				   AND USE_YN = 'Y'
				   --AND LV_TP_CD = 'S'
				UNION
				SELECT V_ACCT_LV
                  FROM DUAL 
				 WHERE p_ACCT_LV IS NULL
			)         
        SELECT AM.ID
             , AM.ACCOUNT_CD
             , AM.ACCOUNT_NM
             , AM.PARENT_SALES_LV_ID
             , SL.SALES_LV_CD       AS PARENT_SALES_LV_CD
             , SL.SALES_LV_NM       AS PARENT_SALES_LV_NM
             , AM.CURCY_CD_ID
             , AC.COMN_CD           AS CURCY_CD
             , AC.COMN_CD_NM        AS CURCY_NM
             , AM.COUNTRY_ID
             , CU.CONF_NM           AS COUNTRY_NM
             , AM.CHANNEL_ID
             , CH.CHANNEL_NM
             , AM.SOLD_TO_ID
             , (SELECT CUST_CD FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SOLD_TO_ID) AS SOLD_TO_CD              
             , (SELECT CUST_NM FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SOLD_TO_ID) AS SOLD_TO_NM
             , AM.SHIP_TO_ID
             , (SELECT CUST_CD FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SHIP_TO_ID) AS SHIP_TO_CD
             , (SELECT CUST_NM FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SHIP_TO_ID) AS SHIP_TO_NM
             , AM.BILL_TO_ID
             , (SELECT CUST_CD FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.BILL_TO_ID) AS BILL_TO_CD
             , (SELECT CUST_NM FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.BILL_TO_ID) AS BILL_TO_NM
             , AM.SRP_YN
             , AM.INCOTERMS_ID
             , AM.VMI_YN
             , AM.DIRECT_SHPP_YN
             , AM.ACTV_YN
             , AM.ATTR_01
             , AM.ATTR_02
             , AM.ATTR_03
             , AM.ATTR_04
             , AM.ATTR_05
             , AM.ATTR_06
             , AM.ATTR_07
             , AM.ATTR_08
             , AM.ATTR_09
             , AM.ATTR_10
             , AM.ATTR_11
             , AM.ATTR_12
             , AM.ATTR_13
             , AM.ATTR_14
             , AM.ATTR_15
             , AM.ATTR_16
             , AM.ATTR_17
             , AM.ATTR_18
             , AM.ATTR_19
             , AM.ATTR_20
             , AM.CREATE_BY
             , AM.CREATE_DTTM
             , AM.MODIFY_BY
             , AM.MODIFY_DTTM
          FROM USER_MAP_ACCT M	
               INNER JOIN
               SALES_HIER SH
            ON CASE WHEN P_ACCT_LV IS NULL THEN V_ACCT_LV ELSE M.ACCT_ID END = SH.ID           
			   INNER JOIN
			   TB_DP_ACCOUNT_MST AM
            ON M.ACCT_ID = AM.ID
               INNER JOIN
               TB_DP_SALES_LEVEL_MGMT SL
            ON AM.PARENT_SALES_LV_ID = SL.ID
               LEFT OUTER JOIN
               TB_AD_COMN_CODE AC
            ON AC.ID = AM.CURCY_CD_ID
               LEFT OUTER JOIN
               TB_CM_COMM_CONFIG CU
            ON CU.ID = AM.COUNTRY_ID
               LEFT OUTER JOIN
               TB_CM_CHANNEL_TYPE CH
            ON CH.ID = AM.CHANNEL_ID
         WHERE 1=1
		     AND ('Y' = CASE WHEN P_ACCT_CD = '' THEN 'Y'
							ELSE ( CASE WHEN UPPER(AM.ACCOUNT_CD)  LIKE '%' || UPPER(RTRIM(P_ACCT_CD)) || '%'	THEN 'Y' ELSE 'N' END) 
						END)
 		     AND ('Y' = CASE WHEN P_ACCT_NM = '' THEN 'Y'
							ELSE ( CASE WHEN UPPER(AM.ACCOUNT_NM)  LIKE '%' || UPPER(RTRIM(P_ACCT_NM)) || '%'	THEN 'Y' ELSE 'N' END) 
						END)
         ORDER BY SL.SEQ, SL.SALES_LV_CD , AM.ACCOUNT_CD
        ;    
    ELSIF (P_MGR_SALES_CNT > 0)
    THEN   
    	-- Case : manager mapping (data of Sales Auth Map)    
        OPEN pRESULT
        FOR
		WITH USER_MAP_ACCT_LV
		  AS (
				SELECT SALES_LV_ID
				  FROM TB_DP_SALES_AUTH_MAP SA
					   INNER JOIN  
					   TB_DP_SALES_LEVEL_MGMT SL 
					ON SA.SALES_LV_ID = SL.ID 
				 WHERE SA.EMP_ID = P_EMP_ID
				   AND SL.LV_MGMT_ID = p_AUTH_TP_ID
				   AND SYSDATE BETWEEN COALESCE(STRT_DATE_AUTH,SYSDATE) AND COALESCE(END_DATE_AUTH, SYSDATE)				   
			 ), USER_MAP_ACCT
		  AS (
				 SELECT DISTINCT SH.DESCENDANT_ID
				   FROM USER_MAP_ACCT_LV MM
						INNER JOIN 
					    TB_DPD_SALES_HIER_CLOSURE SH	
					 ON MM.SALES_LV_ID = SH.ANCESTER_ID
					AND SH.LEAF_YN = 'Y' 
					AND USE_YN = 'Y'
				    AND LV_TP_CD = V_LV_TP_CD
			 ), SALES_HIER 
		  AS (	SELECT DISTINCT DESCENDANT_ID AS ID 
				  FROM TB_DPD_SALES_HIER_CLOSURE SH	
				 WHERE LEAF_YN = 'Y'
				   AND ANCESTER_CD = p_ACCT_LV 
				   AND USE_YN = 'Y'
				   AND LV_TP_CD = V_LV_TP_CD
				UNION
				SELECT V_ACCT_LV
                  FROM DUAL 
				 WHERE p_ACCT_LV IS NULL
			)        
        SELECT AM.ID
    		 , AM.ACCOUNT_CD
    		 , AM.ACCOUNT_NM
    		 , AM.PARENT_SALES_LV_ID
    		 , SL.SEQ
    		 , SL.SALES_LV_CD			AS PARENT_SALES_LV_CD
    		 , SL.SALES_LV_NM			AS PARENT_SALES_LV_NM		
    		 , AM.CURCY_CD_ID
    		 , AM.COUNTRY_ID
    		 , AM.CHANNEL_ID
    		 , AM.SOLD_TO_ID
    		 , AM.SHIP_TO_ID
    		 , AM.BILL_TO_ID 
    		 , AM.SRP_YN
    		 , AM.INCOTERMS_ID
    		 , AM.VMI_YN
    		 , AM.DIRECT_SHPP_YN
    		 , AM.ACTV_YN
    		 , AM.ATTR_01
    		 , AM.ATTR_02
    		 , AM.ATTR_03
    		 , AM.ATTR_04
    		 , AM.ATTR_05
    		 , AM.ATTR_06
    		 , AM.ATTR_07
    		 , AM.ATTR_08
    		 , AM.ATTR_09
    		 , AM.ATTR_10
    		 , AM.ATTR_11
    		 , AM.ATTR_12
    		 , AM.ATTR_13
    		 , AM.ATTR_14
    		 , AM.ATTR_15
    		 , AM.ATTR_16
    		 , AM.ATTR_17
    		 , AM.ATTR_18
    		 , AM.ATTR_19
    		 , AM.ATTR_20
    		 , AM.CREATE_BY
    		 , AM.CREATE_DTTM
    		 , AM.MODIFY_BY
    		 , AM.MODIFY_DTTM
          FROM USER_MAP_ACCT  MM
               INNER JOIN
               SALES_HIER SH
            ON CASE WHEN P_ACCT_LV IS NULL THEN V_ACCT_LV ELSE MM.DESCENDANT_ID END = SH.ID 
               INNER JOIN
               TB_DP_ACCOUNT_MST AM
            ON MM.DESCENDANT_ID = AM.ID
					   INNER JOIN 
					   TB_DP_SALES_LEVEL_MGMT SL
					ON AM.PARENT_SALES_LV_ID = SL.ID 
				       LEFT OUTER JOIN
				       TB_AD_COMN_CODE AC 
				    ON AC.ID = AM.CURCY_CD_ID
				       LEFT OUTER JOIN
				       TB_CM_COMM_CONFIG CU
				    ON CU.ID = AM.COUNTRY_ID
				       LEFT OUTER JOIN
				       TB_CM_CHANNEL_TYPE CH
				    ON CH.ID = AM.CHANNEL_ID         
    	 WHERE 1=1
		    AND ('Y' = CASE WHEN P_ACCT_CD = '' THEN 'Y'
							ELSE ( CASE WHEN UPPER(AM.ACCOUNT_CD)  LIKE '%' || UPPER(RTRIM(P_ACCT_CD)) || '%'	THEN 'Y' ELSE 'N' END) 
						END)
 		    AND ('Y' = CASE WHEN P_ACCT_NM = '' THEN 'Y'
							ELSE ( CASE WHEN UPPER(AM.ACCOUNT_NM)  LIKE '%' || UPPER(RTRIM(P_ACCT_NM)) || '%'	THEN 'Y' ELSE 'N' END) 
						END)         
     	 ORDER BY SL.SEQ, SL.SALES_LV_CD, AM.ACCOUNT_CD
        ; 
    ELSE
		-- Case : mapping data is none, get all master data    
		OPEN pRESULT          
		FOR 
		WITH SALES_HIER 
		AS (	SELECT DESCENDANT_ID AS ID 
				  FROM TB_DPD_SALES_HIER_CLOSURE SH	
				 WHERE LEAF_YN = 'Y'
				   AND ANCESTER_CD = p_ACCT_LV 
				   AND USE_YN = 'Y'
				   AND LV_TP_CD = V_LV_TP_CD
				UNION
				SELECT V_ACCT_LV
                  FROM DUAL 
				 WHERE p_ACCT_LV IS NULL
			)        
		SELECT AM.ID
		     , AM.ACCOUNT_CD
			 , AM.ACCOUNT_NM
			 , AM.PARENT_SALES_LV_ID
             , SL.SALES_LV_CD   AS PARENT_SALES_LV_CD
             , SL.SALES_LV_NM   AS PARENT_SALES_LV_NM
			 , AM.CURCY_CD_ID
             , AC.COMN_CD       AS CURCY_CD
             , AC.COMN_CD_NM    AS CURCY_NM
			 , AM.COUNTRY_ID
             , CU.CONF_NM       AS COUNTRY_NM
			 , AM.CHANNEL_ID
             , CH.CHANNEL_NM
			 , AM.SOLD_TO_ID
			 , (SELECT CUST_CD FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SOLD_TO_ID) AS SOLD_TO_CD			  
			 , (SELECT CUST_NM FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SOLD_TO_ID) AS SOLD_TO_NM
			 , AM.SHIP_TO_ID
			 , (SELECT CUST_CD FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SHIP_TO_ID) AS SHIP_TO_CD
			 , (SELECT CUST_NM FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.SHIP_TO_ID) AS SHIP_TO_NM
			 , AM.BILL_TO_ID
			 , (SELECT CUST_CD FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.BILL_TO_ID) AS BILL_TO_CD
			 , (SELECT CUST_NM FROM  TB_CM_CUSTOMER A WHERE A.ID = AM.BILL_TO_ID) AS BILL_TO_NM
			 , AM.SRP_YN
			 , AM.INCOTERMS_ID
			 , AM.VMI_YN
			 , AM.DIRECT_SHPP_YN
			 , AM.ACTV_YN
			 , AM.ATTR_01
			 , AM.ATTR_02
			 , AM.ATTR_03
			 , AM.ATTR_04
			 , AM.ATTR_05
			 , AM.ATTR_06
			 , AM.ATTR_07
			 , AM.ATTR_08
			 , AM.ATTR_09
			 , AM.ATTR_10
			 , AM.ATTR_11
			 , AM.ATTR_12
			 , AM.ATTR_13
			 , AM.ATTR_14
			 , AM.ATTR_15
			 , AM.ATTR_16
			 , AM.ATTR_17
			 , AM.ATTR_18
			 , AM.ATTR_19
			 , AM.ATTR_20
			 , AM.CREATE_BY
			 , AM.CREATE_DTTM
			 , AM.MODIFY_BY
			 , AM.MODIFY_DTTM
	      FROM TB_DP_ACCOUNT_MST AM
			   INNER JOIN
			   SALES_HIER SH 
            ON CASE WHEN P_ACCT_LV IS NULL THEN V_ACCT_LV ELSE AM.ID END = SH.ID 
			   INNER JOIN 
			   TB_DP_SALES_LEVEL_MGMT SL
			ON AM.PARENT_SALES_LV_ID = SL.ID             
               LEFT OUTER JOIN
               TB_AD_COMN_CODE AC 
            ON AC.ID = AM.CURCY_CD_ID
               LEFT OUTER JOIN
               TB_CM_COMM_CONFIG CU
            ON CU.ID = AM.COUNTRY_ID
               LEFT OUTER JOIN
               TB_CM_CHANNEL_TYPE CH
            ON CH.ID = AM.CHANNEL_ID           
         WHERE 1=1
           AND COALESCE(AM.DEL_YN, 'N') = 'N'
		    AND ('Y' = CASE WHEN P_ACCT_CD = '' THEN 'Y'
							ELSE ( CASE WHEN UPPER(AM.ACCOUNT_CD)  LIKE '%' || UPPER(RTRIM(P_ACCT_CD)) || '%'	THEN 'Y' ELSE 'N' END) 
						END)
 		    AND ('Y' = CASE WHEN P_ACCT_NM = '' THEN 'Y'
							ELSE ( CASE WHEN UPPER(AM.ACCOUNT_NM)  LIKE '%' || UPPER(RTRIM(P_ACCT_NM)) || '%'	THEN 'Y' ELSE 'N' END) 
						END)         
	     ORDER BY SL.SEQ, SL.SALES_LV_CD, AM.ACCOUNT_CD			    
        ;
    END IF;
END
;
/

