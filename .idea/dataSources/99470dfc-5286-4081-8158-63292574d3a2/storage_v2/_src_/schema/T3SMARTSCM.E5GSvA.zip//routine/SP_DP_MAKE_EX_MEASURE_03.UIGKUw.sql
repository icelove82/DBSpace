create PROCEDURE SP_DP_MAKE_EX_MEASURE_03 
(   
/***************************************************************************************
*****************************************************************************************/
     P_STRT_DATE DATE
    ,P_END_DATE  DATE
    ,P_PLAN_TP_CD       IN VARCHAR2 := 'DP_PLAN_MONTHLY' -- PLAN TYPE CODE
    ,P_MIN_MEASURE_VAL  IN INT      :=0                   
    ,P_MAX_MEASURE_VAL  IN INT      :=45
)IS
     V_VER_BUCKET    VARCHAR2(50);
     V_VER_HORIZON   INT ;
     V_VER_DOW_NM    CHAR(3);
     V_VER_DOW       INT ;
     V_PAR_BUCKET   VARCHAR2(50);
     V_PAR_HORIZON  INT := 0; 
BEGIN
-- 1) VAR_BUCKET, VAR_HORIZON
          SELECT C.POLICY_VAL  INTO V_VER_BUCKET
              FROM   TB_CM_COMM_CONFIG B
                     INNER JOIN
                     TB_DP_PLAN_POLICY C
                ON  (B.ID = C.PLAN_TP_ID)
                     INNER JOIN
                     TB_CM_COMM_CONFIG D
                ON  (C.POLICY_ID = D.ID)                     
                 where  1=1 -- A.MODULE_CD = 'DP'
                   AND B.ACTV_YN = 'Y'
                   AND D.CONF_CD = 'B'
                   AND B.CONF_CD = P_PLAN_TP_CD
                   ;
          SELECT C.POLICY_VAL  INTO V_VER_HORIZON
              FROM   TB_CM_COMM_CONFIG B
                     INNER JOIN
                     TB_DP_PLAN_POLICY C
                ON  (B.ID = C.PLAN_TP_ID)
                     INNER JOIN
                     TB_CM_COMM_CONFIG D
                ON  (C.POLICY_ID = D.ID)                     
                 where  1=1 
                   AND B.ACTV_YN = 'Y'
                   AND D.CONF_CD = 'H'
                   AND B.CONF_CD = P_PLAN_TP_CD      
                   ;
            SELECT UPPER(CONF_CD) INTO V_VER_DOW_NM
              FROM TB_CM_COMM_CONFIG 
             WHERE 1=1
               AND CONF_GRP_CD = 'DP_STD_WEEK' 
               AND ACTV_YN = 'Y' 
               AND USE_YN = 'Y' 
             ;
             SELECT CASE UPPER(V_VER_DOW_NM) 
                    WHEN 'SUN'  THEN 1 
                    WHEN 'MON'  THEN 2
                    WHEN 'TUE'  THEN 3 
                    WHEN 'WED'  THEN 4 
                    WHEN 'THU'  THEN 5 
                    WHEN 'FRI'  THEN 6
                    WHEN 'SAT'  THEN 7
                    END INTO V_VER_DOW
            FROM DUAL;

    DELETE FROM TB_DP_MEASURE_DATA
    WHERE BASE_DATE BETWEEN P_STRT_DATE AND P_END_DATE 
    ;
IF(V_VER_BUCKET = 'D')
    THEN
    INSERT INTO TB_DP_MEASURE_DATA 
    (
         ID    
        ,ITEM_MST_ID
        ,ACCOUNT_ID
        ,BASE_DATE
        ,ANNUAL_QTY
        ,ANNUAL_AMT
        ,BF_MEAS_QTY
       , BF_MEAS_AMT
        ,RTF_QTY
        ,RTF_AMT
       , YOY_QTY
       , YOY_AMT
       , YTD_QTY
       , YTD_AMT
       , YTD_ANNUAL_QTY
       , YTD_ANNUAL_AMT
       , ACT_SALES_QTY
       , ACT_SALES_AMT
      , LAST_WEEK_QTY
      , LAST_WEEK_AMT
      , IN_TRAN_QTY
      , IN_TRAN_AMT
      , STOCK_QTY
      , STOCK_AMT    
    )
	SELECT TO_SINGLE_BYTE(SYS_GUID()) AS ID       
           , I.ID                                        AS ITEM_MST_ID
           , A.ID                                        AS ACCOUNT_ID
         , C.DAT								AS BASE_DATE
         -- MEASURES
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000         
	  FROM TB_CM_ITEM_MST I
           INNER JOIN
           TB_DP_ACCOUNT_MST A
        ON (I.DP_PLAN_YN = 'Y') AND (I.DEL_YN = 'N' or I.DEL_YN is null) AND (A.DEL_YN='N' or A.DEL_YN is null )
           INNER JOIN           
           TB_CM_CALENDAR C
        ON (1=1)  
 WHERE 1=1
   AND DAT BETWEEN P_STRT_DATE AND P_END_DATE 
   ;
-- WEEK     -------------------------------------------------------------------------------------------------------------
ELSIF(V_VER_BUCKET = 'W')
    THEN 
    INSERT INTO TB_DP_MEASURE_DATA  (
         ID    
        ,ITEM_MST_ID
        ,ACCOUNT_ID
        ,BASE_DATE
        ,ANNUAL_QTY
        ,ANNUAL_AMT
        ,BF_MEAS_QTY
       , BF_MEAS_AMT
        ,RTF_QTY
        ,RTF_AMT
       , YOY_QTY
       , YOY_AMT
       , YTD_QTY
       , YTD_AMT
       , YTD_ANNUAL_QTY
       , YTD_ANNUAL_AMT
       , ACT_SALES_QTY
       , ACT_SALES_AMT
      , LAST_WEEK_QTY
      , LAST_WEEK_AMT
      , IN_TRAN_QTY
      , IN_TRAN_AMT
      , STOCK_QTY
      , STOCK_AMT    
    )
	SELECT TO_SINGLE_BYTE(SYS_GUID()) AS ID       
           , I.ID                                        AS ITEM_MST_ID
           , A.ID                                        AS ACCOUNT_ID
         , C.DAT								AS BASE_DATE
         -- MEASURES
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000       
	  FROM TB_CM_ITEM_MST I
           INNER JOIN 
           TB_DP_ACCOUNT_MST A
        ON (I.DP_PLAN_YN = 'Y') AND (I.DEL_YN = 'N' or I.DEL_YN is null) AND (A.DEL_YN='N' or A.DEL_YN is null )
           INNER JOIN           
           TB_CM_CALENDAR C
        ON (1=1)  
     WHERE 1=1
       AND DAT BETWEEN P_STRT_DATE AND P_END_DATE 
       AND DOW_NM = (SELECT UPPER(TRIM(CONF_CD)) 
                     FROM TB_CM_COMM_CONFIG 
                    WHERE 1=1
                      AND CONF_GRP_CD = 'DP_STD_WEEK' 
                      AND USE_YN = 'Y' 
                      AND ACTV_YN = 'Y'
                    )
                    ;
-- PARTIAL WEEK -------------------------------------------------------------------------------------------------------------
ELSIF(V_VER_BUCKET = 'PW')
    THEN
    INSERT INTO TB_DP_MEASURE_DATA  (
         ID    
        ,ITEM_MST_ID
        ,ACCOUNT_ID
        ,BASE_DATE
        ,ANNUAL_QTY
        ,ANNUAL_AMT
        ,BF_MEAS_QTY
       , BF_MEAS_AMT
        ,RTF_QTY
        ,RTF_AMT
       , YOY_QTY
       , YOY_AMT
       , YTD_QTY
       , YTD_AMT
       , YTD_ANNUAL_QTY
       , YTD_ANNUAL_AMT
       , ACT_SALES_QTY
       , ACT_SALES_AMT
      , LAST_WEEK_QTY
      , LAST_WEEK_AMT
      , IN_TRAN_QTY
      , IN_TRAN_AMT
      , STOCK_QTY
      , STOCK_AMT    
    )
	SELECT TO_SINGLE_BYTE(SYS_GUID()) AS ID       
           , I.ID                                        AS ITEM_MST_ID
           , A.ID                                        AS ACCOUNT_ID
         , C.DAT								AS BASE_DATE
         -- MEASURES
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000       
	  FROM TB_CM_ITEM_MST I
           INNER JOIN
           TB_DP_ACCOUNT_MST A
        ON (I.DP_PLAN_YN = 'Y') AND (I.DEL_YN = 'N' or I.DEL_YN is null) AND (A.DEL_YN='N' or A.DEL_YN is null )
           INNER JOIN           
           TB_CM_CALENDAR C
        ON (1=1) 
          WHERE 1=1
                AND DAT BETWEEN P_STRT_DATE AND P_END_DATE 
                AND (   DOW_NM = ( SELECT UPPER(CONF_CD) FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_STD_WEEK' AND ACTV_YN = 'Y' AND USE_YN = 'Y' )
                    OR  DD = 1)
                 ;




-- MONTH    -------------------------------------------------------------------------------------------------------------
ELSIF(V_VER_BUCKET = 'M')
    THEN
    INSERT INTO TB_DP_MEASURE_DATA  (
         ID    
        ,ITEM_MST_ID
        ,ACCOUNT_ID
        ,BASE_DATE
        ,ANNUAL_QTY
        ,ANNUAL_AMT
        ,BF_MEAS_QTY
       , BF_MEAS_AMT
        ,RTF_QTY
        ,RTF_AMT
       , YOY_QTY
       , YOY_AMT
       , YTD_QTY
       , YTD_AMT
       , YTD_ANNUAL_QTY
       , YTD_ANNUAL_AMT
       , ACT_SALES_QTY
       , ACT_SALES_AMT
      , LAST_WEEK_QTY
      , LAST_WEEK_AMT
      , IN_TRAN_QTY
      , IN_TRAN_AMT
      , STOCK_QTY
      , STOCK_AMT    
    )
	SELECT TO_SINGLE_BYTE(SYS_GUID()) AS ID       
           , I.ID                                        AS ITEM_MST_ID
           , A.ID                                        AS ACCOUNT_ID
         , C.DAT								AS BASE_DATE
         -- MEASURES
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000       
	  FROM TB_CM_ITEM_MST I
           INNER JOIN
           TB_DP_ACCOUNT_MST A
        ON (I.DP_PLAN_YN = 'Y') AND (I.DEL_YN = 'N' or I.DEL_YN is null) AND (A.DEL_YN='N' or A.DEL_YN is null )
           INNER JOIN           
           TB_CM_CALENDAR C
        ON (1=1)  
    WHERE 1=1
      AND DAT BETWEEN P_STRT_DATE AND P_END_DATE 
      AND DD = 1 --TO_NUMBER(TO_CHAR(TO_DATE(1, 'YY/MM/DD'),'DD'))   -- ？？？ BUCKET
      ;
-- YEAR     -------------------------------------------------------------------------------------------------------------
ELSIF(V_VER_BUCKET = 'Y')
    THEN
    INSERT INTO TB_DP_MEASURE_DATA  (
         ID    
        ,ITEM_MST_ID
        ,ACCOUNT_ID
        ,BASE_DATE
        ,ANNUAL_QTY
        ,ANNUAL_AMT
        ,BF_MEAS_QTY
       , BF_MEAS_AMT
        ,RTF_QTY
        ,RTF_AMT
       , YOY_QTY
       , YOY_AMT
       , YTD_QTY
       , YTD_AMT
       , YTD_ANNUAL_QTY
       , YTD_ANNUAL_AMT
       , ACT_SALES_QTY
       , ACT_SALES_AMT
      , LAST_WEEK_QTY
      , LAST_WEEK_AMT
      , IN_TRAN_QTY
      , IN_TRAN_AMT
      , STOCK_QTY
      , STOCK_AMT    
    )
	SELECT TO_SINGLE_BYTE(SYS_GUID()) AS ID       
           , I.ID                                        AS ITEM_MST_ID
           , A.ID                                        AS ACCOUNT_ID
         , C.DAT								AS BASE_DATE
         -- MEASURES
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0)	
         , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL),0) * 1000       
	  FROM TB_CM_ITEM_MST I
           INNER JOIN
           TB_DP_ACCOUNT_MST A
        ON (I.DP_PLAN_YN = 'Y') AND (I.DEL_YN = 'N' or I.DEL_YN is null) AND (A.DEL_YN='N' or A.DEL_YN is null )
           INNER JOIN           
           TB_CM_CALENDAR C
        ON (1=1)  
    WHERE 1=1
      AND DAT BETWEEN P_STRT_DATE AND P_END_DATE 
      AND DD = 1 -- TO_NUMBER(TO_CHAR(TO_DATE(SYSDATE, 'YY/MM/DD'),'DD'))   -- ？？？ BUCKET
      AND MM = 1 --TO_NUMBER(TO_CHAR(TO_DATE(SYSDATE, 'YY/MM/DD'),'MM'))    
--     ORDER BY ITEM_MST_ID, ACCOUNT_ID, BASE_DATE
      ;
END IF;
END;
/

