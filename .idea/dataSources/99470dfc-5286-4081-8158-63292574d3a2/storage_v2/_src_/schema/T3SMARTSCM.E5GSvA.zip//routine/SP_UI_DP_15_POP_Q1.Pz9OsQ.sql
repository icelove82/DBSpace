create PROCEDURE                "SP_UI_DP_15_POP_Q1" (
    p_EMP_NO        IN VARCHAR2 := ''
  , p_AUTH_TP_ID	IN VARCHAR2 := ''
  , p_ITEM_MST_ID   IN VARCHAR2 := ''
  , pRESULT         OUT SYS_REFCURSOR
  
) IS 

/*****************************************************************************
Title : SP_UI_DP_15_POP_Q1
 
설명 
 - DP User Mapping - New Item mapping 
 
History (수정일자 / 수정자 / 수정내용)
- 2022.11.23 /hanguls / create
- 2023.01.13 / kim sohee / oracle converting
*****************************************************************************/
    V_EMP_ID CHAR(32);
BEGIN
 	SELECT ID INTO V_EMP_ID
	  FROM TB_AD_USER
	WHERE USERNAME = P_EMP_NO
	;

   OPEN pRESULT
   FOR		 
WITH M
  AS (
    SELECT DISTINCT  M.EMP_ID , M.AUTH_TP_ID, M.ACCOUNT_ID, P_ITEM_MST_ID AS ITEM_MST_ID
      FROM TB_DP_USER_ITEM_ACCOUNT_MAP M	
      WHERE AUTH_TP_ID = P_AUTH_TP_ID
        AND EMP_ID = V_EMP_ID
	) SELECT EMP_ID
           , AUTH_TP_ID
           , ACCOUNT_ID
           , ITEM_MST_ID
           , A.ACCOUNT_CD
           , A.ACCOUNT_NM 
           , I.ITEM_CD
           , I.ITEM_NM
           , 'Y' AS ACTV_YN
	  FROM M
          INNER JOIN 
          TB_DP_ACCOUNT_MST A 
       ON A.ID = M.ACCOUNT_ID
          INNER JOIN 
          TB_CM_ITEM_MST I  
       ON I.ID = M.ITEM_MST_ID  

;


END
;
/

