create PROCEDURE SP_UI_CM_07_BATCH (
	P_APPLY_POINT_CD		VARCHAR2 := ''
   ,P_CHECK_LOCAT			CHAR := ''
   ,P_LOCAT_MGMT_ID		    CHAR := ''
   ,P_OVERWRITE_DATA_YN	    CHAR := ''
   ,P_USER_ID				VARCHAR2 := ''
   ,P_RT_ROLLBACK_FLAG      OUT VARCHAR2
   ,P_RT_MSG                OUT VARCHAR2
)
IS
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG VARCHAR2(4000) :='';

BEGIN
	/***************************************************************************************************************************************************************************
	BOD L/T 기준의 출하 L/T 정보 생성
	***************************************************************************************************************************************************************************/
	INSERT INTO TEMP_SHIP_LT
	(
		BOD_TP_ID,
		CONSUME_LOCAT_ID,
		SUPPLY_LOCAT_ID,
		VEHICL_TP_ID,
		PRIORT,
		BOD_LEADTIME_ID,
		TRANSP_COST_CAL_BASE_ID
	)
	SELECT	(SELECT ID FROM TB_AD_COMN_CODE WHERE COMN_CD = 'SITE_BOD') AS BOD_TP_ID,
			G.ID AS CONSUME_LOCAT_ID,
			D.ID AS SUPPLY_LOCAT_ID,
			A.VEHICL_TP_ID,
			I.PRIORT,
			A.ID AS BOD_LEADTIME_ID,
			(SELECT ID FROM TB_AD_COMN_CODE WHERE COMN_CD = 'VEHICLE_TYPE') AS TRANSP_COST_CAL_BASE_ID
	FROM	TB_CM_BOD_LT A
			INNER JOIN TB_CM_LOC_MST B
			ON B.ID = A.FROM_LOCAT_MST_ID
			INNER JOIN TB_CM_LOC_DTL C
			ON B.ID = C.LOCAT_MST_ID
			INNER JOIN TB_CM_LOC_MGMT D
			ON C.ID = D.LOCAT_ID
			INNER JOIN TB_CM_LOC_MST E
			ON E.ID = A.TO_LOCAT_MST_ID
			INNER JOIN TB_CM_LOC_DTL F
			ON E.ID = F.LOCAT_MST_ID
			INNER JOIN TB_CM_LOC_MGMT G
			ON F.ID = G.LOCAT_ID
			INNER JOIN TB_CM_LOC_BOD_MAP H
			ON G.ID = H.CONSUME_LOCAT_ID
			AND D.ID = H.SUPPLY_LOCAT_ID
			LEFT OUTER JOIN TB_CM_VEHICLE I
			ON I.ID = A.VEHICL_TP_ID
	WHERE	NVL(A.ACTV_YN, 'N') = 'Y'
	AND		NVL(C.ACTV_YN, 'N') = 'Y'
	AND		NVL(F.ACTV_YN, 'N') = 'Y'
	AND		(
			D.ID	= CASE WHEN P_APPLY_POINT_CD = 'PARTIAL' AND P_CHECK_LOCAT = 'Y'
						   THEN P_LOCAT_MGMT_ID
						   ELSE D.ID
					  END
		OR	G.ID	= CASE WHEN P_APPLY_POINT_CD = 'PARTIAL' AND P_CHECK_LOCAT = 'Y'
						   THEN P_LOCAT_MGMT_ID
						   ELSE G.ID
					  END
			);

	IF P_APPLY_POINT_CD = 'ALL' AND P_OVERWRITE_DATA_YN = 'Y' THEN
        DELETE FROM TB_CM_SHIP_LT_DTL;
        DELETE FROM TB_CM_SHIP_LT_MST;

	ELSIF P_APPLY_POINT_CD = 'PARTIAL' AND P_OVERWRITE_DATA_YN = 'Y' THEN
        DELETE
        FROM    TB_CM_SHIP_LT_DTL
        WHERE	SHPP_LEADTIME_MST_ID IN	(
                                        SELECT	A.ID
                                        FROM	TB_CM_SHIP_LT_MST A,
                                                TEMP_SHIP_LT B
                                        WHERE	B.CONSUME_LOCAT_ID = A.CONSUME_LOCAT_ID
                                        AND		B.SUPPLY_LOCAT_ID = A.SUPPLY_LOCAT_ID
                                        AND		B.VEHICL_TP_ID = A.VEHICL_TP_ID
                                        );

        DELETE
        FROM    TB_CM_SHIP_LT_MST A
        WHERE   1=1
        AND     EXISTS  (
                        SELECT  1
                        FROM    TEMP_SHIP_LT B
                        WHERE	B.CONSUME_LOCAT_ID = A.CONSUME_LOCAT_ID
                        AND		B.SUPPLY_LOCAT_ID = A.SUPPLY_LOCAT_ID
                        AND		B.VEHICL_TP_ID = A.VEHICL_TP_ID
                        );
    END IF;

    MERGE INTO TB_CM_SHIP_LT_MST A
    USING
        (
		SELECT	DISTINCT 
				BOD_TP_ID,
				CONSUME_LOCAT_ID,
				SUPPLY_LOCAT_ID,
				VEHICL_TP_ID,
				PRIORT,
				TRANSP_COST_CAL_BASE_ID
		FROM	TEMP_SHIP_LT
        ) B
    ON (A.CONSUME_LOCAT_ID = B.CONSUME_LOCAT_ID
      AND A.SUPPLY_LOCAT_ID = B.SUPPLY_LOCAT_ID
	  AND A.VEHICL_TP_ID = B.VEHICL_TP_ID)
    WHEN NOT MATCHED THEN 
		INSERT 
		(
			ID
		   ,BOD_TP_ID
		   ,CONSUME_LOCAT_ID
		   ,SUPPLY_LOCAT_ID
		   ,VEHICL_TP_ID
		   ,PRIORT
		   ,TRANSP_COST_CAL_BASE_ID
		   ,ACTV_YN
		   ,CREATE_BY
		   ,CREATE_DTTM
		)  
		VALUES
		(
			TO_SINGLE_BYTE(SYS_GUID())
		   ,B.BOD_TP_ID
		   ,B.CONSUME_LOCAT_ID
		   ,B.SUPPLY_LOCAT_ID
		   ,B.VEHICL_TP_ID
		   ,B.PRIORT
		   ,B.TRANSP_COST_CAL_BASE_ID
		   ,'Y'
		   ,P_USER_ID
		   ,SYSDATE
		);

    MERGE INTO TB_CM_SHIP_LT_DTL A
    USING
        (
		SELECT  A.ID AS SHPP_LEADTIME_MST_ID, 
				B.BOD_LEADTIME_ID
		FROM    TB_CM_SHIP_LT_MST A,
				TEMP_SHIP_LT B
		WHERE	A.CONSUME_LOCAT_ID = B.CONSUME_LOCAT_ID
		AND		A.SUPPLY_LOCAT_ID = B.SUPPLY_LOCAT_ID
		AND		A.VEHICL_TP_ID = B.VEHICL_TP_ID
        ) B
    ON (A.SHPP_LEADTIME_MST_ID = B.SHPP_LEADTIME_MST_ID)
    WHEN NOT MATCHED THEN 
		INSERT 
		(
			ID
		   ,SHPP_LEADTIME_MST_ID
		   ,BOD_LEADTIME_ID
		   ,ACTV_YN
		   ,CREATE_BY
		   ,CREATE_DTTM
		)
		VALUES
		(
			TO_SINGLE_BYTE(SYS_GUID())
		   ,B.SHPP_LEADTIME_MST_ID
		   ,B.BOD_LEADTIME_ID
		   ,'Y'
		   ,P_USER_ID
		   ,SYSDATE
		);

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0003';

    EXCEPTION
	WHEN OTHERS THEN
		P_RT_ROLLBACK_FLAG := 'false';
		IF(SQLCODE = -20012)
		  THEN
			  P_RT_MSG := P_ERR_MSG;
		  ELSE
			  P_RT_MSG := SQLERRM;
		END IF;
END;

/

