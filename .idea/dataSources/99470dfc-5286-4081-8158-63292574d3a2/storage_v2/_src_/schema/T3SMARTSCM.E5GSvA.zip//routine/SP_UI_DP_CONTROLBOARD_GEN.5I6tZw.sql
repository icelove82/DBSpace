create PROCEDURE SP_UI_DP_CONTROLBOARD_GEN  (
											   p_VER_ID				VARCHAR2 	    
											  ,p_VER_BUCKET			VARCHAR2     
											  ,p_VER_HORIZON			VARCHAR2 	    
											  ,p_VER_FROM_DATE         DATE 	      
											  ,p_VER_TO_DATE           DATE 	 
											  ,p_VER_DTF				NUMBER     
--											  ,p_VER_DTF_DATE          DATE 		
											  ,p_VER_STAT_BUCKET		VARCHAR2	       
											  ,p_VER_DESCRIP           VARCHAR2	    
											  ,p_PAR_BUCKET			VARCHAR2
											  ,p_PAR_HORIZON			VARCHAR2
											  ,p_PAR_DATE				DATE							    
											  ,p_PAR_BUCKET2			VARCHAR2
											  ,p_PAR_HORIZON2			VARCHAR2 
											  ,p_PAR_DATE2				DATE   									    
											  ,P_PLAN_TP_ID				CHAR	 
											  ,P_PRICE_TYPE			VARCHAR2	  
											  ,P_CURRENCY_TYPE			VARCHAR2	  
											  ,p_USER_ID				VARCHAR2      
                                              ,P_RT_ROLLBACK_FLAG	OUT 	VARCHAR2 
                                        	  ,P_RT_MSG           	OUT 	VARCHAR2	 									   
	  										   ) 
AS

 P_ERR_STATUS INT := 0;
       P_ERR_MSG VARCHAR2(4000);
	   V_VER_MST_ID VARCHAR2(32) :=  TO_SINGLE_BYTE(SYS_GUID());
	   p_VER_DTF_DATE	DATE;
       pRESULT      SYS_REFCURSOR;
BEGIN  
	-- calculation DTF DATE 
	WITH CAL
	AS (
			SELECT  MIN(DAT)	AS STRT_DATE
				  , MAX(DAT)	AS END_DATE
				  , DENSE_RANK () OVER (ORDER BY MIN(DAT) ASC) AS RW 
			  FROM TB_CM_CALENDAR
		  GROUP BY CASE p_VER_BUCKET
						WHEN 'Y' THEN YYYY
						WHEN 'Q' THEN YYYY||'-'||CAST( QTR AS CHAR(1))
						WHEN 'M' THEN YYYYMM
						WHEN 'PW' THEN MM||'-'||DP_WK
						WHEN 'W' THEN DP_WK
					ELSE YYYYMMDD END 	
	 ), DTF
	 AS (
			 SELECT RW+COALESCE(P_VER_DTF,0)-1		AS RW				  
			  FROM CAL
			 WHERE P_VER_FROM_DATE BETWEEN STRT_DATE AND END_DATE 
	 )

	 SELECT CAL.END_DATE INTO p_VER_DTF_DATE
	   FROM CAL
			INNER JOIN 
			DTF 
		 ON CAL.RW = DTF.RW
	;

	--버전 DATA 저장
INSERT INTO TB_DP_CONTROL_BOARD_VER_MST
           (ID
           ,VER_ID
		   ,MODULE_ID
           ,BUKT
           ,HORIZ
           ,FROM_DATE
           ,TO_DATE
           ,DTF
           ,DTF_DATE
           ,DESCRIP
           ,CREATE_BY
           ,CREATE_DTTM
           ,VER_S_BUCKET
           ,VER_S_HORIZON
           ,VER_S_HORIZON_DATE
           ,VER_S_BUCKET2
           ,VER_S_HORIZON2
           ,VER_S_HORIZON_DATE2
		   ,PLAN_TP_ID
		   ,PRICE_TP_ID
		   ,CURCY_TP_ID	   
		   )
     VALUES (
            V_VER_MST_ID
           ,p_VER_ID
		   ,(SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_CD = 'DP' AND CONF_GRP_CD = 'DP_WK_TP')
           ,p_VER_BUCKET
           ,p_VER_HORIZON
           ,p_VER_FROM_DATE
           ,p_VER_TO_DATE
           ,p_VER_DTF
           ,p_VER_DTF_DATE
           ,p_VER_DESCRIP
           ,p_USER_ID
           ,SYSDATE 
           ,P_PAR_BUCKET
           ,P_PAR_HORIZON      
           ,P_PAR_DATE  
           ,P_PAR_BUCKET2
           ,P_PAR_HORIZON2     
           ,P_PAR_DATE2  
		   ,P_PLAN_TP_ID
		   ,COALESCE(P_PRICE_TYPE, (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PRICE_TYPE' AND ACTV_YN = 'Y' AND DEFAT_VAL = 'Y' AND ROWNUM = 1))
		   ,COALESCE(P_CURRENCY_TYPE, (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CURRENCY_TYPE' AND ACTV_YN = 'Y'  AND DEFAT_VAL = 'Y' AND ROWNUM = 1))
		   )
		;



		-- DTL
		INSERT INTO TB_DP_CONTROL_BOARD_VER_DTL
		(     ID
			, CONBD_VER_MST_ID		
			, MODULE_ID				
			, WORK_CD				
			, WORK_NM				
			, SEQ					
			, DESCRIP				
			, WORK_TP_ID			
			, LINK					
			, LV_MGMT_ID			
			, INIT_VAL_TP_ID		
			, INIT_FIXED_LV_MGMT_ID	
			, INPUT_TP_ID			
			, CONST_INPUT_YN		
			, CONST_INPUT_DATE		
			, APPV_CONST_ID			
			, APPV_EVENT_ID			
			, AUTO_APPV_YN			
			, AUTO_APPV_DATE		
			, CANC_CONST_ID			
			, CANC_EVENT_ID			
			, CL_TP_ID				
			, CL_LV_MGMT_ID			
			, CL_STATUS_ID			
			, CREATE_BY				
			, CREATE_DTTM			
			, MODIFY_BY				
			, MODIFY_DTTM			
			, PLAN_TP_ID			
			, INIT_MEASURE_ID		
		) 									 
		SELECT TO_SINGLE_BYTE(SYS_GUID())			
			 , V_VER_MST_ID
			 , MODULE_ID
			 , WORK_CD
			 , WORK_NM
			 , SEQ
			 , DESCRIP
			 , WORK_TP_ID
			 , LINK
			 , LV_MGMT_ID
			 , INIT_VAL_TP_ID
			 , INIT_FIXED_LV_MGMT_ID
			 , INPUT_TP_ID
			 , CONST_INPUT_YN
	         , CASE WHEN INIT_CONST_INPUT_VAL IS NOT NULL 
                        THEN P_VER_FROM_DATE+INIT_CONST_INPUT_VAL+INIT_CONST_INPUT_TIME_VAL/24
				END AS INIT_CONST_INPUT_DATE
			 , APPV_CONST_ID
			 , APPV_EVENT_ID
			 , AUTO_APPV_YN
			 , CASE WHEN INIT_AUTO_APPV_VAL IS NOT NULL 
					THEN INIT_AUTO_APPV_VAL+P_VER_FROM_DATE+INIT_AUTO_APPV_TIME_VAL/24 
				END AS INIT_AUTO_APPV_DATE 
			 , CANC_CONST_ID
			 , CANC_EVENT_ID
			 , CL_TP_ID
			 , CL_LV_MGMT_ID
			 , (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'READY')
			 , P_USER_ID 
			 , SYSDATE  
			 , NULL 
			 , NULL 
			 , PLAN_TP_ID
			 , INIT_MEASURE_ID
		  FROM TB_DP_CONTROL_BOARD_MST 
		 WHERE COALESCE(DEL_YN,'N') = 'N'
		   AND PLAN_TP_ID = P_PLAN_TP_ID
		  ;

		   INSERT INTO TB_DP_CONTROL_BOARD_VER_INIT					
			( ID
			 ,CONBD_VER_DTL_ID
			 ,MS_VAL_TP_CD
			 ,INIT_VAL_TP_ID
			 ,INIT_FIXED_LV_MGMT_ID	
			 ,INIT_MEASURE_ID		
			 ,CREATE_BY 
			 ,CREATE_DTTM 
			)
			SELECT TO_SINGLE_BYTE(SYS_GUID())	 AS ID
				 , D.ID						 AS CONBD_VER_DTL_ID
--			     , M.WORK_CD				-- REFERENCE
				 , I.MS_VAL_TP_CD			 AS MS_VAL_TP_CD
				 , I.INIT_VAL_TP_ID			 AS INIT_VAL_TP_ID
				 , I.INIT_FIXED_LV_MGMT_ID	 AS INIT_FIXED_LV_MGMT_ID	
				 , I.INIT_MEASURE_ID		 AS	INIT_MEASURE_ID		
				 , p_USER_ID
				 , SYSDATE 
			  FROM TB_DP_CONTROL_BOARD_MST_INIT I
				   INNER JOIN
				   TB_DP_CONTROL_BOARD_MST M
				ON M.ID = I.CONBD_MST_ID
				   INNER JOIN
				   TB_DP_CONTROL_BOARD_VER_DTL D
				ON D.WORK_CD = M.WORK_CD
			   AND D.CONBD_VER_MST_ID =  V_VER_MST_ID --'DD91D77C3FD4442EAD202BCAC869FBCC'	
 				   INNER JOIN
				   TB_CM_COMM_CONFIG C
				ON I.MS_VAL_tP_CD = C.CONF_CD
			  AND C.ACTV_YN = 'Y'
			  AND C.CONF_GRP_CD = 'DP_MS_VAL_TP'
             ;
 
	       SP_UI_DP_93_VER_CREATE_S3(
			 p_VER_ID
			,P_PLAN_TP_ID
            ,pRESULT
	       );

	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  
       /*  ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN  
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF; 

END;
/

