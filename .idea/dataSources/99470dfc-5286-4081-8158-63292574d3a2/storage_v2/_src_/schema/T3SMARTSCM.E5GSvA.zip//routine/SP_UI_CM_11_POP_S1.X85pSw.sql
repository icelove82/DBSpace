create PROCEDURE SP_UI_CM_11_POP_S1 (
	 P_GLOBAL_PLAN_BOM_ID			IN CHAR := '',
	 P_LOC_DTL_ID					IN CHAR := '',
	 P_ITEM_MST_ID					IN CHAR := '',
	 P_BOD_TP_ID					IN CHAR := '',
	 P_SRCING_POLICY_ID		        IN CHAR := '',
	 P_SUPPLY_LOCAT_ITEM_ID			IN CHAR := '',
	 P_SRCING_RULE			        IN NUMBER := '',
	 P_ACTV_YN						IN CHAR := NULL,
	 P_USER_ID						IN VARCHAR2 :=''
	,P_RT_ROLLBACK_FLAG             OUT VARCHAR2
	,P_RT_MSG                       OUT VARCHAR2
)
IS
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG  VARCHAR2(4000) :='';
    P_CONSUME_LOCAT_ITEM_ID CHAR(32) :='';
    TEMP_ONE VARCHAR2(1000) := '';
    
BEGIN
    IF P_ITEM_MST_ID IS NOT NULL THEN
        P_ERR_MSG := 'MSG_0008';
        TEMP_ONE := CASE RTRIM(LTRIM(P_SRCING_RULE)) WHEN NULL THEN null ELSE P_SRCING_RULE END;
        IF TO_NUMBER(TEMP_ONE) < 0 
            THEN  RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
        END IF;
            
        SELECT B.ID INTO P_CONSUME_LOCAT_ITEM_ID
          FROM TB_CM_LOC_MGMT A,
               TB_CM_SITE_ITEM B,
               TB_CM_ITEM_MST C,
               TB_CM_LOC_DTL D,
               TB_AD_COMN_CODE E
         WHERE 1=1
           AND B.ITEM_MST_ID = C.ID
           AND B.LOCAT_MGMT_ID = A.ID
           AND D.ID = A.LOCAT_ID
           AND C.ID = P_ITEM_MST_ID
           AND D.ID =  P_LOC_DTL_ID
           AND E.ID = B.BOM_ITEM_TP_ID
           AND E.COMN_CD = (CASE WHEN A.SEMI_PRDUCT_GI_USE_YN = 'Y' THEN 'SEMI_PRODUCT_GI_ITEM' ELSE 'FINAL_PRODUCT_GR_ITEM' END);
    
        MERGE INTO TB_CM_GLOBAL_PLAN_BOM BOM
        USING (
                SELECT 
                    P_GLOBAL_PLAN_BOM_ID AS GLOBAL_PLAN_BOM_ID,
                    P_CONSUME_LOCAT_ITEM_ID AS CONSUME_LOCAT_ITEM_ID,
                    P_BOD_TP_ID AS BOD_TP_ID,
                    REPLACE(P_SRCING_POLICY_ID,' ','') AS SRCING_POLICY_ID,
                    P_SUPPLY_LOCAT_ITEM_ID AS SUPPLY_LOCAT_ITEM_ID,
                    P_SRCING_RULE AS SRCING_RULE,
                    REPLACE(P_ACTV_YN,' ','') AS ACTV_YN,
                    P_USER_ID AS USER_ID
                    FROM DUAL
        )A 
        ON (BOM.BOD_TP_ID = A.BOD_TP_ID
        AND BOM.CONSUME_LOCAT_ITEM_ID = A.CONSUME_LOCAT_ITEM_ID
        AND BOM.SUPPLY_LOCAT_ITEM_ID = A.SUPPLY_LOCAT_ITEM_ID)
        WHEN MATCHED THEN
            UPDATE
            SET BOM.SRCING_POLICY_ID = A.SRCING_POLICY_ID,
                BOM.SRCING_RULE = A.SRCING_RULE,
                BOM.ACTV_YN = A.ACTV_YN,
                BOM.MODIFY_BY = A.USER_ID,
                BOM.MODIFY_DTTM = SYSDATE
        WHEN NOT MATCHED THEN
            INSERT  (
                ID
               ,BOD_TP_ID
               ,CONSUME_LOCAT_ITEM_ID
               ,SUPPLY_LOCAT_ITEM_ID
               ,SRCING_POLICY_ID
               ,SRCING_RULE
               ,DEL_YN
               ,ACTV_YN
               ,CREATE_BY
               ,CREATE_DTTM
               ,MODIFY_BY
               ,MODIFY_DTTM
            )VALUES(
                TO_SINGLE_BYTE(SYS_GUID()),
                A.BOD_TP_ID,
                A.CONSUME_LOCAT_ITEM_ID,
                A.SUPPLY_LOCAT_ITEM_ID,
                A.SRCING_POLICY_ID,
                TO_NUMBER(LTRIM(RTRIM(A.SRCING_RULE))),
                'N',
                A.ACTV_YN,
                A.USER_ID,
                SYSDATE,
                A.USER_ID,
                SYSDATE
                );    
    END IF;

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';

EXCEPTION
    WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;   
      ELSE
         RAISE;
      END IF;
END;

/

