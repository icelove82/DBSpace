create PROCEDURE SP_UI_CM_15_S1 (
     P_MODULE_ID            IN CHAR :=''
    ,P_PLAN_POLICY_DESCP    IN VARCHAR2 :=''
    ,P_ACTV_YN              IN VARCHAR2 :=''
    ,P_PLANNING_TYPE        IN CHAR :=''
    ,P_USER_ID              IN VARCHAR2 :=''
    ,P_RT_ROLLBACK_FLAG OUT VARCHAR2
    ,P_RT_MSG OUT VARCHAR2
)
IS
    P_SET_ID CHAR(32) :='';
    P_PP_NAME VARCHAR2(30) :='';
    P_VER_ID VARCHAR2(30) :='';
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG  VARCHAR2(4000) :='';

BEGIN
    P_ERR_MSG := 'MSG_0006';
    IF NVL(P_PLANNING_TYPE, ' ') = ' ' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;

    P_SET_ID :=  TO_SINGLE_BYTE(SYS_GUID());

    SELECT B.COMN_CD INTO P_PP_NAME
      FROM TB_AD_COMN_GRP A
           INNER JOIN TB_AD_COMN_CODE B
           ON  A.ID = B.SRC_ID
     WHERE 1=1
	   AND A.GRP_CD='PLAN_POLICY_NAMING_RULE';
       
    SELECT P_PP_NAME||' - '||LPAD(NVL(MAX(TO_NUMBER(SUBSTR(A.VER_ID,-3))),0) + 1,3,'0') INTO P_VER_ID
      FROM TB_CM_PLAN_POLICY_MGMT A
           INNER JOIN TB_CM_PLAN_POLICY_VALUE B
           ON  A.ID = B.PLAN_POLICY_MGMT_ID
           INNER JOIN TB_CM_PLAN_POLICY_MST C
           ON  B.PLAN_POLICY_MST_ID = C.ID
     WHERE 1=1
       AND C.PLAN_POLICY_ITEM_ID = 'M00010000'
       AND B.PLAN_POLICY_VAL_01 =P_MODULE_ID;

    INSERT INTO TB_CM_PLAN_POLICY_MGMT
      (ID
      ,VER_ID
	  ,ACTV_YN
      ,CREATE_BY
      ,CREATE_DTTM
      )
      SELECT P_SET_ID
             ,P_VER_ID
             ,CASE WHEN P_ACTV_YN IN ('true', 'Y') THEN 'Y' ELSE 'N' END
      	     ,P_USER_ID
      	     ,SYSDATE
        FROM DUAL;

    INSERT INTO TB_CM_PLAN_POLICY_VALUE
      (ID
	  ,PLAN_POLICY_MGMT_ID
      ,PLAN_POLICY_MST_ID
      ,PLAN_POLICY_DTL_ID
      ,PLAN_POLICY_VAL_01
	  ,ACTV_YN
      ,CREATE_BY
      ,CREATE_DTTM
      )
      SELECT 
              TO_SINGLE_BYTE(SYS_GUID())
      	     ,P_SET_ID
      	     ,A.ID
      		 ,CASE WHEN A.SINGLE_VAL_YN = 'N' THEN B.ID ELSE NULL END
      		 ,P_MODULE_ID
			 ,'Y'
      	     ,P_USER_ID
      	     ,SYSDATE
      	FROM  TB_CM_PLAN_POLICY_MST A 
                INNER JOIN TB_CM_PLAN_POLICY_DTL B
                ON A.ID = B.PLAN_POLICY_MST_ID
       WHERE 1=1
      	 AND A.PLAN_POLICY_ITEM_ID ='M00010000'	  
      UNION ALL
      SELECT  TO_SINGLE_BYTE(SYS_GUID())
      	     ,P_SET_ID
      	     ,A.ID
      		 ,CASE WHEN A.SINGLE_VAL_YN = 'N' THEN B.ID ELSE NULL END
      		 ,P_PLAN_POLICY_DESCP
			 ,'Y'
      	     ,P_USER_ID
      	     ,SYSDATE
      	FROM  TB_CM_PLAN_POLICY_MST A 
                    INNER JOIN TB_CM_PLAN_POLICY_DTL B 
                    ON A.ID = B.PLAN_POLICY_MST_ID
       WHERE 1=1
      	 AND A.PLAN_POLICY_ITEM_ID ='M00020000'	  
      UNION ALL
      SELECT  TO_SINGLE_BYTE(SYS_GUID())
      	     ,P_SET_ID
      	     ,A.ID
      		 ,CASE WHEN A.SINGLE_VAL_YN = 'N' THEN B.ID ELSE NULL END
      		 ,NULL
			 ,'Y'
      	     ,P_USER_ID
      	     ,SYSDATE
      	FROM  TB_CM_PLAN_POLICY_MST A 
                    INNER JOIN TB_CM_PLAN_POLICY_DTL B
                    ON A.ID = B.PLAN_POLICY_MST_ID
       WHERE 1=1
      	 AND A.PLAN_POLICY_ITEM_ID ='M00030000'
      	 AND B.ID = P_PLANNING_TYPE	;  

    INSERT INTO TB_CM_PLAN_POLICY_VALUE
      (ID
	  ,PLAN_POLICY_MGMT_ID
      ,PLAN_POLICY_MST_ID
      ,PLAN_POLICY_DTL_ID
	  ,ACTV_YN
      ,CREATE_BY
      ,CREATE_DTTM
      )
      SELECT  TO_SINGLE_BYTE(SYS_GUID())
      	     ,P_SET_ID
			 ,A.ID
	         ,CASE WHEN A.SINGLE_VAL_YN ='N' THEN B.ID ELSE NULL END AS PLAN_POLICY_DTL_ID 
			 ,'Y'
			 ,P_USER_ID
      	     ,SYSDATE
        FROM  TB_CM_PLAN_POLICY_MST A 
                    INNER JOIN TB_CM_PLAN_POLICY_DTL B 
                    ON A.ID = B.PLAN_POLICY_MST_ID
       WHERE 1=1 
         AND A.ACTV_YN = 'Y'
         AND B.ACTV_YN = 'Y'
         AND A.PLAN_POLICY_ITEM_ID NOT IN ('M00010000','M00020000','M00030000')
         AND CASE WHEN A.SINGLE_VAL_YN = 'N' AND B.DEFAT_VAL_YN = 'Y' THEN 1
                  WHEN A.SINGLE_VAL_YN = 'N' AND B.DEFAT_VAL_YN = 'N' THEN 0
                  WHEN A.SINGLE_VAL_YN = 'Y'                          THEN 1
                  ELSE 0
             END  = 1 
	   UNION ALL
      SELECT  TO_SINGLE_BYTE(SYS_GUID())
      	     ,P_SET_ID
			 ,A.ID
	         ,NULL AS PLAN_POLICY_DTL_ID 
			 ,'Y'
			 ,P_USER_ID
      	     ,SYSDATE
        FROM  TB_CM_PLAN_POLICY_MST A 
	  WHERE 1=1
	    AND A.ACTV_YN = 'Y'
		AND A.GRID_VAL_YN = 'Y';

    INSERT INTO TB_CM_GRID_VALUE
    (ID
    ,PLAN_POLICY_VAL_ID
    ,PLAN_POLICY_DTL_ID
    ,PRIORT
    ,ACTV_YN
    ,CREATE_BY
    ,CREATE_DTTM
    )
    SELECT  TO_SINGLE_BYTE(SYS_GUID()) AS ID
           ,A.ID AS PLAN_POLICY_VAL_ID
           ,C.ID
           ,NULL
           ,'N'
           ,P_USER_ID
           ,SYSDATE
      FROM  TB_CM_PLAN_POLICY_VALUE A 
                    INNER JOIN TB_CM_PLAN_POLICY_MST B 
                    ON A.PLAN_POLICY_MST_ID = B.ID
                    INNER JOIN TB_CM_PLAN_POLICY_DTL C
                    ON B.ID = C.PLAN_POLICY_MST_ID
     WHERE 1=1
       AND A.PLAN_POLICY_MGMT_ID=P_SET_ID
       AND B.GRID_VAL_YN = 'Y'
       AND B.PLAN_POLICY_ITEM_ID IN ('M00320000','M00330000');

    INSERT INTO TB_CM_MULTI_LV_ALLOC_RULE
    (
    ID, 
    PLAN_POLICY_MGMT_ID, 
    PLAN_POLICY_DTL_ID, 
    ACTV_YN, 
    APPY_SEQ, 
    CREATE_BY, 
    CREATE_DTTM
    )
    SELECT  TO_SINGLE_BYTE(SYS_GUID()) AS ID
           ,A.PLAN_POLICY_MGMT_ID
           ,C.ID
           ,'N'
           ,NULL
           ,P_USER_ID
           ,SYSDATE
      FROM  TB_CM_PLAN_POLICY_VALUE A
                    INNER JOIN TB_CM_PLAN_POLICY_MST B 
                    ON A.PLAN_POLICY_MST_ID = B.ID
                    INNER JOIN TB_CM_PLAN_POLICY_DTL C
                    ON B.ID = C.PLAN_POLICY_MST_ID
     WHERE 1=1
       AND A.PLAN_POLICY_MGMT_ID=P_SET_ID
       AND B.GRID_VAL_YN = 'Y'
       AND B.PLAN_POLICY_ITEM_ID ='M00430000';

    INSERT INTO TB_CM_SUB_PRIORITY
    (
    ID
    ,PLAN_POLICY_MGMT_ID
    ,CATAGY_TP
    ,POLICY_TP
    ,POLICY_TP_NM
    ,CHANNEL_TP_ID
    ,DMND_TP_PRIORT_RULE_ID
    ,DMND_CLASS_TP_ID
    ,URGENT_ORDER_TP_ID
    ,PRIORT
    ,ACTV_YN
    ,CREATE_BY
    ,CREATE_DTTM
    )
    SELECT  
            TO_SINGLE_BYTE(SYS_GUID())
           ,P_SET_ID AS PLAN_POLICY_MGMT_ID
           ,A.CATAGY_TP
           ,B.POLICY_TP
           ,B.POLICY_TP_NM
           ,B.CHANNEL_TP_ID
           ,B.DMND_TP_PRIORT_RULE_ID
           ,B.DMND_CLASS_TP_ID
           ,B.URGENT_ORDER_TP_ID
           ,NULL AS PRIORT
           ,'N' AS ACTV_YN
           ,P_USER_ID
           ,SYSDATE
      FROM (SELECT 'PP_CON_07' AS CATAGY_TP FROM DUAL) A ,
           (
            SELECT 	'CHANNEL_TYPE' AS POLICY_TP
                   ,'Channel Type' AS POLICY_TP_NM
                   ,A.ID AS CHANNEL_TP_ID
                   ,NULL AS DMND_TP_PRIORT_RULE_ID
                   ,NULL AS DMND_CLASS_TP_ID
                   ,NULL  AS URGENT_ORDER_TP_ID
              FROM TB_CM_CHANNEL_TYPE A 
            UNION ALL
			SELECT  'DEMAND_TYPE' AS POLICY_TP
				   ,'Demand Type' AS POLICY_TP_NM
				   ,NULL AS CHANNEL_TP_ID
				   ,B.ID  AS DMND_TP_PRIORT_RULE_ID
				   ,NULL AS DMND_CLASS_TP_ID
				   ,NULL  AS URGENT_ORDER_TP_ID
			 FROM  TB_AD_COMN_GRP A 
				   INNER JOIN TB_AD_COMN_CODE B 
				   ON A.ID = B.SRC_ID
				   AND A.GRP_CD='DEMAND_TYPE'
            WHERE 1=1
            UNION ALL
            SELECT  'DEMAND_CLASS' AS POLICY_TP
                   ,'Demand Class' AS POLICY_TP_NM
                   ,NULL AS CHANNEL_TP_ID
                   ,NULL  AS DMND_TP_PRIORT_RULE_ID
                   ,B.ID AS DMND_CLASS_TP_ID
                   ,NULL  AS URGENT_ORDER_TP_ID
             FROM  TB_AD_COMN_GRP A
                   INNER JOIN  TB_AD_COMN_CODE B
                   ON A.ID = B.SRC_ID
            WHERE 1=1
              AND A.GRP_CD='DEMAND_CLASS'
            UNION ALL
            SELECT  'URGENT_ORDER_TYPE' AS POLICY_TP
                   ,'Urgent Order Type' AS POLICY_TP_NM
                   ,NULL  AS CHANNEL_TP_ID
                   ,NULL  AS DMND_TP_PRIORT_RULE_ID
                   ,NULL  AS DMND_CLASS_TP_ID
                   ,B.ID  AS URGENT_ORDER_TP_ID
             FROM  TB_AD_COMN_GRP A 
                   INNER JOIN TB_AD_COMN_CODE B
                   ON A.ID = B.SRC_ID
            WHERE 1=1
              AND A.GRP_CD='URGENT_ORDER_TYPE'
           ) B;

    INSERT INTO TB_CM_GRID_VALUE
    (
    ID
    ,PLAN_POLICY_VAL_ID
    ,GRID_VAL_01
    ,GRID_VAL_02
    ,CREATE_BY
    ,CREATE_DTTM
    )
    SELECT  TO_SINGLE_BYTE(SYS_GUID())
           ,A.ID AS PLAN_POLICY_VAL_ID
           ,B.LOC_MST_ID
           ,B.LOC_DTL_ID
           ,P_USER_ID
           ,SYSDATE
      FROM (
            SELECT  B.ID
              FROM  TB_CM_PLAN_POLICY_MGMT A
                        INNER JOIN TB_CM_PLAN_POLICY_VALUE B
                        ON A.ID = B.PLAN_POLICY_MGMT_ID
                        INNER JOIN TB_CM_PLAN_POLICY_MST C
                        ON B.PLAN_POLICY_MST_ID = C.ID
             WHERE 1=1
               AND A.ID=P_SET_ID
               AND C.PLAN_POLICY_ITEM_ID IN ('M00210000','M00230000')
           ) A ,
           (
            SELECT  A.ID AS LOC_MST_ID
                   ,B.ID AS LOC_DTL_ID
              FROM  TB_CM_LOC_MST A
                        INNER JOIN TB_CM_LOC_DTL B 
                        ON A.ID = B.LOCAT_MST_ID
             WHERE 1=1
               AND A.ACTV_YN = 'Y'
               AND B.ACTV_YN = 'Y'
           ) B;

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';

EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN 
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;
      ELSE
          RAISE;
      END IF;
END;
/

