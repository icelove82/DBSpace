create PROCEDURE                "SP_UI_DP_04_D1" (
    p_CUST_CD           IN  VARCHAR2 := '' 
  , P_RT_ROLLBACK_FLAG  OUT VARCHAR2 
  , P_RT_MSG            OUT VARCHAR2 	                                             
) IS
    P_ERR_STATUS INT := 0;
    P_ERR_MSG VARCHAR2(4000):='';
BEGIN

    IF (p_CUST_CD IS NULL) THEN
        P_ERR_MSG := 'MSG_0006';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);  
    END IF;

	DELETE FROM TB_CM_CUSTOMER 
	 WHERE CUST_CD = p_CUST_CD;
	 
    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0002';  --


       /* ============================================================================*/
EXCEPTION WHEN OTHERS THEN  -- e_products_invalid    
    IF (SQLCODE = -20001) THEN
        P_ERR_MSG := SQLERRM;
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
    --SP_COMM_RAISE_ERR();              
        RAISE;
    END IF; 
END;
/

