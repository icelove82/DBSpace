create PROCEDURE "SP_UI_CM_13_Q1" (
    P_LOC_TP            IN VARCHAR2 :='',
    P_LOC_LV            IN VARCHAR2 :='',
    P_LOC_CD            IN VARCHAR2 :='',
    P_LOC_NM            IN VARCHAR2 :='',
    P_WH_TP             IN VARCHAR2 :='',
    P_LOAD_CAPA_BASE    IN VARCHAR2 :='',
    P_ACTV_YN           IN VARCHAR2 :='',
    pResult OUT SYS_REFCURSOR
)
IS  
BEGIN
   
    OPEN pResult FOR
    SELECT   A.ID				      AS WH_MGMT_ID
		   , B.ID				      AS LOCAT_MGMT_ID
		   , C.ID				      AS LOC_DTL_ID
		   , D.ID				      AS LOC_MST_ID
		   , F.COMN_CD_NM		      AS LOCAT_TP
		   , D.LOCAT_LV				  AS LOCAT_LV
		   , C.LOCAT_CD				  AS LOCAT_CD
		   , C.LOCAT_NM				  AS LOCAT_NM
		   , A.WAREHOUSE_TP_ID		  AS WAREHOUSE_TP_ID
		   , A.WAREHOUSE_TP			  AS WAREHOUSE_TP
		   , A.WAREHOUSE_TP_NM		  AS WAREHOUSE_TP_NM
		   , A.LOAD_CAPA_MGMT_BASE	  AS LOAD_CAPA_MGMT_BASE
           , A.LIMIT_VAL              AS CAPA_LIMIT_VAL
		   , A.ACTV_YN				  AS ACTV_YN
		   , A.CREATE_BY			  AS CREATE_BY
		   , A.CREATE_DTTM			  AS CREATE_DTTM
		   , A.MODIFY_BY			  AS MODIFY_BY
		   , A.MODIFY_DTTM			  AS MODIFY_DTTM
	  FROM (
           SELECT A.ID, A.LOCAT_MGMT_ID, A.WAREHOUSE_TP_ID, 
                  C.WAREHOUSE_TP, C.WAREHOUSE_TP_NM, C.LOAD_CAPA_MGMT_BASE, 
                  NVL(B.LIMIT_VAL, A.CAPA_LIMIT_VAL) AS LIMIT_VAL,
                  A.ACTV_YN, A.CREATE_DTTM, A.CREATE_BY, A.MODIFY_DTTM, A.MODIFY_BY
             FROM TB_CM_SITE_WAREHOUSE_MGMT A
                  LEFT OUTER JOIN 
                  (
                  SELECT SITE_WAREHOUSE_MGMT_ID, SUM(LIMIT_VAL) LIMIT_VAL
                    FROM TB_CM_SITE_WH_MGMT_DTL
                   GROUP BY SITE_WAREHOUSE_MGMT_ID        
                  ) B
                  ON A.ID = B.SITE_WAREHOUSE_MGMT_ID,
                  TB_CM_WAREHOUSE_TYPE C
            WHERE C.ID = A.WAREHOUSE_TP_ID
           ) A
	       INNER JOIN 
		   TB_CM_LOC_MGMT B 
		ON (A.LOCAT_MGMT_ID = B.ID)
		   INNER JOIN
		   TB_CM_LOC_DTL C 
	    ON (C.ID = B.LOCAT_ID)
		   INNER JOIN
		   TB_CM_LOC_MST D 
	    ON (C.LOCAT_MST_ID = D.ID)
		   INNER JOIN
		   TB_CM_CONFIGURATION E
	    ON (D.CONF_ID = E.ID)
		   LEFT OUTER JOIN
		   TB_AD_COMN_CODE F
		ON (F.ID = D.LOCAT_TP_ID)
	 WHERE 1=1
 	   AND F.COMN_CD_NM		LIKE '%'||LTRIM(RTRIM(P_LOC_TP))||'%'
 	   AND D.LOCAT_LV		LIKE '%'||LTRIM(RTRIM(P_LOC_LV))||'%'
 	   AND C.LOCAT_CD		LIKE '%'||LTRIM(RTRIM(P_LOC_CD))||'%'
 	   AND C.LOCAT_NM		LIKE '%'||LTRIM(RTRIM(P_LOC_NM))||'%'
 	   AND A.WAREHOUSE_TP_NM LIKE '%'||LTRIM(RTRIM(P_WH_TP))||'%'
       AND UPPER(A.LOAD_CAPA_MGMT_BASE) LIKE '%'||UPPER(LTRIM(RTRIM(P_LOAD_CAPA_BASE)))||'%'
 	   AND A.ACTV_YN = CASE WHEN P_ACTV_YN = 'A' OR P_ACTV_YN IS NULL
	                        THEN A.ACTV_YN
							ELSE P_ACTV_YN END
    ORDER BY F.SEQ, D.LOCAT_LV, C.LOCAT_CD, A.WAREHOUSE_TP;

END;

/

