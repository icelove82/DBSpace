create PROCEDURE                "SP_UI_BF_56_Q2" (
    P_S_DATE            DATE 
  , P_E_DATE            DATE 
  , P_FACTOR_CD         VARCHAR2 := ''
  , P_FACTOR_DESCRIP    VARCHAR2 := ''
  , P_ITEM_CD           VARCHAR2 := ''
  , P_ITEM_NM           VARCHAR2 := ''
  , P_ACCT_CD           VARCHAR2 := ''
  , P_ACCT_NM           VARCHAR2 := ''
  , P_FACTOR_SET        VARCHAR2 := ''
  , pRESULT             OUT SYS_REFCURSOR
) IS

    QUERY VARCHAR2(32767) := '';

BEGIN
    -- START DYNAMIC QUERY WITH 'WITH' TEMP TABLE
    -- THE TABLE HAS ITEM/ACCOUNT CD AND NM WITH SEARCH FILTER APPLIED
    QUERY := '
        WITH
        ITEM_ACCOUNT_POOL AS (
           SELECT DISTINCT 
                  IAM.ITEM_CD
                , IM.ITEM_NM
                , IAM.ACCOUNT_CD
                , AM.ACCOUNT_NM
             FROM TB_BF_ITEM_ACCOUNT_MODEL_MAP IAM
                  INNER JOIN
                  TB_CM_ITEM_MST IM
               ON IM.ITEM_CD = IAM.ITEM_CD
                  INNER JOIN
                  TB_DP_ACCOUNT_MST AM
               ON AM.ACCOUNT_CD = IAM.ACCOUNT_CD
            WHERE (REGEXP_LIKE (
                       UPPER(IAM.ITEM_CD)
                     , ''' || REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[') || '''
                   )
                OR ''' || P_ITEM_CD || ''' IS NULL
              )
              AND (REGEXP_LIKE (
                       UPPER(IM.ITEM_NM)
                     , ''' || REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[') || '''
                   )
                OR ''' || P_ITEM_NM || ''' IS NULL
              )
              AND (REGEXP_LIKE (
                       UPPER(IAM.ACCOUNT_CD)
                     , ''' || REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[') || '''
                   )
                OR ''' || P_ACCT_CD || ''' IS NULL
              )
              AND (REGEXP_LIKE (
                       UPPER(AM.ACCOUNT_NM)
                     , ''' || REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ACCT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[') || '''
                   )
                OR ''' || P_ACCT_NM || ''' IS NULL
              )
        )';

    -- SALES FACTOR STATISTICS PER ITEM/ACCOUNT PAIR
    FOR FCTR_INFO IN (
        SELECT COL_NM AS COL
             , FACTOR_CD AS FCTR
             , DESCRIP
          FROM TB_BF_FACTOR_MGMT
         WHERE COALESCE(DEL_YN, 'Y') = 'N'
           AND ACTV_YN = 'Y'
           AND COL_NM IN (
            SELECT COLUMN_NAME
              FROM ALL_TAB_COLS
             WHERE TABLE_NAME = 'TB_BF_SALES_FACTOR'
           )
           -- FACTOR_SET FILTER
           AND (
            (FACTOR_CD IN (
                SELECT FACTOR_CD
                  FROM TB_BF_FACTOR_SET
                 WHERE FACTOR_SET_CD = P_FACTOR_SET
                )
            ) OR P_FACTOR_SET IS NULL
           )
           -- FACTOR_CD FILTER (MULTI SEARCH)
           AND (REGEXP_LIKE(
                    UPPER(FACTOR_CD)
                  , REPLACE(REPLACE(REPLACE(REPLACE(
                        UPPER(P_FACTOR_CD)
                      , ')', '\)'), '(', '\('), ']', '\]'), '[', '\['
                    )
                )
             OR P_FACTOR_CD IS NULL
           )
           -- FACTOR_DESCRIP FILTER (MULTI SEARCH)
           AND (REGEXP_LIKE(
                    UPPER(DESCRIP)
                  , REPLACE(REPLACE(REPLACE(REPLACE(
                        UPPER(P_FACTOR_DESCRIP)
                      , ')', '\)'), '(', '\('), ']', '\]'), '[', '\['
                    )
                )
             OR P_FACTOR_DESCRIP IS NULL
           )
    )
    LOOP
    QUERY := QUERY || '
        SELECT ''' || FCTR_INFO.COL    || '''    AS "FACTOR_COL"
			 , ''' || FCTR_INFO.FCTR || '''    AS "FACTOR_CD"
             , ''' || FCTR_INFO.DESCRIP || '''    AS "DESCRIP"
             , SF.ITEM_CD       AS "ITEM_CD"
             , IAP.ITEM_NM      AS "ITEM_NM"
             , SF.ACCOUNT_CD    AS "ACCOUNT_CD"
             , IAP.ACCOUNT_NM   AS "ACCOUNT_NM"
             , COUNT(SF.' || FCTR_INFO.COL || ')   AS "COUNT"
             , AVG(SF.'   || FCTR_INFO.COL || ')   AS "AVG"
             , COALESCE(STDDEV(SF.' || FCTR_INFO.COL || '), 0) AS "STDEV"
             , MIN(SF.'   || FCTR_INFO.COL || ')   AS "MIN"
             , MAX(SF.'   || FCTR_INFO.COL || ')   AS "MAX"
             , MAX(MD.'   || FCTR_INFO.COL || ')   AS "MODE"
             , COALESCE(STDDEV(SF.' || FCTR_INFO.COL || '), 0) / (CASE WHEN AVG(SF.' || FCTR_INFO.COL || ') = 0 THEN 1 ELSE AVG(SF.' || FCTR_INFO.COL || ') END) AS "COV"
          FROM TB_BF_SALES_FACTOR SF
               INNER JOIN
               ITEM_ACCOUNT_POOL IAP
            ON IAP.ITEM_CD = SF.ITEM_CD
           AND IAP.ACCOUNT_CD = SF.ACCOUNT_CD
               INNER JOIN (
                SELECT ITEM_CD
                     , ACCOUNT_CD
                     , ' || FCTR_INFO.COL || '
                     , CNT
                  FROM (
                    SELECT ITEM_CD
                         , ACCOUNT_CD
                         , ' || FCTR_INFO.COL || '
                         , COUNT(1)  CNT
                         , ROW_NUMBER() OVER (PARTITION BY ITEM_CD, ACCOUNT_CD ORDER BY COUNT(1) DESC) RID
                      FROM TB_BF_SALES_FACTOR
                     WHERE BASE_DATE BETWEEN ''' || P_S_DATE || ''' AND ''' || P_E_DATE || '''
					   AND ' || FCTR_INFO.COL || ' is not null
                     GROUP BY ITEM_CD, ACCOUNT_CD, ' || FCTR_INFO.COL || '
                  ) MD
                 WHERE RID = 1
               ) MD
            ON MD.ITEM_CD = SF.ITEM_CD
           AND MD.ACCOUNT_CD = SF.ACCOUNT_CD
         WHERE BASE_DATE BETWEEN ''' || P_S_DATE || ''' AND ''' || P_E_DATE || '''
         GROUP BY SF.ITEM_CD, IAP.ITEM_NM, SF.ACCOUNT_CD, IAP.ACCOUNT_NM
        UNION
    ';
    END LOOP;


    -- NULL LINE TO HANDLE FINAL UNION
    QUERY := QUERY || '
        SELECT NULL AS "FACTOR_COL"
			 , NULL AS "FACTOR_CD"                                  
             , NULL AS "DESCRIP"     
             , NULL AS "ITEM_CD"
             , NULL AS "ITEM_NM"
             , NULL AS "ACCOUNT_CD"
             , NULL AS "ACCOUNT_NM"
             , NULL AS "COUNT"
             , NULL AS "AVG"
             , NULL AS "STDEV"
             , NULL AS "MIN"
             , NULL AS "MAX"
             , NULL AS "MODE"
             , NULL AS "COV"
          FROM DUAL
         WHERE 1=0
         ORDER BY FACTOR_CD, ITEM_CD, ITEM_NM, ACCOUNT_CD, ACCOUNT_NM
       ';

    -- RUN THE DYNAMIC QUERY
    OPEN pRESULT FOR QUERY;
    
END;
/

