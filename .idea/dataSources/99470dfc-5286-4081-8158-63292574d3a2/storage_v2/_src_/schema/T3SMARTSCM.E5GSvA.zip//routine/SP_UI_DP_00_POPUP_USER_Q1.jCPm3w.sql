create PROCEDURE                "SP_UI_DP_00_POPUP_USER_Q1" (
    p_EMP_NO    IN VARCHAR2 := ''
  , p_EMP_NM    IN VARCHAR2 := ''
  , p_USER_ID   IN VARCHAR2 :=''
  , pRESULT     OUT SYS_REFCURSOR
)
IS 
 P_AUTHORITY  INT ;
/************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID     
    - 2021.04.13 AUTHORITY 체크로 로 delegation user 확인
************************************************************************/
BEGIN
    select count(AUTHORITY) into P_AUTHORITY from TB_AD_AUTHORITY a
    inner join TB_AD_USER u  on a.user_id = u.id and AUTHORITY = 'ADMIN' and u.USERNAME = p_USER_ID;


    IF (P_AUTHORITY > 0 OR p_USER_ID = 'LOGIN_ID_IGNORE_ALL_LOAD' )
      THEN
        OPEN pRESULT 
        FOR 
        SELECT DISTINCT	  
               US.ID
             , US.USERNAME AS EMP_NO
             , US.USERNAME AS USER_ID
             , US.DISPLAY_NAME AS EMP_NM 
             , US.DEPARTMENT AS DEPT_NM
          FROM TB_AD_USER US
         WHERE UPPER(US.USERNAME) LIKE '%' || UPPER(p_EMP_NO) || '%'            
           AND (COALESCE(UPPER(US.DISPLAY_NAME), '')  LIKE '%' || UPPER(p_EMP_NM) || '%' or p_emp_nm is null)
         ORDER BY US.USERNAME;
    ELSE
        OPEN pRESULT 
        FOR SELECT US.ID
                 , US.USERNAME AS EMP_NO
                 , US.USERNAME AS USER_ID
                 , US.DISPLAY_NAME AS EMP_NM
                 , US.DEPARTMENT AS DEPT_NM
              FROM TB_AD_USER US 
             WHERE ID IN (
                   SELECT DEL.USER_ID 
                     FROM TB_AD_DELEGATION DEL 
                    INNER JOIN TB_AD_USER U ON U.ID = DEL.DELEGATION_USER_ID
                    WHERE U.USERNAME = p_USER_ID 
                      AND (
                               (DEL.APPLY_START_DTTM <= SYSDATE AND DEL.APPLY_END_DTTM > SYSDATE)
                            OR (DEL.APPLY_START_DTTM IS NULL AND DEL.APPLY_END_DTTM > SYSDATE)
                            OR (DEL.APPLY_START_DTTM <= SYSDATE AND DEL.APPLY_END_DTTM IS NULL)
                            OR (DEL.APPLY_START_DTTM IS NULL AND DEL.APPLY_END_DTTM IS NULL)
                           )
                    UNION
                   SELECT p_USER_ID
                     FROM DUAL
                   )
               AND UPPER(US.USERNAME) LIKE '%' || UPPER(p_EMP_NO) || '%'            
               AND COALESCE(UPPER(US.DISPLAY_NAME), '') LIKE '%' || UPPER(p_EMP_NM) || '%'
        ORDER BY US.USERNAME;
    END IF;
 END;
/

