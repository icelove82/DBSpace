create PROCEDURE SP_UI_CM_02_BATCH (
    P_APPLY_POINT_CD        IN VARCHAR2 :=''
   ,P_CHECK_LOCAT           IN CHAR :=''
   ,P_LOCAT_MST_ID          IN CHAR :=''
   ,P_OVERWRITE_DATA_YN     IN CHAR :=''
   ,P_USER_ID               IN VARCHAR2 :=''
   ,P_RT_ROLLBACK_FLAG      OUT VARCHAR2
   ,P_RT_MSG                OUT VARCHAR2
)
IS
    P_ERR_STATUS NUMBER :=0;
    P_ERR_MSG VARCHAR2(4000) :='';

BEGIN	
    /***************************************************************************************************************************************************************************
		거점 정보 생성
		- TB_IF_SITE : IF 받은 데이터 필요
	***************************************************************************************************************************************************************************/
	IF P_OVERWRITE_DATA_YN = 'Y' THEN
        DELETE	FROM TB_CM_LOC_MGMT
        WHERE	LOCAT_ID	IN  (
                                SELECT  ID 
                                FROM	TB_CM_LOC_DTL
                                WHERE	LOCAT_MST_ID =	CASE WHEN P_APPLY_POINT_CD ='PARTIAL' AND P_CHECK_LOCAT = 'Y'
                                                             THEN P_LOCAT_MST_ID
                                                             ELSE LOCAT_MST_ID
                                                        END
                                );

        DELETE	FROM TB_CM_LOC_DTL
        WHERE	LOCAT_MST_ID =	CASE WHEN P_APPLY_POINT_CD ='PARTIAL' AND P_CHECK_LOCAT = 'Y'
                                     THEN P_LOCAT_MST_ID
                                     ELSE LOCAT_MST_ID
                                END;
    END IF;

	MERGE INTO TB_CM_LOC_DTL TARGET
	USING 
		(
		SELECT	D.ID AS LOCAT_MST_ID, 
				A.LOCAT_CD, 
				A.LOCAT_NM
		FROM	TB_IF_SITE A
				INNER JOIN TB_AD_COMN_CODE B
				ON B.COMN_CD_NM = A.LOCAT_TP_NM
				INNER JOIN TB_AD_COMN_GRP C
				ON C.ID = B.SRC_ID
				INNER JOIN TB_CM_LOC_MST D
				ON B.ID = D.LOCAT_TP_ID
				AND D.LOCAT_LV = A.LOCAT_LV
		WHERE	C.GRP_CD = 'LOC_TP'
		AND		NVL(D.ACTV_YN, 'N') = 'Y'
		AND		D.ID	= CASE WHEN P_APPLY_POINT_CD ='PARTIAL' AND P_CHECK_LOCAT = 'Y'
							   THEN P_LOCAT_MST_ID
							   ELSE D.ID
						  END
		) SOURCE
	ON (TARGET.LOCAT_CD = SOURCE.LOCAT_CD)
	WHEN NOT MATCHED THEN
		INSERT 
		(
			ID,
			LOCAT_MST_ID,
			LOCAT_CD,
			LOCAT_NM,
			ACTV_YN,
			CREATE_BY,
			CREATE_DTTM
		)
		VALUES
		(
			TO_SINGLE_BYTE(SYS_GUID()),
			SOURCE.LOCAT_MST_ID,
			SOURCE.LOCAT_CD,
			SOURCE.LOCAT_NM,
			'Y',
			P_USER_ID,
			SYSDATE
		);

	MERGE INTO TB_CM_LOC_MGMT TARGET
	USING 
		(
		SELECT	H.ID AS LOCAT_ID,
				A.LGCY_PLANT_CD, 
				E.ID AS REGION_CD_ID, 
				F.ID AS COUNTRY_CD_ID, 
				CASE WHEN G.ROUTE_CATAGY = 'DISCRETE' THEN G.USE_YN ELSE 'N' END AS DISCRT_YN,
				CASE WHEN G.ROUTE_CATAGY = 'DIVISIBLE' THEN G.USE_YN ELSE 'N' END AS DIVISBL_YN,
				CASE WHEN A.LOCAT_TP_NM IN ('FG','SFG') THEN (SELECT ID FROM TB_AD_COMN_CODE WHERE COMN_CD = 'AR') ELSE NULL END AS PLAN_RES_TP_ID,
                I.INV_KEEPING_COST_RATE
		FROM	TB_IF_SITE A
				INNER JOIN TB_AD_COMN_CODE B
				ON B.COMN_CD_NM = A.LOCAT_TP_NM
				INNER JOIN TB_AD_COMN_GRP C
				ON C.ID = B.SRC_ID
				INNER JOIN TB_CM_LOC_MST D
				ON B.ID = D.LOCAT_TP_ID
				AND D.LOCAT_LV = A.LOCAT_LV
				LEFT OUTER JOIN TB_CM_COMM_CONFIG E
				ON E.CONF_CD = A.REGION_CD
				LEFT OUTER JOIN TB_CM_COMM_CONFIG F
				ON F.CONF_CD = A.COUNTRY_CD
                AND F.CONF_GRP_CD = 'CM_COUNTRY'
				LEFT OUTER JOIN TB_CM_BASE_ROUTE G
				ON D.ID = G.LOCAT_MST_ID
				AND NVL(G.ACTV_YN, 'N') = 'Y'
				INNER JOIN TB_CM_LOC_DTL H
				ON H.LOCAT_CD = A.LOCAT_CD
				LEFT OUTER JOIN TB_IM_INV_KEPPING_COST_RATE I
				ON D.ID = I.LOCAT_MST_ID
		WHERE	C.GRP_CD = 'LOC_TP'
		AND		NVL(D.ACTV_YN, 'N') = 'Y'
		AND		D.ID	= CASE WHEN P_APPLY_POINT_CD ='PARTIAL' AND P_CHECK_LOCAT = 'Y'
							   THEN P_LOCAT_MST_ID
							   ELSE D.ID
						  END
		) SOURCE
	ON (TARGET.LOCAT_ID = SOURCE.LOCAT_ID)
	WHEN NOT MATCHED THEN
		INSERT
		(
			ID, 
			LOCAT_ID, 
			LGCY_PLANT_CD, 
			REGION_CD_ID, 
			COUNTRY_CD_ID, 
			ACTV_YN, 
			OUTSRC_YN, 
			DISCRT_YN, 
			DIVISBL_YN, 
			PLAN_RES_TP_ID, 
            INV_KEEPING_COST_RATE,
			IMMEDIATE_SHIPMENT_YN,
			CREATE_BY, 
			CREATE_DTTM
		)
		VALUES
		(
			TO_SINGLE_BYTE(SYS_GUID()),
			SOURCE.LOCAT_ID, 
			SOURCE.LGCY_PLANT_CD, 
			SOURCE.REGION_CD_ID, 
			SOURCE.COUNTRY_CD_ID, 
			'Y', 
			'N', 
			SOURCE.DISCRT_YN, 
			SOURCE.DIVISBL_YN, 
			SOURCE.PLAN_RES_TP_ID, 
            SOURCE.INV_KEEPING_COST_RATE,
			'N',
			P_USER_ID,
			SYSDATE
		);

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0003';

EXCEPTION
WHEN OTHERS THEN
    P_RT_ROLLBACK_FLAG := 'false';
    IF(SQLCODE = -20012)
        THEN
            P_RT_MSG := P_ERR_MSG;
        ELSE
            P_RT_MSG := SQLERRM;
    END IF;
END;
/

