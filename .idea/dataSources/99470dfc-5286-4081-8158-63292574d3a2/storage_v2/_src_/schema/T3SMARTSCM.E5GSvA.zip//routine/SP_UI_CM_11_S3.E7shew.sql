create PROCEDURE                SP_UI_CM_11_S3 (
    P_WRK_TYPE				IN VARCHAR2 := '',
    P_GLB_PBOM_PRIOD_ID		IN CHAR := '',
    P_GLOBAL_PLAN_BOM_ID    IN CHAR := '',
    P_STRT_DTTM			    IN DATE := '',
    P_END_DTTM			    IN DATE := '',
    P_PRIORT				IN INT := '',
    P_DEL_YN                IN CHAR := '',
    P_USER_ID				IN VARCHAR2 :='',
	P_RT_ROLLBACK_FLAG      OUT VARCHAR2,
	P_RT_MSG                OUT VARCHAR2
)
IS
	P_ERR_STATUS NUMBER :=0;
	P_ERR_MSG  VARCHAR2(4000) :='';
    V_CNT INT :=0;

BEGIN
	P_ERR_MSG := 'MSG_0006';
    IF P_STRT_DTTM IS NULL THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;
    IF P_END_DTTM IS NULL THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;
    IF P_PRIORT IS NULL THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;

	P_ERR_MSG := 'MSG_0007';
	IF P_STRT_DTTM > P_END_DTTM THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;

	P_ERR_MSG := 'MSG_0008';
    IF P_PRIORT IS NOT NULL AND P_PRIORT < 0 THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;

    IF P_GLOBAL_PLAN_BOM_ID IS NOT NULL THEN
        SELECT	COUNT(1) INTO V_CNT
        FROM	TB_CM_GLB_PBOM_PRIOD_PRIOR
        WHERE	GLOBAL_PLAN_BOM_ID = P_GLOBAL_PLAN_BOM_ID
        AND		(STRT_DTTM BETWEEN P_STRT_DTTM AND P_END_DTTM
        OR		END_DTTM BETWEEN P_STRT_DTTM AND P_END_DTTM);

        IF V_CNT > 0 THEN
            P_ERR_MSG := 'MSG_5124';
            RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
        END IF;
    END IF;

	IF P_WRK_TYPE = 'SAVE' THEN
        MERGE INTO TB_CM_GLB_PBOM_PRIOD_PRIOR TARGET
        USING
        (
            SELECT	P_GLB_PBOM_PRIOD_ID	    AS GLB_PBOM_PRIOD_ID,
                    P_GLOBAL_PLAN_BOM_ID	AS GLOBAL_PLAN_BOM_ID,
                    P_STRT_DTTM		        AS STRT_DTTM,
                    P_END_DTTM			    AS END_DTTM,
                    P_PRIORT			    AS PRIORT,
                    P_DEL_YN			    AS DEL_YN
            FROM    DUAL
        ) SOURCE
        ON (TARGET.ID = SOURCE.GLB_PBOM_PRIOD_ID)
        WHEN MATCHED THEN 
            UPDATE	
            SET		TARGET.STRT_DTTM	= SOURCE.STRT_DTTM,
                    TARGET.END_DTTM		= SOURCE.END_DTTM,
                    TARGET.PRIORT		= SOURCE.PRIORT,
                    TARGET.DEL_YN		= SOURCE.DEL_YN,
                    TARGET.MODIFY_BY	= P_USER_ID,
                    TARGET.MODIFY_DTTM	= SYSDATE

        WHEN NOT MATCHED THEN
            INSERT
            (
                ID,
                GLOBAL_PLAN_BOM_ID,
                STRT_DTTM,
                END_DTTM,
                PRIORT,
                DEL_YN,
                CREATE_BY,
                CREATE_DTTM
            )
            VALUES
            (
                TO_SINGLE_BYTE(SYS_GUID()),
                SOURCE.GLOBAL_PLAN_BOM_ID,
                SOURCE.STRT_DTTM,
                SOURCE.END_DTTM,
                SOURCE.PRIORT,
                'N',
                P_USER_ID,
                SYSDATE
            );

        P_RT_MSG := 'MSG_0001';

	ELSIF P_WRK_TYPE = 'DELETE' THEN
        DELETE
        FROM	TB_CM_GLB_PBOM_PRIOD_PRIOR
        WHERE	ID = P_GLB_PBOM_PRIOD_ID;

        P_RT_MSG := 'MSG_0002';
    END IF;

    P_RT_ROLLBACK_FLAG := 'true';

    EXCEPTION
    WHEN OTHERS THEN
        IF(SQLCODE = -20012)
          THEN
              P_RT_ROLLBACK_FLAG := 'false';
              P_RT_MSG := P_ERR_MSG;
          ELSE
              RAISE;
          END IF;
END;
/

