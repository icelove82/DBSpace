create PROCEDURE                "SP_UI_DP_13_Q1" (
    p_ITEM_LV   IN VARCHAR2 := ''
  , p_ITEM_CD   IN VARCHAR2 := ''
  , pRESULT     OUT SYS_REFCURSOR 
) IS   
                                            
/** PARAMETER ************************************************************************************************************/
    p_SEQ INT := NULL;
    p_COLUMN_CNT INT := 0;
    p_SQL VARCHAR2(4000) := 'SELECT ''' || p_ITEM_LV || ''' AS LV_MGMT_CD, ';
    p_WHILE_CNT INT := 1 ;
    p_COLUMN_NM VARCHAR2(100) := NULL;
    p_COUNT    INT := 3    ;-- COLUMN 
    p_COLUMN_NM_CNT INT := NULL;
    p_WHILE_CNT_02 INT := 1;

BEGIN
/*LV_CD SEQ ******************************************************************************************************************************************/

    IF (p_ITEM_LV IS NOT NULL) THEN
        SELECT MAX(R0WNUM) INTO p_SEQ
          FROM (
            SELECT ROW_NUMBER() OVER (ORDER BY SEQ ASC) AS R0WNUM
              FROM TB_CM_LEVEL_MGMT
             WHERE 1=1
               AND SALES_LV_YN = 'N'
               AND ACCOUNT_LV_YN = 'N'
               AND ACTV_YN = 'Y'
               AND SEQ <= (
                        SELECT SEQ
                          FROM TB_CM_LEVEL_MGMT
                         WHERE LV_CD = p_ITEM_LV
                   )
          );
    ELSE    
        SELECT MAX(R0WNUM) INTO p_SEQ
          FROM (
            SELECT ROW_NUMBER() OVER (ORDER BY SEQ ASC) AS R0WNUM
              FROM TB_CM_LEVEL_MGMT
             WHERE 1=1
               AND SALES_LV_YN = 'N'
               AND ACCOUNT_LV_YN = 'N'
               AND ACTV_YN = 'Y'
        );
    END IF;
/*NULL COLUMN COUNT ****************************************************************************************************************************/

    SELECT COUNT(*) INTO p_COLUMN_CNT
    FROM (
        SELECT NM
          FROM TB_DPD_ITEM_HIERACHY2 MAIN
        UNPIVOT (
            VALUE FOR NM
            IN (
                LVL01_NM     
              , LVL02_NM     
              , LVL03_NM     
              , LVL04_NM     
              , LVL05_NM     
              , LVL06_NM    
              , LVL07_NM     
              , LVL08_NM     
              , LVL09_NM     
              , LVL10_NM    
            )
        ) UNPVT
        GROUP BY NM
    ) RESULT;

    SELECT MIN(A.R0WNUM) INTO p_COLUMN_NM_CNT
      FROM (
        SELECT LV_NM, ROW_NUMBER() OVER (ORDER BY SEQ ASC) AS R0WNUM
          FROM TB_CM_LEVEL_MGMT
         WHERE 1=1
           AND SALES_LV_YN = 'N'
           AND ACCOUNT_LV_YN = 'N'
           AND ACTV_YN = 'Y'
      ) A;
    
    SELECT A.LV_NM INTO p_COLUMN_NM
      FROM (
        SELECT LV_NM, ROW_NUMBER() OVER (ORDER BY SEQ)  AS R0WNUM
          FROM TB_CM_LEVEL_MGMT
         WHERE 1=1
           AND SALES_LV_YN = 'N'
           AND ACCOUNT_LV_YN = 'N'
           AND ACTV_YN = 'Y'
           ) A
     WHERE A.R0WNUM = p_COLUMN_NM_CNT;




    IF (p_COLUMN_CNT<=10) THEN
        p_COLUMN_CNT := p_SEQ; --SET
    ELSE
        p_COLUMN_CNT := p_COLUMN_CNT;
    END IF;


    p_SQL   := p_SQL || 'LVL' || LPAD(TO_CHAR(p_WHILE_CNT),2,'0') || '_CD    AS "I_SEQ001' || p_COLUMN_NM || ',CD", '
                     || 'LVL' || LPAD(TO_CHAR(p_WHILE_CNT),2,'0') || '_NM    AS "I_SEQ002' || p_COLUMN_NM || ',NM" ';

    WHILE(p_WHILE_CNT < p_COLUMN_CNT)
    LOOP
        IF (p_WHILE_CNT < p_COLUMN_CNT) THEN
            p_SQL := p_SQL || ', ';
        END IF;
        p_WHILE_CNT := p_WHILE_CNT+1;
        p_COLUMN_NM_CNT := p_COLUMN_NM_CNT+1;

        SELECT A.LV_NM INTO p_COLUMN_NM
          FROM (
            SELECT LV_NM, ROW_NUMBER() OVER (ORDER BY SEQ) AS R0WNUM
              FROM TB_CM_LEVEL_MGMT
             WHERE 1=1
               AND SALES_LV_YN = 'N'
               AND ACCOUNT_LV_YN = 'N'
               AND ACTV_YN = 'Y'
               ) A
         WHERE A.R0WNUM = p_COLUMN_NM_CNT;


        p_SQL := p_SQL || 'LVL' || LPAD(TO_CHAR(p_WHILE_CNT),2,'0') || '_CD    AS "I_SEQ' || LPAD(TO_CHAR(p_COUNT),3,'0')   || p_COLUMN_NM || ',CD", '
                       || 'LVL' || LPAD(TO_CHAR(p_WHILE_CNT),2,'0') || '_NM    AS "I_SEQ' || LPAD(TO_CHAR(p_COUNT+1),3,'0') || p_COLUMN_NM || ',NM"';
--        SET p_SQL         = p_SQL + 'LVL'+REPLICATE('0', 2-LEN(p_WHILE_CNT))+CONVERT(VARCHAR2(2), p_WHILE_CNT)+'_CD    AS I_SEQ'+REPLICATE('0', 3-LEN(p_WHILE_CNT))+CONVERT(VARCHAR2(2), (p_COUNT))+p_COLUMN_NM+',ITEM_CD, '
--                                  + 'LVL'+REPLICATE('0', 2-LEN(p_WHILE_CNT))+CONVERT(VARCHAR2(2), p_WHILE_CNT)+'_NM    AS I_SEQ'+REPLICATE('0', 3-LEN(p_WHILE_CNT))+CONVERT(VARCHAR2(2), (p_COUNT+1))+p_COLUMN_NM+',ITEM_NM'
        p_COUNT := p_COUNT + 2;
    END LOOP;



    SELECT LV_NM INTO p_COLUMN_NM
      FROM TB_CM_LEVEL_MGMT
     WHERE 1=1
       AND SALES_LV_YN = 'N'
       AND ACCOUNT_LV_YN = 'N'
       AND ACTV_YN = 'Y'
       AND LEAF_YN = 'Y';


--            SELECT p_COLUMN_NM = LV_NM 
--              FROM TB_CM_LEVEL_MGMT 
--             WHERE 1=1
--             AND SALES_LV_YN = 'N'
--             AND ACCOUNT_LV_YN = 'N'
--             AND ACTV_YN = 'Y'
--             AND LEAF_YN = 'Y'
    p_SQL := p_SQL || ',LVL' || LPAD(TO_CHAR(p_WHILE_CNT),2,'0') || '_CD    AS KEY_ITEM_CD, '
                   ||  'LVL' || LPAD(TO_CHAR(p_WHILE_CNT),2,'0') || '_ID    AS KEY_ITEM_ID,'
                   ||  'LVL' || LPAD(TO_CHAR(p_WHILE_CNT),2,'0') || '_NM    AS KEY_ITEM_NM';


    p_SQL := p_SQL || ' FROM TB_DPD_ITEM_HIERACHY2 IH '
                   || ' WHERE '''||p_ITEM_CD||''' IS NULL '
                   || ' OR (REGEXP_LIKE (UPPER(ITEM_CD), ''' || REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')||'''))'
                   || ' OR ''' || P_ITEM_CD || ''' NOT LIKE ''%|% AND COALESCE(UPPER(ITEM_CD), '' '') LIKE ''%'' || ''' || COALESCE(P_ITEM_CD, ' ') || ''' || ''%'' )' 
                   || ' GROUP BY ';

/*GROUP BY ===============================================================================================================================================================================*/

    WHILE (p_WHILE_CNT_02 <= p_COLUMN_CNT)
    LOOP
        p_SQL := p_SQL || 'LVL' || LPAD(TO_CHAR(p_WHILE_CNT_02),2,'0') || '_CD, '
                       || 'LVL' || LPAD(TO_CHAR(p_WHILE_CNT_02),2,'0') || '_NM';
        IF (p_WHILE_CNT_02 < p_COLUMN_CNT) THEN
            p_SQL := p_SQL || ', ';
        END IF;
        p_WHILE_CNT_02 := p_WHILE_CNT_02+1;                            
    END LOOP;


    p_SQL := p_SQL || ' ,LVL' || LPAD(TO_CHAR(p_WHILE_CNT_02-1),2,'0') || '_ID ';

    BEGIN
--      OPEN pRESULT FOR SELECT p_SQL FROM dual;
        OPEN pRESULT FOR p_SQL;
--    p_SQL ;

    END;

END;
/

