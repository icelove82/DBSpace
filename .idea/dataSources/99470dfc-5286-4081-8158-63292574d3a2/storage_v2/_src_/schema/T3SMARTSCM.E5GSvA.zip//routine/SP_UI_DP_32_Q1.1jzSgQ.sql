create PROCEDURE  "SP_UI_DP_32_Q1" (
                                     P_VER_ID			VARCHAR2 		
                                    ,P_SALES_LV_ID		VARCHAR2 	
                                    ,P_RT_MSG       OUT VARCHAR2   
                                    ,pRESULT        OUT SYS_REFCURSOR 
 ) 
IS
  P_START_DATE      DATE ;
  P_END_DATE		DATE ;
  P_CL_AUTH_TP_ID   CHAR(32);
/*************************************************************************************************
    -- History ( Date / writer / Comment )
    -- 2021.10.21 / kim sohee / case when 0 
	- 2023.02.15 / kim sohee / 누락된 AUTH_TP_ID 조건 걸기      
*************************************************************************************************/
BEGIN


	SELECT --TOP 1 p_VER_ID = ID , 
		  FROM_DATE
		, TO_DATE 
        INTO P_START_DATE, P_END_DATE
	  FROM TB_DP_CONTROL_BOARD_VER_MST 
	  WHERE ID = p_VER_ID
	  --ORDER BY CREATE_DTTM DESC
	;
	SELECT CL_LV_MGMT_ID INTO P_CL_AUTH_TP_ID
	  FROM TB_DP_CONTROL_BOARD_VER_DTL 
	 WHERE CONBD_VER_MST_ID = P_VER_ID 
	   AND WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
	   ;
    OPEN pRESULT
    FOR             
     WITH  ACCT 
    AS ( 
        SELECT DISTINCT DESCENDANT_ID  
          FROM TB_DPD_SALES_HIER_CLOSURE  
         WHERE LEAF_YN = 'Y' 
           AND ANCESTER_ID = COALESCE(P_SALES_LV_ID, ANCESTER_ID)
    ), CAL  
    AS (SELECT MIN(DAT) AS STRT_DATE 
             , MAX(DAT) AS END_DATE 
             , MIN(DAT) AS BASE_DATE 
         FROM TB_CM_CALENDAR 
        WHERE DAT BETWEEN P_START_DATE AND P_END_DATE 
     GROUP BY YYYYMM
    ), FINAL_DP AS (	-- 판매 계획? 
         SELECT  CA.BASE_DATE 
                , A.ITEM_MST_ID  
                , A.ACCOUNT_ID 
                , SUM(QTY) AS VAL
                , MAX(US.USERNAME) AS USERNAME
                , MAX(US.DISPLAY_NAME) AS DISPLAY_NAME
          FROM TB_DP_ENTRY A
               INNER JOIN 	   
               ACCT AM 
            ON AM.DESCENDANT_ID = A.ACCOUNT_ID    
               INNER JOIN 
               CAL CA 
            ON A.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE 
               INNER JOIN 
               TB_AD_USER US
            ON A.EMP_ID = US.ID 
         WHERE 1=1
           AND VER_ID = p_VER_ID
           AND AUTH_TP_ID = P_CL_AUTH_TP_ID
     GROUP BY CA.BASE_DATE , A.ITEM_MST_ID, A.ACCOUNT_ID 

    ) , DP_VER 
    AS (SELECT DISTINCT DO.ITEM_MST_ID ,DO.ACCOUNT_ID  
          FROM FINAL_DP DO    
    ) 
    , ACT_SALES AS ( 
         SELECT   A.ITEM_MST_ID  
                , A.ACCOUNT_ID 
                , A.SALES_6M
                , A.SALES_3M
                , A.SALES_1M
          FROM TB_DP_DIMENSION_DATA A  
               INNER JOIN 
               DP_VER V  
            ON A.ITEM_MST_ID = V.ITEM_MST_ID 
           AND A.ACCOUNT_ID = V.ACCOUNT_ID 	
    ) 
    , ANNUAL AS (	-- 사업 계획 ?
         SELECT  CA.BASE_DATE 
                , A.ITEM_MST_ID  
                , A.ACCOUNT_ID 
                , SUM(ANNUAL_QTY) AS VAL
          FROM TB_DP_MEASURE_DATA A  
               INNER JOIN 
               CAL CA 
            ON A.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE 
               INNER JOIN 
               DP_VER V   
            ON A.ITEM_MST_ID = V.ITEM_MST_ID 
           AND A.ACCOUNT_ID = V.ACCOUNT_ID 
         WHERE 1=1
     GROUP BY CA.BASE_DATE 
            , A.ITEM_MST_ID, A.ACCOUNT_ID 
    ) 
     SELECT   VER.BASE_DATE												AS "DATE" 
            , AH.LVL02_ID												AS SALES_ID  
            , AH.LVL02_CD												AS SALES_CD
            , AH.LVL02_NM												AS SALES_NM
            , VER.USERNAME												AS EMP_CD	  
            , MAX(VER.DISPLAY_NAME)										AS EMP_NM	  
            , SUM(COALESCE(SA.SALES_3M, 0))								AS SALES_3M
            , SUM(COALESCE(SA.SALES_1M, 0))								AS SALES_1M
            , SUM(COALESCE(VER.VAL, 0))									AS DP
            , SUM(COALESCE(ANNUAL.VAL, 0))								AS ANNUAL
            , SUM(COALESCE(VER.VAL, 0)) - SUM(COALESCE(ANNUAL.VAL, 0))	AS INDE 
            , CASE WHEN SUM(COALESCE(ANNUAL.VAL, 0)) = 0 then 0 else (SUM(COALESCE(VER.VAL, 0)) - SUM(COALESCE(ANNUAL.VAL, 0))) / SUM(COALESCE(ANNUAL.VAL, 0)) * 100 end  AS INDE_RATE 
        FROM FINAL_DP VER 
             INNER JOIN 
             TB_DPD_ACCOUNT_HIERACHY2 AH 
          ON VER.ACCOUNT_ID = AH.ACCOUNT_ID
             LEFT OUTER JOIN
             ACT_SALES SA
          ON VER.ITEM_MST_ID = SA.ITEM_MST_ID
         AND VER.ACCOUNT_ID = SA.ACCOUNT_ID
             LEFT OUTER JOIN
             ANNUAL
          ON VER.BASE_DATE = ANNUAL.BASE_DATE
         AND VER.ITEM_MST_ID = ANNUAL.ITEM_MST_ID
         AND VER.ACCOUNT_ID = ANNUAL.ACCOUNT_ID
    GROUP BY VER.BASE_DATE  , AH.LVL02_ID, AH.LVL02_CD	, AH.LVL02_NM	, VER.USERNAME
    ORDER BY   AH.LVL02_CD	, AH.LVL02_NM , VER.BASE_DATE
    ;

END
;
/

