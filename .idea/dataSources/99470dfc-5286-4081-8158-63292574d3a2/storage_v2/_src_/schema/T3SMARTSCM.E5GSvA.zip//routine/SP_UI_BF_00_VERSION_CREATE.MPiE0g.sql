create PROCEDURE                "SP_UI_BF_00_VERSION_CREATE" (
    pRESULT OUT SYS_REFCURSOR
)

IS 

--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

    V_VER_CD VARCHAR2(100) := '';
/*
    BF Version Create Procedure
    Description

    Userd View ID / Name
    -- UI_BF_16 / Control Board 
    History (Date / Writer / Comment)
    -- 2019.12.04 / Kim sohee / Add a code about creating version When TB_BF_CONTROL_BOARD_VER_DTL is null (first version)
*/
BEGIN
    SELECT VER_CD
      INTO V_VER_CD
      FROM (
        SELECT VER_CD
          FROM TB_BF_CONTROL_BOARD_VER_DTL
         WHERE ROWNUM < 2
         ORDER BY VER_CD DESC
           );

    OPEN pRESULT
    FOR
    SELECT CASE WHEN SUBSTR(V_VER_CD,4,8) != TO_CHAR(SYSDATE, 'YYYYMMDD')
                     THEN 'BF-' || TO_CHAR(SYSDATE, 'YYYYMMDD') || '-01'
                WHEN SUBSTR(V_VER_CD,4,8) = TO_CHAR(SYSDATE, 'YYYYMMDD')
                     THEN 'BF-' || TO_CHAR(SYSDATE, 'YYYYMMDD') || '-' || TO_CHAR(TO_NUMBER(SUBSTR(V_VER_CD, 13, 2)) + 1, 'fm00')
                WHEN V_VER_CD IS NULL
                     THEN 'BF-' || TO_CHAR(SYSDATE, 'YYYYMMDD') || '-01'
                END AS VER_CD
      FROM DUAL;

END;
/

