create PROCEDURE                  "SP_UI_BF_52_Q2" 
(
	p_VER_ID	  VARCHAR2 := NULL,
	p_ITEM_CD	  VARCHAR2 := NULL,
	p_ACCOUNT_CD  VARCHAR2 := NULL,
    pRESULT       OUT SYS_REFCURSOR
)
IS 
v_FROM_DATE DATE     := '';
v_TO_DATE   DATE     := '';
v_BUKT      VARCHAR(10) := '';
v_ACCURACY_WK			INT := 4;

BEGIN
--	SELECT  TARGET_BUKT_CD
--          , INPUT_FROM_DATE
--          , INPUT_TO_DATE
--          INTO
--            v_BUKT
--          , v_FROM_DATE
--          , v_TO_DATE
--	  FROM (
--		 SELECT DISTINCT  TARGET_BUKT_CD
--					   ,  INPUT_TO_DATE
--                       ,  ( SELECT BASE_DATE
--                             FROM (
--                               SELECT LEAD(MIN(DAT),4) OVER(ORDER BY DP_WK DESC) BASE_DATE
--                                 FROM TB_CM_CALENDAR 
--                                WHERE DAT BETWEEN ADD_MONTHS(TO_DATE('2020-06-21')+1, -1) AND TO_DATE('2020-06-21')+1
--                                GROUP BY DP_WK
--                            )
--                           WHERE ROWNUM=1
--					   )  AS INPUT_FROM_DATE
--			FROM TB_BF_CONTROL_BOARD_VER_DTL
--		   WHERE VER_CD = p_VER_ID
--			 AND ENGINE_TP_CD IS NOT NULL
--		) A
--		;
    SELECT DISTINCT TARGET_BUKT_CD
				  , INPUT_TO_DATE
				  , (
                     SELECT FROM_DATE
                       FROM (
                         SELECT LEAD(MIN(DAT),v_ACCURACY_WK) OVER(ORDER BY CASE WHEN TARGET_BUKT_CD='M' THEN MM ELSE TO_CHAR(DP_WK) END  DESC) as "FROM_DATE"
                           FROM TB_CM_CALENDAR 
                          WHERE DAT BETWEEN CASE WHEN TARGET_BUKT_CD='M' THEN ADD_MONTHS(INPUT_TO_DATE+1, v_ACCURACY_WK*-1) ELSE (INPUT_TO_DATE+1)-v_ACCURACY_WK*7 END
                            AND INPUT_TO_DATE+1
                       GROUP BY CASE WHEN TARGET_BUKT_CD='M' THEN MM ELSE TO_CHAR(DP_WK) END 
                       )
                     WHERE ROWNUM=1
                  )
                    INTO
                    v_BUKT
                  , v_TO_DATE
                  , v_FROM_DATE
               FROM TB_BF_CONTROL_BOARD_VER_DTL
              WHERE VER_CD = p_VER_ID
                AND ENGINE_TP_CD IS NOT NULL
            ;
	/*************************************************************************************************************
		-- ???? ???? ???? ????? ??? ?????? ???? ??? ???? ???? ???
	************************************************************************************************************/

	IF (v_BUKT = 'W')
	THEN
		SELECT MAX(END_DATE) INTO v_TO_DATE
		  FROM (
				SELECT --YYYY
					   DP_WK
					 , MIN(DAT) AS STRT_DATE
					 , MAX(DAT) AS END_DATE
				  FROM TB_CM_CALENDAR C
				 WHERE DAT BETWEEN v_FROM_DATE AND v_TO_DATE
			  GROUP BY YYYY, DP_WK
			  HAVING COUNT(DP_WK) >= 7
			  ) A;
	END IF; 

    OPEN pRESULT FOR
    WITH RT AS (
        SELECT ITEM_CD
             , ACCOUNT_CD
             , BASE_DATE 
             , ENGINE_TP_CD
             , QTY
          FROM TB_BF_RT_HISTORY RF
         WHERE BASE_DATE BETWEEN v_FROM_DATE and v_TO_DATE
           AND RF.ITEM_CD    = p_ITEM_CD	 
           AND RF.ACCOUNT_CD = p_ACCOUNT_CD
    ),
    CALENDAR
    AS (
        SELECT DAT 
             , YYYY
             , YYYYMM
             , CASE v_BUKT
                 WHEN 'W' THEN TO_NUMBER(TO_CHAR(DAT,'IW'))
                 WHEN 'PW' THEN TO_NUMBER(TO_CHAR(DAT,'IW'))
                 WHEN 'M' THEN TO_NUMBER(YYYYMM)
               END AS BUKT
--             , CASE v_BUKT
--                --WHEN 'W' THEN YYYY+' w'  +replicate('0',2-LEN(DP_WK))+CONVERT(NVARCHAR(2),DP_WK)
--                --WHEN 'PW'THEN YYYYMM+' w'+replicate('0',2-LEN(DP_WK))+CONVERT(NVARCHAR(2),DP_WK) 
--                WHEN 'W'   THEN YYYY || ' w' || LPAD(DP_WK, 2, '0')
--                WHEN 'PW'  THEN YYYYMM || ' w' || LPAD(DP_WK, 2, '0')
--                WHEN 'M'   THEN YYYYMM
--                WHEN 'D'   THEN YYYYMMDD 
--               END AS BUKT	
          FROM TB_CM_CALENDAR CA
         WHERE DAT between v_FROM_DATE and v_TO_DATE     
    ), CA
    AS (
        SELECT MIN(DAT)	 STRT_DATE
             --, BUKT	
             , MAX(DAT)	 END_DATE
             , TO_CHAR(MIN(DAT), 'YYYY-MM-DD') AS BUKT
--             , CASE v_BUKT
--                 WHEN 'W' THEN MIN(YYYY) || '-' || BUKT
--                 WHEN 'PW' THEN MIN(YYYYMM) || '-' || BUKT
--                 WHEN 'M' THEN MIN(YYYYMM)
--               END AS BUKT
          FROM CALENDAR CA
         WHERE DAT between v_FROM_DATE and v_TO_DATE 
       GROUP BY BUKT 
    )
--    CA AS (
--        SELECT MIN(DAT)	 STRT_DATE
--             , CASE v_BUKT WHEN 'W' THEN YYYY || ' w' || DP_WK
--                           WHEN 'PW'THEN YYYYMM || ' w' || DP_WK
--                           --WHEN 'W' THEN YYYY+' w'+CONVERT(NVARCHAR(2),DP_WK)   --mssql
--                           --WHEN 'PW'THEN YYYYMM+' w'+CONVERT(NVARCHAR(2),DP_WK) --mssql
--                           WHEN 'M' THEN YYYYMM
--                           WHEN 'D' THEN YYYYMMDD 
--               END AS BUKT	
--             , MAX(DAT)	 END_DATE
--          FROM TB_CM_CALENDAR CA
--         WHERE DAT between v_FROM_DATE and v_TO_DATE 
--       GROUP BY CASE v_BUKT WHEN 'W' THEN YYYY || ' w' || DP_WK
--                            WHEN 'PW'THEN YYYYMM || ' w' || DP_WK
--                            WHEN 'M' THEN YYYYMM
--                            WHEN 'D' THEN YYYYMMDD 
--                            END  
--    )
    , SA AS (
        SELECT ITEM_CD
              , ACCOUNT_CD
              , CA.BUKT 
              , CA.STRT_DATE
              , SUM(QTY)	QTY 
          FROM TB_CM_ACTUAL_SALES S
               INNER JOIN
               CA
            ON S.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
               INNER JOIN 
               TB_CM_ITEM_MST IM 
            ON S.ITEM_MST_ID = IM.ID
           AND COALESCE(IM.DEL_YN,'N') = 'N'
               INNER JOIN 
               TB_DP_ACCOUNT_MST AM
            ON S.ACCOUNT_ID = AM.ID
           AND COALESCE(AM.DEL_YN,'N') = 'N'
           AND AM.ACTV_YN = 'Y'
         WHERE ITEM_CD = p_ITEM_CD
           AND ACCOUNT_CD = p_ACCOUNT_CD
      GROUP BY ITEM_CD, ACCOUNT_CD
              , CA.BUKT
              , CA.STRT_DATE
    ), N
    AS (
        SELECT RT.ITEM_CD					AS ITEM_CD
             , RT.ACCOUNT_CD				AS ACCOUNT_CD
             , BUKT
             , RT.ENGINE_TP_CD
             , SUM(RT.QTY)					AS QTY			 
          FROM RT 
               INNER JOIN 
               CA 
            ON RT.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE 
    GROUP BY ITEM_CD, ACCOUNT_CD, BUKT, ENGINE_TP_CD
         UNION
        SELECT SA.ITEM_CD
             , SA.ACCOUNT_CD
             , BUKT
             , 'Z_ACT_SALES'						AS ENGINE_TP_CD
             , SA.QTY 
          FROM SA
    ), M
    AS (
        SELECT ITEM_CD
              ,ACCOUNT_CD 
              ,ENGINE_TP_CD
              ,BUKT
          FROM CA 
               CROSS JOIN
               ( SELECT ITEM_CD
                       ,ACCOUNT_CD 
                       ,ENGINE_TP_CD
                   FROM N  
               GROUP BY ITEM_CD
                       ,ACCOUNT_CD 
                       ,ENGINE_TP_CD
               ) RT
    )
    SELECT M.ITEM_CD
         , M.ACCOUNT_CD
         , M.ENGINE_TP_CD
         , M.BUKT AS MMWW
         , N.QTY	 
      FROM M
           LEFT OUTER JOIN
           N ON M.ITEM_CD = N.ITEM_CD
              AND M.ACCOUNT_CD = N.ACCOUNT_CD
              AND M.BUKT = N.BUKT
              AND M.ENGINE_TP_CD = N.ENGINE_TP_CD
     ORDER BY M.BUKT
    ;
END;

/

