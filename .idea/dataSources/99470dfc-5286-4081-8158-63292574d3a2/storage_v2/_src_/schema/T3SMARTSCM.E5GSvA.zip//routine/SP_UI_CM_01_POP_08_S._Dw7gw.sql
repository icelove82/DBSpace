create PROCEDURE "SP_UI_CM_01_POP_08_S" (
	 P_ID                       IN VARCHAR2 := ''
	,P_UOM_NM	                IN VARCHAR2 := ''
	,P_ACTV_YN		            IN VARCHAR2 := ''
    ,P_BASE_PLAN_UOM_YN		    IN CHAR := ''
    ,P_BASE_WEIGHT_UOM_YN		IN CHAR := ''
    ,P_TIME_BUCKET_YN		    IN CHAR := ''
    ,P_ACTUAL_REF_YN            IN CHAR := ''
    ,P_TIME_UOM_YN		        IN CHAR := ''
    ,P_USER_ID	                IN VARCHAR2 := ''
    ,P_WRK_TYPE	                IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG         OUT VARCHAR2
    ,P_RT_MSG                   OUT VARCHAR2
)
IS
    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';
    P_CONF_ID VARCHAR2(32) := '';

BEGIN
    P_RT_ROLLBACK_FLAG := 'true';
    
    IF P_WRK_TYPE = 'SAVE'
    THEN
        SELECT MAX(CONF_ID) INTO P_CONF_ID FROM (SELECT ROWNUM, CONF_ID FROM TB_CM_UOM);

        P_ERR_MSG := 'MSG_0005';
		   SELECT COUNT(*) INTO P_ERR_STATUS
			 FROM TB_CM_UOM A
			WHERE 1=1
			  AND A.ID <> P_ID
			  AND A.UOM_NM = P_UOM_NM;
		   IF P_ERR_STATUS > 0 THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
           END IF;

        P_ERR_MSG := 'MSG_0006';
            IF NVL(P_UOM_NM,'') ='' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;

        MERGE INTO TB_CM_UOM B 
        USING (SELECT P_ID AS ID FROM DUAL) A
                ON     (B.ID = A.ID)

        WHEN MATCHED THEN

            UPDATE 
               SET UOM_NM				= P_UOM_NM
                 , ACTV_YN				= P_ACTV_YN
                 , BASE_PLAN_UOM_YN		= P_BASE_PLAN_UOM_YN
                 , BASE_WEIGHT_UOM_YN	= P_BASE_WEIGHT_UOM_YN
                 , TIME_BUCKET_YN       = P_TIME_BUCKET_YN
                 , ACTUAL_REF_YN        = P_ACTUAL_REF_YN
                 , TIME_UOM_YN          = P_TIME_UOM_YN
                 , MODIFY_BY			= P_USER_ID
                 , MODIFY_DTTM			= SYSDATE
        WHEN NOT MATCHED THEN			
        INSERT (
            ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
            , CONF_ID
            , UOM_CD
            , UOM_NM
            , BASE_PLAN_UOM_YN
            , BASE_WEIGHT_UOM_YN
            , TIME_BUCKET_YN
            , ACTUAL_REF_YN
            , TIME_UOM_YN 
            , ACTV_YN
            )
        VALUES 
            (
            TO_SINGLE_BYTE(SYS_GUID()), P_USER_ID, SYSDATE, P_USER_ID, SYSDATE
            , P_CONF_ID
            , UPPER(REPLACE(P_UOM_NM, ' ', '_'))
            , P_UOM_NM
            , P_BASE_PLAN_UOM_YN
            , P_BASE_WEIGHT_UOM_YN
            , P_TIME_BUCKET_YN
            , P_ACTUAL_REF_YN
            , P_TIME_UOM_YN
            , P_ACTV_YN
        );

        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';

    ELSIF P_WRK_TYPE = 'DELETE'
    THEN
    
        DELETE FROM TB_CM_UOM
         WHERE ID = P_ID;
    
        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0002';
    
    END IF;

    EXCEPTION
    WHEN OTHERS THEN
        IF(SQLCODE = -20012)
          THEN
              P_RT_ROLLBACK_FLAG := 'false';
              P_RT_MSG := P_ERR_MSG;
          ELSE
              RAISE;
          END IF;

END;

/

