create PROCEDURE "SP_UI_CM_10_Q1" (
    P_BOD_TP 			IN VARCHAR2 :='',
    P_CONSUME_LOCAT_TP 	IN VARCHAR2 :='',
    P_CONSUME_LOCAT_LV 	IN VARCHAR2 :='',
    P_CONSUME_LOCAT_CD 	IN VARCHAR2 :='',
    P_CONSUME_LOCAT_NM 	IN VARCHAR2 :='',
    P_SUPPLY_LOCAT_TP 	IN VARCHAR2 :='',
    P_SUPPLY_LOCAT_LV 	IN VARCHAR2 :='',
    P_SUPPLY_LOCAT_CD 	IN VARCHAR2 :='',
    P_SUPPLY_LOCAT_NM 	IN VARCHAR2 :='',
    P_VEHICL_TP       	IN VARCHAR2 :='',
    P_ITEM_CD         	IN VARCHAR2 :='',
    P_ITEM_NM         	IN VARCHAR2 :='',
    P_ITEM_TP         	IN VARCHAR2 :='',
    P_PAGE_NO       	IN INT :='',
    P_PAGE_SIZE         IN INT :='',
    pResult 			OUT SYS_REFCURSOR
)
    IS
BEGIN
    OPEN pResult FOR
    WITH TARGET AS (
        SELECT *
        FROM (
                 /***************************************************************
                 -- BOD Type : Site BOD 조회
                 ****************************************************************/
                 SELECT TRM.ID                 AS TRANSP_MGMT_MST_ID
                      , TRM.CONSUME_LOCAT_ITEM_ID
                      , TRM.SUPPLY_LOCAT_ITEM_ID
                      , LMG.ID                 AS CONSUME_LOCAT_MGMT_ID
                      , LMG2.ID                AS SUPPLY_LOCAT_MGMT_ID
                      , IMS.ID                 AS ITEM_MST_ID
                      , TRM.BOD_TP_ID
                      , ACD.COMN_CD_NM         AS BOD_TP
                      --------------------------------------------------------------------
                      -- 소요거점 그룹
                      --------------------------------------------------------------------
                      , A1.COMN_CD_NM          AS CONSUME_LOCAT_TP
                      , A1.SEQ                 AS CONSUME_SEQ
                      , LMS.LOCAT_LV           AS CONSUME_LOCAT_LV
                      , LDT.LOCAT_CD           AS CONSUME_LOCAT_CD
                      , LDT.LOCAT_NM           AS CONSUME_LOCAT_NM
                      , IMS.ITEM_CD            AS CONSUME_ITEM_CD
                      , IMS.ITEM_NM            AS CONSUME_ITEM_NM
                      , ICT.CONVN_NM           AS CONSUME_ITEM_TP
                      , UOM1.UOM_NM            AS CONSUME_ITEM_UOM
                      ----------------------------------------------------------------
                      -- 공급거점 그룹
                      ----------------------------------------------------------------
                      , A4.COMN_CD_NM          AS SUPPLY_LOCAT_TP
                      , A4.SEQ                 AS SUPPLY_SEQ
                      , LMS2.LOCAT_LV          AS SUPPLY_LOCAT_LV
                      , LDT2.LOCAT_CD          AS SUPPLY_LOCAT_CD
                      , LDT2.LOCAT_NM          AS SUPPLY_LOCAT_NM
                      ----------------------------------------------------------------
                      -- 운송수단 그룹
                      ----------------------------------------------------------------
                      , TRM.ACTV_YN            AS BOD_LT_ACTV_YN
                      , TRM.FIXED_YN           AS FIXED_YN
                      , VHC.VEHICL_TP          AS VEHICL_TP
                      , TRM.PRIORT             AS BOD_PRIORITY
                      ----------------------------------------------------------------
                      -- Lead Time 그룹
                      ----------------------------------------------------------------
                      , LT.OUTBOUND_LT_MGMT_YN AS OUTBOUND_LT_MGMT_YN
                      , LT.VOYAGE_LT_MGMT_YN   AS VOYAGE_LT_MGMT_YN
                      , LT.INBOUND_LT_MGMT_YN  AS INBOUND_LT_MGMT_YN
                      , LT.OUTBOUND_LT         AS OUTBOUND_LT
                      , LT.VOYAGE_LT           AS VOYAGE_LT
                      , LT.INBOUND_LT          AS INBOUND_LT
                      , LT.TOTAL_LT            AS TOTAL_LT
                      , UOM3.ID                AS LT_UOM
                      ----------------------------------------------------------------
                      -- 운송수단 그룹
                      ----------------------------------------------------------------
                      , TRM.LOAD_UOM_ID        AS LOAD_UOM_ID
                      , TRM.TRANSP_LOTSIZE     AS TRANSP_LOTSIZE
                      , TRM.UOM_QTY            AS UOM_QTY
                      , TRM.PACKING_QTY        AS PACKING_QTY
                      , PAK.PACKING_NM         AS PACKING_TP
                      , TRM.PALLET_QTY         AS PALLET_QTY
                      , PLT.PALLET_CD          AS PALLET_TP
                      , TRM.CREATE_BY
                      , TRM.CREATE_DTTM
                      , TRM.MODIFY_BY
                      , TRM.MODIFY_DTTM
                 FROM TB_CM_TRANSFER_MGMT_MST TRM
                          INNER JOIN TB_AD_COMN_CODE ACD
                                     ON TRM.BOD_TP_ID = ACD.ID
                          LEFT OUTER JOIN TB_CM_VEHICLE VHC
                                          ON TRM.VEHICL_TP_ID = VHC.ID
                          LEFT OUTER JOIN TB_AD_COMN_CODE A2
                                          ON TRM.LOAD_UOM_ID = A2.ID
                          LEFT OUTER JOIN (
                     SELECT A.TRANSP_MGMT_MST_ID
                          , A.PRIORT
                          , MAX(A.UOM_ID)              AS UOM_ID
                          , MAX(A.OUTBOUND_LT_MGMT_YN) AS OUTBOUND_LT_MGMT_YN
                          , MAX(A.VOYAGE_LT_MGMT_YN)   AS VOYAGE_LT_MGMT_YN
                          , MAX(A.INBOUND_LT_MGMT_YN)  AS INBOUND_LT_MGMT_YN
                          , SUM(A.OUTBOUND_LT)         AS OUTBOUND_LT
                          , SUM(A.VOYAGE_LT)           AS VOYAGE_LT
                          , SUM(A.INBOUND_LT)          AS INBOUND_LT
                          , MAX(A.TOTAL_LT)            AS TOTAL_LT
                     FROM (
                              SELECT TRM.ID                                                           AS TRANSP_MGMT_MST_ID
                                   , TRM.PRIORT
                                   , TRD.UOM_ID
                                   , CASE WHEN ACD.COMN_CD = 'OUTBOUND' THEN BOD.LEADTIME_MGMT_YN END AS OUTBOUND_LT_MGMT_YN
                                   , CASE WHEN ACD.COMN_CD = 'VOYAGE' THEN BOD.LEADTIME_MGMT_YN END   AS VOYAGE_LT_MGMT_YN
                                   , CASE WHEN ACD.COMN_CD = 'INBOUND' THEN BOD.LEADTIME_MGMT_YN END  AS INBOUND_LT_MGMT_YN
                                   , CASE WHEN ACD.COMN_CD = 'OUTBOUND' THEN TRD.LEADTIME END         AS OUTBOUND_LT
                                   , CASE WHEN ACD.COMN_CD = 'VOYAGE' THEN TRD.LEADTIME END           AS VOYAGE_LT
                                   , CASE WHEN ACD.COMN_CD = 'INBOUND' THEN TRD.LEADTIME END          AS INBOUND_LT
                                   , SUM(TRD.LEADTIME) OVER (PARTITION BY TRD.TRANSP_MGMT_MST_ID)     AS TOTAL_LT
                              FROM TB_CM_TRANSFER_MGMT_MST TRM
                                       INNER JOIN TB_CM_TRANSFER_MGMT_DTL TRD
                                                  ON TRM.ID = TRD.TRANSP_MGMT_MST_ID
                                       INNER JOIN TB_CM_BOD_LT BOD
                                                  ON TRD.BOD_LEADTIME_ID = BOD.ID
                                       INNER JOIN TB_AD_COMN_CODE ACD
                                                  ON BOD.LEADTIME_TP_ID = ACD.ID
                          ) A
                     GROUP BY A.TRANSP_MGMT_MST_ID, A.PRIORT
                 ) LT
                                          ON TRM.ID = LT.TRANSP_MGMT_MST_ID
                                              AND NVL(TRM.PRIORT, 0) = NVL(LT.PRIORT, 0)
                          LEFT OUTER JOIN TB_CM_UOM UOM3
                                          ON LT.UOM_ID = UOM3.ID
                          LEFT OUTER JOIN TB_CM_PACKING PAK
                                          ON TRM.PACKING_TP_ID = PAK.ID
                          LEFT OUTER JOIN TB_CM_PALLET PLT
                                          ON TRM.PALLET_TP_ID = PLT.ID
                     --------------------------------------------------------------------
                     -- 소요거점 그룹
                     --------------------------------------------------------------------
                          INNER JOIN TB_CM_SITE_ITEM SIT
                                     ON TRM.CONSUME_LOCAT_ITEM_ID = SIT.ID
                          INNER JOIN TB_CM_ITEM_MST IMS
                                     ON SIT.ITEM_MST_ID = IMS.ID
                          INNER JOIN TB_CM_ITEM_TYPE ICT
                                     ON IMS.ITEM_TP_ID = ICT.ID
                          INNER JOIN TB_CM_UOM UOM1
                                     ON IMS.UOM_ID = UOM1.ID
                          INNER JOIN TB_CM_LOC_MGMT LMG
                                     ON SIT.LOCAT_MGMT_ID = LMG.ID
                          INNER JOIN TB_CM_LOC_DTL LDT
                                     ON LDT.ID = LMG.LOCAT_ID
                          INNER JOIN TB_CM_LOC_MST LMS
                                     ON LDT.LOCAT_MST_ID = LMS.ID
                          INNER JOIN TB_AD_COMN_CODE A1
                                     ON LMS.LOCAT_TP_ID = A1.ID
                     ----------------------------------------------------------------
                     -- 공급거점 그룹
                     ----------------------------------------------------------------
                          INNER JOIN TB_CM_SITE_ITEM SIT2
                                     ON TRM.SUPPLY_LOCAT_ITEM_ID = SIT2.ID
                          INNER JOIN TB_CM_ITEM_MST IMS2
                                     ON SIT2.ITEM_MST_ID = IMS2.ID
                          INNER JOIN TB_CM_ITEM_TYPE ITP2
                                     ON IMS2.ITEM_TP_ID = ITP2.ID
                          INNER JOIN TB_CM_LOC_MGMT LMG2
                                     ON SIT2.LOCAT_MGMT_ID = LMG2.ID
                          INNER JOIN TB_CM_LOC_DTL LDT2
                                     ON LDT2.ID = LMG2.LOCAT_ID
                          INNER JOIN TB_CM_LOC_MST LMS2
                                     ON LDT2.LOCAT_MST_ID = LMS2.ID
                          INNER JOIN TB_AD_COMN_CODE A4
                                     ON LMS2.LOCAT_TP_ID = A4.ID
                      ---------------------------------------------------------------
                      -- 조회 조건
                      ---------------------------------------------------------------
                 WHERE 1 = 1
                   AND UPPER(A1.COMN_CD_NM) LIKE '%' || UPPER(P_CONSUME_LOCAT_TP) || '%'
                   AND LMS.LOCAT_LV LIKE '%' || P_CONSUME_LOCAT_LV || '%'
                   AND UPPER(LDT.LOCAT_CD) LIKE '%' || UPPER(P_CONSUME_LOCAT_CD) || '%'
                   AND UPPER(LDT.LOCAT_NM) LIKE '%' || UPPER(P_CONSUME_LOCAT_NM) || '%'
                   AND UPPER(A4.COMN_CD_NM) LIKE '%' || UPPER(P_SUPPLY_LOCAT_TP) || '%'
                   AND LMS2.LOCAT_LV LIKE '%' || P_SUPPLY_LOCAT_LV || '%'
                   AND UPPER(LDT2.LOCAT_CD) LIKE '%' || UPPER(P_SUPPLY_LOCAT_CD) || '%'
                   AND UPPER(LDT2.LOCAT_NM) LIKE '%' || UPPER(P_SUPPLY_LOCAT_NM) || '%'
                   AND VHC.VEHICL_TP = CASE
                                           WHEN P_VEHICL_TP = 'ALL' OR NVL(P_VEHICL_TP, ' ') = ' '
                                               THEN VHC.VEHICL_TP
                                           ELSE P_VEHICL_TP
                     END
                   AND UPPER(IMS.ITEM_CD) LIKE '%' || UPPER(P_ITEM_CD) || '%'
                   AND UPPER(IMS.ITEM_NM) LIKE '%' || UPPER(P_ITEM_NM) || '%'
                   AND UPPER(ICT.CONVN_NM) LIKE '%' || UPPER(P_ITEM_TP) || '%'
             )
    ), TARGET_CNT AS (
        SELECT COUNT(*) AS TOTAL
        FROM TARGET
    )

    SELECT *
    FROM TARGET T1
         INNER JOIN (
            SELECT TRANSP_MGMT_MST_ID
                 , TOTAL
                 , CASE
                       WHEN MOD(TOTAL, P_PAGE_SIZE) > 0 THEN FLOOR(TOTAL / P_PAGE_SIZE) + 1
                       ELSE TOTAL / P_PAGE_SIZE
                END AS TOTAL_PAGES
            FROM TARGET,
                 TARGET_CNT
            ORDER BY CONSUME_SEQ, CONSUME_LOCAT_LV, CONSUME_LOCAT_CD, CONSUME_ITEM_CD,
                     SUPPLY_SEQ, SUPPLY_LOCAT_LV, SUPPLY_LOCAT_CD, BOD_PRIORITY, VEHICL_TP
            OFFSET P_PAGE_NO * P_PAGE_SIZE ROWS
            FETCH NEXT P_PAGE_SIZE ROWS ONLY
        ) T2
        ON T1.TRANSP_MGMT_MST_ID = T2.TRANSP_MGMT_MST_ID;

END;
/

