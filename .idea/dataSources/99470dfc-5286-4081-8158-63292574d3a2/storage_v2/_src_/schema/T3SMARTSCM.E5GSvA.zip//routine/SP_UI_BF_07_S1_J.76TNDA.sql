create PROCEDURE                "SP_UI_BF_07_S1_J" (
	  P_JSON			CLOB
    , P_USER_ID            VARCHAR2
    , P_RT_ROLLBACK_FLAG   OUT VARCHAR2 
    , P_RT_MSG             OUT VARCHAR2 
) 
IS
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

    P_ERR_STATUS    NUMBER          := 0;
    P_ERR_MSG       VARCHAR2(4000)  := '';

BEGIN
    MERGE INTO TB_BF_SALES_FACTOR TAR
    USING ( 
            SELECT  
            		CAST(ID AS CHAR(32))        			AS ID
            	  , TO_DATE(BASE_DATE, 'YYYY-MM-DD"T"HH24:MI:SS"Z"')		AS BASE_DATE
				  , CAST(ACCOUNT_CD AS VARCHAR2(100)) 		AS ACCOUNT_CD
				  , CAST(ITEM_CD AS VARCHAR2(100))			AS ITEM_CD
				  , CAST(SALES_FACTOR1 AS NUMBER(20,3))		AS SALES_FACTOR1
				  , CAST(SALES_FACTOR2 AS NUMBER(20,3))		AS SALES_FACTOR2
				  , CAST(SALES_FACTOR3 AS NUMBER(20,3))		AS SALES_FACTOR3
				  , CAST(SALES_FACTOR4 AS NUMBER(20,3))		AS SALES_FACTOR4
				  , CAST(SALES_FACTOR5 AS NUMBER(20,3))		AS SALES_FACTOR5
				  , CAST(SALES_FACTOR6 AS NUMBER(20,3))		AS SALES_FACTOR6
				  , CAST(SALES_FACTOR7 AS NUMBER(20,3))		AS SALES_FACTOR7
				  , CAST(SALES_FACTOR8 AS NUMBER(20,3))		AS SALES_FACTOR8
				  , CAST(SALES_FACTOR9 AS NUMBER(20,3))		AS SALES_FACTOR9
				  , CAST(SALES_FACTOR10 AS NUMBER(20,3))	AS SALES_FACTOR10
				  , CAST(SALES_FACTOR11 AS NUMBER(20,3))	AS SALES_FACTOR11
				  , CAST(SALES_FACTOR12 AS NUMBER(20,3))	AS SALES_FACTOR12
				  , CAST(SALES_FACTOR13 AS NUMBER(20,3))	AS SALES_FACTOR13
				  , CAST(SALES_FACTOR14 AS NUMBER(20,3))	AS SALES_FACTOR14
				  , CAST(SALES_FACTOR15 AS NUMBER(20,3))	AS SALES_FACTOR15
				  , CAST(SALES_FACTOR16 AS NUMBER(20,3))	AS SALES_FACTOR16
				  , CAST(SALES_FACTOR17 AS NUMBER(20,3))	AS SALES_FACTOR17
				  , CAST(SALES_FACTOR18 AS NUMBER(20,3))	AS SALES_FACTOR18
				  , CAST(SALES_FACTOR19 AS NUMBER(20,3))	AS SALES_FACTOR19
				  , CAST(SALES_FACTOR20 AS NUMBER(20,3))	AS SALES_FACTOR20
                  , P_USER_ID      AS USER_ID
            FROM JSON_TABLE( P_JSON, '$[*]'
            			COLUMNS (
									ID 				PATH	'$.ID'
								  , ACCOUNT_CD		PATH	'$.ACCOUNT_CD'
								  , ITEM_CD			PATH	'$.ITEM_CD'
								  , BASE_DATE		PATH	'$.BASE_DATE'
								  , SALES_FACTOR1	PATH	'$.SALES_FACTOR1'
								  , SALES_FACTOR2	PATH	'$.SALES_FACTOR2'
								  , SALES_FACTOR3	PATH	'$.SALES_FACTOR3'
								  , SALES_FACTOR4	PATH	'$.SALES_FACTOR4'
								  , SALES_FACTOR5	PATH	'$.SALES_FACTOR5'
								  , SALES_FACTOR6	PATH	'$.SALES_FACTOR6'
								  , SALES_FACTOR7	PATH	'$.SALES_FACTOR7'
								  , SALES_FACTOR8	PATH	'$.SALES_FACTOR8'
								  , SALES_FACTOR9	PATH	'$.SALES_FACTOR9'
								  , SALES_FACTOR10	PATH	'$.SALES_FACTOR10'
								  , SALES_FACTOR11	PATH	'$.SALES_FACTOR11'
								  , SALES_FACTOR12	PATH	'$.SALES_FACTOR12'
								  , SALES_FACTOR13	PATH	'$.SALES_FACTOR13'
								  , SALES_FACTOR14	PATH	'$.SALES_FACTOR14'
								  , SALES_FACTOR15	PATH	'$.SALES_FACTOR15'
								  , SALES_FACTOR16	PATH	'$.SALES_FACTOR16'
								  , SALES_FACTOR17	PATH	'$.SALES_FACTOR17'
								  , SALES_FACTOR18	PATH	'$.SALES_FACTOR18'
								  , SALES_FACTOR19	PATH	'$.SALES_FACTOR19'
								  , SALES_FACTOR20	PATH	'$.SALES_FACTOR20'
            					)
            			)
          ) SRC
    ON    (TAR.ID            = SRC.ID)
    WHEN MATCHED THEN
         UPDATE 
           SET   TAR.BASE_DATE          = SRC.BASE_DATE
                ,TAR.ACCOUNT_CD         = SRC.ACCOUNT_CD
                ,TAR.ITEM_CD            = SRC.ITEM_CD
                ,TAR.SALES_FACTOR1      = SRC.SALES_FACTOR1 
                ,TAR.SALES_FACTOR2      = SRC.SALES_FACTOR2 
                ,TAR.SALES_FACTOR3      = SRC.SALES_FACTOR3 
                ,TAR.SALES_FACTOR4      = SRC.SALES_FACTOR4 
                ,TAR.SALES_FACTOR5      = SRC.SALES_FACTOR5 
                ,TAR.SALES_FACTOR6      = SRC.SALES_FACTOR6 
                ,TAR.SALES_FACTOR7      = SRC.SALES_FACTOR7 
                ,TAR.SALES_FACTOR8      = SRC.SALES_FACTOR8 
                ,TAR.SALES_FACTOR9      = SRC.SALES_FACTOR9 
                ,TAR.SALES_FACTOR10     = SRC.SALES_FACTOR10    
                ,TAR.SALES_FACTOR11     = SRC.SALES_FACTOR11    
                ,TAR.SALES_FACTOR12     = SRC.SALES_FACTOR12    
                ,TAR.SALES_FACTOR13     = SRC.SALES_FACTOR13    
                ,TAR.SALES_FACTOR14     = SRC.SALES_FACTOR14    
                ,TAR.SALES_FACTOR15     = SRC.SALES_FACTOR15    
                ,TAR.SALES_FACTOR16     = SRC.SALES_FACTOR16    
                ,TAR.SALES_FACTOR17     = SRC.SALES_FACTOR17    
                ,TAR.SALES_FACTOR18     = SRC.SALES_FACTOR18    
                ,TAR.SALES_FACTOR19     = SRC.SALES_FACTOR19    
                ,TAR.SALES_FACTOR20     = SRC.SALES_FACTOR20    
                ,TAR.MODIFY_BY      = SRC.USER_ID
                ,TAR.MODIFY_DTTM    = (SELECT SYSDATE FROM DUAL)
    WHEN NOT MATCHED THEN 
         INSERT (
                  ID            
                , BASE_DATE 
                , ACCOUNT_CD
                , ITEM_CD
                , SALES_FACTOR1 
                , SALES_FACTOR2 
                , SALES_FACTOR3 
                , SALES_FACTOR4 
                , SALES_FACTOR5 
                , SALES_FACTOR6 
                , SALES_FACTOR7 
                , SALES_FACTOR8 
                , SALES_FACTOR9 
                , SALES_FACTOR10    
                , SALES_FACTOR11    
                , SALES_FACTOR12    
                , SALES_FACTOR13    
                , SALES_FACTOR14    
                , SALES_FACTOR15    
                , SALES_FACTOR16    
                , SALES_FACTOR17    
                , SALES_FACTOR18    
                , SALES_FACTOR19    
                , SALES_FACTOR20    
                , CREATE_BY 
                , CREATE_DTTM
                ) 
         VALUES (
                 RAWTOHEX(SYS_GUID())
                ,SRC.BASE_DATE
                ,SRC.ACCOUNT_CD
                ,SRC.ITEM_CD
                ,SRC.SALES_FACTOR1
                ,SRC.SALES_FACTOR2
                ,SRC.SALES_FACTOR3
                ,SRC.SALES_FACTOR4
                ,SRC.SALES_FACTOR5
                ,SRC.SALES_FACTOR6
                ,SRC.SALES_FACTOR7
                ,SRC.SALES_FACTOR8
                ,SRC.SALES_FACTOR9
                ,SRC.SALES_FACTOR10
                ,SRC.SALES_FACTOR11
                ,SRC.SALES_FACTOR12
                ,SRC.SALES_FACTOR13
                ,SRC.SALES_FACTOR14
                ,SRC.SALES_FACTOR15
                ,SRC.SALES_FACTOR16
                ,SRC.SALES_FACTOR17
                ,SRC.SALES_FACTOR18
                ,SRC.SALES_FACTOR19
                ,SRC.SALES_FACTOR20
                ,SRC.USER_ID
                ,(SELECT SYSDATE FROM DUAL)
                ) 
    ;

    P_RT_ROLLBACK_FLAG  := 'true';
    P_RT_MSG            := 'MSG_0001';  --저장 되었습니다.

EXCEPTION WHEN OTHERS THEN
    IF (SQLERRM = P_ERR_MSG) THEN
        P_ERR_MSG := SQLERRM;
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
    ELSE 
        RAISE_APPLICATION_ERROR (SQLCODE, SQLERRM);
--              EXEC SP_COMM_RAISE_ERR
   END IF;
END;
/

