create PROCEDURE  "SP_UI_DP_33_Q2" (
                                     P_VER_ID			VARCHAR2 		
                                    ,P_SALES_LV_ID		VARCHAR2 	
                                    ,P_ITEM_LV_ID		VARCHAR2 		
                                    ,P_RT_MSG       OUT VARCHAR2   
                                    ,pRESULT        OUT SYS_REFCURSOR 
 ) 
IS
  P_START_DATE      DATE ;
  P_END_DATE		DATE ;
  P_CL_AUTH_TP_ID   CHAR(32);
BEGIN
/*************************************************************************************************
    -- History ( Date / writer / Comment )
	- 2023.02.15 / kim sohee / 누락된 AUTH_TP_ID 조건 걸기      
*************************************************************************************************/
	SELECT FROM_DATE
		 , "TO_DATE"
        INTO P_START_DATE, P_END_DATE
	  FROM TB_DP_CONTROL_BOARD_VER_MST 
	  WHERE ID = p_VER_ID
	;
	SELECT CL_LV_MGMT_ID INTO P_CL_AUTH_TP_ID
	  FROM TB_DP_CONTROL_BOARD_VER_DTL 
	 WHERE CONBD_VER_MST_ID = P_VER_ID 
	   AND WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
	   ;        
    OPEN pRESULT
    FOR     
     WITH  ACCT 
    AS ( 
    /*
        SELECT DISTINCT DESCENDANT_ID  
          FROM TB_DPD_SALES_HIER_CLOSURE  
         WHERE LEAF_YN = 'Y' and ANCESTER_ID like (case when P_SALES_LV_ID = 'ALL' then '%' else  P_SALES_LV_ID end)
         */
         SELECT A.ID as ACCOUNT_ID, ACCOUNT_CD, ACCOUNT_NM, A.PARENT_SALES_LV_ID as SALES_LV_ID, s.SALES_LV_CD, s.SALES_LV_NM 
         from TB_DP_ACCOUNT_MST A
         inner join TB_DP_SALES_LEVEL_MGMT s on s.id = a.PARENT_SALES_LV_ID
         where A.PARENT_SALES_LV_ID =  P_SALES_LV_ID
    ), ITEM 
    AS ( 
    /*
        SELECT DISTINCT DESCENDANT_ID 
          FROM TB_DPD_ITEM_HIER_CLOSURE  
         WHERE LEAF_YN = 'Y'  
        AND ANCESTER_ID like (case when P_ITEM_LV_ID = 'ALL' then '%' else  P_ITEM_LV_ID end)
        */
        SELECT m.ID as ITEM_ID, ITEM_CD, ITEM_NM, m.PARENT_ITEM_LV_ID  as ITEM_LV_ID , L.ITEM_LV_CD, L.ITEM_LV_NM
        FROM TB_CM_ITEM_MST m
        inner join TB_CM_ITEM_LEVEL_MGMT L on L.id = m.PARENT_ITEM_LV_ID
        where m.PARENT_ITEM_LV_ID = P_ITEM_LV_ID
    ), CAL  
    AS (SELECT MIN(DAT) AS STRT_DATE 
             , MAX(DAT) AS END_DATE 
             , MIN(DAT) AS BASE_DATE 
         FROM TB_CM_CALENDAR 
        WHERE DAT BETWEEN P_START_DATE AND P_END_DATE 
     GROUP BY YYYYMM
    ), FINAL_DP AS (	-- 판매 계획? 
         SELECT  CA.BASE_DATE 
                , AM.SALES_LV_ID
                , AM.SALES_LV_CD
                , AM.SALES_LV_NM
                , IM.ITEM_LV_ID
                , IM.ITEM_LV_CD
                , Im.ITEM_LV_NM
                , A.ITEM_MST_ID  
                , IM.ITEM_CD
                , IM.ITEM_NM
                , A.ACCOUNT_ID 
                , AM.ACCOUNT_CD
                , AM.ACCOUNT_NM
                , SUM(QTY) AS VAL
                , MAX(US.USERNAME) AS USERNAME
                , MAX(US.DISPLAY_NAME) AS DISPLAY_NAME
          FROM TB_DP_ENTRY A
               INNER JOIN 	   
               ACCT AM 
            ON AM.ACCOUNT_ID = A.ACCOUNT_ID   
            INNER JOIN 	   
               ITEM IM 
            ON IM.ITEM_ID = A.ITEM_MST_ID 
               INNER JOIN 
               CAL CA 
            ON A.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE 
               INNER JOIN 
               TB_AD_USER US
            ON A.EMP_ID = US.ID 
         WHERE 1=1
           AND VER_ID = P_VER_ID
           AND AUTH_TP_ID = P_CL_AUTH_TP_ID
     GROUP BY CA.BASE_DATE ,AM.SALES_LV_ID
                , AM.SALES_LV_CD
                , AM.SALES_LV_NM
                , IM.ITEM_LV_ID
                , IM.ITEM_LV_CD
                , Im.ITEM_LV_NM
                , A.ITEM_MST_ID  
                , IM.ITEM_CD
                , IM.ITEM_NM
                , A.ACCOUNT_ID 
                , AM.ACCOUNT_CD
                , AM.ACCOUNT_NM

    ) , DP_VER 
    AS (SELECT DISTINCT DO.ITEM_MST_ID ,DO.ACCOUNT_ID  
          FROM FINAL_DP DO    
    ) 
    , ACT_SALES AS ( 
         SELECT   A.ITEM_MST_ID  
                , A.ACCOUNT_ID 
                , A.SALES_6M
                , A.SALES_3M
                , A.SALES_1M
          FROM TB_DP_DIMENSION_DATA A  
               INNER JOIN 
               DP_VER  V
            ON A.ITEM_MST_ID = V.ITEM_MST_ID 
           AND A.ACCOUNT_ID = V.ACCOUNT_ID 	
    ) 
    , ANNUAL AS (	-- 사업 계획 ?
         SELECT  CA.BASE_DATE 
                , A.ITEM_MST_ID  
                , A.ACCOUNT_ID 
                , SUM(ANNUAL_QTY) AS VAL
          FROM TB_DP_MEASURE_DATA A  
               INNER JOIN 
               CAL CA 
            ON A.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE 
               INNER JOIN 
               DP_VER  V
            ON A.ITEM_MST_ID = V.ITEM_MST_ID 
           AND A.ACCOUNT_ID = V.ACCOUNT_ID 
         WHERE 1=1
     GROUP BY CA.BASE_DATE 
            , A.ITEM_MST_ID, A.ACCOUNT_ID 
    ) 
     SELECT   VER.BASE_DATE												AS "DATE"  
            , VER.SALES_LV_ID												AS SALES_ID 
            , VER.SALES_LV_CD												AS SALES_CD
            , VER.SALES_LV_NM												AS SALES_NM
            , VER.ITEM_LV_ID												AS ITEM_LV_ID
            , VER.ITEM_LV_CD												AS ITEM_LV_CD
            , VER.ITEM_LV_NM												AS ITEM_LV_NM 
            , VER.ITEM_CD
            , VER.ITEM_NM
            , SUM(COALESCE(SA.SALES_6M, 0))									AS SALES_6M
            , SUM(COALESCE(SA.SALES_3M, 0))									AS SALES_3M
            , SUM(COALESCE(SA.SALES_1M, 0))									AS SALES_1M
            , SUM(COALESCE(VER.VAL, 0))									AS DP
            , SUM(COALESCE(ANNUAL.VAL, 0))								AS ANNUAL
            --, SUM(COALESCE(VER.VAL, 0)) - SUM(COALESCE(ANNUAL.VAL, 0))	AS INDE 
            --, (SUM(COALESCE(VER.VAL, 0)) - SUM(COALESCE(ANNUAL.VAL, 0))) / SUM(COALESCE(ANNUAL.VAL, 0)) * 100 AS INDE_RATE 
        FROM FINAL_DP VER 		 
             LEFT OUTER JOIN
             ACT_SALES SA
          ON VER.ITEM_MST_ID = SA.ITEM_MST_ID
         AND VER.ACCOUNT_ID = SA.ACCOUNT_ID
             LEFT OUTER JOIN
             ANNUAL
          ON VER.BASE_DATE = ANNUAL.BASE_DATE
         AND VER.ITEM_MST_ID = ANNUAL.ITEM_MST_ID
         AND VER.ACCOUNT_ID = ANNUAL.ACCOUNT_ID
    GROUP BY VER.BASE_DATE  , VER.SALES_LV_ID, VER.SALES_LV_CD, VER.SALES_LV_NM	, VER.ITEM_LV_ID, VER.ITEM_LV_CD, VER.ITEM_LV_NM, VER.ITEM_CD, VER.ITEM_NM
    ORDER BY  VER.SALES_LV_CD, VER.SALES_LV_NM , VER.ITEM_LV_CD, VER.ITEM_LV_NM, VER.BASE_DATE
    ;
END
;
/

