create PROCEDURE                  "SP_UI_BF_05_D1" (
    P_ID                 CHAR       := ''     
  , P_USER_ID            VARCHAR2   := ''
  , P_RT_ROLLBACK_FLAG   OUT VARCHAR2
  , P_RT_MSG             OUT VARCHAR2        
) 
IS
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
    P_ERR_STATUS    NUMBER          := 0;
    P_ERR_MSG       VARCHAR2(4000)  :='';

BEGIN
--    DELETE FROM TB_CM_ACTUAL_SALES
--     WHERE ID = P_ID
    UPDATE TB_CM_ACTUAL_SALES 
       SET QTY_CORRECTION          = NULL
         , CORRECTION_COMMENT_ID   = NULL
         , CORRECTION_YN           = 'N'
         , MODIFY_BY               = P_USER_ID
         , MODIFY_DTTM             = (SELECT SYSDATE FROM DUAL)
     WHERE ID = P_ID;

     P_RT_ROLLBACK_FLAG := 'true';
     P_RT_MSG := 'MSG_0002';  --삭제 되었습니다.

EXCEPTION WHEN OTHERS THEN
    P_ERR_MSG := SQLERRM;
    P_RT_ROLLBACK_FLAG := 'false';
    P_RT_MSG := P_ERR_MSG;
END;

/

