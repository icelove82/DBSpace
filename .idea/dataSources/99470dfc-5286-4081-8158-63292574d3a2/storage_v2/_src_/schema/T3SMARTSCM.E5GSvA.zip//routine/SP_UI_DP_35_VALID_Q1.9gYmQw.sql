create PROCEDURE "SP_UI_DP_35_VALID_Q1"
(	
	 p_OPERATOR_ID		IN VARCHAR2     :=''
	,p_AUTH_TP_ID		IN VARCHAR2     :=''
    ,pRESULT       OUT SYS_REFCURSOR 
) 
IS 

/*****************************************************************************
Title : [SP_UI_DP_35_VALIDATION_Q1] 
*****************************************************************************/
v_VALID_FLAG	VARCHAR2(10); 
BEGIN

IF	(p_OPERATOR_ID IS NULL OR RTRIM(p_OPERATOR_ID) ='')
	THEN
	v_VALID_FLAG := 'ALL'; 
ELSE 
	v_VALID_FLAG := 'PSNZ'; 
END	IF;



--IF(v_VALID_FLAG = 'ALL')
--    THEN
		-- ？？u #################################################################################
    OPEN pRESULT
    FOR
SELECT A.CHECK_CD, A.CHECK_DESC, A.CNT
FROM (
		SELECT	  A.CHECK_CD                                AS CHECK_CD
                , A.CHECK_DESC                              AS CHECK_DESC
                , A.CNT                                     AS CNT
		FROM	(
				SELECT   'ITEM_CD_P_LEVEL'					AS CHECK_CD	
                        ,'Item Master의 상위 Level 미지정'	AS CHECK_DESC
						--,'parent item level is none'	    AS CHECK_DESC
						,TO_CHAR(COUNT(ID))		            AS CNT
				FROM	TB_CM_ITEM_MST 
				WHERE	1=1
                  AND NVL(DEL_YN,'N')     = 'N' 
                  AND DP_PLAN_YN = 'Y'
				  AND NVL(PARENT_ITEM_LV_ID, 'none') NOT IN (SELECT ID FROM TB_CM_ITEM_LEVEL_MGMT )
				UNION ALL
				SELECT	'ITEM_LV_CD_P_LEVEL'										AS CHECK_CD
						--,'parent level of Item Master is none (except seq=1)'	    AS CHECK_DESC
                        ,'Item Level Management의 상위 Lecel 미지정(seq = 1제외)'	AS CHECK_DESC
						,TO_CHAR(COUNT(A.ID))								        AS CNT
				FROM	TB_CM_ITEM_LEVEL_MGMT A 
						INNER JOIN TB_CM_LEVEL_MGMT B  
                  ON  ( A.LV_MGMT_ID = B.ID AND B.ACTV_YN = 'Y')
				WHERE	A.ACTV_YN = 'Y'
				  AND	A.SEQ NOT IN (
									SELECT MIN(X.SEQ) FROM  TB_CM_ITEM_LEVEL_MGMT X 
															INNER JOIN TB_CM_LEVEL_MGMT Y   
                                                        ON (X.LV_MGMT_ID = Y.ID AND Y.ACTV_YN = 'Y')
									)
				  AND   A.LV_MGMT_ID IN ( SELECT ID FROM TB_CM_LEVEL_MGMT  WHERE ACTV_YN = 'Y')
				  AND	NVL(A.PARENT_ITEM_LV_ID, 'none') NOT IN	(
																SELECT ID FROM TB_CM_ITEM_LEVEL_MGMT 
															)
				UNION ALL
				SELECT	'ACCOUNT_CD_P_LEVEL'					AS CHECK_CD
						--,'parent level of Account Master is none'	    AS CHECK_DESC
                        ,'Account Master의 상위 Level 미지정'	AS CHECK_DESC
						,TO_CHAR(COUNT(ID))			            AS CNT
				  FROM	TB_DP_ACCOUNT_MST 
				 WHERE	1=1
                   AND  NVL(DEL_YN,'N') = 'N' AND ACTV_YN = 'Y'
				   AND	NVL(PARENT_SALES_LV_ID, 'none') NOT IN	(
																SELECT ID FROM TB_DP_SALES_LEVEL_MGMT 
															)
				UNION ALL 
				SELECT	'SALES_LV_CD_P_LEVEL'									    AS CHECK_CD
						--,'parent level of Sales level is none (except seq=1)'     AS CHECK_DESC
                        ,'Sales Level Management의 상위 Level 미지정 (seq = 1제외)' AS CHECK_DESC
						,TO_CHAR(COUNT(A.ID))								        AS CNT
				  FROM	TB_DP_SALES_LEVEL_MGMT A 
						INNER JOIN TB_CM_LEVEL_MGMT B  
                    ON (A.LV_MGMT_ID = B.ID AND B.ACTV_YN = 'Y')
                 WHERE	1=1
                   AND  A.ACTV_YN = 'Y'
				   AND	A.SEQ NOT IN (
                                        SELECT	MIN(X.SEQ) 
                                          FROM	TB_DP_SALES_LEVEL_MGMT X 
											    INNER JOIN 
                                                TB_CM_LEVEL_MGMT Y  
                                            ON (X.LV_MGMT_ID = Y.ID AND Y.ACTV_YN = 'Y')
									)
				  AND	A.LV_MGMT_ID IN ( SELECT ID FROM TB_CM_LEVEL_MGMT  WHERE ACTV_YN = 'Y') 
				  AND	NVL(A.PARENT_SALES_LV_ID, 'none') NOT IN	(
																SELECT ID FROM TB_DP_SALES_LEVEL_MGMT 
																)
				UNION ALL 
				SELECT	 'U_AUTHORITY'											AS CHECK_CD
						--,'approval authority manager of parent sales level is none (except Virtual)'       AS CHECK_DESC
                        ,'상위 Sales Level 의 승인 권한자 미지정(Virtual 제외)' AS CHECK_DESC
						,TO_CHAR(COUNT(A.ID))							        AS CNT
				FROM	TB_DP_SALES_LEVEL_MGMT A 
						INNER JOIN TB_CM_LEVEL_MGMT B  
                  ON  ( A.LV_MGMT_ID = B.ID AND B.ACTV_YN = 'Y')
				WHERE	1=1
                  AND   A.ACTV_YN = 'Y' 
                  AND   A.VIRTUAL_YN = 'N'
				  AND	A.LV_MGMT_ID IN ( SELECT ID FROM TB_CM_LEVEL_MGMT  WHERE ACTV_YN = 'Y') 
				  AND	NVL(A.PARENT_SALES_LV_ID, 'none') IN	(
                                                                SELECT ID 
                                                                  FROM TB_DP_SALES_LEVEL_MGMT 
                                                                 WHERE ACTV_YN = 'Y'
															)
				  AND		NOT EXISTS	(
                                        SELECT 'X'
                                          FROM TB_DP_SALES_AUTH_MAP X 
                                         WHERE A.ID = X.SALES_LV_ID
									)
				) A
                WHERE 1=1 AND 'ALL' = v_VALID_FLAG                             
    UNION ALL
-- ELSE --IF(v_VALID_FLAG = 'PSNZ')
		-- #################################################################################
--    OPEN pRESULT
--    FOR
		SELECT	 'U_I_A_ITEM_CD'												   AS CHECK_CD
                ,'User별 Item & Account 맵핑에서 Item Code가 Master에 없는 경우'       AS CHECK_DESC
				--,'Some item is a unknown value in Item&Account mapping by User'        AS CHECK_DESC
				,TO_CHAR(COUNT(A.ITEM_MST_ID))					        		   AS CNT
         FROM	TB_DP_USER_ITEM_ACCOUNT_MAP A 
				INNER JOIN 
                TB_AD_USER B  
           ON  ( A.EMP_ID = B.ID)
		 WHERE	NOT EXISTS	(
                                SELECT 'X'
                                  FROM TB_CM_ITEM_MST X 
                                 WHERE 1=1
                                   AND A.ITEM_MST_ID = X.ID
                                   AND NVL(X.DEL_YN,'N') = 'N' AND X.DP_PLAN_YN = 'Y'
							)
		AND		A.AUTH_TP_ID LIKE '%' || p_AUTH_TP_ID ||'%'
		AND		B.USERNAME    LIKE '%' || p_OPERATOR_ID || '%'
		UNION ALL
		SELECT	'U_I_A_ACCOUNT_CD'													AS CHECK_CD
				--,'Some account is a unknown value in Item&Account mapping by User'      AS CHECK_DESC
                ,'User별 Item & Account 맵핑에서 Account Code가 Master에 없는 경우' AS CHECK_DESC
				,TO_CHAR(COUNT(A.ACCOUNT_ID))								        AS CNT
		FROM TB_DP_USER_ITEM_ACCOUNT_MAP A 
             INNER JOIN 
             TB_AD_USER B  
        ON ( A.EMP_ID = B.ID)
		WHERE NOT EXISTS	(
								SELECT 'X'
								  FROM TB_DP_ACCOUNT_MST X 
								 WHERE 1=1
                                   AND A.ACCOUNT_ID= X.ID
								   AND X.ACTV_YN = 'Y'
							)
		AND		A.AUTH_TP_ID LIKE '%' || p_AUTH_TP_ID ||'%'
		AND		B.USERNAME    LIKE '%' || p_OPERATOR_ID || '%'
		UNION ALL
		SELECT	'U_I_ITEM_CD'																AS CHECK_CD
				--,'Some item is a unknown value in Item mapping by User'          AS CHECK_DESC
                ,'User별 Item 매핑에서 등록된 값이 Item Code일때 그값이 Master에 없는 경우' AS CHECK_DESC
				,TO_CHAR(COUNT(A.ITEM_MST_ID))										        AS CNT
		FROM	TB_DP_USER_ITEM_MAP A 
				INNER JOIN TB_AD_USER B  
          ON  ( A.EMP_ID = B.ID)
		WHERE	1=1
          AND A.LV_MGMT_ID IN	(
                                    SELECT A.ID 
                                      FROM TB_CM_LEVEL_MGMT A 
                                           INNER JOIN  
                                           TB_CM_COMM_CONFIG B  
                                        ON(A.LV_TP_ID = B.ID AND B.CONF_GRP_CD = 'DP_LV_TP' AND B.CONF_CD = 'I')
                                     WHERE 1=1
                                       AND A.ACTV_YN = 'Y' 
                                       AND A.LEAF_YN = 'Y'
								)
		  AND	NOT EXISTS		(
								SELECT 'X'
								  FROM TB_CM_ITEM_MST X 
								 WHERE 1=1
                                   AND A.ITEM_MST_ID = X.ID
								   AND NVL(X.DEL_YN,'N') = 'N' 
                                   AND X.DP_PLAN_YN = 'Y'
								)
		AND		A.AUTH_TP_ID LIKE '%' || p_AUTH_TP_ID || '%'
		AND		B.USERNAME LIKE '%' || p_OPERATOR_ID || '%'
		UNION ALL 
		SELECT	'U_ITEM_LV_CD'																 AS CHECK_CD
				--,'Some item level is a unknown value in Item mapping by User'          AS CHECK_DESC
                ,'User별 Item 매핑에서 등록된 값이 Item Level일때 그값이 Master에 없는 경우' AS CHECK_DESC
				,TO_CHAR(COUNT(A.ITEM_LV_ID))										         AS CNT
		FROM	TB_DP_USER_ITEM_MAP A 
				INNER JOIN 
                TB_AD_USER B  
          ON  ( A.EMP_ID = B.ID)
		WHERE	A.LV_MGMT_ID IN	(
                                    SELECT A.ID 
                                      FROM TB_CM_LEVEL_MGMT A 
                                           INNER JOIN  
                                           TB_CM_COMM_CONFIG B  
                                        ON(A.LV_TP_ID = B.ID AND B.CONF_GRP_CD = 'DP_LV_TP' AND B.CONF_CD = 'I')
                                     WHERE 1=1
                                       AND A.ACTV_YN = 'Y' 
                                       AND A.LEAF_YN = 'N'
								)
		AND		NOT EXISTS		(
                                    SELECT 'X'
                                      FROM TB_CM_ITEM_LEVEL_MGMT X 
                                     WHERE 1=1
                                       AND A.ITEM_LV_ID = X.ID
                                       AND X.ACTV_YN = 'Y'
								)
		AND		A.AUTH_TP_ID LIKE '%' || p_AUTH_TP_ID || '%'
		AND		B.USERNAME LIKE '%' || p_OPERATOR_ID || '%'
		UNION ALL 
		SELECT	'U_A_ACCOUNT_CD'																	AS CHECK_CD
				--,'Some account is a unknown value in Account mapping by User'          AS CHECK_DESC
                ,'User별 Account 매핑에서 등록된 값이 Account Code 일때 그 값이 Master에 없는 경우' AS CHECK_DESC
				,TO_CHAR(COUNT(A.ACCOUNT_ID))												        AS CNT
		FROM	TB_DP_USER_ACCOUNT_MAP A 
				INNER JOIN 
                TB_AD_USER B  
          ON  ( A.EMP_ID = B.ID )
		WHERE	A.LV_MGMT_ID IN	(
                                    SELECT A.ID 
                                      FROM TB_CM_LEVEL_MGMT A 
                                           INNER JOIN  
                                           TB_CM_COMM_CONFIG B  
                                        ON(A.LV_TP_ID = B.ID AND B.CONF_GRP_CD = 'DP_LV_TP' AND B.CONF_CD = 'S')
                                     WHERE A.ACTV_YN = 'Y' AND A.LEAF_YN = 'Y' AND A.ACCOUNT_LV_YN = 'Y'
								)
		AND		NOT EXISTS		(	
                                    SELECT 'X'
                                      FROM TB_DP_ACCOUNT_MST X 
                                     WHERE 1=1
                                       AND A.ACCOUNT_ID = X.ID
                                       AND NVL(X.DEL_YN,'N') = 'N' 
								)
		AND		A.AUTH_TP_ID LIKE '%' || p_AUTH_TP_ID || '%'
		AND		B.USERNAME LIKE '%' || p_OPERATOR_ID || '%'
		UNION ALL 
		SELECT	'U_A_SALES_LV_CD'																   AS CHECK_CD
				--,'Some sales level is a unknown value in Account mapping by User'	       AS CHECK_DESC
                ,'User별 Account매핑에서 등록된 값이 Sales Levle 일때 그 값이 Master에 없는 경우'	AS CHECK_DESC
				,TO_CHAR(COUNT(A.SALES_LV_ID))												       AS CNT
		FROM	TB_DP_USER_ACCOUNT_MAP A 
				INNER JOIN TB_AD_USER B  
          ON  ( A.EMP_ID = B.ID )
		WHERE	A.LV_MGMT_ID IN		(
                                        SELECT A.ID 
                                          FROM TB_CM_LEVEL_MGMT A 
                                               INNER JOIN  TB_CM_COMM_CONFIG B  
                                            ON A.LV_TP_ID = B.ID AND B.CONF_GRP_CD = 'DP_LV_TP' AND B.CONF_CD = 'S'
									     WHERE 1=1
                                           AND A.ACTV_YN = 'Y' 
                                           AND A.LEAF_YN = 'N'  
									)
		AND		NOT EXISTS		(
                                    SELECT 'X'
                                      FROM TB_DP_SALES_LEVEL_MGMT X 
                                  	 WHERE 1=1
                                       AND A.SALES_LV_ID = X.ID
                                       AND NVL(X.DEL_YN,'N') = 'N' 
								)
		AND		A.AUTH_TP_ID LIKE '%' || p_AUTH_TP_ID || '%'
		AND		B.USERNAME LIKE '%' || p_OPERATOR_ID || '%'
		UNION ALL
		-- #################################################################################
		SELECT	A.CHECK_CD, A.CHECK_DESC, A.CNT
		FROM	(
				SELECT	'U_M_EXCEPTION'												AS CHECK_CD
						--,'User Mapping Exception. management target is none by mapping structure'	AS CHECK_DESC
                        ,'User Mapping Exception. 맵핑구조상 관리대상이 없는 경우'	AS CHECK_DESC
						,CASE WHEN COUNT(*) = 0 
                              THEN 'DP ？？？？ ？？？？' ELSE 'NONE'
                              END													AS CNT
				FROM	(
							SELECT	DISTINCT B.USERNAME AS EMP_NO, B.DISPLAY_NAME as EMP_NM, A.AUTH_TP_ID, B.USERNAME AS USER_ID
							  FROM	TB_DP_USER_ITEM_MAP		A 
									INNER JOIN TB_AD_USER	B  ON A.EMP_ID = B.ID

							UNION ALL
							SELECT	DISTINCT B.USERNAME AS EMP_NO, B.DISPLAY_NAME as EMP_NM, A.AUTH_TP_ID, B.USERNAME AS USER_ID
							FROM	TB_DP_USER_ACCOUNT_MAP		A 
									INNER JOIN TB_AD_USER	B  ON A.EMP_ID = B.ID

							UNION ALL
							SELECT	DISTINCT B.USERNAME AS EMP_NO, B.DISPLAY_NAME as EMP_NM, A.AUTH_TP_ID, B.USERNAME AS USER_ID
							FROM	TB_DP_USER_ITEM_ACCOUNT_MAP	A 
									INNER JOIN TB_AD_USER		B ON A.EMP_ID = B.ID
						) A
				WHERE	1=1
				  AND		A.AUTH_TP_ID = p_AUTH_TP_ID 
				  AND		A.USER_ID = p_OPERATOR_ID 
				) A
		WHERE	1=1 AND 'PSNZ' = v_VALID_FLAG
        ) A
        ;

END
;
/

