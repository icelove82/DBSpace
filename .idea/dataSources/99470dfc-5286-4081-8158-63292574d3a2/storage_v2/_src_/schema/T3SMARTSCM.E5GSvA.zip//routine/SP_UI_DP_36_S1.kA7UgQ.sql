create PROCEDURE SP_UI_DP_36_S1 (
					 P_ID				IN  CHAR		:= ''
					,P_MODULE_ID		IN  CHAR		:= ''
					,P_PLAN_TP_ID		IN  CHAR		:= ''
					,P_POLICY_ID		IN  CHAR		:= ''
					,P_POLICY_VAL		IN  VARCHAR2	:= ''
					,P_DESCRIP			IN  VARCHAR2	:= ''
					,P_USER_ID			IN  VARCHAR2	:= ''
                    ,P_RT_ROLLBACK_FLAG OUT VARCHAR2     
                    ,P_RT_MSG           OUT VARCHAR2    		
)
IS
        P_ERR_STATUS INT := 0;
        P_ERR_MSG VARCHAR2(4000):='';
        P_IF_STATUS INT := 0;



BEGIN 
/*
		PLAN POLICY 
*/
/* MESSAGE VALIDATION	*/
	SELECT COUNT(*) INTO P_ERR_STATUS
	  FROM TB_DP_PLAN_POLICY
	WHERE 1=1
	  AND MODULE_ID = P_MODULE_ID
	  AND PLAN_TP_ID = P_PLAN_TP_ID
	  AND POLICY_ID = P_POLICY_ID   
	  AND ID != P_ID;
	IF(P_ERR_STATUS > 0)
		THEN
            P_ERR_MSG := 'MSG_0013';
            RAISE_APPLICATION_ERROR(-20000, P_ERR_MSG);  
    END IF;

				MERGE INTO TB_DP_PLAN_POLICY TGT
				USING ( 
						SELECT
						 P_ID				AS ID			
						,P_MODULE_ID		AS MODULE_ID	
						,P_PLAN_TP_ID		AS PLAN_TP_ID	
						,P_POLICY_ID		AS POLICY_ID	
						,P_POLICY_VAL		AS POLICY_VAL	
						,P_DESCRIP			AS DESCRIP		
						,P_USER_ID			AS USER_ID	
                        FROM dual
					  ) SRC
				ON (TGT.ID = SRC.ID)
				WHEN MATCHED THEN
					 UPDATE 
					   SET   		
							 TGT.MODULE_ID	 = SRC.MODULE_ID	
							,TGT.PLAN_TP_ID	 = SRC.PLAN_TP_ID	
							,TGT.POLICY_ID	 = SRC.POLICY_ID	
							,TGT.POLICY_VAL	 = SRC.POLICY_VAL	
							,TGT.DESCRIP	 = SRC.DESCRIP			
							,TGT.MODIFY_BY	 = SRC.USER_ID	
							,TGT.MODIFY_DTTM = SYSDATE		
				WHEN NOT MATCHED THEN 
					 INSERT (
								 ID			
								,MODULE_ID	
								,PLAN_TP_ID	
								,POLICY_ID	
								,POLICY_VAL	
								,DESCRIP		
								,CREATE_BY	
								,CREATE_DTTM	
								,MODIFY_BY	
								,MODIFY_DTTM								 
							) 
					 VALUES (
							 TO_SINGLE_BYTE(SYS_GUID())			
							,SRC.MODULE_ID	
							,SRC.PLAN_TP_ID	
							,SRC.POLICY_ID	
							,SRC.POLICY_VAL	
							,SRC.DESCRIP		
							,SRC.USER_ID 
							,SYSDATE  
							,NULL
							,NULL          
 							) 
							;  
/*********************************************************************************************************
	Policy CD : PB
**********************************************************************************************************/
        SELECT COUNT(CONF_CD) INTO P_IF_STATUS
          FROM TB_CM_COMM_CONFIG
         WHERE CONF_CD = 'PB'
           AND CONF_GRP_CD = 'DP_POLICY'
           AND ID = P_POLICY_ID
           ;
	IF (P_IF_STATUS > 0)
        THEN
        	UPDATE TB_CM_COMM_CONFIG
        	  SET ATTR_01 = P_POLICY_VAL
                , PRIORT = (SELECT PRIORT FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_BUKT_TP' AND CONF_CD = P_POLICY_VAL)
            WHERE CONF_GRP_CD = 'DP_BUKT_TP'
        	  AND CONF_CD = 'PB'
        	;
        END IF
        ;                            
/**********************************************************************************************************
	Policy CD : B
		가변 아닐때			(		가변일때		)
		bucket	actv buc	( bucket	actv bucket	)
		D		D-PW-M		( D			D-PW-PB-M	)
		W		W-M			( W			W-PB-M		)
		PW		PW-M		( PW		PW-PB-M		)
		M		M-Q			( M			M-PB-Q		)
		Q		Q-Y			( Q			Q-PB-Y		)
**********************************************************************************************************/
			SELECT COUNT(*) INTO P_IF_STATUS
			  FROM TB_CM_COMM_CONFIG
			 WHERE CONF_CD = 'B'
			   AND CONF_GRP_CD = 'DP_POLICY'
			   AND ID = P_POLICY_ID;

	IF(P_IF_STATUS > 0)
		  THEN
				UPDATE TB_CM_COMM_CONFIG  
				  SET ACTV_YN = 'N'
				WHERE CONF_GRP_CD = 'DP_BUKT_TP'
				;
				MERGE INTO TB_CM_COMM_CONFIG TGT
				USING (
					SELECT 'D' AS "MAIN"
						 , 'D' AS SUB
					FROM DUAL UNION
					SELECT 'D', 'PW'
					FROM DUAL UNION
					SELECT 'D', 'M'		  
					FROM DUAL UNION
					SELECT 'W', 'W'
					FROM DUAL UNION
					SELECT 'W', 'M'
					FROM DUAL UNION
					SELECT 'PW', 'PW'
					FROM DUAL UNION
					SELECT 'PW', 'M'
					FROM DUAL UNION
					SELECT 'M', 'M'
					FROM DUAL UNION
					SELECT 'M', 'Q'
					FROM DUAL UNION
					SELECT 'Q', 'Q'
					FROM DUAL UNION
					SELECT 'Q', 'Y'
					FROM DUAL UNION
					SELECT 'Y', 'Y'
                    FROM DUAL                
				) SRC 
				ON ( TGT.CONF_GRP_CD = 'DP_BUKT_TP'
			   AND SRC."MAIN" = P_POLICY_VAL
			   AND TGT.CONF_CD = SRC.SUB 
				   )
				WHEN MATCHED THEN
				UPDATE SET ACTV_YN = 'Y'
				;
		  END IF
		  ;


	   P_RT_ROLLBACK_FLAG := 'true';
	   P_RT_MSG := 'MSG_0001'; 
       /* ============================================================================*/  
       EXCEPTION   
        WHEN OTHERS THEN  -- e_products_invalid       
              P_RT_ROLLBACK_FLAG := 'false';
              IF(SQLCODE = -20000)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF;

END;
/

