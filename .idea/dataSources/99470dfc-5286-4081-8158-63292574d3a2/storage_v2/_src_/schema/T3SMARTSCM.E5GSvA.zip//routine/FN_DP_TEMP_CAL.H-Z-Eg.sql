create FUNCTION  FN_DP_TEMP_CAL
(
   V_STRT_DATE IN DATE
  ,V_END_DATE  IN DATE
  ,P_BUCKET    IN VARCHAR2
)
RETURN DP_TEMP_CALENDAR IS
C_DP_TEMP_CALENDAR DP_TEMP_CALENDAR := DP_TEMP_CALENDAR();
-- YEAR
CURSOR C_DATA_IMPORT IS 
    SELECT TP_DP_TEMP_CALENDAR(    -- TB_SRP_CNTRL_BOARD_VER_MST ？？？？ ？？？？？？, ？？？？ ？？？？？？
						  BUCKET_START_DATE      =>  BUCKET_START_DATE  
                        , BUCKET_END_DATE        =>  BUCKET_END_DATE
                     )
    FROM (
            SELECT
                                  DAT                                                          AS BUCKET_START_DATE             
                                , NVL ((LEAD(DAT,1)  OVER ( ORDER BY YYYYMMDD)) -1,V_END_DATE) AS BUCKET_END_DATE
              FROM TB_CM_CALENDAR
             WHERE 1=1
               AND DAT BETWEEN V_STRT_DATE AND V_END_DATE 
               AND DD = 1
               AND MM = 1
               AND (P_BUCKET = 'YEAR' OR P_BUCKET = 'Y')
            UNION ALL
            SELECT
                                  DAT                                                          AS BUCKET_START_DATE             
                                , NVL ((LEAD(DAT,1)  OVER ( ORDER BY YYYYMMDD)) -1,V_END_DATE) AS BUCKET_END_DATE
              FROM TB_CM_CALENDAR
             WHERE 1=1
               AND DD = 1
               AND DAT BETWEEN TO_DATE(TO_CHAR(V_STRT_DATE, 'YYYYMM')||'01', 'YYYYMMDD') AND V_END_DATE
               -- MM BETWEEN TO_NUMBER(TO_CHAR(V_STRT_DATE, 'MM')) AND TO_NUMBER(TO_CHAR(V_END_DATE, 'MM')) --
               AND (P_BUCKET = 'MONTH' OR P_BUCKET = 'M')
            UNION ALL
            SELECT
                                  DAT                                                          AS BUCKET_START_DATE             
                                , NVL ((LEAD(DAT,1)  OVER ( ORDER BY YYYYMMDD)) -1,V_END_DATE) AS BUCKET_END_DATE
              FROM TB_CM_CALENDAR
             WHERE 1=1
               AND DAT BETWEEN V_STRT_DATE AND V_END_DATE
               AND DOW_NM = ( SELECT UPPER(CONF_CD) FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_STD_WEEK' AND ACTV_YN = 'Y' AND USE_YN = 'Y' )
               AND (P_BUCKET = 'WEEK' or P_BUCKET = 'W')
            UNION ALL
            SELECT
                                  DAT                                                          AS BUCKET_START_DATE             
                                , NVL ((LEAD(DAT,1)  OVER ( ORDER BY YYYYMMDD)) -1,V_END_DATE) AS BUCKET_END_DATE
              FROM TB_CM_CALENDAR
             WHERE 1=1
               AND DAT BETWEEN V_STRT_DATE AND V_END_DATE 
               AND (DOW_NM = ( SELECT UPPER(CONF_CD) FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_STD_WEEK' AND ACTV_YN = 'Y' AND USE_YN = 'Y' )
               OR  DD = 1 )
               AND (P_BUCKET = 'PAR_WEEK' OR P_BUCKET = 'PW')
            UNION ALL
            SELECT
                                  DAT                                                          AS BUCKET_START_DATE             
                                , NVL ((LEAD(DAT,1)  OVER ( ORDER BY YYYYMMDD)) -1,V_END_DATE) AS BUCKET_END_DATE
              FROM TB_CM_CALENDAR
             WHERE 1=1
               AND DAT BETWEEN V_STRT_DATE AND V_END_DATE
               AND (P_BUCKET = 'DAY' OR P_BUCKET ='D')
       ) A
       ;

BEGIN

        OPEN C_DATA_IMPORT;
        FETCH C_DATA_IMPORT BULK COLLECT INTO C_DP_TEMP_CALENDAR;
        CLOSE C_DATA_IMPORT;    
    RETURN C_DP_TEMP_CALENDAR;
END;

/

