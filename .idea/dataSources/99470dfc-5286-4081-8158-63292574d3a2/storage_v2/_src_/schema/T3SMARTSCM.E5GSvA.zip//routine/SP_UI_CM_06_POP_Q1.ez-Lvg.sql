create PROCEDURE SP_UI_CM_06_POP_Q1 (
    P_BOD_TP_ID             IN VARCHAR := '',
    P_CONSUME_LOCAT_ID      IN CHAR := '',
    pResult OUT SYS_REFCURSOR
)
IS

BEGIN
    OPEN pResult FOR
    SELECT  DISTINCT
            LMG.ID                AS LOC_MGMT_ID
          , ACM.COMN_CD_NM		  AS LOCAT_TP
          , MST.LOCAT_LV		  AS LOCAT_LV
          , DTL.LOCAT_CD		  AS LOCAT_CD
          , DTL.LOCAT_NM		  AS LOCAT_NM
     FROM TB_CM_LOC_DTL DTL,
          TB_CM_LOC_MST MST
          LEFT OUTER JOIN TB_AD_COMN_CODE ACM
          ON MST.LOCAT_TP_ID = ACM.ID,
          TB_CM_LOC_MGMT LMG,
          TB_CM_SITE_ITEM SIT,
          TB_AD_COMN_CODE ACC,
          (
          SELECT  DISTINCT FROM_LOCAT_MST_ID AS ID
            FROM  TB_CM_BOD_LT A,
                  TB_CM_LOC_DTL B,
                  TB_CM_lOC_MST C,
                  TB_CM_LOC_MGMT D
           WHERE  C.ID = B.LOCAT_MST_ID
             AND  C.ID = A.TO_LOCAT_MST_ID
             AND  B.ID = D.LOCAT_ID
             AND  D.ID = P_CONSUME_LOCAT_ID
          ) SUP
    WHERE MST.ID = DTL.LOCAT_MST_ID
      AND MST.ID = SUP.ID
      AND DTL.ID = LMG.LOCAT_ID
      AND LMG.ID = SIT.LOCAT_MGMT_ID
      AND ACC.ID = SIT.BOM_ITEM_TP_ID
      AND ACC.COMN_CD = 'FINAL_PRODUCT_GR_ITEM'
    ORDER BY LOCAT_TP, LOCAT_LV, LOCAT_CD, LOCAT_NM;

END;

/

