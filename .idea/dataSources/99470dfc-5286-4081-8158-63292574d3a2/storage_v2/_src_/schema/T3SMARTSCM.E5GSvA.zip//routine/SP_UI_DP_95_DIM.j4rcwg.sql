create PROCEDURE SP_UI_DP_95_DIM(
     p_USER_ID   VARCHAR2
    ,p_AUTH_TP   VARCHAR2
    ,p_UI_ID     VARCHAR2
    ,p_GRID_ID	 VARCHAR2
    ,pRESULT     OUT SYS_REFCURSOR
)IS
/*
    history (date / writer / comment)
    - 2021.01.04 / kim sohee / By Character 1 type, convert hard coding to level type of TB_CM_COMM_CONFIG
    - 2021.10.08 / hanguls / level type 
    - 2021.12.26 / kimsohee / custom dimension
    -- 2022.01.04 / Kim sohee / convert grid ID parameter (remain only grid ID, not Menu ID)
*/
    V_GRID_ID  VARCHAR2(100);
BEGIN    
	V_GRID_ID := REPLACE(P_GRID_ID, P_UI_ID||'-', '');
     OPEN pRESULT FOR
WITH DP_LEVEL
 AS (
           select L.ID, L.LV_CD, L.SALES_LV_YN, L.ACCOUNT_LV_YN, L.LEAF_YN, ROW_NUMBER() over (PARTITION BY CONF_CD ORDER BY CONF_CD, SEQ) as IDX 
                , C.CONF_CD AS LV_TP_CD
                , L.LV_TP_ID AS LV_TP_ID
            from TB_CM_LEVEL_MGMT L
                 INNER JOIN 
                 TB_CM_COMM_CONFIG C
              ON L.LV_TP_ID = C.ID 
           where ACCOUNT_LV_YN = 'Y'   and DEL_YN = 'N' and L.ACTV_YN = 'Y'						                
            union					
            select L.ID, LV_CD, SALES_LV_YN,ACCOUNT_LV_YN,LEAF_YN,  ROW_NUMBER() over (PARTITION BY CONF_CD ORDER BY CONF_CD, SEQ) as IDX 	
                 , C.CONF_CD AS LV_TP_CD
                 , L.LV_TP_ID
            from TB_CM_LEVEL_MGMT L
                 INNER JOIN TB_CM_COMM_CONFIG C 
              ON L.LV_TP_ID = C.Id 
            WHERE l.DEL_YN = 'N' AND L.ACTV_YN = 'Y'	AND ACCOUNT_LV_YN = 'N' AND SALES_LV_YN = 'N' 	AND L.ACTV_YN = 'Y'				
 ), MN
 AS (SELECT A.FLD_CD  				
         , LV_TP_CD 
		 , CAST(CASE WHEN (V.SALES_LV_YN = 'Y' OR V.ACCOUNT_LV_YN = 'Y')   THEN 'S' 					
		 		WHEN (V.SALES_LV_YN = 'N' OR V.ACCOUNT_LV_YN = 'N')   THEN 'I'   					
		 		ELSE 'C'	
		 	END AS VARCHAR2(1)) AS TYPE		
         , (case when (V.SALES_LV_YN = 'Y' and V.LEAF_YN = 'N') then 'SALES_LV' 					
                 when (V.ACCOUNT_LV_YN = 'Y' and V.LEAF_YN = 'Y') then 'ACCOUNT'  					
                 when (V.SALES_LV_YN = 'N' and V.LEAF_YN = 'N') then 'ITEM_LV'  					
                 when (V.SALES_LV_YN = 'N' and V.LEAF_YN = 'Y') then 'ITEM'					
                 else 'NONE' end ) AS "LEVEL"		
         , V.LV_CD as LEVEL_CD 
         , case when (SUBSTR(B.COL_NM, -2) = 'CD' or  SUBSTR(B.COL_NM, -2) = 'NM') then B.DISP_NM  else B.COL_NM end  as FIELD					
         , COALESCE(V.IDX,0) AS IDX 					
         , C.ATTR_01   AS CUSTOM_TYPE
         , V.LEAF_YN
         , COALESCE(up.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N')) AS FLD_ACTV_YN
         , A.FLD_SEQ
	  FROM TB_AD_USER_PREF_DTL A 
	 inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = p_UI_ID and m.GRID_CD = V_GRID_ID 
	 inner join TB_AD_GROUP g on g.ID = A.GRP_ID and GRP_CD = p_AUTH_TP
	 inner join TB_AD_USER u on u.USERNAME = p_USER_ID
	 inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
	 INNER JOIN TB_DP_DIM_SETTING B on  A.REFER_VALUE = B.ID	
	 LEFT OUTER JOIN DP_LEVEL V	 on 		V.ID = B.LV_MGMT_ID	
	LEFT OUTER JOIN TB_AD_USER_PREF up ON	m.id = up.USER_PREF_MST_ID AND A.GRP_ID = up.GRP_ID	AND	A.FLD_CD = up.FLD_CD	AND up.USER_ID = u.ID		
    LEFT OUTER JOIN
                TB_CM_COMM_CONFIG C
            ON  B.LV_MGMT_ID = C.CONF_ID 
           AND  B.COL_NM = C.CONF_CD    
	WHERE A.DIM_MEASURE_TP = 'DIMENSION'			
     )
    SELECT FLD_CD AS "DISPLAY"
         , "TYPE"
         , "LEVEL"
         , LEVEL_CD
         , IDX
         , LEAF_YN
         , "FIELD"
         , LV_TP_CD
         , CUSTOM_TYPE
      FROM MN 
     WHERE FLD_ACTV_YN = 'Y'	
        OR ((SELECT COUNT(1) FROM MN WHERE "TYPE" = 'C' AND FLD_ACTV_YN = 'Y') > 0 AND LEAF_YN = 'Y')      
         ORDER BY FLD_SEQ
	;
END;
/

