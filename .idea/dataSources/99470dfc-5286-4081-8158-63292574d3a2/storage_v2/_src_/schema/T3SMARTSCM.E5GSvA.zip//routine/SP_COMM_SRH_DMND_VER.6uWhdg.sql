create PROCEDURE SP_COMM_SRH_DMND_VER (
    P_SNRIO_MST_ID      IN CHAR := ''
   ,P_PLAN_TP_ID        IN CHAR := ''
   ,P_CL_YN             IN CHAR := ''
   ,P_DMND_MODULE_ID	IN CHAR := ''
   ,pResult             OUT SYS_REFCURSOR
)
IS
    V_DMND_MODULE_ID CHAR(32) := '';
    V_DF_PLAN_TP_ID CHAR(32);
	V_DISPLAY_BLANK_VER	INT := 1;

BEGIN
    IF NVL(P_SNRIO_MST_ID, ' ') = ' ' THEN
        SELECT COMN_CD INTO V_DMND_MODULE_ID FROM TB_AD_COMN_CODE WHERE ID = P_DMND_MODULE_ID;
        V_DISPLAY_BLANK_VER := 0;
    ELSE
        BEGIN
            SELECT B.COMN_CD INTO V_DMND_MODULE_ID
            FROM TB_CM_PLAN_SNRIO_MGMT_MST A
                ,TB_AD_COMN_CODE B  
            WHERE A.DMND_MODULE_ID = B.ID
            AND   A.ID = P_SNRIO_MST_ID;
            EXCEPTION WHEN NO_DATA_FOUND
            THEN NULL;
        END;
    END IF;

    SELECT ID INTO V_DF_PLAN_TP_ID
    FROM TB_CM_COMM_CONFIG
    WHERE CONF_GRP_CD = 'DP_PLAN_TYPE'
    AND DEFAT_VAL = 'Y';

    IF V_DMND_MODULE_ID = 'DP'
    THEN
        OPEN pResult FOR
		SELECT A.ID,
               A.VER_ID
          FROM (
                SELECT MS.ID,
                       MS.VER_ID,
                       ROW_NUMBER() OVER (ORDER BY MS.VER_ID DESC) AS ROWN
                  FROM TB_DP_CONTROL_BOARD_VER_MST MS
                       INNER JOIN
					   (
					   SELECT DISTINCT T3SERIES_VER_ID
					   FROM TB_CM_DEMAND_OVERVIEW
					   ) DO
					   ON MS.VER_ID = DO.T3SERIES_VER_ID
			   )  A
		WHERE A.ROWN <= 10
        UNION ALL
        SELECT NULL AS ID,
               ' '  AS VER_ID
          FROM DUAL
         WHERE 1 = V_DISPLAY_BLANK_VER;

    ELSIF V_DMND_MODULE_ID = 'RP'
    THEN
        OPEN pResult FOR
        SELECT A.ID,
               A.VER_ID
          FROM (
               SELECT C.ID				AS ID,
                      C.SIMUL_VER_ID	AS VER_ID,
                      ROW_NUMBER() OVER (ORDER BY C.CREATE_DTTM DESC, C.MODIFY_DTTM DESC) AS ROW_NUM
                 FROM TB_CM_CONBD_MAIN_VER_MST B
                      INNER JOIN TB_AD_COMN_CODE A
                      ON B.MODULE_ID = A.ID
                      AND A.COMN_CD = 'RP',
                      TB_CM_CONBD_MAIN_VER_DTL C
                WHERE 1=1
                  AND B.ID = C.CONBD_MAIN_VER_MST_ID
                  AND C.CONFRM_YN = 'Y'
              ) A
        WHERE ROW_NUM <= 10
        UNION ALL
        SELECT NULL AS ID,
               ' '  AS VER_ID
          FROM DUAL
         WHERE 1 = V_DISPLAY_BLANK_VER;
    END IF;

END;
/

