create PROCEDURE        "SP_UI_CM_01_POP_28_Q1" (
        P_LOCAT_MST_ID IN VARCHAR2 := '' ,
        pResult OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN pResult FOR 
      SELECT  C.ID
             ,D.COMN_CD         AS LOCAT_TP
             ,D.COMN_CD_NM      AS LOCAT_NM
			 ,B.LOCAT_LV
			 ,C.CATAGY_GRP
			 ,F.UOM_CD
			 ,F.UOM_NM
			 ,C.GRP_NO
			 ,C.LOTSIZE_CD
			 ,C.FROM_QTY
			 ,C.TO_QTY
			 ,C.EFFICY
			 ,C.ACTV_YN
      	     ,C.CREATE_BY		
      	     ,C.CREATE_DTTM	
      	     ,C.MODIFY_BY		
      	     ,C.MODIFY_DTTM	
	    FROM       TB_CM_CONFIGURATION A
        INNER JOIN TB_CM_LOC_MST B
          ON A.ID = B.CONF_ID
        INNER JOIN TB_CM_LOT_SIZE_GROUP C
          ON B.ID = C.LOCAT_MST_ID
        INNER JOIN TB_AD_COMN_CODE D
          ON B.LOCAT_TP_ID = D.ID
        INNER JOIN TB_CM_UOM F
          ON C.UOM_ID = F.ID     
	    WHERE 
	      C.LOCAT_MST_ID = P_LOCAT_MST_ID
	    ORDER BY C.CATAGY_GRP, C.GRP_NO, C.LOTSIZE_CD;
        
END;

/

