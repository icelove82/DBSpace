create PROCEDURE SP_UI_CM_08_POP_01_S (
     P_SHPP_LEADTIME_DTL_ID	IN VARCHAR2	:= ''
	,P_SHPP_SCHDL_TP_CD	    IN VARCHAR2 := ''
	,P_MON_YN				IN CHAR := 'N' 
	,P_TUE_YN				IN CHAR := 'N'
	,P_WED_YN				IN CHAR := 'N'
	,P_THU_YN				IN CHAR := 'N'
	,P_FRI_YN				IN CHAR := 'N'
	,P_SAT_YN				IN CHAR := 'N'
	,P_SUN_YN				IN CHAR := 'N'
	,P_DD					IN NUMBER := 0
	,P_ACTV_YN				IN CHAR := ''
	,P_USER_ID				IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG     OUT VARCHAR2
	,P_RT_MSG               OUT VARCHAR2
)
IS

    P_SHPP_SCHDL_TP_ID VARCHAR2(100) := '';
    P_ERR_STATUS NUMBER := 0;
    P_ERR_MSG VARCHAR2(4000) := '';

BEGIN

    BEGIN
        SELECT A.ID INTO P_SHPP_SCHDL_TP_ID
          FROM TB_AD_COMN_CODE A,
               TB_AD_COMN_GRP B
        WHERE B.ID = A.SRC_ID
          AND B.GRP_CD = 'SHIPPING_SCHEDULE_TYPE'
          AND A.COMN_CD = P_SHPP_SCHDL_TP_CD;
         EXCEPTION
            WHEN NO_DATA_FOUND THEN NULL;
    END;
    
    IF P_SHPP_SCHDL_TP_ID IS NULL THEN
        P_ERR_MSG := 'MSG_0020';
        RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
    END IF;
        
    UPDATE TB_CM_SHIP_LT_DTL
       SET SHPP_SCHDL_TP_ID = P_SHPP_SCHDL_TP_ID
         , MODIFY_BY		= P_USER_ID
         , MODIFY_DTTM	    = SYSDATE
     WHERE ID = P_SHPP_LEADTIME_DTL_ID;

    IF P_SHPP_SCHDL_TP_CD = 'DAILY'
    THEN 

        MERGE INTO TB_CM_SHIP_LT_DAILY_SCH B 
        USING (SELECT P_SHPP_LEADTIME_DTL_ID AS ID FROM DUAL) A
           ON (B.SHPP_LEADTIME_DTL_ID = A.ID)
        WHEN MATCHED THEN
            UPDATE 
               SET MON_YN		= P_MON_YN
                 , TUE_YN		= P_TUE_YN
                 , WED_YN		= P_WED_YN
                 , THU_YN		= P_THU_YN
                 , FRI_YN		= P_FRI_YN
                 , SAT_YN		= P_SAT_YN
                 , SUN_YN		= P_SUN_YN
                 , ACTV_YN      = P_ACTV_YN
                 , MODIFY_BY	= P_USER_ID
                 , MODIFY_DTTM	= SYSDATE
        WHEN NOT MATCHED THEN
            INSERT (
                    ID
                    ,SHPP_LEADTIME_DTL_ID
                    ,MON_YN
                    ,TUE_YN
                    ,WED_YN
                    ,THU_YN
                    ,FRI_YN
                    ,SAT_YN
                    ,SUN_YN
                    ,ACTV_YN
                    ,CREATE_BY
                    ,CREATE_DTTM
                    ,MODIFY_BY
                    ,MODIFY_DTTM
                    )
                VALUES 
                    (
                    TO_SINGLE_BYTE(SYS_GUID())
                    ,P_SHPP_LEADTIME_DTL_ID
                    ,P_MON_YN
                    ,P_TUE_YN
                    ,P_WED_YN
                    ,P_THU_YN
                    ,P_FRI_YN
                    ,P_SAT_YN
                    ,P_SUN_YN
                    ,P_ACTV_YN
                    ,P_USER_ID
                    ,SYSDATE
                    ,P_USER_ID
                    ,SYSDATE
                    );
    
    ELSE 
        
        IF P_ACTV_YN = 'Y'
        THEN 
            MERGE INTO TB_CM_SHIP_LT_MONTHLY_SCH B 
            USING (
                   SELECT P_SHPP_LEADTIME_DTL_ID AS ID,
                          P_DD AS DD
                     FROM DUAL
                  ) A
               ON (B.SHPP_LEADTIME_DTL_ID = A.ID
               AND B.DD = A.DD)
            WHEN MATCHED THEN
                UPDATE 
                   SET ACTV_YN	   = P_ACTV_YN
                     , MODIFY_BY   = P_USER_ID
                     , MODIFY_DTTM = SYSDATE
            WHEN NOT MATCHED THEN
                INSERT (
                        ID
                        ,SHPP_LEADTIME_DTL_ID
                        ,DD
                        ,ACTV_YN
                        ,CREATE_BY
                        ,CREATE_DTTM
                        ,MODIFY_BY
                        ,MODIFY_DTTM
                        )
                    VALUES 
                        (
                        TO_SINGLE_BYTE(SYS_GUID())
                        ,P_SHPP_LEADTIME_DTL_ID
                        ,P_DD
                        ,P_ACTV_YN
                        ,P_USER_ID
                        ,SYSDATE
                        ,P_USER_ID
                        ,SYSDATE
                        );
        ELSE
            DELETE TB_CM_SHIP_LT_MONTHLY_SCH
             WHERE SHPP_LEADTIME_DTL_ID = P_SHPP_LEADTIME_DTL_ID
               AND DD = P_DD;
               
        END IF;
        
    END IF;

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';  --???？？????？？

    EXCEPTION
    WHEN OTHERS THEN
        IF(SQLCODE = -20012)
        THEN
              P_RT_ROLLBACK_FLAG := 'false';
              P_RT_MSG := P_ERR_MSG;
          ELSE
              RAISE;
          END IF;
END;

/

