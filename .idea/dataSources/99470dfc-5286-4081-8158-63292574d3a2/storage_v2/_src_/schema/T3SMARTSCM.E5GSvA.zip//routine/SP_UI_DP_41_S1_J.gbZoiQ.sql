create PROCEDURE                SP_UI_DP_41_S1_J (
                                       P_JSON			    CLOB
                                     , P_MEASURE		    VARCHAR2
                                     , P_USER_ID            VARCHAR2
                                     , P_RT_ROLLBACK_FLAG   OUT VARCHAR2
                                     , P_RT_MSG             OUT VARCHAR2						        
)IS

    p_SQL		    VARCHAR2(4000);
    p_ERR_MSG       VARCHAR2(4000):='';
/************************************************************************************************V*********
Title : SP_UI_DP_41_S1_J
  - DP Measure Data Management

설명 
  - OPENJSON : https://docs.microsoft.com/ko-kr/sql/t-sql/functions/openjson-transact-sql?view=sql-server-ver15

 
History (수정일자 / 수정자 / 수정내용)
- 2022.01.13 / kim sohee / json bulk insert draft
******************************************************************************************************************/
BEGIN 
/*
	-- Find ID
	SELECT ID INTO p_ITEM_MST_ID FROM TB_CM_ITEM_MST WHERE ITEM_CD =p_ITEM_CD;
	SELECT ID INTO p_ACCOUNT_ID FROM TB_DP_ACCOUNT_MST WHERE ACCOUNT_CD = p_ACCT_CD;
	-- VALIDATION ABOUT ID 
	IF(p_ITEM_MST_ID IS NULL)
	THEN
		p_ERR_MSG := 'Item Code is not valid';
        RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG);
	END IF;
	IF(p_ACCOUNT_ID IS NULL)
	THEN
		p_ERR_MSG := 'Account Code is not valid';
        RAISE_APPLICATION_ERROR(-20001, p_ERR_MSG);
	END IF;
*/
    INSERT INTO TEMP_DP_MEASURE_DATA
    SELECT ITEM_CD
         , ACCOUNT_CD
         , BASE_DATE 
         , QTY 
         , AMT
      FROM JSON_TABLE ( P_JSON,  '$[*]'  
                COLUMNS (    ITEM_CD		PATH	'$.ITEM_CD'
                           , ACCOUNT_CD		PATH	'$.ACCOUNT_CD'
                           , BASE_DATE		DATE PATH	'$.BASE_DATE'
                           , QTY		    PATH	'$.QTY'
                           , AMT		    PATH	'$.AMT'
                        )                                      
            ) 
            ;


				P_SQL := 'MERGE INTO TB_DP_MEASURE_DATA TGT '
				||'USING ( SELECT   A.ID	AS  ACCOUNT_ID '    
								||',I.ID	AS  ITEM_MST_ID '     
								||',M.BASE_DATE '       
								||',M.QTY '					
								||',M.AMT '				
					   ||'FROM TEMP_DP_MEASURE_DATA M '
						     ||'INNER JOIN '
							 ||'TB_CM_ITEM_MST I '
						  ||'ON M.ITEM_CD = I.ITEM_CD '
						     ||'INNER JOIN '
							 ||'TB_DP_ACCOUNT_MST A '
						  ||'ON M.ACCOUNT_CD = A.ACCOUNT_CD '
					  ||') SRC '
					||'ON (TGT.ACCOUNT_ID = SRC.ACCOUNT_ID '
				   ||'AND TGT.ITEM_MST_ID = SRC.ITEM_MST_ID '
				   ||'AND TGT.BASE_DATE = SRC.BASE_DATE) '
				||'WHEN MATCHED THEN '
					 ||'UPDATE '
					   ||'SET   '||P_MEASURE||'_QTY = SRC.QTY '
                            ||','||P_MEASURE||'_AMT = SRC.AMT '
							||',MODIFY_BY = '''||P_USER_ID||''' '     
							||',MODIFY_DTTM = SYSDATE '      
				||'WHEN NOT MATCHED THEN '
					 ||'INSERT (ID '         
							||',ACCOUNT_ID '
							||',ITEM_MST_ID '
							||',BASE_DATE '
							||','||P_MEASURE||'_QTY '   
							||','||P_MEASURE||'_AMT '   
							||',CREATE_BY '
							||',CREATE_DTTM '
							||') '
					 ||'VALUES ( '
							 ||'TO_SINGLE_BYTE(SYS_GUID()) '
							||',SRC.ACCOUNT_ID '   
							||',SRC.ITEM_MST_ID '  
							||',SRC.BASE_DATE '  
							||',SRC.QTY '   
							||',SRC.AMT '   
							||','''||P_USER_ID||''' '
							||',SYSDATE '           
 							||')' 
							;  

    EXECUTE IMMEDIATE P_SQL;
    DELETE FROM TEMP_DP_MEASURE_DATA;

    p_RT_MSG := 'MSG_0001';
    p_RT_ROLLBACK_FLAG := 'true';

     EXCEPTION WHEN OTHERS THEN
              IF(SQLCODE = -20001)
              THEN
                  P_RT_MSG := SQLERRM; 
                  p_RT_ROLLBACK_FLAG := 'false';
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;   	

END;
/

