create PROCEDURE                SP_UI_CM_06_Q1 (
	 P_BOD_TYPE					    IN VARCHAR2 := ''
	,P_CONSUME_LOCAT_TP_NM			IN VARCHAR2 := ''
	,P_CONSUME_LOCAT_LV			    IN VARCHAR2 := ''
	,P_CONSUME_LOCAT_CD			    IN VARCHAR2 := ''
	,P_CONSUME_LOCAT_NM			    IN VARCHAR2 := ''
	,P_SUPPLY_LOCAT_TP_NM			IN VARCHAR2 := ''
	,P_SUPPLY_LOCAT_LV				IN VARCHAR2 := ''
	,P_SUPPLY_LOCAT_CD				IN VARCHAR2 := ''
	,P_SUPPLY_LOCAT_NM				IN VARCHAR2 := ''
    ,pResult OUT SYS_REFCURSOR
)
IS
BEGIN

    OPEN pResult FOR
	SELECT AA.ID					AS BOD_MAP_ID
		 , AA.C_LOC_MGMT_ID			AS CONSUME_LOCAT_ID
		 , AA.S_LOC_MGMT_ID			AS SUPPLY_LOCAT_ID
		 , D.COMN_CD_NM             AS BOD_TYPE
		 , AA.BOD_TP_ID
		 , AA.LOCAT_TP_ID
		 , B.COMN_CD_NM             AS LOCAT_TP
		 , AA.LOCAT_LV
		 , AA.LOCAT_CD
		 , AA.LOCAT_NM
		 , AA.SRCING_POLICY_ID
		 , AA.SRCING_RULE
		 , AA.ACTV_YN
		 , J.COMN_CD_NM             AS SUPPLY_LOCAT_TP
		 , AA.SUPPLY_LOCAT_TP_ID
		 , AA.SUPPLY_LOCAT_LV
		 , AA.SUPPLY_LOCAT_CD
		 , AA.SUPPLY_LOCAT_NM
         , K.VEHICL_TP
         , K.LT                     AS BOD_LEADTIME
         , K.UOM_NM
		 , AA.CREATE_BY
		 , AA.CREATE_DTTM
		 , AA.MODIFY_BY
		 , AA.MODIFY_DTTM
	  FROM (
			SELECT D.ID 
				 , C.ID             AS C_LOC_MGMT_ID
				 , E.ID             AS S_LOC_MGMT_ID
				 , A.ID             AS TO_LOC_MST_ID
				 , G.ID             AS FROM_LOC_MST_ID
				 , A.LOCAT_TP_ID
				 , A.LOCAT_LV
				 , B.LOCAT_CD
				 , B.LOCAT_NM
				 , D.SUPPLY_LOCAT_ID
				 , D.BOD_TP_ID
				 , D.SRCING_POLICY_ID
				 , D.SRCING_RULE
				 , D.ACTV_YN
				 , G.LOCAT_TP_ID            AS SUPPLY_LOCAT_TP_ID
				 , G.LOCAT_LV	            AS SUPPLY_LOCAT_LV
				 , F.LOCAT_CD	            AS SUPPLY_LOCAT_CD
				 , F.LOCAT_NM	            AS SUPPLY_LOCAT_NM
				 , D.CREATE_BY
				 , D.CREATE_DTTM
				 , D.MODIFY_BY
				 , D.MODIFY_DTTM
			  FROM TB_CM_LOC_MST A
				 , TB_CM_LOC_DTL B
				 , TB_CM_LOC_MGMT C
				 , TB_CM_LOC_BOD_MAP D
				 , TB_CM_LOC_MGMT E
				 , TB_CM_LOC_DTL F
				 , TB_CM_LOC_MST G
			 WHERE A.ID = B.LOCAT_MST_ID
			   AND B.ID = C.LOCAT_ID
			   AND C.ID = D.CONSUME_LOCAT_ID
			   AND E.ID = D.SUPPLY_LOCAT_ID
			   AND F.ID = E.LOCAT_ID
			   AND G.ID = F.LOCAT_MST_ID
		   ) AA
		   LEFT OUTER JOIN 
		   TB_AD_COMN_CODE B
		ON (AA.LOCAT_TP_ID = B.ID )
		   LEFT OUTER JOIN 
           TB_AD_COMN_CODE C
        ON (AA.SUPPLY_LOCAT_TP_ID = C.ID)
		   LEFT OUTER JOIN 
		   TB_AD_COMN_CODE D
		ON (AA.BOD_TP_ID = D.ID )
		   LEFT OUTER JOIN 
		   TB_AD_COMN_CODE J
		ON (AA.SUPPLY_LOCAT_TP_ID = J.ID)
           LEFT OUTER JOIN
           (
            SELECT  A.CONSUME_LOCAT_ID, A.SUPPLY_LOCAT_ID, A.VEHICL_TP, A.LT, A.UOM_NM
            FROM    (
                    SELECT  A.SHIP_LT_MST_ID, 
                            A.CONSUME_LOCAT_ID, A.SUPPLY_LOCAT_ID, A.VEHICL_TP_ID, A.VEHICL_TP, A.LT, A.UOM_NM,
                            ROW_NUMBER() OVER (PARTITION BY A.CONSUME_LOCAT_ID, A.SUPPLY_LOCAT_ID ORDER BY A.A_PRIO, A.B_PRIO, A.VEHICL_TP) AS ROW_SEQ
                    FROM    (
                            SELECT  A.ID AS SHIP_LT_MST_ID, A.VEHICL_TP_ID, 
                                    A.CONSUME_LOCAT_ID, A.SUPPLY_LOCAT_ID,
                                    B.VEHICL_TP, NVL(A.PRIORT, 0) A_PRIO, NVL(B.PRIORT, 0) B_PRIO, C.LT, D.UOM_NM
                            FROM    TB_CM_SHIP_LT_MST A,
                                    TB_CM_VEHICLE B,
                                    (
                                    SELECT  SHPP_LEADTIME_MST_ID, SUM(LEADTIME) LT, MIN(UOM_ID) UOM_ID
                                    FROM    TB_CM_SHIP_LT_DTL
                                    GROUP   BY SHPP_LEADTIME_MST_ID
                                    ) C
                                    LEFT OUTER JOIN TB_CM_UOM D
                                    ON D.ID = C.UOM_ID
                            WHERE   B.ID = A.VEHICL_TP_ID
                            AND     A.ID = C.SHPP_LEADTIME_MST_ID
                            AND     NVL(A.ACTV_YN, 'N') = 'Y'
                            ) A
                    ) A
            WHERE   A.ROW_SEQ = 1
           ) K
        ON AA.C_LOC_MGMT_ID = K.CONSUME_LOCAT_ID
		AND AA.S_LOC_MGMT_ID = K.SUPPLY_LOCAT_ID
	 WHERE 1=1
	   -------------------
    	  AND D.ID = CASE WHEN P_BOD_TYPE = 'ALL' OR P_BOD_TYPE IS NULL
                     THEN D.ID
                     ELSE P_BOD_TYPE
                     END
		  AND UPPER(B.COMN_CD_NM) 		LIKE '%'||UPPER(P_CONSUME_LOCAT_TP_NM)||'%'
          AND AA.LOCAT_LV		  		LIKE '%'||P_CONSUME_LOCAT_LV||'%'
		  AND UPPER(AA.LOCAT_CD)  		LIKE '%'||UPPER(P_CONSUME_LOCAT_CD)||'%'
		  AND UPPER(AA.LOCAT_NM)  		LIKE '%'||UPPER(P_CONSUME_LOCAT_NM)||'%'
		  AND UPPER(J.COMN_CD_NM) 		LIKE '%'||UPPER(P_SUPPLY_LOCAT_TP_NM)||'%'
		  AND AA.SUPPLY_LOCAT_LV		LIKE '%'||P_SUPPLY_LOCAT_LV||'%'
		  AND UPPER(AA.SUPPLY_LOCAT_CD) LIKE '%'||UPPER(P_SUPPLY_LOCAT_CD)||'%'
		  AND UPPER(AA.SUPPLY_LOCAT_NM) LIKE '%'||UPPER(P_SUPPLY_LOCAT_NM)||'%'
    ORDER BY
       D.COMN_CD_NM
     , B.SEQ
     , AA.LOCAT_LV
     , AA.LOCAT_CD
     , AA.LOCAT_NM;
          
END;
/

