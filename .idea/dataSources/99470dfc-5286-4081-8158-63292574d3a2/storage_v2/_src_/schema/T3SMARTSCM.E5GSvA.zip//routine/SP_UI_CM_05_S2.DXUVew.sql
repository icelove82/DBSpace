create PROCEDURE SP_UI_CM_05_S2 (
    P_ID                IN CHAR := ''
   ,P_GLOBAL_BOM_MST_ID IN CHAR := ''
   ,P_BOM_VER           IN VARCHAR2 := ''
   ,P_VER_ACTV_YN       IN CHAR := ''
   ,P_BASE_BOM_YN       IN CHAR := ''
   ,P_LOCAT_ITEM_ID     IN CHAR := ''
   ,P_BASE_BOM_RATE     IN NUMBER := NULL
   ,P_ALT_GRP_ID		IN VARCHAR2	:= ''
   ,P_ALT_POLICY_ID		IN VARCHAR2	:= ''
   ,P_PRIORT			IN NUMBER	:= ''
   ,P_PRDUCT_YN			IN CHAR		:= ''
   ,P_ACTV_YN			IN CHAR		:= '' 
   ,P_BOM_LV			IN NUMBER := 0
   ,P_USER_ID			IN VARCHAR2 := ''
   ,P_RT_ROLLBACK_FLAG	OUT VARCHAR2
   ,P_RT_MSG			OUT VARCHAR2
)
IS
    P_ERR_STATUS       NUMBER := 0;
    P_ERR_MSG          VARCHAR2(4000) := '';
    V_PARENT_BASE_QTY  NUMBER := 0;
    V_BASE_BOM_RATE    NUMBER := P_BASE_BOM_RATE;
    V_PRIORT           NUMBER := P_PRIORT;
    V_CHECK_ID         CHAR(32) := NULL;
    
BEGIN

    --NULL CHECK
    IF NVL(P_BASE_BOM_RATE, -1) < 0
    THEN V_BASE_BOM_RATE := 0;
    END IF;

    --BASE QTY
    BEGIN
        SELECT A.BASE_QTY INTO V_PARENT_BASE_QTY
        FROM TB_CM_GLOBAL_BOM_MST A
        WHERE A.ID = P_GLOBAL_BOM_MST_ID;
    EXCEPTION WHEN NO_DATA_FOUND
    THEN V_PARENT_BASE_QTY := 0;
    END;

    --ERROR MESSAGE
    P_ERR_MSG := 'MSG_0006'; -- Required input value is not entered.
    IF P_BOM_VER IS NULL OR P_BOM_VER = ''
    THEN RAISE_APPLICATION_ERROR (-20012, P_ERR_MSG);
    END IF;

    P_ERR_MSG := 'MSG_0008'; -- You cannot enter a negative number.
    IF V_BASE_BOM_RATE < 0
    THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); 
    END IF;

    P_ERR_MSG := 'MSG_0013'; -- Already registered.
    BEGIN
        SELECT ID  INTO V_CHECK_ID 
        FROM TB_CM_GLOBAL_BOM_DTL
        WHERE PRDUCT_BOM_MST_ID = P_GLOBAL_BOM_MST_ID
        AND LOCAT_ITEM_ID = P_LOCAT_ITEM_ID;
    EXCEPTION WHEN NO_DATA_FOUND
    THEN V_CHECK_ID := NULL;
    END;
    
    IF ((P_ID IS NULL OR P_ID = '') AND V_CHECK_ID IS NOT NULL)
    THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); 
    END IF;

    MERGE INTO TB_CM_GLOBAL_BOM_DTL A
    USING (SELECT P_ID AS ID FROM DUAL) B
    ON (A.ID = B.ID)
    WHEN MATCHED THEN
        UPDATE
        SET A.VER_ACTV_YN = P_VER_ACTV_YN
           ,A.BASE_BOM_YN = P_BASE_BOM_YN
           ,A.BASE_BOM_RATE = V_BASE_BOM_RATE
           ,A.CONSUME_QTY = (V_PARENT_BASE_QTY * V_BASE_BOM_RATE)
           ,A.ALT_GRP_ID = P_ALT_GRP_ID
           ,A.ALT_POLICY_ID = P_ALT_POLICY_ID
           ,A.PRIORT = V_PRIORT
           ,A.PRDUCT_YN = P_PRDUCT_YN
           ,A.ACTV_YN = P_ACTV_YN
           ,A.MODIFY_BY = P_USER_ID
           ,A.MODIFY_DTTM = SYSDATE
    WHEN NOT MATCHED THEN
        INSERT (
            ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
           ,PRDUCT_BOM_MST_ID
           ,BOM_VER_ID
           ,VER_ACTV_YN
           ,BASE_BOM_YN
           ,LOCAT_ITEM_ID
           ,STRT_DATE
           ,END_DATE
           ,CONSUME_QTY
           ,BASE_BOM_RATE
           ,ALT_GRP_ID
           ,ALT_POLICY_ID
           ,PRIORT
           ,PRDUCT_YN
           ,ACTV_YN
           ,BOM_LV
        )
        VALUES (
            TO_SINGLE_BYTE(SYS_GUID()), P_USER_ID, SYSDATE, NULL, NULL
           ,P_GLOBAL_BOM_MST_ID
           ,P_BOM_VER
           ,P_VER_ACTV_YN
           ,P_BASE_BOM_YN
           ,P_LOCAT_ITEM_ID
		   ,TO_DATE('19990101', 'YYYY-MM-DD')
           ,TO_DATE('99991231', 'YYYY-MM-DD')
           ,(V_PARENT_BASE_QTY * V_BASE_BOM_RATE)
           ,V_BASE_BOM_RATE
           ,P_ALT_GRP_ID
           ,P_ALT_POLICY_ID
           ,P_PRIORT
           ,P_PRDUCT_YN
           ,P_ACTV_YN
           ,P_BOM_LV
        );
    
    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';
    
    EXCEPTION
    WHEN OTHERS THEN
        P_RT_ROLLBACK_FLAG := 'false';
        IF(SQLCODE = -20012)
          THEN
              P_RT_MSG := P_ERR_MSG;
          ELSE
              P_RT_MSG := SQLERRM;
          END IF;
END;

/

