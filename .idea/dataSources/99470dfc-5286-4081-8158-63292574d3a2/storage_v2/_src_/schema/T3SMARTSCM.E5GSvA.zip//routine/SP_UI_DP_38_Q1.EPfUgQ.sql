create PROCEDURE                SP_UI_DP_38_Q1 (
	  p_PLAN_TP_ID	VARCHAR2 
	, p_BUCK		VARCHAR2
	, p_STRT_DATE	DATE
	, p_END_DATE	DATE
	, p_USER_ID		VARCHAR2 := 'admin'
	, p_ITEM_CD		VARCHAR2
	, p_ACCT_CD		VARCHAR2
	, p_ITEM_LV_CD	VARCHAR2 
	, p_ACCT_LV_CD	VARCHAR2
	, p_RT_MSG		OUT VARCHAR2
    , pRESULT		OUT SYS_REFCURSOR
)
IS


v_DIMENSION_01_ACTV_YN          CHAR(1);						   /* DIMENSION 조회 여부 */
v_DIMENSION_02_ACTV_YN          CHAR(1); 	
v_DIMENSION_03_ACTV_YN          CHAR(1); 	
v_DIMENSION_04_ACTV_YN          CHAR(1); 	
v_DIMENSION_05_ACTV_YN          CHAR(1); 	
v_DIMENSION_06_ACTV_YN          CHAR(1); 	
v_DIMENSION_07_ACTV_YN          CHAR(1); 	
v_DIMENSION_08_ACTV_YN          CHAR(1); 	
v_DIMENSION_09_ACTV_YN          CHAR(1); 	
v_DIMENSION_10_ACTV_YN          CHAR(1); 	
v_DIMENSION_11_ACTV_YN          CHAR(1); 	
v_DIMENSION_12_ACTV_YN          CHAR(1); 	
v_DIMENSION_13_ACTV_YN          CHAR(1); 	
v_DIMENSION_14_ACTV_YN          CHAR(1); 	
v_DIMENSION_15_ACTV_YN          CHAR(1); 	
v_DIMENSION_16_ACTV_YN          CHAR(1); 	
v_DIMENSION_17_ACTV_YN          CHAR(1); 	
v_DIMENSION_18_ACTV_YN          CHAR(1); 	
v_DIMENSION_19_ACTV_YN          CHAR(1); 	
v_DIMENSION_20_ACTV_YN          CHAR(1); 	
v_DIMENSION_21_ACTV_YN          CHAR(1); 	
v_DIMENSION_22_ACTV_YN          CHAR(1); 	
v_DIMENSION_23_ACTV_YN          CHAR(1); 	
v_DIMENSION_24_ACTV_YN          CHAR(1); 	
v_DIMENSION_25_ACTV_YN          CHAR(1); 	
v_DIMENSION_26_ACTV_YN          CHAR(1); 	
v_DIMENSION_27_ACTV_YN          CHAR(1); 	
v_DIMENSION_28_ACTV_YN          CHAR(1); 	
v_DIMENSION_29_ACTV_YN          CHAR(1); 	
v_DIMENSION_30_ACTV_YN          CHAR(1); 	
v_DIMENSION_31_ACTV_YN          CHAR(1); 	
v_DIMENSION_32_ACTV_YN          CHAR(1); 	
v_DIMENSION_33_ACTV_YN          CHAR(1); 	
v_DIMENSION_34_ACTV_YN          CHAR(1); 	
v_DIMENSION_35_ACTV_YN          CHAR(1); 	
v_DIMENSION_36_ACTV_YN          CHAR(1); 	
v_DIMENSION_37_ACTV_YN          CHAR(1); 	
v_DIMENSION_38_ACTV_YN          CHAR(1); 	
v_DIMENSION_39_ACTV_YN          CHAR(1); 	
v_DIMENSION_40_ACTV_YN          CHAR(1); 	

v_PLAN_TP_ID	CHAR(32) :='';
v_DP_VERSION_ID				    VARCHAR2(100);
v_AUTH_TP_ID                    CHAR(32);

v_A_DP_VERSION_ID				VARCHAR2(100);
v_A_AUTH_TP_ID                  CHAR(32);

v_ERR_MSG						VARCHAR2(4000) := '';
v_ERR_STATUS					INT            := NULL;
v_SEARCH_LV_SEQ					INT            := NULL;
v_SEARCH_LV_SEQ_02              INT            := NULL;
v_ITEM_CHECK					INT            := 0;
v_ACCT_CHECK					INT			   := 0;
v_ITEM_LV_CHECK					INT			   := 0;
v_ACCT_LV_CHECK					INT            := 0;

v_LAST_ITEM_LV					INT;
v_LAST_ACCT_LV					INT;
v_STRT_DATE						DATE;
v_END_DATE						DATE;


BEGIN

    select ID INTO v_PLAN_TP_ID  from TB_CM_COMM_CONFIG where conf_grp_cd = 'DP_PLAN_TYPE' and conf_cd = 'DP_PLAN_MONTHLY';

	IF ( p_STRT_DATE IS NOT NULL )
    THEN
        -- 월 첫날
        --v_STRT_DATE = CONVERT(CHAR(10),DATEADD(mm, DATEDIFF(mm,0,p_STRT_DATE), 0),23)
        v_STRT_DATE := ADD_MONTHS(LAST_DAY(p_STRT_DATE)+1,-1);
    END IF;
	IF ( p_END_DATE IS NOT NULL )
    THEN
        -- 월 마지막 날
        --v_END_DATE = CONVERT(CHAR(10),DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,p_END_DATE)+1,0)),23)
        v_END_DATE := LAST_DAY(p_END_DATE);
    END IF;
----------------------------------------------------------------------------------
-- item level 혹은 ITEM CODE를 검색한다면 메시지 Validation
----------------------------------------------------------------------------------

	IF ( p_ITEM_LV_CD IS NOT NULL OR p_ITEM_CD IS NOT NULL )
    THEN
        SELECT COUNT(*) INTO v_ITEM_CHECK
          FROM TB_CM_ITEM_MST
         WHERE 1=1
           AND REGEXP_LIKE(UPPER(ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\['))                
--           AND  ITEM_CD IN (
--                SELECT TRIM(REGEXP_SUBSTR(p_ITEM_CD, '[^|]+', 1, LEVEL)) AS ITEM_CD
--                    FROM DUAL
--                CONNECT BY INSTR(p_ITEM_CD, '|', 1, LEVEL - 1) > 0
--            )
           AND COALESCE(DEL_YN,'N') = 'N'
           AND DP_PLAN_YN = 'Y'
        ;

        SELECT COUNT(*) INTO v_ITEM_LV_CHECK
          FROM TB_CM_ITEM_LEVEL_MGMT
         WHERE 1=1
           AND ITEM_LV_CD = p_ITEM_LV_CD
           AND COALESCE(DEL_YN,'N')='N'
        ;

        IF ( v_ITEM_CHECK != 0 )
        THEN
            SELECT MAX(SEARCH_LV_SEQ)+1 INTO v_SEARCH_LV_SEQ
              FROM (
                        SELECT DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ
                          FROM TB_CM_ITEM_LEVEL_MGMT SL
                               INNER JOIN
                               TB_CM_LEVEL_MGMT LV
                            ON (SL.LV_MGMT_ID = LV.ID)
                         WHERE 1=1
                           AND COALESCE(SL.DEL_YN,'N') = 'N'
                           AND COALESCE(LV.DEL_YN,'N') = 'N'   
            )
            ;
        ELSIF ( v_ITEM_LV_CHECK != 0 )
        THEN
            SELECT SEARCH_LV_SEQ INTO v_SEARCH_LV_SEQ
              FROM ( 
                        SELECT  IL.ITEM_LV_CD
                              , DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ
                          FROM TB_CM_ITEM_LEVEL_MGMT IL
                               INNER JOIN
                               TB_CM_LEVEL_MGMT LV
                            ON(IL.LV_MGMT_ID = LV.ID)
                         WHERE 1=1
                           AND COALESCE(IL.DEL_YN,'N') = 'N'
                           AND COALESCE(LV.DEL_YN,'N') = 'N' 
                  )
            ;
        ELSE
            v_ERR_MSG := 'MSG_0020';
            RAISE_APPLICATION_ERROR(-20001, v_ERR_MSG); 
        END IF;
    END IF;
----------------------------------------------------------------------------------
    -- ACCOUNT LEVEL 혹은 ACCOUNT CODE를 검색한다면 메시지 Validation
----------------------------------------------------------------------------------
    IF ( p_ACCT_LV_CD IS NOT NULL OR p_ACCT_CD  IS NOT NULL )
    THEN
        SELECT COUNT(*) INTO v_ACCT_CHECK
          FROM TB_DP_ACCOUNT_MST
         WHERE 1=1
           AND (REGEXP_LIKE(UPPER(ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                OR p_ACCT_CD IS NULL
          )
--           AND ACCOUNT_CD IN (
--                SELECT TRIM(REGEXP_SUBSTR(p_ACCT_CD, '[^|]+', 1, LEVEL)) AS ACCT_CD
--                    FROM DUAL
--                CONNECT BY INSTR(p_ACCT_CD, '|', 1, LEVEL - 1) > 0
--            )
           AND COALESCE(DEL_YN,'N') = 'N'
           AND ACTV_YN = 'Y'
         ;

        SELECT COUNT(*) INTO v_ACCT_LV_CHECK
          FROM TB_DP_SALES_LEVEL_MGMT
         WHERE 1=1
           AND SALES_LV_CD = p_ACCT_LV_CD
            AND COALESCE(DEL_YN,'N') = 'N'   
        ;

        IF(v_ACCT_CHECK != 0)    
        THEN    -- ACCOUNT 최하위 레벨로 SEQ 넣어주기
             SELECT MAX(SEARCH_LV_SEQ)+1 INTO v_SEARCH_LV_SEQ_02
                FROM(        
                        SELECT  DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ
                          FROM TB_DP_SALES_LEVEL_MGMT SL
                               INNER JOIN
                               TB_CM_LEVEL_MGMT LV
                            ON (SL.LV_MGMT_ID = LV.ID)
                         WHERE 1=1
                           AND COALESCE(SL.DEL_YN,'N') = 'N'
                           AND COALESCE(LV.DEL_YN,'N') = 'N'
            )   
            ;
        ELSIF(v_ACCT_LV_CHECK != 0) -- ACCOUNT LEVEL 레벨로 SEQ 넣어주기
        THEN
            SELECT SEARCH_LV_SEQ_02 INTO v_SEARCH_LV_SEQ_02
              FROM (
                        SELECT SL.SALES_LV_CD
                              , DENSE_RANK() OVER (ORDER BY LV.SEQ ASC) AS SEARCH_LV_SEQ_02
                          FROM TB_DP_SALES_LEVEL_MGMT SL
                               INNER JOIN
                               TB_CM_LEVEL_MGMT LV
                            ON (SL.LV_MGMT_ID = LV.ID)
                         WHERE 1=1
                           AND COALESCE(SL.DEL_YN,'N') = 'N'
                           AND COALESCE(LV.DEL_YN,'N') = 'N'   
            )
            WHERE SALES_LV_CD = p_ACCT_LV_CD
            ;
        ELSE 
            v_ERR_MSG := 'MSG_0020';
            RAISE_APPLICATION_ERROR(-20001, v_ERR_MSG);
        END IF;
    END IF;

---------------------------------------------------------------------------------
    -- 개인화에서 DIMENSION 칼럼의 활성화 여부 값 가져오기
    ---- 20개까지 DIMENSION이 있을 것이라고 가정한 것 (하드코딩)
---------------------------------------------------------------------------------

-- 최하단 ITEM & ACCOUNT LV 셋팅
    SELECT	CAST(SUBSTR(MAX(A.FLD_CD), 11,2) AS INT ) INTO v_LAST_ITEM_LV
    FROM	TB_AD_USER_PREF_DTL A 
    inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = 'UI_DP_38' and m.GRID_CD = 'RST_CPT_01' 
    inner join TB_AD_GROUP g on g.ID = A.GRP_ID 
    inner join TB_AD_USER u on u.USERNAME = p_USER_ID 
    inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
    LEFT OUTER JOIN TB_AD_USER_PREF B  ON	m.id = B.USER_PREF_MST_ID AND A.GRP_ID = B.GRP_ID	AND	A.FLD_CD = B.FLD_CD	AND B.USER_ID = u.ID					
    WHERE COALESCE(B.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N')) = 'Y' AND A.DIM_MEASURE_TP = 'DIMENSION'    AND SUBSTR(A.FLD_CD, 11,2) BETWEEN 1 AND 20  
    ;

    SELECT	CAST(SUBSTR(MAX(A.FLD_CD), 11,2) AS INT ) INTO v_LAST_ACCT_LV
    FROM	TB_AD_USER_PREF_DTL A 
    inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = 'UI_DP_38' and m.GRID_CD = 'RST_CPT_01' 
    inner join TB_AD_GROUP g on g.ID = A.GRP_ID
    inner join TB_AD_USER u on u.USERNAME = p_USER_ID 
    inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
    LEFT OUTER JOIN TB_AD_USER_PREF B  ON	m.id = B.USER_PREF_MST_ID AND A.GRP_ID = B.GRP_ID	AND	A.FLD_CD = B.FLD_CD	AND B.USER_ID = u.ID					
    WHERE COALESCE(B.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N')) = 'Y' AND A.DIM_MEASURE_TP = 'DIMENSION'    AND SUBSTR(A.FLD_CD, 11,2) BETWEEN 21 AND 40
    ;

	 SELECT  MAX(CASE WHEN A.FLD_CD = 'DIMENSION_01' THEN A.ACTV_YN ELSE NULL END) 
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_02' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_03' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_04' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_05' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_06' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_07' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_08' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_09' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_10' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_11' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_12' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_13' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_14' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_15' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_16' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_17' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_18' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_19' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_20' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_21' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_22' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_23' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_24' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_25' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_26' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_27' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_28' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_29' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_30' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_31' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_32' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_33' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_34' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_35' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_36' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_37' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_38' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_39' THEN A.ACTV_YN ELSE NULL END)
           , MAX(CASE WHEN A.FLD_CD = 'DIMENSION_40' THEN A.ACTV_YN ELSE NULL END)
             INTO
             v_DIMENSION_01_ACTV_YN
           , v_DIMENSION_02_ACTV_YN
           , v_DIMENSION_03_ACTV_YN
           , v_DIMENSION_04_ACTV_YN
           , v_DIMENSION_05_ACTV_YN
           , v_DIMENSION_06_ACTV_YN
           , v_DIMENSION_07_ACTV_YN
           , v_DIMENSION_08_ACTV_YN
           , v_DIMENSION_09_ACTV_YN
           , v_DIMENSION_10_ACTV_YN
           , v_DIMENSION_11_ACTV_YN
           , v_DIMENSION_12_ACTV_YN
           , v_DIMENSION_13_ACTV_YN
           , v_DIMENSION_14_ACTV_YN
           , v_DIMENSION_15_ACTV_YN
           , v_DIMENSION_16_ACTV_YN
           , v_DIMENSION_17_ACTV_YN
           , v_DIMENSION_18_ACTV_YN
           , v_DIMENSION_19_ACTV_YN
           , v_DIMENSION_20_ACTV_YN
           , v_DIMENSION_21_ACTV_YN
           , v_DIMENSION_22_ACTV_YN
           , v_DIMENSION_23_ACTV_YN
           , v_DIMENSION_24_ACTV_YN
           , v_DIMENSION_25_ACTV_YN
           , v_DIMENSION_26_ACTV_YN
           , v_DIMENSION_27_ACTV_YN
           , v_DIMENSION_28_ACTV_YN
           , v_DIMENSION_29_ACTV_YN
           , v_DIMENSION_30_ACTV_YN
           , v_DIMENSION_31_ACTV_YN
           , v_DIMENSION_32_ACTV_YN
           , v_DIMENSION_33_ACTV_YN
           , v_DIMENSION_34_ACTV_YN
           , v_DIMENSION_35_ACTV_YN
           , v_DIMENSION_36_ACTV_YN
           , v_DIMENSION_37_ACTV_YN
           , v_DIMENSION_38_ACTV_YN
           , v_DIMENSION_39_ACTV_YN
           , v_DIMENSION_40_ACTV_YN
    FROM ( 
		SELECT	 m.VIEW_CD
					,m.GRID_CD
					,g.GRP_CD
					,A.FLD_CD
					,A.REFER_VALUE
					,A.FLD_APPLY_CD
					,A.DIM_MEASURE_TP
					,A.CROSSTAB_ITEM_CD
					,A.FLD_SEQ AS SEQ_1, B.FLD_SEQ AS SEQ_2
					, COALESCE(B.DATA_KEY_YN,COALESCE(A.DATA_KEY_YN,'N'))  AS DATA_KEY_YN 
					, COALESCE(B.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N'))			 AS ACTV_YN 
					, ROW_NUMBER() OVER( ORDER BY A.FLD_CD)   AS ROW_NUM 
			FROM	TB_AD_USER_PREF_DTL A 
					inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = 'UI_DP_38'  AND m.GRID_CD	= 'RST_CPT_01'
					inner join TB_AD_GROUP g on g.ID = A.GRP_ID 
					inner join TB_AD_USER u on u.USERNAME = p_USER_ID
					inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
					LEFT OUTER JOIN TB_AD_USER_PREF B  ON	m.id = B.USER_PREF_MST_ID	AND A.GRP_ID	= B.GRP_ID	AND	A.FLD_CD	= B.FLD_CD	AND B.USER_ID	= u.ID
			WHERE    A.CROSSTAB_ITEM_CD = 'GROUP-COLUMNS'
       )  A
    GROUP BY  CROSSTAB_ITEM_CD
    ;

----  ========================================
--  CODE   SETTING 
----   =======================================
    SELECT ID
	     , CL_LV_MGMT_ID
           INTO
           v_DP_VERSION_ID
         , v_AUTH_TP_ID
      FROM	(
            SELECT   MST.ID --VER_ID    
                    , CL_LV_MGMT_ID
                    , ROW_NUMBER() OVER (ORDER BY MST.CREATE_DTTM DESC) AS ROWN
              FROM   TB_DP_CONTROL_BOARD_VER_MST MST  
                     INNER JOIN
                     TB_DP_CONTROL_BOARD_VER_DTL DTL  
                ON (DTL.CONBD_VER_MST_ID = MST.ID)
             WHERE  1=1
               AND DTL.CL_STATUS_ID = (SELECT ID
                                         FROM TB_CM_COMM_CONFIG   
                                        WHERE CONF_GRP_CD = 'DP_CL_STATUS' 
                                          AND CONF_CD = 'CLOSE')
               AND MST.PLAN_TP_ID = v_PLAN_TP_ID
			  AND DTL.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL') 
              ) A
    WHERE ROWN = 1;

--	-- Annual DP's Version 과 Auth Type
--    SELECT v_A_DP_VERSION_ID = ID
--	     , v_A_AUTH_TP_ID = CL_LV_MGMT_ID
--      FROM	(
--            SELECT    MST.ID --VER_ID  
--                    , CL_LV_MGMT_ID
--                    , ROW_NUMBER() OVER (ORDER BY MST.CREATE_DTTM DESC) AS ROWN
--              FROM   TB_DP_CONTROL_BOARD_VER_MST MST  
--                     INNER JOIN
--                     TB_DP_CONTROL_BOARD_VER_DTL DTL  
--                ON (DTL.CONBD_VER_MST_ID = MST.ID)
--             WHERE  1=1
--               AND DTL.CL_STATUS_ID = (SELECT ID
--                                         FROM TB_CM_COMM_CONFIG   
--                                        WHERE CONF_GRP_CD = 'DP_CL_STATUS' 
--                                          AND CONF_CD = 'CLOSE')
--               AND MST.PLAN_TP_ID = (
--                                     SELECT  B.ID
--                                       FROM  TB_CM_COMM_CONFIG B
--                                             INNER JOIN
--                                             TB_DP_PLAN_POLICY C
--                                         ON (B.ID = C.PLAN_TP_ID)
--                                             INNER JOIN
--                                             TB_CM_COMM_CONFIG D
--                                         ON (C.POLICY_ID = D.ID)
--                                      where  1=1 
--                                           AND B.CONF_GRP_CD LIKE  '%' + 'DP_PLAN_TYPE' + '%'  --'DP_LV_TP'
--                                           AND B.ACTV_YN = 'Y'
--                                           AND D.CONF_CD = 'B'
--                                           AND B.ATTR_01 = 'Y')
--			AND DTL.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL') 
--                                   ) A
--    WHERE ROWN = 1;

--------------------------------
-- ITEM * MEASURE   SETTING   --
--------------------------------
    OPEN pRESULT FOR
    SELECT   CASE WHEN --YEAR(M.BUCKET_START_DATE)=YEAR(M.BUCKET_END_DATE)
                       -- AND MONTH(M.BUCKET_START_DATE)=MONTH(M.BUCKET_END_DATE)
                       --THEN CONVERT(CHAR(7), M.BUCKET_START_DATE, 23)
                --ELSE 'SUM-'||CONVERT(CHAR(7),M.BUCKET_START_DATE,102)||'~'||CONVERT(CHAR(2),M.BUCKET_END_DATE,110)
                       EXTRACT ( YEAR FROM M.BUCKET_START_DATE ) = EXTRACT ( YEAR FROM M.BUCKET_END_DATE )
                   AND EXTRACT ( MONTH FROM M.BUCKET_START_DATE) = EXTRACT ( MONTH FROM M.BUCKET_END_DATE)
                  THEN TO_CHAR(M.BUCKET_START_DATE, 'yyyy-MM')
                  ELSE 'SUM-'||TO_CHAR(M.BUCKET_START_DATE,'yyyy.MM')||'~'||LPAD(EXTRACT(MONTH FROM M.BUCKET_END_DATE),2,'0')
                  END                AS "DATE" 
		------------------------------------------
		-- DIMENSION:   LEVEL 값을 하드코딩 해야 함 -- 
		------------------------------------------
        --, 'MD01' AS DB_TYPE -- hyundai custom
        -- ITEM 
		, CASE WHEN v_DIMENSION_01_ACTV_YN = 'Y' THEN ITEM_LVL01_CD	   ELSE NULL END AS DIMENSION_01
		, CASE WHEN v_DIMENSION_02_ACTV_YN = 'Y' THEN ITEM_LVL01_NM       ELSE NULL END AS DIMENSION_02
		, CASE WHEN v_DIMENSION_03_ACTV_YN = 'Y' THEN ITEM_LVL02_CD	   ELSE NULL END AS DIMENSION_03
		, CASE WHEN v_DIMENSION_04_ACTV_YN = 'Y' THEN ITEM_LVL02_NM       ELSE NULL END AS DIMENSION_04
		, CASE WHEN v_DIMENSION_05_ACTV_YN = 'Y' THEN ITEM_LVL03_CD       ELSE NULL END AS DIMENSION_05
		, CASE WHEN v_DIMENSION_06_ACTV_YN = 'Y' THEN ITEM_LVL03_NM       ELSE NULL END AS DIMENSION_06
		, CASE WHEN v_DIMENSION_07_ACTV_YN = 'Y' THEN ITEM_LVL04_CD       ELSE NULL END AS DIMENSION_07
		, CASE WHEN v_DIMENSION_08_ACTV_YN = 'Y' THEN ITEM_LVL04_NM       ELSE NULL END AS DIMENSION_08
		, CASE WHEN v_DIMENSION_09_ACTV_YN = 'Y' THEN ITEM_LVL05_CD	   ELSE NULL END AS DIMENSION_09
		, CASE WHEN v_DIMENSION_10_ACTV_YN = 'Y' THEN ITEM_LVL05_NM       ELSE NULL END AS DIMENSION_10
		, CASE WHEN v_DIMENSION_11_ACTV_YN = 'Y' THEN ITEM_LVL06_CD       ELSE NULL END AS DIMENSION_11
		, CASE WHEN v_DIMENSION_12_ACTV_YN = 'Y' THEN ITEM_LVL06_NM       ELSE NULL END AS DIMENSION_12
		, CASE WHEN v_DIMENSION_13_ACTV_YN = 'Y' THEN ITEM_LVL07_CD       ELSE NULL END AS DIMENSION_13
		, CASE WHEN v_DIMENSION_14_ACTV_YN = 'Y' THEN ITEM_LVL07_NM       ELSE NULL END AS DIMENSION_14
		, CASE WHEN v_DIMENSION_15_ACTV_YN = 'Y' THEN ITEM_LVL08_CD       ELSE NULL END AS DIMENSION_15
		, CASE WHEN v_DIMENSION_16_ACTV_YN = 'Y' THEN ITEM_LVL08_NM       ELSE NULL END AS DIMENSION_16
		, CASE WHEN v_DIMENSION_17_ACTV_YN = 'Y' THEN ITEM_LVL09_CD       ELSE NULL END AS DIMENSION_17
		, CASE WHEN v_DIMENSION_18_ACTV_YN = 'Y' THEN ITEM_LVL09_NM       ELSE NULL END AS DIMENSION_18
		, CASE WHEN v_DIMENSION_19_ACTV_YN = 'Y' THEN ITEM_LVL10_CD       ELSE NULL END AS DIMENSION_19
		, CASE WHEN v_DIMENSION_20_ACTV_YN = 'Y' THEN ITEM_LVL10_NM       ELSE NULL END AS DIMENSION_20

        -- ACCOUNT
		, CASE WHEN v_DIMENSION_21_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_CD       ELSE NULL END AS DIMENSION_21
		, CASE WHEN v_DIMENSION_22_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_NM       ELSE NULL END AS DIMENSION_22
		, CASE WHEN v_DIMENSION_23_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_CD       ELSE NULL END AS DIMENSION_23
		, CASE WHEN v_DIMENSION_24_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_NM	      ELSE NULL END AS DIMENSION_24
		, CASE WHEN v_DIMENSION_25_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_CD       ELSE NULL END AS DIMENSION_25
		, CASE WHEN v_DIMENSION_26_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_NM       ELSE NULL END AS DIMENSION_26
		, CASE WHEN v_DIMENSION_27_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_CD       ELSE NULL END AS DIMENSION_27
		, CASE WHEN v_DIMENSION_28_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_NM       ELSE NULL END AS DIMENSION_28
		, CASE WHEN v_DIMENSION_29_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_CD       ELSE NULL END AS DIMENSION_29
		, CASE WHEN v_DIMENSION_30_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_NM       ELSE NULL END AS DIMENSION_30
		, CASE WHEN v_DIMENSION_31_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_CD       ELSE NULL END AS DIMENSION_31
		, CASE WHEN v_DIMENSION_32_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_NM       ELSE NULL END AS DIMENSION_32        
		, CASE WHEN v_DIMENSION_33_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_CD       ELSE NULL END AS DIMENSION_33
		, CASE WHEN v_DIMENSION_34_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_NM       ELSE NULL END AS DIMENSION_34
		, CASE WHEN v_DIMENSION_35_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_CD       ELSE NULL END AS DIMENSION_35
		, CASE WHEN v_DIMENSION_36_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_NM       ELSE NULL END AS DIMENSION_36
		, CASE WHEN v_DIMENSION_37_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_CD       ELSE NULL END AS DIMENSION_37
		, CASE WHEN v_DIMENSION_38_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_NM       ELSE NULL END AS DIMENSION_38
		, CASE WHEN v_DIMENSION_39_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_CD       ELSE NULL END AS DIMENSION_39
		, CASE WHEN v_DIMENSION_40_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_NM       ELSE NULL END AS DIMENSION_40
        , CASE v_LAST_ITEM_LV WHEN 1             THEN  ITEM_LVL01_CD
                              WHEN 2             THEN  ITEM_LVL01_NM
                              WHEN 3             THEN  ITEM_LVL02_CD
                              WHEN 4             THEN  ITEM_LVL02_NM
                              WHEN 5             THEN  ITEM_LVL03_CD
                              WHEN 6             THEN  ITEM_LVL03_NM
                              WHEN 7             THEN  ITEM_LVL04_CD
                              WHEN 8             THEN  ITEM_LVL04_NM
                              WHEN 9             THEN  ITEM_LVL05_CD
                              WHEN 10            THEN  ITEM_LVL05_NM
                              WHEN 11            THEN  ITEM_LVL06_CD
                              WHEN 12            THEN  ITEM_LVL06_NM
                              WHEN 13            THEN  ITEM_LVL07_CD
                              WHEN 14            THEN  ITEM_LVL07_NM
                              WHEN 15            THEN  ITEM_LVL08_CD
                              WHEN 16            THEN  ITEM_LVL08_NM
                              WHEN 17            THEN  ITEM_LVL09_CD
                              WHEN 18            THEN  ITEM_LVL09_NM
                              WHEN 19            THEN  ITEM_LVL10_CD
                              WHEN 20            THEN  ITEM_LVL10_NM
                              --else null
							  END	AS ITEM

        , CASE v_LAST_ACCT_LV WHEN 21            THEN  ACCOUNT_LVL01_CD
                               WHEN 22            THEN  ACCOUNT_LVL01_NM
                               WHEN 23            THEN  ACCOUNT_LVL02_CD
                               WHEN 24            THEN  ACCOUNT_LVL02_NM
                               WHEN 25            THEN  ACCOUNT_LVL03_CD
                               WHEN 26            THEN  ACCOUNT_LVL03_NM
                               WHEN 27            THEN  ACCOUNT_LVL04_CD
                               WHEN 28            THEN  ACCOUNT_LVL04_NM
                               WHEN 29            THEN  ACCOUNT_LVL05_CD
                               WHEN 30            THEN  ACCOUNT_LVL05_NM
                               WHEN 31            THEN  ACCOUNT_LVL06_CD
                               WHEN 32            THEN  ACCOUNT_LVL06_NM
                               WHEN 33            THEN  ACCOUNT_LVL07_CD
                               WHEN 34            THEN  ACCOUNT_LVL07_NM
                               WHEN 35            THEN  ACCOUNT_LVL08_CD
                               WHEN 36            THEN  ACCOUNT_LVL08_NM
                               WHEN 37            THEN  ACCOUNT_LVL09_CD
                               WHEN 38            THEN  ACCOUNT_LVL09_NM
                               WHEN 39            THEN  ACCOUNT_LVL10_CD
                               WHEN 40            THEN  ACCOUNT_LVL10_NM
                END
		        AS ACCOUNT
		, ' ' AS SALES
        -- MEASURE
		, SUM(COALESCE(T_ACTUAL_SALES.QTY, 0))	    AS MEASURE_01
        , SUM(COALESCE(T_ACTUAL_SALES.AMT, 0 ))		AS MEASURE_02
		, SUM(COALESCE(T_ANNUAL_DP.QTY, 0))			AS MEASURE_03
		, SUM(COALESCE(T_FINAL_DP.QTY, 0)) 			AS MEASURE_04
        , CASE WHEN	SUM( COALESCE(T_ANNUAL_DP.QTY, 0)) = 0 THEN 0
               ELSE	(1-ABS(SUM(COALESCE(T_ANNUAL_DP.QTY,0))-SUM(COALESCE(T_ACTUAL_SALES.QTY,0)))/SUM(COALESCE(T_ANNUAL_DP.QTY,0)))*100
                         -- ( 1 - ABS(연간PLAN - Actual)/연간PLAN)*100
			   END		AS MEASURE_05 -- 경영
        , CASE WHEN	SUM( COALESCE(T_FINAL_DP.QTY, 0)) = 0 THEN 0
			   ELSE	(1-ABS(SUM(COALESCE(T_FINAL_DP.QTY,0))-SUM(COALESCE(T_ACTUAL_SALES.QTY,0)))/SUM(COALESCE(T_FINAL_DP.QTY,0)))*100
                         -- ( 1 - ABS(월간PLAN - Actual)/월간PLAN)*100
			   END		AS MEASURE_06 -- 판매
--        , SUM (COALESCE(T_ACTUAL_SALES.YOY,0)) AS MEASURE_07 --여기
        FROM TABLE(FN_DP_TEMP_REPORT_MAIN_THREE(	        p_BUCK 
                                                   , v_STRT_DATE
                                                   , v_END_DATE
                                                   , v_DP_VERSION_ID 
                                                   , v_AUTH_TP_ID
                                                   , CASE WHEN v_ITEM_CHECK = 0    THEN NULL ELSE p_ITEM_CD    END
                                                   , CASE WHEN v_ACCT_CHECK = 0    THEN NULL ELSE p_ACCT_CD    END
                                                   , CASE WHEN v_ITEM_LV_CHECK = 0 THEN NULL ELSE p_ITEM_LV_CD END
                                                   , CASE WHEN v_ACCT_LV_CHECK = 0 THEN NULL ELSE p_ACCT_LV_CD END
                                                   , v_SEARCH_LV_SEQ
                                                   , v_SEARCH_LV_SEQ_02
                                                   , p_USER_ID)) M  
					   -------------------------------------- 
					   --  MEASURE 1 ACTUAL_SALES
					   -------------------------------------- 
					LEFT OUTER JOIN
						(
							SELECT ITEM_MST_ID
                                 , ACCOUNT_ID
                                 , BUCKET_START_DATE
                                 , BUCKET_END_DATE
                                 , sum(QTY) qty
                                 , sum(AMT) amt
--                                 , sum(YOY_QTY) as YOY
                              FROM TB_CM_ACTUAL_SALES A 
								  ,TABLE(FN_DP_TEMP_THREE_CAL( v_STRT_DATE, v_END_DATE )) CA 
						 	 WHERE A.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
					      GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE, BUCKET_END_DATE
						) T_ACTUAL_SALES
						ON
						M.ITEM_ID = T_ACTUAL_SALES.ITEM_MST_ID
						AND M.ACCOUNT_ID = T_ACTUAL_SALES.ACCOUNT_ID
						AND T_ACTUAL_SALES.BUCKET_START_DATE = M.BUCKET_START_DATE
                              AND T_ACTUAL_SALES.BUCKET_END_DATE = M.BUCKET_END_DATE
		--				 UNION ALL 
					   -------------------------------------- 
					   -- MEASURE 2 Annual DP 
					   -------------------------------------- 
					LEFT OUTER JOIN 
						(
--							SELECT ITEM_MST_ID
--                                 , ACCOUNT_ID
--                                 , BUCKET_START_DATE
--                                 , BUCKET_END_DATE
--                                 , AUTH_TP_ID
--                                 , sum(qty) qty 
--                              FROM TB_DP_ENTRY A 
--								  ,TABLE (FN_DP_TEMP_THREE_CAL( v_STRT_DATE, v_END_DATE )) CA
--							 WHERE A.QTY > 0 
--                                      AND A.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
--                                      AND A.VER_ID = v_A_DP_VERSION_ID
--                                      AND AUTH_TP_ID = v_A_AUTH_TP_ID
--						  GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE, AUTH_TP_ID, BUCKET_END_DATE
						  SELECT ITEM_MST_ID, ACCOUNT_ID
								,CA.BUCKET_START_DATE
								,CA.BUCKET_END_DATE
								,SUM(ANNUAL_QTY)	AS QTY
						    FROM TB_DP_MEASURE_DATA AN
								 INNER JOIN
								 TABLE( FN_DP_TEMP_THREE_CAL( v_STRT_DATE, v_END_DATE ))  CA
                              ON AN.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
						   WHERE ANNUAL_QTY >0
						GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE, BUCKET_END_DATE
						) T_ANNUAL_DP 
						ON
						M.ITEM_ID = T_ANNUAL_DP.ITEM_MST_ID
						AND M.ACCOUNT_ID = T_ANNUAL_DP.ACCOUNT_ID
						AND T_ANNUAL_DP.BUCKET_START_DATE = M.BUCKET_START_DATE
                              AND T_ANNUAL_DP.BUCKET_END_DATE = M.BUCKET_END_DATE

		--             UNION ALL 


					   --------------------------------------
					   --  MEASURE 4 Final DP  
					   --------------------------------------
          LEFT OUTER JOIN (
							SELECT ITEM_MST_ID
                                 , ACCOUNT_ID
                                 , BUCKET_START_DATE
                                 , BUCKET_END_DATE
--                                 , AUTH_TP_ID
                                 , sum(qty) qty
                              FROM TB_DP_ENTRY_HISTORY A
								  ,TABLE ( FN_DP_TEMP_THREE_CAL( v_STRT_DATE, v_END_DATE)) CA
							WHERE A.BASE_DATE BETWEEN CA.BUCKET_START_DATE AND CA.BUCKET_END_DATE
--						AND A.VER_ID = v_DP_VERSION_ID
--                              AND AUTH_TP_ID = v_AUTH_TP_ID
						 GROUP BY ITEM_MST_ID, ACCOUNT_ID, BUCKET_START_DATE
--                         , AUTH_TP_ID
                         , BUCKET_END_DATE
						) T_FINAL_DP
						ON
						M.ITEM_ID = T_FINAL_DP.ITEM_MST_ID
						AND M.ACCOUNT_ID = T_FINAL_DP.ACCOUNT_ID
						AND T_FINAL_DP.BUCKET_START_DATE = M.BUCKET_START_DATE
                              AND T_FINAL_DP.BUCKET_END_DATE = M.BUCKET_END_DATE

-- WHERE

GROUP BY 	  
          M.BUCKET_START_DATE
          , M.BUCKET_END_DATE
		, CASE WHEN v_DIMENSION_01_ACTV_YN = 'Y' THEN ITEM_LVL01_CD	      ELSE NULL END 
		, CASE WHEN v_DIMENSION_02_ACTV_YN = 'Y' THEN ITEM_LVL01_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_03_ACTV_YN = 'Y' THEN ITEM_LVL02_CD	      ELSE NULL END 
		, CASE WHEN v_DIMENSION_04_ACTV_YN = 'Y' THEN ITEM_LVL02_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_05_ACTV_YN = 'Y' THEN ITEM_LVL03_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_06_ACTV_YN = 'Y' THEN ITEM_LVL03_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_07_ACTV_YN = 'Y' THEN ITEM_LVL04_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_08_ACTV_YN = 'Y' THEN ITEM_LVL04_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_09_ACTV_YN = 'Y' THEN ITEM_LVL05_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_10_ACTV_YN = 'Y' THEN ITEM_LVL05_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_11_ACTV_YN = 'Y' THEN ITEM_LVL06_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_12_ACTV_YN = 'Y' THEN ITEM_LVL06_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_13_ACTV_YN = 'Y' THEN ITEM_LVL07_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_14_ACTV_YN = 'Y' THEN ITEM_LVL07_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_15_ACTV_YN = 'Y' THEN ITEM_LVL08_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_16_ACTV_YN = 'Y' THEN ITEM_LVL08_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_17_ACTV_YN = 'Y' THEN ITEM_LVL09_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_18_ACTV_YN = 'Y' THEN ITEM_LVL09_NM       ELSE NULL END
		, CASE WHEN v_DIMENSION_19_ACTV_YN = 'Y' THEN ITEM_LVL10_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_20_ACTV_YN = 'Y' THEN ITEM_LVL10_NM       ELSE NULL END
        -- ACCOUNT
		, CASE WHEN v_DIMENSION_21_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_22_ACTV_YN = 'Y' THEN ACCOUNT_LVL01_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_23_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_24_ACTV_YN = 'Y' THEN ACCOUNT_LVL02_NM	      ELSE NULL END 
		, CASE WHEN v_DIMENSION_25_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_26_ACTV_YN = 'Y' THEN ACCOUNT_LVL03_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_27_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_28_ACTV_YN = 'Y' THEN ACCOUNT_LVL04_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_29_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_30_ACTV_YN = 'Y' THEN ACCOUNT_LVL05_NM	      ELSE NULL END 
		, CASE WHEN v_DIMENSION_31_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_32_ACTV_YN = 'Y' THEN ACCOUNT_LVL06_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_33_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_34_ACTV_YN = 'Y' THEN ACCOUNT_LVL07_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_35_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_CD       ELSE NULL END 
		, CASE WHEN v_DIMENSION_36_ACTV_YN = 'Y' THEN ACCOUNT_LVL08_NM	      ELSE NULL END 
		, CASE WHEN v_DIMENSION_37_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_38_ACTV_YN = 'Y' THEN ACCOUNT_LVL09_NM       ELSE NULL END 
		, CASE WHEN v_DIMENSION_39_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_CD       ELSE NULL END
		, CASE WHEN v_DIMENSION_40_ACTV_YN = 'Y' THEN ACCOUNT_LVL10_NM       ELSE NULL END 
        , CASE v_LAST_ITEM_LV WHEN 1             THEN  ITEM_LVL01_CD
                               WHEN 2             THEN  ITEM_LVL01_NM
                               WHEN 3             THEN  ITEM_LVL02_CD
                               WHEN 4             THEN  ITEM_LVL02_NM
                               WHEN 5             THEN  ITEM_LVL03_CD
                               WHEN 6             THEN  ITEM_LVL03_NM
                               WHEN 7             THEN  ITEM_LVL04_CD
                               WHEN 8             THEN  ITEM_LVL04_NM
                               WHEN 9             THEN  ITEM_LVL05_CD
                               WHEN 10            THEN  ITEM_LVL05_NM
                               WHEN 11            THEN  ITEM_LVL06_CD
                               WHEN 12            THEN  ITEM_LVL06_NM
                               WHEN 13            THEN  ITEM_LVL07_CD
                               WHEN 14            THEN  ITEM_LVL07_NM
                               WHEN 15            THEN  ITEM_LVL08_CD
                               WHEN 16            THEN  ITEM_LVL08_NM
                               WHEN 17            THEN  ITEM_LVL09_CD
                               WHEN 18            THEN  ITEM_LVL09_NM
                               WHEN 19            THEN  ITEM_LVL10_CD
                               WHEN 20            THEN  ITEM_LVL10_NM
							   END
        , CASE v_LAST_ACCT_LV WHEN 21            THEN  ACCOUNT_LVL01_CD
                               WHEN 22            THEN  ACCOUNT_LVL01_NM
                               WHEN 23            THEN  ACCOUNT_LVL02_CD
                               WHEN 24            THEN  ACCOUNT_LVL02_NM
                               WHEN 25            THEN  ACCOUNT_LVL03_CD
                               WHEN 26            THEN  ACCOUNT_LVL03_NM
                               WHEN 27            THEN  ACCOUNT_LVL04_CD
                               WHEN 28            THEN  ACCOUNT_LVL04_NM
                               WHEN 29            THEN  ACCOUNT_LVL05_CD
                               WHEN 30            THEN  ACCOUNT_LVL05_NM
                               WHEN 31            THEN  ACCOUNT_LVL06_CD
                               WHEN 32            THEN  ACCOUNT_LVL06_NM
                               WHEN 33            THEN  ACCOUNT_LVL07_CD
                               WHEN 34            THEN  ACCOUNT_LVL07_NM
                               WHEN 35            THEN  ACCOUNT_LVL08_CD
                               WHEN 36            THEN  ACCOUNT_LVL08_NM
                               WHEN 37            THEN  ACCOUNT_LVL09_CD
                               WHEN 38            THEN  ACCOUNT_LVL09_NM
                               WHEN 39            THEN  ACCOUNT_LVL10_CD
                               WHEN 40            THEN  ACCOUNT_LVL10_NM
							   END
		;

    p_RT_MSG := 'MSG_0003' ; --조회 되었습니다.

     EXCEPTION WHEN OTHERS THEN  -- e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_MSG := SQLERRM;
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;   	
END;
/

