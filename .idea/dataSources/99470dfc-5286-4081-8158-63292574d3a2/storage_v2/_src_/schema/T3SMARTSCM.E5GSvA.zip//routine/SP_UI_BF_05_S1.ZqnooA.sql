create PROCEDURE                  "SP_UI_BF_05_S1" (
    P_ID                    CHAR
  , P_ACCOUNT_CD            VARCHAR2
  , P_ITEM_CD               VARCHAR2
  , P_BASE_DATE             DATE
  , P_STATUS                VARCHAR2
  , P_QTY                   NUMBER
  , P_QTY_CORRECTION        NUMBER
  , P_CORRECTION_COMMENT    VARCHAR2 --CHAR(32)
  , P_USER_ID               VARCHAR2
  , P_RT_ROLLBACK_FLAG      OUT VARCHAR2
  , P_RT_MSG                OUT VARCHAR2
) 
IS
/*
    History (date / writer / comment)
    -- 2020.02.03 / kim sohee / change data type of correction comment : char(32) => nvarchar(50) for excel import 
*/
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

    P_ERR_STATUS            NUMBER := 0;
    P_ERR_MSG               VARCHAR2(4000) := '';
    V_ACCOUNT_ID            CHAR(32);
    V_ITEM_MST_ID           CHAR(32);
    V_SO_STATUS_ID          CHAR(32);
    V_ID                    CHAR(32);
    V_CORRECTION_COMMENT    VARCHAR2(32);

BEGIN
    SELECT ID
      INTO V_ACCOUNT_ID
      FROM TB_DP_ACCOUNT_MST
     WHERE ACCOUNT_CD = P_ACCOUNT_CD;

    SELECT ID
      INTO V_ITEM_MST_ID
      FROM TB_CM_ITEM_MST
     WHERE ITEM_CD = P_ITEM_CD;

    SELECT ID
      INTO V_SO_STATUS_ID
      FROM TB_CM_COMM_CONFIG 
     WHERE CONF_GRP_CD='DP_SO_STATUS'
       AND CONF_CD = P_STATUS;

-- Excel import
    IF (P_ID IS NULL) THEN
        SELECT id
          INTO V_ID
          FROM TB_CM_ACTUAL_SALES
         WHERE ITEM_MST_ID = V_ITEM_MST_ID
           AND ACCOUNT_ID = V_ITEM_MST_ID
           AND BASE_DATE = P_BASE_DATE
           AND SO_STATUS_ID = V_SO_STATUS_ID
           ;
    ELSE
        V_ID := P_ID;
    END IF;
    -- IF(LEN(RTRIM(P_CORRECTION_COMMENT)) = 0)
    -- BEGIN
    --  SET P_CORRECTION_COMMENT = NULL
    -- END
    IF (P_CORRECTION_COMMENT != 'NN') THEN
        SELECT ID
          INTO V_CORRECTION_COMMENT
          FROM TB_CM_COMM_CONFIG
         WHERE CONF_CD = P_CORRECTION_COMMENT
           AND CONF_GRP_CD = 'BF_SO_MODIFY_REASON';
    ELSE 
        V_CORRECTION_COMMENT := NULL;
    END IF;

    IF (V_CORRECTION_COMMENT IS NOT NULL AND P_QTY_CORRECTION IS NULL) THEN
        P_ERR_MSG := 'Calibration QTY is required';
        RAISE_APPLICATION_ERROR (SQLCODE, P_ERR_MSG);            
    END IF;

    UPDATE TB_CM_ACTUAL_SALES
       SET QTY_CORRECTION          = CASE WHEN ID = V_ID THEN P_QTY_CORRECTION ELSE NULL END
         , CORRECTION_COMMENT_ID   = V_CORRECTION_COMMENT
         , CORRECTION_YN           = CASE WHEN P_QTY_CORRECTION IS NOT NULL THEN 'Y' ELSE 'N' END
         , MODIFY_BY               = P_USER_ID
         , MODIFY_DTTM             = (SELECT SYSDATE FROM DUAL)
     WHERE 1=1
       AND ITEM_MST_ID = V_ITEM_MST_ID
       AND ACCOUNT_ID = V_ITEM_MST_ID
       AND BASE_DATE = P_BASE_DATE
     ;

--              MERGE TB_CM_ACTUAL_SALES TAR
--              USING ( 
--                      SELECT
--                        P_ID                     AS  ID                  
--                      , V_ACCOUNT_ID             AS  ACCOUNT_ID
--                      , V_ITEM_MST_ID            AS  ITEM_MST_ID
--                      , P_BASE_DATE              AS  BASE_DATE           
--                      , V_SO_STATUS_ID           AS  SO_STATUS_ID
--                      , P_QTY                    AS  QTY         
--                      , P_QTY_CORRECTION         AS  QTY_CORRECTION
--                      , P_CORRECTION_COMMENT     AS  CORRECTION_COMMENT_ID
--                      , P_USER_ID                AS  USER_ID
--                    ) SRC
--              ON    (TAR.ID           = SRC.ID    
--                    )
--              WHEN MATCHED THEN
--                   UPDATE 
--                     SET   TAR.QTY_CORRECTION        = SRC.QTY_CORRECTION
--                          ,TAR.CORRECTION_COMMENT_ID = SRC.CORRECTION_COMMENT_ID
--                          ,TAR.CORRECTION_YN         = 'Y'
--                          ,TAR.MODIFY_BY             = SRC.USER_ID
--                          ,TAR.MODIFY_DTTM           = GETDATE()    
--              WHEN NOT MATCHED THEN 
--                   INSERT (
--                            ID                    
--                          , ACCOUNT_ID    
--                          , ITEM_MST_ID       
--                          , BASE_DATE         
--                          , SO_STATUS_ID      
--                          , QTY               
--                          , QTY_CORRECTION        
--                          , CORRECTION_COMMENT_ID
--                          , CREATE_BY         
--                          , CREATE_DTTM
--                          ) 
--                   VALUES (
--                           (SELECT REPLACE(NEWID(),'-','') )
--                          ,SRC.ACCOUNT_ID 
--                          ,SRC.ITEM_MST_ID        
--                          ,SRC.BASE_DATE          
--                          ,SRC.SO_STATUS_ID       
--                          ,SRC.QTY                
--                          ,SRC.QTY_CORRECTION 
--                          ,SRC.CORRECTION_COMMENT_ID
--                          ,SRC.USER_ID            
--                          ,GETDATE()        
--                          ) 
--                          
--                      ;    





     P_RT_ROLLBACK_FLAG := 'true';
     P_RT_MSG := 'MSG_0001';  --저장 되었습니다.

EXCEPTION WHEN OTHERS THEN
    IF (SQLERRM = P_ERR_MSG) THEN
        P_ERR_MSG := SQLERRM;
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
    ELSE 
        RAISE_APPLICATION_ERROR(SQLCODE, SQLERRM);
--              EXEC SP_COMM_RAISE_ERR
    END IF;
END;
/

