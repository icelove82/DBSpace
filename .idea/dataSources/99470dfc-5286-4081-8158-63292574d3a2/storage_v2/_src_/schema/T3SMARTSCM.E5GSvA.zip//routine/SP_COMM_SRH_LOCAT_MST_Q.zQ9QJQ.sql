create PROCEDURE "SP_COMM_SRH_LOCAT_MST_Q" (
    pResult OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN pResult FOR
	SELECT  B.ID			AS LOCAT_MST_ID
           ,B.LOCAT_TP_ID 
           ,A.COMN_CD_NM	AS LOCAT_TP_NM
           ,B.LOCAT_LV
      FROM  TB_AD_COMN_CODE A
           ,TB_CM_LOC_MST   B
     WHERE 1=1
       AND A.ID = B.LOCAT_TP_ID
       AND B.ACTV_YN = 'Y'
     ORDER BY A.SEQ, B.LOCAT_LV;

END;

/

