create PROCEDURE                "SP_UI_DP_00_LV_CD_Q1" (
    p_LV_TP                 IN VARCHAR2	:= ''
  , p_ACCOUNT_TP            IN VARCHAR2	:= ''
  , p_LEAF_YN               IN VARCHAR2	:= ''
  , p_LV_LEAF_YN            IN VARCHAR2	:= ''
  , p_TYPE                  IN VARCHAR2 := ''
  , p_ACCOUNT_LV_YN		 	IN VARCHAR2 := ''
  , p_PARENT_SEARCH         IN VARCHAR2 := ''
  , p_NOW_LEVEL_SEARCH      IN VARCHAR2 := ''
  , pRESULT                 OUT SYS_REFCURSOR  
)
   IS 
/*
    History (date / writer / commnet)
    - 2023.01.25 / kim sohee / P_LV_TP_CD EQUAL compare
*/

BEGIN
    IF p_ACCOUNT_TP = 'ACCOUNT'
    THEN
        OPEN pRESULT          
        FOR
        SELECT A.LV_TP
             , A.ID
             , A.CD
             , A.CD_NM
          FROM (
            SELECT '1'              AS LV_TP 
				 , ' '              AS ID
				 , UPPER(p_TYPE)    AS CD
				 , UPPER(p_TYPE)    AS CD_NM
				 , 0                AS SEQ 
			  FROM dual      
             WHERE 1=1
               AND UPPER(P_TYPE) = 'ALL'
            UNION ALL 

			SELECT B.CONF_CD AS LV_TP
			     , LM.ID     AS ID
			     , LM.LV_CD  AS CD
    			 , LM.LV_NM  AS CD_NM 
    			 , LM.SEQ 
			  FROM   TB_CM_CONFIGURATION A
				   , TB_CM_COMM_CONFIG B
				   , TB_CM_LEVEL_MGMT  LM
			 WHERE A.MODULE_CD = 'DP'
			   AND A.ID = B.CONF_ID
			   AND B.CONF_GRP_CD = 'DP_LV_TP'
			   AND B.ACTV_YN = 'Y'
			   AND B.CONF_CD = p_LV_TP   -- S/I/C
			   AND B.ID = LM.LV_TP_ID 
			   AND LM.ACCOUNT_LV_YN = 'Y'   -- ACCOUNT_YN 
			   AND COALESCE(LM.DEL_YN, 'N') = 'N'
			   AND LM.ACTV_YN = 'Y'
			   AND LM.LEAF_YN LIKE   '%' || p_LEAF_YN || '%'
			   AND LM.LV_LEAF_YN LIKE   '%' || p_LV_LEAF_YN || '%'
			) A
		 ORDER BY A.LV_TP ASC, A.SEQ ASC
        ;

    ELSIF p_ACCOUNT_TP = 'SALES'
    THEN 

        OPEN pRESULT          
		FOR
		SELECT A.LV_TP
		     , A.ID
		     , A.CD
		     , A.CD_NM
		  FROM (
            SELECT '2'              AS LV_TP 
    			 , ' '              AS ID
    			 , UPPER(p_TYPE)    AS CD
    			 , UPPER(p_TYPE)    AS CD_NM
    			 , 0                AS SEQ 
			  FROM dual      
             WHERE 1=1
               AND UPPER(P_TYPE) = 'ALL'
            UNION ALL 
            SELECT B.CONF_CD    AS LV_TP
				 , LM.ID        AS ID
				 , LM.LV_CD     AS CD
				 , LM.LV_NM     AS CD_NM 
				 , LM.SEQ 
			  FROM TB_CM_CONFIGURATION A
			     , TB_CM_COMM_CONFIG B
			     , TB_CM_LEVEL_MGMT  LM
			 WHERE A.MODULE_CD = 'DP'
			   AND A.ID = B.CONF_ID
			   AND B.CONF_GRP_CD = 'DP_LV_TP'
			   AND B.ACTV_YN = 'Y'
               AND B.CONF_CD = P_LV_TP
			   --AND B.CONF_CD LIKE  '%' || p_LV_TP || '%'    -- S/I/C
			   AND B.ID = LM.LV_TP_ID 
			   AND LM.SALES_LV_YN = 'Y'   -- SALES_LV_YN 
			   AND NVL(LM.DEL_YN, 'N') = 'N'
			   AND LM.ACTV_YN = 'Y'
			   AND LM.LEAF_YN LIKE   '%' || p_LEAF_YN || '%'
			   AND LM.LV_LEAF_YN LIKE   '%' || p_LV_LEAF_YN || '%'
		  ) A
		 ORDER BY A.LV_TP ASC,A.SEQ ASC
        ;

    ELSE 
	     OPEN pRESULT          
		 FOR
		SELECT A.LV_TP
			 , A.ID
		     , A.CD
		     , A.CD_NM
		     , A.LEAF_YN
		  FROM (
			SELECT '3'              AS LV_TP 
				 , ' '              AS ID
				 , UPPER(p_TYPE)    AS CD
				 , UPPER(p_TYPE)    AS CD_NM
				 , 0                AS SEQ 
				 , ''               AS LEAF_YN
			  FROM dual      
             WHERE 1=1
               AND UPPER(P_TYPE) = 'ALL'
            UNION ALL 
			SELECT B.CONF_CD     AS LV_TP
                 , LM.ID         AS ID
                 , LM.LV_CD      AS CD
                 , LM.LV_NM      AS CD_NM 
                 , LM.SEQ 
                 , LM.LEAF_YN
			  FROM TB_CM_CONFIGURATION A
			     , TB_CM_COMM_CONFIG B
			     , TB_CM_LEVEL_MGMT  LM
			 WHERE A.MODULE_CD = 'DP'
			   AND A.ID = B.CONF_ID
			   AND B.CONF_GRP_CD = 'DP_LV_TP'
			   AND B.ACTV_YN = 'Y'
			   AND B.CONF_CD = p_LV_TP
			   AND B.ID = LM.LV_TP_ID 
			   AND COALESCE(LM.DEL_YN, 'N') = 'N'
			   AND LM.ACTV_YN = 'Y'
			   AND LM.LEAF_YN LIKE '%' || p_LEAF_YN || '%'
			   AND LM.LV_LEAF_YN LIKE '%' || p_LV_LEAF_YN || '%'
			   AND LM.ACCOUNT_LV_YN LIKE '%' || p_ACCOUNT_LV_YN || '%'
			   AND (( p_PARENT_SEARCH IS NOT NULL AND  LM.SEQ = ( SELECT LM2.SEQ -1  FROM TB_CM_LEVEL_MGMT LM2 WHERE LM2.ID = p_PARENT_SEARCH ))
					 OR
				    ( p_PARENT_SEARCH IS NULL AND COALESCE(LM.ID, '')  LIKE  '%'  )	                                        
				   )        
			   AND ((p_NOW_LEVEL_SEARCH IS NOT NULL AND  LM.ID = p_NOW_LEVEL_SEARCH)
					 OR
				    (p_NOW_LEVEL_SEARCH IS NULL AND COALESCE(LM.ID,' ')  LIKE  '%'  )	                                        
				   )        

			) A
		ORDER BY A.LV_TP ASC,A.SEQ ASC ;
    END IF;
END;
/

