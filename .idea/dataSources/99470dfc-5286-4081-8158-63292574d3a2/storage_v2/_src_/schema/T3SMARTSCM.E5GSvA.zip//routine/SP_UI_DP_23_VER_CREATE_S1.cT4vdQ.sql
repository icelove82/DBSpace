create PROCEDURE SP_UI_DP_23_VER_CREATE_S1(
     p_VER_ID           VARCHAR2
    ,p_VER_BUCKET		VARCHAR2
    ,p_VER_HORIZON		VARCHAR2
    ,p_VER_FROM_DATE    DATE
    ,p_VER_TO_DATE      DATE
    ,p_VER_DTF			VARCHAR2
    ,p_VER_DTF_DATE     DATE
    ,p_VER_STAT_BUCKET	VARCHAR2
    ,p_VER_DESCRIP      VARCHAR2
    ,p_PARTIAL_BUCKET	VARCHAR2
    ,p_PARTIAL_HORIZON	VARCHAR2
    ,p_PARTIAL_DATE		DATE
    ,p_PARTIAL_BUCKET2	VARCHAR2
    ,p_PARTIAL_HORIZON2	VARCHAR2
    ,p_PARTIAL_DATE2	DATE
    ,p_PLAN_TP			CHAR
    ,p_PRICE_TYPE		VARCHAR2
    ,p_CURRENCY_TYPE	VARCHAR2
    ,p_USER_ID			VARCHAR2
    ,p_RT_ROLLBACK_FLAG	OUT VARCHAR2
    ,p_RT_MSG           OUT VARCHAR2
) 
IS

/*****************************************************************************
Title : SP_DP_VER_CREATE_S1
최초 작성자 : 이고은
최초 생성일 : 2017.07.10
 
설명 
 - DP VERSION CREATE
 
History (수정일자 / 수정자 / 수정내용)
- 2017.07.10 / 이고은 / 최초 작성
- 2020.12.23 / 민경훈 / MSSQL -> ORACLE
*****************************************************************************/

p_ERR_STATUS    INT := 0;
p_ERR_MSG       VARCHAR2(4000):='';

BEGIN 

    --버전 DATA 저장
    INSERT INTO TB_DP_CONTROL_BOARD_VER_MST
               (ID
               ,VER_ID
               ,MODULE_ID
               ,BUKT
               ,HORIZ
               ,FROM_DATE
               ,TO_DATE
               ,DTF
               ,DTF_DATE
               ,DESCRIP
               ,CREATE_BY
               ,CREATE_DTTM
               ,VER_S_BUCKET
               ,VER_S_HORIZON
               ,VER_S_HORIZON_DATE
               ,VER_S_BUCKET2
               ,VER_S_HORIZON2
               ,VER_S_HORIZON_DATE2
               ,PLAN_TP_ID
               ,PRICE_TP_ID
               ,CURCY_TP_ID	   
               )
         VALUES
                (TO_SINGLE_BYTE(SYS_GUID())
               ,p_VER_ID
               ,'DP'
               ,p_VER_BUCKET
               ,p_VER_HORIZON
               ,p_VER_FROM_DATE
               ,p_VER_TO_DATE
               ,p_VER_DTF
               ,p_VER_DTF_DATE
               ,p_VER_DESCRIP
               ,p_USER_ID
               ,SYSDATE
               ,p_PARTIAL_BUCKET
               ,p_PARTIAL_HORIZON      
               ,p_PARTIAL_DATE  
               ,p_PARTIAL_BUCKET2
               ,p_PARTIAL_HORIZON2     
               ,p_PARTIAL_DATE2  
               ,p_PLAN_TP
               ,p_PRICE_TYPE
               ,p_CURRENCY_TYPE
               )
    ;    
	   p_RT_ROLLBACK_FLAG := 'true';
	   p_RT_MSG := 'MSG_0001' ; --저장 되었습니다.

    EXCEPTION WHEN OTHERS THEN  --  e_products_invalid    
      IF(SQLCODE = -20001)
      THEN
          P_RT_MSG := sqlerrm;   
          p_RT_ROLLBACK_FLAG :='false';
      ELSE
        --SP_COMM_RAISE_ERR();              
        RAISE;
      END IF; 


END;
/

