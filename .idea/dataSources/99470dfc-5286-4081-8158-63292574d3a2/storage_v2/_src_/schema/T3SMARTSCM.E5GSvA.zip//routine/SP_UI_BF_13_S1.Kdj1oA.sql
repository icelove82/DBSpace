create PROCEDURE                "SP_UI_BF_13_S1" (
      P_ID                  CHAR
    , P_ACCOUNT_CD          VARCHAR2
    , P_ITEM_CD             VARCHAR2
    , P_ACTIVE              VARCHAR2
    , P_USER_ID             VARCHAR2
    , P_FACTOR_SET_CD       VARCHAR2
    , P_RT_ROLLBACK_FLAG    OUT VARCHAR2
    , P_RT_MSG              OUT VARCHAR2
)  
IS
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
    V_ID            CHAR(32);
    P_ERR_STATUS    NUMBER          := 0;
    P_ERR_MSG       VARCHAR2(4000)  :='';
    V_ITEM_CNT      INT; 
    V_ACCT_CNT      INT; 

BEGIN
    
    SELECT COUNT(*)
      INTO P_ERR_STATUS
      FROM TB_BF_ITEM_ACCOUNT_MODEL_MAP
     WHERE (SALES_LV_CD = P_ACCOUNT_CD OR ACCOUNT_CD = P_ACCOUNT_CD)
       AND (ITEM_LV_CD  = P_ITEM_CD    OR ITEM_CD    = P_ITEM_CD)
       AND ID != P_ID
    ;
   
    IF P_ERR_STATUS > 0 THEN
        P_ERR_MSG := 'The Item/Account (lvl) pair already exists.';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;
    
    IF (P_ID IS NULL) THEN
        SELECT ID INTO V_ID
          FROM TB_BF_ITEM_ACCOUNT_MODEL_MAP
         WHERE ACCOUNT_CD = P_ACCOUNT_CD
           AND ITEM_CD = P_ITEM_CD;
    ELSE
        V_ID := P_ID;
    END IF;

    SELECT COUNT(DESCENDANT_CD)
      INTO V_ACCT_CNT
      FROM TB_DPD_SALES_HIER_CLOSURE
     WHERE LEAF_YN = 'Y'
       AND DEPTH_NUM = 0
       AND DESCENDANT_CD = P_ACCOUNT_CD;

    SELECT COUNT(DESCENDANT_CD)
      INTO V_ITEM_CNT
      FROM TB_DPD_ITEM_HIER_CLOSURE
     WHERE LEAF_YN = 'Y'
       AND DEPTH_NUM = 0
       AND DESCENDANT_CD = P_ITEM_CD;

    IF (V_ACCT_CNT > 0 AND V_ITEM_CNT > 0) THEN
        MERGE INTO TB_BF_ITEM_ACCOUNT_MODEL_MAP TAR
        USING ( 
                SELECT  V_ID           AS ID   
                      , P_ACCOUNT_CD   AS ACCOUNT_CD
                      , P_ITEM_CD      AS ITEM_CD
                      , NVL(P_ACTIVE,'N') AS ACTV_YN
                      , P_FACTOR_SET_CD AS FACTOR_SET_CD
                      , P_USER_ID      AS USER_ID
                FROM DUAL
              ) SRC
        ON    (TAR.ID = SRC.ID)
        WHEN MATCHED THEN
             UPDATE 
               SET   TAR.ACCOUNT_CD     = SRC.ACCOUNT_CD
                    ,TAR.ITEM_CD        = SRC.ITEM_CD
                    ,TAR.ACTV_YN        = SRC.ACTV_YN
                    ,TAR.FACTOR_SET_CD  = SRC.FACTOR_SET_CD
                    ,TAR.MODIFY_BY      = SRC.USER_ID
                    ,TAR.MODIFY_DTTM    = SYSDATE
        WHEN NOT MATCHED THEN 
             INSERT (
                      ID        
                    , ACCOUNT_CD
                    , ITEM_CD
                    , ACTV_YN
                    , FACTOR_SET_CD
                    , CREATE_BY 
                    , CREATE_DTTM
                    ) 
             VALUES (
                     RAWTOHEX(SYS_GUID()) 
                    ,SRC.ACCOUNT_CD
                    ,SRC.ITEM_CD
                    ,SRC.ACTV_YN
                    ,SRC.FACTOR_SET_CD
                    ,SRC.USER_ID
                    ,SYSDATE
                    ) 
        ;   
    ELSIF (V_ACCT_CNT = 0 AND V_ITEM_CNT > 0) THEN
        MERGE INTO TB_BF_ITEM_ACCOUNT_MODEL_MAP TAR
        USING ( 
                SELECT  V_ID           AS ID   
                      , P_ACCOUNT_CD   AS ACCOUNT_CD
                      , P_ITEM_CD      AS ITEM_CD
                      , NVL(P_ACTIVE,'N') AS ACTV_YN
                      , P_FACTOR_SET_CD AS FACTOR_SET_CD
                      , P_USER_ID      AS USER_ID
                FROM DUAL
              ) SRC
        ON    (TAR.ID = SRC.ID)
        WHEN MATCHED THEN
             UPDATE 
               SET   TAR.ACCOUNT_CD     = NULL
                    ,TAR.SALES_LV_CD    = SRC.ACCOUNT_CD
                    ,TAR.ITEM_CD        = SRC.ITEM_CD
                    ,TAR.ACTV_YN        = SRC.ACTV_YN
                    ,TAR.FACTOR_SET_CD  = SRC.FACTOR_SET_CD
                    ,TAR.MODIFY_BY      = SRC.USER_ID
                    ,TAR.MODIFY_DTTM    = SYSDATE
        WHEN NOT MATCHED THEN 
             INSERT (
                      ID        
                    , SALES_LV_CD
                    , ITEM_CD
                    , ACTV_YN
                    , FACTOR_SET_CD
                    , CREATE_BY 
                    , CREATE_DTTM
                    ) 
             VALUES (
                     RAWTOHEX(SYS_GUID())
                    ,SRC.ACCOUNT_CD
                    ,SRC.ITEM_CD
                    ,SRC.ACTV_YN
                    ,SRC.FACTOR_SET_CD
                    ,SRC.USER_ID
                    ,SYSDATE
                    ) 
        ;   
    ELSIF(V_ACCT_CNT > 0 AND V_ITEM_CNT = 0) THEN
        MERGE INTO TB_BF_ITEM_ACCOUNT_MODEL_MAP TAR
        USING ( 
                SELECT  V_ID           AS ID   
                      , P_ACCOUNT_CD   AS ACCOUNT_CD
                      , P_ITEM_CD      AS ITEM_CD
                      , NVL(P_ACTIVE,'N') AS ACTV_YN
                      , P_FACTOR_SET_CD AS FACTOR_SET_CD
                      , P_USER_ID      AS USER_ID
                FROM DUAL
              ) SRC
        ON    (TAR.ID = SRC.ID)
        WHEN MATCHED THEN
             UPDATE 
               SET   TAR.ACCOUNT_CD     = SRC.ACCOUNT_CD
                    ,TAR.ITEM_CD        = NULL
                    ,TAR.ITEM_LV_CD     = SRC.ITEM_CD
                    ,TAR.ACTV_YN        = SRC.ACTV_YN
                    ,TAR.FACTOR_SET_CD  = SRC.FACTOR_SET_CD
                    ,TAR.MODIFY_BY      = SRC.USER_ID
                    ,TAR.MODIFY_DTTM    = SYSDATE
        WHEN NOT MATCHED THEN 
             INSERT (
                      ID        
                    , ACCOUNT_CD
                    , ITEM_LV_CD
                    , ACTV_YN
                    , FACTOR_SET_CD
                    , CREATE_BY 
                    , CREATE_DTTM
                    ) 
             VALUES (
                     RAWTOHEX(SYS_GUID())
                    ,SRC.ACCOUNT_CD
                    ,SRC.ITEM_CD
                    ,SRC.ACTV_YN
                    ,SRC.FACTOR_SET_CD
                    ,SRC.USER_ID
                    ,SYSDATE
                    ) 
        ;   
    ELSE
        MERGE INTO TB_BF_ITEM_ACCOUNT_MODEL_MAP TAR
        USING ( 
                SELECT  V_ID           AS ID   
                      , P_ACCOUNT_CD   AS ACCOUNT_CD
                      , P_ITEM_CD      AS ITEM_CD
                      , NVL(P_ACTIVE,'N') AS ACTV_YN
                      , P_FACTOR_SET_CD AS FACTOR_SET_CD
                      , P_USER_ID      AS USER_ID
                FROM DUAL
              ) SRC
        ON    (TAR.ID = SRC.ID)
        WHEN MATCHED THEN
             UPDATE 
               SET   TAR.ACCOUNT_CD     = NULL
                    ,TAR.ITEM_CD        = NULL
                    ,TAR.SALES_LV_CD    = SRC.ACCOUNT_CD
                    ,TAR.ITEM_LV_CD     = SRC.ITEM_CD
                    ,TAR.ACTV_YN        = SRC.ACTV_YN
                    ,TAR.FACTOR_SET_CD  = SRC.FACTOR_SET_CD
                    ,TAR.MODIFY_BY      = SRC.USER_ID
                    ,TAR.MODIFY_DTTM    = SYSDATE
        WHEN NOT MATCHED THEN 
             INSERT (
                      ID        
                    , SALES_LV_CD
                    , ITEM_LV_CD
                    , ACTV_YN
                    , FACTOR_SET_CD
                    , CREATE_BY 
                    , CREATE_DTTM
                    ) 
             VALUES (
                     RAWTOHEX(SYS_GUID())
                    ,SRC.ACCOUNT_CD
                    ,SRC.ITEM_CD
                    ,SRC.ACTV_YN
                    ,SRC.FACTOR_SET_CD
                    ,SRC.USER_ID
                    ,SYSDATE
                    ) 
        ;
    END IF;

    P_RT_ROLLBACK_FLAG  := 'true';
    P_RT_MSG            := 'MSG_0001';  --저장 되었습니다.

EXCEPTION WHEN OTHERS THEN
    IF (SQLCODE = -20001) THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
    ELSE
        RAISE;
--              EXEC SP_COMM_RAISE_ERR
    END IF;
END;
/

