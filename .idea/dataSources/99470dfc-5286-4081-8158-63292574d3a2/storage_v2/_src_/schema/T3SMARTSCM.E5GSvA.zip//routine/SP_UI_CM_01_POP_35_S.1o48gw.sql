create PROCEDURE        "SP_UI_CM_01_POP_35_S" (
	 P_ID                   IN VARCHAR2 := ''
    ,P_LIMIT_FNC_TIME	    IN NUMBER := ''
    ,P_TIME_UOM_NM			IN CHAR := ''
    ,P_ACTV_YN              IN VARCHAR2 := ''
    ,P_USER_ID	            IN VARCHAR2 := ''
    ,P_WRK_TYPE	            IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG     OUT VARCHAR2 
    ,P_RT_MSG               OUT VARCHAR2
    
)
IS
    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';
    P_CONF_ID VARCHAR2(32) := '';

BEGIN
IF P_WRK_TYPE = 'SAVE'
THEN

    SELECT ID INTO P_CONF_ID FROM TB_CM_CONFIGURATION WHERE CONF_KEY = '035';

        P_ERR_MSG := 'MSG_0008'; -- '?????？?？？？ ?? ?????？？ '
            IF P_LIMIT_FNC_TIME < 0  THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;

        P_ERR_MSG := 'MSG_0006'; --'？?? ?？？???？?？μ？? ?？？??？？'
            IF NVL(P_LIMIT_FNC_TIME,'') ='' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
            END IF;

    MERGE INTO TB_CM_MAT_CONST_CHG_PERIOD B 
			USING (SELECT P_ID AS ID FROM DUAL) A
					ON     (B.ID = P_ID)

			WHEN MATCHED THEN

				UPDATE 
				   SET B.ACTV_YN			= P_ACTV_YN
					 , B.LIMIT_FNC_TIME		= P_LIMIT_FNC_TIME
					 , B.UOM_ID				= P_TIME_UOM_NM
					 , MODIFY_BY			= P_USER_ID
					 , MODIFY_DTTM			= SYSDATE;
                     
        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';  --???？？????？？
        
END IF;

        EXCEPTION
        WHEN OTHERS THEN
            P_RT_ROLLBACK_FLAG := 'false';
            IF(SQLCODE = -20012)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF; 

END;

/

