create PROCEDURE "SP_UI_CM_15_Q7" (
    P_PLAN_POLICY_ID        IN VARCHAR2 := '',
    P_PLAN_POLICY_ITEM_ID   IN VARCHAR2 := '', /* M00210000 [Confirmed Planning Level] , M00230000 [Infinite Planning Level] */
    P_LOC_MST_ID            IN VARCHAR2 := '',
    PRESULT                 OUT SYS_REFCURSOR
)
IS
    v_PLAN_POLICY_VAL_ID CHAR(32) := NULL;
    
BEGIN   
     SELECT A.ID INTO v_PLAN_POLICY_VAL_ID
     FROM TB_CM_PLAN_POLICY_VALUE A
     INNER JOIN
          TB_CM_PLAN_POLICY_MST B
     ON A.PLAN_POLICY_MST_ID = B.ID
     AND A.PLAN_POLICY_MGMT_ID = P_PLAN_POLICY_ID
     AND B.PLAN_POLICY_ITEM_ID = P_PLAN_POLICY_ITEM_ID;
     
     OPEN PRESULT FOR 
     SELECT  C.ID
            ,CASE WHEN C.PLAN_POLICY_VAL_ID IS NULL THEN v_PLAN_POLICY_VAL_ID ELSE C.PLAN_POLICY_VAL_ID END AS PLAN_POLICY_VAL_ID
            ,A.ID           AS VAL_05
            ,B.ID           AS VAL_04
			,C.GRID_VAL_03	AS VAL_06
            ,A.LOCAT_CD
            ,A.LOCAT_NM
            ,CASE WHEN C.ACTV_YN IS NULL THEN 'N' ELSE C.ACTV_YN END AS ACTV_YN
    FROM    TB_CM_LOC_DTL A
            INNER JOIN
            TB_CM_LOC_MST B
            ON A.LOCAT_MST_ID = B.ID
            LEFT OUTER JOIN
            (
            SELECT C.ID, C.GRID_VAL_01, C.GRID_VAL_02, C.GRID_VAL_03, D.ID AS PLAN_POLICY_VAL_ID, C.ACTV_YN
            FROM    TB_CM_GRID_VALUE C
                    INNER JOIN
                    TB_CM_PLAN_POLICY_VALUE D
                    ON D.ID = C.PLAN_POLICY_VAL_ID
                    INNER JOIN
                    TB_CM_PLAN_POLICY_MGMT E
                    ON E.ID = D.PLAN_POLICY_MGMT_ID
                    AND E.ID = P_PLAN_POLICY_ID 
                    INNER JOIN
                    TB_CM_PLAN_POLICY_MST F
                    ON F.ID = D.PLAN_POLICY_MST_ID
                    AND F.PLAN_POLICY_ITEM_ID = P_PLAN_POLICY_ITEM_ID
            ) C
            ON C.GRID_VAL_01 = B.ID AND C.GRID_VAL_02 = A.ID
    WHERE 1=1
    AND B.ID = P_LOC_MST_ID;

END;
/

