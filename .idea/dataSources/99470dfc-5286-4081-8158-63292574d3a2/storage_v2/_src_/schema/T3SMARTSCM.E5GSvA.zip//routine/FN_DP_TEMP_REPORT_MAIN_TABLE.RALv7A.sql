create FUNCTION  FN_DP_TEMP_REPORT_MAIN_TABLE
(
		 P_BUCKET			CHAR := ''
		,P_STRT_DATE	    DATE := ''
		,P_END_DATE	  	    DATE := ''
        --,P_VER_ID           CHAR := ''  -- ENTRY KEY
        --,P_AUTH_TP_ID       CHAR := ''  -- ENTRY KEY
        ,P_ITEM_CD          VARCHAR2 :=''
        ,P_ACCT_CD          VARCHAR2 :=''
        ,P_ITEM_LV_CD       VARCHAR2 :=''
        ,P_ACCT_LV_CD       VARCHAR2 :=''
        ,V_SEARCH_LV_SEQ    VARCHAR2 :=''
        ,V_SEARCH_LV_SEQ_02 VARCHAR2 :=''
        ,P_PLAN_TP_ID       CHAR:=''
		,P_USER_ID		    VARCHAR2 := 'admin' /* ？α？？？ USER (？？？) */
)
RETURN DP_TEMP_REPORT_MAIN_TABLE IS
C_DP_TEMP_REPORT_MAIN_TABLE DP_TEMP_REPORT_MAIN_TABLE := DP_TEMP_REPORT_MAIN_TABLE();
      -- FN_DP_TEMP_REPORT_MAIN_TABLE :
      -- ITEM_LV(ITEM ALL, ..., ITEM_CD) | ACCOUNT_LV(GOC, ..., ACCOUNT_CD) | STRT_DATE | END_DATE (BUCKET？？ DATE)
    CURSOR C_DATA_IMPORT IS
    SELECT TP_DP_TEMP_REPORT_MAIN_TABLE(            
                       ITEM_LVL01_ID 			  =>   IH.LVL01_ID
                    ,  ITEM_LVL01_CD 			  =>   IH.LVL01_CD
                    ,  ITEM_LVL01_NM 			  =>   IH.LVL01_NM
                    ,  ITEM_LVL02_ID 			  =>   IH.LVL02_ID
                    ,  ITEM_LVL02_CD 			  =>   IH.LVL02_CD
                    ,  ITEM_LVL02_NM 			  =>   IH.LVL02_NM
                    ,  ITEM_LVL03_ID 			  =>   IH.LVL03_ID
                    ,  ITEM_LVL03_CD 			  =>   IH.LVL03_CD
                    ,  ITEM_LVL03_NM 			  =>   IH.LVL03_NM
                    ,  ITEM_LVL04_ID 			  =>   IH.LVL04_ID
                    ,  ITEM_LVL04_CD 			  =>   IH.LVL04_CD
                    ,  ITEM_LVL04_NM 			  =>   IH.LVL04_NM
                    ,  ITEM_LVL05_ID 			  =>   IH.LVL05_ID
                    ,  ITEM_LVL05_CD 			  =>   IH.LVL05_CD
                    ,  ITEM_LVL05_NM 			  =>   IH.LVL05_NM
                    ,  ITEM_LVL06_ID 			  =>   IH.LVL06_ID
                    ,  ITEM_LVL06_CD 			  =>   IH.LVL06_CD
                    ,  ITEM_LVL06_NM 			  =>   IH.LVL06_NM
                    ,  ITEM_LVL07_ID 			  =>   IH.LVL07_ID
                    ,  ITEM_LVL07_CD 			  =>   IH.LVL07_CD
                    ,  ITEM_LVL07_NM 			  =>   IH.LVL07_NM
                    ,  ITEM_LVL08_ID 			  =>   IH.LVL08_ID
                    ,  ITEM_LVL08_CD 			  =>   IH.LVL08_CD
                    ,  ITEM_LVL08_NM 			  =>   IH.LVL08_NM
                    ,  ITEM_LVL09_ID 			  =>   IH.LVL09_ID
                    ,  ITEM_LVL09_CD 			  =>   IH.LVL09_CD
                    ,  ITEM_LVL09_NM 			  =>   IH.LVL09_NM
                    ,  ITEM_LVL10_ID 			  =>   IH.LVL10_ID
                    ,  ITEM_LVL10_CD 			  =>   IH.LVL10_CD
                    ,  ITEM_LVL10_NM 			  =>   IH.LVL10_NM
                    ,  ITEM_ID 					  =>   IH.ITEM_ID
                    ,  ITEM_CD 					  =>   IH.ITEM_CD
                    ,  ITEM_NM  				  =>   IH.ITEM_NM 
                    ,  ACCOUNT_LVL01_ID 		  =>   AH.LVL01_ID
                    ,  ACCOUNT_LVL01_CD 		  =>   AH.LVL01_CD
                    ,  ACCOUNT_LVL01_NM 		  =>   AH.LVL01_NM
                    ,  ACCOUNT_LVL02_ID 		  =>   AH.LVL02_ID
                    ,  ACCOUNT_LVL02_CD 		  =>   AH.LVL02_CD
                    ,  ACCOUNT_LVL02_NM 		  =>   AH.LVL02_NM
                    ,  ACCOUNT_LVL03_ID 		  =>   AH.LVL03_ID
                    ,  ACCOUNT_LVL03_CD 		  =>   AH.LVL03_CD
                    ,  ACCOUNT_LVL03_NM 		  =>   AH.LVL03_NM
                    ,  ACCOUNT_LVL04_ID 		  =>   AH.LVL04_ID
                    ,  ACCOUNT_LVL04_CD 		  =>   AH.LVL04_CD
                    ,  ACCOUNT_LVL04_NM 		  =>   AH.LVL04_NM
                    ,  ACCOUNT_LVL05_ID 		  =>   AH.LVL05_ID
                    ,  ACCOUNT_LVL05_CD 		  =>   AH.LVL05_CD
                    ,  ACCOUNT_LVL05_NM 		  =>   AH.LVL05_NM
                    ,  ACCOUNT_LVL06_ID 		  =>   AH.LVL06_ID
                    ,  ACCOUNT_LVL06_CD 		  =>   AH.LVL06_CD
                    ,  ACCOUNT_LVL06_NM 		  =>   AH.LVL06_NM
                    ,  ACCOUNT_LVL07_ID 		  =>   AH.LVL07_ID
                    ,  ACCOUNT_LVL07_CD 		  =>   AH.LVL07_CD
                    ,  ACCOUNT_LVL07_NM 		  =>   AH.LVL07_NM
                    ,  ACCOUNT_LVL08_ID 		  =>   AH.LVL08_ID
                    ,  ACCOUNT_LVL08_CD 		  =>   AH.LVL08_CD
                    ,  ACCOUNT_LVL08_NM 		  =>   AH.LVL08_NM
                    ,  ACCOUNT_LVL09_ID 		  =>   AH.LVL09_ID
                    ,  ACCOUNT_LVL09_CD 		  =>   AH.LVL09_CD
                    ,  ACCOUNT_LVL09_NM 		  =>   AH.LVL09_NM
                    ,  ACCOUNT_LVL10_ID 		  =>   AH.LVL10_ID
                    ,  ACCOUNT_LVL10_CD 		  =>   AH.LVL10_CD
                    ,  ACCOUNT_LVL10_NM 		  =>   AH.LVL10_NM
                    ,  ACCOUNT_ID 				  =>   AH.ACCOUNT_ID
                    ,  ACCOUNT_CD 				  =>   AH.ACCOUNT_CD
                    ,  ACCOUNT_NM 				  =>   AH.ACCOUNT_NM
                    ,  BUCKET_START_DATE		  =>   CA.BUCKET_START_DATE
					,  BUCKET_END_DATE 			  =>   CA.BUCKET_END_DATE
                     )
                FROM (
                            SELECT DO.ITEM_MST_ID ,DO.ACCOUNT_ID 
                              FROM TB_DP_ENTRY_HISTORY DO 
                             WHERE 1=1  
                               AND BASE_DATE BETWEEN P_STRT_DATE AND P_END_DATE
							   AND PLAN_TP_ID = P_PLAN_TP_ID
                          GROUP BY DO.ITEM_MST_ID ,DO.ACCOUNT_ID 
                       ) DO
                      INNER JOIN -- FN_DP_TEMP_CAL : ？？？？？？？ CALENDAR ？？？？ ？？？？？？？？ ？？？
                      TABLE (FN_DP_TEMP_CAL(P_STRT_DATE, P_END_DATE, P_BUCKET)) CA ON(1=1)
                      INNER JOIN
                      TB_DPD_ITEM_HIERACHY2 IH                                  
                 ON   IH.ITEM_ID = DO.ITEM_MST_ID
                      INNER JOIN
                      TB_DPD_ACCOUNT_HIERACHY2 AH
                 ON   AH.ACCOUNT_ID = DO.ACCOUNT_ID                    
                 WHERE   1=1      -- ( ) [ ]
                  AND  (  REGEXP_LIKE (UPPER(AH.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                      OR p_ACCT_CD IS NULL
                     )
                   AND  ( REGEXP_LIKE (UPPER(IH.ITEM_CD),    REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                      OR P_ITEM_CD IS NULL
                      )                  
                      
                 AND ( P_ITEM_LV_CD = 
                     CASE WHEN V_SEARCH_LV_SEQ = 1  THEN  IH.LVL01_CD
                          WHEN V_SEARCH_LV_SEQ = 2  THEN  IH.LVL02_CD		    
                          WHEN V_SEARCH_LV_SEQ = 3  THEN  IH.LVL03_CD      
                          WHEN V_SEARCH_LV_SEQ = 4  THEN  IH.LVL04_CD      
                          WHEN V_SEARCH_LV_SEQ = 5  THEN  IH.LVL05_CD	     
                          WHEN V_SEARCH_LV_SEQ = 6  THEN  IH.LVL06_CD      
                          WHEN V_SEARCH_LV_SEQ = 7  THEN  IH.LVL07_CD      
                          WHEN V_SEARCH_LV_SEQ = 8  THEN  IH.LVL08_CD      
                          WHEN V_SEARCH_LV_SEQ = 9  THEN  IH.LVL09_CD      
                          WHEN V_SEARCH_LV_SEQ = 10 THEN  IH.LVL10_CD      
                          ELSE NULL END
                    OR P_ITEM_LV_CD IS NULL
                 )
                 AND ( P_ACCT_LV_CD =  
                         CASE WHEN V_SEARCH_LV_SEQ_02 = 1  THEN  AH.LVL01_CD		    
                              WHEN V_SEARCH_LV_SEQ_02 = 2  THEN  AH.LVL02_CD		    
                              WHEN V_SEARCH_LV_SEQ_02 = 3  THEN  AH.LVL03_CD      
                              WHEN V_SEARCH_LV_SEQ_02 = 4  THEN  AH.LVL04_CD      
                              WHEN V_SEARCH_LV_SEQ_02 = 5  THEN  AH.LVL05_CD	     
                              WHEN V_SEARCH_LV_SEQ_02 = 6  THEN  AH.LVL06_CD      
                              WHEN V_SEARCH_LV_SEQ_02 = 7  THEN  AH.LVL07_CD      
                              WHEN V_SEARCH_LV_SEQ_02 = 8  THEN  AH.LVL08_CD      
                              WHEN V_SEARCH_LV_SEQ_02 = 9  THEN  AH.LVL09_CD       
                              WHEN V_SEARCH_LV_SEQ_02 = 10 THEN  AH.LVL10_CD      
                              ELSE NULL END
                    OR P_ACCT_LV_CD IS NULL
                 )                     
                   ;
BEGIN 
	OPEN C_DATA_IMPORT;
	FETCH C_DATA_IMPORT BULK COLLECT INTO C_DP_TEMP_REPORT_MAIN_TABLE;
	CLOSE C_DATA_IMPORT;
    RETURN C_DP_TEMP_REPORT_MAIN_TABLE;

END;
/

