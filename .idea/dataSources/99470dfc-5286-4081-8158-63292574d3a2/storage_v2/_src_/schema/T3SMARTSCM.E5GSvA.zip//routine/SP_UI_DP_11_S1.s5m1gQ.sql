create PROCEDURE                SP_UI_DP_11_S1 (
                                        p_ID                  IN VARCHAR2     := ''         
                                      ,p_ACCOUNT_CD          IN VARCHAR      := ''         
									  ,p_ACCOUNT_NM          IN VARCHAR      := ''         
									  ,p_PARENT_SALES_LV_ID  IN VARCHAR2     := ''  
									  ,p_PARENT_SALES_LV_ID_AD1 IN VARCHAR2     := ''      
									  ,p_PARENT_SALES_LV_ID_AD2 IN VARCHAR2     := ''      
									  ,p_PARENT_SALES_LV_ID_AD3 IN VARCHAR2     := ''                                            
									  ,p_CURCY_CD_ID         IN VARCHAR2     := ''      
									  ,p_COUNTRY_ID          IN VARCHAR2     := ''      
									  ,p_CHANNEL_ID          IN VARCHAR2     := ''      
									  ,p_SOLD_TO_ID          IN VARCHAR2     := ''      
									  ,p_SHIP_TO_ID          IN VARCHAR2     := ''      
									  ,p_BILL_TO_ID          IN VARCHAR2     := ''      
									  ,p_INCOTERMS_ID        IN VARCHAR2     := ''      
									  ,p_SRP_YN              IN CHAR         := ''      
									  ,p_VMI_YN              IN CHAR         := ''      
									  ,p_DIRECT_SHPP_YN  IN CHAR         := ''      
									  ,p_ACTV_YN             IN CHAR         := ''
									  ,p_PRIORT             IN INTEGER         := 0
									  ,p_ATTR_01             IN VARCHAR2     := '' 
			                          ,p_ATTR_02			 IN  VARCHAR2    := ''
			                          ,p_ATTR_03			 IN  VARCHAR2    := ''
			                          ,p_ATTR_04			 IN  VARCHAR2    := ''
			                          ,p_ATTR_05			 IN  VARCHAR2    := ''
			                          ,p_ATTR_06			 IN  VARCHAR2    := ''
			                          ,p_ATTR_07			 IN  VARCHAR2    := ''
			                          ,p_ATTR_08			 IN  VARCHAR2    := ''
			                          ,p_ATTR_09			 IN  VARCHAR2    := ''
			                          ,p_ATTR_10			 IN  VARCHAR2    := ''
			                          ,p_ATTR_11			 IN  VARCHAR2    := ''
			                          ,p_ATTR_12			 IN  VARCHAR2    := ''
			                          ,p_ATTR_13			 IN  VARCHAR2    := ''
			                          ,p_ATTR_14			 IN  VARCHAR2    := ''
			                          ,p_ATTR_15			 IN  VARCHAR2    := ''
			                          ,p_ATTR_16			 IN  VARCHAR2    := ''
			                          ,p_ATTR_17			 IN  VARCHAR2    := ''
			                          ,p_ATTR_18			 IN  VARCHAR2    := ''
			                          ,p_ATTR_19			 IN  VARCHAR2    := ''
			                          ,p_ATTR_20			 IN  VARCHAR2    := ''
									  ,p_DEL_YN              IN CHAR         := ''      
									  ,p_USER_ID             IN VARCHAR2     := ''    
									  ,P_RT_ROLLBACK_FLAG  OUT VARCHAR2   
									  ,P_RT_MSG            OUT VARCHAR2 
									    
				                   ) 
IS
	    P_ERR_STATUS INT := 0;
        P_ERR_MSG VARCHAR2(4000) :='';
        V_ENTRY_COUNT INT := 0;
        V_ACCT_ID   CHAR(32);
BEGIN
/*********************************************************************************************************************

    -- History ( date / writer / comment)
    -- 2021.02.26 / kimsohee / code re-define about entry mapping data 
*********************************************************************************************************************/
P_RT_ROLLBACK_FLAG := 'true';
-- IF (p_SRP_YN				= 't' OR p_SRP_YN				= '1' OR p_SRP_YN				= 'Y') SET p_SRP_YN				= 'Y' ELSE SET p_SRP_YN				='N'
-- IF (p_VMI_YN				= 't' OR p_VMI_YN				= '1' OR p_VMI_YN				= 'Y') SET p_VMI_YN				= 'Y' ELSE SET p_VMI_YN				='N'
-- IF (p_DIRECT_SHPP_YN 	= 't' OR p_DIRECT_SHPP_YN 	= '1' OR p_DIRECT_SHPP_YN 	= 'Y') SET p_DIRECT_SHPP_YN 	= 'Y' ELSE SET p_DIRECT_SHPP_YN 	='N'
-- IF (p_ACTV_YN   			= 't' OR p_ACTV_YN   			= '1' OR p_ACTV_YN   			= 'Y') SET p_ACTV_YN   			= 'Y' ELSE SET p_ACTV_YN   			='N'
-- IF (p_DEL_YN          		= 't' OR p_DEL_YN          	= '1' OR p_DEL_YN          	= 'Y') SET p_DEL_YN          		= 'Y' ELSE SET p_DEL_YN          		='N'

		IF(p_PARENT_SALES_LV_ID IS NULL)
		THEN
		   P_ERR_MSG := 'MSG_5046';
		   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);			
		END IF;
--		IF(EXISTS(SELECT * FROM TB_DP_ACCOUNT_MST WHERE ACCOUNT_CD = p_ACCOUNT_CD AND ID != P_ID))
--		BEGIN
--		   P_ERR_MSG := 'MSG_5046' 
--		   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);			
--		END

        SELECT COUNT(*) INTO P_ERR_STATUS
          FROM TB_DP_ACCOUNT_MST
         WHERE 1=1
           AND ACCOUNT_CD = P_ACCOUNT_CD
           AND ID != P_ID;
        IF (P_ERR_STATUS >0)
            THEN
 		   P_ERR_MSG := 'MSG_0013' ;
		   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);	           
        END IF;

        V_ACCT_ID := COALESCE(P_ID, TO_SINGLE_BYTE(SYS_GUID()));

				MERGE INTO TB_DP_ACCOUNT_MST TGT
				USING ( 
						SELECT   p_ID                  AS  ID                         
                                ,p_ACCOUNT_CD          AS  ACCOUNT_CD                 
								,p_ACCOUNT_NM          AS  ACCOUNT_NM                 
								,p_PARENT_SALES_LV_ID  AS  PARENT_SALES_LV_ID      
								,p_PARENT_SALES_LV_ID_AD1  AS  PARENT_SALES_LV_ID_AD1      
								,p_PARENT_SALES_LV_ID_AD2  AS  PARENT_SALES_LV_ID_AD2      
								,p_PARENT_SALES_LV_ID_AD3  AS  PARENT_SALES_LV_ID_AD3      
								,p_CURCY_CD_ID         AS  CURCY_CD_ID             
								,p_COUNTRY_ID          AS  COUNTRY_ID              
								,p_CHANNEL_ID          AS  CHANNEL_ID              
								,p_SOLD_TO_ID          AS  SOLD_TO_ID              
								,p_SHIP_TO_ID          AS  SHIP_TO_ID             
								,p_BILL_TO_ID          AS  BILL_TO_ID             
								,p_INCOTERMS_ID        AS  INCOTERMS_ID           
								,p_SRP_YN              AS  SRP_YN                 
								,p_VMI_YN              AS  VMI_YN                 
								,p_DIRECT_SHPP_YN  AS  DIRECT_SHPP_YN     
								,p_ACTV_YN             AS  ACTV_YN
								,p_PRIORT              AS PRIORT
								,p_ATTR_01             AS  ATTR_01            
			                    ,p_ATTR_02			  	AS  ATTR_02			  
			                    ,p_ATTR_03			  	AS  ATTR_03			  
			                    ,p_ATTR_04			  	AS  ATTR_04			  
			                    ,p_ATTR_05			  	AS  ATTR_05			  
			                    ,p_ATTR_06			  	AS  ATTR_06			  
			                    ,p_ATTR_07			  	AS  ATTR_07			  
			                    ,p_ATTR_08			  	AS  ATTR_08			  
			                    ,p_ATTR_09			  	AS  ATTR_09			  
			                    ,p_ATTR_10			  	AS  ATTR_10			  
			                    ,p_ATTR_11			  	AS  ATTR_11			  
			                    ,p_ATTR_12			  	AS  ATTR_12			  
			                    ,p_ATTR_13			  	AS  ATTR_13			  
			                    ,p_ATTR_14			  	AS  ATTR_14			  
			                    ,p_ATTR_15			  	AS  ATTR_15			  
			                    ,p_ATTR_16			  	AS  ATTR_16			  
			                    ,p_ATTR_17			  	AS  ATTR_17			  
			                    ,p_ATTR_18			  	AS  ATTR_18			  
			                    ,p_ATTR_19			  	AS  ATTR_19			  
			                    ,p_ATTR_20			  	AS  ATTR_20			  
								,p_DEL_YN              AS  DEL_YN                 
								,p_USER_ID             AS  USER_ID               
					  FROM dual ) SRC
				ON     (TGT.ID = SRC.ID)
				WHEN MATCHED THEN
					 UPDATE 
					   SET    TGT.ACCOUNT_CD          = SRC.ACCOUNT_CD         
							, TGT.ACCOUNT_NM          = SRC.ACCOUNT_NM         
							, TGT.PARENT_SALES_LV_ID  = SRC.PARENT_SALES_LV_ID 
                            , TGT.PARENT_SALES_LV_ID_AD1 = SRC.PARENT_SALES_LV_ID_AD1
                            , TGT.PARENT_SALES_LV_ID_AD2 = SRC.PARENT_SALES_LV_ID_AD2
                            , TGT.PARENT_SALES_LV_ID_AD3 = SRC.PARENT_SALES_LV_ID_AD3
							, TGT.CURCY_CD_ID         = SRC.CURCY_CD_ID        
							, TGT.COUNTRY_ID          = SRC.COUNTRY_ID         
							, TGT.CHANNEL_ID          = SRC.CHANNEL_ID         
							, TGT.SOLD_TO_ID          = SRC.SOLD_TO_ID         
							, TGT.SHIP_TO_ID          = SRC.SHIP_TO_ID         
							, TGT.BILL_TO_ID          = SRC.BILL_TO_ID         
							, TGT.INCOTERMS_ID        = SRC.INCOTERMS_ID       
							, TGT.SRP_YN              = SRC.SRP_YN             
							, TGT.VMI_YN              = SRC.VMI_YN             
							, TGT.DIRECT_SHPP_YN  = SRC.DIRECT_SHPP_YN 
							, TGT.ACTV_YN             = SRC.ACTV_YN
							, TGT.PRIORT 			  = SRC.PRIORT
							, TGT.ATTR_01             = SRC.ATTR_01            
							, TGT.ATTR_02			  = SRC.ATTR_02			  
							, TGT.ATTR_03			  = SRC.ATTR_03			  
							, TGT.ATTR_04			  = SRC.ATTR_04			  
							, TGT.ATTR_05			  = SRC.ATTR_05			  
							, TGT.ATTR_06			  = SRC.ATTR_06			  
							, TGT.ATTR_07			  = SRC.ATTR_07			  
							, TGT.ATTR_08			  = SRC.ATTR_08			  
							, TGT.ATTR_09			  = SRC.ATTR_09			  
							, TGT.ATTR_10			  = SRC.ATTR_10			  
							, TGT.ATTR_11			  = SRC.ATTR_11			  
							, TGT.ATTR_12			  = SRC.ATTR_12			  
							, TGT.ATTR_13			  = SRC.ATTR_13			  
							, TGT.ATTR_14			  = SRC.ATTR_14			  
							, TGT.ATTR_15			  = SRC.ATTR_15			  
							, TGT.ATTR_16			  = SRC.ATTR_16			  
							, TGT.ATTR_17			  = SRC.ATTR_17			  
							, TGT.ATTR_18			  = SRC.ATTR_18			  
							, TGT.ATTR_19			  = SRC.ATTR_19			  
							, TGT.ATTR_20			  = SRC.ATTR_20			  
							, TGT.DEL_YN              = SRC.DEL_YN             
							, TGT.MODIFY_BY           = SRC.USER_ID       
							, TGT.MODIFY_DTTM         = SYSDATE     
				WHEN NOT MATCHED THEN 
					 INSERT (
					              ID                 
								, ACCOUNT_CD         
								, ACCOUNT_NM         
								, PARENT_SALES_LV_ID 
                                , PARENT_SALES_LV_ID_AD1
                                , PARENT_SALES_LV_ID_AD2
                                , PARENT_SALES_LV_ID_AD3
								, CURCY_CD_ID        
								, COUNTRY_ID         
								, CHANNEL_ID         
								, SOLD_TO_ID         
								, SHIP_TO_ID         
								, BILL_TO_ID         
								, INCOTERMS_ID       
								, SRP_YN             
								, VMI_YN             
								, DIRECT_SHPP_YN 
								, ACTV_YN
								, PRIORT
								, ATTR_01            
								, ATTR_02			  
								, ATTR_03			  
								, ATTR_04			  
								, ATTR_05			  
								, ATTR_06			  
								, ATTR_07			  
								, ATTR_08			  
								, ATTR_09			  
								, ATTR_10			  
								, ATTR_11			  
								, ATTR_12			  
								, ATTR_13			  
								, ATTR_14			  
								, ATTR_15			  
								, ATTR_16			  
								, ATTR_17			  
								, ATTR_18			  
								, ATTR_19			  
								, ATTR_20			  
								, DEL_YN             
							    , CREATE_BY
							    , CREATE_DTTM
							) 
					 VALUES (
                                  V_ACCT_ID
								, SRC.ACCOUNT_CD         
								, SRC.ACCOUNT_NM         
								, SRC.PARENT_SALES_LV_ID 
                                , SRC.PARENT_SALES_LV_ID_AD1
                                , SRC.PARENT_SALES_LV_ID_AD2
                                , SRC.PARENT_SALES_LV_ID_AD3
								, SRC.CURCY_CD_ID        
								, SRC.COUNTRY_ID         
								, SRC.CHANNEL_ID         
								, SRC.SOLD_TO_ID         
								, SRC.SHIP_TO_ID         
								, SRC.BILL_TO_ID         
								, SRC.INCOTERMS_ID       
								, SRC.SRP_YN             
								, SRC.VMI_YN             
								, SRC.DIRECT_SHPP_YN 
								, SRC.ACTV_YN
								, SRC.PRIORT
								, SRC.ATTR_01            
								, SRC.ATTR_02			  
								, SRC.ATTR_03			  
								, SRC.ATTR_04			  
								, SRC.ATTR_05			  
								, SRC.ATTR_06			  
								, SRC.ATTR_07			  
								, SRC.ATTR_08			  
								, SRC.ATTR_09			  
								, SRC.ATTR_10			  
								, SRC.ATTR_11			  
								, SRC.ATTR_12			  
								, SRC.ATTR_13			  
								, SRC.ATTR_14			  
								, SRC.ATTR_15			  
								, SRC.ATTR_16			  
								, SRC.ATTR_17			  
								, SRC.ATTR_18			  
								, SRC.ATTR_19			  
								, SRC.ATTR_20			  
								, SRC.DEL_YN      
							    , SRC.USER_ID 
							    , SYSDATE 
 							) 
							;    	


		FOR CUR IN (
		  SELECT VER_ID
		    FROM (
    		  SELECT M.ID AS VER_ID
    		       , DENSE_RANK () OVER (PARTITION BY M.PLAN_TP_ID ORDER BY M.CREATE_DTTM DESC) AS RW
    		    FROM TB_DP_CONTROL_BOARD_VER_MST M
    		         INNER JOIN
    		         TB_DP_CONTROL_BOARD_VER_DTL D
    		      ON M.ID = D.CONBD_VER_MST_ID
    		         INNER JOIN
    		         TB_CM_COMM_CONFIG W
    		      ON W.ID = D.WORK_TP_ID
    		     AND W.CONF_CD = 'CL'
    		         INNER JOIN
    		         TB_CM_COMM_CONFIG C
    		      ON D.CL_STATUS_ID = C.ID
    		     AND C.CONF_CD != 'CLOSE'
    		   WHERE EXISTS (SELECT DISTINCT VER_ID FROM TB_DP_ENTRY WHERE VER_ID = M.ID)
		    ) A
		   WHERE RW = 1
		     AND P_DEL_YN != 'Y' AND P_ACTV_YN = 'Y'
		) LOOP
		    SELECT COUNT(1) INTO V_ENTRY_COUNT
		      FROM TB_DP_ENTRY
		     WHERE VER_ID = CUR.VER_ID
		       AND ACCOUNT_ID = V_ACCT_ID;

		    IF V_ENTRY_COUNT = 0 THEN
                SP_UI_DPD_MAKE_HIER_SALES();
		        SP_UI_DP_93_ITEM_ACCT_CREATE(
		            NULL,
		            NULL,
		            V_ACCT_ID,
		            NULL,
		            NULL,
		            NULL,
		            CUR.VER_ID
		        );
		    END IF;

		END LOOP;

	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  --
       /*  ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN  -- : e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF; 

END;
/

