create PROCEDURE "SP_UI_DP_93_VER_CREATE_S3_01"  (
			P_VER_ID					CHAR 
		  , P_PLAN_TP_ID				CHAR  
          , pRESULT        OUT SYS_REFCURSOR
)
IS  
		   -- For Loop  
		   P_STR	VARCHAR2(4000); 
           p_SELECT_STR    VARCHAR2(4000);
		   P_VAL_CNT  INT ;
BEGIN 
/**************************************************************************************************************
    -- Oracle Test를 위한 SP_UI_DP_93_VER_CREATE_S3 프로시저 PART 1
    -- 동적쿼리 확인용... 다양한 Case test하고 기본 프로시저랑 합칠 예정
    
    History (Date / Writer / Comment)
    - 2023.02.02 / Kim sohee / Function => Temp Table
    
*************************************************************************************************************/	 
/************************************************************************************************************
	-- Initial Value
************************************************************************************************************/
	--------------- 2. Create and Insert Result Temporary Table
 
	BEGIN 
        SELECT COUNT(1) INTO P_VAL_CNT FROM TABLE(FN_DP_TEMP_VER_INFO_DTL (P_VER_ID)) WHERE INIT_TP_CD = 'PR';
        IF (P_VAL_CNT = 0)
            THEN
             SELECT COUNT(1) INTO P_VAL_CNT  
              FROM TABLE(FN_DP_TEMP_VER_INFO_INIT (P_VER_ID)) 
              WHERE INIT_VAL_TP_CD = 'PR'   
             ;
            END IF;
		IF P_VAL_CNT > 0
			THEN	   
                  P_STR := 'INSERT INTO TEMP_DP_RT  ( ITEM_MST_ID,ACCOUNT_ID,BASE_DATE,QTY,AUTH_TP_ID';             
                      SELECT CASE WHEN LISTAGG(INIT_MS_VAL_TP_CD,',') WITHIN GROUP (ORDER BY INIT_MS_VAL_TP_CD) IS NOT NULL THEN ',' END
                            ||LISTAGG(INIT_MS_VAL_TP_CD,',') WITHIN GROUP (ORDER BY INIT_MS_VAL_TP_CD)
                                INTO P_SELECT_STR                       
                        FROM ( SELECT DISTINCT INIT_MS_VAL_TP_CD 
                                 FROM TABLE(FN_DP_TEMP_VER_INFO_INIT (P_VER_ID))		
                                WHERE INIT_VAL_TP_CD = 'PR' 	
                              ) A			
                              ;
                    P_STR := P_STR||P_SELECT_STR||')';
                    --
                    SELECT 'WITH INI_PR '
                            ||  'AS ( '
                            ||	'SELECT DTL_ID '
                            ||		 ', INIT_FIXED_LV_MGMT_ID '
                            ||		 ', INIT_MS_VAL_TP_CD '
                            ||	  'FROM TABLE(FN_DP_TEMP_VER_INFO_INIT ('''||P_VER_ID||''')) '
                            ||	 'WHERE INIT_VAL_TP_CD = ''PR'' '
                            ||  ') ' 
                            ||'SELECT M.ITEM_ID '
                            ||	  ', M.ACCT_ID'
                            ||	  ', M.BASE_DATE  '                            
                            ||	CASE WHEN EXISTS ( SELECT 1 FROM TABLE(FN_DP_TEMP_VER_INFO_DTL (P_VER_ID)) WHERE INIT_TP_CD = 'PR') THEN  ', DE.QTY ' ELSE ', 0' END
                            ||	  ', VE.AUTH_TP_ID '
                        INTO P_SELECT_STR
                        FROM DUAL 
                            ;
                    P_STR := P_STR || P_SELECT_STR;
                    
             SELECT COUNT(1) INTO P_VAL_CNT  
              FROM TABLE(FN_DP_TEMP_VER_INFO_INIT (P_VER_ID)) 
              WHERE INIT_VAL_TP_CD = 'PR'   
              ;
              IF ( P_VAL_CNT > 0)
                THEN
				 	SELECT  coalesce(','||LISTAGG('DE'||TO_CHAR(IDX)||'.'||INIT_MS_VAL_TP_CD,',')  WITHIN GROUP(ORDER BY INIT_MS_VAL_TP_CD) ,' ')
                            INTO p_SELECT_STR
						  FROM ( SELECT DISTINCT INIT_MS_VAL_TP_CD, IDX 
						  		    FROM TABLE(FN_DP_TEMP_VER_INFO_INIT (P_VER_ID))		
								   WHERE INIT_VAL_TP_CD = 'PR' 	
							      ) A	 
                        GROUP BY CASE WHEN EXISTS ( SELECT 1 FROM TABLE(FN_DP_TEMP_VER_INFO_DTL (P_VER_ID)) WHERE INIT_TP_CD = 'PR') THEN  ', DE.QTY ' ELSE ', 0' END
                                ;         
                ELSE                    
                    p_SELECT_STR := '';
                END IF;
                P_STR := P_STR || p_SELECT_STR; 
                P_STR := P_STR ||' FROM TEMP_DP_ITEM_ACCT_ROLE_DATE M ' 
				||' INNER JOIN'
				||' TABLE(FN_DP_TEMP_VER_INFO_DTL ('''||P_VER_ID||''')) VE ON M.ROLE_ID = VE.AUTH_TP_ID '
                ;
        SELECT COUNT(1) INTO P_VAL_CNT FROM TABLE(FN_DP_TEMP_VER_INFO_DTL (P_VER_ID)) WHERE INIT_TP_CD = 'PR';
				IF (P_VAL_CNT > 0)
					THEN
                                P_STR := P_STR 
									||     ' LEFT OUTER JOIN '
									||	   'TABLE(FN_DP_TEMP_VER_INFO_DTL ('''||P_VER_ID||''')) VD'
									|| ' ON VE.DTL_ID = VD.DTL_ID AND VD.INIT_TP_CD = ''PR'''		
									||	   'LEFT OUTER JOIN '
									||	   'TABLE(FN_DP_TEMP_PR_VER('''||P_VER_ID||''', '''||P_PLAN_TP_ID||''')) DE '
									|| ' ON VD.INIT_VAL_ID = DE.AUTH_TP_ID '
									||' AND M.ITEM_ID = DE.ITEM_MST_ID'
									||' AND M.ACCT_ID = DE.ACCOUNT_ID'
									||' AND M.BASE_DATE = DE.BASE_DATE '
                                    ;
					END IF                                        
                    ;

				SELECT DISTINCT COUNT(INIT_VAL_TP_CD) INTO P_VAL_CNT
				  FROM TABLE(FN_DP_TEMP_VER_INFO_INIT (P_VER_ID))  WHERE INIT_VAL_TP_CD = 'PR'	 
				  ;		
				IF (P_VAL_CNT > 0)
					THEN
                        SELECT 'INNER JOIN '		  
						||	   'INI_PR '
						||' PIVOT (MAX(INIT_FIXED_LV_MGMT_ID) FOR INIT_MS_VAL_TP_CD IN ('
                        ||coalesce(LISTAGG(''''||INIT_MS_VAL_TP_CD||''' AS '||INIT_MS_VAL_TP_CD,',') WITHIN GROUP(ORDER BY INIT_MS_VAL_TP_CD)  ,'')
                        INTO P_SELECT_STR
								  FROM ( SELECT DISTINCT INIT_MS_VAL_TP_CD 
						  		    FROM TABLE(FN_DP_TEMP_VER_INFO_INIT (P_VER_ID))		
								   WHERE INIT_VAL_TP_CD = 'PR' 	
							      ) A			
						 ;
                        P_STR := P_STR || P_SELECT_STR|| ')) PVT '  
						||' ON VE.DTL_ID = PVT.DTL_ID '
                        ;
                        SELECT ' LEFT OUTER JOIN '
                        ||    ' TABLE(FN_DP_TEMP_PR_VER('''||P_VER_ID||''','''|| P_PLAN_TP_ID||''')) DE'
                        ||TO_CHAR(IDX) 
                        || ' ON PVT.'||INIT_MS_VAL_TP_CD||' = DE'||TO_CHAR(IDX)||'.AUTH_TP_ID '
                        || ' AND M.ITEM_ID = DE'||TO_CHAR(  IDX) ||'.ITEM_MST_ID '
                        || ' AND M.ACCT_ID = DE'||TO_CHAR(  IDX) ||'.ACCOUNT_ID '
                        || ' AND M.BASE_DATE = DE'||TO_CHAR(  IDX) ||'.BASE_DATE '
                        INTO P_SELECT_STR
                      FROM TABLE(FN_DP_TEMP_VER_INFO_INIT (P_VER_ID))
                     WHERE INIT_VAL_TP_CD = 'PR' 
                    GROUP BY INIT_MS_VAL_TP_CD, IDX 
                    ;
                    P_STR := P_STR || P_SELECT_STR
                    ;
                END IF
                ;

			  P_STR := P_STR||P_SELECT_STR;              

              
              OPEN pRESULT
                FOR  
            SELECT P_STR AS STR
             FROM DUAL ;
              EXECUTE IMMEDIATE P_STR ;

			END IF
            ;

	END
		;


END
;
/

