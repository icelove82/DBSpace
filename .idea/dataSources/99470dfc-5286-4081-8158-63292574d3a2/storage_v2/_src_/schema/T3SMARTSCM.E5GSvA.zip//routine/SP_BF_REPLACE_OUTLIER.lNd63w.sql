create PROCEDURE                  "SP_BF_REPLACE_OUTLIER" (
      p_VER_CD				VARCHAR2
    , p_THRESHOLD_PCT		INT
    , p_YOY_MULTIPLIER		INT
    ) 
IS

--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
v_input_from_date	DATE;
v_input_to_date		DATE;
v_target_from_date	DATE;
v_target_to_date	DATE;


BEGIN
	 SELECT MAX(INPUT_FROM_DATE)
          , MAX(INPUT_TO_DATE)
          , MAX(TARGET_FROM_DATE)
          , MAX(TARGET_TO_DATE)
           INTO
            v_input_from_date
          , v_input_to_date
          , v_target_from_date
          , v_target_to_date
	  FROM TB_BF_CONTROL_BOARD_VER_DTL
	 WHERE VER_CD = p_VER_CD
	   AND ENGINE_TP_CD IS NOT NULL
  ;

INSERT INTO TB_BF_RT_POST
	with 
	qf as (
	select 	v_input_from_date as input_from_date, v_input_to_date as input_to_date, 
			v_target_from_date as target_from_date, v_target_to_date as target_to_date,
			p_VER_CD AS ver_cd
		  , p_THRESHOLD_PCT as threshold_pct
	FROM dual
	)
	,cal_hist as ( 
	select 
			  distinct trunc(dat,'MM') AS base_month
			, yyyymm
			, yyyy
			, cast(mm as int) as mm
	from tb_cm_calendar c
	cross join qf
	where 1=1
	and c.dat between qf.input_from_date and qf.input_to_date 
	)
	,cal_fcst as ( 
	select 
			distinct trunc(dat,'MM') as base_date
			, yyyymm
			, yyyy
			, cast(mm as int) as mm
	from tb_cm_calendar c
	cross join qf
	where 1=1
	and c.dat between qf.target_from_date and qf.target_to_date 
	)
	,sales_agg as (
	select 
			i.item_cd,
			a.account_cd,
			trunc(s.base_date, 'MM') as txn_month,
			sum(s.qty) as qty  
	from tb_cm_actual_sales s 
	inner join tb_cm_item_mst i on (i.id = s.item_mst_id)
	inner join tb_dp_account_mst a on (a.id = s.account_id)
--	INNER JOIN tb_bf_rt rt ON (i.item_cd = rt.item_cd AND a.account_cd = rt.account_cd) 
	cross join qf
	where 1=1
	and s.base_date between qf.input_from_date and qf.input_to_date 
	group by i.item_cd, a.account_cd, trunc(s.base_date, 'MM')
	)
	,sales_hist1 as (
	select 
			s.item_cd,
			s.account_cd,
			c.base_month as base_date,
			c.yyyymm,
			c.yyyy,
			c.mm,
			coalesce(s.qty,0) as qty
	from cal_hist c
	left outer join sales_agg s on (c.base_month = s.txn_month) 
	)
	,sales_stats as ( 
	select 
			item_cd, account_cd,
			cast(mm as int) as mm,
			round(avg(qty),2) as qty_avg,
			round(stddev(qty),2) as qty_std,
			min(qty) as qty_min,
			max(qty) as qty_max
	from sales_hist1
	group by item_cd, account_cd, mm
	)
	,cal_fcst2 as (
	select 	c.*, 
			s.item_cd, s.account_cd,
			s.qty_avg,
			s.qty_std,
			s.qty_min,
			s.qty_max
	from cal_fcst c 
	inner join sales_stats s on (c.mm = s.mm)
	)
	,sales_hist as (
	select	s1.item_cd,
			s1.account_cd,
			s1.base_date,
			s1.qty,
			add_months(s1.base_date, 1) AS next_date,
			add_months(s1.base_date, -1) AS prev_date,
			s2.qty as qty_prev,
			add_months(s1.base_date, 12) AS yoy_date,
			s3.qty as qty_yoy
	from sales_hist1 s1 
	left outer join sales_hist1 s2 on (s1.item_cd = s2.item_cd and s1.account_cd = s2.account_cd and s1.base_date = add_months(s2.base_date, 1))
	left outer join sales_hist1 s3 on (s1.item_cd = s3.item_cd and s1.account_cd = s3.account_cd and s1.base_date = add_months(s2.base_date, 12))
	)
	,sales_fcst as ( 
	select 
			f.ver_cd,
			f.engine_tp_cd, 
			f.item_cd, 
			f.account_cd,
			f.base_date,
			f.qty
--			,case when f.base_date = min(f.base_date) over(PARTITION BY f.item_cd, f.account_cd, f.ENGINE_TP_CD) THEN 'Y' ELSE 'N' END FCST_START
			,case 
				when hm.base_date is not null then 'Y'
				else 'N'
			end fcst_start		
			,hm.base_date as prev_date
			,hm.qty as qty_prev
			,f.qty - hm.qty as diff_prev
			,round((f.qty - hm.qty)/case when f.qty = 0 then null else f.qty end * 100,2) as diff_prev_pct
			,hy.base_date as yoy_date
			,hy.qty as qty_yoy
			,f.qty - hy.qty as diff_yoy
			,round((f.qty - hy.qty)/case when f.qty = 0 then null else f.qty end * 100,2) as diff_yoy_pct
			,c.qty_avg
	from tb_bf_rt f
	cross join qf
	inner join sales_hist hy on (f.item_cd = hy.item_cd and f.account_cd = hy.account_cd and f.base_date = hy.yoy_date)
	left join sales_hist hm on (f.item_cd = hm.item_cd and f.account_cd = hm.account_cd and f.base_date = hm.next_date)
	inner join cal_fcst2 c on (f.item_cd = c.item_cd and f.account_cd = c.account_cd and f.base_date = c.base_date)
	where 1=1
	and f.ver_cd = qf.ver_cd
	)
	,sales_df1 as ( 
	select 	'HIST' as ver_cd, 'NA' as engine_tp_cd, item_cd, account_cd, 
			base_date, qty, 0 AS qty_correction,
			qty_yoy yoy,
			null as fcst_start,
			prev_date, qty_prev, null as diff_prev, null as diff_prev_pct,
			null as threshold_pct,
			yoy_date
	from sales_hist
	union all
	select	
			f.ver_cd, engine_tp_cd, item_cd, account_cd, 
			base_date, qty,
			round(qty_yoy * p_YOY_MULTIPLIER / 100, 0) qty_correction,
			qty_yoy yoy,
			fcst_start,
			prev_date, qty_prev, diff_prev, diff_prev_pct,
			qf.threshold_pct,
			yoy_date
	from sales_fcst f
	cross join qf
	)
	select 'FCST_OUTLIER' type_cd
		 , t1.*
		 , 'admin' create_by
		 , SYSDATE create_dttm
		 , null modify_by
		 , null modify_dttm
	FROM sales_df1 t1
	where 1=1
	and exists 
	(
		select 1 
		from sales_df1 t2 
		where 1=1
		and t1.engine_tp_cd = t2.engine_tp_cd and t1.item_cd = t2.item_cd and t1.ver_cd = t2.ver_cd and t1.account_cd = t2.account_cd 
		and t2.fcst_start = 'Y' and abs(t2.diff_prev_pct) > 10
	)
	;
	UPDATE TB_BF_RT rt
	SET RT.QTY = (SELECT QTY_CORRECTION FROM TB_BF_RT_POST fo WHERE rt.ver_cd = fo.ver_cd and rt.item_cd = fo.item_cd and rt.account_cd = fo.account_cd and rt.base_date = fo.base_date and rt.engine_tp_cd = fo.engine_tp_cd and fo.type_cd = 'FCST_OUTLIER' )
	WHERE EXISTS (
		SELECT 1 FROM TB_BF_RT_POST fo 
		WHERE rt.ver_cd = fo.ver_cd and rt.item_cd = fo.item_cd and rt.account_cd = fo.account_cd and rt.base_date = fo.base_date and rt.engine_tp_cd = fo.engine_tp_cd and fo.type_cd = 'FCST_OUTLIER'
	);

END;

/

