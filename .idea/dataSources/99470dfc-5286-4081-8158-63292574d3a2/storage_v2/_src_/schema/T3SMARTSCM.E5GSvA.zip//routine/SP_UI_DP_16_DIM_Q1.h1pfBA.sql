create PROCEDURE SP_UI_DP_16_DIM_Q1 (                            			        
                                      pRESULT              OUT SYS_REFCURSOR
) IS

/************************************************************************************************V*********
Title : SP_UI_DP_16_S1_J
  - DP Dimension Data Management

설명 
  - OPENJSON : https://docs.microsoft.com/ko-kr/sql/t-sql/functions/openjson-transact-sql?view=sql-server-ver15

 
History (수정일자 / 수정자 / 수정내용)
- 2022.01.13 / kim sohee / json bulk insert draft
******************************************************************************************************************/
BEGIN 
    OPEN pRESULT for
    select CONF_CD AS DIM_COL
    , ATTR_01 AS DIM_TP 
    from TB_CM_COMM_CONFIG where conf_grp_cd = 'DP_DMND_CUSTOM' and ACTV_YN = 'Y' and CONF_CD != '_COMMENT'
    ;

END;
/

