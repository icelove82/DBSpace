create PROCEDURE                SP_UI_BF_55_CHART_Q1(
     p_VER_CD       VARCHAR2
	,p_FROM_DATE	DATE        := NULL
	,p_TO_DATE		DATE        := NULL
	,p_ITEM_LV		VARCHAR2    := NULL -- id 로 넘어옴
	,p_SALES_LV	    VARCHAR2    := NULL 
	,p_GRADE		VARCHAR2    :='Y'
	,p_ITEM_CD		VARCHAR2    :=''
	,p_ACCOUNT_CD   VARCHAR2    :=''
	,p_SELECT_GRADE VARCHAR2    :=''
    ,pRESULT        OUT SYS_REFCURSOR
)IS 

v_TO_DATE date :='';
v_BUCKET VARCHAR2(2);
v_EXISTS_NUM INT :=0;

BEGIN
    v_TO_DATE := p_TO_DATE;

    SELECT TARGET_BUKT_CD INTO v_BUCKET 
      FROM TB_BF_CONTROL_BOARD_VER_DTL WHERE 1=1 AND VER_CD = p_VER_CD AND ENGINE_TP_CD IS NOT NULL AND ROWNUM=1;

    INSERT INTO TEMP_ITEM_LEVEL
    SELECT ID, ITEM_LV_NM
      FROM TB_CM_ITEM_LEVEL_MGMT
     WHERE LV_MGMT_ID = p_ITEM_LV
     ;  
    INSERT INTO TEMP_SALES_LEVEL
    SELECT ID, SALES_LV_NM
      FROM TB_DP_SALES_LEVEL_MGMT
     WHERE LV_MGMT_ID = p_SALES_LV
    ;

    SELECT CASE WHEN EXISTS ( SELECT 1 FROM TEMP_ITEM_LEVEL ) THEN '1' ELSE '0' END INTO v_EXISTS_NUM
      FROM DUAL;

	IF (v_EXISTS_NUM='1')
    THEN
        INSERT INTO TEMP_ITEM_HIER
        SELECT IH.DESCENDANT_ID
              ,IH.DESCENDANT_CD
              ,IH.ANCESTER_CD
              ,IL.ITEM_LV_NM 
              ,IM.ATTR_05
         FROM TB_DPD_ITEM_HIER_CLOSURE IH
              INNER JOIN 
              TEMP_ITEM_LEVEL IL 
           ON IH.ANCESTER_ID = IL.ID 
              INNER JOIN
              TB_CM_ITEM_MST IM
           ON IH.DESCENDANT_CD = IM.ITEM_CD
         WHERE IH.LEAF_YN = 'Y'  
         ;
	ELSE
        INSERT INTO TEMP_ITEM_HIER
        SELECT IH.DESCENDANT_ID
              ,IH.DESCENDANT_CD
              ,IH.ANCESTER_CD
              ,IT.ITEM_NM
              ,IT.ATTR_05
         FROM TB_DPD_ITEM_HIER_CLOSURE IH
              INNER JOIN
              TB_CM_ITEM_MST IT
           ON IH.ANCESTER_ID = IT.ID 
        WHERE IH.LEAF_YN = 'Y'
        ;
    END IF;

    SELECT CASE WHEN EXISTS ( SELECT 1 FROM TEMP_SALES_LEVEL ) THEN '1' ELSE '0' END INTO v_EXISTS_NUM
      FROM DUAL;

	IF (v_EXISTS_NUM='1') 
    THEN
        INSERT INTO TEMP_ACCT_HIER
        SELECT SH.DESCENDANT_ID
              ,SH.DESCENDANT_CD
              ,SH.ANCESTER_CD
              ,SL.SALES_LV_NM 
         FROM TB_DPD_SALES_HIER_CLOSURE SH
              INNER JOIN 
              TEMP_SALES_LEVEL SL 
           ON SH.ANCESTER_ID = SL.ID 
         WHERE SH.LEAF_YN = 'Y'  
         ;
	ELSE
        INSERT INTO TEMP_ACCT_HIER 
        SELECT SH.DESCENDANT_ID
              ,SH.DESCENDANT_CD
              ,SH.ANCESTER_CD
              ,AM.ACCOUNT_NM
         FROM TB_DPD_SALES_HIER_CLOSURE SH
              INNER JOIN 
              TB_DP_ACCOUNT_MST AM 
           ON SH.ANCESTER_ID = AM.ID
         WHERE SH.LEAF_YN = 'Y'
         ;
    END IF;
    
    IF (v_BUCKET = 'M')
    THEN
        IF (p_GRADE = 'Y')
        THEN
            OPEN pRESULT FOR
            WITH ACT_SALES AS (
                SELECT AM.ACCOUNT_CD
                        , AM.ACCOUNT_NM
                        , IM.ITEM_CD
                        , IM.ITEM_NM
                        , TO_CHAR(S.BASE_DATE,'YYYY-MM') BASE_DATE
                        , SUM(S.QTY) QTY
                    FROM TB_CM_ACTUAL_SALES S
                    INNER JOIN TB_DP_ACCOUNT_MST AM ON S.ACCOUNT_ID=AM.ID
                    INNER JOIN TB_CM_ITEM_MST	  IM ON S.ITEM_MST_ID=IM.ID
                    WHERE S.BASE_DATE BETWEEN p_FROM_DATE AND v_TO_DATE
                    GROUP BY AM.ACCOUNT_CD, AM.ACCOUNT_NM, IM.ITEM_CD, IM.ITEM_NM, TO_CHAR(S.BASE_DATE,'YYYY-MM')
            )
            , FINAL AS (
                SELECT F.VER_CD
                     , F.ITEM_CD
                     , F.ACCOUNT_CD
                     , TO_CHAR(F.BASE_DATE,'YYYY-MM') BASE_DATE
                     , SUM(F.QTY) QTY
                  FROM TB_BF_RT_FINAL F
                 WHERE F.VER_CD = p_VER_CD
                 GROUP BY F.VER_CD, ITEM_CD, ACCOUNT_CD, TO_CHAR(F.BASE_DATE,'YYYY-MM')
            ),
            WAPE AS (
            select A.ITEM_CD
                    , IH.ANCS_CD ITEM_LV_CD
                    , IH.ANCS_NM ITEM_LV_NM
                    , A.ACCOUNT_CD
                    , AH.ANCS_CD ACCT_LV_CD
                    , AH.ANCS_NM ACCT_LV_NM
                    , A.BASE_DATE BASE_DATE
                    -- 예측
                    , A.QTY PREDICT
                    -- 실적
                    , B.QTY ACT_SALES
                    -- 개별정확도
                    , CASE WHEN B.QTY = 0 THEN 0 ELSE (CASE WHEN (1-ABS(A.QTY-B.QTY)/B.QTY) >= 0 THEN (1-ABS(A.QTY-B.QTY)/B.QTY)*100 ELSE 0 END) END WAPE
                    , IH.GRADE
                from FINAL A
                    INNER JOIN ACT_SALES B ON A.ITEM_CD=B.ITEM_CD AND A.ACCOUNT_CD=B.ACCOUNT_CD AND A.BASE_DATE = B.BASE_DATE
                    --INNER JOIN TB_CM_ITEM_MST IM ON A.ITEM_CD = IM.ITEM_CD AND IM.ATTR_05 !='N'
                    INNER JOIN TEMP_ACCT_HIER AH ON AH.DESC_CD = A.ACCOUNT_CD
                    INNER JOIN TEMP_ITEM_HIER IH ON IH.DESC_CD = A.ITEM_CD
            )
        --SELECT * FROM WAPE
           SELECT CAST(GRADE AS VARCHAR2(100)) || '-' || ITEM_LV_CD || '-' || ACCT_LV_CD AS GIA
                , TO_CHAR(BASE_DATE, 'yyyy-mm-dd') AS "DATE"
                , CASE WHEN SUM(ACT_SALES) = 0 THEN 0 ELSE SUM(WAPE*ACT_SALES)/SUM(ACT_SALES) END AS ACCRY
            FROM WAPE
           WHERE CAST(GRADE AS VARCHAR2(100)) LIKE '%' || p_SELECT_GRADE || '%'
             AND ITEM_LV_CD=p_ITEM_CD 
             AND ACCT_LV_CD=p_ACCOUNT_CD
            GROUP BY GRADE, ITEM_LV_CD, ACCT_LV_CD, BASE_DATE
            ORDER BY GRADE, ITEM_LV_CD, ACCT_LV_CD, BASE_DATE
            ;
        ELSE
            OPEN pRESULT FOR
            WITH ACT_SALES AS (
                SELECT AM.ACCOUNT_CD
                     , AM.ACCOUNT_NM
                     , IM.ITEM_CD
                     , IM.ITEM_NM
                     , TO_CHAR(S.BASE_DATE,'YYYY-MM') BASE_DATE
                     , SUM(S.QTY) QTY
                  FROM TB_CM_ACTUAL_SALES S
                 INNER JOIN TB_DP_ACCOUNT_MST AM ON S.ACCOUNT_ID=AM.ID
                 INNER JOIN TB_CM_ITEM_MST	  IM ON S.ITEM_MST_ID=IM.ID
                 WHERE S.BASE_DATE BETWEEN p_FROM_DATE AND v_TO_DATE
                 GROUP BY AM.ACCOUNT_CD, AM.ACCOUNT_NM, IM.ITEM_CD, IM.ITEM_NM, TO_CHAR(S.BASE_DATE,'YYYY-MM')
            )
            , FINAL AS (
                SELECT F.VER_CD
                     , F.ITEM_CD
                     , F.ACCOUNT_CD
                     , TO_CHAR(F.BASE_DATE,'YYYY-MM') BASE_DATE
                     , SUM(F.QTY) QTY
                  FROM TB_BF_RT_FINAL F
                 WHERE F.VER_CD = p_VER_CD
                 GROUP BY F.VER_CD, ITEM_CD, ACCOUNT_CD, TO_CHAR(F.BASE_DATE,'YYYY-MM')
            ),
            WAPE AS (
                select A.ITEM_CD
                     , IH.ANCS_CD ITEM_LV_CD
                     , IH.ANCS_NM ITEM_LV_NM
                     , A.ACCOUNT_CD
                     , AH.ANCS_CD ACCT_LV_CD
                     , AH.ANCS_NM ACCT_LV_NM
                     , A.BASE_DATE
                     -- 예측
                     , A.QTY PREDICT
                     -- 실적
                     , B.QTY ACT_SALES
                     -- 개별정확도
                     , CASE WHEN B.QTY = 0 THEN 0 ELSE (CASE WHEN (1-ABS(A.QTY-B.QTY)/B.QTY) >= 0 THEN (1-ABS(A.QTY-B.QTY)/B.QTY)*100 ELSE 0 END) END WAPE
                     , IH.GRADE
                  from FINAL A
                 INNER JOIN ACT_SALES B ON A.ITEM_CD=B.ITEM_CD AND A.ACCOUNT_CD=B.ACCOUNT_CD AND A.BASE_DATE = B.BASE_DATE
                 INNER JOIN TEMP_ACCT_HIER AH ON AH.DESC_CD = A.ACCOUNT_CD
                 INNER JOIN TEMP_ITEM_HIER IH ON IH.DESC_CD = A.ITEM_CD
            )
           SELECT 'N' || '-' || ITEM_LV_CD || '-' || ACCT_LV_CD AS GIA
                , TO_CHAR(BASE_DATE, 'yyyy-mm-dd') AS "DATE"
                , CASE WHEN SUM(ACT_SALES) = 0 THEN 0 ELSE SUM(WAPE*ACT_SALES)/SUM(ACT_SALES) END ACCRY
            FROM WAPE
           WHERE 1=1
             AND ITEM_LV_CD = p_ITEM_CD
             AND ACCT_LV_CD = p_ACCOUNT_CD
            GROUP BY ITEM_LV_CD, ACCT_LV_CD, BASE_DATE
            ORDER BY ITEM_LV_CD, ACCT_LV_CD, BASE_DATE
            ;
        END IF;
    ELSE
        IF p_GRADE = 'Y'
        THEN
            OPEN pRESULT FOR
            WITH CAL AS (
                SELECT YYYY, DP_WK, MM, MIN(DAT) MIN_DAT, MAX(DAT) MAX_DAT
                  FROM TB_CM_CALENDAR
                 WHERE DAT BETWEEN p_FROM_DATE AND v_TO_DATE
                 GROUP BY YYYY, DP_WK, MM
            )
            , SALES AS (
                   SELECT AM.ACCOUNT_CD
                        , AM.ACCOUNT_NM
                        , IM.ITEM_CD
                        , IM.ITEM_NM
                        , S.BASE_DATE BASE_DATE
                        , SUM(S.QTY) QTY
                        , MIN(CL.YYYY ) YYYY
                        , MIN(CL.MM   ) MM
                        , MIN(CL.DP_WK) DP_WK
                    FROM TB_CM_ACTUAL_SALES S
                    INNER JOIN TB_DP_ACCOUNT_MST  AM ON S.ACCOUNT_ID=AM.ID
                    INNER JOIN TB_CM_ITEM_MST	  IM ON S.ITEM_MST_ID=IM.ID
                    INNER JOIN TB_CM_CALENDAR     CL ON CL.DAT = S.BASE_DATE
                    WHERE S.BASE_DATE BETWEEN p_FROM_DATE AND v_TO_DATE
                    GROUP BY AM.ACCOUNT_CD, AM.ACCOUNT_NM, IM.ITEM_CD, IM.ITEM_NM, S.BASE_DATE
            ),
            ACT_SALES AS (
                SELECT ITEM_CD
                     , ITEM_NM
                     , ACCOUNT_CD
                     , ACCOUNT_NM
                     , B.MIN_DAT BASE_DATE
                     , SUM(QTY) QTY
                  FROM SALES A
                 INNER JOIN CAL B ON A.YYYY = B.YYYY AND A.MM = B.MM AND A.DP_WK = B.DP_WK
                 GROUP BY ITEM_CD, ITEM_NM, ACCOUNT_CD, ACCOUNT_NM, B.MIN_DAT
                 --ORDER BY B.MIN_DAT
            )
            , FINAL AS (
                SELECT F.VER_CD
                        , F.ITEM_CD
                        , F.ACCOUNT_CD
                        , F.BASE_DATE BASE_DATE
                        , SUM(F.QTY) QTY
                    FROM TB_BF_RT_FINAL F
                    WHERE F.VER_CD = p_VER_CD
                    --INNER JOIN VER V ON F.VER_CD = V.VER_CD AND CONVERT(CHAR(7),F.BASE_DATE,23)=V.TARGET_FROM_DATE
                    GROUP BY F.VER_CD, ITEM_CD, ACCOUNT_CD, F.BASE_DATE
            ),
            WAPE AS (
            select A.ITEM_CD
                    , IH.ANCS_CD ITEM_LV_CD
                    , IH.ANCS_NM ITEM_LV_NM
                    , A.ACCOUNT_CD
                    , AH.ANCS_CD ACCT_LV_CD
                    , AH.ANCS_NM ACCT_LV_NM
                    , A.BASE_DATE
                    -- 예측
                    , A.QTY PREDICT
                    -- 실적
                    , B.QTY ACT_SALES
                    -- 개별정확도
                    , CASE WHEN B.QTY = 0 THEN 0 ELSE (CASE WHEN (1-ABS(A.QTY-B.QTY)/B.QTY) >= 0 THEN (1-ABS(A.QTY-B.QTY)/B.QTY)*100 ELSE 0 END) END WAPE
                    , IH.GRADE
                from FINAL A
                    INNER JOIN ACT_SALES B ON A.ITEM_CD=B.ITEM_CD AND A.ACCOUNT_CD=B.ACCOUNT_CD AND A.BASE_DATE = B.BASE_DATE
                    --INNER JOIN TB_CM_ITEM_MST IM ON A.ITEM_CD = IM.ITEM_CD AND IM.ATTR_05 !='N'
                    INNER JOIN TEMP_ACCT_HIER AH ON AH.DESC_CD = A.ACCOUNT_CD
                    INNER JOIN TEMP_ITEM_HIER IH ON IH.DESC_CD = A.ITEM_CD
            )

            --SELECT * FROM WAPE
            SELECT TO_CHAR(GRADE) || '-' || ITEM_LV_CD || '-' || ACCT_LV_CD AS GIA
                 , TO_CHAR(BASE_DATE, 'yyyy-mm-dd') AS "DATE"
                 , CASE WHEN SUM(ACT_SALES) = 0 THEN 0 ELSE SUM(WAPE*ACT_SALES)/SUM(ACT_SALES) END ACCRY
              FROM WAPE
             WHERE 1=1
               AND ITEM_LV_CD = p_ITEM_CD
               AND ACCT_LV_CD = p_ACCOUNT_CD 
             GROUP BY GRADE, ITEM_LV_CD, ACCT_LV_CD, BASE_DATE
             ORDER BY GRADE, ITEM_LV_CD, ACCT_LV_CD, BASE_DATE
             ;
        ELSE
            OPEN pRESULT FOR
            WITH CAL AS (
                SELECT YYYY, DP_WK, MM, MIN(DAT) MIN_DAT, MAX(DAT) MAX_DAT
                  FROM TB_CM_CALENDAR
                 WHERE DAT BETWEEN p_FROM_DATE AND v_TO_DATE
                 GROUP BY YYYY, DP_WK, MM
            )
            , SALES AS (
                   SELECT AM.ACCOUNT_CD
                        , AM.ACCOUNT_NM
                        , IM.ITEM_CD
                        , IM.ITEM_NM
                        , S.BASE_DATE BASE_DATE
                        , SUM(S.QTY) QTY
                        , MIN(CL.YYYY ) YYYY
                        , MIN(CL.MM   ) MM
                        , MIN(CL.DP_WK) DP_WK
                    FROM TB_CM_ACTUAL_SALES S
                    INNER JOIN TB_DP_ACCOUNT_MST  AM ON S.ACCOUNT_ID=AM.ID
                    INNER JOIN TB_CM_ITEM_MST	  IM ON S.ITEM_MST_ID=IM.ID
                    INNER JOIN TB_CM_CALENDAR     CL ON CL.DAT = S.BASE_DATE
                    WHERE S.BASE_DATE BETWEEN p_FROM_DATE AND v_TO_DATE
                    GROUP BY AM.ACCOUNT_CD, AM.ACCOUNT_NM, IM.ITEM_CD, IM.ITEM_NM, S.BASE_DATE
            ),
            ACT_SALES AS (
                SELECT ITEM_CD
                     , ITEM_NM
                     , ACCOUNT_CD
                     , ACCOUNT_NM
                     , B.MIN_DAT BASE_DATE
                     , SUM(QTY) QTY
                  FROM SALES A
                 INNER JOIN CAL B ON A.YYYY = B.YYYY AND A.MM = B.MM AND A.DP_WK = B.DP_WK
                 GROUP BY ITEM_CD, ITEM_NM, ACCOUNT_CD, ACCOUNT_NM, B.MIN_DAT
                 --ORDER BY B.MIN_DAT
            )
            , FINAL AS (
                    SELECT F.VER_CD
                         , F.ITEM_CD
                         , F.ACCOUNT_CD
                         , F.BASE_DATE BASE_DATE
                         , SUM(F.QTY) QTY
                      FROM TB_BF_RT_FINAL F
                     WHERE F.VER_CD = p_VER_CD
                     GROUP BY F.VER_CD, ITEM_CD, ACCOUNT_CD, F.BASE_DATE
            ),
            WAPE AS (
            select A.ITEM_CD
                    , IH.ANCS_CD ITEM_LV_CD
                    , IH.ANCS_NM ITEM_LV_NM
                    , A.ACCOUNT_CD
                    , AH.ANCS_CD ACCT_LV_CD
                    , AH.ANCS_NM ACCT_LV_NM
                    , A.BASE_DATE
                    -- 예측
                    , A.QTY PREDICT
                    -- 실적
                    , B.QTY ACT_SALES
                    -- 개별정확도
                    , CASE WHEN B.QTY = 0 THEN 0 ELSE (CASE WHEN (1-ABS(A.QTY-B.QTY)/B.QTY) >= 0 THEN (1-ABS(A.QTY-B.QTY)/B.QTY)*100 ELSE 0 END) END WAPE
                    , IH.GRADE
                from FINAL A
                    INNER JOIN ACT_SALES B ON A.ITEM_CD=B.ITEM_CD AND A.ACCOUNT_CD=B.ACCOUNT_CD AND A.BASE_DATE = B.BASE_DATE
                    INNER JOIN TEMP_ACCT_HIER AH ON AH.DESC_CD = A.ACCOUNT_CD
                    INNER JOIN TEMP_ITEM_HIER IH ON IH.DESC_CD = A.ITEM_CD
            )
			SELECT 'N' || '-' || ITEM_LV_CD || '-' || ACCT_LV_CD AS GIA
					 , TO_CHAR(BASE_DATE, 'yyyy-mm-dd') AS "DATE"
					 , CASE WHEN SUM(ACT_SALES) = 0 THEN 0 ELSE SUM(WAPE*ACT_SALES)/SUM(ACT_SALES) END ACCRY
				  FROM WAPE
			     WHERE 1=1
 				   AND ITEM_LV_CD = p_ITEM_CD 
				   AND ACCT_LV_CD = p_ACCOUNT_CD 
				 GROUP BY ITEM_LV_CD, ACCT_LV_CD, BASE_DATE
				 ORDER BY ITEM_LV_CD, ACCT_LV_CD, BASE_DATE				
				;
		END IF;
    END IF;
    DELETE FROM TEMP_ITEM_LEVEL;
    DELETE FROM TEMP_SALES_LEVEL;
    DELETE FROM TEMP_ITEM_HIER;
    DELETE FROM TEMP_ACCT_HIER;
END;
/

