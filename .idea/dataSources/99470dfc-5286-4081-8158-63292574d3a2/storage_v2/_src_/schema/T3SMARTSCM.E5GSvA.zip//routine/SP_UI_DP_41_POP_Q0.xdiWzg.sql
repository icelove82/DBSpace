create PROCEDURE SP_UI_DP_41_POP_Q0(
    pRESULT OUT SYS_REFCURSOR
)IS

BEGIN
    OPEN pRESULT FOR
	SELECT REPLACE(REPLACE(MEASURE_CD, '_QTY', ''), '_AMT', '') AS MEASURE_CD
	  FROM TB_DP_MEASURE_MST
	 WHERE DP_YN = 'Y'
	    AND COALESCE(DEL_YN,'N') = 'N'
		AND SUBSTR(MEASURE_CD, -3) IN ('QTY','AMT')
        AND MEASURE_CD NOT IN ( SELECT COLUMN_NAME
                                  FROM ALL_TAB_COLUMNS
                                 WHERE OWNER = (SELECT USER FROM DUAL)
                                   AND TABLE_NAME = 'TB_DP_MEASURE_DATA'
                                   AND COLUMN_NAME NOT IN ('ITEM_MST_ID', 'ACCOUNT_ID', 'BASE_DATE', 'CREATE_BY', 'CREATE_DTTM', 'MODIFY_BY', 'MODIFY_DTTM', 'ID')
                                 GROUP BY COLUMN_NAME
        )
   GROUP BY REPLACE(REPLACE(MEASURE_CD, '_QTY', ''), '_AMT', '')
  ;
END;
/

