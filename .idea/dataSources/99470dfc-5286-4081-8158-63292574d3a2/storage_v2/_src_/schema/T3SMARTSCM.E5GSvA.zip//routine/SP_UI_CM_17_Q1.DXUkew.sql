create PROCEDURE                SP_UI_CM_17_Q1 (
    P_Q_TYPE                  IN VARCHAR2 := '',
    P_MODULE_ID               IN CHAR := '',
    P_SNRIO_VER_ID            IN VARCHAR2 := '',
    P_LANG_CD                 IN VARCHAR2 := '',
    PRESULT                   OUT SYS_REFCURSOR
)
IS
    V_MAX_VER_ID               VARCHAR2(50) := '';
    V_PLAN_SNRIO_MGMT_MST_ID   CHAR(32) := '';
    V_DMND_MODULE_ID           VARCHAR2(50) := '';
    V_DMND_VER_ID              VARCHAR2(50) := '';
    V_DMND_VER_CHK             CHAR(1) :=  'N';
    
BEGIN
    IF P_Q_TYPE = 'MAIN_INFO' THEN
        BEGIN
            SELECT MAX(A.MAIN_VER_ID) INTO V_MAX_VER_ID
              FROM TB_CM_CONBD_MAIN_VER_MST A,
                   TB_CM_PLAN_SNRIO_MGMT_MST B
             WHERE 1 = 1
               AND A.PLAN_SNRIO_MGMT_MST_ID = B.ID
               AND A.MODULE_ID = P_MODULE_ID
               AND 1 = CASE WHEN P_SNRIO_VER_ID IS NULL OR P_SNRIO_VER_ID = '' THEN 1
                            ELSE CASE WHEN B.SNRIO_VER_ID = P_SNRIO_VER_ID THEN 1
                       END END;
        EXCEPTION WHEN NO_DATA_FOUND
            THEN NULL;
        END;

        BEGIN
            SELECT B.COMN_CD INTO V_DMND_MODULE_ID
              FROM TB_CM_CONBD_MAIN_VER_MST C,
                   TB_CM_PLAN_SNRIO_MGMT_MST A
                    LEFT OUTER JOIN TB_AD_COMN_CODE B
                    ON A.DMND_MODULE_ID = B.ID
             WHERE 1 = 1
               AND C.PLAN_SNRIO_MGMT_MST_ID = A.ID
               AND C.MAIN_VER_ID = V_MAX_VER_ID
               AND C.MODULE_ID = P_MODULE_ID;
        EXCEPTION WHEN NO_DATA_FOUND
            THEN NULL;
        END;
        
        IF V_DMND_MODULE_ID = 'DP' THEN
            BEGIN
                SELECT B.VER_ID, CASE WHEN C.T3SERIES_VER_ID IS NULL THEN 'N' ELSE 'Y' END INTO V_DMND_VER_ID, V_DMND_VER_CHK
                  FROM TB_CM_CONBD_MAIN_VER_MST A
			           INNER JOIN TB_DP_CONTROL_BOARD_VER_MST B
				       ON B.ID = A.DMND_VER_ID
				       LEFT OUTER JOIN 
				       (SELECT DISTINCT T3SERIES_VER_ID FROM TB_CM_DEMAND_OVERVIEW) C
				       ON B.VER_ID = C.T3SERIES_VER_ID
                 WHERE 1=1
                   AND B.ID = A.DMND_VER_ID
                   AND A.MODULE_ID = P_MODULE_ID
                   AND A.MAIN_VER_ID = V_MAX_VER_ID;
            EXCEPTION WHEN NO_DATA_FOUND
                THEN NULL;
            END;
        ELSIF V_DMND_MODULE_ID = 'RP' THEN
            BEGIN
                SELECT MAX(A.SIMUL_VER_ID), 'Y' INTO V_DMND_VER_ID, V_DMND_VER_CHK
				  FROM TB_CM_CONBD_MAIN_VER_DTL A
					   INNER JOIN TB_CM_CONBD_MAIN_VER_MST B
					   ON B.ID = A.CONBD_MAIN_VER_MST_ID
					   INNER JOIN TB_AD_COMN_CODE C
					   ON C.ID = B.MODULE_ID
				 WHERE C.COMN_CD = 'RP'
				   AND A.CONFRM_YN = 'Y';
            EXCEPTION WHEN NO_DATA_FOUND
                THEN NULL;
            END;
        ELSE
            V_DMND_VER_ID := NULL;
            V_DMND_VER_CHK := 'Y';
        END IF;

        OPEN PRESULT FOR
        WITH TEMP_RST_DATA AS (
            SELECT 'ID' AS CONTROL_ITEM			,NULL AS VAL FROM DUAL UNION ALL
            SELECT 'MODULE_ID'					,NULL FROM DUAL UNION ALL
            SELECT 'MAIN_VER_ID'				,NULL FROM DUAL UNION ALL
            SELECT 'VER_DATE'					,NULL FROM DUAL UNION ALL
            SELECT 'DESCRIP'					,NULL FROM DUAL UNION ALL
            SELECT 'PLAN_HORIZ_STRT'			,NULL FROM DUAL UNION ALL
            SELECT 'PLAN_HORIZ_END'				,NULL FROM DUAL UNION ALL
            SELECT 'TIME_BUKT'					,NULL FROM DUAL UNION ALL
            SELECT 'DMND_VER_ID'				,NULL FROM DUAL UNION ALL
            SELECT 'DMND_VER'				    ,NULL FROM DUAL UNION ALL
            SELECT 'DMND_VER_CHK'			    ,NULL FROM DUAL UNION ALL
            SELECT 'PLAN_SNRIO_MGMT_MST_ID'   	,NULL FROM DUAL UNION ALL
            SELECT 'PLAN_SNRIO_MGMT_VER'		,NULL FROM DUAL UNION ALL
            SELECT 'PLAN_SNRIO_MGMT_MST_DESCP'	,NULL FROM DUAL
       )
       SELECT  NVL(B.CONTROL_ITEM, A.CONTROL_ITEM) AS CONTROL_ITEM
              ,NVL(B.VAL, A.VAL) AS VAL
         FROM TEMP_RST_DATA A
              LEFT OUTER JOIN 
              (
              SELECT  UNPVT.CONTROL_ITEM
                     ,TO_CHAR(UNPVT.VAL) AS VAL
                FROM (
                        SELECT
                            TO_CHAR(A.ID)                                       AS ID,
                            TO_CHAR(B.COMN_CD)                                  AS MODULE_ID,
                            TO_CHAR(A.MAIN_VER_ID)                              AS MAIN_VER_ID,
                            TO_CHAR(A.VER_DATE, 'YYYY-MM-DD HH24:MI:SS')        AS VER_DATE,
                            TO_CHAR(NVL(A.DESCRIP, ''))                         AS DESCRIP,
                            TO_CHAR(A.PLAN_HORIZ_STRT, 'YYYY-MM-DD')            AS PLAN_HORIZ_STRT,
                            TO_CHAR(A.PLAN_HORIZ_END, 'YYYY-MM-DD')             AS PLAN_HORIZ_END,
                            TO_CHAR(A.TIME_BUKT)                                AS TIME_BUKT,
                            TO_CHAR(A.DMND_VER_ID)                              AS DMND_VER_ID,
                            TO_CHAR(V_DMND_VER_ID)                              AS DMND_VER,
                            TO_CHAR(V_DMND_VER_CHK)                             AS DMND_VER_CHK,
                            TO_CHAR(A.PLAN_SNRIO_MGMT_MST_ID)                   AS PLAN_SNRIO_MGMT_MST_ID,
                            TO_CHAR((
                                SELECT X.SNRIO_VER_ID
                                  FROM TB_CM_PLAN_SNRIO_MGMT_MST X
                                 WHERE X.ID = A.PLAN_SNRIO_MGMT_MST_ID
                            ))                                                  AS PLAN_SNRIO_MGMT_VER,
                            TO_CHAR(NVL(C.DESCRIP, ''))                         AS PLAN_SNRIO_MGMT_MST_DESCP
						FROM TB_CM_CONBD_MAIN_VER_MST A 
							 LEFT OUTER JOIN TB_AD_COMN_CODE B 
						  ON (A.MODULE_ID = B.ID)
							 LEFT OUTER JOIN TB_CM_PLAN_SNRIO_MGMT_MST C 
						  ON (A.PLAN_SNRIO_MGMT_MST_ID = C.ID)
					   WHERE 1=1
						 AND A.MODULE_ID = P_MODULE_ID
						 AND A.MAIN_VER_ID = V_MAX_VER_ID
                    ) A 
                    UNPIVOT ( 
                            VAL FOR CONTROL_ITEM IN ( 
                                                     ID,
                                                     MODULE_ID,
                                                     MAIN_VER_ID,
                                                     VER_DATE,
                                                     DESCRIP,
                                                     PLAN_HORIZ_STRT,
                                                     PLAN_HORIZ_END,
                                                     TIME_BUKT,
                                                     DMND_VER_ID,
                                                     DMND_VER,
                                                     DMND_VER_CHK,
                                                     PLAN_SNRIO_MGMT_MST_ID,
                                                     PLAN_SNRIO_MGMT_VER,
                                                     PLAN_SNRIO_MGMT_MST_DESCP 
                                                    ) 
                            ) UNPVT
            ) B 
            ON (A.CONTROL_ITEM = B.CONTROL_ITEM);

    ELSIF P_Q_TYPE = 'MODULE' THEN
        OPEN PRESULT FOR
        SELECT  B.ID
               ,B.COMN_CD
          FROM  TB_AD_COMN_GRP A   
               ,TB_AD_COMN_CODE B  
         WHERE 1=1
           AND A.ID = B.SRC_ID
           AND A.GRP_CD = 'MODULE_TP'
           AND A.USE_YN = 'Y';
                
    ELSIF P_Q_TYPE = 'MAX_MAIN_VER' THEN
        OPEN PRESULT FOR
	    SELECT C.SNRIO_VER_ID, C.MAIN_VER_ID, C.DESCRIP 
	    FROM   (
               SELECT A.SNRIO_VER_ID,
                      ROW_NUMBER() OVER(PARTITION BY A.SNRIO_VER_ID ORDER BY B.MAIN_VER_ID DESC) AS ROW_INDEX,
                      B.MAIN_VER_ID,
                      A.DESCRIP,
                      A.ID	AS SNRIO_MGMT_MST_ID,
                      B.ID	AS CONBD_MAIN_VER_ID
                 FROM TB_CM_PLAN_SNRIO_MGMT_MST A,
                      TB_CM_CONBD_MAIN_VER_MST B
                WHERE 1 = 1
                  AND B.PLAN_SNRIO_MGMT_MST_ID = A.ID
                  AND A.ACTV_YN = 'Y'
                  AND A.MODULE_ID = P_MODULE_ID
               ) C
	   WHERE  ROW_INDEX = 1;
        
    ELSIF P_Q_TYPE = 'SNRIO_VER' THEN
        OPEN PRESULT FOR
        SELECT A.SNRIO_VER_ID
	          ,A.DESCRIP
	  	  	  ,A.ID
          FROM TB_CM_PLAN_SNRIO_MGMT_MST A
	     WHERE 1=1
		   AND A.ACTV_YN = 'Y'
		   AND A.MODULE_ID = P_MODULE_ID
        ORDER BY A.SNRIO_VER_ID;

    ELSIF P_Q_TYPE = 'STEP_INFO' THEN
        BEGIN
            SELECT MAX(A.MAIN_VER_ID) INTO V_MAX_VER_ID
              FROM TB_CM_CONBD_MAIN_VER_MST A
                  ,TB_CM_PLAN_SNRIO_MGMT_MST B
             WHERE 1=1
               AND A.PLAN_SNRIO_MGMT_MST_ID = B.ID
               AND A.MODULE_ID = P_MODULE_ID
               AND B.SNRIO_VER_ID = P_SNRIO_VER_ID;
        EXCEPTION WHEN NO_DATA_FOUND 
            THEN NULL;
        END;

        BEGIN
            SELECT A.PLAN_SNRIO_MGMT_MST_ID INTO V_PLAN_SNRIO_MGMT_MST_ID
              FROM TB_CM_CONBD_MAIN_VER_MST A 
             WHERE 1=1
               AND A.MODULE_ID = P_MODULE_ID
               AND A.MAIN_VER_ID = V_MAX_VER_ID;
        EXCEPTION WHEN NO_DATA_FOUND 
            THEN V_PLAN_SNRIO_MGMT_MST_ID := NULL;
        END;
        
        DELETE FROM TEMP_CONBD_STEP_HIST;
		INSERT INTO TEMP_CONBD_STEP_HIST
		(
			PLAN_SNRIO_MGMT_MST_ID
		   ,PLAN_SNRIO_MGMT_DTL_ID
		   ,STEP
		   ,PROCESS_TP_ID
		   ,SIMUL_VER_ID
		   ,CONFRM_YN
		   ,LOAD_STRT_DTTM
		   ,LOAD_END_DTTM
		   ,PLAN_STRT_DTTM
		   ,PLAN_END_DTTM
		   ,STRT_DTTM
		   ,END_DTTM
		   ,ELAPSED_TIME
		   ,STEP_STATUS_ID
		   ,STEP_STATUS_NM
		   ,EXE_STATUS_ID
		   ,EXE_STATUS_NM
		   ,CONBD_MAIN_VER_DTL_ID
		   ,CONBD_MAIN_VER_MST_ID
		   ,MODULE_CD
		   ,MAIN_VER_ID
		   ,MAIN_VER_DESCRIP
		   ,UI_ID_01
		   ,UI_ID_02
		   ,UI_ID_03
		   ,UI_ID_04
		   ,UI_ID_05
		)
		SELECT  A.PLAN_SNRIO_MGMT_MST_ID
			   ,B.PLAN_SNRIO_MGMT_DTL_ID
			   ,C.STEP
			   ,C.PROCESS_TP_ID
			   ,B.SIMUL_VER_ID
			   ,B.CONFRM_YN
			   ,B.LOAD_STRT_DTTM
			   ,B.LOAD_END_DTTM
			   ,B.PLAN_STRT_DTTM
			   ,B.PLAN_END_DTTM
			   ,B.STRT_DTTM
			   ,B.END_DTTM
			   ,B.ELAPSED_TIME
			   ,B.STEP_STATUS_ID
			   ,D.COMN_CD_NM AS STEP_STATUS_NM
			   ,B.EXE_STATUS_ID
			   ,E.COMN_CD_NM AS EXE_STATUS_NM
			   ,B.ID AS CONBD_MAIN_VER_DTL_ID
			   ,B.CONBD_MAIN_VER_MST_ID
			   ,F.COMN_CD MODULE_CD
			   ,A.MAIN_VER_ID
			   ,A.DESCRIP AS MAIN_VER_DESCRIP
			   ,C.UI_ID_01
			   ,C.UI_ID_02
			   ,C.UI_ID_03
			   ,C.UI_ID_04
			   ,C.UI_ID_05
		  FROM  TB_CM_CONBD_MAIN_VER_MST A
			   ,TB_CM_CONBD_MAIN_VER_DTL B
			   ,TB_CM_PLAN_SNRIO_MGMT_DTL C
			   ,TB_AD_COMN_CODE D
			   ,TB_AD_COMN_CODE E
			   ,TB_AD_COMN_CODE F
		 WHERE 1=1
		   AND A.MODULE_ID = P_MODULE_ID
		   AND A.MAIN_VER_ID = V_MAX_VER_ID
		   AND A.ID = B.CONBD_MAIN_VER_MST_ID
		   AND B.PLAN_SNRIO_MGMT_DTL_ID = C.ID
		   AND B.STEP_STATUS_ID = D.ID
		   AND B.EXE_STATUS_ID = E.ID
		   AND A.MODULE_ID = F.ID;

        DELETE FROM TEMP_PROCESS_STEP_INFO;
		INSERT INTO TEMP_PROCESS_STEP_INFO
		(
			PLAN_SNRIO_MGMT_MST_ID
		   ,PLAN_SNRIO_MGMT_DTL_ID
		   ,STEP
		   ,PROCESS_TP
		   ,PROCESS_TP_ID
		   ,PROCESS_DESCRIP
		   ,PROCESS_TP_NM
		   ,CONFRM_MTD_ID
		   ,CONFRM_MTD_NM
		   ,PLAN_POLICY_MGMT_ID
		   ,UI_ID
		   ,PROC_NM
		   ,SNRIO_VER_ID
		   ,SNRIO_VER_DESCRIP
		)
		SELECT  A.ID AS PLAN_SNRIO_MGMT_MST_ID
			   ,B.ID AS PLAN_SNRIO_MGMT_DTL_ID
			   ,B.STEP
			   ,C.COMN_CD
			   ,B.PROCESS_TP_ID
			   ,B.PROCESS_DESCRIP
			   ,C.COMN_CD_NM AS PROCESS_TP_NM
			   ,B.CONFRM_MTD_ID
			   ,(
				 SELECT X.COMN_CD_NM
				   FROM TB_AD_COMN_CODE X
				  WHERE 1=1
					AND X.ID = B.CONFRM_MTD_ID
				) AS CONFRM_MTD_NM
			   ,B.PLAN_POLICY_MGMT_ID
			   ,B.UI_ID
			   ,B.PROC AS PROC_NM
			   ,A.SNRIO_VER_ID
			   ,A.DESCRIP AS SNRIO_VER_DESCRIP
		  FROM  TB_CM_PLAN_SNRIO_MGMT_MST A
			   ,TB_CM_PLAN_SNRIO_MGMT_DTL B
			   ,TB_AD_COMN_CODE           C
		 WHERE 1=1
		   AND A.ID = B.PLAN_SNRIO_MGMT_MST_ID
		   AND A.ID = V_PLAN_SNRIO_MGMT_MST_ID
		   AND B.PROCESS_TP_ID = C.ID;

        DELETE FROM TEMP_PLAN_POLCY_INFO;
		INSERT INTO TEMP_PLAN_POLCY_INFO
		(
			PLAN_POLICY_MGMT_ID    
		   ,PLAN_POLICY_VER_ID		
		   ,PLAN_POLICY_VER_DESCRIP
           ,PLAN_POLICY_TYPE
		)
		SELECT  A.ID AS PLAN_POLICY_MGMT_ID
			   ,A.VER_ID AS PLAN_POLICY_VER_ID
			   ,B.PLAN_POLICY_VAL_01 AS PLAN_POLICY_VER_DESCRIP
			   ,F.PLAN_POLICY_NM
		  FROM  TB_CM_PLAN_POLICY_MGMT A
			   ,TB_CM_PLAN_POLICY_VALUE B
			   ,TB_CM_PLAN_POLICY_MST C
			   ,TB_CM_PLAN_POLICY_VALUE D
			   ,TB_CM_PLAN_POLICY_MST E
			   ,TB_CM_PLAN_POLICY_DTL F
		 WHERE 1=1
		   AND A.ID = B.PLAN_POLICY_MGMT_ID
		   AND B.PLAN_POLICY_MST_ID = C.ID
		   AND C.PLAN_POLICY_ITEM_ID = 'M00020000'
		   AND A.ID = D.PLAN_POLICY_MGMT_ID
		   AND D.PLAN_POLICY_MST_ID = E.ID
		   AND D.PLAN_POLICY_DTL_ID = F.ID
		   AND F.PLAN_POLICY_MST_ID = E.ID
		   AND E.PLAN_POLICY_ITEM_ID = 'M00030000'
		   AND A.ACTV_YN = 'Y';

        DELETE FROM TEMP_CONBD_STEP_HIST_RST;
		INSERT INTO TEMP_CONBD_STEP_HIST_RST
		(
			PLAN_SNRIO_MGMT_MST_ID
		   ,PLAN_SNRIO_MGMT_DTL_ID
		   ,STEP                  
		   ,PROCESS_TP_ID         
		   ,SIMUL_VER_ID          
		   ,CONFRM_YN  
		   ,LOAD_STRT_DTTM
		   ,LOAD_END_DTTM
		   ,PLAN_STRT_DTTM
		   ,PLAN_END_DTTM
		   ,STRT_DTTM
		   ,END_DTTM
		   ,ELAPSED_TIME
		   ,STEP_STATUS_ID 
		   ,STEP_STATUS_NM        
		   ,EXE_STATUS_ID    
		   ,EXE_STATUS_NM  
		   ,SNRIO_CNT
		   ,MAX_SIMUL_VER_ID
		   ,CONFRM_SIMUL_VER_ID
		   ,CONBD_MAIN_VER_DTL_ID
		   ,CONBD_MAIN_VER_MST_ID
		   ,MODULE_CD
		   ,MAIN_VER_ID
		   ,MAIN_VER_DESCRIP
		   ,UI_ID_01
		   ,UI_ID_02
		   ,UI_ID_03
		   ,UI_ID_04
		   ,UI_ID_05
		)
		SELECT  A.PLAN_SNRIO_MGMT_MST_ID
			   ,A.PLAN_SNRIO_MGMT_DTL_ID
			   ,A.STEP                  
			   ,A.PROCESS_TP_ID         
			   ,A.SIMUL_VER_ID
			   ,A.CONFRM_YN  
			   ,A.LOAD_STRT_DTTM
			   ,A.LOAD_END_DTTM
			   ,A.PLAN_STRT_DTTM
			   ,A.PLAN_END_DTTM
			   ,A.STRT_DTTM
			   ,A.END_DTTM
			   ,A.ELAPSED_TIME
			   ,A.STEP_STATUS_ID 
			   ,A.STEP_STATUS_NM     
			   ,A.EXE_STATUS_ID    
			   ,A.EXE_STATUS_NM
			   ,A.SNRIO_CNT
			   ,A.SIMUL_VER_ID
			   ,B.CONFRM_SIMUL_VER_ID
			   ,A.CONBD_MAIN_VER_DTL_ID
			   ,A.CONBD_MAIN_VER_MST_ID
			   ,A.MODULE_CD
			   ,A.MAIN_VER_ID
			   ,A.MAIN_VER_DESCRIP
			   ,A.UI_ID_01
			   ,A.UI_ID_02
			   ,A.UI_ID_03
			   ,A.UI_ID_04
			   ,A.UI_ID_05
		  FROM (
				SELECT  A.PLAN_SNRIO_MGMT_MST_ID
					   ,A.PLAN_SNRIO_MGMT_DTL_ID
					   ,A.STEP
					   ,A.PROCESS_TP_ID
					   ,A.SIMUL_VER_ID
					   ,A.CONFRM_YN
					   ,A.LOAD_STRT_DTTM
					   ,A.LOAD_END_DTTM
					   ,A.PLAN_STRT_DTTM
					   ,A.PLAN_END_DTTM
					   ,A.STRT_DTTM
					   ,A.END_DTTM
					   ,A.ELAPSED_TIME
					   ,A.STEP_STATUS_ID
					   ,A.STEP_STATUS_NM
					   ,A.EXE_STATUS_ID
					   ,A.EXE_STATUS_NM
					   ,ROW_NUMBER() OVER (PARTITION BY A.PLAN_SNRIO_MGMT_MST_ID, A.PLAN_SNRIO_MGMT_DTL_ID ORDER BY A.SIMUL_VER_ID DESC) AS RN
					   ,COUNT(*) OVER (PARTITION BY A.PLAN_SNRIO_MGMT_MST_ID, A.PLAN_SNRIO_MGMT_DTL_ID) AS SNRIO_CNT
					   ,A.CONBD_MAIN_VER_DTL_ID
					   ,A.CONBD_MAIN_VER_MST_ID
					   ,A.MODULE_CD
					   ,A.MAIN_VER_ID
					   ,A.MAIN_VER_DESCRIP
					   ,A.UI_ID_01
					   ,A.UI_ID_02
					   ,A.UI_ID_03
					   ,A.UI_ID_04
					   ,A.UI_ID_05
				  FROM TEMP_CONBD_STEP_HIST A
			   ) A
			   LEFT OUTER JOIN 
			   (
				SELECT  A.PLAN_SNRIO_MGMT_MST_ID
					   ,A.PLAN_SNRIO_MGMT_DTL_ID
					   ,MAX(A.SIMUL_VER_ID) AS CONFRM_SIMUL_VER_ID
				  FROM TEMP_CONBD_STEP_HIST A
				 WHERE 1=1
				   AND A.CONFRM_YN = 'Y'
				 GROUP BY  A.PLAN_SNRIO_MGMT_MST_ID
						,A.PLAN_SNRIO_MGMT_DTL_ID
			   ) B
			   ON ( A.PLAN_SNRIO_MGMT_MST_ID = B.PLAN_SNRIO_MGMT_MST_ID
				AND A.PLAN_SNRIO_MGMT_DTL_ID = B.PLAN_SNRIO_MGMT_DTL_ID
			   )
         WHERE 1=1
           AND A.RN = 1;

        OPEN PRESULT FOR
		SELECT   A.PLAN_SNRIO_MGMT_MST_ID
				,A.PLAN_SNRIO_MGMT_DTL_ID
				,A.PROC_NM
				,A.STEP
				,A.PROCESS_TP_ID
				,A.PROCESS_TP
				,A.PROCESS_DESCRIP
				,A.PROCESS_TP_NM
				,A.CONFRM_MTD_ID
				,A.CONFRM_MTD_NM
				,B.PLAN_POLICY_MGMT_ID
				,B.PLAN_POLICY_VER_ID
				,B.PLAN_POLICY_VER_DESCRIP
				,B.PLAN_POLICY_TYPE
				,C.EXE_STATUS_ID
				,C.EXE_STATUS_NM
				,A.UI_ID
				,C.LOAD_STRT_DTTM
				,C.LOAD_END_DTTM
				,C.PLAN_STRT_DTTM
				,C.PLAN_END_DTTM
				,C.STRT_DTTM
				,C.END_DTTM
				,C.ELAPSED_TIME AS ING_DTTM
				,C.STEP_STATUS_ID 
				,C.STEP_STATUS_NM
				,C.SNRIO_CNT
				,C.MAX_SIMUL_VER_ID
				,C.CONFRM_SIMUL_VER_ID
				,C.CONBD_MAIN_VER_DTL_ID
				,C.CONBD_MAIN_VER_MST_ID
				,C.UI_ID_01
				,C.UI_ID_02
				,C.UI_ID_03
				,C.UI_ID_04
				,C.UI_ID_05
				,D.MENU_NM		AS UI_NM_01
				,D.MENU_CD		AS URL_01
				,E.MENU_NM		AS UI_NM_02
				,E.MENU_CD		AS URL_02
				,F.MENU_NM		AS UI_NM_03
				,F.MENU_CD		AS URL_03
				,G.MENU_NM		AS UI_NM_04
				,G.MENU_CD		AS URL_04
				,H.MENU_NM		AS UI_NM_05
				,H.MENU_CD		AS URL_05
			FROM TEMP_PROCESS_STEP_INFO A
				LEFT OUTER JOIN 
				TEMP_PLAN_POLCY_INFO B
			ON (A.PLAN_POLICY_MGMT_ID = B.PLAN_POLICY_MGMT_ID)
				LEFT OUTER JOIN
				TEMP_CONBD_STEP_HIST_RST C
			ON (A.PLAN_SNRIO_MGMT_MST_ID = C.PLAN_SNRIO_MGMT_MST_ID
				AND A.PLAN_SNRIO_MGMT_DTL_ID = C.PLAN_SNRIO_MGMT_DTL_ID)
				LEFT OUTER JOIN
				(
				SELECT	A.ID,
						A.MENU_PATH  AS MENU_CD,
						B.LANG_VALUE AS MENU_NM
				FROM	TB_AD_MENU A,
						TB_AD_LANG_PACK B
				WHERE	A.MENU_CD = B.LANG_KEY
				AND		B.LANG_CD = P_LANG_CD
				) D
			ON (C.UI_ID_01 = D.ID)
				LEFT OUTER JOIN
				(
				SELECT	A.ID,
						A.MENU_PATH  AS MENU_CD,
						B.LANG_VALUE AS MENU_NM
				FROM	TB_AD_MENU A,
						TB_AD_LANG_PACK B
				WHERE	A.MENU_CD = B.LANG_KEY
				AND		B.LANG_CD = P_LANG_CD
				) E
			ON (C.UI_ID_02 = E.ID)
				LEFT OUTER JOIN
				(
				SELECT	A.ID,
						A.MENU_PATH  AS MENU_CD,
						B.LANG_VALUE AS MENU_NM
				FROM	TB_AD_MENU A,
						TB_AD_LANG_PACK B
				WHERE	A.MENU_CD = B.LANG_KEY
				AND		B.LANG_CD = P_LANG_CD
				) F
			ON (C.UI_ID_03 = F.ID)
				LEFT OUTER JOIN
				(
				SELECT	A.ID,
						A.MENU_PATH  AS MENU_CD,
						B.LANG_VALUE AS MENU_NM
				FROM	TB_AD_MENU A,
						TB_AD_LANG_PACK B
				WHERE	A.MENU_CD = B.LANG_KEY
				AND		B.LANG_CD = P_LANG_CD
				) G
			ON (C.UI_ID_04 = G.ID)
				LEFT OUTER JOIN
				(
				SELECT	A.ID,
						A.MENU_PATH  AS MENU_CD,
						B.LANG_VALUE AS MENU_NM
				FROM	TB_AD_MENU A,
						TB_AD_LANG_PACK B
				WHERE	A.MENU_CD = B.LANG_KEY
				AND		B.LANG_CD = P_LANG_CD
				) H
			ON (C.UI_ID_05 = H.ID)
		ORDER BY A.STEP;
        
    END IF;
    
END;
/

