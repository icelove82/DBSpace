create PROCEDURE                "SP_UI_DP_18_DIMENS_COL_COMBO"(
    pRESULT OUT SYS_REFCURSOR
)IS 

BEGIN
/*****************************************************************************
TITLE : [SP_UI_DP_18_DIMENS_COL_COMBO]
 
설명 
 -  SP_UI_DP_18_DIMENSION_COLUMN_COMBO

HISTORY (수정일자 / 수정자 / 수정내용)
- 2022.01.06 / kim sohee / SALES_LV_YN 조건 추가
*****************************************************************************/
OPEN pRESULT          
FOR 
WITH DP_CONF
AS (
	 SELECT ID 
		   ,CONF_GRP_CD 
		   ,CONF_CD
		   ,CONF_NM 
	   FROM TB_CM_COMM_CONFIG
	  WHERE CONF_GRP_CD = 'DP_LV_TP'
	    AND ACTV_YN = 'Y' 
 ), TB_COL
AS (
        SELECT CM.COLUMN_NAME    AS COLUMN_NAME
             , CM.COMMENTS       AS DESCRIPTION
             , 'Y'               AS ACCOUNT_LV_YN
             , 'N'               AS LEAF_YN
             , 'Y'               AS SALES_LV_YN
          FROM USER_COL_COMMENTS CM
         WHERE TABLE_NAME = 'TB_DP_SALES_LEVEL_MGMT'
           AND COLUMN_NAME LIKE 'SALES_LV%'
        UNION
        SELECT CM.COLUMN_NAME    AS COLUMN_NAME
             , CM.COMMENTS       AS DESCRIPTION
             , 'N'               AS ACCOUNT_LV_YN
             , 'N'               AS LEAF_YN
             , 'N'               AS SALES_LV_YN 
          FROM USER_COL_COMMENTS CM
         WHERE TABLE_NAME = 'TB_CM_ITEM_LEVEL_MGMT'
           AND COLUMN_NAME LIKE 'ITEM_LV%'
        UNION
        SELECT CM.COLUMN_NAME    AS COLUMN_NAME
             , CM.COMMENTS       AS DESCRIPTION
             , CASE WHEN TABLE_NAME LIKE '%ACCOUNT%' THEN 'Y' ELSE 'N' END AS ACCOUNT_LV_YN
             , 'Y'               AS LEAF_YN
             , 'N'               AS SALES_LV_YN 
          FROM USER_COL_COMMENTS CM
         WHERE TABLE_NAME IN ('TB_DPD_ITEM_HIERACHY2', 'TB_DPD_ACCOUNT_HIERACHY2')
           AND COLUMN_NAME NOT LIKE 'LVL_%'      
 ), DMND_CUSTOM
AS (
	SELECT CONF_GRP_CD		AS GRP_CD
		 , CONF_CD			AS COLUMN_NAME
		 , CC.CONF_ID		AS GRP_ID 
		 , LP.LANG_VALUE    AS DESCRIP
	  FROM TB_CM_COMM_CONFIG CC
		   INNER JOIN 
		   TB_AD_LANG_PACK LP
		ON CC.CONF_NM = LP.LANG_KEY 
	   AND LANG_CD = 'en'
	 WHERE CONF_GRP_CD = 'DP_DMND_CUSTOM'
	   AND ACTV_YN = 'Y' 
 )
 	SELECT LV_TP_ID		
		  ,CC.CONF_CD		AS LV_TP_CD	
		  ,CC.CONF_CD		AS LV_TP_NM
		  ,LV.ID			AS LV_MGMT_ID 		  
		  ,LV_NM			AS LV_MGMT_NM 
		  ,TC.COLUMN_NAME	AS COL_NM
		  ,TC.COLUMN_NAME || CASE WHEN TC.DESCRIPTION IS NULL THEN ' ' ELSE ' ('||TC.DESCRIPTION||')' END  AS COL_DESC
	  FROM TB_CM_LEVEL_MGMT LV 
		   INNER JOIN 
		   DP_CONF CC
		ON LV.LV_TP_ID = CC.ID 
		   INNER JOIN 
		   TB_COL TC
		ON (LV.LEAF_YN = TC.LEAF_YN 
	   AND LV.LEAF_YN = TC.LEAF_YN 
	   AND LV.ACCOUNT_LV_YN = TC.ACCOUNT_LV_YN
       AND LV.SALES_LV_YN = TC.SALES_LV_YN)	  
	 WHERE 1=1
	   AND LV.ACTV_YN = 'Y'
	   AND COALESCE(LV.DEL_YN,'N') = 'N'
UNION 
 SELECT GRP_ID
	   ,GRP_CD
	   ,'C'
	   ,GRP_ID
	   ,GRP_CD
	   ,COLUMN_NAME  
	   ,DESCRIP
   FROM DMND_CUSTOM 
;
/*
SELECT   A.ID       AS LV_MGMT_ID
        ,A.LV_NM    AS LV_MGMT_NM
        ,A.COULMN   AS COL_NM
        ,CASE WHEN A.HINT_NM IS NULL THEN A.COULMN ELSE A.COULMN || ' (' || TO_CHAR(A.HINT_NM) ||')' END    AS COL_DESC
FROM    (
        SELECT  CON.CONF_CD, LV.ID, LV.LV_NM, LV.SEQ, TBL.COLUMN_NAME AS COULMN, TBL.DESCRIPTION AS HINT_NM
        FROM    TB_CM_COMM_CONFIG CON 
                INNER JOIN TB_CM_LEVEL_MGMT LV  ON CON.ID = LV.LV_TP_ID
                INNER JOIN (
                            SELECT  A.COLUMN_NAME      AS COLUMN_NAME
                                   ,B.COMMENTS         AS DESCRIPTION
                              FROM SYS.ALL_TAB_COLUMNS A
                                   INNER JOIN
                                   ALL_TAB_COMMENTS B
                                ON (A.OWNER = B.OWNER AND A.TABLE_NAME = B.TABLE_NAME)
                             WHERE 1=1
                               AND A.OWNER IN (                                   
                                SELECT USERNAME
                                  FROM user_users
                               )
                               AND a.TABLE_NAME = 'TB_DP_SALES_LEVEL_MGMT'
                            ) TBL ON 1=1
        WHERE   CON.CONF_GRP_CD = 'DP_LV_TP'
        AND     CON.CONF_CD        = 'S'            -- SALES HIERARCHY LEVEL 
        AND     CON.ACTV_YN        = 'Y'
        AND     LV.SALES_LV_YN     = 'Y'
--        AND        LV.LEAF_YN        = 'N'            -- ?？LEVEL?？?？
        AND     LV.ACCOUNT_LV_YN = 'Y'
        AND     LV.ACTV_YN        = 'Y'
        AND     COALESCE(LV.DEL_YN, 'N')        = 'N'
        UNION ALL 
        SELECT  CON.CONF_CD, LV.ID, LV.LV_NM, LV.SEQ, TBL.COLUMN_NAME AS COULMN, TBL.DESCRIPTION AS HINT_NM
        FROM    TB_CM_COMM_CONFIG CON 
                INNER JOIN TB_CM_LEVEL_MGMT LV  ON CON.ID = LV.LV_TP_ID
                INNER JOIN (
                            SELECT A.COLUMN_NAME      AS COLUMN_NAME
                                 , B.COMMENTS         AS DESCRIPTION
                              FROM SYS.ALL_TAB_COLUMNS A
                                   INNER JOIN
                                   ALL_TAB_COMMENTS B
                                ON (A.OWNER = B.OWNER AND A.TABLE_NAME = B.TABLE_NAME)
                             WHERE 1=1
                               AND A.OWNER IN (                                   
                                SELECT USERNAME
                                FROM user_users
                               )
                               AND A.TABLE_NAME = 'TB_DP_ACCOUNT_MST'                    
                            ) TBL ON 1=1
        WHERE   CON.CONF_GRP_CD = 'DP_LV_TP'
        AND     CON.CONF_CD     = 'S'            -- SALES HIERARCHY LEVEL 
        AND     CON.ACTV_YN     = 'Y'
        AND     COALESCE(LV.SALES_LV_YN,'N') = 'N'
--        AND        LV.LEAF_YN        = 'Y'            -- ?????? LEVEL?？?？
        AND     LV.ACCOUNT_LV_YN = 'Y'
        AND     LV.ACTV_YN = 'Y'
        AND     COALESCE(LV.DEL_YN, 'N') = 'N'
		UNION ALL -- MAP_USERNAME
		SELECT	CON.CONF_CD, LV.ID, LV.LV_NM, LV.SEQ, 'MAP_USERID' AS COULMN, 'MAP_USERID' AS HINT_NM
		FROM	TB_CM_COMM_CONFIG CON 
				INNER JOIN TB_CM_LEVEL_MGMT LV  ON CON.ID = LV.LV_TP_ID
		WHERE	CON.CONF_GRP_CD = 'DP_LV_TP'
		AND		CON.CONF_CD		= 'S'			
		AND		CON.ACTV_YN		= 'Y'
		AND		COALESCE(LV.SALES_LV_YN,'N') ='N'
		AND		LV.ACCOUNT_LV_YN = 'Y'
		AND		LV.ACTV_YN		= 'Y'
		AND     COALESCE(LV.DEL_YN,'N') = 'N'
		UNION ALL -- MAP_USERNAME
		SELECT	CON.CONF_CD, LV.ID, LV.LV_NM, LV.SEQ, 'MAP_USERNAME' AS COULMN, 'MAP_USERNAME' AS HINT_NM
		FROM	TB_CM_COMM_CONFIG CON 
				INNER JOIN TB_CM_LEVEL_MGMT LV  ON CON.ID = LV.LV_TP_ID
		WHERE	CON.CONF_GRP_CD = 'DP_LV_TP'
		AND		CON.CONF_CD		= 'S'			
		AND		CON.ACTV_YN		= 'Y'
		AND		COALESCE(LV.SALES_LV_YN,'N') ='N'
		AND		LV.ACCOUNT_LV_YN = 'Y'
		AND		LV.ACTV_YN		= 'Y'
		AND     COALESCE(LV.DEL_YN,'N') = 'N'            
        UNION ALL
        SELECT    CON.CONF_CD, LV.ID, LV.LV_NM, LV.SEQ, TBL.COLUMN_NAME AS COULMN, TBL.DESCRIPTION AS HINT_NM
        FROM    TB_CM_COMM_CONFIG CON 
                INNER JOIN TB_CM_LEVEL_MGMT LV  ON CON.ID = LV.LV_TP_ID
                INNER JOIN (
                           SELECT A.COLUMN_NAME      AS COLUMN_NAME
                                , B.COMMENTS         AS DESCRIPTION
                             FROM SYS.ALL_TAB_COLUMNS A
                                  INNER JOIN
                                  ALL_TAB_COMMENTS B
                               ON (A.OWNER = B.OWNER AND A.TABLE_NAME = B.TABLE_NAME)
                            WHERE 1=1
                              AND A.OWNER IN (                                   
                                SELECT USERNAME
                                FROM user_users
                              )
                              AND A.TABLE_NAME = 'TB_CM_ITEM_LEVEL_MGMT'                    
                            ) TBL ON 1=1
        WHERE   CON.CONF_GRP_CD = 'DP_LV_TP'
        AND     CON.CONF_CD     = 'I'            
        AND     CON.ACTV_YN     = 'Y'
        AND     LV.LEAF_YN      = 'N'            
        AND     LV.ACTV_YN      = 'Y'
        AND     COALESCE(LV.DEL_YN, 'N') = 'N'
        UNION ALL 
        SELECT  CON.CONF_CD, LV.ID, LV.LV_NM, LV.SEQ, TBL.COLUMN_NAME AS COULMN, TBL.DESCRIPTION AS HINT_NM
        FROM    TB_CM_COMM_CONFIG CON
                INNER JOIN TB_CM_LEVEL_MGMT LV  ON CON.ID = LV.LV_TP_ID
                INNER JOIN (
                           SELECT A.COLUMN_NAME      AS COLUMN_NAME
                                , B.COMMENTS         AS DESCRIPTION
                             FROM SYS.ALL_TAB_COLUMNS A
                                  INNER JOIN
                                  ALL_TAB_COMMENTS B
                               ON (A.OWNER = B.OWNER AND A.TABLE_NAME = B.TABLE_NAME)
                            WHERE 1=1
                              AND A.OWNER IN (                                   
                                SELECT USERNAME
                                FROM user_users
                              )
                              AND A.TABLE_NAME = 'TB_CM_ITEM_MST'                
                            ) TBL ON 1=1
        WHERE   CON.CONF_GRP_CD = 'DP_LV_TP'
        AND     CON.CONF_CD     = 'I'            -- ITEM HIERARCHY LEVEL 
        AND     CON.ACTV_YN     = 'Y'
        AND     LV.LEAF_YN      = 'Y'            -- ?????? LEVEL?？?？
        AND     LV.ACTV_YN      = 'Y'
        AND     COALESCE(LV.DEL_YN, 'N') = 'N'
        UNION
        SELECT G.CONF_NM                            AS CONF_CD
             , G.ID                                 AS LV_MGMT_ID
             , COALESCE(L1.LANG_VALUE, G.DESCRIP)   AS LV_MGMT_NM
             , 99                                   AS SEQ
             , C.CONF_CD                            AS COULMN
             , COALESCE(L2.LANG_VALUE, C.CONF_NM)   AS HINT_NM
          FROM TB_CM_CONFIGURATION G
         INNER JOIN TB_CM_COMM_CONFIG C
            ON G.ID = C.CONF_ID
          LEFT OUTER JOIN TB_AD_LANG_PACK L1
            ON L1.LANG_KEY = G.DESCRIP
           AND L1.LANG_CD = 'en'
          LEFT OUTER JOIN TB_AD_LANG_PACK L2
            ON C.CONF_NM = L2.LANG_KEY
           AND L2.LANG_CD = 'en'
         WHERE G.CONF_NM = 'DP_DMND_CUSTOM'
           AND C.ACTV_YN = 'Y'
    ) A
ORDER BY A.CONF_CD, A.SEQ;
*/


END
;
/

