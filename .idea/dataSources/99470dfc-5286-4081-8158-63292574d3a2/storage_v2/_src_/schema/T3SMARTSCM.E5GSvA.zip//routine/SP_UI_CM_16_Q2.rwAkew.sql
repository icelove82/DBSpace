create PROCEDURE "SP_UI_CM_16_Q2" (
    P_Q_TYPE            IN VARCHAR2 := '' ,
    P_VAL_01            IN VARCHAR2 := '' ,
    P_VAL_02            IN VARCHAR2 := '' ,
    P_LANG_CD			IN VARCHAR2 := '' ,
    pResult OUT SYS_REFCURSOR
)
IS
    P_TEMP_VAL01        VARCHAR2(100) := '';
    P_TEMP_VAL01_01     VARCHAR2(100) := '';
    P_TEMP_VAL01_02     VARCHAR2(100) := '';
    P_TEMP_VAL02        VARCHAR2(100) := '';
    P_TEMP_VAL          VARCHAR2(100) := '';
    NOT_DATA_FOUND      EXCEPTION;
    
BEGIN
    BEGIN
        SELECT A.COMN_CD INTO P_TEMP_VAL01
          FROM TB_AD_COMN_CODE A 
         WHERE A.ID=P_VAL_01;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN Null;
    END;

    IF P_Q_TYPE = 'BASE_LOV' 
    THEN
        BEGIN
            SELECT A.COMN_CD INTO P_TEMP_VAL
              FROM TB_AD_COMN_CODE A
             WHERE 1=1
               AND A.ID = P_VAL_01;
            EXCEPTION
            WHEN NO_DATA_FOUND THEN Null;
        END;
    
        OPEN pResult FOR 
           SELECT *
             FROM 
                (
                  SELECT CASE NVL(P_TEMP_VAL,'null') 
                              WHEN 'null'   THEN 'MODULE_TP' 
                              WHEN ''       THEN 'MODULE_TP' 
                              ELSE '' END AS GRP_CD
                        ,''			 AS ID
                        ,'ALL'		 AS COMN_CD
                        ,'All'		 AS COMN_CD_NM
                        , 0			 AS SEQ
                   FROM DUAL
                  UNION ALL
                  SELECT  TO_CHAR(A.GRP_CD)
                         ,B.ID
                         ,TO_CHAR(B.COMN_CD)
                         ,TO_CHAR(B.COMN_CD_NM)
                         ,B.SEQ
                    FROM  TB_AD_COMN_GRP A
                         ,TB_AD_COMN_CODE B
                   WHERE A.ID = B.SRC_ID 
                     AND B.USE_YN = 'Y'
                     AND CASE WHEN P_TEMP_VAL ='IM' AND B.COMN_CD = 'SPROC_05' THEN 1 ELSE 0 END = 0
                     AND CASE WHEN A.GRP_CD = 'MODULE_TP' AND NVL(B.ATTR_02_VAL,' ')  <> 'ENGINE' THEN 1 ELSE 0 END  = 0
                     AND A.GRP_CD IN ( 'SCENARIO_PROCESS_TP'
                                      ,'DAY_OF_WEEK'
                                      ,'DAY_OF_MONTH'
                                      ,'SCENARIO_CYCL_TP'
                                      ,'MODULE_TP'
                                     )
                ) A
            ORDER BY A.GRP_CD, A.SEQ;

    ELSIF P_Q_TYPE = 'EXTEND_LOV_01' AND P_TEMP_VAL01 IN ('SPROC_03','SPROC_05') 
    THEN
        SELECT B.COMN_CD INTO P_TEMP_VAL01_01
          FROM TB_AD_COMN_GRP A
               INNER JOIN 
               TB_AD_COMN_CODE B 
            ON (A.ID = B.SRC_ID)
        WHERE 1=1
            AND B.ID = P_VAL_01;

        SELECT B.COMN_CD_NM INTO P_TEMP_VAL02
          FROM TB_AD_COMN_GRP A
               INNER JOIN 
               TB_AD_COMN_CODE B 
            ON (A.ID = B.SRC_ID)
         WHERE 1=1
            AND B.ID = P_VAL_02;

        IF (P_TEMP_VAL01_01 = 'SPROC_03' AND P_TEMP_VAL02 = 'Inventory Management')
        THEN
            OPEN pResult FOR    
              SELECT  A.GRP_CD
                     ,B.ID
                     ,B.COMN_CD
                     ,B.COMN_CD_NM
                FROM  TB_AD_COMN_GRP A
                  INNER JOIN TB_AD_COMN_CODE B
                    ON A.ID = B.SRC_ID 
               WHERE 1=1
                 AND B.USE_YN = 'Y'
                 AND A.GRP_CD = 'SCENARIO_CONFRM_METHD'
                 AND B.COMN_CD = 'COMPARE'
              ORDER BY A.GRP_CD, B.SEQ;
        ELSE
            OPEN pResult FOR
            SELECT  A.GRP_CD
                   ,B.ID
                   ,B.COMN_CD
                   ,B.COMN_CD_NM
              FROM  TB_AD_COMN_GRP A
                INNER JOIN TB_AD_COMN_CODE B
                ON A.ID = B.SRC_ID 
            WHERE 1=1
                AND B.USE_YN = 'Y'
                AND A.GRP_CD = 'SCENARIO_CONFRM_METHD'
            ORDER BY A.GRP_CD, B.SEQ;
        END IF;

    ELSIF P_Q_TYPE = 'PROC_NM'
    THEN
        OPEN pResult FOR
        SELECT DISTINCT A.NAME AS PROC_NM
            FROM USER_SOURCE A
           WHERE 1=1
             AND A.TYPE = 'PROCEDURE'
         ORDER BY A.NAME;
         
    ELSIF P_Q_TYPE = 'EXTEND_LOV_01' AND P_TEMP_VAL01 NOT IN ('SPROC_03','SPROC_05')
    THEN
        OPEN pResult FOR
          SELECT  NULL GRP_CD
                 ,NULL ID
                 ,NULL COMN_CD
                 ,NULL COMN_CD_NM
            FROM dual;

    ELSIF P_Q_TYPE = 'CONFRM_PLAN_SNRIO'
    THEN
        OPEN pResult FOR
          SELECT  B.ID                                                      AS DTL_ID	
                 ,B.STEP													AS STEP				
                 ,B.PROCESS_DESCRIP											AS PROCESS_DESCRIP	
                 ,(																		 
                   SELECT  X.COMN_CD_NM													 
                     FROM TB_AD_COMN_CODE X 					 
                    WHERE 1=1																 
                      AND X.ID = B.PROCESS_TP_ID											 
                  )               											AS PROCESS_TP_NM	 
            FROM  TB_CM_PLAN_SNRIO_MGMT_MST A 
              INNER JOIN TB_CM_PLAN_SNRIO_MGMT_DTL B 
                ON A.ID = B.PLAN_SNRIO_MGMT_MST_ID
              INNER JOIN TB_AD_COMN_CODE C          
                ON B.PROCESS_TP_ID = C.ID
           WHERE 1=1
             AND C.COMN_CD IN ('SPROC_03','SPROC_05')
             AND A.ID = P_VAL_01
          ORDER BY A.ID, B.STEP;

    ELSIF P_Q_TYPE = 'UI_ID'
    THEN
        OPEN pResult FOR
         SELECT 
              A.ID		   AS MENU_ID
            , B.LANG_VALUE AS MENU_NM
            , D.LANG_VALUE AS PARENT_MENU_NM
            , A.MENU_PATH
            , A.CREATE_BY
            , A.CREATE_DTTM
            , A.MODIFY_BY
            , A.MODIFY_DTTM
         FROM TB_AD_MENU A
			  INNER JOIN TB_AD_LANG_PACK B
			  ON A.MENU_CD = B.LANG_KEY
			  INNER JOIN TB_AD_MENU C
			  ON C.ID = A.PARENT_ID
			  INNER JOIN TB_AD_LANG_PACK D
			  ON C.MENU_CD = D.LANG_KEY
		WHERE B.LANG_CD = P_LANG_CD
		  AND D.LANG_CD = P_LANG_CD
		  AND A.MENU_PATH IS NOT NULL
		  AND (A.MENU_CD LIKE '%_IM%' OR A.MENU_CD LIKE '%\_RP%' ESCAPE '\' OR A.MENU_CD LIKE '%_MP%')
		ORDER BY A.MENU_CD;

    ELSIF P_Q_TYPE = 'POLICY'   
    THEN
        BEGIN
            SELECT A.COMN_CD INTO P_TEMP_VAL
            FROM TB_AD_COMN_CODE A
            WHERE 1=1
            AND A.USE_YN ='Y'
            AND A.ID =P_VAL_02;
            EXCEPTION
            WHEN NO_DATA_FOUND THEN NULL;
        END;

        OPEN pResult FOR
          SELECT  A.ID
                 ,A.COMN_CD_NM          AS MODULE
                 ,A.VER_ID              AS PLAN_POLICY_VER_ID
                 ,B.PLAN_POLICY_VAL_01  AS DESCP
                 ,C.PLAN_POLICY_VAL_ID 
                 ,C.PLAN_POLICY_NM      AS PLAN_TYPE
            FROM (
                  SELECT A.ID
                        ,B.COMN_CD_NM
                        ,A.VER_ID
                   FROM  TB_CM_PLAN_POLICY_MGMT A 
                     INNER JOIN TB_CM_PLAN_POLICY_VALUE C  
                       ON A.ID = C.PLAN_POLICY_MGMT_ID
                     INNER JOIN TB_CM_PLAN_POLICY_MST D 
                       ON C.PLAN_POLICY_MST_ID = D.ID
                     INNER JOIN TB_AD_COMN_CODE B 
                       ON C.PLAN_POLICY_VAL_01 = B.ID
                  WHERE 1=1
                    AND D.PLAN_POLICY_ITEM_ID = 'M00010000'
                    AND A.ACTV_YN ='Y'
                   AND B.ID = P_VAL_01  /* MODULE ID */
                 ) A
                 LEFT OUTER JOIN
                 (
                    SELECT  A.PLAN_POLICY_MGMT_ID
                           ,A.PLAN_POLICY_VAL_01
                      FROM  TB_CM_PLAN_POLICY_VALUE A
                        INNER JOIN TB_CM_PLAN_POLICY_MST B
                          ON A.PLAN_POLICY_MST_ID = B.ID 
                     WHERE 1=1
                       AND B.PLAN_POLICY_ITEM_ID ='M00020000'	   
                 ) B
              ON (A.ID = B.PLAN_POLICY_MGMT_ID)
                 LEFT OUTER JOIN 
                 (
                  SELECT  A.PLAN_POLICY_MGMT_ID
                         ,C.PLAN_POLICY_VAL_ID 
                         ,C.PLAN_POLICY_NM
                    FROM  TB_CM_PLAN_POLICY_VALUE A
                      INNER JOIN TB_CM_PLAN_POLICY_MST B 
                        ON A.PLAN_POLICY_MST_ID = B.ID
                      INNER JOIN TB_CM_PLAN_POLICY_DTL C
                        ON A.PLAN_POLICY_DTL_ID = C.ID	
                   WHERE 1=1
                     AND B.PLAN_POLICY_ITEM_ID ='M00030000'
                 ) C
              ON (A.ID = C.PLAN_POLICY_MGMT_ID)
           WHERE 1 = 1
--             AND 1 = CASE WHEN P_TEMP_VAL = 'SPROC_03' 
--                     THEN
--                         CASE WHEN C.PLAN_POLICY_VAL_ID IN ('D00000003', 'D00000152') THEN 1 END
--                     WHEN P_TEMP_VAL ='SPROC_05'
--                     THEN
--                         CASE WHEN C.PLAN_POLICY_VAL_ID = 'D00000004' THEN 1 END
--                     END
             ORDER BY A.VER_ID;

    ELSIF P_Q_TYPE = 'IM_PLAN_SNRIO_TP' AND P_TEMP_VAL01 = 'SPROC_03'
    THEN     
        SELECT MAX(A.COMN_CD)  INTO P_TEMP_VAL
            FROM TB_AD_COMN_CODE A
           WHERE 1=1
             AND A.ID = P_VAL_02;
    
        OPEN pResult FOR
          SELECT  A.GRP_CD
                 ,B.ID
                 ,B.COMN_CD
                 ,B.COMN_CD_NM
            FROM  TB_AD_COMN_GRP A 
              INNER JOIN TB_AD_COMN_CODE B
                ON A.ID = B.SRC_ID  
           WHERE 1=1
             AND B.USE_YN = 'Y'
             AND A.GRP_CD = 'IM_PLAN_SNRIO_TP'
             AND P_TEMP_VAL = 'IM'
          ORDER BY A.GRP_CD, B.SEQ;

    ELSIF P_Q_TYPE = 'IM_PLAN_SNRIO_TP' AND P_TEMP_VAL01 != 'SPROC_03'
    THEN
        OPEN pResult FOR
          SELECT  NULL GRP_CD
                 ,NULL ID
                 ,NULL COMN_CD
                 ,NULL COMN_CD_NM
            FROM DUAL;

    ELSIF P_Q_TYPE = 'IM_PROCESS_TP_CHANGE'
    THEN
        SELECT B.COMN_CD_NM INTO P_TEMP_VAL01_02
          FROM TB_AD_COMN_GRP A
               INNER JOIN 
               TB_AD_COMN_CODE B 
            ON (A.ID = B.SRC_ID)
         WHERE 1=1
            AND B.ID = P_VAL_01;

        IF P_TEMP_VAL01_02 = 'Inventory Management'
        THEN
            OPEN pResult FOR    
            SELECT  B.ID         AS CD
                   ,B.COMN_CD_NM AS CD_NM
            FROM TB_AD_COMN_GRP A
                 INNER JOIN 
                 TB_AD_COMN_CODE B 
              ON (A.ID = B.SRC_ID)
            WHERE 1=1
                AND A.GRP_CD = 'SCENARIO_PROCESS_TP'
                AND B.COMN_CD <> 'SPROC_05';
        ELSE
            OPEN pResult FOR    
            SELECT  B.ID         AS CD
                   ,B.COMN_CD_NM AS CD_NM
            FROM TB_AD_COMN_GRP A
                 INNER JOIN 
                 TB_AD_COMN_CODE B 
              ON (A.ID = B.SRC_ID)
            WHERE 1=1
                AND A.GRP_CD = 'SCENARIO_PROCESS_TP';
        END IF;

    END IF;
    
END;
/

