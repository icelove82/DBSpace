create PROCEDURE "SP_UI_CM_07_Q1" (
    P_BOD_TP            IN VARCHAR2 :='',
    P_CONSUME_LOCAT_TP  IN VARCHAR2 :='',
    P_CONSUME_LOCAT_LV  IN VARCHAR2 :='',
    P_CONSUME_LOCAT_CD  IN VARCHAR2 :='',
    P_CONSUME_LOCAT_NM  IN VARCHAR2 :='',
    P_ACCOUNT_CD        IN VARCHAR2 :='',
    P_ACCOUNT_NM        IN VARCHAR2 :='',
    P_SUPPLY_LOCAT_TP   IN VARCHAR2 :='',
    P_SUPPLY_LOCAT_LV   IN VARCHAR2 :='',
    P_SUPPLY_LOCAT_CD   IN VARCHAR2 :='',
    P_SUPPLY_LOCAT_NM   IN VARCHAR2 :='',
    P_VEHICL_TP         IN VARCHAR2 :='',
    pResult 			OUT SYS_REFCURSOR
)
IS
BEGIN

    OPEN pResult FOR 
      SELECT  SLM.ID					    AS SHPP_LEADTIME_MST_ID
         , SLM.CONSUME_LOCAT_ID
         , SLM.SUPPLY_LOCAT_ID
         , SLM.ACCOUNT_ID
         , SLM.BOD_TP_ID
         , ACD.COMN_CD_NM			        AS BOD_TYPE
         , A1.COMN_CD_NM		            AS CONSUME_LOCAT_TP
         , LMS.LOCAT_LV				        AS CONSUME_LOCAT_LV
         , LDT.LOCAT_CD				        AS CONSUME_LOCAT_CD
         , LDT.LOCAT_NM				        AS CONSUME_LOCAT_NM
         , ACC.ACCOUNT_CD			        AS ACCOUNT_CD
         , ACC.ACCOUNT_NM			        AS ACCOUNT_NM
         , CTP.CHANNEL_NM			        AS CHANNEL_NM
         , INC.INCOTERMS			        AS INCOTERMS
         , A4.COMN_CD_NM			        AS SUPPLY_LOCAT_TP
         , LMS2.LOCAT_LV			        AS SUPPLY_LOCAT_LV
         , LDT2.LOCAT_CD			        AS SUPPLY_LOCAT_CD
         , LDT2.LOCAT_NM			        AS SUPPLY_LOCAT_NM
         , SLM.ACTV_YN				        AS VEHICL_ACTV_YN
         , VHC.VEHICL_TP			        AS VEHICL_TP
         , SLM.PRIORT				        AS PRIORT
         , LT.OUTBOUND_LT_MGMT_YN	        AS OUTBOUND_LT_MGMT_YN
         , LT.VOYAGE_LT_MGMT_YN		        AS VOYAGE_LT_MGMT_YN
         , LT.INBOUND_LT_MGMT_YN	        AS INBOUND_LT_MGMT_YN
         , LT.OUTBOUND_LT		        	AS OUTBOUND_LT
         , LT.VOYAGE_LT			        	AS VOYAGE_LT
         , LT.INBOUND_LT		        	AS INBOUND_LT
         , LT.TOTAL_LT			        	AS TOTAL_LT
         , LT.UOM_ID				        AS LT_UOM
         , SLM.TRANSP_COST_CAL_BASE_ID
         , ACD2.COMN_CD				        AS TRANSP_COST_CAL_BASE_CD
         , CASE WHEN ACD2.COMN_CD ='VEHICLE_TYPE' THEN NULL
                ELSE SLM.WEIGHT_UOM_ID
            END						        AS WEIGHT_UOM_ID
         , SLM.TRANSP_UTPIC
         , SLM.CURCY_CD_ID
         , SLM.CREATE_BY
         , SLM.CREATE_DTTM
         , SLM.MODIFY_BY
         , SLM.MODIFY_DTTM
      FROM TB_CM_SHIP_LT_MST SLM
            INNER JOIN TB_AD_COMN_CODE ACD
                ON SLM.BOD_TP_ID = ACD.ID
            LEFT OUTER JOIN TB_AD_COMN_CODE ACD2 
                ON SLM.TRANSP_COST_CAL_BASE_ID = ACD2.ID
            LEFT OUTER JOIN TB_DP_ACCOUNT_MST ACC
                ON SLM.ACCOUNT_ID = ACC.ID
            LEFT OUTER JOIN TB_CM_CHANNEL_TYPE CTP 
                ON ACC.CHANNEL_ID = CTP.ID
            LEFT OUTER JOIN TB_CM_INCOTERMS INC
                ON ACC.INCOTERMS_ID = INC.ID
            LEFT OUTER JOIN TB_CM_VEHICLE VHC
                ON SLM.VEHICL_TP_ID = VHC.ID
            LEFT OUTER JOIN 
            (
            SELECT A.SHPP_LEADTIME_MST_ID
                 , A.PRIORT
                 , MAX(A.UOM_ID)                AS UOM_ID
                 , MAX(A.OUTBOUND_LT_MGMT_YN)	AS OUTBOUND_LT_MGMT_YN
                 , MAX(A.VOYAGE_LT_MGMT_YN)		AS VOYAGE_LT_MGMT_YN
                 , MAX(A.INBOUND_LT_MGMT_YN)	AS INBOUND_LT_MGMT_YN
                 , SUM(A.OUTBOUND_LT)	        AS OUTBOUND_LT
                 , SUM(A.VOYAGE_LT)		        AS VOYAGE_LT
                 , SUM(A.INBOUND_LT)	        AS INBOUND_LT
                 , MAX(A.TOTAL_LT)		        AS TOTAL_LT
              FROM (
                    SELECT SLM.ID   AS SHPP_LEADTIME_MST_ID
                         , SLM.PRIORT
                         , SLD.UOM_ID
                         , CASE WHEN ACD.COMN_CD  = 'OUTBOUND' THEN BOD.LEADTIME_MGMT_YN END AS OUTBOUND_LT_MGMT_YN
                         , CASE WHEN ACD.COMN_CD  = 'VOYAGE' THEN BOD.LEADTIME_MGMT_YN END AS VOYAGE_LT_MGMT_YN
                         , CASE WHEN ACD.COMN_CD  = 'INBOUND' THEN BOD.LEADTIME_MGMT_YN END AS INBOUND_LT_MGMT_YN
                         , CASE WHEN ACD.COMN_CD  = 'OUTBOUND' THEN SLD.LEADTIME END AS OUTBOUND_LT
                         , CASE WHEN ACD.COMN_CD  = 'VOYAGE' THEN SLD.LEADTIME END AS VOYAGE_LT
                         , CASE WHEN ACD.COMN_CD  = 'INBOUND' THEN SLD.LEADTIME END AS INBOUND_LT
                         , SUM(SLD.LEADTIME) OVER (PARTITION BY SLD.SHPP_LEADTIME_MST_ID) AS TOTAL_LT
                      FROM TB_CM_SHIP_LT_MST SLM
                      INNER JOIN  TB_CM_SHIP_LT_DTL SLD 
                      ON (SLM.ID = SLD.SHPP_LEADTIME_MST_ID)
                      INNER JOIN TB_CM_BOD_LT BOD 
                      ON (SLD.BOD_LEADTIME_ID = BOD.ID)
                      INNER JOIN TB_AD_COMN_CODE ACD 
                      ON (BOD.LEADTIME_TP_ID = ACD.ID)
                    ) A
            GROUP BY A.SHPP_LEADTIME_MST_ID, A.PRIORT
           ) LT
            ON SLM.ID = LT.SHPP_LEADTIME_MST_ID
            AND NVL(SLM.PRIORT,0) = NVL(LT.PRIORT,0)
        --------------------------------------------------------------------
        -- 소요거점 그룹
        --------------------------------------------------------------------
            LEFT OUTER JOIN TB_CM_LOC_MGMT LMG 
            ON SLM.CONSUME_LOCAT_ID = LMG.ID
            LEFT OUTER JOIN TB_CM_LOC_DTL LDT
            ON LDT.ID = LMG.LOCAT_ID
            LEFT OUTER JOIN TB_CM_LOC_MST LMS 
            ON LDT.LOCAT_MST_ID = LMS.ID
            LEFT OUTER JOIN TB_AD_COMN_CODE A1 
            ON LMS.LOCAT_TP_ID = A1.ID
        ----------------------------------------------------------------
        -- 공급거점 그룹
        ----------------------------------------------------------------
            INNER JOIN TB_CM_LOC_MGMT LMG2 
            ON SLM.SUPPLY_LOCAT_ID = LMG2.ID
            INNER JOIN TB_CM_LOC_DTL LDT2
            ON LDT2.ID = LMG2.LOCAT_ID
            INNER JOIN TB_CM_LOC_MST LMS2
            ON LDT2.LOCAT_MST_ID = LMS2.ID
            INNER JOIN TB_AD_COMN_CODE A4 
            ON LMS2.LOCAT_TP_ID = A4.ID
       ---------------------------------------------------------------
       -- 조회 조건
       ---------------------------------------------------------------
       WHERE 1=1
       AND NVL(UPPER(A1.COMN_CD_NM), ' ') LIKE '%'||UPPER(P_CONSUME_LOCAT_TP)||'%'
       AND NVL(UPPER(LMS.LOCAT_LV), ' ') LIKE '%'||P_CONSUME_LOCAT_LV||'%'
       AND NVL(UPPER(LDT.LOCAT_CD), ' ') LIKE '%'||UPPER(P_CONSUME_LOCAT_CD)||'%'
       AND NVL(UPPER(LDT.LOCAT_NM), ' ') LIKE '%'||UPPER(P_CONSUME_LOCAT_NM)||'%'
       AND NVL(UPPER(A4.COMN_CD_NM), ' ') LIKE '%'||UPPER(P_SUPPLY_LOCAT_TP)||'%'
       AND NVL(UPPER(ACC.ACCOUNT_CD), ' ') LIKE '%'||UPPER(P_ACCOUNT_CD)||'%'
       AND NVL(UPPER(ACC.ACCOUNT_NM), ' ') LIKE '%'||UPPER(P_ACCOUNT_NM)||'%'
       AND NVL(UPPER(LMS2.LOCAT_LV), ' ') LIKE '%'||P_SUPPLY_LOCAT_LV||'%'
       AND NVL(UPPER(LDT2.LOCAT_CD), ' ') LIKE '%'||UPPER(P_SUPPLY_LOCAT_CD)||'%'
       AND NVL(UPPER(LDT2.LOCAT_NM), ' ') LIKE '%'||UPPER(P_SUPPLY_LOCAT_NM)||'%'
       AND VHC.VEHICL_TP = CASE WHEN P_VEHICL_TP = 'ALL' OR NVL(P_VEHICL_TP, ' ') = ' '
                                THEN VHC.VEHICL_TP
                                ELSE P_VEHICL_TP
                            END
    ORDER BY ACD.COMN_CD_NM, A1.SEQ, LMS.LOCAT_LV, LDT.LOCAT_CD, A4.SEQ, LMS2.LOCAT_LV, LDT2.LOCAT_CD;

END;
/

