create PROCEDURE                "SP_UI_DP_19_S1" (
    p_ID                    IN VARCHAR2        := ''    
  , p_UI_ID                 IN VARCHAR2        := ''                
  , p_GRID_ID               IN VARCHAR2        := ''
  , p_GRP_ID                IN VARCHAR2        := ''  
  , p_MEASURE_CONF_TP_ID    IN VARCHAR2        := ''      
  , p_MEASURE_CD            IN VARCHAR2        := ''      
  , p_VER_APPY_BASE_ID      IN VARCHAR2        := ''  
  , p_MEASURE_VAL_TP_ID     IN VARCHAR2        := ''
  , p_INPUT_YN              IN CHAR            := ''     
  , p_DISP_NM               IN VARCHAR2        := ''   
  , p_SEQ                   IN INT             := ''  
  , p_ACTV_YN               IN CHAR            := ''     
  , p_USER_ID               IN VARCHAR2        := ''     
  , P_RT_ROLLBACK_FLAG      OUT    VARCHAR2 
  , P_RT_MSG                OUT    VARCHAR2                                       
) 
IS
    P_ERR_STATUS        INT  := 0; 
    P_ERR_MSG           VARCHAR2(4000) :='';
    v_CONF_CD           VARCHAR2(100);
    v_LV_MGMT_ID        CHAR(32);
    v_MEASURE_MST_ID    CHAR(32);
    v_MEASURE_CD        VARCHAR2(100);    -- CODE 
    v_DISP_NM           VARCHAR2(100);
    V_USER_PREF_MST_ID  CHAR(32);
BEGIN 
    /************************************************************************************************
        -- Validation
    ************************************************************************************************/
    IF(p_MEASURE_CONF_TP_ID IS NULL 
    OR p_MEASURE_CD         IS NULL 
    OR p_VER_APPY_BASE_ID   IS NULL
    OR p_MEASURE_VAL_TP_ID  IS NULL
    OR p_SEQ                IS NULL)
    THEN 
         P_ERR_MSG := 'MSG_0006';         
         RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);                 
    END IF;

    IF (P_UI_ID IS NULL) THEN
        P_ERR_MSG := 'UI ID is empty.';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

    IF P_GRID_ID IS NULL THEN
        P_ERR_MSG := 'Grid ID is empty.';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

    SELECT COUNT(1) INTO P_ERR_STATUS
      FROM TB_AD_GROUP GRP
     WHERE ID = P_GRP_ID;

    IF P_ERR_STATUS = 0 THEN 
        P_ERR_MSG := 'Group Code is empty.';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

    SELECT ID
      INTO V_USER_PREF_MST_ID
      FROM TB_AD_USER_PREF_MST
     WHERE VIEW_CD = P_UI_ID
       AND GRID_CD = P_GRID_ID;
    /************************************************************************************************
        -- Make Measure Data
    ************************************************************************************************/
    SELECT MIN(CD) INTO v_MEASURE_CD
      FROM (
        SELECT 'MEASURE_' || RPAD('0', LENGTH('0') *2 - LENGTH(RTRIM(TO_CHAR(ROWNUM))), '0')  || TO_CHAR(ROWNUM) AS CD 
          FROM TB_CM_CONFIGURATION WHERE ROWNUM <= 70
      ) A 
     WHERE NOT EXISTS ( 
        SELECT FLD_CD 
          FROM TB_AD_USER_PREF_DTL PER 
         WHERE PER.DIM_MEASURE_TP   = 'MEASURE'
           AND PER.USER_PREF_MST_ID = V_USER_PREF_MST_ID  --'UI_DP_25'
           AND PER.GRP_ID           = P_GRP_ID --'SALESMAN'
           AND PER.FLD_CD           = A.CD
     );     

    SELECT CONF_CD INTO v_CONF_CD
      FROM TB_CM_COMM_CONFIG
     WHERE CONF_GRP_CD  = 'DP_MS_INPUT_TP'
       AND ID           = p_MEASURE_CONF_TP_ID
    ;

    IF    (v_CONF_CD = 'DEMAND')
    THEN 
        SELECT  p_MEASURE_CD, NULL INTO v_LV_MGMT_ID, v_MEASURE_MST_ID
        FROM DUAL;
    ELSIF (v_CONF_CD = 'ADDITION')
    THEN
        SELECT NULL, p_MEASURE_CD INTO v_LV_MGMT_ID, v_MEASURE_MST_ID
        FROM DUAL;
    END IF; 

    -- DISP NM 
    SELECT CASE WHEN v_CONF_CD = 'DEMAND' --v_MEASURE_MST_ID IS NULL AND v_LV_MGMT_ID IS NOT NULL
                THEN (SELECT LV_CD FROM TB_CM_LEVEL_MGMT WHERE ID = v_LV_MGMT_ID)
                     ||CASE WHEN (SELECT CONF_CD FROM TB_CM_COMM_CONFIG WHERE ID = P_VER_APPY_BASE_ID AND CONF_CD != 'CT') IS NULL THEN NULL
                            ELSE '_'||(SELECT CONF_CD FROM TB_CM_COMM_CONFIG WHERE ID = P_VER_APPY_BASE_ID) END
                     ||'_'||(SELECT CONF_CD FROM TB_CM_COMM_CONFIG WHERE ID = p_MEASURE_VAL_TP_ID)-- Demand Level
                WHEN v_CONF_CD ='ADDITION' 
                THEN (SELECT MEASURE_CD FROM TB_DP_MEASURE_MST WHERE ID = v_MEASURE_MST_ID) --  measure
           END
      INTO v_DISP_NM
      FROM DUAL
    ;

    MERGE INTO TB_DP_MEASURE_SETTING TARGET
    USING ( 
        SELECT p_ID                 AS ID                    
             , p_UI_ID              AS UI_ID                        
             , p_GRID_ID            AS GRID_ID                
             , p_GRP_ID             AS GRP_ID                            
             , p_MEASURE_CONF_TP_ID AS MEASURE_CONF_TP_ID                
             , v_LV_MGMT_ID         AS LV_MGMT_ID    
             , v_MEASURE_MST_ID     AS MEASURE_MST_ID            
             , p_VER_APPY_BASE_ID   AS VER_APPY_BASE_ID            
             , p_MEASURE_VAL_TP_ID  AS MEASURE_VAL_TP_ID    
             , NVL(p_INPUT_YN, 'N') AS INPUT_YN
             , v_DISP_NM            AS DISP_NM                
             , p_SEQ                AS SEQ                
             , NVL(p_ACTV_YN,'N')   AS ACTV_YN     
             , p_USER_ID            AS USER_ID    
          FROM DUAL
    ) SOURCE
    ON (TARGET.ID = SOURCE.ID)    
    WHEN NOT MATCHED THEN 
        INSERT (
            ID
          , UI_ID
          , GRID_ID
          , GRP_ID
          , MEASURE_CONF_TP_ID
          , LV_MGMT_ID
          , MEASURE_MST_ID
          , VER_APPY_BASE_ID
          , MEASURE_VAL_TP_ID
          , INPUT_YN
          , DISP_NM
          , SEQ
          , ACTV_YN
          , CREATE_BY
          , CREATE_DTTM
        )
        VALUES (
            TO_SINGLE_BYTE(SYS_GUID())
          , SOURCE.UI_ID                        
          , SOURCE.GRID_ID                
          , SOURCE.GRP_ID                    
          , SOURCE.MEASURE_CONF_TP_ID            
          , SOURCE.LV_MGMT_ID    
          , SOURCE.MEASURE_MST_ID            
          , SOURCE.VER_APPY_BASE_ID            
          , SOURCE.MEASURE_VAL_TP_ID    
          , SOURCE.INPUT_YN                        
          , SOURCE.DISP_NM                
          , SOURCE.SEQ    
          , 'Y'        
          , SOURCE.USER_ID       
          , SYSDATE       
        ) 
    WHEN MATCHED THEN
        UPDATE 
           SET TARGET.GRP_ID                = SOURCE.GRP_ID
             , TARGET.MEASURE_CONF_TP_ID    = SOURCE.MEASURE_CONF_TP_ID
             , TARGET.LV_MGMT_ID            = SOURCE.LV_MGMT_ID
             , TARGET.MEASURE_MST_ID        = SOURCE.MEASURE_MST_ID
             , TARGET.VER_APPY_BASE_ID      = SOURCE.VER_APPY_BASE_ID
             , TARGET.MEASURE_VAL_TP_ID     = SOURCE.MEASURE_VAL_TP_ID        
             , TARGET.INPUT_YN              = SOURCE.INPUT_YN      
             , TARGET.DISP_NM               = SOURCE.DISP_NM                                        
             , TARGET.SEQ                   = SOURCE.SEQ    
             , TARGET.ACTV_YN               = SOURCE.ACTV_YN                                      
             , TARGET.MODIFY_BY             = SOURCE.USER_ID       
             , TARGET.MODIFY_DTTM           = SYSDATE     
	;   

    SELECT COUNT(ID) INTO P_ERR_STATUS
      FROM TB_DP_MEASURE_SETTING
     WHERE 1=1
       AND UI_ID = P_UI_ID
       AND GRP_ID = P_GRP_ID
       AND GRID_ID = P_GRID_ID
       AND ID = P_ID;      
    /************************************************************************************************
        -- Make Preference Data
    ************************************************************************************************/          
    IF (P_ERR_STATUS = 0 OR P_ID IS NULL) THEN
            -- TB_DP_MEASURE_SETTING
        SP_UI_DP_19_PERSON_AUTO_CREATE (
            P_GRP_ID
          , P_UI_ID
          , P_GRID_ID
          , P_USER_ID
          , P_RT_ROLLBACK_FLAG
          , P_RT_MSG
        );
    ELSE    
            -- TB_DP_MEASURE_SETTING  : PERSONALIZATION_MGMT_MST 
        MERGE INTO TB_AD_USER_PREF_DTL TARGET
        USING ( 
            SELECT V_USER_PREF_MST_ID           AS USER_PREF_MST_ID                       
                 , v_MEASURE_CD                 AS FIELD_ID
                 , P_GRP_ID                     AS GRP_ID                
                 , p_ID                         AS REFER_VALUE
                 , v_DISP_NM                    AS FLD_APPLY_CD
                 , COALESCE(p_ACTV_YN, 'N')     AS ACTV_YN
                 , p_SEQ                        AS SEQ
                 , 100                          AS FLD_WIDTH                
                 , 'Y'                          AS APPLY_YN
                 , 'GROUP-VERTICAL-VALUES'      AS PIVOT_ITEM_CD
                 , 'MEASURE'                    AS DIM_MEASURE_TP
                 , COALESCE(p_INPUT_YN, 'N')    AS EDIT_MEASURE_YN
                 , 'Y'                          AS PIVOT_APPY_YN 
                 , p_USER_ID                    AS USER_ID
              FROM DUAL
        ) SOURCE
        ON (    TARGET.USER_PREF_MST_ID = SOURCE.USER_PREF_MST_ID    
            AND TARGET.GRP_ID           = SOURCE.GRP_ID
            AND TARGET.REFER_VALUE      = SOURCE.REFER_VALUE)
        WHEN MATCHED THEN
            UPDATE 
               SET TARGET.FLD_APPLY_CD      = SOURCE.FLD_APPLY_CD
                 , TARGET.FLD_ACTIVE_YN     = SOURCE.ACTV_YN        
                 , TARGET.FLD_SEQ           = SOURCE.SEQ      
                 , TARGET.FLD_WIDTH         = SOURCE.FLD_WIDTH                                        
                 , TARGET.APPLY_YN          = SOURCE.APPLY_YN    
                 , TARGET.EDIT_MEASURE_YN   = SOURCE.EDIT_MEASURE_YN                          
                 , TARGET.MODIFY_BY         = SOURCE.USER_ID       
                 , TARGET.MODIFY_DTTM       = SYSDATE   
                 , TARGET.CROSSTAB_YN       = SOURCE.ACTV_YN
        ;                           
		/************************************************************************************************************************
            -- Re-make TB_AD_USER_PREF
        *************************************************************************************************************************/
				   INSERT INTO TEMP_AD_USER_PREF 
				   (  USER_ID			
					, GRP_ID			
					, FLD_CD			
					, FLD_APPLY_CD		
					, FLD_WIDTH		
					, FLD_SEQ			
					, FLD_ACTIVE_YN	
					, APPLY_YN			
--					, REFER_VALUE		
					, DIM_MEASURE_TP 
					, CROSSTAB_ITEM_CD	
					, CATEGORY_GROUP	
					, SUMMARY_TP		
					, SUMMARY_YN		
					, EDIT_MEASURE_YN	
					, EDIT_TARGET_YN	
					, DATA_KEY_YN		
					, CROSSTAB_YN		
					, CREATE_BY	
					, CREATE_DTTM					
					)		 
					SELECT USER_ID
						 , GRP_ID
						 , FLD_CD
						 , FLD_APPLY_CD
						 , FLD_WIDTH
						 , FLD_SEQ
						 , FLD_ACTIVE_YN
						 , APPLY_YN
--						 , REFER_VALUE
						 , DIM_MEASURE_TP 
						 , CROSSTAB_ITEM_CD
						 , CATEGORY_GROUP
						 , SUMMARY_TP
						 , SUMMARY_YN
						 , EDIT_MEASURE_YN
						 , EDIT_TARGET_YN
						 , DATA_KEY_YN
						 , CROSSTAB_YN
						 , CREATE_BY	
						 , CREATE_DTTM	
					 FROM TB_AD_USER_PREF
					WHERE USER_PREF_MST_ID = V_USER_PREF_MST_ID
					  AND DIM_MEASURE_TP = 'MEASURE'
					  AND REFER_VALUE = p_ID
					  ;
				DELETE 
				  FROM TB_AD_USER_PREF
				 WHERE USER_PREF_MST_ID = V_USER_PREF_MST_ID
				   AND DIM_MEASURE_TP = 'MEASURE'
				   AND REFER_VALUE = p_ID
				   ;
				INSERT INTO TB_AD_USER_PREF
				( ID
				, USER_ID
				, USER_PREF_MST_ID
				, GRP_ID
				, FLD_CD
				, FLD_APPLY_CD
				, FLD_WIDTH
				, FLD_SEQ
				, FLD_ACTIVE_YN
				, APPLY_YN
				, REFER_VALUE
				, CROSSTAB_ITEM_CD
				, CATEGORY_GROUP
				, DIM_MEASURE_TP
				, SUMMARY_TP
				, SUMMARY_YN
				, EDIT_MEASURE_YN
				, EDIT_TARGET_YN
				, DATA_KEY_YN
				, CROSSTAB_YN
				, CREATE_BY
				, CREATE_DTTM
				, MODIFY_BY
				, MODIFY_DTTM
				)                   
				WITH PREF_USER
				 AS (
					SELECT DISTINCT USER_ID FROM TEMP_AD_USER_PREF 
				 ), NEW_USER_PREF
				AS ( 
					 SELECT D.GRP_ID
						  , D.FLD_CD
						  , D.FLD_APPLY_CD
						  , D.FLD_WIDTH
						  , D.FLD_SEQ
						  , D.FLD_ACTIVE_YN
						  , D.APPLY_YN
--						  , D.REFER_VALUE
						  , D.CROSSTAB_ITEM_CD
						  , D.CATEGORY_GROUP
						  , D.DIM_MEASURE_TP
						  , D.SUMMARY_TP
						  , D.SUMMARY_YN
						  , D.EDIT_MEASURE_YN
						  , D.EDIT_TARGET_YN
						  , D.DATA_KEY_YN
						  , D.CROSSTAB_YN	
						  , P.USER_ID 				 
					   FROM TB_AD_USER_PREF_DTL D
							CROSS JOIN
							PREF_USER P 
					  WHERE D.USER_PREF_MST_ID = V_USER_PREF_MST_ID
						AND D.DIM_MEASURE_TP = 'MEASURE'
						AND REFER_VALUE = p_ID
				   )
				SELECT	TO_SINGLE_BYTE(SYS_GUID()) AS ID 
					  , M.USER_ID 	
					  , V_USER_PREF_MST_ID
					  , M.GRP_ID
					  , M.FLD_CD
					  , M.FLD_APPLY_CD
					  , COALESCE(S.FLD_WIDTH		, M.FLD_WIDTH		)
					  , COALESCE(S.FLD_SEQ			, M.FLD_SEQ			)
					  , COALESCE(S.FLD_ACTIVE_YN	, M.FLD_ACTIVE_YN	)
					  , M.APPLY_YN
					  , P_ID        REFER_VALUE
					  , M.CROSSTAB_ITEM_CD
					  , M.CATEGORY_GROUP
					  , M.DIM_MEASURE_TP
					  , M.SUMMARY_TP
					  , M.SUMMARY_YN
					  , M.EDIT_MEASURE_YN
					  , M.EDIT_TARGET_YN
					  , M.DATA_KEY_YN
					  , M.CROSSTAB_YN	
					  , COALESCE(S.CREATE_BY   ,	'system')  CREATE_BY
					  , COALESCE(S.CREATE_DTTM ,SYSDATE)	   CREATE_DTTM
					  , CASE WHEN S.FLD_CD IS NULL THEN NULL ELSE 'system'	END
					  , CASE WHEN S.FLD_CD IS NULL THEN NULL ELSE SYSDATE END
				  FROM NEW_USER_PREF M 
					   LEFT OUTER JOIN 
					   TEMP_AD_USER_PREF S
					ON M.GRP_ID = S.GRP_ID
				   AND M.USER_ID = S.USER_ID 
				   AND M.DIM_MEASURE_TP = S.DIM_MEASURE_TP
				  ;

				DELETE FROM TEMP_AD_USER_PREF;
    END IF;



        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';  

EXCEPTION WHEN OTHERS THEN  --  e_products_invalid    
    IF(SQLCODE = -20001)
    THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
    --SP_COMM_RAISE_ERR();              
        RAISE;
    END IF;  

END;
/

