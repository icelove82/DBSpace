create PROCEDURE SP_UI_CM_03_S1 (
     P_ITEM_SCOPE_MST_ID IN CHAR  := NULL
    ,P_ITEM_CLASS_VAL    IN VARCHAR2 := NULL
    ,P_DESCRIP           IN VARCHAR2 := NULL
    ,P_CONTINU_PRDUCT_YN IN CHAR     := NULL
    ,P_PROD_MIX_YN       IN CHAR     := NULL
    ,P_ATTR_01           IN CHAR     := NULL
    ,P_ATTR_02           IN CHAR     := NULL
    ,P_ATTR_03           IN CHAR     := NULL
    ,P_ATTR_04           IN CHAR     := NULL
    ,P_ATTR_05           IN CHAR     := NULL
    ,P_ATTR_06           IN CHAR     := NULL
    ,P_ATTR_07           IN CHAR     := NULL
    ,P_ATTR_08           IN CHAR     := NULL
    ,P_ATTR_09           IN CHAR     := NULL
    ,P_ATTR_10           IN CHAR     := NULL
    ,P_ATTR_11           IN CHAR     := NULL
    ,P_ATTR_12           IN CHAR     := NULL
    ,P_ATTR_13           IN CHAR     := NULL
    ,P_ATTR_14           IN CHAR     := NULL
    ,P_ATTR_15           IN CHAR     := NULL
    ,P_ATTR_16           IN CHAR     := NULL
    ,P_ATTR_17           IN CHAR     := NULL
    ,P_ATTR_18           IN CHAR     := NULL
    ,P_ATTR_19           IN CHAR     := NULL
    ,P_ATTR_20           IN CHAR     := NULL
    ,P_ACTV_YN           IN CHAR     := NULL
    ,P_USER_ID           IN VARCHAR2 := NULL
    ,P_RT_ROLLBACK_FLAG  OUT VARCHAR2
    ,P_RT_MSG            OUT VARCHAR2
)
IS
    P_ERR_STATUS        NUMBER :=0;
    P_ERR_MSG           VARCHAR2(4000) :='';
    V_DUP_ITEM_CLASS    INT := 0;

BEGIN
    P_ERR_MSG := 'MSG_0006';
    IF NVL(P_ITEM_SCOPE_MST_ID, ' ') = ' ' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;
    IF NVL(P_ITEM_CLASS_VAL, ' ') = ' ' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;

	IF P_CONTINU_PRDUCT_YN = 'Y' THEN
        SELECT	COUNT(1) INTO V_DUP_ITEM_CLASS
        FROM	TB_CM_ITEM_CLASS_MST
        WHERE	ITEM_SCOPE_MST_ID = P_ITEM_SCOPE_MST_ID
        AND		CONTINU_PRDUCT_YN = 'Y';

        P_ERR_MSG := 'MSG_5147';
        IF V_DUP_ITEM_CLASS > 0 THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;
    END IF;

	IF P_PROD_MIX_YN = 'Y' THEN
        SELECT	COUNT(1) INTO V_DUP_ITEM_CLASS
        FROM	TB_CM_ITEM_CLASS_MST
        WHERE	ITEM_SCOPE_MST_ID = P_ITEM_SCOPE_MST_ID
        AND		ITEM_CLASS_VAL != P_ITEM_CLASS_VAL
        AND     NVL(ATTR_01, ' ') = NVL(P_ATTR_01, ' ')
        AND     NVL(ATTR_02, ' ') = NVL(P_ATTR_02, ' ')
        AND     NVL(ATTR_03, ' ') = NVL(P_ATTR_03, ' ')
        AND     NVL(ATTR_04, ' ') = NVL(P_ATTR_04, ' ')
        AND     NVL(ATTR_05, ' ') = NVL(P_ATTR_05, ' ')
        AND     NVL(ATTR_06, ' ') = NVL(P_ATTR_06, ' ')
        AND     NVL(ATTR_07, ' ') = NVL(P_ATTR_07, ' ')
        AND     NVL(ATTR_08, ' ') = NVL(P_ATTR_08, ' ')
        AND     NVL(ATTR_09, ' ') = NVL(P_ATTR_09, ' ')
        AND     NVL(ATTR_10, ' ') = NVL(P_ATTR_10, ' ')
        AND     NVL(ATTR_11, ' ') = NVL(P_ATTR_11, ' ')
        AND     NVL(ATTR_12, ' ') = NVL(P_ATTR_12, ' ')
        AND     NVL(ATTR_13, ' ') = NVL(P_ATTR_13, ' ')
        AND     NVL(ATTR_14, ' ') = NVL(P_ATTR_14, ' ')
        AND     NVL(ATTR_15, ' ') = NVL(P_ATTR_15, ' ')
        AND     NVL(ATTR_16, ' ') = NVL(P_ATTR_16, ' ')
        AND     NVL(ATTR_17, ' ') = NVL(P_ATTR_17, ' ')
        AND     NVL(ATTR_18, ' ') = NVL(P_ATTR_18, ' ')
        AND     NVL(ATTR_19, ' ') = NVL(P_ATTR_19, ' ')
        AND     NVL(ATTR_20, ' ') = NVL(P_ATTR_20, ' ')
        AND		PROD_MIX_YN = 'Y';

        P_ERR_MSG := 'MSG_5022';
        IF V_DUP_ITEM_CLASS > 0 THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;
    END IF;

	MERGE INTO TB_CM_ITEM_CLASS_MST A
    USING (
          SELECT P_ITEM_SCOPE_MST_ID   AS ITEM_SCOPE_MST_ID
            	,P_ITEM_CLASS_VAL	    AS ITEM_CLASS_VAL
          FROM   DUAL
	      ) B
	ON (A.ITEM_SCOPE_MST_ID = P_ITEM_SCOPE_MST_ID AND A.ITEM_CLASS_VAL = P_ITEM_CLASS_VAL)
	WHEN MATCHED THEN 
		UPDATE 
		SET 	 DESCRIP				= P_DESCRIP
				,CONTINU_PRDUCT_YN		= P_CONTINU_PRDUCT_YN
				,PROD_MIX_YN			= P_PROD_MIX_YN
				,ATTR_01				= P_ATTR_01
				,ATTR_02				= P_ATTR_02
				,ATTR_03				= P_ATTR_03
				,ATTR_04				= P_ATTR_04
				,ATTR_05				= P_ATTR_05
				,ATTR_06				= P_ATTR_06
				,ATTR_07				= P_ATTR_07
				,ATTR_08				= P_ATTR_08
				,ATTR_09				= P_ATTR_09
				,ATTR_10				= P_ATTR_10
				,ATTR_11				= P_ATTR_11
				,ATTR_12				= P_ATTR_12
				,ATTR_13				= P_ATTR_13
				,ATTR_14				= P_ATTR_14
				,ATTR_15				= P_ATTR_15
				,ATTR_16				= P_ATTR_16
				,ATTR_17				= P_ATTR_17
				,ATTR_18				= P_ATTR_18
				,ATTR_19				= P_ATTR_19
				,ATTR_20				= P_ATTR_20
				,ACTV_YN				= P_ACTV_YN
				,MODIFY_BY				= P_USER_ID
				,MODIFY_DTTM			= SYSDATE
	WHEN NOT MATCHED THEN 
        INSERT (
                ID
                ,ITEM_SCOPE_MST_ID
                ,ITEM_CLASS_VAL
                ,DESCRIP
                ,CONTINU_PRDUCT_YN
                ,PROD_MIX_YN
                ,ATTR_01
                ,ATTR_02
                ,ATTR_03
                ,ATTR_04
                ,ATTR_05
                ,ATTR_06
                ,ATTR_07
                ,ATTR_08
                ,ATTR_09
                ,ATTR_10
                ,ATTR_11
                ,ATTR_12
                ,ATTR_13
                ,ATTR_14
                ,ATTR_15
                ,ATTR_16
                ,ATTR_17
                ,ATTR_18
                ,ATTR_19
                ,ATTR_20
                ,ACTV_YN
                ,CREATE_BY
                ,CREATE_DTTM
			)			
		VALUES (
                TO_SINGLE_BYTE(SYS_GUID())
                ,P_ITEM_SCOPE_MST_ID 
                ,P_ITEM_CLASS_VAL	 
                ,P_DESCRIP			
                ,P_CONTINU_PRDUCT_YN
                ,P_PROD_MIX_YN
                ,P_ATTR_01
                ,P_ATTR_02
                ,P_ATTR_03
                ,P_ATTR_04
                ,P_ATTR_05
                ,P_ATTR_06
                ,P_ATTR_07
                ,P_ATTR_08
                ,P_ATTR_09
                ,P_ATTR_10
                ,P_ATTR_11
                ,P_ATTR_12
                ,P_ATTR_13
                ,P_ATTR_14
                ,P_ATTR_15
                ,P_ATTR_16
                ,P_ATTR_17
                ,P_ATTR_18
                ,P_ATTR_19
                ,P_ATTR_20
                ,P_ACTV_YN
                ,P_USER_ID
                ,SYSDATE
			);

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';

EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN 
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;
      ELSE
          RAISE;
      END IF;
END;
/

