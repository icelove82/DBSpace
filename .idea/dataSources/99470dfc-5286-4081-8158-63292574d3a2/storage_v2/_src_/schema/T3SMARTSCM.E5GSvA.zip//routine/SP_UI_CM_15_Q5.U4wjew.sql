create PROCEDURE "SP_UI_CM_15_Q5" (
    P_PLAN_POLICY_ID        IN VARCHAR2 := '' ,
    P_PLAN_POLICY_ITEM_ID   IN VARCHAR2 := '' ,
    pResult                 OUT SYS_REFCURSOR
)
IS
BEGIN
    IF P_PLAN_POLICY_ITEM_ID IN ('M00320000') /* M00320000 [Plan Priority] */
    THEN
        OPEN pResult FOR 
          SELECT   C.ID
                  ,D.PLAN_POLICY_NM                          AS NM
                  ,CASE WHEN C.ACTV_YN = 'Y' THEN 'Y'
                   ELSE NULL
                   END                                       AS ACTV_YN
                  ,C.PRIORT
          FROM  TB_CM_PLAN_POLICY_MGMT A
            INNER JOIN TB_CM_PLAN_POLICY_VALUE B 
              ON A.ID = B.PLAN_POLICY_MGMT_ID
            INNER JOIN TB_CM_GRID_VALUE C 
              ON B.ID = C.PLAN_POLICY_VAL_ID
            INNER JOIN TB_CM_PLAN_POLICY_DTL D 
              ON C.PLAN_POLICY_DTL_ID = D.ID
            INNER JOIN TB_CM_PLAN_POLICY_MST E 
              ON B.PLAN_POLICY_MST_ID = E.ID
         WHERE 1=1
           AND A.ID= P_PLAN_POLICY_ID
           AND E.PLAN_POLICY_ITEM_ID = P_PLAN_POLICY_ITEM_ID
         ORDER BY D.PLAN_POLICY_NM;

    ELSIF P_PLAN_POLICY_ITEM_ID IN ('PP_CON_07') /* PP_CON_07 [Sub Plan Priority] */
    THEN
        OPEN pResult FOR
          SELECT  B.ID
                 ,B.POLICY_TP_NM
                 ,C.NM
                 ,CASE WHEN B.ACTV_YN = 'Y' THEN 'Y'
                  ELSE NULL
                  END AS ACTV_YN
                 ,B.PRIORT
          FROM  TB_CM_PLAN_POLICY_MGMT A 
            INNER JOIN TB_CM_SUB_PRIORITY B 
              ON A.ID = B.PLAN_POLICY_MGMT_ID
            INNER JOIN (
                SELECT 	A.ID
                       ,A.CHANNEL_NM AS NM
                  FROM TB_CM_CHANNEL_TYPE A
                UNION ALL
                SELECT  B.ID
                       ,TO_CHAR(B.COMN_CD_NM)
                FROM  TB_AD_COMN_GRP A 
                  INNER JOIN TB_AD_COMN_CODE B 
                    ON A.ID = B.SRC_ID
                WHERE 1=1
                  AND A.GRP_CD='DEMAND_TYPE'
                UNION ALL
                SELECT  B.ID
                       ,TO_CHAR(B.COMN_CD_NM)
                FROM  TB_AD_COMN_GRP A 
                  INNER JOIN TB_AD_COMN_CODE B 
                    ON A.ID = B.SRC_ID
                WHERE 1=1
                  AND A.GRP_CD='DEMAND_CLASS'
                UNION ALL
                SELECT  B.ID
                       ,TO_CHAR(B.COMN_CD_NM)
                 FROM  TB_AD_COMN_GRP A 
                   INNER JOIN TB_AD_COMN_CODE B
                     ON A.ID = B.SRC_ID 
                WHERE 1=1
                  AND A.GRP_CD='URGENT_ORDER_TYPE'
                ) C
                ON NVL(NVL(NVL(B.CHANNEL_TP_ID,B.DMND_TP_PRIORT_RULE_ID),B.DMND_CLASS_TP_ID),B.URGENT_ORDER_TP_ID) = C.ID
         WHERE 1=1
           AND A.ID = P_PLAN_POLICY_ID
           AND B.CATAGY_TP = P_PLAN_POLICY_ITEM_ID
         ORDER BY B.POLICY_TP_NM, C.NM;
    END IF;

END;
/

