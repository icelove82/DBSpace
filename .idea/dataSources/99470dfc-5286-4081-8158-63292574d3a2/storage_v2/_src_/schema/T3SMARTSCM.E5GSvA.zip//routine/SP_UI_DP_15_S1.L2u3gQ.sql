create PROCEDURE                "SP_UI_DP_15_S1" (
                                       P_ID                 IN VARCHAR2      := ''  
									  ,P_EMP_NO             IN VARCHAR2      := ''      									 
									  ,P_AUTH_TP_ID         IN VARCHAR2      := ''   
									  ,V_ACCOUNT_ID         IN VARCHAR2      := '' 
                                      ,P_ACCOUNT_CD         IN VARCHAR2      := '' 
									  ,V_ITEM_MST_ID        IN VARCHAR2      := ''     
									  ,p_ITEM_CD            IN VARCHAR2      := ''     
									  ,p_USER_ID            IN VARCHAR2      := ''     
									  ,P_ACTV_YN            IN CHAR        := ''   
                                      ,P_RT_ROLLBACK_FLAG   OUT VARCHAR2
									  ,P_RT_MSG             OUT VARCHAR2    
				                   ) 
AS  
/*************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 
    -                        / Mssql converting
    - 2023.01.13 / kim sohee / for new item map
    - 2023.01.18 / KIM SOHEE / DEL_YN bug fix
    - 2023.01.19 / kim sohee / item & account & user key validation
************************************************************************/
		-- Paremeter 
		 V_ERR_TYPE                 VARCHAR2(50)      := NULL  ;  
		 V_EMP_ID                   VARCHAR2(32)      := NULL ;   
         P_ERR_STATUS INT := 0;
         P_ERR_MSG VARCHAR2(4000) :='';
         P_ACCOUNT_ID   CHAR(32) := V_ACCOUNT_ID;
         P_ITEM_MST_ID  CHAR(32) := V_ITEM_MST_ID;
         V_ENT_COUNT INT := 0;
         V_ACTV_YN  CHAR(1) := P_ACTV_YN;
BEGIN 
-- EMPLOYEE 

IF (P_EMP_NO IS NULL)
	THEN
	   P_ERR_MSG := 'MSG_0014'; 
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);	
END IF;
-- EMP_ID Setting 
    SELECT ID INTO V_EMP_ID  
      FROM TB_AD_USER
    WHERE USERNAME = P_EMP_NO
    ;

-- Account u？
IF (p_ACCOUNT_ID IS NULL)
THEN
    	SELECT ID  into P_ACCOUNT_ID
          FROM TB_DP_ACCOUNT_MST 
         WHERE ACCOUNT_CD = p_ACCOUNT_CD
         ;
END IF;
       IF (P_ACCOUNT_ID IS NULL)
        THEN
           P_ERR_MSG := 'MSG_0015' ;
           RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);	        
        END IF
        ;

-- item
IF (p_ITEM_MST_ID IS NULL)
THEN
	SELECT ID  INTO P_ITEM_MST_ID
      FROM TB_CM_ITEM_MST 
     WHERE ITEM_CD = p_ITEM_CD
    ;
END IF;
    IF (P_ITEM_MST_ID IS NULL)
    THEN
	   P_ERR_MSG := 'MSG_0017' ;
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);	
    END IF
    ;

    IF(P_ACTV_YN IS NULL)
    THEN
        V_ACTV_YN := 'Y';
    END IF;


-- Account + Item 의 1개의 값은 1명의 User만 담당할 수 있다. 중복된 데이터가 있는 경우 msg
SELECT COUNT(*)  INTO P_ERR_STATUS
		    FROM TB_DP_USER_ITEM_ACCOUNT_MAP UI 
		   WHERE UI.ACCOUNT_ID = P_ACCOUNT_ID 
		     AND UI.ITEM_MST_ID = P_ITEM_MST_ID 
			 AND UI.AUTH_TP_ID = P_AUTH_TP_ID 
             AND UI.EMP_ID = V_EMP_ID 
			 AND ID != P_ID
             ;
IF P_ERR_STATUS > 0
	THEN
	   P_ERR_MSG := 'MSG_0013' ;
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);	
	END IF;


				MERGE INTO TB_DP_USER_ITEM_ACCOUNT_MAP  TGT   
				USING ( 
						SELECT  p_ID             AS ID 
						       ,p_AUTH_TP_ID     AS  AUTH_TP_ID
							   ,p_ACCOUNT_ID     AS  ACCOUNT_ID
							   ,p_ITEM_MST_ID    AS  ITEM_MST_ID
							   ,V_EMP_ID         AS  EMP_ID
							   ,p_USER_ID        AS USER_ID --p_USER_ID   AS  USER_ID
							   ,V_ACTV_YN       AS ACTV_YN
					  FROM DUAL ) SRC
				ON      (TGT.ID = SRC.ID) 
				WHEN MATCHED THEN
					 UPDATE 
					   SET   TGT.MODIFY_BY   = SRC.USER_ID
					        ,TGT.ACCOUNT_ID  = SRC.ACCOUNT_ID
							,TGT.ITEM_MST_ID = SRC.ITEM_MST_ID 
							,TGT.ACTV_YN  = SRC.ACTV_YN
							,TGT.MODIFY_DTTM = SYSDATE
				WHEN NOT MATCHED THEN 
					 INSERT (
					            ID 
							  , AUTH_TP_ID
							  , ACCOUNT_ID
							  , ITEM_MST_ID
							  , EMP_ID
							  , ACTV_YN 
							  , CREATE_BY
							  , CREATE_DTTM
							) 
					 VALUES (
					             TO_SINGLE_BYTE(SYS_GUID()) 
							  , SRC.AUTH_TP_ID
							  , SRC.ACCOUNT_ID
							  , SRC.ITEM_MST_ID
							  , SRC.EMP_ID
							  , SRC.ACTV_YN
							  , SRC.USER_ID 
							  , SYSDATE
 							) 
							;



    FOR CUR IN (
		SELECT VER_ID
		  FROM (
		      SELECT M.ID AS VER_ID
		           , DENSE_RANK () OVER (PARTITION BY M.PLAN_TP_ID ORDER BY M.CREATE_DTTM DESC) AS RW
		        FROM TB_DP_CONTROL_BOARD_VER_MST M
		             INNER JOIN
		             TB_DP_CONTROL_BOARD_VER_DTL D
		          ON M.ID = D.CONBD_VER_MST_ID
		             INNER JOIN
		             TB_CM_COMM_CONFIG W
		          ON W.ID = D.WORK_TP_ID
		         AND W.CONF_CD = 'CL'
		             INNER JOIN
		             TB_CM_COMM_CONFIG C
		          ON D.CL_STATUS_ID = C.ID
		         AND C.CONF_CD != 'CLOSE'
		       WHERE EXISTS (SELECT DISTINCT VER_ID FROM TB_DP_ENTRY WHERE VER_ID = M.ID)
		  ) A
		 WHERE RW = 1
	) LOOP
	   SELECT COUNT(1) INTO V_ENT_COUNT
	     FROM TB_DP_ENTRY
	    WHERE VER_ID= CUR.VER_ID
	      AND ITEM_MST_ID = P_ITEM_MST_ID
	      AND ACCOUNT_ID = P_ACCOUNT_ID;

	   IF V_ENT_COUNT = 0 THEN
	       SP_UI_DP_93_ITEM_ACCT_CREATE(
	           P_ITEM_MST_ID,
	           NULL,
	           P_ACCOUNT_ID,
	           NULL,
	           P_USER_ID,
	           P_AUTH_TP_ID,
	           CUR.VER_ID
	       );
	   END IF;

	END LOOP;


        SP_UI_DP_00_MAKE_USER_GROUP ( V_EMP_ID  , P_EMP_NO, P_AUTH_TP_ID );
        SP_UI_DPD_MAKE_HIER_USER;

	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001'; 
       /*  ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN   
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF;     

END;
/

