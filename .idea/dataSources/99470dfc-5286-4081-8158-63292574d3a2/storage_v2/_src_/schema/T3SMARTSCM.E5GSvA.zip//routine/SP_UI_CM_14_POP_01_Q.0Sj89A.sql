create PROCEDURE "SP_UI_CM_14_POP_01_Q" (
    P_CONF_KEY          IN VARCHAR2:='' ,
    P_VIEW_ID           IN VARCHAR2:='' ,
    P_ATTR_01           IN VARCHAR2:='' ,
    pResult OUT SYS_REFCURSOR
)
IS
BEGIN
	
	IF P_CONF_KEY ='001' /* HOLIDAY */
	THEN
		OPEN pResult FOR
	        SELECT A.ID 
				 , A.SHPP_LEADTIME_DTL_ID
				 , A.CALENDAR_ID
				 , A.CALENDAR_DESCRIP           AS CALENDAR_DESC
				 , A.STRT_DATE                  AS START_DATE
				 , A.END_DATE                   AS END_DATE
				 , A.ACTV_YN
				 , A.CYCL_TP_ID                 AS CYCLE_TYPE
			  FROM TB_CM_HOLIDAY A 
			 WHERE A.SHPP_LEADTIME_DTL_ID = P_ATTR_01
			   AND ACTV_YN = 'Y';
	
	ELSIF P_CONF_KEY ='002' /* EXCEPTION - MONTHLY */
	THEN
		OPEN pResult FOR 
	        SELECT A.ID
				 , A.SHPP_LEADTIME_DTL_ID
				 , A.STRT_DATE
				 , A.END_DATE
				 , A.TRANSFER_DD
				 , P_VIEW_ID AS VIEW_ID
			  FROM TB_CM_SHIP_LT_EXCEPTION_SCH A 
			 WHERE A.SHPP_LEADTIME_DTL_ID = P_ATTR_01
			   AND A.ACTV_YN = 'Y';
	
	ELSIF P_CONF_KEY ='003' /* EXCEPTION - DAILY */
	THEN
		OPEN pResult FOR 
	        SELECT A.ID
				 , A.SHPP_LEADTIME_DTL_ID
				 , A.STRT_DATE
				 , A.END_DATE
				 , A.MON_YN
				 , A.TUE_YN
				 , A.WED_YN
				 , A.THU_YN
				 , A.FRI_YN
				 , A.SAT_YN
				 , A.SUN_YN
				 , P_VIEW_ID AS VIEW_ID
			  FROM TB_CM_SHIP_LT_EXCEPTION_SCH A
		     WHERE A.SHPP_LEADTIME_DTL_ID = P_ATTR_01
			   AND A.ACTV_YN = 'Y';
	
	ELSIF P_CONF_KEY ='004' /* ???? ？?? ?？??？??？？??？ */
	THEN
		OPEN pResult FOR 
	        SELECT A.ID
				 , A.DD
				 --, A.ACTV_YN 
				 , 'Y' AS ACTV_YN
				 , P_VIEW_ID AS VIEW_ID
			  FROM TB_CM_SHIP_LT_MONTHLY_SCH A 
		     WHERE A.SHPP_LEADTIME_DTL_ID = P_ATTR_01
			   AND A.ACTV_YN = 'Y';
	
	END IF;

END;

/

