create PROCEDURE SP_UI_CM_05_Q6 (
    P_LOCAT_ITEM_ID     IN CHAR := ''
    ,pResult OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN pResult FOR
    WITH TEMP_LOCAT_ITEM_INFO AS
    (
    SELECT  A.COMN_CD_NM      AS LOCAT_TP_NM
            ,B.LOCAT_LV       AS LOCAT_LV
            ,C.LOCAT_CD       AS LOCAT_CD
            ,C.LOCAT_NM       AS LOCAT_NM
            ,I.COMN_CD        AS BOM_ITEM_TP
            ,I.COMN_CD_NM     AS BOM_ITEM_TP_NM
            ,J.COMN_CD        AS PROCUR_TP
            ,J.COMN_CD_NM     AS PROCUR_TP_NM
            ,F.ITEM_CD        AS ITEM_CD
            ,F.ITEM_NM        AS ITEM_NM
            ,F.DESCRIP        AS ITEM_DESCRIP
            ,G.CONVN_NM       AS ITEM_TP_NM
            ,H.UOM_NM         AS ITEM_UOM
            ,D.ID             AS LOCAT_MGMT_ID
            ,E.ID             AS LOCAT_ITEM_ID
            ,F.ID             AS ITEM_MST_ID
        FROM TB_AD_COMN_CODE A
            INNER JOIN 
            TB_CM_LOC_MST B
        ON (A.ID = B.LOCAT_TP_ID)
            INNER JOIN 
            TB_CM_LOC_DTL C
        ON (B.ID = C.LOCAT_MST_ID)
            INNER JOIN 
            TB_CM_LOC_MGMT D
        ON (C.ID = D.LOCAT_ID)
            INNER JOIN 
            TB_CM_SITE_ITEM E
        ON (D.ID = E.LOCAT_MGMT_ID)
            INNER JOIN 
            TB_CM_ITEM_MST F
        ON (E.ITEM_MST_ID = F.ID)
            INNER JOIN 
            TB_CM_ITEM_TYPE G
        ON (F.ITEM_TP_ID = G.ID)
            INNER JOIN 
            TB_CM_UOM H
       ON (F.UOM_ID = H.ID)
            INNER JOIN 
            TB_AD_COMN_CODE I
       ON (E.BOM_ITEM_TP_ID = I.ID)
            INNER JOIN 
            TB_AD_COMN_CODE J
       ON (E.PROCUR_TP_ID = J.ID)     
       )
       SELECT  E.ID 
              ,MAX(I.COMN_CD_NM)            AS P_LOCAT_TP_NM
              ,MAX(H.LOCAT_LV  )            AS P_LOCAT_LV 
              ,MAX(G.LOCAT_CD  )            AS P_LOCAT_CD 
              ,MAX(G.LOCAT_NM  )            AS P_LOCAT_NM 
              ,MAX(J.ITEM_CD   )            AS P_ITEM_CD  
              ,MAX(J.ITEM_NM   )            AS P_ITEM_NM  
              ,MAX(K.CONVN_NM)              AS P_ITEM_TP_NM
              ,MAX(NVL(D.BOM_LV,NULL))      AS P_BOM_LV
              ,MAX(NVL(D.BOM_LV,0) + 1)     AS P_TRANS_BOM_LV
              ,MAX(A.LOCAT_TP_NM)           AS ORI_LOCAT_TP_NM
              ,MAX(A.LOCAT_LV   )           AS ORI_LOCAT_LV 
              ,MAX(A.LOCAT_CD	)           AS ORI_LOCAT_CD
              ,MAX(A.LOCAT_NM	)           AS ORI_LOCAT_NM
              ,MAX(A.LOCAT_ITEM_ID)         AS ORI_LOCAT_ITEM_ID
              ,MAX(A.ITEM_CD	)           AS ORI_ITEM_CD
              ,MAX(A.ITEM_NM	)           AS ORI_ITEM_NM
         FROM TEMP_LOCAT_ITEM_INFO A
              INNER JOIN 
              TB_CM_SITE_ITEM B
           ON (A.ITEM_MST_ID = B.ITEM_MST_ID)
               INNER JOIN
              TB_CM_GLOBAL_BOM_DTL C
           ON (B.ID = C.LOCAT_ITEM_ID)
               INNER JOIN 
              TB_CM_GLOBAL_BOM_MST D
           ON (C.PRDUCT_BOM_MST_ID = D.ID)
               INNER JOIN 
              TB_CM_SITE_ITEM E
           ON (D.LOCAT_ITEM_ID = E.ID)
               INNER JOIN 
              TB_CM_LOC_MGMT F
           ON (E.LOCAT_MGMT_ID = F.ID)
               INNER JOIN 
              TB_CM_LOC_DTL G
           ON (F.LOCAT_ID = G.ID)
               INNER JOIN 
              TB_CM_LOC_MST H
           ON (G.LOCAT_MST_ID = H.ID)
               INNER JOIN 
              TB_AD_COMN_CODE I
           ON (H.LOCAT_TP_ID = I.ID)
               INNER JOIN 
              TB_CM_ITEM_MST J
           ON (E.ITEM_MST_ID = J.ID)
               INNER JOIN 
              TB_CM_ITEM_TYPE K
           ON (J.ITEM_TP_ID = K.ID)
        WHERE 1=1
          AND A.LOCAT_ITEM_ID = P_LOCAT_ITEM_ID
        AND E.ID IS NOT NULL
       GROUP BY E.ID;
END;

/

