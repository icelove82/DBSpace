create FUNCTION "FN_SRP_TEMP_ITEM" 
(
   P_USER_ID     IN VARCHAR2
  ,P_SALES_LV_ID IN VARCHAR2
  ,P_UNIT_ID     IN VARCHAR2
--  ,V_ITEM        IN VARCHAR2
)
---------------------------------------------------------
    -- (SRP UNIT？？ ？？？？ ？？？) USER？？ ？？？ε？？？？？ ITEM, UNIT
---------------------------------------------------------
RETURN TMP_ITEM IS
C_TMP_ITEM TMP_ITEM := TMP_ITEM();
CURSOR C_DATA_IMPORT IS 
SELECT TP_TMP_ITEM(
                         ITEM_ID       =>    IM.ITEM_ID      
                        ,ITEM_CD       =>    IM.ITEM_CD
                        ,ITEM_NM       =>    IM.ITEM_NM
                        ,PARENT_ITEM_LV_ID => IM.PARENT_ITEM_LV_ID
						,SRP_UNIT_ID   =>  	 UM.ID				
						,SRP_UNIT_CD   =>	 UM.SRP_UNIT_CD	
                        ,SRP_UNIT_NM   =>    UM.SRP_UNIT_NM
                  )                 

		FROM (
                    SELECT M.SRP_UNIT_ID, A.ID AS ITEM_ID, A.ITEM_CD, A.ITEM_NM, A.PARENT_ITEM_LV_ID
                      FROM TB_SRP_USER_ITEM_MAP M
                           INNER JOIN
                           TABLE(FN_DP_TEMP_ITEM_TREE()) IH
                        ON M.ITEM_LV_ID = IH.PATH_ID
                           INNER JOIN
                           TB_CM_ITEM_MST A 
                        ON IH.LEAF_ITEM_LV_ID = A.PARENT_ITEM_LV_ID
                     WHERE A.DP_PLAN_YN = 'Y'
                       AND A.DEL_YN != 'Y'
                       AND M.SRP_UNIT_ID = P_UNIT_ID
                       AND M.ACTV_YN = 'Y'
                    GROUP BY M.SRP_UNIT_ID, A.ID, A.ITEM_CD, A.ITEM_NM, A.PARENT_ITEM_LV_ID
                    UNION
                    -- ITEM
                    SELECT M.SRP_UNIT_ID, A.ID AS ITEM_ID, A.ITEM_CD, A.ITEM_NM, A.PARENT_ITEM_LV_ID
                      FROM TB_SRP_USER_ITEM_MAP M
                           INNER JOIN
                           TB_CM_ITEM_MST A
                        ON A.ID = M.ITEM_MST_ID                     
                     WHERE A.DP_PLAN_YN = 'Y'
                       AND M.SRP_UNIT_ID = P_UNIT_ID
                       AND A.DEL_YN != 'Y'
                       AND M.ACTV_YN = 'Y'
             )IM            
              INNER JOIN
              TB_SRP_UNIT_MST  UM
          ON  IM.SRP_UNIT_ID = UM.ID  
              INNER JOIN
              TB_SRP_UNIT_WAREHOUSE_MAP UW
          ON  UW.SRP_UNIT_ID = UM.ID
              INNER JOIN          
              (
                SELECT ITEM_MST_ID, INV_LOCAT_ID
                  FROM TB_CM_WAREHOUSE_STOCK_MST
                 WHERE ACTV_YN = 'Y' 
              GROUP BY ITEM_MST_ID, INV_LOCAT_ID
              ) SM
          ON  SM.INV_LOCAT_ID = UW.INV_LOCAT_ID
         AND  SM.ITEM_MST_ID = IM.ITEM_ID
--		WHERE 1=1
            --'David'		
--          AND IM.SALES_LV_ID = P_SALES_LV_ID
--          AND UM.ID          = P_UNIT_ID
--          AND IH.ITEM_ID     = CASE WHEN V_ITEM    IS NULL THEN IH.ITEM_ID ELSE V_ITEM    END
		;


BEGIN
	OPEN C_DATA_IMPORT;
    FETCH C_DATA_IMPORT BULK COLLECT INTO C_TMP_ITEM;
    CLOSE C_DATA_IMPORT;

    RETURN C_TMP_ITEM;
END;
/

