create PROCEDURE                "SP_UI_DP_10_Q1" (p_SALES_LV      IN VARCHAR2 := ''
                                            , p_SRP_LV_YN         IN VARCHAR2 := ''
                                            , p_ACTV_YN            IN VARCHAR2 := ''
                                             ,p_LV_TP_ID     VARCHAR2 := ''                                            
                                             ,pRESULT       OUT SYS_REFCURSOR ) IS 
BEGIN

OPEN pRESULT          
FOR 
SELECT SL.ID
      ,SL.SALES_LV_CD
      ,SL.SALES_LV_NM
      ,SL.LV_MGMT_ID
      ,SL.PARENT_SALES_LV_ID
      ,SL2.SALES_LV_CD  AS PARENT_SALES_LV_CD
      ,SL2.SALES_LV_NM  AS PARENT_SALES_LV_NM  
      ,SL.CURCY_CD_ID
      ,SL.SEQ
      ,SL.VIRTUAL_YN
      ,SL.ACTV_YN
      ,SL.DEL_YN
      ,SL.SRP_YN
      ,SL.CREATE_BY
      ,SL.CREATE_DTTM
      ,SL.MODIFY_BY
      ,SL.MODIFY_DTTM
  FROM TB_DP_SALES_LEVEL_MGMT SL 
       INNER JOIN
       TB_CM_LEVEL_MGMT  LM
    ON LM.ID = SL.LV_MGMT_ID 
   AND COALESCE(LM.DEL_YN, 'N') = 'N'
   AND LM.ACTV_YN = 'Y'   
   AND LM.SRP_LV_YN LIKE '%' || LTRIM(RTRIM(p_SRP_LV_YN)) || '%'    
   AND LM.LV_TP_ID = p_LV_TP_ID
       LEFT OUTER JOIN  
       TB_DP_SALES_LEVEL_MGMT SL2 
    ON SL.PARENT_SALES_LV_ID = SL2.ID 
   AND COALESCE(SL2.DEL_YN, 'N') = 'N' 
   AND SL2.ACTV_YN = 'Y'   		
  WHERE 1=1
    AND SL.LV_MGMT_ID LIKE '%' || LTRIM(RTRIM(p_SALES_LV)) || '%'    
    AND (NVL(SL.ACTV_YN,'N') LIKE '%' || RTRIM(p_ACTV_YN) || '%'   OR   p_ACTV_YN IS NULL)
  ORDER BY LM.SEQ, SL.SEQ;




END
;
/

