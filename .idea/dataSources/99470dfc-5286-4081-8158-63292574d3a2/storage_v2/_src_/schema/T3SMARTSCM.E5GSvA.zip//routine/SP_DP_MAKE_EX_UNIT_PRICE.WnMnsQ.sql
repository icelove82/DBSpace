create PROCEDURE SP_DP_MAKE_EX_UNIT_PRICE
(
     P_MIN_MEASURE_VAL  IN INT      := 1000
    ,P_MAX_MEASURE_VAL  IN INT      := 5000
)IS
BEGIN
-- 1. TB_DP_UNIT_PRICE 
DELETE FROM TB_DP_UNIT_PRICE;
commit;

-- 2. TB_DP_UNIT_PRICE 
-- TB_DP_USER_ITEM_ACCOUNT_MAP
INSERT INTO TB_DP_UNIT_PRICE
( ID
, ACCOUNT_ID
, ITEM_MST_ID
, BASE_DATE
, UTPIC
, CURCY_CD_ID
, CREATE_BY
, CREATE_DTTM
, MODIFY_BY
, MODIFY_DTTM
, PRICE_TP_ID
, ATTR_01)
     SELECT TO_SINGLE_BYTE(SYS_GUID())  AS ID
          , ACCOUNT_ID AS ACCOUNT_ID          
          , ITEM_MST_ID AS ITEM_MST_ID          
          , TO_CHAR(SYSDATE,'YY') || '/01/01' AS BASE_DATE
          , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL)) AS UTPIC
          , NULL AS CURCY_CD_ID
          , NULL AS CREATE_BY
          , NULL AS CREATE_DTTM
          , NULL AS MODIFY_BY
          , NULL AS MODIFY_DTTM
          , '5CD5F31CCE334DC798FEE3D9DFAD46E1' AS PRICE_TP_ID
          , NULL AS ATTR_01
      FROM 
           (
               SELECT ACCOUNT_ID
                    , ITEM_MST_ID
                 FROM TB_DP_USER_ITEM_ACCOUNT_MAP
                UNION
               SELECT ACCOUNT_ID
                    , ITEM_MST_ID
                 FROM 
                 (    
                    SELECT (CASE WHEN im.ITEM_LV_ID IS NULL THEN im.ITEM_MST_ID
                                 WHEN im.ITEM_LV_ID IS NOT NULL THEN ih.ITEM_ID END) AS ITEM_MST_ID
                         , im.AUTH_TP_ID
                         , im.EMP_ID
                      FROM TB_DPD_ITEM_HIERACHY2 ih
                           INNER JOIN
                           TB_DP_USER_ITEM_MAP im
                        ON (   ih.LVL01_ID = im.ITEM_LV_ID
                            OR ih.LVL02_ID = im.ITEM_LV_ID
                            OR ih.LVL03_ID = im.ITEM_LV_ID 
                            OR ih.LVL04_ID = im.ITEM_LV_ID 
                            OR ih.LVL05_ID = im.ITEM_LV_ID 
                            OR ih.LVL06_ID = im.ITEM_LV_ID 
                            OR ih.LVL07_ID = im.ITEM_LV_ID 
                            OR ih.LVL08_ID = im.ITEM_LV_ID 
                            OR ih.LVL09_ID = im.ITEM_LV_ID 
                            OR ih.LVL10_ID = im.ITEM_LV_ID 
                            )
                    ) ITEM
                    INNER JOIN
                    (    -- ACCOUNT 
                         SELECT (CASE WHEN am.SALES_LV_ID IS NULL THEN am.ACCOUNT_ID
                                      WHEN am.SALES_LV_ID IS NOT NULL THEN ah.ACCOUNT_ID end) AS ACCOUNT_ID
                              , am.AUTH_TP_ID
                              , am.EMP_ID
                           FROM TB_DPD_ACCOUNT_HIERACHY2 ah
                                INNER JOIN
                                TB_DP_USER_ACCOUNT_MAP am
                             ON (   ah.LVL01_ID = am.SALES_LV_ID
                                 OR ah.LVL02_ID = am.SALES_LV_ID 
                                 OR ah.LVL03_ID = am.SALES_LV_ID 
                                 OR ah.LVL04_ID = am.SALES_LV_ID 
                                 OR ah.LVL05_ID = am.SALES_LV_ID 
                                 OR ah.LVL06_ID = am.SALES_LV_ID 
                                 OR ah.LVL07_ID = am.SALES_LV_ID 
                                 OR ah.LVL08_ID = am.SALES_LV_ID 
                                 OR ah.LVL09_ID = am.SALES_LV_ID 
                                 OR ah.LVL10_ID = am.SALES_LV_ID 
                                 )
                    ) ACCOUNT
                    ON (ITEM.EMP_ID = ACCOUNT.EMP_ID and ITEM.AUTH_TP_ID = ACCOUNT.AUTH_TP_ID)
               )
      ;

commit;

END;
/

