create PROCEDURE "SP_UI_CM_17_Q3" (
	P_MAIN_VER_ID   IN CHAR :='',
    P_SIMUL_VER_ID  IN VARCHAR2 := '' ,
    pResult 		OUT SYS_REFCURSOR
)
IS
    V_SIMUL_VER_ID VARCHAR2(100) := P_SIMUL_VER_ID;
    
BEGIN

     IF P_SIMUL_VER_ID IS NULL THEN
		SELECT	MAX(A.SIMUL_VER_ID) INTO V_SIMUL_VER_ID
		FROM	TB_CM_CONBD_MAIN_VER_DTL A,
				TB_CM_CONBD_MAIN_VER_MST B
		WHERE	B.ID = A.CONBD_MAIN_VER_MST_ID
		AND		MAIN_VER_ID = P_MAIN_VER_ID
		AND		A.MODIFY_DTTM IS NOT NULL;
	 END IF;
    
    OPEN pResult FOR 
      SELECT  C.COMN_CD                         AS MODULE_CD
              ,A.MAIN_VER_ID                     AS MAIN_VER_ID
              ,A.DESCRIP                         AS MAIN_VER_DESCRIP
              ,E.SNRIO_VER_ID                    AS SNRIO_VER_ID
              ,E.DESCRIP                         AS SNRIO_VER_DESCRIP
              ,D.STEP                            AS STEP
              ,D.PROCESS_DESCRIP                 AS PROCESS_DESCRIP
              ,F.COMN_CD_NM                      AS PROCESS_TP
              ,G.SIMUL_VER_ID                    AS ORIGINAL_VER_ID
              ,G.SIMUL_VER_DESCRIP               AS ORIGINAL_DESCRIP
              ,B.SIMUL_VER_ID                    AS MAX_SIMUL_VER_ID
              ,B.SIMUL_VER_DESCRIP               AS SIMUL_VER_DESCRIP
              ,A.PLAN_SNRIO_MGMT_MST_ID
              ,B.PLAN_SNRIO_MGMT_DTL_ID
              ,NULL                              AS NEW_CONBD_MAIN_VER_DTL_ID
              ,B.CONBD_MAIN_VER_MST_ID
              ,D.PLAN_POLICY_MGMT_ID
         FROM TB_CM_CONBD_MAIN_VER_MST A 
              INNER JOIN 
              TB_CM_CONBD_MAIN_VER_DTL B 
           ON (A.ID = B.CONBD_MAIN_VER_MST_ID)
              INNER JOIN 
              TB_AD_COMN_CODE C 
           ON (A.MODULE_ID = C.ID)
              INNER JOIN
              TB_CM_PLAN_SNRIO_MGMT_DTL D 
           ON (B.PLAN_SNRIO_MGMT_DTL_ID = D.ID)
              INNER JOIN 
              TB_CM_PLAN_SNRIO_MGMT_MST E 
           ON (D.PLAN_SNRIO_MGMT_MST_ID = E.ID)
              INNER JOIN 
              TB_AD_COMN_CODE F 
           ON (D.PROCESS_TP_ID = F.ID)
              LEFT OUTER JOIN 
              TB_CM_CONBD_MAIN_VER_DTL G 
           ON (B.REFER_CONBD_MAIN_VER_DTL_ID = G.ID)
        WHERE 1=1
          AND B.SIMUL_VER_ID = V_SIMUL_VER_ID;
          
END;

/

