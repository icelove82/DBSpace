create PROCEDURE        "SP_UI_DP_23_TIME_COMBO_Q1" 
(
 pRESULT       OUT SYS_REFCURSOR
)
IS 


BEGIN


OPEN pRESULT          
FOR SELECT	TO_number(A.ID) ID, A.CD_NM
FROM	(
		SELECT '24' ID, '12:00 AM' CD_NM, 0 SEQ
        FROM dual
		UNION 
		SELECT '1' ID, '01:00 AM' CD_NM, 1 SEQ
        FROM dual
		UNION 
		SELECT '2' ID, '02:00 AM' CD_NM, 2 SEQ
        FROM dual
		UNION 
		SELECT '3' ID, '03:00 AM' CD_NM, 3 SEQ
        FROM dual
		UNION 
		SELECT '4' ID, '04:00 AM' CD_NM, 4 SEQ
        FROM dual
		UNION 
		SELECT '5' ID, '05:00 AM' CD_NM, 5 SEQ
        FROM dual
		UNION
		SELECT '6' ID, '06:00 AM' CD_NM, 6 SEQ
        FROM dual
		UNION 
		SELECT '7' ID, '07:00 AM' CD_NM, 7 SEQ
        FROM dual
		UNION 
		SELECT '8' ID, '08:00 AM' CD_NM, 8 SEQ
        FROM dual
		UNION 
		SELECT '9' ID, '09:00 AM' CD_NM, 9 SEQ
        FROM dual
		UNION 
		SELECT '10' ID, '10:00 AM' CD_NM, 10 SEQ
        FROM dual
		UNION 
		SELECT '11' ID, '11:00 AM' CD_NM, 11 SEQ
        FROM dual
		UNION 
		SELECT '12' ID, '12:00 PM' CD_NM, 12 SEQ
        FROM dual
		UNION 
		SELECT '13' ID, '01:00 PM' CD_NM, 13 SEQ
        FROM dual
		UNION 
		SELECT '14' ID, '02:00 PM' CD_NM, 14 SEQ
        FROM dual
		UNION 
		SELECT '15' ID, '03:00 PM' CD_NM, 15 SEQ
        FROM dual
		UNION 
		SELECT '16' ID, '04:00 PM' CD_NM, 16 SEQ
        FROM dual
		UNION 
		SELECT '17' ID, '05:00 PM' CD_NM, 17 SEQ
        FROM dual
		UNION 
		SELECT '18' ID, '06:00 PM' CD_NM, 18 SEQ
        FROM dual
		UNION 
		SELECT '19' ID, '07:00 PM' CD_NM, 19 SEQ
        FROM dual
		UNION 
		SELECT '20' ID, '08:00 PM' CD_NM, 20 SEQ
        FROM dual
		UNION 
		SELECT '21' ID, '09:00 PM' CD_NM, 21 SEQ
        FROM dual
		UNION 
		SELECT '22' ID, '10:00 PM' CD_NM, 22 SEQ
        FROM dual
		UNION 
		SELECT '23' ID, '11:00 PM' CD_NM, 23 SEQ
        FROM dual
		) A
ORDER BY A.SEQ;




END
;


/

