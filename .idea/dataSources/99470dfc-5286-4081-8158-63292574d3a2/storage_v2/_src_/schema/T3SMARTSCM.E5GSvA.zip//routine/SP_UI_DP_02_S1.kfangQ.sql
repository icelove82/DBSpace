create PROCEDURE                SP_UI_DP_02_S1 (
    P_ID                IN VARCHAR2         := ''         
  , P_LV_TP_ID          IN VARCHAR2         := ''         
  , P_LV_CD             IN VARCHAR2         := ''         
  , P_LV_NM             IN VARCHAR2         := ''      
  , P_SEQ               IN VARCHAR2         := ''   -- cast(P_SEQ AS int)   AS  SEQ
  , P_LV_LEAF_YN        IN VARCHAR2         := ''  
  , P_SRP_LV_YN         IN VARCHAR2         := ''  
  , P_LEAF_YN           IN VARCHAR2         := ''  
  , P_ACTV_YN           IN VARCHAR2         := ''  
  , P_SALES_LV_YN       IN VARCHAR2         := ''  
  , P_ACCOUNT_LV_YN     IN VARCHAR2         := ''  
  , P_USER_ID           IN VARCHAR2         := ''  
  , P_RT_ROLLBACK_FLAG  OUT VARCHAR2
  , P_RT_MSG            OUT VARCHAR2                             
) IS
    P_ERR_STATUS INT := 0;
    P_ERR_MSG VARCHAR2(4000):='';
    P_COUNT1 INT;
    P_COUNT2 INT;
BEGIN
    P_RT_ROLLBACK_FLAG := 'true';
/***** Validation 1 Level Type *******************************************************/
    SELECT COUNT(CONF_NM) INTO P_ERR_STATUS
      FROM TB_CM_COMM_CONFIG
     WHERE ID = P_LV_TP_ID;

    IF (P_ERR_STATUS = 0 OR P_LV_TP_ID IS NULL) THEN
        P_ERR_MSG := 'MSG_5031';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;
/****** Validation 2 Level Code *****************************************************/
    IF (P_LV_CD IS NULL) THEN
        P_ERR_MSG := 'MSG_5032';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

    SELECT COUNT(LV_CD) INTO P_ERR_STATUS
      FROM TB_CM_LEVEL_MGMT
     WHERE LV_CD = P_LV_CD
       AND LV_TP_ID = P_LV_TP_ID
       AND ID != P_ID;
   
    IF (P_ERR_STATUS !=0) THEN
        P_ERR_MSG := 'MSG_5033';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;

    MERGE INTO TB_CM_LEVEL_MGMT TGT
    USING ( SELECT P_ID                 AS  ID
                 , P_LV_TP_ID           AS  LV_TP_ID
                 , P_LV_CD              AS  LV_CD
                 , P_LV_NM              AS  LV_NM
                 , CAST(P_SEQ AS INT)   AS  SEQ   
                 , CASE WHEN P_LV_LEAF_YN IS NULL OR P_LV_LEAF_YN ='' THEN 'N' ELSE P_LV_LEAF_YN END            AS  LV_LEAF_YN      
                 , CASE WHEN P_SRP_LV_YN IS NULL OR P_SRP_LV_YN ='' THEN 'N' ELSE P_SRP_LV_YN END               AS  SRP_LV_YN 
                 , CASE WHEN P_LEAF_YN IS NULL OR P_LEAF_YN ='' THEN 'N' ELSE P_LEAF_YN END                     AS  LEAF_YN 
                 , CASE WHEN P_ACTV_YN IS NULL OR P_ACTV_YN ='' THEN 'N' ELSE P_ACTV_YN END                     AS  ACTV_YN 
                 , CASE WHEN P_SALES_LV_YN IS NULL OR P_SALES_LV_YN ='' THEN 'N' ELSE P_SALES_LV_YN END         AS  SALES_LV_YN 
                 , CASE WHEN P_ACCOUNT_LV_YN IS NULL OR P_ACCOUNT_LV_YN ='' THEN 'N' ELSE P_ACCOUNT_LV_YN END   AS  ACCOUNT_LV_YN 
                 , P_USER_ID            AS  USER_ID
              FROM dual
          ) SRC
       ON (TGT.ID = SRC.ID)
     WHEN MATCHED THEN
        UPDATE 
           SET   TGT.LV_TP_ID      = SRC.LV_TP_ID        
                ,TGT.LV_CD         = SRC.LV_CD       
                ,TGT.LV_NM         = SRC.LV_NM          
                ,TGT.SEQ           = SRC.SEQ           
                ,TGT.LV_LEAF_YN    = SRC.LV_LEAF_YN     
                ,TGT.SRP_LV_YN     = SRC.SRP_LV_YN 
                ,TGT.LEAF_YN       = SRC.LEAF_YN 
                ,TGT.ACTV_YN       = SRC.ACTV_YN 
                ,TGT.SALES_LV_YN   = SRC.SALES_LV_YN 
                ,TGT.ACCOUNT_LV_YN = SRC.ACCOUNT_LV_YN
                --,TGT.DEL_YN        = SRC.DEL_YN 
                ,TGT.MODIFY_BY     = SRC.USER_ID       
                ,TGT.MODIFY_DTTM   = SYSDATE
     WHEN NOT MATCHED THEN 
        INSERT (
                   ID
                ,  LV_TP_ID     
                ,  LV_CD      
                ,  LV_NM        
                ,  SEQ      
                ,  LV_LEAF_YN   
                ,  SRP_LV_YN 
                ,  LEAF_YN 
                ,  ACTV_YN 
                ,  SALES_LV_YN 
                ,  ACCOUNT_LV_YN
                ,  DEL_YN 
                ,  CREATE_BY
                ,  CREATE_DTTM
               ) 
        VALUES (
                   TO_SINGLE_BYTE(SYS_GUID())  --(SELECT REPLACE(NEWID(),'-','') )
                ,  SRC.LV_TP_ID     
                ,  SRC.LV_CD      
                ,  SRC.LV_NM        
                ,  SRC.SEQ      
                ,  SRC.LV_LEAF_YN   
                ,  SRC.SRP_LV_YN 
                ,  SRC.LEAF_YN 
                ,  SRC.ACTV_YN 
                ,  SRC.SALES_LV_YN 
                ,  SRC.ACCOUNT_LV_YN
                ,  'N'--DEL_YN 
                ,  SRC.USER_ID 
                ,  SYSDATE
               ) 
    ;

    SELECT COUNT(*)
      INTO P_COUNT1
      FROM TB_CM_COMM_CONFIG CO
     INNER JOIN TB_CM_LEVEL_MGMT LM
        ON CO.ID = LM.LV_TP_ID
     WHERE CO.CONF_GRP_CD =  'DP_LV_TP'
       AND CO.ACTV_YN = 'Y'
       AND CO.CONF_CD = 'S'
       AND COALESCE(LM.DEL_YN,'N') = 'N'
       AND LM.ACTV_YN = 'Y'
       AND LM.SALES_LV_YN = 'Y' 
       AND LM.LV_CD = P_LV_CD;

    SELECT COUNT(*)
      INTO P_COUNT2
      FROM TB_AD_GROUP
     WHERE GRP_CD = P_LV_CD;
 
    IF (P_COUNT1 > 0 AND P_COUNT2 = 0) THEN
        INSERT INTO TB_AD_GROUP (
            ID 
          , GRP_CD 
          , GRP_NM 
          , GRP_DESCRIP
        )
        VALUES (
            RAWTOHEX(SYS_GUID())
          , P_LV_CD
          , P_LV_NM
          , P_LV_NM
        );
    END IF;

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';  --
       /*  ============================================================================*/
EXCEPTION WHEN OTHERS THEN  -- : e_products_invalid       
    IF(SQLCODE = -20001) THEN
        P_ERR_MSG := SQLERRM;
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
    --SP_COMM_RAISE_ERR();              
        RAISE;
    END IF;
END;
/

