create PROCEDURE "SP_UI_DPD_MAKE_HIER_TABLE"
IS
 P_CHECK INT ;
BEGIN
    -- Create Table and Index
    -- TABLE 재생성과 data변경을 프로시저에서 동시에 할 수는 없다.
    -- 프로시저 안에서 table을 만들려면 사용자에 권한이 부여돼야 한다.
SELECT COUNT(1) INTO P_CHECK FROM ALL_TABLES WHERE TABLE_NAME = 'TB_DPD_ITEM_HIER_CLOSURE' AND OWNER = (SELECT USER FROM DUAL);
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE 
        'CREATE TABLE TB_DPD_ITEM_HIER_CLOSURE('
            ||'	ANCESTER_ID char(32) NOT NULL,'
            ||'	ANCESTER_CD VARCHAR2(100) NULL,'
            ||'	DESCENDANT_ID char(32) NOT NULL,'
            ||'	DESCENDANT_CD VARCHAR2(50) NULL,'
            ||' DEPTH_NUM       INT NULL,'
            ||'	LEAF_YN char(1) NULL,'
            ||' USE_YN    CHAR(1) NOT NULL DEFAULT ''Y'' ,'            
            ||' LV_TP_CD    VARCHAR2(100) NOT NULL,'            
            ||' CREATE_BY   VARCHAR2(100) NULL,'                 
            ||' CREATE_DTTM   DATE NULL'                 
        ||')'
        ;
        EXECUTE IMMEDIATE
        'ALTER TABLE TB_DPD_ITEM_HIER_CLOSURE ADD ('
        ||   ' CONSTRAINT PK_TB_DPD_ITEM_HIER_CLOSURE '
        ||' PRIMARY KEY (ANCESTER_ID, DESCENDANT_ID)'
        ||')';
    END IF;    
SELECT COUNT(1) INTO P_CHECK FROM ALL_TABLES WHERE TABLE_NAME = 'TB_DPD_USER_HIER_CLOSURE' AND OWNER = (SELECT USER FROM DUAL);
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE 
    ' CREATE TABLE TB_DPD_USER_HIER_CLOSURE('
		||' ANCS_ROLE_ID char(32) NOT NULL,'
		||' ANCS_ROLE_CD VARCHAR2(100) NULL,'
		||' ANCS_ID char(32) NOT NULL,'
		||' ANCS_CD VARCHAR2(100) NULL,'
		||' DESC_ROLE_ID char(32) NOT NULL,'
		||' DESC_ROLE_CD VARCHAR2(50) NULL,'
		||' DESC_ID char(32) NOT NULL,'
		||' DESC_CD VARCHAR2(50) NULL,'
        ||' USER_ACCT_YN       CHAR(1) NULL,'
		||' MAPPING_SELF_YN char(1) NULL,'
        ||' CREATE_BY   VARCHAR2(100) NULL,'                 
        ||' CREATE_DTTM   DATE NULL'                         
        ||')'
        ;
        EXECUTE IMMEDIATE 
        'ALTER TABLE TB_DPD_USER_HIER_CLOSURE ADD ('
        ||   ' CONSTRAINT PK_TB_DPD_USER_HIER_CLOSURE '
        ||' PRIMARY KEY (ANCS_ROLE_ID, ANCS_ID, DESC_ROLE_ID, DESC_ID)'
        ||')';         
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_TABLES WHERE TABLE_NAME = 'TB_DPD_SALES_HIER_CLOSURE' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE 
        'CREATE TABLE TB_DPD_SALES_HIER_CLOSURE('
            ||'	ANCESTER_ID char(32) NOT NULL,'
            ||'	ANCESTER_CD VARCHAR2(100) NULL,'
            ||'	DESCENDANT_ID char(32) NOT NULL,'
            ||'	DESCENDANT_CD VARCHAR2(50) NULL,'
            ||'    DEPTH_NUM       INT NULL,'
            ||'	LEAF_YN char(1) NULL,'
            ||' USE_YN    CHAR(1) NOT NULL DEFAULT ''Y'' ,'            
            ||' LV_TP_CD    VARCHAR2(100) NOT NULL,'            
            ||' CREATE_BY   VARCHAR2(100) NULL,'                 
            ||' CREATE_DTTM   DATE NULL'                   
        ||')'
        ;
        EXECUTE IMMEDIATE
        'ALTER TABLE TB_DPD_SALES_HIER_CLOSURE ADD ('
        ||   ' CONSTRAINT PK_TB_DPD_SALES_HIER_CLOSURE '
        ||' PRIMARY KEY (ANCESTER_ID, DESCENDANT_ID)'
        ||')';        
    END IF;
END
;
/

