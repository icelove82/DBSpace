create PROCEDURE                "SP_UI_DP_12_Q1" (p_SALES_LV   IN VARCHAR2 := ''
                                      , p_SRP_LV_YN   IN VARCHAR2 := ''
                                             ,pRESULT       OUT SYS_REFCURSOR ) IS 
BEGIN

OPEN pRESULT
FOR
SELECT SL.ID
      ,SL.SALES_LV_CD
      ,SL.SALES_LV_NM
      ,SL.LV_MGMT_ID
      ,SL.PARENT_SALES_LV_ID
      ,SL2.SALES_LV_CD  AS PARENT_SALES_LV_CD
      ,SL2.SALES_LV_NM  AS PARENT_SALES_LV_NM  
      ,SL.CURCY_CD_ID
      ,SL.SEQ
      ,SL.ACTV_YN
      ,SL.CREATE_BY
      ,SL.CREATE_DTTM
      ,SL.MODIFY_BY
      ,SL.MODIFY_DTTM
  FROM TB_CM_CONFIGURATION A
     , TB_CM_COMM_CONFIG B
     , TB_CM_LEVEL_MGMT  LM
     , TB_DP_SALES_LEVEL_MGMT SL 
         LEFT OUTER JOIN  TB_DP_SALES_LEVEL_MGMT SL2 ON  SL.PARENT_SALES_LV_ID = SL2.ID AND NVL(SL2.DEL_YN, 'N') = 'N' AND SL2.ACTV_YN = 'Y'
  WHERE A.MODULE_CD = 'DP'
    AND A.ID = B.CONF_ID
    AND B.CONF_GRP_CD = 'DP_LV_TP'
    AND B.CONF_CD = 'S'
    AND B.ID = LM.LV_TP_ID  -- S/C/I
    AND NVL(LM.DEL_YN, 'N') = 'N'
    AND LM.ACTV_YN = 'Y'
    AND LM.ID = SL.LV_MGMT_ID 
    AND LM.SRP_LV_YN LIKE '%' || p_SRP_LV_YN || '%'    
    AND SL.DEL_YN = 'N'
    AND SL.VIRTUAL_YN = 'N'
    AND SL.LV_MGMT_ID LIKE '%' || trim(p_SALES_LV) || '%'    

  ORDER BY LM.SEQ, SL.SEQ
 ;




END
;
/

