create PROCEDURE                "SP_UI_DP_08_Q1" (p_ITEM_LV       IN  VARCHAR2 := ''
                                             ,p_ACTV_YN            IN VARCHAR2 := ''
                                             ,p_LV_TP_ID     VARCHAR2 := ''
                                             ,pRESULT       OUT SYS_REFCURSOR ) IS 


BEGIN
 
 
OPEN pRESULT          
FOR  
SELECT IL.ID
      ,IL.ITEM_LV_CD
      ,IL.ITEM_LV_NM
      ,IL.LV_MGMT_ID
      ,IL.ATTR_01
      ,NVL(IL.PARENT_ITEM_LV_ID, '') AS PARENT_ITEM_LV_ID
      ,IL2.ITEM_LV_CD  AS PARENT_ITEM_LV_CD
      ,IL2.ITEM_LV_NM  AS PARENT_ITEM_LV_NM        
      ,IL.SEQ
      ,IL.ACTV_YN
      ,IL.DEL_YN
      ,IL.CREATE_BY
      ,IL.CREATE_DTTM
      ,IL.MODIFY_BY
      ,IL.MODIFY_DTTM
  FROM TB_CM_CONFIGURATION A
     , TB_CM_COMM_CONFIG B
     , TB_CM_LEVEL_MGMT  LM
     , TB_CM_ITEM_LEVEL_MGMT IL 
          LEFT OUTER JOIN  TB_CM_ITEM_LEVEL_MGMT IL2 ON  IL.PARENT_ITEM_LV_ID = IL2.ID AND IL2.DEL_YN = 'N' AND IL2.ACTV_YN = 'Y'      
  WHERE A.MODULE_CD = 'DP'
    AND A.ID = B.CONF_ID
    AND B.CONF_GRP_CD = 'DP_LV_TP'
    --AND B.CONF_CD = 'I'
    AND B.ID = p_LV_TP_ID
    AND B.ID = LM.LV_TP_ID  -- S/C/I
    AND COALESCE(LM.DEL_YN, 'N') = 'N'
    AND LM.ACTV_YN = 'Y'
    AND LM.ID = IL.LV_MGMT_ID 
--    AND IL.DEL_YN = 'N'
    AND IL.LV_MGMT_ID  LIKE '%' || LTRIM(RTRIM(p_ITEM_LV)) || '%'
    AND (IL.ACTV_YN LIKE '%' || RTRIM(p_ACTV_YN) || '%' OR RTRIM(P_ACTV_YN) IS NULL)
  ORDER BY LM.SEQ, IL.SEQ
 ;


END
;
/

