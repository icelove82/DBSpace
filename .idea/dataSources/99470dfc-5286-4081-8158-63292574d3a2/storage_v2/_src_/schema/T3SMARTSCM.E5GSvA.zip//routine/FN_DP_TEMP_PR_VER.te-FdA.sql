create FUNCTION  FN_DP_TEMP_PR_VER
(
   P_VER_ID     IN CHAR
  ,P_PLAN_TP_ID IN CHAR
)
/**********************************************************************************************************
    -- Get Prev DP Version
    
    history (date / writer / comment)
    - 2021.02.23 / KSH / wrong code fix
*********************************************************************************************************/
RETURN DP_TEMP_PR_VER IS
C_DP_TEMP_PR_VER DP_TEMP_PR_VER := DP_TEMP_PR_VER();
-- YEAR
CURSOR C_DATA_IMPORT IS 
WITH VER
AS (SELECT MIN(CONBD_VER_MST_ID) KEEP (DENSE_RANK FIRST ORDER BY CREATE_DTTM DESC)  AS ID
	  FROM TB_DP_CONTROL_BOARD_VER_DTL D  
	 WHERE CONBD_VER_MST_ID != P_VER_ID 
	   AND PLAN_TP_ID = P_PLAN_TP_ID 
	   AND D.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_cD = 'DP_WK_TP' AND CONF_CD = 'CL')
	   AND D.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
       AND CONBD_VER_MST_ID IN (SELECT ID FROM TB_dP_CONTROL_BOARD_VER_MST)
)
 SELECT TP_DP_TEMP_PR_VER 
    ( ITEM_MST_ID => ITEM_MST_ID
    , ACCOUNT_ID => ACCOUNT_ID
    , BASE_DATE => BASE_DATE
    , AUTH_TP_ID => AUTH_TP_ID
    , QTY => QTY
    , QTY_1 => QTY_1
    , QTY_2 => QTY_2
    , QTY_3 => QTY_3
    )
   FROM TB_DP_ENTRY
  WHERE VER_ID = (SELECT ID FROM VER)
;
BEGIN  
        OPEN C_DATA_IMPORT;
        FETCH C_DATA_IMPORT BULK COLLECT INTO C_DP_TEMP_PR_VER;
        CLOSE C_DATA_IMPORT;    
    RETURN C_DP_TEMP_PR_VER;
END;
/

