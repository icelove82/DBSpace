create PROCEDURE SP_UI_CM_10_POP_S1 (
	P_TRANSP_MGMT_MST_ID        IN CHAR := NULL,
	P_BOD_TP_ID				    IN CHAR := NULL,
	P_CONSUME_LOCAT_MGMT_ID	    IN CHAR := NULL,
	P_SUPPLY_LOCAT_MGMT_ID	    IN CHAR := NULL,
	P_ITEM_MST_ID			    IN CHAR := NULL,
	P_LOAD_UOM_ID			    IN CHAR := NULL,
	P_TRANSP_LOTSIZE		    IN NUMBER := NULL,
	P_BOD_LT_ACTV_YN		    IN CHAR := NULL,
    P_FIXED_YN                  IN CHAR := NULL,
	P_VEHICL_TP_ID			    IN CHAR := NULL,
	P_BOD_PRIORITY			    IN INT := NULL,
	P_USER_ID				    IN VARCHAR2 := NULL,
    P_RT_ROLLBACK_FLAG          OUT VARCHAR2,
    P_RT_MSG                    OUT VARCHAR2
)
IS
	P_ERR_MSG	VARCHAR2(4000) :='';
	V_LOAD_UOM	VARCHAR2(32) :='';
	V_CONSUME_LOCAT_ITEM_ID CHAR(32) :='';
	V_SUPPLY_LOCAT_ITEM_ID CHAR(32) :='';
    V_MST_DATA_CNT INT := 0;
 
BEGIN
    IF P_VEHICL_TP_ID IS NOT NULL THEN 
        P_ERR_MSG := 'MSG_0008';
        IF P_BOD_PRIORITY IS NOT NULL AND P_BOD_PRIORITY < 0
        THEN
            RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
        END IF;
        IF P_TRANSP_LOTSIZE IS NOT NULL AND P_TRANSP_LOTSIZE < 0
        THEN
            RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
        END IF;
            
        SELECT A.ID INTO V_CONSUME_LOCAT_ITEM_ID
		FROM   TB_CM_SITE_ITEM A,
			   TB_AD_COMN_CODE B,
			   TB_CM_LOC_MGMT C
		WHERE  A.ITEM_MST_ID = P_ITEM_MST_ID
		AND    A.LOCAT_MGMT_ID = P_CONSUME_LOCAT_MGMT_ID
		AND	   A.LOCAT_MGMT_ID = C.ID
		AND    A.BOM_ITEM_TP_ID = B.ID
		AND    B.COMN_CD = (CASE WHEN C.SEMI_PRDUCT_GI_USE_YN = 'Y' THEN 'SEMI_PRODUCT_GI_ITEM' ELSE 'FINAL_PRODUCT_GR_ITEM' END);
    
        SELECT A.ID INTO V_SUPPLY_LOCAT_ITEM_ID
        FROM   TB_CM_SITE_ITEM A,
               TB_AD_COMN_CODE B
        WHERE  A.ITEM_MST_ID = P_ITEM_MST_ID
        AND    A.LOCAT_MGMT_ID = P_SUPPLY_LOCAT_MGMT_ID
        AND    A.BOM_ITEM_TP_ID = B.ID
        AND    B.COMN_CD = 'FINAL_PRODUCT_GR_ITEM';
        
        SELECT COUNT(A.ID) INTO V_MST_DATA_CNT
        FROM   TB_CM_TRANSFER_MGMT_MST A
        WHERE  A.CONSUME_LOCAT_ITEM_ID = V_CONSUME_LOCAT_ITEM_ID
        AND    A.SUPPLY_LOCAT_ITEM_ID = V_SUPPLY_LOCAT_ITEM_ID
        AND    A.BOD_TP_ID = P_BOD_TP_ID
        AND    A.VEHICL_TP_ID = P_VEHICL_TP_ID;
        
        IF V_MST_DATA_CNT > 0
        THEN 
            P_ERR_MSG := 'MSG_0013';
            RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
        END IF;
            
        SELECT UPPER(B.COMN_CD) INTO V_LOAD_UOM
        FROM   TB_AD_COMN_GRP A,
               TB_AD_COMN_CODE B
        WHERE  1=1
        AND    A.GRP_CD = 'LOAD_UOM_TYPE'
        AND    B.ID = P_LOAD_UOM_ID
        AND    A.ID = B.SRC_ID;
    
        MERGE INTO TB_CM_TRANSFER_MGMT_MST B
        USING	(
                SELECT P_TRANSP_MGMT_MST_ID 		AS TRANSP_MGMT_MST_ID
                     , P_BOD_TP_ID					AS BOD_TP_ID
                     , V_CONSUME_LOCAT_ITEM_ID		AS CONSUME_LOCAT_ITEM_ID
                     , V_SUPPLY_LOCAT_ITEM_ID		AS SUPPLY_LOCAT_ITEM_ID
                     , C.PALLET_TP_ID
                     , C.PACKING_TP_CD_ID			AS PACKING_TP_ID
                     , C.UOM_PER_PACKING			AS UOM_PER_PACKING
                     , C.PACKING_PER_PALLET			AS PACKING_PER_PALLET
                     , P_LOAD_UOM_ID				AS LOAD_UOM_ID
                     , P_VEHICL_TP_ID				AS VEHICL_TP_ID
                     , P_TRANSP_LOTSIZE			    AS TRANSP_LOTSIZE
                     , CASE WHEN V_LOAD_UOM = 'UOM'	    THEN P_TRANSP_LOTSIZE
                            WHEN V_LOAD_UOM = 'PACKING' THEN C.UOM_PER_PACKING * P_TRANSP_LOTSIZE
                            WHEN V_LOAD_UOM = 'PALLET'	THEN C.UOM_PER_PACKING * C.PACKING_PER_PALLET * P_TRANSP_LOTSIZE
                            ELSE 0
                       END UOM_QTY
                     , P_BOD_LT_ACTV_YN			    AS ACTV_YN
                     , P_FIXED_YN					AS FIXED_YN
                     , P_BOD_PRIORITY				AS PRIORT
                     , P_USER_ID					AS USER_ID
                  FROM TB_CM_SITE_ITEM D
                       LEFT OUTER JOIN
                       TB_CM_SITE_PACKING C
                       ON D.ID = C.LOCAT_ITEM_ID
                 WHERE D.ID = V_CONSUME_LOCAT_ITEM_ID
                ) A
        ON (B.ID = A.TRANSP_MGMT_MST_ID)
        WHEN MATCHED THEN
            UPDATE
            SET
                B.ACTV_YN = A.ACTV_YN,
                B.FIXED_YN = A.FIXED_YN,
                B.PRIORT = A.PRIORT,
                B.LOAD_UOM_ID = A.LOAD_UOM_ID,
                B.TRANSP_LOTSIZE = A.TRANSP_LOTSIZE,
                B.UOM_QTY = A.UOM_QTY,
                B.PACKING_QTY = A.UOM_QTY/A.UOM_PER_PACKING,
                B.PACKING_TP_ID = A.PACKING_TP_ID,
                B.PALLET_QTY = (A.UOM_QTY/A.UOM_PER_PACKING)/A.PACKING_PER_PALLET,
                B.PALLET_TP_ID = A.PALLET_TP_ID,
                B.MODIFY_BY = A.USER_ID,
                B.MODIFY_DTTM = SYSDATE
        WHEN NOT MATCHED THEN
            INSERT (
                ID,
                BOD_TP_ID,
                CONSUME_LOCAT_ITEM_ID,
                FIXED_YN,
                SUPPLY_LOCAT_ITEM_ID,
                ACTV_YN,
                VEHICL_TP_ID,
                PRIORT,
                LOAD_UOM_ID,
                TRANSP_LOTSIZE,
                UOM_QTY,
                PACKING_QTY,
                PACKING_TP_ID,
                PALLET_QTY,
                PALLET_TP_ID,
                CREATE_BY,
                CREATE_DTTM
                )
            VALUES(
                TO_SINGLE_BYTE(SYS_GUID()),
                A.BOD_TP_ID,
                A.CONSUME_LOCAT_ITEM_ID,
                A.FIXED_YN,
                A.SUPPLY_LOCAT_ITEM_ID,
                A.ACTV_YN,
                A.VEHICL_TP_ID,
                A.PRIORT,
                A.LOAD_UOM_ID,
                A.TRANSP_LOTSIZE,
                A.UOM_QTY,
                (A.UOM_QTY/A.UOM_PER_PACKING),
                A.PACKING_TP_ID,
                (A.UOM_QTY/A.UOM_PER_PACKING)/A.PACKING_PER_PALLET,
                A.PALLET_TP_ID,
                A.USER_ID,
                SYSDATE
                );
    END IF;
                    
    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';
    
EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;
      ELSE
         RAISE;
      END IF;
END;

/

