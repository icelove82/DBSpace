create procedure                "SP_UI_BF_50_Q1" 
(
    p_VER_CD            VARCHAR2, 
    p_ITEM              VARCHAR2,
    p_SALES             VARCHAR2,
    p_FROM_DATE         DATE,
    p_TO_DATE           DATE,
    p_USERNAME          VARCHAR2,
    p_BEST_SELECT_YN    CHAR,
    pRESULT             OUT SYS_REFCURSOR
)IS 
    p_ACCURACY          VARCHAR2(30);
BEGIN
    SELECT RULE_01 INTO p_ACCURACY
      FROM TB_BF_CONTROL_BOARD_VER_DTL
     WHERE VER_CD = p_VER_CD
       AND (PROCESS_NO = '990000' OR PROCESS_NO = '990')
       ;

    OPEN pRESULT FOR
    WITH RT AS (
        SELECT B.ITEM_CD
             , B.ACCOUNT_CD
             , B.BASE_DATE
             , B.ENGINE_TP_CD	
             , CASE p_ACCURACY WHEN 'MAPE'   THEN MAPE
                               WHEN 'MAE'	 THEN MAE
                               WHEN 'MAE_P'  THEN MAE_P
                               WHEN 'RMSE'	 THEN RMSE 
                               WHEN 'RMSE_P' THEN RMSE_P
                               WHEN 'WAPE'	 THEN WAPE
                               WHEN 'MAPE_W' THEN MAPE_W
                               ELSE NULL END AS ACCRY
             , A.SELECT_SEQ
             , QTY 
             , B.VER_CD 
          FROM TB_BF_RT B
          LEFT OUTER JOIN TB_BF_RT_ACCRCY A
            ON A.ITEM_CD = B.ITEM_CD 
           AND A.ACCOUNT_CD=B.ACCOUNT_CD 
           AND A.VER_CD = B.VER_CD 
           AND A.ENGINE_TP_CD = B.ENGINE_TP_CD		  		   		  
         WHERE B.VER_CD = p_VER_CD 
           AND BASE_DATE BETWEEN p_FROM_DATE AND p_TO_DATE
           AND  (  REGEXP_LIKE (UPPER(B.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_SALES), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                    OR 
                      p_SALES IS NULL
                    )
           AND  ( REGEXP_LIKE (UPPER(B.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                  OR 
                   p_ITEM IS NULL
                )
           --AND CASE WHEN p_ITEM LIKE '%|%' THEN UPPER(B.ITEM_CD) ELSE COALESCE(p_ITEM,'') END IN (SELECT COALESCE(Value,'') VAL FROM SplitTableNVARCHAR(UPPER(COALESCE(p_ITEM,'')),'|'))
           --AND CASE WHEN p_ITEM LIKE '%|%' THEN COALESCE(p_ITEM,'') ELSE B.ITEM_CD END LIKE '%'+ REPLACE(REPLACE(REPLACE(REPLACE(UPPER(COALESCE(p_ITEM,'')),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#'  
           --AND CASE WHEN p_SALES LIKE '%|%' THEN UPPER(B.ACCOUNT_CD) ELSE COALESCE(p_SALES,'') END IN (SELECT COALESCE(Value,'') VAL FROM SplitTableNVARCHAR(UPPER(COALESCE(p_SALES,'')),'|'))
           --AND CASE WHEN p_SALES LIKE '%|%' THEN COALESCE(p_SALES,'') ELSE B.ACCOUNT_CD END LIKE '%'+ REPLACE(REPLACE(REPLACE(REPLACE(UPPER(COALESCE(p_SALES,'')),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#'  
           AND CASE WHEN p_BEST_SELECT_YN = 'Y' THEN A.SELECT_SEQ ELSE 1 END = 1
    )
    SELECT RT.VER_CD
    	,  RT.ITEM_CD
    	,  IM.ITEM_NM
    	,  RT.ACCOUNT_CD 
    	,  AM.ACCOUNT_NM
		,  RT.ENGINE_TP_CD		AS ENGINE_TP_CD 
		,  RT.ACCRY
		,  RT.BASE_DATE			AS "DATE"
		,  SUM(RT.QTY)			AS QTY
		,  SELECT_SEQ	
	  FROM RT
	  	   INNER JOIN
	  	   TB_CM_ITEM_MST IM
	  	ON RT.ITEM_CD = IM.ITEM_CD
	  	   INNER JOIN
	  	   TB_DP_ACCOUNT_MST AM
	  	ON RT.ACCOUNT_CD = AM.ACCOUNT_CD
	GROUP BY RT.VER_CD
		  ,  RT.ITEM_CD 
		  ,  IM.ITEM_NM
		  ,  RT.ACCOUNT_CD 
		  ,  AM.ACCOUNT_NM
		  ,  RT.BASE_DATE
		  ,  RT.ENGINE_TP_CD
		  ,  RT.ACCRY
		  ,  SELECT_SEQ	 
	ORDER BY RT.ACCOUNT_CD, RT.ITEM_CD
    ;
END
;
/

