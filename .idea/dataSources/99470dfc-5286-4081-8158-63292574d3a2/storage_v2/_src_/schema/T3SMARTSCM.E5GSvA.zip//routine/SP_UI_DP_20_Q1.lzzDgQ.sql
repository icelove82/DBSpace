create PROCEDURE                "SP_UI_DP_20_Q1" (
    p_FROM_DATE           IN DATE         := NULL
  , p_TO_DATE             IN DATE         := NULL
  , p_ITEM_CD             IN VARCHAR2 := ''
  , P_ITEM_NM             IN VARCHAR2 := ''
  , P_ACCOUNT_CD          IN VARCHAR2 := ''
  , P_ACCOUNT_NM          IN VARCHAR2 := ''
  , P_PRICE_TP            IN VARCHAR2 := ''
  , P_EMP_NO              IN VARCHAR2 :=NULL
  , P_AUTH_TP_ID          IN CHAR := NULL
  , pRESULT              OUT SYS_REFCURSOR
)
IS
/*****************************************************************************
Title : SP_UI_DP_20_Q1
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 
************************************************************************/
    P_EMP_ID CHAR(32);
    P_LAST_DT DATE;

BEGIN 

    SELECT ID INTO P_EMP_ID
      FROM TB_AD_USER
     WHERE USERNAME = P_EMP_NO;
/**************************************************************************************************************************
	-- MAIN PROCEDURE
**************************************************************************************************************************/

	OPEN pRESULT          
    FOR 
    SELECT UP.ID
         , UP.ITEM_MST_ID
         , IM.ITEM_CD
         , IM.ITEM_NM
         , UP.ACCOUNT_ID
         , AM.ACCOUNT_CD
         , AM.ACCOUNT_NM
         , AC.COMN_CD       AS CURCY_CD
         , AC.COMN_CD_NM    AS CURCY_NM
         , UP.BASE_DATE
         , UP.UTPIC
         , (SELECT CONF_CD
              FROM TB_CM_COMM_CONFIG
             WHERE ID = CASE WHEN UP.PRICE_TP_ID IS NULL THEN P_PRICE_TP
                             ELSE UP.PRICE_TP_ID END
           )              AS PRICE_TP_CD
      FROM (
        SELECT ID
             , ITEM_MST_ID
             , ACCOUNT_ID
             , BASE_DATE
             , PRICE_TP_ID
             , UTPIC
          FROM (
            SELECT UP.ID
                 , IA.ITEM_ID AS ITEM_MST_ID
                 , IA.ACCOUNT_ID
                 , UP.BASE_DATE
                 , UP.PRICE_TP_ID
                 , UP.UTPIC
                 , DENSE_RANK () OVER (PARTITION BY UP.PRICE_TP_ID, IA.ITEM_ID, IA.ACCOUNT_ID ORDER BY BASE_DATE DESC) AS ROW_NUM
              FROM TABLE(FN_DP_TEMP_USER_ITEM_ACCOUNT(P_EMP_ID, P_AUTH_TP_ID)) IA
             INNER JOIN TB_DP_UNIT_PRICE UP
                ON IA.ITEM_ID = UP.ITEM_MST_ID
               AND IA.ACCOUNT_ID = UP.ACCOUNT_ID
               AND PRICE_TP_ID = P_PRICE_TP
               AND P_FROM_DATE < P_TO_DATE
          ) A
         WHERE ROW_NUM = 1
        UNION
        SELECT UP.ID
             , IA.ITEM_ID AS ITEM_MST_ID
             , IA.ACCOUNT_ID
             , UP.BASE_DATE
             , UP.PRICE_TP_ID
             , UP.UTPIC
          FROM TABLE(FN_DP_TEMP_USER_ITEM_ACCOUNT(P_EMP_ID, P_AUTH_TP_ID)) IA
         INNER JOIN TB_DP_UNIT_PRICE UP
            ON IA.ITEM_ID = UP.ITEM_MST_ID
           AND IA.ACCOUNT_ID = UP.ACCOUNT_ID
           AND PRICE_TP_ID = P_PRICE_TP
           AND (UP.BASE_DATE BETWEEN P_FROM_DATE AND P_TO_DATE)
        ) UP
     INNER JOIN TB_CM_ITEM_MST IM
        ON UP.ITEM_MST_ID = IM.ID
     INNER JOIN TB_DP_ACCOUNT_MST AM
        ON UP.ACCOUNT_ID = AM.ID
      LEFT OUTER JOIN TB_AD_COMN_CODE AC
        ON AC.ID = AM.CURCY_CD_ID
       AND COALESCE(AC.DEL_YN, 'N') = 'N'
       AND AC.USE_YN = 'Y'
     WHERE 1=1
       AND (REGEXP_LIKE(UPPER(AM.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ACCOUNT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
            OR p_ACCOUNT_CD IS NULL
           )
       AND (REGEXP_LIKE(UPPER(AM.ACCOUNT_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ACCOUNT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
            OR p_ACCOUNT_NM IS NULL
           )
       AND (REGEXP_LIKE(UPPER(IM.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
            OR p_ITEM_CD IS NULL
           )
       AND (REGEXP_LIKE(UPPER(IM.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(P_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
            OR p_ITEM_NM IS NULL
           )
     ORDER BY UP.PRICE_TP_ID DESC, UP.ACCOUNT_ID, UP.ITEM_MST_ID;

END;
/

