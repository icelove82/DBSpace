create PROCEDURE                "SP_UI_BF_09_S1"  (
      P_TYPE        VARCHAR2    := ''
    , P_FACTOR_CD   VARCHAR2    := ''
    , P_DESCRIP     VARCHAR2    := ''
    , P_COLUMN_NAME VARCHAR2    := ''
    , P_ACTV_YN     CHAR        := ''
    , P_USER_ID     VARCHAR2    := ''
    , P_RT_ROLLBACK_FLAG  OUT   VARCHAR2
    , P_RT_MSG            OUT   VARCHAR2
)

IS

--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

    P_ERR_STATUS NUMBER := 0;
    P_ERR_MSG VARCHAR2(4000) := '';
    V_TYPE CHAR(1) := '';

BEGIN
    IF (P_TYPE = 'extend') THEN
        V_TYPE := 'N';
    ELSE
        V_TYPE := 'Y';
    END IF;


      --SELECT * FROM TB_BF_FACTOR_MGMT
    MERGE INTO TB_BF_FACTOR_MGMT TAR
    USING ( 
            SELECT  V_TYPE          AS EXTEND_YN            
                  , P_FACTOR_CD     AS FACTOR_CD
                  , P_DESCRIP       AS DESCRIP
                  , P_COLUMN_NAME   AS COL_NM
                  , P_ACTV_YN       AS ACTV_YN
                  , P_USER_ID       AS USER_ID
            FROM DUAL
          ) SRC
    ON    (TAR.FACTOR_CD         = SRC.FACTOR_CD)
    WHEN MATCHED THEN
         UPDATE 
           SET   TAR.EXTEND_YN      = SRC.EXTEND_YN     
                ,TAR.COL_NM         = SRC.COL_NM
                ,TAR.DESCRIP        = SRC.DESCRIP
                ,TAR.ACTV_YN        = SRC.ACTV_YN
                ,TAR.MODIFY_BY      = SRC.USER_ID
                ,TAR.MODIFY_DTTM    = (SELECT SYSDATE FROM DUAL)
    WHEN NOT MATCHED THEN 
         INSERT (
                  FACTOR_CD
                , COL_NM    
                , DESCRIP
                , EXTEND_YN
                , ACTV_YN
                , CREATE_BY
                , CREATE_DTTM
                ) 
         VALUES (
                  SRC.FACTOR_CD
                , SRC.COL_NM
                , SRC.DESCRIP
                , SRC.EXTEND_YN
                , SRC.ACTV_YN
                , SRC.USER_ID
                , (SELECT SYSDATE FROM DUAL)
                ) 
        ;


    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';

EXCEPTION WHEN OTHERS THEN
   IF (SQLERRM = P_ERR_MSG) THEN
       P_ERR_MSG := SQLERRM;
       P_RT_ROLLBACK_FLAG := 'false';
       P_RT_MSG := P_ERR_MSG;
   ELSE 
        RAISE_APPLICATION_ERROR (SQLCODE, SQLERRM);
--              EXEC SP_COMM_RAISE_ERR
   END IF;

END;
/

