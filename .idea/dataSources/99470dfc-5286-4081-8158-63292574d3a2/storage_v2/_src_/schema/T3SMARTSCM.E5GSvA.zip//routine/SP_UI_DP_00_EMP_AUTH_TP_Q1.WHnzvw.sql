create PROCEDURE                "SP_UI_DP_00_EMP_AUTH_TP_Q1" (
    P_USER_ID   IN  VARCHAR2 := ''
  , P_UI_ID     IN  VARCHAR2
  , pRESULT     OUT SYS_REFCURSOR 
) IS 

    V_USER_ID CHAR(32);
    V_IF_CHECK INT;
BEGIN
/*************************************************************************
    History ( Date / Writer / Comment)
    - 2021.01.14 / ksh / get ID of user by user param
    - 2021.02.09 / ksh / relocate unclear code to get user id  
************************************************************************/
    SELECT COUNT(ID) INTO V_IF_CHECK
      FROM TB_AD_USER
     WHERE USERNAME = P_USER_ID
     ;
IF (V_IF_CHECK > 0)
    THEN
        SELECT ID INTO V_USER_ID
          FROM TB_AD_USER
         WHERE USERNAME = P_USER_ID;
    END IF;
    
IF (P_UI_ID = 'UI_DP_25' OR P_UI_ID = 'UI_DP_25_CHART' OR P_UI_ID = 'UI_DP_26' OR P_UI_ID = 'UI_DP_26_CHART'
 OR P_UI_ID = 'UI_DP_95' OR P_UI_ID = 'UI_DP_95_CHART' OR P_UI_ID = 'UI_DP_96' OR P_UI_ID = 'UI_DP_96_CHART'
 OR P_UI_ID = 'UI_BP_95' OR P_UI_ID = 'UI_BP_95_CHART'  OR P_UI_ID = 'UI_BP_96' or P_UI_ID = 'UI_BP_96_CHART' )

    THEN
    -- Entry는 mapping data만 나오도록 수정 (20190624)
    -- FN_DP_TEMP_ITEM_TREE, ACCT_TREE 등 컨버팅을 아직 못해서 우선은 DEL_YN 등은 체크 안하고 Auth type 가져옴
    OPEN pRESULT          
    FOR 
		WITH ITEM_ACCT_MAP
		AS (
			SELECT UI.EMP_ID
				 , UI.AUTH_TP_ID
				 , '2' AS TP
			  FROM TB_DP_USER_ITEM_MAP UI
			 WHERE UI.ACTV_YN ='Y' 
			   AND UI.EMP_ID =	V_USER_ID
		  GROUP BY EMP_ID, AUTH_TP_ID
			 UNION
			SELECT UI.EMP_ID
				 , UI.AUTH_TP_ID
				 , '2' AS TP
			  FROM TB_DP_USER_ACCOUNT_MAP UI
			 WHERE  UI.ACTV_YN ='Y' 
			   AND UI.EMP_ID =	V_USER_ID
		  GROUP BY EMP_ID, AUTH_TP_ID
			 UNION
			SELECT EMP_ID
			     , AUTH_TP_ID 
				 , '1'AS TP
			  FROM TB_DP_USER_ITEM_ACCOUNT_MAP IA 
			 WHERE IA.ACTV_YN ='Y' 
			   AND EMP_ID = V_USER_ID
		  GROUP BY EMP_ID, AUTH_TP_ID
			UNION
		 	SELECT SA.EMP_ID, 
		 		   SL.LV_MGMT_ID AS AUTH_TP_ID, 
		 		   '0' AS TP
			  FROM TB_DP_SALES_AUTH_MAP SA
				   INNER JOIN 
				   TB_DP_SALES_LEVEL_MGMT SL 
				ON SL.ID = SA.SALES_LV_ID 
			   AND COALESCE(SL.DEL_YN,'N') = 'N' 
			   AND SL.ACTV_YN = 'Y'
			 WHERE (STRT_DATE_AUTH  IS NULL OR STRT_DATE_AUTH <= SYSDATE) 
			   AND (END_DATE_AUTH IS NULL  OR END_DATE_AUTH >= SYSDATE) 
			   AND EMP_ID = V_USER_ID
	 	  GROUP BY EMP_ID, SL.LV_MGMT_ID 
	   ), CM_LEVEL
	   AS (
	   SELECT ID, LV_CD, LV_NM, LEAF_YN, ROW_NUMBER () OVER(PARTITION BY LV_TP_ID ORDER BY SEQ ) AS SEQ
	     FROM TB_CM_LEVEL_MGMT 	
		WHERE SALES_LV_YN = 'Y'	
		  AND DEL_YN ='N'		
	   )
		  SELECT M.EMP_ID		
			   , M.AUTH_TP_ID	AS ID   
			   , CL.LV_CD 		AS CD
			   , CL.LV_NM 		AS CD_NM
			   , CL.LEAF_YN 	AS LEAF_YN 
			   , cast(MAX(TP) as varchar2(2))		AS MAP_TP
			   , SEQ 
		    FROM ITEM_ACCT_MAP M 
		   	     INNER JOIN 
		   	     CM_LEVEL CL 
		      ON M.AUTH_TP_ID = CL.ID	
		GROUP BY M.EMP_ID		
			   , M.AUTH_TP_ID	 
			   , CL.LV_CD 		 
			   , CL.LV_NM 		 
			   , CL.SEQ 		 
			   , CL.LEAF_YN 	
		ORDER BY CL.SEQ 
		;    
    
ELSE
    OPEN pRESULT          
    FOR SELECT A.ID
         , A.LV_CD AS CD
         , A.LV_NM AS CD_NM 
         , A.SEQ
      FROM 
          (
            SELECT   LM.ID 
                   , LM.LV_CD 
                   , LM.LV_NM 
                   , LM.SEQ
             FROM TB_CM_COMM_CONFIG CO
                , TB_CM_LEVEL_MGMT LM
            WHERE CO.CONF_GRP_CD =  'DP_LV_TP'
              AND CO.ACTV_YN = 'Y'
              AND CO.CONF_CD = 'S'
              AND CO.ID = LM.LV_TP_ID
              AND COALESCE(LM.DEL_YN, 'N') = 'N'
              AND LM.ACTV_YN = 'Y'
              AND LM.SALES_LV_YN = 'Y' 
              --AND LM.LEAF_YN = 'Y'
              AND LM.SEQ IN (          
                                     SELECT LM.SEQ
                                       FROM TB_CM_COMM_CONFIG CO
                                          , TB_CM_LEVEL_MGMT LM
                                          , TB_DP_SALES_LEVEL_MGMT SL
                                          , TB_DP_SALES_AUTH_MAP SA 
                                      WHERE CO.CONF_GRP_CD =  'DP_LV_TP'
                                        AND CO.ACTV_YN = 'Y'
                                        AND CO.CONF_CD = 'S'
                                        AND CO.ID = LM.LV_TP_ID
                                        AND COALESCE(LM.DEL_YN, 'N') = 'N'
                                        AND LM.ACTV_YN = 'Y'
                                        AND LM.SALES_LV_YN = 'Y'
                                        AND LM.ID = SL.LV_MGMT_ID
                                        AND SL.ID  = SA.SALES_LV_ID
                                        AND SA.EMP_ID = V_USER_ID  -- '6CE1034002E54DB6A1A88E568D082B5E'
                                        AND (SA.STRT_DATE_AUTH is null or  SA.STRT_DATE_AUTH <= SYSDATE)
                                        AND (SA.END_DATE_AUTH is null or SA.END_DATE_AUTH >= SYSDATE)
                                    ) 
            UNION 
            -- default Sales Man 
            SELECT  LM.ID
                  , LM.LV_CD
                  , LM.LV_NM
                  , LM.SEQ
             FROM TB_CM_COMM_CONFIG CO
                , TB_CM_LEVEL_MGMT LM
            WHERE CO.CONF_GRP_CD =  'DP_LV_TP'
              AND CO.ACTV_YN = 'Y'
              AND CO.CONF_CD = 'S'
              AND CO.ID = LM.LV_TP_ID
              AND COALESCE(LM.DEL_YN, 'N') = 'N'
              AND LM.ACTV_YN = 'Y'
              AND LM.SALES_LV_YN = 'Y' 
              AND LM.LEAF_YN = 'Y'
           )  A
    ORDER BY A.SEQ 
    ; 
END IF;


END
;
/

