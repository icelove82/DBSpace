create PROCEDURE SP_DP_MAKE_EX_MEASURE02
(
     P_PRE_MONTH        IN INT      := 0
    ,P_PLAN_TP_CD       IN VARCHAR2 := 'DP_PLAN_MONTHLY' -- PLAN TYPE CODE
    ,P_MIN_MEASURE_VAL  IN INT      :=0                   
    ,P_MAX_MEASURE_VAL  IN INT      :=45
    ,P_MONTH            IN INT      :=2  
)IS
/********************************************************************************************************
********************************************************************************************************/
     V_VER_BUCKET    VARCHAR2(50);
     V_VER_HORIZON   INT ;
     V_VER_DOW_NM    CHAR(3);
     V_VER_DOW       INT ;
     V_PAR_BUCKET   VARCHAR2(50);
     V_PAR_HORIZON  INT := 0;

     V_MAX_DATE01  VARCHAR2(10);
     V_MAX_DATE02  VARCHAR2(10);

     V_SO_STATUS_OPEN_ID			     CHAR(32)	;
     V_SO_STATUS_SHIPPED_ID		     CHAR(32)  ;

     V_CNT      INT  :=0;
BEGIN
     -- 1) VAR_BUCKET, VAR_HORIZON 
          SELECT C.POLICY_VAL  INTO V_VER_BUCKET
              FROM   TB_CM_COMM_CONFIG B
                     INNER JOIN
                     TB_DP_PLAN_POLICY C
                ON  (B.ID = C.PLAN_TP_ID)
                     INNER JOIN
                     TB_CM_COMM_CONFIG D
                ON  (C.POLICY_ID = D.ID)                     
                 where  1=1 -- A.MODULE_CD = 'DP'
                   AND B.ACTV_YN = 'Y'
                   AND D.CONF_CD = 'B'
                   AND B.CONF_CD = P_PLAN_TP_CD
                   ;
          SELECT C.POLICY_VAL  INTO V_VER_HORIZON
              FROM   TB_CM_COMM_CONFIG B
                     INNER JOIN
                     TB_DP_PLAN_POLICY C
                ON  (B.ID = C.PLAN_TP_ID)
                     INNER JOIN
                     TB_CM_COMM_CONFIG D
                ON  (C.POLICY_ID = D.ID)                     
                 where  1=1 
                   AND B.ACTV_YN = 'Y'
                   AND D.CONF_CD = 'H'
                   AND B.CONF_CD = P_PLAN_TP_CD      
                   ;
            SELECT UPPER(CONF_CD) INTO V_VER_DOW_NM
              FROM TB_CM_COMM_CONFIG 
             WHERE 1=1
               AND CONF_GRP_CD = 'DP_STD_WEEK' 
               AND ACTV_YN = 'Y' 
               AND USE_YN = 'Y' 
             ;
             SELECT CASE UPPER(V_VER_DOW_NM) 
                    WHEN 'SUN'  THEN 1 
                    WHEN 'MON'  THEN 2
                    WHEN 'TUE'  THEN 3 
                    WHEN 'WED'  THEN 4 
                    WHEN 'THU'  THEN 5 
                    WHEN 'FRI'  THEN 6
                    WHEN 'SAT'  THEN 7
                    END INTO V_VER_DOW
            FROM DUAL;


-- 3) V_MAX_DATE01 
     SELECT (CASE WHEN MAX(BASE_DATE) IS NULL THEN SYSDATE
                  ELSE MAX(BASE_DATE)+1 END
             ) INTO V_MAX_DATE01
       FROM TB_CM_ACTUAL_SALES;

-- 4) V_MAX_DATE02 
     SELECT ID INTO V_SO_STATUS_OPEN_ID
	FROM TB_CM_COMM_CONFIG 
	WHERE CONF_GRP_CD = 'DP_SO_STATUS'
	AND CONF_CD = 'OPEN'
	;

	SELECT ID INTO V_SO_STATUS_SHIPPED_ID
	FROM TB_CM_COMM_CONFIG 
	WHERE CONF_GRP_CD = 'DP_SO_STATUS'
	AND CONF_CD = 'SHIP'
	;        


-- TB_CM_ACTUAL_SALES  ************************************************************************************************
INSERT INTO TB_CM_ACTUAL_SALES (ID,ITEM_MST_ID,ACCOUNT_ID, BASE_DATE, SO_STATUS_ID, QTY,AMT,CURCY_CD_ID,CREATE_BY,  CREATE_DTTM,MODIFY_BY, MODIFY_DTTM)
     SELECT TO_SINGLE_BYTE(SYS_GUID())  AS ID
          , I.ID                        AS ITEM_MST_ID
          , A.ID                        AS ACCOUNT_ID
          , C.DAT                       AS BASE_DATE
          , DECODE( MOD(rownum,2),0,V_SO_STATUS_SHIPPED_ID,V_SO_STATUS_OPEN_ID ) AS SO_STATUS_ID
          , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL)) AS QTY
          , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL)) AS AMT
          , NULL                        AS CURCY_CD_ID
          , NULL                        AS CREATE_BY
          , NULL                        AS CREATE_DTTM
          , NULL                        AS MODIFY_BY
          , NULL                        AS MODIFY_DTTM
       FROM TB_CM_ITEM_MST I
      INNER JOIN TB_DP_ACCOUNT_MST A ON (I.DP_PLAN_YN = 'Y' AND I.DEL_YN = 'N' AND A.ACTV_YN = 'Y')
      INNER JOIN TB_CM_CALENDAR C ON (1=1)
      WHERE 1=1
        AND DAT BETWEEN V_MAX_DATE01 AND ADD_MONTHS(V_MAX_DATE01,P_MONTH)
        AND (   DOW_NM = ( SELECT UPPER(CONF_CD) FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_STD_WEEK' AND ACTV_YN = 'Y' AND USE_YN = 'Y' )
                    OR  DD = 1)
        ;

     --ITEM_MST_ID, ACCOUNT_ID, BASE_DATE SO_STATUS_ID
INSERT INTO TB_CM_ACTUAL_SALES (ID,ITEM_MST_ID,ACCOUNT_ID, BASE_DATE, SO_STATUS_ID, QTY,AMT,CURCY_CD_ID,CREATE_BY,  CREATE_DTTM,MODIFY_BY, MODIFY_DTTM)
     SELECT TO_SINGLE_BYTE(SYS_GUID()) AS ID
          , ITEM_MST_ID
          , ACCOUNT_ID
          , BASE_DATE
          , DECODE( MOD(rownum,2),1,V_SO_STATUS_SHIPPED_ID,V_SO_STATUS_OPEN_ID ) AS SO_STATUS_ID
          , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL)) AS QTY
          , ROUND(DBMS_RANDOM.VALUE(P_MIN_MEASURE_VAL, P_MAX_MEASURE_VAL)) AS AMT
          , NULL                        AS CURCY_CD_ID
          , NULL                        AS CREATE_BY
          , NULL                        AS CREATE_DTTM
          , NULL                        AS MODIFY_BY
          , NULL                        AS MODIFY_DTTM
       FROM TB_CM_ACTUAL_SALES
commit;


     commit;


END;
/

