create PROCEDURE                "SP_UI_DP_08_S1" (
    p_ID                  IN VARCHAR2       := ''
  , p_ITEM_LV_CD          IN VARCHAR        := NULL         
  , p_ITEM_LV_NM          IN VARCHAR        := NULL         
  , p_LV_MGMT_ID          IN VARCHAR2       := NULL      
  , p_PARENT_ITEM_LV_ID   IN VARCHAR2       := NULL   -- cast(p_SEQ AS int)   AS  SEQ
  , p_SEQ                 IN INT			:= NULL  
  , p_ACTV_YN             IN  CHAR          := NULL  
  , p_DEL_YN              IN  CHAR          := NULL  
  , p_USER_ID             IN VARCHAR2      
  , p_ATTR_01             IN VARCHAR2
  , P_RT_ROLLBACK_FLAG OUT VARCHAR2  
  , P_RT_MSG           OUT VARCHAR2		 									       
) 
IS
		P_ERR_STATUS INT := 0;
		P_ERR_STATUS_02 INT := 0;
        P_ERR_MSG VARCHAR2(4000):='';
BEGIN
    P_RT_ROLLBACK_FLAG := 'true';

/******************************************************************************************************************************************************************************************/
-- IF(p_ACTV_YN  = 't' OR p_ACTV_YN  ='1') SET p_ACTV_YN = 'Y' ELSE SET p_ACTV_YN  ='N'    
-- IF(p_DEL_YN   = 't' OR	p_DEL_YN 	='1') SET p_DEL_YN  = 'Y' ELSE SET p_DEL_YN   ='N' 	          

IF(p_ITEM_LV_CD IS NULL OR p_ITEM_LV_CD ='')
THEN
	   P_ERR_MSG := 'MSG_5037' ;
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
END IF;

SELECT COUNT(*) INTO P_ERR_STATUS
  FROM TB_CM_ITEM_LEVEL_MGMT
 WHERE 1=1 
   AND ITEM_LV_CD = P_ITEM_LV_CD
   AND ID != P_ID;
IF(P_ERR_STATUS > 0)
    THEN
	   P_ERR_MSG := 'MSG_0013' ;
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);        
END IF;
IF (p_LV_MGMT_ID IS NULL OR p_LV_MGMT_ID='')
THEN
	   P_ERR_MSG := 'MSG_5032' ;
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
END IF;

       SELECT SEQ INTO P_ERR_STATUS
         FROM TB_CM_LEVEL_MGMT 
        WHERE 1=1
          AND ID = P_LV_MGMT_ID;
   SELECT MIN(SEQ) INTO P_ERR_STATUS_02
     FROM TB_CM_LEVEL_MGMT
    WHERE 1=1
      AND ACTV_YN = 'Y'
      AND NVL(DEL_YN,'N') = 'N'
      AND SALES_LV_YN = 'N'
      AND ACCOUNT_LV_YN = 'N'
;
/* ======= */
IF (P_ERR_STATUS = P_ERR_STATUS_02 AND p_PARENT_ITEM_LV_ID IS NOT NULL)
    THEN
	   P_ERR_MSG := 'MSG_5043' ;
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;
/* ======= */
IF (P_ERR_STATUS != P_ERR_STATUS_02 AND p_PARENT_ITEM_LV_ID IS NULL)
    THEN
	   P_ERR_MSG := 'MSG_5051' ;
	   RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;


/******************************************************************************************************************************************************************************************
1. Master Templete  
******************************************************************************************************************************************************************************************/

			    -- 2. 
				MERGE INTO TB_CM_ITEM_LEVEL_MGMT TGT
				USING ( 
						SELECT 
						       p_ID                   AS ID               
							 ,p_ITEM_LV_CD           AS ITEM_LV_CD       
							 ,p_ITEM_LV_NM           AS ITEM_LV_NM       
							 ,p_LV_MGMT_ID           AS LV_MGMT_ID       
							 ,p_PARENT_ITEM_LV_ID    AS PARENT_ITEM_LV_ID
							 ,p_SEQ				  AS SEQ   
							 ,p_ACTV_YN              AS ACTV_YN
							 ,NVL(p_DEL_YN,'N')               AS DEL_YN
                                    ,p_USER_ID              AS  USER_ID
                                    ,p_ATTR_01              AS ATTR_01
					  FROM dual ) SRC
				ON     (TGT.ID = SRC.ID)
				WHEN MATCHED THEN
					 UPDATE 
					   SET   TGT.ITEM_LV_CD           = SRC.ITEM_LV_CD       
							,TGT.ITEM_LV_NM           = SRC.ITEM_LV_NM       
							,TGT.LV_MGMT_ID           = SRC.LV_MGMT_ID        
							,TGT.PARENT_ITEM_LV_ID    = SRC.PARENT_ITEM_LV_ID        
							,TGT.SEQ                  = SRC.SEQ   
							,TGT.ACTV_YN              = SRC.ACTV_YN
							,TGT.DEL_YN               = SRC.DEL_YN
							,TGT.MODIFY_BY            = SRC.USER_ID  
							,TGT.MODIFY_DTTM          = SYSDATE     
                                   ,TGT.ATTR_01              = SRC.ATTR_01
				WHEN NOT MATCHED THEN 
					 INSERT (
							  ID               
							, ITEM_LV_CD       
							, ITEM_LV_NM       
							, LV_MGMT_ID       
							, PARENT_ITEM_LV_ID
							, SEQ   
							, ACTV_YN
							, DEL_YN
							, CREATE_BY
							, CREATE_DTTM
                                   , ATTR_01
							) 
					 VALUES (
							  SRC.ID--TO_SINGLE_BYTE(SYS_GUID())
							, SRC.ITEM_LV_CD       
							, SRC.ITEM_LV_NM       
							, SRC.LV_MGMT_ID       
							, SRC.PARENT_ITEM_LV_ID
							, SRC.SEQ   
							, SRC.ACTV_YN
							, 'N'      -- DEL_YN
							, SRC.USER_ID   
							, SYSDATE
                                   , SRC.ATTR_01
 							) 
							;    
	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  --
       /*  ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN  -- : e_products_invalid    
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                SP_COMM_RAISE_ERR();              
                --RAISE;
              END IF;    
END;
/

