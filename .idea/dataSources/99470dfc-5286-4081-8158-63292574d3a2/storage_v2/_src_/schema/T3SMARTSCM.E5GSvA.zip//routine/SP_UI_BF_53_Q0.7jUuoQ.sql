create PROCEDURE                SP_UI_BF_53_Q0
(
	p_VER_CNT_YN CHAR
   ,p_ENGINE_TP_CD VARCHAR2
   ,pRESULT         OUT SYS_REFCURSOR
)IS	

BEGIN
/*********************************************************************************
	-- Version Number
**********************************************************************************/
    IF (p_VER_CNT_YN = 'Y')
	THEN
        OPEN pRESULT FOR
		WITH VER AS (
			SELECT ROW_NUMBER() OVER (ORDER BY VER_CD) AS NUM 
			  FROM TB_BF_CONTROL_BOARD_VER_DTL
			 WHERE (PROCESS_NO = '990000' OR PROCESS_NO = '990')
			   AND STATUS = 'Completed'	
               AND ROWNUM <= 12 -- TOP 12
        )
		SELECT NUM
		  FROM (
			SELECT NUM, MAX(NUM) OVER(ORDER BY NUM DESC) AS CNT 
			  FROM VER 
        ) A
		 WHERE CASE WHEN CNT>=4 THEN NUM ELSE 4 END >=4
		   AND CASE WHEN CNT<4 THEN CNT ELSE NUM END = NUM 
		 ;
    ELSE
/*********************************************************************************
	-- Item & Account
**********************************************************************************/
		OPEN pRESULT FOR
        WITH  RT
		AS (
        SELECT ITEM_CD, ACCOUNT_CD
			  FROM TB_BF_ITEM_ACCOUNT_MODEL_MAP 	
		)
		, M
		AS (
		SELECT RT.ITEM_CD
			  ,RT.ACCOUNT_CD
			  ,IT.PARENT_ITEM_LV_ID					AS PARENT_ITEM_ID
			  ,IL.PARENT_ITEM_LV_ID					AS PARENT_ITEM_LV_ID
			  ,IL.ID								AS ITEM_LV_ID
			  ,IL.ITEM_LV_CD
			  ,AC.ID								AS ACCOUNT_ID
			  ,IT.ID								AS ITEM_MST_ID 
		  FROM RT 
			   INNER JOIN
			   TB_CM_ITEM_MST IT
			ON RT.ITEM_CD = IT.ITEM_CD
		  AND COALESCE(IT.DEL_YN,'N') = 'N'
			   INNER JOIN
			   TB_CM_ITEM_LEVEL_MGMT IL
			ON IT.PARENT_ITEM_LV_ID = IL.ID
			   INNER JOIN 
			   TB_DP_ACCOUNT_MST AC
			ON RT.ACCOUNT_CD = AC.ACCOUNT_CD
		)	
		SELECT ACCOUNT_CD				AS LV_CD
			 , ITEM_CD					AS PARENT_LV_CD
			 , ACCOUNT_CD || ITEM_CD	AS LV_KEY
			 , ITEM_CD || ITEM_LV_CD	AS PARENT_LV_KEY
			 , ITEM_CD					AS REF_COL
--			 , SUM(CNT)					AS CNT
		  FROM M
--			   LEFT OUTER JOIN 
--			   SALES S
--			ON M.ITEM_MST_ID = S.ITEM_MST_ID
--		   AND M.ACCOUNT_ID = S.ACCOUNT_ID
		GROUP BY ACCOUNT_CD, ITEM_LV_CD, ITEM_CD 
		UNION
		SELECT ITEM_CD					AS LV_CD
			  ,ITEM_LV_CD				AS PARENT_LV_CD
			 , ITEM_CD || ITEM_LV_CD	AS LV_KEY
			 , ITEM_LV_CD				AS PARENT_LV_KEY
			 , NULL						AS REF_COL
--			 , 0
		  FROM M 
		GROUP BY ITEM_CD, ITEM_LV_CD
		UNION
		SELECT ITEM_LV_CD				AS LV_CD
			  ,NULL						AS PARENT_LV_CD
			 , ITEM_LV_CD				AS LV_KEY
			 , NULL						AS PRENT_LV_KEY
			 , NULL						AS REF_COL
--			 , 0
		  FROM M 
		GROUP BY ITEM_LV_CD;
--		ORDER BY CNT DESC 		
	END IF;
END;
/

