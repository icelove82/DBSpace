create PROCEDURE                "SP_UI_DP_17_Q1" 
(
    p_SYSTEM_YN             IN VARCHAR2    := ''
  , p_MEASURE_VAL_TP_ID	    IN VARCHAR2    := ''
  , p_MEASURE_CD            IN VARCHAR2    := ''
  , p_BFSRPDP               IN VARCHAR2    := ''
  , pRESULT                 OUT SYS_REFCURSOR 
) 
IS

BEGIN

OPEN pRESULT

FOR 

SELECT	 MM.ID
		,MM.MEASURE_CD
		,MM.MEASURE_NM
		,MM.DESCRIP
		,MM.TBL_NM
		,MM.COL_NM
		,MM.MEASURE_VAL_TP_ID
		,MM.SYSTEM_YN
		,MM.BF_YN
		,MM.DP_YN
		,MM.SRP_YN
		,MM.CAL_YN
		,MM.CREATE_BY
		,MM.CREATE_DTTM
		,MM.MODIFY_BY
		,MM.MODIFY_DTTM
FROM	TB_DP_MEASURE_MST MM 
WHERE	MM.SYSTEM_YN			LIKE '%' || p_SYSTEM_YN || '%'
AND		MM.MEASURE_VAL_TP_ID	LIKE '%' || p_MEASURE_VAL_TP_ID || '%'
AND     UPPER(MM.MEASURE_CD)    LIKE '%' || UPPER(p_MEASURE_CD) || '%'
AND		COALESCE(MM.DEL_YN,'N') = 'N'
AND       (
               CASE WHEN p_BFSRPDP = 'ALL' THEN 'Y'
                    WHEN p_BFSRPDP = 'BF'  THEN MM.BF_YN
                    WHEN p_BFSRPDP = 'SRP' THEN MM.SRP_YN
                    WHEN p_BFSRPDP = 'DP'  THEN MM.DP_YN
                    END = 'Y'
          )
ORDER BY MM.SYSTEM_YN DESC, MM.MEASURE_CD
;

END
;
/

