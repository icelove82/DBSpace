create PROCEDURE                "SP_UI_BF_09_D1" (
    P_TYPE               IN  VARCHAR2    := ''        -- 체크된 행의 TYPE
  , P_FACTOR_CD          IN  VARCHAR2    := ''
  , P_RT_ROLLBACK_FLAG   OUT VARCHAR2
  , P_RT_MSG             OUT VARCHAR2        
)

IS

--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
P_ERR_MSG VARCHAR2(4000) := '';

BEGIN
    IF P_TYPE = 'extend' THEN
    --    DELETE FROM TB_BF_FACTOR_MGMT
    --     WHERE FACTOR_CD = @P_FACTOR_CD
        UPDATE TB_BF_FACTOR_MGMT
           SET DEL_YN = 'Y'
         WHERE FACTOR_CD = P_FACTOR_CD;
    END IF;
    P_RT_ROLLBACK_FLAG   := 'true';
    P_RT_MSG             := 'MSG_0002';  --삭제 되었습니다.

EXCEPTION WHEN OTHERS THEN
    P_ERR_MSG           := SQLERRM;
    P_RT_ROLLBACK_FLAG  := 'false';
    P_RT_MSG            := P_ERR_MSG;
END;
/

