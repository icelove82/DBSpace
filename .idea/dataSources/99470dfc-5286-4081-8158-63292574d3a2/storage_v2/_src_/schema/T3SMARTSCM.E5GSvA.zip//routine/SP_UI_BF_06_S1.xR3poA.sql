create PROCEDURE                "SP_UI_BF_06_S1" (
      P_ID                  CHAR
    , P_BASE_DATE           DATE
    , P_FACTOR1             NUMBER 
    , P_FACTOR2             NUMBER 
    , P_FACTOR3             NUMBER 
    , P_FACTOR4             NUMBER 
    , P_FACTOR5             NUMBER 
    , P_FACTOR6             NUMBER 
    , P_FACTOR7             NUMBER 
    , P_FACTOR8             NUMBER 
    , P_FACTOR9             NUMBER 
    , P_FACTOR10            NUMBER 
    , P_FACTOR11            NUMBER 
    , P_FACTOR12            NUMBER 
    , P_FACTOR13            NUMBER 
    , P_FACTOR14            NUMBER 
    , P_FACTOR15            NUMBER 
    , P_FACTOR16            NUMBER 
    , P_FACTOR17            NUMBER 
    , P_FACTOR18            NUMBER 
    , P_FACTOR19            NUMBER 
    , P_FACTOR20            NUMBER 
    , P_FACTOR21            NUMBER 
    , P_FACTOR22            NUMBER 
    , P_FACTOR23            NUMBER 
    , P_FACTOR24            NUMBER 
    , P_FACTOR25            NUMBER 
    , P_FACTOR26            NUMBER 
    , P_FACTOR27            NUMBER 
    , P_FACTOR28            NUMBER 
    , P_FACTOR29            NUMBER 
    , P_FACTOR30            NUMBER 
    , P_FACTOR31            NUMBER 
    , P_FACTOR32            NUMBER 
    , P_FACTOR33            NUMBER 
    , P_FACTOR34            NUMBER 
    , P_FACTOR35            NUMBER 
    , P_FACTOR36            NUMBER 
    , P_FACTOR37            NUMBER 
    , P_FACTOR38            NUMBER 
    , P_FACTOR39            NUMBER 
    , P_FACTOR40            NUMBER 
    , P_FACTOR41            NUMBER 
    , P_FACTOR42            NUMBER 
    , P_FACTOR43            NUMBER 
    , P_FACTOR44            NUMBER 
    , P_FACTOR45            NUMBER 
    , P_FACTOR46            NUMBER 
    , P_FACTOR47            NUMBER 
    , P_FACTOR48            NUMBER 
    , P_FACTOR49            NUMBER 
    , P_FACTOR50            NUMBER 
    , P_USER_ID             VARCHAR2
    , P_RT_ROLLBACK_FLAG    OUT VARCHAR2
    , P_RT_MSG              OUT VARCHAR2
) 
IS
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

    P_ERR_STATUS    NUMBER          := 0;
    P_ERR_MSG       VARCHAR2(4000)  :='';

BEGIN
    
    SELECT COUNT(BASE_DATE)
      INTO P_ERR_STATUS
      FROM TB_BF_DATE_FACTOR
     WHERE BASE_DATE = P_BASE_DATE
       AND ID != P_ID
     ;
 
    IF P_ERR_STATUS > 0 THEN
        P_ERR_MSG := 'Factors for desired date already exist.';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;
    
    MERGE INTO TB_BF_DATE_FACTOR TAR
    USING ( 
        SELECT  P_ID           AS ID           
              , P_BASE_DATE    AS BASE_DATE    
              , P_FACTOR1      AS FACTOR1  
              , P_FACTOR2      AS FACTOR2  
              , P_FACTOR3      AS FACTOR3  
              , P_FACTOR4      AS FACTOR4  
              , P_FACTOR5      AS FACTOR5  
              , P_FACTOR6      AS FACTOR6  
              , P_FACTOR7      AS FACTOR7  
              , P_FACTOR8      AS FACTOR8  
              , P_FACTOR9      AS FACTOR9  
              , P_FACTOR10     AS FACTOR10 
              , P_FACTOR11     AS FACTOR11 
              , P_FACTOR12     AS FACTOR12 
              , P_FACTOR13     AS FACTOR13 
              , P_FACTOR14     AS FACTOR14 
              , P_FACTOR15     AS FACTOR15 
              , P_FACTOR16     AS FACTOR16 
              , P_FACTOR17     AS FACTOR17 
              , P_FACTOR18     AS FACTOR18 
              , P_FACTOR19     AS FACTOR19 
              , P_FACTOR20     AS FACTOR20 
              , P_FACTOR21     AS FACTOR21 
              , P_FACTOR22     AS FACTOR22 
              , P_FACTOR23     AS FACTOR23 
              , P_FACTOR24     AS FACTOR24 
              , P_FACTOR25     AS FACTOR25 
              , P_FACTOR26     AS FACTOR26 
              , P_FACTOR27     AS FACTOR27 
              , P_FACTOR28     AS FACTOR28 
              , P_FACTOR29     AS FACTOR29 
              , P_FACTOR30     AS FACTOR30 
              , P_FACTOR31     AS FACTOR31 
              , P_FACTOR32     AS FACTOR32 
              , P_FACTOR33     AS FACTOR33 
              , P_FACTOR34     AS FACTOR34 
              , P_FACTOR35     AS FACTOR35 
              , P_FACTOR36     AS FACTOR36 
              , P_FACTOR37     AS FACTOR37 
              , P_FACTOR38     AS FACTOR38 
              , P_FACTOR39     AS FACTOR39 
              , P_FACTOR40     AS FACTOR40 
              , P_FACTOR41     AS FACTOR41 
              , P_FACTOR42     AS FACTOR42 
              , P_FACTOR43     AS FACTOR43 
              , P_FACTOR44     AS FACTOR44 
              , P_FACTOR45     AS FACTOR45 
              , P_FACTOR46     AS FACTOR46 
              , P_FACTOR47     AS FACTOR47 
              , P_FACTOR48     AS FACTOR48 
              , P_FACTOR49     AS FACTOR49 
              , P_FACTOR50     AS FACTOR50 
              , P_USER_ID      AS USER_ID
        FROM DUAL
    ) SRC
    ON    (TAR.ID            = SRC.ID)
    WHEN MATCHED THEN
         UPDATE 
           SET   TAR.BASE_DATE      = SRC.BASE_DATE
                ,TAR.FACTOR1        = SRC.FACTOR1   
                ,TAR.FACTOR2        = SRC.FACTOR2   
                ,TAR.FACTOR3        = SRC.FACTOR3   
                ,TAR.FACTOR4        = SRC.FACTOR4   
                ,TAR.FACTOR5        = SRC.FACTOR5   
                ,TAR.FACTOR6        = SRC.FACTOR6   
                ,TAR.FACTOR7        = SRC.FACTOR7   
                ,TAR.FACTOR8        = SRC.FACTOR8   
                ,TAR.FACTOR9        = SRC.FACTOR9   
                ,TAR.FACTOR10       = SRC.FACTOR10  
                ,TAR.FACTOR11       = SRC.FACTOR11  
                ,TAR.FACTOR12       = SRC.FACTOR12  
                ,TAR.FACTOR13       = SRC.FACTOR13  
                ,TAR.FACTOR14       = SRC.FACTOR14  
                ,TAR.FACTOR15       = SRC.FACTOR15  
                ,TAR.FACTOR16       = SRC.FACTOR16  
                ,TAR.FACTOR17       = SRC.FACTOR17  
                ,TAR.FACTOR18       = SRC.FACTOR18  
                ,TAR.FACTOR19       = SRC.FACTOR19  
                ,TAR.FACTOR20       = SRC.FACTOR20  
                ,TAR.FACTOR21       = SRC.FACTOR21  
                ,TAR.FACTOR22       = SRC.FACTOR22  
                ,TAR.FACTOR23       = SRC.FACTOR23  
                ,TAR.FACTOR24       = SRC.FACTOR24  
                ,TAR.FACTOR25       = SRC.FACTOR25  
                ,TAR.FACTOR26       = SRC.FACTOR26  
                ,TAR.FACTOR27       = SRC.FACTOR27  
                ,TAR.FACTOR28       = SRC.FACTOR28  
                ,TAR.FACTOR29       = SRC.FACTOR29  
                ,TAR.FACTOR30       = SRC.FACTOR30  
                ,TAR.FACTOR31       = SRC.FACTOR31  
                ,TAR.FACTOR32       = SRC.FACTOR32  
                ,TAR.FACTOR33       = SRC.FACTOR33  
                ,TAR.FACTOR34       = SRC.FACTOR34  
                ,TAR.FACTOR35       = SRC.FACTOR35  
                ,TAR.FACTOR36       = SRC.FACTOR36  
                ,TAR.FACTOR37       = SRC.FACTOR37  
                ,TAR.FACTOR38       = SRC.FACTOR38  
                ,TAR.FACTOR39       = SRC.FACTOR39  
                ,TAR.FACTOR40       = SRC.FACTOR40  
                ,TAR.FACTOR41       = SRC.FACTOR41  
                ,TAR.FACTOR42       = SRC.FACTOR42  
                ,TAR.FACTOR43       = SRC.FACTOR43  
                ,TAR.FACTOR44       = SRC.FACTOR44  
                ,TAR.FACTOR45       = SRC.FACTOR45  
                ,TAR.FACTOR46       = SRC.FACTOR46  
                ,TAR.FACTOR47       = SRC.FACTOR47  
                ,TAR.FACTOR48       = SRC.FACTOR48  
                ,TAR.FACTOR49       = SRC.FACTOR49  
                ,TAR.FACTOR50       = SRC.FACTOR50  
                ,TAR.MODIFY_BY      = SRC.USER_ID
                ,TAR.MODIFY_DTTM    = SYSDATE
    WHEN NOT MATCHED THEN 
         INSERT (
                  ID
                , BASE_DATE 
                , FACTOR1   
                , FACTOR2   
                , FACTOR3   
                , FACTOR4   
                , FACTOR5   
                , FACTOR6   
                , FACTOR7   
                , FACTOR8   
                , FACTOR9   
                , FACTOR10  
                , FACTOR11  
                , FACTOR12  
                , FACTOR13  
                , FACTOR14  
                , FACTOR15  
                , FACTOR16  
                , FACTOR17  
                , FACTOR18  
                , FACTOR19  
                , FACTOR20  
                , FACTOR21  
                , FACTOR22  
                , FACTOR23  
                , FACTOR24  
                , FACTOR25  
                , FACTOR26  
                , FACTOR27  
                , FACTOR28  
                , FACTOR29  
                , FACTOR30  
                , FACTOR31  
                , FACTOR32  
                , FACTOR33  
                , FACTOR34  
                , FACTOR35  
                , FACTOR36  
                , FACTOR37  
                , FACTOR38  
                , FACTOR39  
                , FACTOR40  
                , FACTOR41  
                , FACTOR42  
                , FACTOR43  
                , FACTOR44  
                , FACTOR45  
                , FACTOR46  
                , FACTOR47  
                , FACTOR48  
                , FACTOR49  
                , FACTOR50  
                , CREATE_BY 
                , CREATE_DTTM
                ) 
         VALUES (
                 RAWTOHEX(SYS_GUID())
                ,SRC.BASE_DATE
                ,SRC.FACTOR1
                ,SRC.FACTOR2
                ,SRC.FACTOR3
                ,SRC.FACTOR4
                ,SRC.FACTOR5
                ,SRC.FACTOR6
                ,SRC.FACTOR7
                ,SRC.FACTOR8
                ,SRC.FACTOR9
                ,SRC.FACTOR10
                ,SRC.FACTOR11
                ,SRC.FACTOR12
                ,SRC.FACTOR13
                ,SRC.FACTOR14
                ,SRC.FACTOR15
                ,SRC.FACTOR16
                ,SRC.FACTOR17
                ,SRC.FACTOR18
                ,SRC.FACTOR19
                ,SRC.FACTOR20
                ,SRC.FACTOR21
                ,SRC.FACTOR22
                ,SRC.FACTOR23
                ,SRC.FACTOR24
                ,SRC.FACTOR25
                ,SRC.FACTOR26
                ,SRC.FACTOR27
                ,SRC.FACTOR28
                ,SRC.FACTOR29
                ,SRC.FACTOR30
                ,SRC.FACTOR31
                ,SRC.FACTOR32
                ,SRC.FACTOR33
                ,SRC.FACTOR34
                ,SRC.FACTOR35
                ,SRC.FACTOR36
                ,SRC.FACTOR37
                ,SRC.FACTOR38
                ,SRC.FACTOR39
                ,SRC.FACTOR40
                ,SRC.FACTOR41
                ,SRC.FACTOR42
                ,SRC.FACTOR43
                ,SRC.FACTOR44
                ,SRC.FACTOR45
                ,SRC.FACTOR46
                ,SRC.FACTOR47
                ,SRC.FACTOR48
                ,SRC.FACTOR49
                ,SRC.FACTOR50
                ,SRC.USER_ID
                ,SYSDATE
                ) 
    ;    
            
    P_RT_ROLLBACK_FLAG  := 'true';
    P_RT_MSG            := 'MSG_0001';  --저장 되었습니다.

EXCEPTION WHEN OTHERS THEN
    IF (SQLCODE = -20001) THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
    ELSE 
        RAISE;
--              EXEC SP_COMM_RAISE_ERR
    END IF;
END;
/

