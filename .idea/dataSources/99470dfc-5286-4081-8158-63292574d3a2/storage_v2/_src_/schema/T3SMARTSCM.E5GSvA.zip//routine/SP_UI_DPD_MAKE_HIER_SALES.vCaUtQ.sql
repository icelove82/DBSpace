create PROCEDURE                "SP_UI_DPD_MAKE_HIER_SALES" 
IS          
/******************************************************************************************
	-- Create table 
	-- 2020.12.09 / kim sohee / oracle conveting
    - 2021.07.15 / Kim sohee / Make DPD_HIERARCHY2 data
    - 2021.11.23 / Kim sohee / add level type and use_yn
    -- 2022.11.30 / kim sohee / add NM 
********************************************************************************************/

    P_CHECK  INT; 
	CURSOR CUR_LOOP  IS
    SELECT LV_TP_ID, CC.CONF_CD AS LV_TP_CD, COALESCE(MAX(ATTR_01), 'PARENT_SALES_LV_ID') AS LV_TP_COL,  COUNT(CL.SEQ) AS LV_CNT
      FROM TB_CM_LEVEL_MGMT CL
           INNER JOIN
           TB_CM_COMM_CONFIG CC
        ON CL.LV_TP_ID = CC.ID 
     WHERE COALESCE(CL.ACCOUNT_LV_YN, 'N') = 'Y'
       AND COALESCE(CL.DEL_YN,'N') = 'N' 
       AND CL.ACTV_YN = 'Y'
    GROUP BY LV_TP_ID, CC.CONF_CD
       ;
	P_TMP_CNT INT := 1;  
	P_SQL	VARCHAR2(4000);               

BEGIN
/***************************************************************************************************************************
    -- Create Table and Index
****************************************************************************************************************************/
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_SALES_HIER_CLOSURE_01' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_SALES_HIER_CLOSURE_01 ON TB_DPD_SALES_HIER_CLOSURE (ANCESTER_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_SALES_HIER_CLOSURE_02' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_SALES_HIER_CLOSURE_02 ON TB_DPD_SALES_HIER_CLOSURE (ANCESTER_CD)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_SALES_HIER_CLOSURE_03' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_SALES_HIER_CLOSURE_03 ON TB_DPD_SALES_HIER_CLOSURE (DESCENDANT_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_SALES_HIER_CLOSURE_04' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_SALES_HIER_CLOSURE_04 ON TB_DPD_SALES_HIER_CLOSURE (DESCENDANT_CD)';
    END IF;
/* TB_DPD_ACCOUNT_HIERARCHY2 */
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'PK_TB_DPD_ACCOUNT_HIERACHY2' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN    -- PK
        EXECUTE IMMEDIATE  'ALTER TABLE TB_DPD_ACCOUNT_HIERACHY2 ADD CONSTRAINT PK_TB_DPD_ACCOUNT_HIERACHY2 PRIMARY KEY (ACCOUNT_ID)';        
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'UK_TB_DPD_ACCOUNT_HIERACHY2' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN    -- UK
        EXECUTE IMMEDIATE  'CREATE UNIQUE INDEX UK_TB_DPD_ACCOUNT_HIERACHY2 ON TB_DPD_ACCOUNT_HIERACHY2 (ACCOUNT_CD)';                
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_01' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN 
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_01 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL01_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_02' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_02 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL02_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_03' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_03 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL03_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_04' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_04 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL04_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_05' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_05 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL05_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_06' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_06 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL06_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_07' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_07 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL07_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_08' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_08 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL08_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_09' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_09 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL09_ID)';
    END IF;
SELECT COUNT(1) INTO P_CHECK FROM ALL_INDEXES WHERE INDEX_NAME = 'IDX_TB_DPD_ACCOUNT_HIERACHY2_10' AND OWNER = (SELECT USER FROM DUAL); 
IF P_CHECK = 0
    THEN
        EXECUTE IMMEDIATE  'CREATE INDEX IDX_TB_DPD_ACCOUNT_HIERACHY2_10 ON TB_DPD_ACCOUNT_HIERACHY2 (LVL10_ID)';
    END IF;
/************************************************************************************************************************************************************************************************************
	-- Main Query
************************************************************************************************************************************************************************************************************/ 

	DELETE FROM TB_DPD_SALES_HIER_CLOSURE;

    INSERT INTO TB_DPD_SALES_HIER_CLOSURE 
		 ( ANCESTER_ID
		 , ANCESTER_CD
		 , ANCESTER_NM
		 , DESCENDANT_ID
		 , DESCENDANT_CD
		 , DESCENDANT_NM
		 , DEPTH_NUM
		 , LEAF_YN 
         , LV_TP_CD
         , USE_YN
 		  )
	WITH SALES_HIER AS
	(SELECT M.ID					AS DESCENDANT_ID 
		  , M.SALES_LV_CD			AS DESCENDANT_CD
		  , M.SALES_LV_NM			AS DESCENDANT_NM
		  , M.PARENT_SALES_LV_ID	AS ANCESTER_ID
		  , P.SALES_LV_CD			AS ANCESTER_CD 
		  , P.SALES_LV_NM			AS ANCESTER_NM
		  , 'N'						AS LEAF_YN 
		  , CL.LV_TP_ID
		  , CC.CONF_CD	AS LV_TP_CD          
          , 'Y' AS USE_YN
	   FROM TB_DP_SALES_LEVEL_MGMT M 
		    LEFT OUTER JOIN
			TB_DP_SALES_LEVEL_MGMT P 
		 ON M.PARENT_SALES_LV_ID=P.ID 
		AND M.ACTV_YN = 'Y' 
			INNER JOIN 
			TB_CM_LEVEL_MGMT CL
		 ON M.LV_MGMT_ID = CL.ID 
		AND NVL(CL.DEL_YN,'N') = 'N'
		AND CL.ACTV_YN = 'Y'
			INNER JOIN 
			TB_CM_COMM_CONFIG CC
		 ON CL.LV_TP_ID = CC.ID         
			LEFT OUTER JOIN 
			TB_CM_LEVEL_MGMT PL
		 ON P.LV_MGMT_ID = PL.ID 
		AND NVL(PL.DEL_YN,'N') = 'N'
		AND PL.ACTV_YN = 'Y'
	    AND P.ACTV_YN = 'Y'
	    AND NVL(P.DEL_YN,'N') = 'N'
	)
	SELECT DESCENDANT_ID
		 , DESCENDANT_CD
		 , DESCENDANT_NM
		 , DESCENDANT_ID
		 , DESCENDANT_CD
		 , DESCENDANT_NM
		 , 0				AS DEPTH_NUM  
		 , LEAF_YN				AS LEAF_YN
         , LV_TP_CD
         , USE_YN 
	   FROM SALES_HIER
	  WHERE DESCENDANT_ID IS NOT NULL	   
	   ;
    DBMS_OUTPUT.PUT_LINE('BEGIN CLOSURE LOOP');
    /******************************************************************************************************************************************
        Loop를 parents sales level 개수 따라 돌려야 함.
        (1) 상하위 계층 다 Account인 정보를 넣어주고
        (2) 계층 깊이 만큼 Loop를 돌린다.            
        (3) 상하위 깊이가 다른 정보들을 DPD 테이블에 넣준다. (기존에 존재하던 루프 코드를 Level type을 조건으로 넣게끔 dynamic query로 변경)

        https://docs.oracle.com/cd/B19306_01/appdev.102/b14261/dynamic.htm#i13130
    *******************************************************************************************************************************************/            
    FOR CLOSURE_LOOP IN CUR_LOOP LOOP
    P_TMP_CNT := 1;  
        -- (1) 상하위 계층 다 Account인 정보를 level type에 따라 만들어주기    
        DBMS_OUTPUT.PUT_LINE('CLOSURE_LOOP:'||CLOSURE_LOOP.LV_TP_COL);
	 P_SQL := ' SELECT A.ID'
			||'	, A.ACCOUNT_CD' 
			||'	, A.ACCOUNT_NM' 
			||'	, A.ID'
			||'	, A.ACCOUNT_CD' 
			||'	, A.ACCOUNT_NM' 
			||' , 0' 
			||' , ''Y'''
			||' , CASE WHEN A.ACTV_YN = ''N'' OR COALESCE(A.DEL_YN,''N'') = ''Y'' OR P.ACTV_YN = ''N'' OR COALESCE(P.DEL_YN,''N'') = ''Y'' THEN ''N''  ELSE ''Y'' END AS USE_YN' 
--			||'	, PL.LV_TP_ID'
			||'	, CC.CONF_CD AS LV_TP_CD'
			||'   FROM TB_DP_ACCOUNT_MST A'
			||' 	   INNER JOIN'
			||'        TB_DP_SALES_LEVEL_MGMT P'
			||'	 ON A.'||CLOSURE_LOOP.LV_TP_COL||'=P.ID'	-- PARENT_SALES_LV_ID
			||'		INNER JOIN 	'
			||'		TB_CM_LEVEL_MGMT PL'
			||'	 ON P.LV_MGMT_ID = PL.ID'
			||'	AND NVL(PL.DEL_YN,''N'') = ''N'''
			||'	AND PL.ACTV_YN = ''Y'''
			||'		INNER JOIN 	'
			||'		TB_CM_COMM_CONFIG CC'
			||'	 ON PL.LV_TP_ID = CC.ID  '
		;    

        -- insert exec query

        P_SQL := 'INSERT INTO TB_DPD_SALES_HIER_CLOSURE '
                ||' ( '
                ||' ANCESTER_ID '
                ||',ANCESTER_CD '                
                ||',ANCESTER_NM '                
                ||',DESCENDANT_ID '                
                ||',DESCENDANT_CD '                
                 ||',DESCENDANT_NM '
                ||',DEPTH_NUM '                
                ||',LEAF_YN '                
                ||',USE_YN '                
                ||',LV_TP_CD '                
                ||' ) '
                ||P_SQL       
        ; 
        --DBMS_OUTPUT.PUT_LINE(P_SQL);
        EXECUTE IMMEDIATE  P_SQL;
        DBMS_OUTPUT.PUT_LINE('BEGIN WHILE P_TMP_CNT <= CLOSURE_LOOP.LV_CNT');    

        WHILE P_TMP_CNT <= CLOSURE_LOOP.LV_CNT
        LOOP           
                DBMS_OUTPUT.PUT_LINE('P_TMP_CNT:'||TO_CHAR(P_TMP_CNT));
                
                P_SQL := ' WITH SALES_HIER AS '
				||'(SELECT SL.ID'
				||'		 , SL.SALES_LV_CD AS ACCT_CD'
				||'		 , SL.SALES_LV_NM AS ACCT_NM'
				||'		 , SL.PARENT_SALES_LV_ID' 
				||'		 , ''N''		AS LEAF_YN'
                ||'      , CASE WHEN  SL.ACTV_YN = ''N'' OR NVL(SL.DEL_YN,''N'') = ''Y'' THEN ''N'' ELSE ''Y'' END AS USE_YN'
				||'	  FROM TB_DP_SALES_LEVEL_MGMT SL'
				||'		   INNER JOIN 	'
				||'	 	   TB_CM_LEVEL_MGMT CL'
				||'	   ON SL.LV_MGMT_ID = CL.ID '
				||'	  AND COALESCE(CL.DEL_YN,''N'') = ''N'''
				||'	  AND CL.ACTV_YN = ''Y'''
				||' WHERE CL.LV_TP_ID = '''||CLOSURE_LOOP.LV_TP_ID||''''
                -- Account
				||' UNION ALL'
				||'	SELECT ID'
				||'	     , ACCOUNT_CD  AS ACCT_CD'
				||'	     , ACCOUNT_NM  AS ACCT_NM'
				||'	     , '||CLOSURE_LOOP.LV_TP_COL	-- AS PARENT_SALES_LV_ID
				||'		 , ''Y'''
                ||'      , CASE WHEN ACTV_YN = ''N'' OR COALESCE(DEL_YN,''N'') = ''Y'' THEN ''N'' ELSE ''Y'' END AS USE_YN'
				||'	 FROM TB_DP_ACCOUNT_MST'
				||' WHERE '||CLOSURE_LOOP.LV_TP_COL||' IS NOT NULL' -- PARENT_SALES_LV_ID
				||' ) '			
                ;

            P_SQL :=P_SQL||' SELECT C.ANCESTER_ID ' 
            ||', C.ANCESTER_CD '
            ||', C.ANCESTER_NM '
            ||', H.ID '
            ||', H.ACCT_CD '
            ||', H.ACCT_NM '
            ||', '||TO_CHAR(P_TMP_CNT)||' '
            ||', H.LEAF_YN '
            ||', H.USE_YN '
            ||', '''||CLOSURE_LOOP.LV_TP_CD||''''
            ||' FROM TB_DPD_SALES_HIER_CLOSURE C '
            ||'  INNER JOIN '
            ||' SALES_HIER H '
            ||' ON (C.DESCENDANT_ID = H.PARENT_SALES_LV_ID '
         	||' AND C.DEPTH_NUM = '|| TO_CHAR(P_TMP_CNT-1)||')'             
            ;                       

           P_SQL := 'INSERT INTO TB_DPD_SALES_HIER_CLOSURE '
            ||'( ANCESTER_ID '
            ||', ANCESTER_CD '
            ||', ANCESTER_NM '
            ||', DESCENDANT_ID '
            ||', DESCENDANT_CD '
            ||', DESCENDANT_NM '
            ||', DEPTH_NUM '
            ||', LEAF_YN   '
            ||', USE_YN '               
            ||', LV_TP_CD '               
            ||')'
            ||P_SQL
            ;

             EXECUTE IMMEDIATE  P_SQL;
            DBMS_OUTPUT.PUT_LINE(P_SQL);

            P_TMP_CNT := P_TMP_CNT+1
            ;
        END LOOP;
        DBMS_OUTPUT.PUT_LINE('WHILE END');

    END LOOP;
    DBMS_OUTPUT.PUT_LINE('END LOOP');    


/***********************************************************************************************************************************************
	Create TB_DPD_ACCOUNT_HIERARCHY2
************************************************************************************************************************************************/

    DBMS_OUTPUT.PUT_LINE('CREATE TB_DPD_ACCOUNT_HIERACHY2');
    DELETE FROM TB_DPD_ACCOUNT_HIERACHY2;         
    FOR LOOP_HIERACHY2 IN CUR_LOOP 
    LOOP

    INSERT INTO TB_DPD_ACCOUNT_HIERACHY2
    (     LVL01_ID
        , LVL02_ID
        , LVL03_ID
        , LVL04_ID
        , LVL05_ID
        , LVL06_ID
        , LVL07_ID
        , LVL08_ID
        , LVL09_ID
        , LVL10_ID
        , LVL01_CD
        , LVL02_CD
        , LVL03_CD
        , LVL04_CD
        , LVL05_CD
        , LVL06_CD
        , LVL07_CD
        , LVL08_CD
        , LVL09_CD
        , LVL10_CD
        , LVL01_NM
        , LVL02_NM
        , LVL03_NM
        , LVL04_NM
        , LVL05_NM
        , LVL06_NM
        , LVL07_NM
        , LVL08_NM
        , LVL09_NM
        , LVL10_NM
        , ACCOUNT_ID
        , ACCOUNT_CD
        , ACCOUNT_NM
        , CURCY_CD
        , CURCY_NM
        , CURCY_ID
        , SOLD_CUSTOMER_CD
        , SOLD_CUSTOMER_NM
        , SHIP_CUSTOMER_CD
        , SHIP_CUSTOMER_NM
        , BILL_CUSTOMER_CD
        , BILL_CUSTOMER_NM
        , INCOTERMS
        , CHANNEL_NM
        , COUNTRY_CD
        , COUNTRY_NM
        , VMI_YN
        , ATTR_01
        , ATTR_02
        , ATTR_03
        , ATTR_04
        , ATTR_05
        , ATTR_06
        , ATTR_07
        , ATTR_08
        , ATTR_09
        , ATTR_10
        , ATTR_11
        , ATTR_12
        , ATTR_13
        , ATTR_14
        , ATTR_15
        , ATTR_16
        , ATTR_17
        , ATTR_18
        , ATTR_19
        , ATTR_20
        , LV_TP_CD
        , USE_YN 
    ) 
    WITH SALES_HIER 
     AS (
        SELECT ANCESTER_ID  
                 , ANCESTER_CD
                 , COALESCE(SL.SALES_LV_NM, AC.ACCOUNT_NM) AS ANCESTER_NM
                 , DESCENDANT_ID
                 , DESCENDANT_CD
                 , 'LVL'|| LPAD( DENSE_RANK () OVER ( ORDER BY DEPTH_NUM DESC ), 2, '0')  AS COL
                 , USE_YN
          FROM TB_DPD_SALES_HIER_CLOSURE SH 
               LEFT OUTER JOIN 
               TB_DP_SALES_LEVEL_MGMT SL 
            ON SH.ANCESTER_ID = SL.ID 
              LEFT OUTER JOIN 
              TB_DP_ACCOUNT_MST AC
           ON SH.ANCESTER_ID = AC.ID 
         WHERE SH.LEAF_YN = 'Y' 
           AND SH.LV_TP_CD = LOOP_HIERACHY2.LV_TP_CD
     ), CURRENCY
     AS (
         SELECT CD.ID, CD.COMN_CD, CD.COMN_CD_NM 
           FROM TB_AD_COMN_GRP CM
                INNER JOIN 
                TB_AD_COMN_CODE CD 
             ON CM.ID = CD.SRC_ID 
            AND CM.GRP_CD = 'CURRENCY'  
     ), COUNTRY
    AS (
         SELECT B.ID  AS ID
              , B.CONF_CD 
              , B.CONF_NM 
           FROM TB_CM_CONFIGURATION A
                INNER JOIN 
                TB_CM_COMM_CONFIG B
             ON A.ID = B.CONF_ID
            AND B.CONF_GRP_CD = 'CM_COUNTRY'
            AND B.ACTV_YN = 'Y'
        ) 
    SELECT  LVL01_ID
          , LVL02_ID
          , LVL03_ID
          , LVL04_ID
          , LVL05_ID
          , LVL06_ID
          , LVL07_ID
          , LVL08_ID
          , LVL09_ID
          , LVL10_ID
          , LVL01_CD
          , LVL02_CD
          , LVL03_CD
          , LVL04_CD
          , LVL05_CD
          , LVL06_CD
          , LVL07_CD
          , LVL08_CD
          , LVL09_CD
          , LVL10_CD
          , LVL01_NM
          , LVL02_NM
          , LVL03_NM
          , LVL04_NM
          , LVL05_NM
          , LVL06_NM
          , LVL07_NM
          , LVL08_NM
          , LVL09_NM
          , LVL10_NM
          , DESCENDANT_ID					AS ACCOUNT_ID
          , DESCENDANT_CD					AS ACCOUNT_CD
          , AM.ACCOUNT_NM					AS ACCOUNT_NM
          , CC.COMN_CD						AS CURCY_CD
          , CC.COMN_CD_NM					AS CURCY_NM
          , AM.CURCY_CD_ID					AS CURCY_ID
          , ST.CUST_CD						AS SOLD_CUSTOMER_CD
          , ST.CUST_NM						AS SOLD_CUSTOMER_NM
          , PT.CUST_CD						AS SHIP_CUSTOMER_CD
          ,	PT.CUST_NM						AS SHIP_CUSTOMER_NM
          ,	BT.CUST_CD						AS BILL_CUSTOMER_CD
          ,	BT.CUST_NM						AS BILL_CUSTOMER_NM
          , IC.INCOTERMS
          , CH.CHANNEL_NM
          , CR.CONF_CD						AS COUNTRY_CD
          , CR.CONF_NM						AS COUNTRY_NM
          , AM.VMI_YN
          , AM.ATTR_01
          , AM.ATTR_02
          , AM.ATTR_03
          , AM.ATTR_04
          , AM.ATTR_05
          , AM.ATTR_06
          , AM.ATTR_07
          , AM.ATTR_08
          , AM.ATTR_09
          , AM.ATTR_10
          , AM.ATTR_11
          , AM.ATTR_12
          , AM.ATTR_13
          , AM.ATTR_14
          , AM.ATTR_15
          , AM.ATTR_16
          , AM.ATTR_17
          , AM.ATTR_18
          , AM.ATTR_19
          , AM.ATTR_20
          , LOOP_HIERACHY2.LV_TP_CD
          , SH.USE_YN AS USE_YN     -- CASE WHEN AM.ACTV_YN = 'Y' AND COALESCE(AM.DEL_YN,'N') = 'N' THEN 'Y' ELSE 'N' END
      FROM SALES_HIER SH
           PIVOT (MAX(ANCESTER_ID) AS ID
                , MAX(ANCESTER_CD) AS CD
                , MAX(ANCESTER_NM) AS NM 
            FOR COL IN ( 'LVL01' AS LVL01	
                       , 'LVL02' AS LVL02
                       , 'LVL03' AS LVL03
                       , 'LVL04' AS LVL04
                       , 'LVL05' AS LVL05
                       , 'LVL06' AS LVL06
                       , 'LVL07' AS LVL07
                       , 'LVL08' AS LVL08
                       , 'LVL09' AS LVL09
                       , 'LVL10' AS LVL10)
                      )  SH
           INNER JOIN
           TB_DP_ACCOUNT_MST AM
        ON SH.DESCENDANT_ID = AM.ID 
           LEFT OUTER JOIN
           TB_CM_CUSTOMER ST
        ON AM.SOLD_TO_ID = ST.ID 
           LEFT OUTER JOIN
           TB_CM_CUSTOMER PT
        ON AM.SHIP_TO_ID = PT.ID 	
           LEFT OUTER JOIN
           TB_CM_CUSTOMER BT
        ON AM.BILL_TO_ID = BT.ID 	
           LEFT OUTER JOIN 
           TB_CM_INCOTERMS IC
        ON IC.ID = AM.INCOTERMS_ID
           LEFT OUTER JOIN 
           TB_CM_CHANNEL_TYPE CH 
        ON CH.ID = AM.CHANNEL_ID
           LEFT OUTER JOIN
           CURRENCY CC
        ON AM.CURCY_CD_ID = CC.ID 
           LEFT OUTER JOIN
           COUNTRY CR
        ON CR.ID = AM.COUNTRY_ID
    WHERE LVL01_ID IS NOT NULL
    ; 
 END LOOP;
END
;
/

