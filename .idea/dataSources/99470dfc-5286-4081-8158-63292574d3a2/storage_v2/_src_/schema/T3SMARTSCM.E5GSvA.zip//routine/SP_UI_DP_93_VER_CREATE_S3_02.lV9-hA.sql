create PROCEDURE                "SP_UI_DP_93_VER_CREATE_S3_02"  (
			P_VER_ID					CHAR 
          , P_FROM_DATE                 DATE 
          , P_TO_DATE                   DATE
          , pRESULT        OUT SYS_REFCURSOR
)
IS  
/**************************************************************************************************************
    -- Oracle Test를 위한 SP_UI_DP_93_VER_CREATE_S3 프로시저 PART 1
    -- 동적쿼리 확인용... 다양한 Case test하고 기본 프로시저랑 합칠 예정
    
    - History ( date / writer / comment )
    - 2021.02.03 / kim sohee / 누락된 where 조건 추가 (data 못찾는 error에 대한 예외 처리 관련) 
*************************************************************************************************************/	 
		   -- For Loop 
		   P_STR	VARCHAR2(4000); 
           p_SELECT_STR    NVARCHAR2(4000);
		   P_VAL_CNT  INT ;
BEGIN 
         SELECT COUNT(1) INTO P_VAL_CNT
           FROM TABLE(FN_DP_TEMP_VER_INFO_DTL (P_VER_ID))
          WHERE INIT_TP_CD = 'MS'   
           ;
        IF( P_VAL_CNT = 0)
            THEN
                SELECT COUNT(1) INTO P_VAL_CNT
                  FROM TABLE(FN_DP_TEMP_VER_INFO_INIT (P_VER_ID)) 
                 WHERE INIT_VAL_TP_CD = 'MS'   
                 ;
            END IF;
        IF (P_VAL_CNT > 0)
			THEN	
				P_STR := '';		 
				WITH INI
				  AS (
					SELECT DTL_ID 
						 , AUTH_TP_ID 
						 , INIT_VAL_CD|| ' AS QTY' AS COL
						 , 'QTY' as VAL_COL
						 , 'SRC.QTY'  as IST_COL
						 , 'TGT.QTY = SRC.QTY' as UPT_COL
					 FROM TABLE(FN_DP_TEMP_VER_INFO_DTL (P_VER_ID)) 
					WHERE INIT_TP_CD = 'MS' 
					UNION
					SELECT DTL_ID 
						 , AUTH_TP_ID 
						 , LISTAGG(INIT_MEASURE_CD||' AS '||INIT_MS_VAL_TP_CD, ',') within group (order by INIT_MEASURE_CD)  AS COL
--						 , LISTAGG(INIT_MEASURE_CD, ',') within group (order by INIT_MS_VAL_TP_CD AS MS_COL
						 , LISTAGG(INIT_MS_VAL_TP_CD, ',') within group (order by INIT_MS_VAL_TP_CD) AS VAL_COL
						 , LISTAGG('SRC.'||INIT_MS_VAL_TP_CD, ',') within group (order by INIT_MS_VAL_TP_CD) as IST_COL
						 , LISTAGG ('TGT.'||INIT_MS_VAL_TP_CD||'='||'SRC.'||INIT_MS_VAL_TP_CD, ',') within group (order by INIT_MS_VAL_TP_CD) as UPT_COL
					  FROM TABLE(FN_DP_TEMP_VER_INFO_INIT (P_VER_ID)) 
					 WHERE INIT_VAL_TP_CD = 'MS' 
					 GROUP BY DTL_ID, AUTH_TP_ID
				  ) 
				SELECT  P_STR 
					 || ' MERGE INTO TEMP_DP_RT TGT'
					 || ' USING (			  '
					 || 'SELECT ITEM_MST_ID, ACCOUNT_ID, BASE_DATE '
				     || ','''||AUTH_TP_ID||''' AS AUTH_TP_ID '
				     || ','''||DTL_ID||''' AS DTL_ID '
					 ||  ','||coalesce(COL,'')
					 || ' FROM TB_DP_MEASURE_DATA'
					 || ' WHERE BASE_DATE BETWEEN TO_DATE( '''||TO_CHAR(P_FROM_DATE, 'YYYY-MM-DD' )||''') AND TO_DATE( '''||TO_CHAR( P_TO_DATE, 'YYYY-MM-DD')||''') '
					 || ' ) SRC '
					 || ' ON (SRC.ITEM_MST_ID = TGT.ITEM_MST_ID '
					 || ' AND SRC.ACCOUNT_ID = TGT.ACCOUNT_ID '
					 || ' AND SRC.BASE_DATE = TGT.BASE_DATE '
					 || ' AND SRC.AUTH_TP_ID = TGT.AUTH_TP_ID) '
					 || ' WHEN MATCHED THEN '
					 || ' UPDATE SET '||UPT_COL
					 || ' WHEN NOT MATCHED THEN '
					 || ' INSERT  ( '
					 || ' ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, AUTH_TP_ID ,'
					 ||  VAL_COL
					 || ' ) VALUES '
					 || ' (SRC.ITEM_MST_ID, SRC.ACCOUNT_ID, SRC.BASE_DATE, SRC.AUTH_TP_ID ,'
					 || IST_COL
					 || ' )'
					 INTO P_STR
				 FROM INI 
				;	
			
				dbms_output.put_line ('P_STR : ['||P_STR||']');
			
			
                OPEN PRESULT FOR 
                SELECT P_STR AS STR 
                  FROM DUAL;
                  
				--EXECUTE IMMEDIATE P_STR;	 				
				
			END IF
            ;

END
;
/

