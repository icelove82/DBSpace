create PROCEDURE                "SP_UI_DP_19_PERSON_AUTO_CREATE" 
(
    P_GRP_ID       IN  VARCHAR2 :=''
  , P_UI_ID            IN  VARCHAR2 :=''
  , P_GRID_ID          IN  VARCHAR2 :=''
  , P_USER_ID          IN  VARCHAR2 :=''
  , P_RT_ROLLBACK_FLAG OUT VARCHAR2      
  , P_RT_MSG           OUT VARCHAR2  
)IS
    /*****************************************************************************************************************
        DP Measure 
         2018.06.07

         -- 2021.06.16 / Kim sohee / keep Preference Data by user 
    *****************************************************************************************************************/
    v_PERSON_CNT INT;
    P_ERR_STATUS INT := 0;
    P_ERR_MSG VARCHAR2(4000):='';
    V_USER_PREF_MST_ID CHAR(32);

BEGIN

    SELECT ID INTO V_USER_PREF_MST_ID
      FROM TB_AD_USER_PREF_MST
     WHERE VIEW_CD = P_UI_ID
       AND GRID_CD = P_GRID_ID;

    DELETE FROM TB_AD_USER_PREF_DTL
     WHERE 1=1
       AND GRP_ID = P_GRP_ID
       AND USER_PREF_MST_ID = V_USER_PREF_MST_ID
       AND DIM_MEASURE_TP = 'MEASURE'
       ;

    INSERT INTO TB_AD_USER_PREF_DTL (
        ID
      , USER_PREF_MST_ID
      , GRP_ID
      , FLD_CD
      , FLD_APPLY_CD
      , FLD_WIDTH
      , FLD_SEQ
      , FLD_ACTIVE_YN
      , APPLY_YN
      , REFER_VALUE
      , CROSSTAB_ITEM_CD
      , CATEGORY_GROUP
      , DIM_MEASURE_TP
      , EDIT_MEASURE_YN
      , EDIT_TARGET_YN
      , DATA_KEY_YN
      , CROSSTAB_YN
      , CREATE_BY
      , CREATE_DTTM
    )
    SELECT RAWTOHEX(SYS_GUID()) 
         , V_USER_PREF_MST_ID
         , P_GRP_ID
         , 'MEASURE_' || LPAD(TO_CHAR(ROW_NUMBER() OVER (ORDER BY SEQ)), 2, '0') AS FIELD_ID
         , A.DISP_NM                AS FIELD_NM
         , '100'                    AS FIELD_WDTH
         , A.SEQ                    AS SEQ
         , A.ACTV_YN                AS ACTV_YN
         , 'Y'                      AS PNSZ_APPY_YN
         , A.ID                     AS FIELD_VAL
         , 'GROUP-VERTICAL-VALUES'  AS PIVOT_ITEM_CD
         , NULL                     AS CATEGORY_GROUP
         , 'MEASURE'                AS DIM_MEASURE_TP
         , A.INPUT_YN               AS EDIT_MEASURE
         , 'N'                      AS EDIT_TARGET
         , 'N'                      AS DATA_KEY_YN
         , A.ACTV_YN                AS PIVOT_APPY_YN
         , P_USER_ID                AS CREATE_BY
         , SYSDATE                  AS CREATE_DTTM
      FROM TB_DP_MEASURE_SETTING A
     INNER JOIN TB_CM_COMM_CONFIG B
        ON A.MEASURE_CONF_TP_ID = B.ID
     WHERE 1=1
       AND RTRIM(GRP_ID) = RTRIM(P_GRP_ID)
       AND UI_ID = P_UI_ID
       AND GRID_ID = P_GRID_ID
    ;

/************************************************************************************************************************

	[ Re-make TB_AD_USER_PREF ]

	-- Dimension를 하나 생성하는 case에는 이전 dimesion ID가 지워져서 이전 refer value로 개인화 정보를 읽어올 수 없다.
	-- 그래서, 이 프로시저 (개인화 기준 정보를 새로 생성)는 이전 개인화 정보를 찾을 때, Field code 혹은 Field apply code를 key로 한다.
*************************************************************************************************************************/

			   INSERT INTO TEMP_AD_USER_PREF 
			   (  USER_ID			
			    , GRP_ID			
			    , FLD_CD			
			    , FLD_APPLY_CD		
			    , FLD_WIDTH		
			    , FLD_SEQ			
			    , FLD_ACTIVE_YN	
			    , APPLY_YN			
			    , REFER_VALUE		
				, DIM_MEASURE_TP 
			    , CROSSTAB_ITEM_CD	
			    , CATEGORY_GROUP	
			    , SUMMARY_TP		
			    , SUMMARY_YN		
			    , EDIT_MEASURE_YN	
			    , EDIT_TARGET_YN	
			    , DATA_KEY_YN		
			    , CROSSTAB_YN		
				, CREATE_BY	
				, CREATE_DTTM					
				)		 
			    SELECT USER_ID
					 , GRP_ID
					 , FLD_CD
					 , FLD_APPLY_CD
					 , FLD_WIDTH
					 , FLD_SEQ
					 , FLD_ACTIVE_YN
					 , APPLY_YN
					 , REFER_VALUE
					 , DIM_MEASURE_TP 
					 , CROSSTAB_ITEM_CD
					 , CATEGORY_GROUP
					 , SUMMARY_TP
					 , SUMMARY_YN
					 , EDIT_MEASURE_YN
					 , EDIT_TARGET_YN
					 , DATA_KEY_YN
					 , CROSSTAB_YN
					 , CREATE_BY	
					 , CREATE_DTTM	
			     FROM TB_AD_USER_PREF
				WHERE USER_PREF_MST_ID = V_USER_PREF_MST_ID
				  AND DIM_MEASURE_TP = 'MEASURE'
				  AND RTRIM(GRP_ID) = RTRIM(P_GRP_ID)
				  ;
			DELETE 
			  FROM TB_AD_USER_PREF
			 WHERE USER_PREF_MST_ID = V_USER_PREF_MST_ID
			   AND DIM_MEASURE_TP = 'MEASURE'
				  AND RTRIM(GRP_ID) = RTRIM(P_GRP_ID)
			   ;
			INSERT INTO TB_AD_USER_PREF
			( ID
			, USER_ID
			, USER_PREF_MST_ID
			, GRP_ID
			, FLD_CD
			, FLD_APPLY_CD
			, FLD_WIDTH
			, FLD_SEQ
			, FLD_ACTIVE_YN
			, APPLY_YN
			, REFER_VALUE
			, CROSSTAB_ITEM_CD
			, CATEGORY_GROUP
			, DIM_MEASURE_TP
			, SUMMARY_TP
			, SUMMARY_YN
			, EDIT_MEASURE_YN
			, EDIT_TARGET_YN
			, DATA_KEY_YN
			, CROSSTAB_YN
			, CREATE_BY
			, CREATE_DTTM
			, MODIFY_BY
			, MODIFY_DTTM
			)               
			WITH PREF_USER
			 AS (
				SELECT DISTINCT USER_ID FROM TEMP_AD_USER_PREF 
			 ), NEW_USER_PREF
			AS ( 
				 SELECT D.GRP_ID
					  , D.FLD_CD
					  , D.FLD_APPLY_CD
					  , D.FLD_WIDTH
					  , D.FLD_SEQ
					  , D.FLD_ACTIVE_YN
					  , D.APPLY_YN
					  , D.REFER_VALUE
					  , D.CROSSTAB_ITEM_CD
					  , D.CATEGORY_GROUP
					  , D.DIM_MEASURE_TP
					  , D.SUMMARY_TP
					  , D.SUMMARY_YN
					  , D.EDIT_MEASURE_YN
					  , D.EDIT_TARGET_YN
					  , D.DATA_KEY_YN
					  , D.CROSSTAB_YN	
					  , P.USER_ID 				 
				   FROM TB_AD_USER_PREF_DTL D
					    CROSS JOIN
						PREF_USER P 
				  WHERE D.USER_PREF_MST_ID = V_USER_PREF_MST_ID
				    AND D.DIM_MEASURE_TP = 'MEASURE'
                    AND RTRIM(GRP_ID) = RTRIM(P_GRP_ID)
			   )
			SELECT	TO_SINGLE_BYTE(SYS_GUID()) AS ID 
				  , M.USER_ID 	
				  , V_USER_PREF_MST_ID
				  , M.GRP_ID
				  , M.FLD_CD
				  , M.FLD_APPLY_CD
				  , M.FLD_WIDTH
				  , COALESCE(S.FLD_SEQ			, M.FLD_SEQ			)
				  , COALESCE(S.FLD_ACTIVE_YN	, M.FLD_ACTIVE_YN	)
				  , M.APPLY_YN
				  , M.REFER_VALUE
				  , M.CROSSTAB_ITEM_CD
				  , M.CATEGORY_GROUP
				  , M.DIM_MEASURE_TP
				  , M.SUMMARY_TP
				  , M.SUMMARY_YN
				  , M.EDIT_MEASURE_YN
				  , M.EDIT_TARGET_YN
				  , M.DATA_KEY_YN
				  , M.CROSSTAB_YN	
				  , COALESCE(S.CREATE_BY   ,	'system')  CREATE_BY
				  , COALESCE(S.CREATE_DTTM ,SYSDATE)	   CREATE_DTTM
				  , CASE WHEN S.FLD_CD IS NULL THEN NULL ELSE 'system'	END
				  , CASE WHEN S.FLD_CD IS NULL THEN NULL ELSE SYSDATE END
			  FROM NEW_USER_PREF M  
				   LEFT OUTER JOIN 
				   TEMP_AD_USER_PREF S
				ON M.GRP_ID = S.GRP_ID
			   AND M.USER_ID = S.USER_ID 
--			   AND M.REFER_VALUE = S.REFER_VALUE 
			   AND M.FLD_APPLY_CD = S.FLD_APPLY_CD
			   AND M.DIM_MEASURE_TP = S.DIM_MEASURE_TP
			  ;


				DELETE FROM TEMP_AD_USER_PREF;


        /*****************************************************************************************************/


    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001'; 

EXCEPTION WHEN OTHERS THEN  --  e_products_invalid    
    IF(SQLCODE = -20001)
    THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
    --SP_COMM_RAISE_ERR();              
        RAISE;
    END IF; 

END;
/

