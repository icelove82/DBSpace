create PROCEDURE                "SP_UI_DP_00_CM_CD_Q1" (       
                                            p_GRP_CD 	    IN 	VARCHAR2 :=''  
                                          , p_TYPE       	IN 	VARCHAR2 :=''   -- ALL or Other value
                                          , pRESULT         OUT SYS_REFCURSOR ) IS 

/*
    TB_AD_COMN_CODE 
    HISTORY ()
    - 2019.01.24 /  :Interfaced YN, Currency code
                 /  : MODULE_TP    
*/
BEGIN
    IF p_GRP_CD = 'MODULE_TP'
    THEN
          OPEN pRESULT
           FOR
        SELECT NULL           AS ID
             , NULL           AS CD 
             , UPPER(P_TYPE)  AS CD_NM
             , 0              AS SEQ 
             , 'ALL' AS ALL_YN
          FROM DUAL     
         WHERE UPPER(p_TYPE) = 'ALL'
        UNION
        SELECT B.ID          AS ID
              ,B.COMN_CD     AS CD
              ,TO_CHAR(B.COMN_CD_NM)  AS CD_NM
              ,CASE B.COMN_CD WHEN 'DP' THEN 1 ELSE SEQ  END  AS SEQ
              , P_TYPE AS ALL_YN
        FROM TB_AD_COMN_GRP A
           INNER JOIN
           TB_AD_COMN_CODE B
          ON (A.ID = B.SRC_ID)
         WHERE 1=1
           AND A.GRP_CD = 'MODULE_TP'
           AND (B.COMN_CD = 'DP'
             OR B.COMN_CD = 'SRP'
             OR B.COMN_CD = 'BF'
             OR B.COMN_CD = 'CM'
               )
         ORDER BY SEQ;
ELSIF p_GRP_CD = 'ITEM_TYPE'
	THEN
          OPEN pRESULT
           FOR    
		SELECT	A.ID					AS ID
			,	A.ITEM_TP				AS CD
			,	A.CONVN_NM				AS CD_NM
		FROM	TB_CM_ITEM_TYPE A 
        ;        
ELSIF p_GRP_CD = 'UOM'
	THEN
          OPEN pRESULT
           FOR    
	SELECT	A.ID		            AS ID,
			A.UOM_CD	            AS CD,
			A.UOM_NM	            AS CD_NM
	FROM	TB_CM_UOM A
	WHERE	COALESCE(A.TIME_UOM_YN, 'N') = 'N'
    ;
    ELSE
	     		OPEN pRESULT
				FOR SELECT A.ID
					     , A.CD
					     , A.CD_NM
				FROM (
						SELECT  ''  AS ID
							  , CASE P_GRP_CD WHEN 'CURRENCY' 
                                              THEN UPPER(P_TYPE) 
                                              ELSE '' END  AS CD --CURRENCY CD TEXT-ID CD_NM TEXT
							  , UPPER(P_TYPE)  AS CD_NM
							  , 0   AS SEQ 
                              , 'ALL' AS ALL_YN
                         FROM DUAL     
                        WHERE UPPER(p_TYPE) = 'ALL'
						UNION ALL 
                        SELECT  CD.ID
							  , CD.COMN_CD  AS CD
							  , TO_CHAR(CD.COMN_CD_NM)  AS CD_NM
							  , CD.SEQ
                              , P_TYPE AS ALL_YN
						  FROM TB_AD_COMN_GRP CM
							  , TB_AD_COMN_CODE CD
						  WHERE CM.ID = CD.SRC_ID
						   AND CM.GRP_CD = p_GRP_CD
						) A
				ORDER BY A.SEQ ASC, A.CD ASC
                ;
    END IF;
END;
/

