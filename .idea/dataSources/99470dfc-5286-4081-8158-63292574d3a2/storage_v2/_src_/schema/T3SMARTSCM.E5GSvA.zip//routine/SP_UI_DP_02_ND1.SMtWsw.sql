create PROCEDURE                SP_UI_DP_02_ND1 (
    P_ID                IN VARCHAR2     := ''
  , P_USER_ID           IN VARCHAR2     := ''
  , P_RT_ROLLBACK_FLAG  OUT VARCHAR2     
  , P_RT_MSG            OUT VARCHAR2                                         
)
IS
    P_ERR_STATUS INT := 0;
    P_ERR_MSG VARCHAR2(4000):='';
    P_LV_LEAF_YN		CHAR(1);
    P_ACCOUNT_LV_YN	CHAR(1);
    P_LV_TP_ID			CHAR(32);

BEGIN
	SELECT COUNT(1) INTO P_ERR_STATUS
	  FROM TB_CM_LEVEL_MGMT 
	 WHERE LEAF_YN = 'Y' 
	   AND ID = P_ID
	   ;
	IF (P_ERR_STATUS > 0 )
	THEN
		P_ERR_MSG := 'MSG_5052';	-- The lowest level cannot be deleted.
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
	END IF
    ;
/**********************************************************************************************
-- LEAF_YN, LV_LEAF_YN UPDATE
-- Config에서 레벨 타입이 새로 생기면, LEAF로 최하위 레벨을 만들어줘야 한다.
-- LEAF LEVEL이 삭제되면 다른 레벨을 LEAF LEVEL로 만들어줘야 한다
**********************************************************************************************/

SELECT LV_LEAF_YN, ACCOUNT_LV_YN, LV_TP_ID 
      INTO P_LV_LEAF_YN, P_ACCOUNT_LV_YN, P_LV_TP_ID
 FROM TB_CM_LEVEL_MGMT
WHERE ID = P_ID 
;
IF P_LV_LEAF_YN = 'Y'
	THEN
     UPDATE TB_CM_LEVEL_MGMT 
        SET LV_LEAF_YN = 'Y' 	
			WHERE ID = (SELECT ID 
                         FROM (
                            SELECT LV.ID, LV.LV_CD, SEQ, ROW_NUMBER() OVER (ORDER BY LV.SEQ DESC) AS SEQ_NUM 
                             FROM TB_CM_LEVEL_MGMT LV
                             WHERE COALESCE(LV.DEL_YN,'N') = 'N'
                               AND COALESCE(LV.ACTV_YN, 'N') = 'Y'
                               AND COALESCE(ACCOUNT_LV_YN, 'N') = P_ACCOUNT_LV_YN
                               AND COALESCE(LEAF_YN,'N') = 'N'	
                               AND LV_TP_ID = P_LV_TP_ID
                               AND LV.ID != P_ID            
                                ) A 
                        WHERE SEQ_NUM = 1) 
                        ;
	 END IF;


/***********************************************************************************************
	-- Main 
 **********************************************************************************************/   
        DELETE FROM TB_CM_LEVEL_MGMT WHERE ID = P_ID
        ;
    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0002';  --

EXCEPTION WHEN OTHERS THEN  --  e_products_invalid    
    IF(SQLCODE = -20001) THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
        P_ERR_MSG := SQLERRM;
    ELSE
    --SP_COMM_RAISE_ERR();
        RAISE;
    END IF; 
END;
/

