create PROCEDURE                "SP_UI_BF_15_Q1" (
    pRESULT OUT SYS_REFCURSOR
)
IS 

--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
/*
    BF Control board master
*/
BEGIN
    OPEN pRESULT
    FOR
    SELECT ID
         , ENGINE_TP_CD
         , DESCRIP
         , SEQ
         , BF_DIST_RULE_CD
         , INPUT_HORIZ
         , INPUT_BUKT_CD
         , TARGET_HORIZ
         , TARGET_BUKT_CD
         , SALES_LV_CD
         , ITEM_LV_CD
         , VAL_TP
         , ATTR_01
         , ATTR_02
         , ATTR_03
         , ATTR_04
         , ATTR_05
         , ATTR_06
         , ATTR_07
         , ATTR_08
         , ATTR_09
         , ATTR_10
         , CREATE_BY
         , CREATE_DTTM
         , MODIFY_BY
         , MODIFY_DTTM
      FROM TB_BF_CONTROL_BOARD_MST
     ORDER BY SEQ;
END;
/

