create PROCEDURE                "SP_UI_DP_04_Q1" (
    p_CUST_CD IN VARCHAR2 := ''
  , p_CUST_NM IN VARCHAR2 := ''
  , pRESULT       OUT SYS_REFCURSOR
) IS 


BEGIN

    OPEN pRESULT
    FOR
    SELECT
           C.ID             AS ID
          ,C.CUST_CD        AS CUST_CD    
          ,C.CUST_NM        AS CUST_NM    
          ,C.COUNTRY_ID     AS COUNTRY_ID    
          ,B.CONF_CD        AS COUNTRY_CD
          ,C.ADDR           AS ADDR        
          ,C.CREATE_BY      AS CREATE_BY    
          ,C.CREATE_DTTM    AS CREATE_DTTM
          ,C.MODIFY_BY      AS MODIFY_BY    
          ,C.MODIFY_DTTM    AS MODIFY_DTTM   
      FROM TB_CM_CUSTOMER C 
           LEFT OUTER JOIN
           TB_CM_COMM_CONFIG B 
        ON (C.COUNTRY_ID = B.ID)
     WHERE 1=1
       AND ( REGEXP_LIKE (UPPER(C.CUST_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_CUST_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
             OR p_CUST_CD IS NULL
           )
       AND ( REGEXP_LIKE (UPPER(C.CUST_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_CUST_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\['))
             OR p_CUST_NM IS NULL
           )
    ;
END;
/

