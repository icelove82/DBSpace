create PROCEDURE SP_UI_DP_CURRENCY_COMBO
(
	p_VER_ID    VARCHAR2
  , pRESULT     OUT SYS_REFCURSOR
)
IS 

/*****************************************************************************
Title : SP_UI_DP_CURRENCY_COMBO
최초 작성자 : 이고은
최초 생성일 : 2017.07.31
 
설명 
 - SP_UI_DP_CURRENCY_COMBO
  
History (수정일자 / 수정자 / 수정내용)
- 2017.07.31 / 이고은 / 최초 작성
- 2019.06.19 / 김소희 / DEL_YN 추가 
- 2020.12.23 / 민경훈 / MSSQL -> ORACLE
*****************************************************************************/

BEGIN

    OPEN pRESULT FOR
    SELECT 'LOCAL' AS CD
         , 'Local Currency' AS CD_NM 
         , '0' AS ID
      FROM DUAL
    UNION ALL
    SELECT	B.COMN_CD AS CD, TO_CHAR(B.COMN_CD_NM) AS CD_NM, B.ID 
      FROM	TB_AD_COMN_GRP A 
            INNER JOIN 
            TB_AD_COMN_CODE B  
         ON A.ID = B.SRC_ID
            INNER JOIN 
            (     SELECT DISTINCT(TO_CURCY_CD_ID) AS TO_CURCY_CD_ID
                    FROM TB_DP_EXCHANGE_RATE 
                   WHERE CURCY_TP_ID =(SELECT CURCY_TP_ID  FROM TB_DP_CONTROL_BOARD_VER_MST WHERE VER_ID = p_VER_ID)
                    ) C
            ON B.ID = C.TO_CURCY_CD_ID
    WHERE	A.GRP_CD = 'CURRENCY'
      AND   COALESCE(A.DEL_YN, 'N') = 'N'
      AND   COALESCE(B.DEL_YN, 'N') = 'N'
    ;

END;
/

