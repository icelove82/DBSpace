create PROCEDURE "SP_BF_REVERT_REPLACE_OUTLIER"  (
      p_VER_CD				VARCHAR2
    ) 
IS

BEGIN
	UPDATE TB_BF_RT rt
		SET RT.qty = (SELECT QTY FROM TB_BF_RT_POST fo WHERE rt.ver_cd = fo.ver_cd and rt.item_cd = fo.item_cd and rt.account_cd = fo.account_cd and rt.base_date = fo.base_date and rt.engine_tp_cd = fo.engine_tp_cd and fo.type_cd = 'FCST_OUTLIER' )
	WHERE 1=1
	  AND VER_CD = p_VER_CD 
	  AND EXISTS (
			SELECT 1 FROM TB_BF_RT_POST fo 
			WHERE rt.ver_cd = fo.ver_cd and rt.item_cd = fo.item_cd and rt.account_cd = fo.account_cd and rt.base_date = fo.base_date and rt.engine_tp_cd = fo.engine_tp_cd and fo.type_cd = 'FCST_OUTLIER'
	);
	
	DELETE FROM TB_BF_RT_POST
	WHERE VER_CD = p_VER_CD 
	  AND TYPE_CD = 'FCST_OUTLIER';
END;
/

