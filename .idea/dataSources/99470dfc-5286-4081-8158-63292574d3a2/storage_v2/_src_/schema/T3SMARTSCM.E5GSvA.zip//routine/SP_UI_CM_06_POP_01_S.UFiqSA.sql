create PROCEDURE SP_UI_CM_06_POP_01_S (
     P_WRK_TYPE					IN CHAR := ''
	,P_BOD_MAP_ID				IN VARCHAR2 := ''
	,P_BOD_TP_ID				IN CHAR := '' 
	,P_CONSUME_LOCAT_ID			IN CHAR := ''
	,P_SUPPLY_LOCAT_ID			IN CHAR := ''
	,P_SRCING_POLICY_ID	        IN CHAR := ''
	,P_SRCING_RULE		        IN NUMBER := ''
	,P_ACTV_YN					IN CHAR := ''
	,P_USER_ID					IN VARCHAR2:= ''
	,P_RT_ROLLBACK_FLAG         OUT VARCHAR2
	,P_RT_MSG                   OUT VARCHAR2
)
IS
	P_ERR_STATUS NUMBER := 0;
    P_ERR_MSG   VARCHAR2(4000) := '';
    V_BOD_TP    VARCHAR2(30) := '';

BEGIN
    SELECT COMN_CD INTO V_BOD_TP FROM  TB_AD_COMN_CODE WHERE ID = P_BOD_TP_ID;
    
    P_ERR_MSG := 'MSG_0006';
    IF NVL(P_CONSUME_LOCAT_ID, ' ') = ' ' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;
    IF NVL(P_SUPPLY_LOCAT_ID, ' ') = ' '  THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;

	IF P_WRK_TYPE = 'SAVE'
    THEN
        MERGE INTO TB_CM_LOC_BOD_MAP B 
        USING (SELECT P_BOD_MAP_ID AS ID FROM DUAL) A
           ON (B.ID = P_BOD_MAP_ID)
        WHEN MATCHED THEN
            UPDATE 
               SET	
                   SRCING_POLICY_ID	    = P_SRCING_POLICY_ID
                 , SRCING_RULE		    = P_SRCING_RULE
                 , ACTV_YN				= P_ACTV_YN
                 , MODIFY_BY			= P_USER_ID
                 , MODIFY_DTTM			= SYSDATE
        WHEN NOT MATCHED THEN
            INSERT (
                ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
                ,BOD_TP_ID
                ,CONSUME_LOCAT_ID
                ,SRCING_POLICY_ID	
                ,SUPPLY_LOCAT_ID			
                ,SRCING_RULE		
                ,ACTV_YN					
                )
            VALUES 
                (
                TO_SINGLE_BYTE(SYS_GUID()), P_USER_ID, SYSDATE, NULL, NULL
                ,P_BOD_TP_ID
                ,P_CONSUME_LOCAT_ID
                ,P_SRCING_POLICY_ID
                ,P_SUPPLY_LOCAT_ID
                ,P_SRCING_RULE
                ,P_ACTV_YN
            );
	
	    P_RT_MSG := 'MSG_0001';
        
    ELSIF P_WRK_TYPE = 'DELETE'
    THEN
        DELETE FROM TB_CM_LOC_BOD_MAP
        WHERE ID = P_BOD_MAP_ID;

        P_RT_MSG := 'MSG_0002';
	END IF;
    
    P_RT_ROLLBACK_FLAG := 'true';

EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN 
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;
      ELSE
          RAISE;
      END IF;
END;

/

