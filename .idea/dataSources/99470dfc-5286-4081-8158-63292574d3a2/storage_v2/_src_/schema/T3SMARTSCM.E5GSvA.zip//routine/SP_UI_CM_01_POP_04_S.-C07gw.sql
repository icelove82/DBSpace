create PROCEDURE "SP_UI_CM_01_POP_04_S" (
	 P_ID                   IN VARCHAR2 := ''
	,P_CONF_NM	            IN VARCHAR2 := ''
	,P_ACTV_YN	            IN VARCHAR2 := ''
    ,P_USER_ID	            IN VARCHAR2 := ''
    ,P_WRK_TYPE	            IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG     OUT VARCHAR2 
    ,P_RT_MSG               OUT VARCHAR2
)
IS

    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';

BEGIN
	
	IF P_WRK_TYPE = 'SAVE'
	THEN
	
        P_ERR_MSG := 'MSG_0005'; --'？？？？ ？？ ？？？？？？ ？？？？？？？ ？？？ ？？？？？？？？.'
		   SELECT COUNT(*) INTO P_ERR_STATUS
                FROM TB_CM_COMM_CONFIG A
            WHERE 1=1
              AND A.ID <> P_ID
              AND A.CONF_NM = P_CONF_NM;
		   IF P_ERR_STATUS > 0 THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
           END IF;

           
	    MERGE INTO TB_CM_COMM_CONFIG B 
			USING (SELECT P_ID AS ID FROM DUAL) A
					ON  (B.ID = A.ID)
	
			WHEN MATCHED THEN
	
				UPDATE 
				   SET ACTV_YN	    = P_ACTV_YN
					 , MODIFY_BY	= P_USER_ID
					 , MODIFY_DTTM	= SYSDATE()
	
			WHEN NOT MATCHED THEN			
				INSERT (
					-- ？？？？？？
					ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
					-- ？？？？？？？？
					, CONF_ID
					, CONF_GRP_CD
					, CONF_CD
					, CONF_NM
					, DEFAT_VAL
					, ACTV_YN
					, DESCRIP
					)
				VALUES 
			  	    (
					-- ？？？？？？
					TO_SINGLE_BYTE(SYS_GUID()), P_USER_ID, SYSDATE(), P_USER_ID, SYSDATE()
					-- ？？？？？？？？
					, (SELECT DISTINCT CONF_ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'CM_COUNTRY')
					, 'CM_COUNTRY'
					, P_CONF_NM
					, P_CONF_NM
					, 'N'
					, P_ACTV_YN
					, P_CONF_NM
	
				);
	
        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';  --？？？？ ？？？？？？？？.
	
	
	ELSIF P_WRK_TYPE = 'DELETE'
	THEN
	    DELETE FROM TB_CM_COMM_CONFIG
	        WHERE ID = P_ID;
	
	        P_RT_ROLLBACK_FLAG := 'true';
	        P_RT_MSG := 'MSG_0002';
	
	END IF;

	
    EXCEPTION
    WHEN OTHERS THEN
        IF(SQLCODE = -20012)
          THEN
        	  P_RT_ROLLBACK_FLAG := 'false';
              P_RT_MSG := P_ERR_MSG;   
          ELSE
              RAISE;
          END IF; 

END;

/

