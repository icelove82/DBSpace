create PROCEDURE                  "SP_UI_BF_05_Q1" 
(
    p_FROM_DATE    DATE
  , p_TO_DATE      DATE
  , p_ITEM_CD      VARCHAR2  
  , p_ITEM_NM      VARCHAR2  
  , p_ACCOUNT_CD   VARCHAR2  
  , p_ACCOUNT_NM   VARCHAR2  
  , p_STATUS       VARCHAR2
  , pRESULT OUT SYS_REFCURSOR
)
IS 
--SET NOCOUNT ON
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
/*  
    Load Correction of Actual Sales

    History (date / writer / comment)
    -- 2020.02.03 / kim sohee / Status로 구분 되어있던 IF문을 CASE WHEN 으로 변경 
                              / CORRECTION_COMMENT 를 Code로 보여주게 변경  
*/
BEGIN
    OPEN pRESULT
    FOR
    WITH DP_WK AS (
    SELECT D.DP_WK
         , MIN(D.DAT) AS MON_DT
         , TO_CHAR(MIN(D.DAT),'D') WK_NM
      FROM TB_CM_CALENDAR D
     WHERE D.DAT BETWEEN TO_DATE(p_FROM_DATE)-7 AND TO_DATE(p_TO_DATE)
     GROUP BY D.DP_WK
     HAVING TO_CHAR(MIN(D.DAT),'D') = 2
    )
    SELECT T.ID
         , M.ACCOUNT_CD
         , M.ACCOUNT_NM
         , M.ITEM_CD
         , M.ITEM_NM
         , M.MON_DT AS BASE_DATE
         , NULL AS STATUS
         , M.QTY
         , M.QTY_CORRECTION
         , T.CORRECTION_COMMENT
         , T.MODIFY_BY
         , T.MODIFY_DTTM
      FROM (
           SELECT L.ACCOUNT_ID
                , A.ACCOUNT_CD AS ACCOUNT_CD
                , A.ACCOUNT_NM AS ACCOUNT_NM
                , L.ITEM_MST_ID
                , I.ITEM_CD AS ITEM_CD
                , I.ITEM_NM AS ITEM_NM
                , MIN(L.BASE_DATE) AS MIN_DT
                , SUM(L.QTY) AS QTY
                , SUM(L.QTY_CORRECTION) AS QTY_CORRECTION
                , W.DP_WK
                , W.MON_DT
             FROM TB_CM_ACTUAL_SALES L
                  INNER JOIN TB_CM_CALENDAR CAL ON L.BASE_DATE = CAL.DAT
                  INNER JOIN DP_WK W ON W.DP_WK = CAL.DP_WK
                  INNER JOIN TB_DP_ACCOUNT_MST A ON L.ACCOUNT_ID = A.ID
                  INNER JOIN TB_CM_ITEM_MST I ON L.ITEM_MST_ID = I.ID
                  INNER JOIN TB_CM_COMM_CONFIG C ON L.SO_STATUS_ID = C.ID --AND C.CONF_GRP_CD='DP_SO_STATUS'
            WHERE 1=1
                  AND ( REGEXP_LIKE (UPPER(A.ACCOUNT_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCOUNT_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                        OR p_ACCOUNT_CD IS NULL
                      )
                  AND ( REGEXP_LIKE (UPPER(A.ACCOUNT_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ACCOUNT_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                        OR p_ACCOUNT_NM IS NULL 
                      )
                  AND ( REGEXP_LIKE (UPPER(I.ITEM_CD), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM_CD), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                        OR p_ITEM_CD IS NULL
                      )
                  AND ( REGEXP_LIKE (UPPER(I.ITEM_NM), REPLACE(REPLACE(REPLACE(REPLACE(UPPER(p_ITEM_NM), ')', '\)'), '(', '\('), ']', '\]'), '[', '\[')) 
                        OR p_ITEM_NM IS NULL
                      )
--                  AND (BASE_DATE BETWEEN p_FROM_DATE AND p_TO_DATE )
--                  OR p_STATUS IS null
--                  AND CASE WHEN p_STATUS = 'ALL' THEN 'ALL' 
--                           WHEN p_STATUS = '' THEN ''
--                           ELSE C.CONF_CD END = p_STATUS
            GROUP BY L.ITEM_MST_ID
                   , L.ACCOUNT_ID
                   , I.ITEM_CD
                   , I.ITEM_NM
                   , A.ACCOUNT_CD
                   , A.ACCOUNT_NM
                   , W.DP_WK
                   , W.MON_DT
          ) M
          CROSS APPLY (
                       SELECT Z.ID, Z.CORRECTION_COMMENT, Z.MODIFY_BY, Z.MODIFY_DTTM
                         FROM (
                              SELECT S.ID,NVL(R.CONF_CD, 'NN') AS CORRECTION_COMMENT, S.MODIFY_BY, S.MODIFY_DTTM
                                FROM TB_CM_ACTUAL_SALES S
                                     LEFT OUTER JOIN TB_CM_COMM_CONFIG R ON S.CORRECTION_COMMENT_ID = R.ID
                               WHERE M.ITEM_MST_ID = S.ITEM_MST_ID
                                 AND M.ACCOUNT_ID  = S.ACCOUNT_ID
                                 AND M.MIN_DT      = S.BASE_DATE
                               ORDER BY S.ID
                              ) Z
                         WHERE ROWNUM=1
                       ) T
    WHERE 1=1
      AND M.MON_DT BETWEEN p_FROM_DATE AND p_TO_DATE
    ORDER BY ITEM_CD, ACCOUNT_CD, MON_DT
    ;
END;
/

