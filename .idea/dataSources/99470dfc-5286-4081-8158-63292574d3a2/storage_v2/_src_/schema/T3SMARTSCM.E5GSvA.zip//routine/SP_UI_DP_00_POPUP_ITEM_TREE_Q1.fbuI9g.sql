create PROCEDURE                "SP_UI_DP_00_POPUP_ITEM_TREE_Q1" (
    p_EMP_NO	   VARCHAR2 := NULL
  , p_AUTH_TP_ID   CHAR     := NULL
  , p_ITEM_CD   IN VARCHAR2 := NULL
  , p_ITEM_NM   IN VARCHAR2 := NULL
  , P_ITEM_LV   IN VARCHAR2 := NULL
  , p_LV_TP_CD     VARCHAR2    := NULL
  , pRESULT     OUT SYS_REFCURSOR
) IS
                                                     
/*************************************************************************
      ITEM LEVEL  
    USED UI : UI_DP_POPUP_ITEM_TREE

    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 
    - 2021.12.13 / Kim sohee / get data by using DPD table (for performance)
************************************************************************/
    P_EMP_ID CHAR(32) := NULL;
    P_ITEM_CNT   INT;
    P_CNT        INT;
    V_ITEM_LV    VARCHAR2(50) := P_ITEM_LV;
    V_LV_TP_CD    VARCHAR2(100)   := COALESCE(p_LV_TP_CD, 'I');    
    
BEGIN

-- get Employee ID
    SELECT COUNT(ID)
      INTO P_CNT
      FROM TB_AD_USER
     WHERE USERNAME = P_EMP_NO;
    
    IF P_CNT != 0 THEN
        SELECT ID INTO P_EMP_ID
          FROM TB_AD_USER
         WHERE USERNAME = P_EMP_NO;
    END IF;

-- check the number of mapping data
    SELECT COUNT(*) INTO P_ITEM_CNT
      FROM (
        SELECT EMP_ID 
          FROM TB_DP_USER_ITEM_MAP
         WHERE EMP_ID = p_EMP_ID
           AND AUTH_TP_ID = p_AUTH_TP_ID
         UNION
        SELECT EMP_ID
          FROM TB_DP_USER_ITEM_ACCOUNT_MAP
         WHERE EMP_ID = p_EMP_ID
           AND AUTH_TP_ID = p_AUTH_TP_ID
      )
    ;
    IF(P_ITEM_CNT = 0)
    THEN
        P_EMP_ID := NULL;
    END IF;
-- convert null to top level
IF (P_ITEM_LV IS NULL)       
    THEN
    SELECT ITEM_LV_CD INTO V_ITEM_LV
      FROM TB_CM_ITEM_LEVEL_MGMT IL
           INNER JOIN 
           TB_CM_LEVEL_MGMT LV 
        ON IL.LV_MGMT_ID = LV.ID 
           INNER JOIN
           TB_CM_COMM_CONFIG CC
        ON LV.LV_TP_ID = CC.ID
       AND CC.CONF_CD = 'I'
     WHERE IL.PARENT_ITEM_LV_ID IS NULL		
       ;
    END IF
    ;

/*****************************************************************
    MAIN PROCEDURE
*****************************************************************/
    IF (P_EMP_ID IS NULL OR p_AUTH_TP_ID IS NULL)
	THEN
    	-- Case : mapping data is none, get all master data    
        OPEN pRESULT   
        FOR
        WITH ITEM_HIER
          AS (
            SELECT DESCENDANT_ID AS ID
              FROM TB_DPD_ITEM_HIER_CLOSURE 
             WHERE LEAF_YN = 'Y'
               AND ANCESTER_CD = V_ITEM_LV
               AND USE_YN = 'Y'
               AND LV_TP_CD = V_LV_TP_CD
            UNION
            SELECT V_ITEM_LV
              FROM DUAL
             WHERE P_ITEM_LV IS NULL
         )
        SELECT A.ID 
             , A.ITEM_CD
             , A.ITEM_NM
             , A.EOS  AS EOS      
             , A.RTS  AS RTS  
             , C.UOM_CD
             , C.UOM_NM
             , A.DESCRIP
             , A.PARENT_ITEM_LV_ID 
             , IL.ITEM_LV_CD   AS PARENT_ITEM_LV_CD
             , IL.ITEM_LV_NM   AS PARENT_ITEM_LV_NM
		  FROM TB_CM_ITEM_MST A
		       INNER JOIN    
               ITEM_HIER IH
            ON CASE WHEN P_ITEM_LV IS NULL THEN V_ITEM_LV ELSE A.ID END = IH.ID -- NULL 을 = 로 읽을 수 있나 오라클?
               INNER JOIN
               TB_CM_ITEM_LEVEL_MGMT IL
            ON A.PARENT_ITEM_LV_ID = IL.ID 
               LEFT OUTER JOIN
               TB_CM_UOM C
            ON A.UOM_ID = C.ID
           AND C.ACTV_YN = 'Y'	    
         WHERE 1=1 
		   AND COALESCE(A.DEL_YN,'N') = 'N'
		   AND A.DP_PLAN_YN = 'Y'
				AND A.DP_PLAN_YN = 'Y'
								AND  ('Y' = CASE WHEN P_ITEM_CD = '' THEN 'Y'
								ELSE ( CASE WHEN UPPER(A.ITEM_CD)  LIKE '%' || UPPER(RTRIM(P_ITEM_CD)) || '%'	THEN 'Y' ELSE 'N' END) 
							END)
 				AND ('Y' = CASE WHEN P_ITEM_NM = '' THEN 'Y'
								ELSE ( CASE WHEN UPPER(A.ITEM_NM)  LIKE '%' || UPPER(RTRIM(P_ITEM_NM)) || '%'	THEN 'Y' ELSE 'N' END) 
							END)
		 ORDER BY IL.SEQ, IL.ITEM_LV_CD, A.ITEM_CD
		;
    ELSE
		-- Salesman Mapping (Only user mapping data)    
        OPEN pRESULT   
        FOR    
        WITH DP_LEVEL 
        AS (
            SELECT LV.ID
                 , LV.LEAF_YN
              FROM TB_CM_LEVEL_MGMT LV
                   INNER JOIN 
                   TB_CM_COMM_CONFIG CC
                ON LV.LV_TP_ID = CC.ID
             WHERE CC.CONF_CD = 'I'
			   AND COALESCE(LV.ACCOUNT_LV_YN,'N') = 'N'
			   AND COALESCE(LV.SALES_LV_YN  ,'N')= 'N'
			   AND LV.ACTV_YN = 'Y'
			   AND COALESCE(LV.DEL_YN,'N') = 'N'
        ), USER_MAV_ITEM_LV
		  AS (  SELECT DISTINCT ITEM_LV_ID AS ID
				  FROM TB_DP_USER_ITEM_MAP M	    
					   INNER JOIN 
					   DP_LEVEL L
					ON M.LV_MGMT_ID = L.ID 
				   AND L.LEAF_YN = 'N'
				 WHERE 1=1 
				   AND AUTH_TP_ID = P_AUTH_TP_ID
				   AND EMP_ID = P_EMP_ID
				   AND ACTV_YN = 'Y'		 
		), USER_MAP_ITEM
		AS (
			SELECT DISTINCT ITEM_MST_ID AS ITEM_ID 
			  FROM TB_DP_USER_ITEM_MAP M
			       INNER JOIN 
				   DP_LEVEL L
				ON M.LV_MGMT_ID = L.ID 
			   AND L.LEAF_YN = 'Y'
			 WHERE EMP_ID = P_EMP_ID
			   AND M.AUTH_TP_ID = P_AUTH_TP_ID
			   AND M.ACTV_YN = 'Y'
			UNION
			SELECT DISTINCT ITEM_MST_ID
			  FROM TB_DP_USER_ITEM_ACCOUNT_MAP 
			 WHERE EMP_ID = P_EMP_ID
			   AND AUTH_TP_ID = P_AUTH_TP_ID 
			   AND ACTV_YN = 'Y'
			UNION
			SELECT IH.DESCENDANT_ID
			  FROM USER_MAV_ITEM_LV IM
				   INNER JOIN 
				   TB_DPD_ITEM_HIER_CLOSURE IH
				ON IM.ID = IH.ANCESTER_ID
			   AND USE_YN = 'Y' 
			   AND IH.LEAF_YN = 'Y'
		), ITEM_HIER
		  AS (  SELECT DESCENDANT_ID AS ID 
				  FROM TB_DPD_ITEM_HIER_CLOSURE IH	
				 WHERE LEAF_YN = 'Y'
				   AND ANCESTER_CD = V_ITEM_LV
				   AND USE_YN = 'Y'
				   AND LV_TP_CD = 'I'
				UNION
				SELECT V_ITEM_LV
                  FROM DUAL 
				 WHERE P_ITEM_LV IS NULL 
			 )
 		SELECT IM.ID
 		     , IM.ITEM_CD
 		     , IM.ITEM_NM
 		     , IM.EOS
 		     , IM.RTS
 		     , UM.UOM_CD
 		     , UM.UOM_NM
 		     , IM.DESCRIP
 		     , IM.PARENT_ITEM_LV_ID
 		     , IL.ITEM_LV_CD AS PARENT_ITEM_LV_CD
 		     , IL.ITEM_LV_NM AS PARENT_ITEM_LV_NM
		  FROM USER_MAP_ITEM FI
			   INNER JOIN
			   ITEM_HIER IH
            ON CASE WHEN P_ITEM_LV IS NULL THEN V_ITEM_LV ELSE FI.ITEM_ID END = IH.ID -- NULL 을 = 로 읽을 수 있나 오라클?
               INNER JOIN
			   TB_CM_ITEM_MST IM
			ON IM.ID = FI.ITEM_ID
			   LEFT OUTER JOIN
			   TB_CM_UOM UM
			ON IM.UOM_ID = UM.ID
			   LEFT OUTER JOIN
			   TB_CM_ITEM_LEVEL_MGMT IL
			ON IL.ID = IM.PARENT_ITEM_LV_ID
				 WHERE ('Y' = CASE WHEN P_ITEM_CD IS NULL THEN 'Y'
									ELSE ( CASE WHEN UPPER(IM.ITEM_CD)  LIKE '%' || UPPER(RTRIM(P_ITEM_CD)) || '%'	THEN 'Y' ELSE 'N' END) 
								END)
 					AND ('Y' = CASE WHEN P_ITEM_NM IS NULL THEN 'Y'
									ELSE ( CASE WHEN UPPER(IM.ITEM_NM)  LIKE '%' || UPPER(RTRIM(P_ITEM_NM)) || '%'	THEN 'Y' ELSE 'N' END) 
								END)
		 ORDER BY IL.SEQ, IL.ITEM_LV_CD, IM.ITEM_CD
        ;
    END IF;
END
;
/

