create PROCEDURE  "SP_UI_DP_00_MAKE_USER_GROUP" (
     P_USER_ID        CHAR
    ,P_USER_NAME      VARCHAR2
    ,P_AUTH_TP_ID     CHAR
) AS
     P_GRP_ID CHAR(32);
     IF_CNT   INT;
BEGIN

    -- Insert User Group
    SELECT ID INTO P_GRP_ID
      FROM TB_AD_GROUP
     WHERE GRP_CD = (SELECT LV_CD 
                       FROM TB_CM_LEVEL_MGMT 
                      WHERE ID = P_AUTH_TP_ID
                     )
     ;
     SELECT COUNT(*) INTO IF_CNT
       FROM TB_AD_USER_GROUP
      WHERE USER_ID = P_USER_ID 
        AND GRP_ID = P_GRP_ID
          ;

    IF (IF_CNT = 0)
        THEN
           INSERT INTO TB_AD_USER_GROUP 
                       ( ID
                       , USER_ID
                       , GRP_ID
                       , PREF_DEFAULT_YN
                       , CREATE_BY
                       , CREATE_DTTM
                       )
            VALUES ( TO_SINGLE_BYTE(SYS_GUID())
                    ,P_USER_ID
                    ,P_GRP_ID
                    ,'N'
                    ,P_USER_NAME
                    , SYSDATE 
                    )
                    ;
    END IF
    ;

END
;
/

