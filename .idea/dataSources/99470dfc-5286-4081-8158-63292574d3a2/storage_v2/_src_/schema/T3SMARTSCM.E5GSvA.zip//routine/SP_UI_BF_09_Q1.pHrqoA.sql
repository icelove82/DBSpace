create PROCEDURE                "SP_UI_BF_09_Q1" (
    p_DESCRIP  VARCHAR2 := '',
    p_ACTV_YN  VARCHAR2 := '',
    p_DEL_YN   VARCHAR2 := '',
    pRESULT    OUT SYS_REFCURSOR
)

IS
--
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
--SET NOCOUNT ON
/*
    Model Management
    
*/
BEGIN
    OPEN pRESULT
    FOR
    SELECT
            CASE EXTEND_YN WHEN 'Y' THEN 'default'
                           WHEN 'N' THEN 'extend' END AS TYPE,
            FACTOR_CD,
            DESCRIP,
            COL_NM,
            CREATE_BY,
            CREATE_DTTM AS CREATE_DTTM,
            ACTV_YN,
            DEL_YN
      FROM  TB_BF_FACTOR_MGMT
     WHERE  DESCRIP LIKE '%' || p_DESCRIP || '%'
       AND  CASE WHEN p_ACTV_YN = 'A' THEN 'A' ELSE ACTV_YN END = p_ACTV_YN
       AND  CASE WHEN p_DEL_YN = 'A' THEN 'A' ELSE DEL_YN END = p_DEL_YN
  ORDER BY  TYPE ASC, FACTOR_CD ASC;
END;
/

