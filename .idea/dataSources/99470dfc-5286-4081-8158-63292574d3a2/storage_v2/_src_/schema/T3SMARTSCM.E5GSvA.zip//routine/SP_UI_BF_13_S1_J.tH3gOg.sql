create PROCEDURE                "SP_UI_BF_13_S1_J" (
    P_JSON			CLOB
    , P_USER_ID         VARCHAR2
    , P_RT_ROLLBACK_FLAG    OUT VARCHAR2
    , P_RT_MSG              OUT VARCHAR2
)  
IS
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
    P_ERR_STATUS    NUMBER          := 0;
    P_ERR_MSG       VARCHAR2(4000)  :='';

BEGIN
    

        MERGE INTO TB_BF_ITEM_ACCOUNT_MODEL_MAP TAR
        USING ( 
				SELECT 
				      ITEM_CD
				    , ACCOUNT_CD
				    , CASE WHEN ACTV_YN = 'true' THEN 'Y' ELSE 'N' END AS ACTV_YN
					, P_USER_ID      AS USER_ID
				FROM  json_table( P_JSON , '$[*]'  
					                COLUMNS ( 
					                         ITEM_CD PATH '$.ITEM_CD'  
					                        , ACCOUNT_CD PATH '$.ACCOUNT_CD'
					                        , ACTV_YN PATH '$.ACTV_YN'
					                        )  
						               )
              ) SRC
        ON    (TAR.ITEM_CD = SRC.ITEM_CD AND TAR.ACCOUNT_CD = SRC.ACCOUNT_CD)
        WHEN MATCHED THEN
             UPDATE 
               SET   TAR.ACTV_YN        = SRC.ACTV_YN
                    ,TAR.MODIFY_BY      = SRC.USER_ID
                    ,TAR.MODIFY_DTTM    = SYSDATE
        WHEN NOT MATCHED THEN 
             INSERT (
                      ID        
                    , ACCOUNT_CD
                    , ITEM_CD
                    , ACTV_YN
                    , CREATE_BY 
                    , CREATE_DTTM
                    ) 
             VALUES (
                     RAWTOHEX(SYS_GUID()) 
                    ,SRC.ACCOUNT_CD
                    ,SRC.ITEM_CD
                    ,SRC.ACTV_YN
                    ,SRC.USER_ID
                    ,SYSDATE
                    ) 
        ;   
    

    P_RT_ROLLBACK_FLAG  := 'true';
    P_RT_MSG            := 'MSG_0001';  --저장 되었습니다.

EXCEPTION WHEN OTHERS THEN
    IF (SQLCODE = -20001) THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
    ELSE
        RAISE;
--              EXEC SP_COMM_RAISE_ERR
    END IF;
END;
/

