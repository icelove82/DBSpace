create PROCEDURE                SP_UI_DP_07_S1_J (     
                                       P_JSON			    CLOB
                                     , P_USER_ID            VARCHAR2
                                     , P_RT_ROLLBACK_FLAG   OUT VARCHAR2
                                     , P_RT_MSG             OUT VARCHAR2						        
	  								   ) 
IS
    P_ERR_STATUS    NUMBER          := 0;
    P_ERR_MSG       VARCHAR2(4000)  :='';
/********************************************************************************************************************************
    Title : SP_UI_DP_07_S1_J

	Exchange Rate Save (Json Param Bulk Insert)
 
설명 
  - Exchange Rate
  - OPENJSON : https://docs.oracle.com/database/121/SQLRF/functions092.htm#SQLRF56973

 
History (수정일자 / 수정자 / 수정내용)
- 2022.01.11 / kim sohee / json bulk insert draft

*********************************************************************************************************************************/    
BEGIN
/*
    BEGIN
        SELECT ID INTO p_FROM_CURCY_CD_ID 
          FROM TB_AD_COMN_CODE 
          WHERE 1=1
            AND COMN_CD = p_FROM_CURCY_CD
            AND NVL(DEL_YN, 'N') = 'N'
            AND USE_YN = 'Y'
          ;
        SELECT ID INTO p_TO_CURCY_CD_ID 
          FROM TB_AD_COMN_CODE 
          WHERE 1=1
            AND COMN_CD = p_TO_CURCY_CD
            AND NVL(DEL_YN,'N') = 'N'
            AND USE_YN = 'Y'            
            ;

        SELECT ID INTO p_CURCY_TP_ID FROM TB_CM_COMM_CONFIG 
        WHERE CONF_CD = p_CURCY_TP_CD AND CONF_GRP_CD = 'DP_CURRENCY_TYPE';    

    EXCEPTION
    WHEN NO_DATA_FOUND  THEN
          P_ERR_MSG := 'MSG_0006';
    WHEN OTHERS THEN    
        RAISE;
    END;

-------------- VALIDATION ------------------------------------------------- 
     IF (p_FROM_CURCY_CD_ID IS NULL)
        THEN
          P_ERR_MSG := 'MSG_0006';  
          RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); -- RAISERROR (P_ERR_MSG,12, 1);                       
        END IF;

     IF (p_TO_CURCY_CD_ID IS NULL)
        THEN
          P_ERR_MSG := 'MSG_0006';   
          RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); -- RAISERROR (P_ERR_MSG,12, 1);                       
        END IF;   

     IF (p_BASE_DATE IS NULL)
        THEN
          P_ERR_MSG := 'MSG_0006';   
          RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); -- RAISERROR (P_ERR_MSG,12, 1);                       
        END IF; 

     IF (p_EXCHANGE_RATE IS NULL)
        THEN
          P_ERR_MSG := 'MSG_0006';  
          RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); -- RAISERROR (P_ERR_MSG,12, 1);                       
        END IF;

     IF (p_CURCY_TP_ID IS NULL)
        THEN
          P_ERR_MSG := 'MSG_0006';  
          RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); -- RAISERROR (P_ERR_MSG,12, 1);                       
        END IF;

     IF (p_FROM_CURCY_CD_ID = p_TO_CURCY_CD_ID)
        THEN
          P_ERR_MSG := 'MSG_5100';  
          RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); -- RAISERROR (P_ERR_MSG,12, 1);                    
        END IF;
------------------------------------------------------------------------------------------------      
*/

            MERGE INTO TB_DP_EXCHANGE_RATE TGT
                USING ( 
                      WITH CURRENCY
                        AS (   SELECT C.ID, C.COMN_CD
                                 FROM TB_AD_COMN_CODE C
                                      INNER JOIN 
                                      TB_AD_COMN_GRP G 
                                   ON C.SRC_ID = G.ID 
                               WHERE G.GRP_CD = 'CURRENCY'		
                            )                
                        SELECT  M.ID				  
							   ,F.ID				 AS FROM_CURCY_CD_ID
							   ,T.ID				 AS TO_CURCY_CD_ID
							   ,M.BASE_DATE		     AS BASE_DATE
							   ,M.EXCHANGE_RATE	     AS EXCHANGE_RATE
							   ,C.ID				 AS CURCY_TP_ID	
							   --,M.ROW_STATUS		
                               ,P_USER_ID             AS USER_ID 
                          FROM JSON_TABLE ( P_JSON,  '$[*]'  
                                      COLUMNS (   ID				PATH	'$.ID'
                                                , FROM_CURCY_CD		PATH	'$.FROM_CURCY_CD'
                                                , TO_CURCY_CD		PATH	'$.TO_CURCY_CD'
                                                , BASE_DATE			DATE PATH	'$.BASE_DATE'
                                                , EXCHANGE_RATE		PATH	'$.EXCHANGE_RATE'
                                                , CURCY_TP_CD		PATH	'$.CURCY_TP_CD'
                                                --, ROW_STATUS		PATH	'$.ROW_STATUS'
						                        )  
                                ) M
                                INNER JOIN
                                CURRENCY F
                             ON M.FROM_CURCY_CD = F.COMN_CD
                                INNER JOIN 
                                CURRENCY T
                             ON M.TO_CURCY_CD = T.COMN_CD 
                                INNER JOIN 
                                TB_CM_COMM_CONFIG C
                             ON M.CURCY_TP_CD = C.CONF_CD
                            AND C.CONF_GRP_CD = 'DP_CURRENCY_TYPE'                                
                        ) SRC 
                    ON ( TGT.FROM_CURCY_CD_ID  = SRC.FROM_CURCY_CD_ID 
                    AND TGT.TO_CURCY_CD_ID     = SRC.TO_CURCY_CD_ID 
                    AND TGT.BASE_DATE          = SRC.BASE_DATE 
                    AND TGT.CURCY_TP_ID        = SRC.CURCY_TP_ID)
        WHEN MATCHED THEN
             UPDATE 
               SET   TGT.EXCHANGE_RATE       	= SRC.EXCHANGE_RATE   
--                    ,TGT.UNIT_UOM_VAL    		= SRC.UNIT_UOM_VAL    
                    ,TGT.MODIFY_BY              = SRC.USER_ID       
                    ,TGT.MODIFY_DTTM            = SYSDATE
        WHEN NOT MATCHED THEN 
             INSERT (
                     ID               
                    ,FROM_CURCY_CD_ID
                    ,TO_CURCY_CD_ID  
                    ,BASE_DATE       
                    ,EXCHANGE_RATE   
                    ,UNIT_UOM_VAL
                    ,CURCY_TP_ID
                    ,CREATE_BY
                    ,CREATE_DTTM                            
                    ) 
             VALUES (
                     TO_SINGLE_BYTE(SYS_GUID())
                    ,SRC.FROM_CURCY_CD_ID   
                    ,SRC.TO_CURCY_CD_ID     
                    ,SRC.BASE_DATE          
                    ,SRC.EXCHANGE_RATE      
                    ,NULL
                    ,SRC.CURCY_TP_ID
                    ,SRC.USER_ID 
                    ,SYSDATE   
                    );    

	    P_RT_ROLLBACK_FLAG := 'true';
	    P_RT_MSG := 'MSG_0001';  
       /*  ============================================================================*/
       EXCEPTION
        WHEN OTHERS THEN  
              IF(SQLCODE = -20001)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                --SP_COMM_RAISE_ERR();              
                RAISE;
              END IF; 
 END;
/

