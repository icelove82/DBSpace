create PROCEDURE                "SP_UI_DP_18_POP_Q1" 
(
    p_TBL_NM      IN VARCHAR2 := ''
  , pRESULT       OUT SYS_REFCURSOR 
) 
IS 

BEGIN
    OPEN pRESULT          
    FOR 
    SELECT 
            TABLE_NAME
           ,COLUMN_NAME
    FROM ALL_TAB_COLUMNS
    WHERE 1=1
      AND OWNER IN (                                   
                        SELECT USERNAME
                          FROM user_users
                   )            
      AND TABLE_NAME = p_TBL_NM
    ORDER BY TABLE_NAME, COLUMN_NAME
    ;

END
;
/

