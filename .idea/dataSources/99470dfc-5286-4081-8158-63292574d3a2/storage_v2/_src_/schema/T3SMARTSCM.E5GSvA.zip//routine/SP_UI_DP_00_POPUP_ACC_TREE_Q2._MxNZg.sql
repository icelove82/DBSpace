create PROCEDURE                "SP_UI_DP_00_POPUP_ACC_TREE_Q2" (
    P_EMP_NO       VARCHAR2    := NULL
  , P_AUTH_TP_ID   CHAR        := NULL
  , P_SALES_LV     VARCHAR2    := NULL
  , p_SRP_LV_YN    CHAR        := NULL
  , p_LV_TP_CD     VARCHAR2    := NULL
  , pREESULT       OUT     SYS_REFCURSOR
) IS
/*************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 
    - 2021.12.13 / Kim sohee / get data by using DPD table (for performance)    
    - 2022.03.07 / Kim sohee / add a case : level type 
************************************************************************/
    P_EMP_ID    CHAR(32);
    p_CNT       INT;
    P_USER_ACCT_CNT INT := 0;
    P_MGR_SALES_CNT INT := 0; 
    V_LV_TP_CD    VARCHAR2(100)   := COALESCE(p_LV_TP_CD, 'S');    
    P_LV_TP_COL   VARCHAR2(100);

BEGIN
		SELECT ATTR_01 INTO P_LV_TP_COL
		  FROM TB_CM_COMM_CONFIG 
		 WHERE CONF_GRP_CD = 'DP_LV_TP' 
		   AND CONF_CD = p_LV_TP_CD
		  ;
-- get Employee ID    
    SELECT COUNT(ID)
      INTO P_CNT
      FROM TB_AD_USER
     WHERE USERNAME = P_EMP_NO;

    IF P_CNT != 0 THEN
        SELECT ID
          INTO P_EMP_ID
          FROM TB_AD_USER
         WHERE USERNAME = P_EMP_NO;
    END IF;

    --IF V_LV_TP_CD is null or V_LV_TP_CD = '' THEN 
    --    V_LV_TP_CD := 'S';
    --END IF;

-- check the number of mapping data
    SELECT COUNT(EMP_ID) INTO P_USER_ACCT_CNT
      FROM TB_DP_USER_ACCOUNT_MAP UA
           INNER JOIN
           TB_DP_ACCOUNT_MST AC
        ON AC.ID = UA.ACCOUNT_ID
       AND AC.DEL_YN != 'Y'
       AND AC.ACTV_YN = 'Y'
     WHERE AUTH_TP_ID = P_AUTH_TP_ID
       AND EMP_ID = P_EMP_ID
    ;
    SELECT P_USER_ACCT_CNT + COUNT(EMP_ID) INTO P_USER_ACCT_CNT
      FROM TB_DP_USER_ACCOUNT_MAP UA
           INNER JOIN
           TB_DP_SALES_LEVEL_MGMT SL
        ON SL.ID = UA.SALES_LV_ID
       AND SL.DEL_YN != 'Y'
       AND SL.ACTV_YN = 'Y'
     WHERE AUTH_TP_ID = P_AUTH_TP_ID
       AND EMP_ID = P_EMP_ID
    ;    
    SELECT P_USER_ACCT_CNT+COUNT(EMP_ID) INTO P_USER_ACCT_CNT
      FROM TB_DP_USER_ITEM_ACCOUNT_MAP UA
           INNER JOIN
           TB_DP_ACCOUNT_MST AC
        ON AC.ID = UA.ACCOUNT_ID
       AND AC.DEL_YN != 'Y'
       AND AC.ACTV_YN = 'Y'
     WHERE EMP_ID = P_EMP_ID
       AND AUTH_TP_ID = P_AUTH_TP_ID
    ;
-- Check the number of user sales mapping data
    SELECT COUNT(1) INTO P_MGR_SALES_CNT
      FROM TB_DP_SALES_AUTH_MAP SA
           INNER JOIN  
           TB_DP_SALES_LEVEL_MGMT SL 
        ON SA.SALES_LV_ID = SL.ID 
     WHERE SA.EMP_ID = P_EMP_ID
       AND SL.LV_MGMT_ID = p_AUTH_TP_ID
       AND SYSDATE BETWEEN COALESCE(STRT_DATE_AUTH,SYSDATE) AND COALESCE(END_DATE_AUTH, SYSDATE)
       ;    
/*********************************************************************************************************************************
    -- MAIN PROCEDURE
*********************************************************************************************************************************/
    IF (P_USER_ACCT_CNT > 0)
    THEN
		-- Salesman Mapping (Only user mapping data)    
        OPEN pREESULT
        FOR
		WITH USER_MAP_ACCT_LV
		 AS (
			 SELECT DISTINCT SALES_LV_ID AS ID 
			   FROM TB_DP_USER_ACCOUNT_MAP 
			  WHERE 1=1
			    AND AUTH_TP_ID = P_AUTH_TP_ID
				AND EMP_ID = P_EMP_ID
				AND ACTV_YN = 'Y'
			), USER_MAP_ACCT_PR
		AS (
			SELECT DISTINCT
                   A.PARENT_SALES_LV_ID_AD1
                 , A.PARENT_SALES_LV_ID_AD2
                 , A.PARENT_SALES_LV_ID_AD3
                 , A.PARENT_SALES_LV_ID            
			  FROM TB_DP_USER_ACCOUNT_MAP M
				   INNER JOIN
				   TB_DP_ACCOUNT_MST A 
				ON M.ACCOUNT_ID = A.ID 
			 WHERE EMP_ID = P_EMP_ID
			   AND AUTH_TP_ID = P_AUTH_TP_ID
			   AND M.ACTV_YN = 'Y'
			   AND A.ACTV_YN = 'Y'
			   AND COALESCE(A.DEL_YN,'N') = 'N'
			 UNION
		    SELECT DISTINCT
                   A.PARENT_SALES_LV_ID_AD1
                 , A.PARENT_SALES_LV_ID_AD2
                 , A.PARENT_SALES_LV_ID_AD3
                 , A.PARENT_SALES_LV_ID                        
		      FROM TB_DP_USER_ITEM_ACCOUNT_MAP M
				   INNER JOIN 
				   TB_DP_ACCOUNT_MST A 
				ON M.ACCOUNT_ID = A.ID 
			 WHERE EMP_ID = P_EMP_ID 
			   AND AUTH_TP_ID = P_AUTH_TP_ID 
			UNION
			SELECT DISTINCT
                   A.PARENT_SALES_LV_ID_AD1
                 , A.PARENT_SALES_LV_ID_AD2
                 , A.PARENT_SALES_LV_ID_AD3
                 , A.PARENT_SALES_LV_ID                        
			  FROM USER_MAP_ACCT_LV AM
			       INNER JOIN 
				   TB_DPD_SALES_HIER_CLOSURE SH
				ON AM.ID = SH.ANCESTER_ID 
				   INNER JOIN 
				   TB_DP_ACCOUNT_MST A
				ON SH.DESCENDANT_ID = A.ID 
			   AND SH.USE_YN = 'Y'
			   AND SH.LV_TP_CD = 'S'
			)  , USER_MAP_ACCT AS (            
                SELECT CASE P_LV_TP_COL
                            WHEN 'PARENT_SALES_LV_ID_AD1' THEN PARENT_SALES_LV_ID_AD1
                            WHEN 'PARENT_SALES_LV_ID_AD2' THEN PARENT_SALES_LV_ID_AD2
                            WHEN 'PARENT_SALES_LV_ID_AD3' THEN PARENT_SALES_LV_ID_AD3
                            ELSE  PARENT_SALES_LV_ID 
                        END AS ID 
                 FROM USER_MAP_ACCT_PR 
            )         
		SELECT distinct SL.ID
			 , SL.SALES_LV_CD
			 , SL.SALES_LV_NM
			  ,SL.LV_MGMT_ID
			 , SL.PARENT_SALES_LV_ID
			 , SL2.SALES_LV_CD		AS PARENT_SALES_LV_CD
			 , SL2.SALES_LV_NM		AS PARENT_SALES_LV_NM
			 , SL.CURCY_CD_ID
			 , SL.SEQ
			 , SL.SRP_YN
		  FROM TB_DPD_SALES_HIER_CLOSURE TR
		       INNER JOIN
			   USER_MAP_ACCT FA
			ON TR.DESCENDANT_ID = FA.ID
			   INNER JOIN 
               TB_DP_SALES_LEVEL_MGMT SL
			ON TR.ANCESTER_ID = SL.ID 
			   LEFT OUTER JOIN
			   TB_DP_SALES_LEVEL_MGMT SL2
			ON (SL.PARENT_SALES_LV_ID = SL2.ID)
			   INNER JOIN
			   TB_CM_LEVEL_MGMT CL
			ON CL.ID = SL.LV_MGMT_ID
               INNER JOIN tb_cm_comm_config CC
            ON CC.ID = CL.LV_TP_ID and CC.CONF_CD = V_LV_TP_CD
		   AND CASE WHEN P_SRP_LV_YN IS NULL THEN 'Y' ELSE (CASE WHEN CL.SRP_LV_YN= P_SRP_LV_YN THEN 'Y' ELSE 'N' END) END = 'Y'
           ;        
    ELSIF (P_MGR_SALES_CNT > 0)
    THEN
        OPEN pREESULT
        FOR
		WITH USER_MAP_ACCT_LV
		  AS (
				SELECT SALES_LV_ID
				  FROM TB_DP_SALES_AUTH_MAP SA
					   INNER JOIN  
					   TB_DP_SALES_LEVEL_MGMT SL 
					ON SA.SALES_LV_ID = SL.ID 
				 WHERE SA.EMP_ID = P_EMP_ID
				   AND SL.LV_MGMT_ID = p_AUTH_TP_ID
				   AND SYSDATE BETWEEN COALESCE(STRT_DATE_AUTH,SYSDATE) AND COALESCE(END_DATE_AUTH, SYSDATE)				   
			 ), USER_MAP_ACCT
		 AS (
				 SELECT DISTINCT 
						CASE P_LV_TP_COL
							WHEN 'PARENT_SALES_LV_ID_AD1' THEN PARENT_SALES_LV_ID_AD1
							WHEN 'PARENT_SALES_LV_ID_AD2' THEN PARENT_SALES_LV_ID_AD2
							WHEN 'PARENT_SALES_LV_ID_AD3' THEN PARENT_SALES_LV_ID_AD3
							ELSE  PARENT_SALES_LV_ID 
						END AS ID 
				   FROM USER_MAP_ACCT_LV MM
						INNER JOIN 
					    TB_DPD_SALES_HIER_CLOSURE SH
					 ON MM.SALES_LV_ID = SH.ANCESTER_ID
					AND USE_YN = 'Y'
				    AND LV_TP_CD = 'S'
					AND LEAF_YN = 'Y'
						INNER JOIN 
						TB_DP_ACCOUNT_MST AM 
					 ON SH.DESCENDANT_ID = AM.ID 
					AND AM.ACTV_YN = 'Y'
					AND COALESCE(AM.DEL_YN,'N') = 'N' 			 
			 )        
    	SELECT SL.ID
			 , SL.SALES_LV_CD
			 , SL.SALES_LV_NM
			  ,SL.LV_MGMT_ID
			 , SL.PARENT_SALES_LV_ID
			 , SL2.SALES_LV_CD		AS PARENT_SALES_LV_CD
			 , SL2.SALES_LV_NM		AS PARENT_SALES_LV_NM
			 , SL.CURCY_CD_ID
			 , SL.SEQ
			 , SL.SRP_YN
		  FROM USER_MAP_ACCT MM
               INNER JOIN 
               TB_DPD_SALES_HIER_CLOSURE SH
            ON MM.ID = SH.DESCENDANT_ID          
               INNER JOIN
               TB_DP_SALES_LEVEL_MGMT SL
		    ON SH.ANCESTER_ID = SL.ID 					   
			   LEFT OUTER JOIN
			   TB_DP_SALES_LEVEL_MGMT SL2
		    ON SL.PARENT_SALES_LV_ID = SL2.ID 
			   INNER JOIN
			   TB_CM_LEVEL_MGMT CL
			ON CL.ID = SL.LV_MGMT_ID
               INNER JOIN 
               TB_CM_COMM_CONFIG CC
            ON CC.ID = CL.LV_TP_ID and CC.CONF_CD = V_LV_TP_CD             
		   AND CASE WHEN P_SRP_LV_YN IS NULL THEN 'Y' ELSE (CASE WHEN CL.SRP_LV_YN= P_SRP_LV_YN THEN 'Y' ELSE 'N' END) END = 'Y'
        ;
    ELSE
		-- Case : mapping data is none, get all master data    
        OPEN pREESULT
        FOR
        SELECT SL.ID
			 , SL.SALES_LV_CD
			 , SL.SALES_LV_NM
			 , SL.LV_MGMT_ID
			 , SL.PARENT_SALES_LV_ID
			 , SL2.SALES_LV_CD  AS PARENT_SALES_LV_CD
			 , SL2.SALES_LV_NM  AS PARENT_SALES_LV_NM
			 , SL.CURCY_CD_ID
			 , SL.SEQ
			 , SL.SRP_YN
		  FROM TB_DP_SALES_LEVEL_MGMT SL
			   INNER JOIN  
			   TB_CM_LEVEL_MGMT LM
			ON SL.LV_MGMT_ID = LM.ID
           AND LM.ACTV_YN = 'Y'
           AND COALESCE(LM.DEL_YN,'N') = 'N'
		   AND CASE WHEN P_SRP_LV_YN IS NULL THEN 'Y' ELSE (CASE WHEN LM.SRP_LV_YN= P_SRP_LV_YN THEN 'Y' ELSE 'N' END) END = 'Y'
               INNER JOIN tb_cm_comm_config CC
            ON CC.ID = LM.LV_TP_ID and CC.CONF_CD = V_LV_TP_CD          
               LEFT OUTER JOIN  
			   TB_DP_SALES_LEVEL_MGMT SL2 
			ON SL.PARENT_SALES_LV_ID = SL2.ID 
		   AND COALESCE(SL2.DEL_YN,'N') = 'N' 
		   AND SL2.ACTV_YN = 'Y'
		 WHERE 1=1
--		   AND SL.LV_MGMT_ID LIKE '%' || TRIM(p_SALES_LV) ||'%'	
		   AND SL.ACTV_YN ='Y'
		 ORDER BY LM.SEQ, SL.SEQ
        ;

    END IF;
END;
/

