create PROCEDURE                "SP_UI_BF_06_S1_J" (
	  P_JSON				CLOB
    , P_USER_ID             VARCHAR2
    , P_RT_ROLLBACK_FLAG    OUT VARCHAR2
    , P_RT_MSG              OUT VARCHAR2
) 
IS
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

    P_ERR_STATUS    NUMBER          := 0;
    P_ERR_MSG       VARCHAR2(4000)  :='';

BEGIN
    
    SELECT COUNT(DF.BASE_DATE)
      INTO P_ERR_STATUS
      FROM TB_BF_DATE_FACTOR DF
      INNER JOIN (SELECT CAST(ID AS CHAR(32)) AS ID, TO_DATE(BASE_DATE, 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS BASE_DATE 
      			  FROM JSON_TABLE(P_JSON, '$[*]' 
								  COLUMNS(
										 ID 		PATH '$.ID' 
										,BASE_DATE 	PATH '$.BASE_DATE' )
								 )
				  ) J
      ON DF.BASE_DATE = J.BASE_DATE
      AND DF.ID != J.ID 
     ;
 
    IF P_ERR_STATUS > 0 THEN
        P_ERR_MSG := 'Factors for desired date already exist.';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);
    END IF;
    
    MERGE INTO TB_BF_DATE_FACTOR TAR
    USING ( 
        SELECT  CAST(ID AS CHAR(32))	          AS ID           
              , TO_DATE(BASE_DATE, 'YYYY-MM-DD"T"HH24:MI:SS"Z"')    AS BASE_DATE    
              , CAST(FACTOR1  AS NUMBER(20,3))    AS FACTOR1  
              , CAST(FACTOR2  AS NUMBER(20,3))    AS FACTOR2  
              , CAST(FACTOR3  AS NUMBER(20,3))    AS FACTOR3  
              , CAST(FACTOR4  AS NUMBER(20,3))    AS FACTOR4  
              , CAST(FACTOR5  AS NUMBER(20,3))    AS FACTOR5  
              , CAST(FACTOR6  AS NUMBER(20,3))    AS FACTOR6  
              , CAST(FACTOR7  AS NUMBER(20,3))    AS FACTOR7  
              , CAST(FACTOR8  AS NUMBER(20,3))    AS FACTOR8  
              , CAST(FACTOR9  AS NUMBER(20,3))    AS FACTOR9  
              , CAST(FACTOR10 AS NUMBER(20,3))    AS FACTOR10 
              , CAST(FACTOR11 AS NUMBER(20,3))    AS FACTOR11 
              , CAST(FACTOR12 AS NUMBER(20,3))    AS FACTOR12 
              , CAST(FACTOR13 AS NUMBER(20,3))    AS FACTOR13 
              , CAST(FACTOR14 AS NUMBER(20,3))    AS FACTOR14 
              , CAST(FACTOR15 AS NUMBER(20,3))    AS FACTOR15 
              , CAST(FACTOR16 AS NUMBER(20,3))    AS FACTOR16 
              , CAST(FACTOR17 AS NUMBER(20,3))    AS FACTOR17 
              , CAST(FACTOR18 AS NUMBER(20,3))    AS FACTOR18 
              , CAST(FACTOR19 AS NUMBER(20,3))    AS FACTOR19 
              , CAST(FACTOR20 AS NUMBER(20,3))    AS FACTOR20 
              , CAST(FACTOR21 AS NUMBER(20,3))    AS FACTOR21 
              , CAST(FACTOR22 AS NUMBER(20,3))    AS FACTOR22 
              , CAST(FACTOR23 AS NUMBER(20,3))    AS FACTOR23 
              , CAST(FACTOR24 AS NUMBER(20,3))    AS FACTOR24 
              , CAST(FACTOR25 AS NUMBER(20,3))    AS FACTOR25 
              , CAST(FACTOR26 AS NUMBER(20,3))    AS FACTOR26 
              , CAST(FACTOR27 AS NUMBER(20,3))    AS FACTOR27 
              , CAST(FACTOR28 AS NUMBER(20,3))    AS FACTOR28 
              , CAST(FACTOR29 AS NUMBER(20,3))    AS FACTOR29 
              , CAST(FACTOR30 AS NUMBER(20,3))    AS FACTOR30 
              , CAST(FACTOR31 AS NUMBER(20,3))    AS FACTOR31 
              , CAST(FACTOR32 AS NUMBER(20,3))    AS FACTOR32 
              , CAST(FACTOR33 AS NUMBER(20,3))    AS FACTOR33 
              , CAST(FACTOR34 AS NUMBER(20,3))    AS FACTOR34 
              , CAST(FACTOR35 AS NUMBER(20,3))    AS FACTOR35 
              , CAST(FACTOR36 AS NUMBER(20,3))    AS FACTOR36 
              , CAST(FACTOR37 AS NUMBER(20,3))    AS FACTOR37 
              , CAST(FACTOR38 AS NUMBER(20,3))    AS FACTOR38 
              , CAST(FACTOR39 AS NUMBER(20,3))    AS FACTOR39 
              , CAST(FACTOR40 AS NUMBER(20,3))    AS FACTOR40 
              , CAST(FACTOR41 AS NUMBER(20,3))    AS FACTOR41 
              , CAST(FACTOR42 AS NUMBER(20,3))    AS FACTOR42 
              , CAST(FACTOR43 AS NUMBER(20,3))    AS FACTOR43 
              , CAST(FACTOR44 AS NUMBER(20,3))    AS FACTOR44 
              , CAST(FACTOR45 AS NUMBER(20,3))    AS FACTOR45 
              , CAST(FACTOR46 AS NUMBER(20,3))    AS FACTOR46 
              , CAST(FACTOR47 AS NUMBER(20,3))    AS FACTOR47 
              , CAST(FACTOR48 AS NUMBER(20,3))    AS FACTOR48 
              , CAST(FACTOR49 AS NUMBER(20,3))    AS FACTOR49 
              , CAST(FACTOR50 AS NUMBER(20,3))    AS FACTOR50 
              , P_USER_ID     AS USER_ID
        FROM JSON_TABLE(P_JSON, '$[*]' 
	        				COLUMNS
	        				(
				        	    ID           PATH  '$.ID'
				              , BASE_DATE    PATH  '$.BASE_DATE'
				              , FACTOR1      PATH  '$.FACTOR1'
				              , FACTOR2      PATH  '$.FACTOR2'
				              , FACTOR3      PATH  '$.FACTOR3'
				              , FACTOR4      PATH  '$.FACTOR4'
				              , FACTOR5      PATH  '$.FACTOR5'
				              , FACTOR6      PATH  '$.FACTOR6'
				              , FACTOR7      PATH  '$.FACTOR7'
				              , FACTOR8      PATH  '$.FACTOR8' 
				              , FACTOR9      PATH  '$.FACTOR9'
				              , FACTOR10     PATH  '$.FACTOR10'
				              , FACTOR11     PATH  '$.FACTOR11'
				              , FACTOR12     PATH  '$.FACTOR12'
				              , FACTOR13     PATH  '$.FACTOR13'
				              , FACTOR14     PATH  '$.FACTOR14'
				              , FACTOR15     PATH  '$.FACTOR15'
				              , FACTOR16     PATH  '$.FACTOR16'
				              , FACTOR17     PATH  '$.FACTOR17'
				              , FACTOR18     PATH  '$.FACTOR18'
				              , FACTOR19     PATH  '$.FACTOR19'
				              , FACTOR20     PATH  '$.FACTOR20'
				              , FACTOR21     PATH  '$.FACTOR21'
				              , FACTOR22     PATH  '$.FACTOR22'
				              , FACTOR23     PATH  '$.FACTOR23'
				              , FACTOR24     PATH  '$.FACTOR24'
				              , FACTOR25     PATH  '$.FACTOR25'
				              , FACTOR26     PATH  '$.FACTOR26'
				              , FACTOR27     PATH  '$.FACTOR27'
				              , FACTOR28     PATH  '$.FACTOR28'
				              , FACTOR29     PATH  '$.FACTOR29'
				              , FACTOR30     PATH  '$.FACTOR30'
				              , FACTOR31     PATH  '$.FACTOR31'
				              , FACTOR32     PATH  '$.FACTOR32'
				              , FACTOR33     PATH  '$.FACTOR33'
				              , FACTOR34     PATH  '$.FACTOR34'
				              , FACTOR35     PATH  '$.FACTOR35'
				              , FACTOR36     PATH  '$.FACTOR36'
				              , FACTOR37     PATH  '$.FACTOR37'
				              , FACTOR38     PATH  '$.FACTOR38'
				              , FACTOR39     PATH  '$.FACTOR39'
				              , FACTOR40     PATH  '$.FACTOR40'
				              , FACTOR41     PATH  '$.FACTOR41'
				              , FACTOR42     PATH  '$.FACTOR42'
				              , FACTOR43     PATH  '$.FACTOR43'
				              , FACTOR44     PATH  '$.FACTOR44'
				              , FACTOR45     PATH  '$.FACTOR45'
				              , FACTOR46     PATH  '$.FACTOR46'
				              , FACTOR47     PATH  '$.FACTOR47'
				              , FACTOR48     PATH  '$.FACTOR48'
				              , FACTOR49     PATH  '$.FACTOR49'
				              , FACTOR50     PATH  '$.FACTOR50'
	        				)
        				)
    ) SRC
    ON    (TAR.BASE_DATE            = SRC.BASE_DATE)
    WHEN MATCHED THEN
         UPDATE 
           SET   
                 TAR.FACTOR1        = SRC.FACTOR1   
                ,TAR.FACTOR2        = SRC.FACTOR2   
                ,TAR.FACTOR3        = SRC.FACTOR3   
                ,TAR.FACTOR4        = SRC.FACTOR4   
                ,TAR.FACTOR5        = SRC.FACTOR5   
                ,TAR.FACTOR6        = SRC.FACTOR6   
                ,TAR.FACTOR7        = SRC.FACTOR7   
                ,TAR.FACTOR8        = SRC.FACTOR8   
                ,TAR.FACTOR9        = SRC.FACTOR9   
                ,TAR.FACTOR10       = SRC.FACTOR10  
                ,TAR.FACTOR11       = SRC.FACTOR11  
                ,TAR.FACTOR12       = SRC.FACTOR12  
                ,TAR.FACTOR13       = SRC.FACTOR13  
                ,TAR.FACTOR14       = SRC.FACTOR14  
                ,TAR.FACTOR15       = SRC.FACTOR15  
                ,TAR.FACTOR16       = SRC.FACTOR16  
                ,TAR.FACTOR17       = SRC.FACTOR17  
                ,TAR.FACTOR18       = SRC.FACTOR18  
                ,TAR.FACTOR19       = SRC.FACTOR19  
                ,TAR.FACTOR20       = SRC.FACTOR20  
                ,TAR.FACTOR21       = SRC.FACTOR21  
                ,TAR.FACTOR22       = SRC.FACTOR22  
                ,TAR.FACTOR23       = SRC.FACTOR23  
                ,TAR.FACTOR24       = SRC.FACTOR24  
                ,TAR.FACTOR25       = SRC.FACTOR25  
                ,TAR.FACTOR26       = SRC.FACTOR26  
                ,TAR.FACTOR27       = SRC.FACTOR27  
                ,TAR.FACTOR28       = SRC.FACTOR28  
                ,TAR.FACTOR29       = SRC.FACTOR29  
                ,TAR.FACTOR30       = SRC.FACTOR30  
                ,TAR.FACTOR31       = SRC.FACTOR31  
                ,TAR.FACTOR32       = SRC.FACTOR32  
                ,TAR.FACTOR33       = SRC.FACTOR33  
                ,TAR.FACTOR34       = SRC.FACTOR34  
                ,TAR.FACTOR35       = SRC.FACTOR35  
                ,TAR.FACTOR36       = SRC.FACTOR36  
                ,TAR.FACTOR37       = SRC.FACTOR37  
                ,TAR.FACTOR38       = SRC.FACTOR38  
                ,TAR.FACTOR39       = SRC.FACTOR39  
                ,TAR.FACTOR40       = SRC.FACTOR40  
                ,TAR.FACTOR41       = SRC.FACTOR41  
                ,TAR.FACTOR42       = SRC.FACTOR42  
                ,TAR.FACTOR43       = SRC.FACTOR43  
                ,TAR.FACTOR44       = SRC.FACTOR44  
                ,TAR.FACTOR45       = SRC.FACTOR45  
                ,TAR.FACTOR46       = SRC.FACTOR46  
                ,TAR.FACTOR47       = SRC.FACTOR47  
                ,TAR.FACTOR48       = SRC.FACTOR48  
                ,TAR.FACTOR49       = SRC.FACTOR49  
                ,TAR.FACTOR50       = SRC.FACTOR50  
                ,TAR.MODIFY_BY      = SRC.USER_ID
                ,TAR.MODIFY_DTTM    = SYSDATE
    WHEN NOT MATCHED THEN 
         INSERT (
                  ID
                , BASE_DATE 
                , FACTOR1   
                , FACTOR2   
                , FACTOR3   
                , FACTOR4   
                , FACTOR5   
                , FACTOR6   
                , FACTOR7   
                , FACTOR8   
                , FACTOR9   
                , FACTOR10  
                , FACTOR11  
                , FACTOR12  
                , FACTOR13  
                , FACTOR14  
                , FACTOR15  
                , FACTOR16  
                , FACTOR17  
                , FACTOR18  
                , FACTOR19  
                , FACTOR20  
                , FACTOR21  
                , FACTOR22  
                , FACTOR23  
                , FACTOR24  
                , FACTOR25  
                , FACTOR26  
                , FACTOR27  
                , FACTOR28  
                , FACTOR29  
                , FACTOR30  
                , FACTOR31  
                , FACTOR32  
                , FACTOR33  
                , FACTOR34  
                , FACTOR35  
                , FACTOR36  
                , FACTOR37  
                , FACTOR38  
                , FACTOR39  
                , FACTOR40  
                , FACTOR41  
                , FACTOR42  
                , FACTOR43  
                , FACTOR44  
                , FACTOR45  
                , FACTOR46  
                , FACTOR47  
                , FACTOR48  
                , FACTOR49  
                , FACTOR50  
                , CREATE_BY 
                , CREATE_DTTM
                ) 
         VALUES (
                 RAWTOHEX(SYS_GUID())
                ,SRC.BASE_DATE
                ,SRC.FACTOR1
                ,SRC.FACTOR2
                ,SRC.FACTOR3
                ,SRC.FACTOR4
                ,SRC.FACTOR5
                ,SRC.FACTOR6
                ,SRC.FACTOR7
                ,SRC.FACTOR8
                ,SRC.FACTOR9
                ,SRC.FACTOR10
                ,SRC.FACTOR11
                ,SRC.FACTOR12
                ,SRC.FACTOR13
                ,SRC.FACTOR14
                ,SRC.FACTOR15
                ,SRC.FACTOR16
                ,SRC.FACTOR17
                ,SRC.FACTOR18
                ,SRC.FACTOR19
                ,SRC.FACTOR20
                ,SRC.FACTOR21
                ,SRC.FACTOR22
                ,SRC.FACTOR23
                ,SRC.FACTOR24
                ,SRC.FACTOR25
                ,SRC.FACTOR26
                ,SRC.FACTOR27
                ,SRC.FACTOR28
                ,SRC.FACTOR29
                ,SRC.FACTOR30
                ,SRC.FACTOR31
                ,SRC.FACTOR32
                ,SRC.FACTOR33
                ,SRC.FACTOR34
                ,SRC.FACTOR35
                ,SRC.FACTOR36
                ,SRC.FACTOR37
                ,SRC.FACTOR38
                ,SRC.FACTOR39
                ,SRC.FACTOR40
                ,SRC.FACTOR41
                ,SRC.FACTOR42
                ,SRC.FACTOR43
                ,SRC.FACTOR44
                ,SRC.FACTOR45
                ,SRC.FACTOR46
                ,SRC.FACTOR47
                ,SRC.FACTOR48
                ,SRC.FACTOR49
                ,SRC.FACTOR50
                ,SRC.USER_ID
                ,SYSDATE
                ) 
    ;    
            
    P_RT_ROLLBACK_FLAG  := 'true';
    P_RT_MSG            := 'MSG_0001';  --저장 되었습니다.

EXCEPTION WHEN OTHERS THEN
    IF (SQLCODE = -20001) THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
    ELSE 
        RAISE;
--              EXEC SP_COMM_RAISE_ERR
    END IF;
END;
/

