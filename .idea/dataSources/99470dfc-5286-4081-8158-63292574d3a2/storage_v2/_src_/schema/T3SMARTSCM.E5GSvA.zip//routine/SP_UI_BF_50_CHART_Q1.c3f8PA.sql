create PROCEDURE                  "SP_UI_BF_50_CHART_Q1" 
(
    p_VER_CD        VARCHAR2,
    p_ITEM       VARCHAR2,
    p_SALES         VARCHAR2,
    p_FROM_DATE     DATE,
    p_TO_DATE       DATE,
    pRESULT         OUT SYS_REFCURSOR  
)IS 

    p_TARGET_FROM_DATE  DATE := NULL;
    v_TO_DATE           DATE := NULL;
    v_BUKT              VARCHAR2(5);

BEGIN
    SELECT MAX(TARGET_FROM_DATE)
         , MAX(TARGET_BUKT_CD)
           INTO
           p_TARGET_FROM_DATE
         , v_BUKT
      FROM TB_BF_CONTROL_BOARD_VER_DTL
     WHERE VER_CD = p_VER_CD
       AND ENGINE_TP_CD IS NOT NULL
    ;

    IF (v_BUKT = 'W')
    THEN
        SELECT MAX(END_DATE) INTO v_TO_DATE
          FROM (
                SELECT YYYY
                     , DP_WK
                     , MIN(DAT) AS STRT_DATE
                     , MAX(DAT) AS END_DATE
                  FROM TB_CM_CALENDAR C
                 WHERE DAT BETWEEN p_FROM_DATE AND p_TO_DATE
		      GROUP BY YYYY, DP_WK
          HAVING COUNT(DP_WK) >= 7
          );
    ELSE
        v_TO_DATE := p_TO_DATE;
    END IF;

    OPEN pRESULT FOR
    WITH RT AS (
        SELECT ITEM_CD
             , ACCOUNT_CD
             , BASE_DATE 
             , ENGINE_TP_CD
             , COALESCE(QTY,0)	AS QTY
          FROM TB_BF_RT RF
         WHERE BASE_DATE BETWEEN p_FROM_DATE and v_TO_DATE
           AND VER_CD = p_VER_CD
           AND ACCOUNT_CD = p_SALES
           AND ITEM_CD = p_ITEM
    ), CALENDAR
    AS (
        SELECT DAT 
             , YYYY
             , YYYYMM
             , CASE v_BUKT
                 WHEN 'W' THEN SUBSTR(DP_WK, 1, 4) || ' w' || SUBSTR(DP_WK, 5, 2)
                 WHEN 'PW' THEN YYYYMM || ' w' || SUBSTR(DP_WK, 5, 2)
                 WHEN 'M' THEN YYYYMM
               END AS BUKT
--             , CASE v_BUKT
--                --WHEN 'W' THEN YYYY+' w'  +replicate('0',2-LEN(DP_WK))+CONVERT(NVARCHAR(2),DP_WK)
--                --WHEN 'PW'THEN YYYYMM+' w'+replicate('0',2-LEN(DP_WK))+CONVERT(NVARCHAR(2),DP_WK) 
--                WHEN 'W'   THEN YYYY || ' w' || LPAD(DP_WK, 2, '0')
--                WHEN 'PW'  THEN YYYYMM || ' w' || LPAD(DP_WK, 2, '0')
--                WHEN 'M'   THEN YYYYMM
--                WHEN 'D'   THEN YYYYMMDD 
--               END AS BUKT	
          FROM TB_CM_CALENDAR CA
         WHERE DAT between p_FROM_DATE and v_TO_DATE     

    ), CA
    AS (
        SELECT MIN(DAT)	 STRT_DATE
             , BUKT	
             , MAX(DAT)	 END_DATE
--             , TO_CHAR(MIN(DAT), 'YYYY-MM-DD') AS BUKT
--             , CASE v_BUKT
--                 WHEN 'W' THEN MIN(YYYY) || ' w' ||  LPAD(BUKT, 2, '0')
--                 WHEN 'PW' THEN MIN(YYYYMM) || ' w' ||  LPAD(BUKT, 2, '0')
--                 WHEN 'M' THEN MIN(YYYYMM)
--               END AS BUKT
          FROM CALENDAR CA
         WHERE DAT between p_FROM_DATE and v_TO_DATE 
       GROUP BY BUKT 
    ), SA
    AS (
        SELECT  ITEM_CD
              , ACCOUNT_CD
              , CA.STRT_DATE
              , CA.BUKT 
              , SUM(QTY)	QTY 
          FROM TB_CM_ACTUAL_SALES S
--               INNER JOIN CALENDAR MCA
--            ON S.BASE_DATE = MCA.DAT 
               INNER JOIN
               CA
--            ON MCA.BUKT = CA.BUKT 
            ON S.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
               INNER JOIN 
               TB_CM_ITEM_MST IM 
            ON S.ITEM_MST_ID = IM.ID
           AND COALESCE(IM.DEL_YN,'N') = 'N'           
               INNER JOIN 
               TB_DP_ACCOUNT_MST AM
            ON S.ACCOUNT_ID = AM.ID
           AND COALESCE(AM.DEL_YN,'N') = 'N'
           AND AM.ACTV_YN = 'Y'
         WHERE 1=1
           AND ACCOUNT_CD = p_SALES
           AND ITEM_CD = p_ITEM
      GROUP BY ITEM_CD, ACCOUNT_CD
              , CA.BUKT
              , CA.STRT_DATE
    ), N
    AS (
        SELECT RT.ITEM_CD					AS ITEM_CD
             , RT.ACCOUNT_CD				AS ACCOUNT_CD
             , CA.BUKT
             , RT.ENGINE_TP_CD
             , SUM(RT.QTY)					AS QTY 			 
          FROM RT 
--               INNER JOIN
--               CALENDAR MCA
--            ON RT.BASE_DATE = MCA.DAT
               INNER JOIN 
               CA 
--            ON MCA.BUKT = CA.BUKT 
            ON RT.BASE_DATE BETWEEN CA.STRT_DATE AND END_DATE
    GROUP BY ITEM_CD, ACCOUNT_CD, CA.BUKT, ENGINE_TP_CD 
         UNION
        SELECT SA.ITEM_CD
             , SA.ACCOUNT_CD
             , BUKT
             , 'Z_ACT_SALES'						AS ENGINE_TP_CD
             , SA.QTY 
          FROM SA
    ), M
    AS (
        SELECT ITEM_CD
              ,ACCOUNT_CD 
              ,ENGINE_TP_CD
              ,STRT_DATE
              ,END_DATE
              ,BUKT
              ,CASE WHEN ENGINE_TP_CD ='Z_ACT_SALES' AND STRT_DATE >= p_TARGET_FROM_DATE THEN 'ORANGE' 
                    WHEN ENGINE_TP_CD ='Z_ACT_SALES' AND STRT_DATE < p_TARGET_FROM_DATE THEN 'GREY'
                    ELSE NULL 
               END AS COLOR
          FROM CA 
               CROSS JOIN
               ( SELECT ITEM_CD
                       ,ACCOUNT_CD 
                       ,ENGINE_TP_CD
                   FROM N  
               GROUP BY ITEM_CD
                       ,ACCOUNT_CD 
                       ,ENGINE_TP_CD
               ) RT
    )
    SELECT M.ITEM_CD
         , M.ACCOUNT_CD
         , M.ENGINE_TP_CD
         , M.BUKT
    --     , TO_CHAR(M.STRT_DATE,'YYYY-MM-DD') AS BUKT
    --	 , M.STRT_DATE
    --	 , M.END_DATE 
         , N.QTY	 
         , M.COLOR 
      FROM M
           LEFT OUTER JOIN
           N ON M.ITEM_CD = N.ITEM_CD
              AND M.ACCOUNT_CD = N.ACCOUNT_CD
              AND M.BUKT = N.BUKT
              AND M.ENGINE_TP_CD = N.ENGINE_TP_CD
     ORDER BY M.ENGINE_TP_CD, M.STRT_DATE
              ;
END
;

/

