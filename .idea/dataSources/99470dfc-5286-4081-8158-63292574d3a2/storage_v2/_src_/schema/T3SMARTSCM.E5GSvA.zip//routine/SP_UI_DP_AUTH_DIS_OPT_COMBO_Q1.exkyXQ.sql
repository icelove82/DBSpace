create PROCEDURE SP_UI_DP_AUTH_DIS_OPT_COMBO_Q1 (
	  p_AUTH_TP		VARCHAR2
    , P_UI_ID       VARCHAR2
    , P_GRID_ID     VARCHAR2
    , pRESULT       OUT SYS_REFCURSOR
)
IS
/*****************************************************************************
Title : SP_UI_DP_AUTH_DIS_OPTION_Q1
최초 작성자 : 이고은
최초 생성일 : 2017.07.21
?
설명 
 - DP Entry Dis.Oprion Combo
 ?
History (수정일자 / 수정자 / 수정내용)
- 2017.07.21 / 이고은 / 최초 작성
- 2019.04.25 / 김소희 / DEL_YN Null처리?
- 2020.11.02 / KSH / add a condition about group ID
	- 2020.11.10 / Kim sohee / data type of CODE VARCHAR2(100)
- 2020.11.17 / Kim sohee / auth type ID => Group ID 
- 2020.12.23 / 민경훈 / MSSQL -> ORACLE
*****************************************************************************/


v_GRP_ID	char(32); -- CD를 ID로 변환
V_GRID_ID   VARCHAR2(100);
BEGIN
	V_GRID_ID := REPLACE(P_GRID_ID, P_UI_ID||'-', '');
    
    SELECT ID INTO v_GRP_ID
      FROM TB_AD_GROUP 
    WHERE GRP_CD = p_AUTH_TP
    ;

    OPEN pRESULT FOR 		
    SELECT	DISTINCT A.ID
                   , A.CD
                   , A.DISP_NM AS CD_NM
                   , A.DIS_SEQ
                   , A.SEQ
                   , CONCAT(CONCAT(A.CD, '|'), A.R_TYPE) as D_RULE
                   , MS_KEY
                   , VAL_TP
                   , R_TYPE
    FROM	(
                SELECT	 p_UI_ID		AS UI_ID
                        ,V_GRID_ID		AS GRID_ID
                        ,v_GRP_ID AS GRP_ID
                        ,'N'			AS ID
                        ,'N'			AS CD
                        ,'1/N'			AS DISP_NM
                        ,0				AS DIS_SEQ
                        ,0				AS SEQ
                        ,'N'    as R_TYPE
                        ,NULL   AS MS_KEY
                        ,NULL   AS VAL_TP
                   FROM DUAL

                UNION 

                SELECT	 p_UI_ID		AS UI_ID
                        ,V_GRID_ID		AS GRID_ID
                        ,v_GRP_ID  
                        ,'SAME'			AS ID
                        ,'SAME'			AS CD
                        ,'Same Value'	AS DISP_NM
                        ,0				AS DIS_SEQ
                        ,1				AS SEQ
                        ,'SAME' as R_TYPE
                        ,NULL   AS MS_KEY
                        ,NULL   AS VAL_TP
                   FROM DUAL

                UNION  

			SELECT 
              MS.UI_ID
            , MS.GRID_ID
            , MS.GRP_ID
            , MS.ID 
            , CASE CF.CONF_CD 
					WHEN 'ADDITION' THEN ME.MEASURE_CD
					WHEN 'DEMAND'	THEN LV.LV_CD 
				   END	AS CD
            ,MS.DISP_NM
            ,CASE CF.CONF_CD 
					WHEN 'ADDITION' THEN 2
					WHEN 'DEMAND'	THEN 1 
				   END	AS DIS_SEQ
            ,MS.SEQ
			, CF.CONF_CD		AS R_TYPE
            ,   CASE CF.CONF_CD 
					WHEN 'ADDITION' THEN (CASE WHEN CF.CONF_CD LIKE 'RTF%' THEN ME.TBL_NM ELSE 'TB_DP_MEASURE_DATA' END )
					WHEN 'DEMAND'	THEN LV.ID  
				   END	AS MS_KEY
				 , VT.CONF_CD		AS VAL_TP
			 FROM TB_DP_MEASURE_SETTING MS
				  INNER JOIN 
				  TB_CM_COMM_CONFIG CF  
			   ON MS.MEASURE_CONF_TP_ID = CF.ID
			      LEFT OUTER JOIN
				  TB_DP_MEASURE_MST ME
			   ON MS.MEASURE_MST_ID = ME.ID
			      LEFT OUTER JOIN
				  TB_CM_LEVEL_MGMT LV
			   ON MS.LV_MGMT_ID = LV.ID 
			      INNER JOIN
				  TB_CM_COMM_CONFIG VT
			   ON MS.MEASURE_VAL_TP_ID = VT.ID    
            WHERE UI_ID = p_UI_ID
              AND GRID_ID = V_GRID_ID
              AND GRP_ID = v_GRP_ID 
			  AND MS.ACTV_YN = 'Y'              
                ) A

    ORDER BY A.DIS_SEQ, A.SEQ
    ;
END;
/

