create PROCEDURE "SP_UI_CM_16_S3" (
        P_DTL_ID						IN VARCHAR2 :=''
        ,P_RT_ROLLBACK_FLAG				OUT VARCHAR2
        ,P_RT_MSG						OUT VARCHAR2
)IS
P_ERR_STATUS NUMBER :=0;
P_ERR_MSG  VARCHAR2(4000) :='';
BEGIN
    P_RT_ROLLBACK_FLAG := 'true';

DELETE FROM TB_CM_PLAN_SNRIO_MGMT_DTL 
    WHERE ID = P_DTL_ID;  

    P_RT_MSG := 'MSG_0002'; 
    P_RT_ROLLBACK_FLAG := 'true';

EXCEPTION
        WHEN OTHERS THEN
            P_RT_ROLLBACK_FLAG := 'false';
            IF(SQLCODE = -20012)
              THEN
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
                  P_RT_MSG := SQLERRM;
              END IF; 
END;

/

