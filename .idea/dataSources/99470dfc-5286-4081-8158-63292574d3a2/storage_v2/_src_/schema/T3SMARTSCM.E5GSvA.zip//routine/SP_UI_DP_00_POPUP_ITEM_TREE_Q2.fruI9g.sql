create PROCEDURE                "SP_UI_DP_00_POPUP_ITEM_TREE_Q2" (
    P_EMP_NO       VARCHAR2    := NULL
  , P_AUTH_TP_ID   CHAR        := NULL
  , P_ITEM_LV      VARCHAR2    := NULL
  , p_LV_TP_CD     VARCHAR2    := NULL
  , pREESULT       OUT     SYS_REFCURSOR
)IS

/************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID     
    - 2021.12.13 / Kim sohee / get data by using DPD table (for performance)    
	- 2022.02.28 / Kim sohee / 속도 개선   
    - 2022.03.07 / Kim sohee / add a case : level type 
************************************************************************/
    P_EMP_ID    CHAR(32);
    p_CNT       INT;
    V_LV_TP_CD    VARCHAR2(100)   := COALESCE(p_LV_TP_CD, 'I');    
    P_LV_TP_COL   VARCHAR2(100);

BEGIN

    SELECT COUNT(ID)
      INTO P_CNT
      FROM TB_AD_USER
     WHERE USERNAME = P_EMP_NO;

    IF P_CNT != 0 THEN
        SELECT ID
          INTO P_EMP_ID
          FROM TB_AD_USER
         WHERE USERNAME = P_EMP_NO;
    END IF;

    SELECT COUNT(EMP_ID) INTO P_CNT
      FROM TB_DP_USER_ITEM_MAP
     WHERE AUTH_TP_ID = P_AUTH_TP_ID
       AND EMP_ID = P_EMP_ID
    ;
    SELECT P_CNT+COUNT(EMP_ID) INTO P_CNT
      FROM TB_DP_USER_ITEM_ACCOUNT_MAP
     WHERE EMP_ID = P_EMP_ID
       AND AUTH_TP_ID = P_AUTH_TP_ID
    ;

    IF (P_CNT = 0)
    THEN
        P_EMP_ID := NULL;
    END IF;
/**********************************************************
    -- MAIN PROCEDURE
**********************************************************/
    IF (P_EMP_ID IS NULL OR P_AUTH_TP_ID IS NULL)
    THEN
        OPEN pREESULT
        FOR
        SELECT IL.ID
             , IL.ITEM_LV_CD
		     , IL.ITEM_LV_NM
		     , IL.LV_MGMT_ID
		     , IL.PARENT_ITEM_LV_ID   AS PARENT_ITEM_LV_ID
		     , IL2.ITEM_LV_CD         AS PARENT_ITEM_LV_CD
		     , IL2.ITEM_LV_NM         AS PARENT_ITEM_LV_NM        
		     , IL.SEQ
		     , IL.ATTR_01
	      FROM TB_CM_ITEM_LEVEL_MGMT IL 
			   INNER JOIN 
			   TB_CM_LEVEL_MGMT  LM
		    ON LM.ID = IL.LV_MGMT_ID 
		 	   INNER JOIN
		       TB_CM_COMM_CONFIG B
		    ON B.ID = LM.LV_TP_ID  -- S/C/I
		   AND B.CONF_GRP_CD = 'DP_LV_TP'
		   AND B.CONF_CD = V_LV_TP_CD
		       INNER JOIN
			   TB_CM_CONFIGURATION A
		    ON A.ID = B.CONF_ID
		   AND A.MODULE_CD = 'DP'
		 	   LEFT OUTER JOIN  
               TB_CM_ITEM_LEVEL_MGMT IL2 
            ON IL.PARENT_ITEM_LV_ID = IL2.ID AND COALESCE(IL2.DEL_YN,'N') = 'N' AND IL2.ACTV_YN = 'Y'  
	     WHERE COALESCE(LM.DEL_YN,'N') = 'N'
	  	   AND LM.ACTV_YN = 'Y'
	  	   AND IL.LV_MGMT_ID  LIKE '%' || COALESCE(TRIM(P_ITEM_LV), '') || '%'    
	  	   AND IL.ACTV_YN ='Y'
	     ORDER BY LM.SEQ, IL.SEQ
        ;
    ELSE
		SELECT ATTR_01 INTO P_LV_TP_COL
		  FROM TB_CM_COMM_CONFIG 
		 WHERE CONF_GRP_CD = 'DP_LV_TP' 
		   AND CONF_CD = p_LV_TP_CD
			   ;    
		-- Salesman Mapping (Only user mapping data)    
        OPEN pREESULT
        FOR
		WITH USER_MAP_ITEM_LV
		  AS (
			SELECT DISTINCT ITEM_LV_ID AS ID
			  FROM TB_DP_USER_ITEM_MAP	       
			 WHERE 1=1 
			   AND AUTH_TP_ID = P_AUTH_TP_ID
			   AND EMP_ID = P_EMP_ID
			   AND ACTV_YN = 'Y'		 
		), USER_MAP_ITEM_PR
		AS (
			SELECT DISTINCT 
                   I.PARENT_ITEM_LV_ID_AD1
				 , I.PARENT_ITEM_LV_ID_AD2
				 , I.PARENT_ITEM_LV_ID_AD3
				 , I.PARENT_ITEM_LV_ID 
			  FROM TB_DP_USER_ITEM_MAP M
				   INNER JOIN 
				   TB_CM_ITEM_MST I	
				ON M.ITEM_MST_ID = I.ID 
			 WHERE EMP_ID = P_EMP_ID
			   AND AUTH_TP_ID = P_AUTH_TP_ID
			   AND ACTV_YN = 'Y'
			UNION
			SELECT DISTINCT
                   I.PARENT_ITEM_LV_ID_AD1
				 , I.PARENT_ITEM_LV_ID_AD2
				 , I.PARENT_ITEM_LV_ID_AD3
				 , I.PARENT_ITEM_LV_ID             
			  FROM TB_DP_USER_ITEM_ACCOUNT_MAP M
				   INNER JOIN 
				   TB_CM_ITEM_MST I	
				ON M.ITEM_MST_ID = I.ID 
			 WHERE EMP_ID = P_EMP_ID
			   AND AUTH_TP_ID = P_AUTH_TP_ID 
			UNION
			SELECT DISTINCT 
                   I.PARENT_ITEM_LV_ID_AD1
				 , I.PARENT_ITEM_LV_ID_AD2
				 , I.PARENT_ITEM_LV_ID_AD3
				 , I.PARENT_ITEM_LV_ID             
			  FROM USER_MAP_ITEM_LV IM
				   INNER JOIN 
				   TB_DPD_ITEM_HIER_CLOSURE IH 	
				ON IM.ID = IH.ANCESTER_ID
				   INNER JOIN 
				   TB_CM_ITEM_MST I	
				ON IH.DESCENDANT_ID = I.ID 
			   AND IH.USE_YN = 'Y' 
			   AND IH.LV_TP_CD = 'I'
		), USER_MAP_ITEM
        AS (SELECT CASE P_LV_TP_COL
						WHEN 'PARENT_ITEM_LV_ID_AD1' THEN I.PARENT_ITEM_LV_ID_AD1
						WHEN 'PARENT_ITEM_LV_ID_AD2' THEN I.PARENT_ITEM_LV_ID_AD2
						WHEN 'PARENT_ITEM_LV_ID_AD3' THEN I.PARENT_ITEM_LV_ID_AD3
						ELSE  I.PARENT_ITEM_LV_ID 
					END AS ID 
			 FROM USER_MAP_ITEM_PR I        
            )
		SELECT DISTINCT IL.ID
			 , IL.ITEM_LV_CD
			 , IL.ITEM_LV_NM
			 , IL.LV_MGMT_ID
			 , IL.PARENT_ITEM_LV_ID
			 , IL2.ITEM_LV_CD		AS PARENT_ITEM_LV_CD
			 , IL2.ITEM_LV_NM		AS PARENT_ITEM_LV_NM
			 , IL.SEQ
			 , IL.ATTR_01
		  FROM TB_DPD_ITEM_HIER_CLOSURE TR 
               INNER JOIN
               USER_MAP_ITEM FA 
			ON TR.DESCENDANT_ID = FA.ID
			   INNER JOIN
			   TB_CM_ITEM_LEVEL_MGMT IL
			ON TR.ANCESTER_ID = IL.ID
--           AND IL.ITEM_LV_CD LIKE '%'||P_ITEM_LV||'%'
			   INNER JOIN
			   TB_CM_LEVEL_MGMT CL
			ON CL.ID = IL.LV_MGMT_ID
  			   LEFT OUTER JOIN
			   TB_CM_ITEM_LEVEL_MGMT IL2
			ON IL.PARENT_ITEM_LV_ID = IL2.ID 
      ;
    END IF;
END;
/

