create PROCEDURE                "SP_UI_DP_00_POPUP_USER_Q2" (
    p_LOGIN_ID  VARCHAR2 := ''   
  , p_EMP_NO    VARCHAR2 := ''
  , p_EMP_NM    VARCHAR2 := ''
  , pRESULT     OUT SYS_REFCURSOR
) IS 

BEGIN
    
    IF P_LOGIN_ID = 'admin'
    THEN
        OPEN pRESULT
        FOR
        SELECT A.ID
             , A.USER_ID
             , A.EMP_NO
             , A.EMP_NM 
          FROM (
            SELECT '' ID,  '' USER_ID, '' EMP_NO, '' EMP_NM
              FROM DUAL
            UNION ALL
            SELECT ID
                 , USERNAME as USER_ID
                 , USERNAME as EMP_NO
                 , DISPLAY_NAME as EMP_NM  
              FROM TB_AD_USER  
             WHERE USERNAME LIKE '%' + P_EMP_NO +'%'            
               AND COALESCE(DISPLAY_NAME,'') LIKE '%' + P_EMP_NM +'%'      
          ) A
         ORDER BY EMP_NO 
        ;
    END IF;
END;
/

