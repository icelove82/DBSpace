create PROCEDURE SP_UI_CM_09_S1(
     P_WRK_TYPE								IN VARCHAR2 := NULL
	,P_ID										IN VARCHAR2	:= NULL
	,P_PACKING_TP_ID							IN VARCHAR2	:= NULL
	,P_PALLET_TP_ID							IN VARCHAR2	:= NULL
	,P_UOM_PER_PACKING							IN VARCHAR2	:= NULL
	,P_PACKING_PER_PALLET						IN VARCHAR2	:= NULL
	,P_UNIT_WEIGHT	 							IN VARCHAR2	:= NULL
	,P_WEIGHT_UOM_ID							IN VARCHAR2	:= NULL
	,P_SITE_WAREHOUSE_MGMT_ID					IN VARCHAR2	:= NULL
	,P_PALLET_LAYER							IN VARCHAR2	:= NULL	-- CHAGNE
	,P_PACKING_CELLL						IN VARCHAR2	:= NULL		-- CHANGE
	,P_FIXED_YN								    IN CHAR := 'Y'
	,P_ACTV_YN									IN CHAR := 'Y'
	,P_USER_ID									IN VARCHAR2	:= NULL
	,P_RT_ROLLBACK_FLAG				    OUT VARCHAR2
	,P_RT_MSG									  OUT VARCHAR2
)IS 

        P_ERR_STATUS NUMBER :=0;
        P_ERR_MSG  VARCHAR2(4000) :='';
        --


        BEGIN
        P_RT_ROLLBACK_FLAG := 'true';
        
        IF P_WRK_TYPE = 'SAVE'
		THEN

			UPDATE TB_CM_SITE_PACKING
			   SET
			       SITE_WAREHOUSE_MGMT_ID   =  P_SITE_WAREHOUSE_MGMT_ID		
			     , PACKING_TP_CD_ID			=  P_PACKING_TP_ID			
			     , PALLET_TP_ID				=  P_PALLET_TP_ID			
			     , UOM_PER_PACKING			=  TO_NUMBER(DECODE(RTRIM(P_UOM_PER_PACKING),'',null,P_UOM_PER_PACKING) )	
			     , PACKING_PER_PALLET		=  TO_NUMBER(DECODE(RTRIM(P_PACKING_PER_PALLET),'',null,P_PACKING_PER_PALLET) )
			     , WEIGHT_UOM_ID			=  P_WEIGHT_UOM_ID
			     , UNIT_WEIGHT				=  TO_NUMBER(DECODE(RTRIM(P_UNIT_WEIGHT),'',null,P_UNIT_WEIGHT) )
			     , PALLET_LAYER				=  TO_NUMBER(DECODE(RTRIM(P_PALLET_LAYER),'',null,P_PALLET_LAYER) )		
			     , PACKING_CELL				=  TO_NUMBER(DECODE(RTRIM(P_PACKING_CELLL),'',null,P_PACKING_CELLL) )	
			     , FIXED_YN					=  P_FIXED_YN		
			     , ACTV_YN					=  P_ACTV_YN	
				 , MODIFY_BY				=  P_USER_ID
				 , MODIFY_DTTM				=  SYSDATE
		  WHERE ID = P_ID;

             P_RT_MSG := 'MSG_0001';  --???？？????？？
             P_RT_ROLLBACK_FLAG := 'true';

	ELSIF P_WRK_TYPE = 'DELETE'
		THEN

			DELETE FROM TB_CM_SITE_PACKING
			WHERE ID = P_ID ;

        P_RT_MSG := 'MSG_0002';  --?？ ?？????？？
		 P_RT_ROLLBACK_FLAG := 'true';

         END IF;

EXCEPTION
        WHEN OTHERS THEN
            IF(SQLCODE = -20012)
              THEN
                  P_RT_ROLLBACK_FLAG := 'false';
                  P_RT_MSG := P_ERR_MSG;   
              ELSE
              RAISE;
              END IF; 

END;

/

