create PROCEDURE                "SP_UI_BF_15_D1" 
(
    P_ID                CHAR            
  , P_RT_ROLLBACK_FLAG  OUT VARCHAR2
  , P_RT_MSG            OUT VARCHAR2  
)
IS
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
    P_ERR_STATUS    NUMBER          := 0;
    P_ERR_MSG       VARCHAR2(4000)  :='';

BEGIN
    DELETE FROM TB_BF_CONTROL_BOARD_MST
     WHERE ID = P_ID;
         
    P_RT_MSG := 'MSG_0002';
    P_RT_ROLLBACK_FLAG := 'true';

EXCEPTION WHEN OTHERS THEN
    IF (SQLERRM = P_ERR_MSG) THEN
        P_ERR_MSG := SQLERRM;
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
    ELSE
        RAISE_APPLICATION_ERROR(SQLCODE, SQLERRM);
--              EXEC SP_COMM_RAISE_ERR
    END IF;
END;


/*

SELECT *
 FROM  TB_CM_CONFIGURATION CF
         INNER JOIN
         TB_CM_COMM_CONFIG CC   
      ON CF.ID = CC.CONF_ID 
     AND CF.CONF_NM = 'BF_ENGINE_TP'
     AND CF.MODULE_CD = 'BF'
      -- lang_pack 문서에 반영하기!!!
      SELECT *
        FROM LANG_PACK
      WHERE LANG_KEY LIKE '%ENGINE_TP%'
        OR LANG_KEY = 'INPUT'
*/
/

