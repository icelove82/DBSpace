create PROCEDURE                "SP_UI_DP_00_CONF_Q1" (
    p_GRP_CD    IN VARCHAR2 := ''
  , p_TYPE      IN VARCHAR2 := ''
  , p_LOCALE    IN VARCHAR2 := ''
  , pRESULT     OUT SYS_REFCURSOR 
) 
IS
/*
    TB_CM_CONFIGURATION 
    HISTORY 
    - 2019.01.24 / : MODULE_TP, MODULE_TP_EDIT, CONF_KEY, CUSTOMER
    - 2021.10.12 / add LV_TP_I, LV_TP_S 
*/
BEGIN
    -- CONFIGURATION
    IF p_GRP_CD = 'UOM' -- UI_ID : DP_09
      THEN
        OPEN pRESULT
        FOR
        SELECT  A.ID
              , A.CD
              , A.CD_NM
        FROM (
                SELECT  ''             AS ID
                      , UPPER(P_TYPE)  AS CD
                      , UPPER(P_TYPE)  AS CD_NM
                FROM dual      
                WHERE UPPER(P_TYPE) = 'ALL'
                UNION ALL
                SELECT  B.ID
                      , B.UOM_CD
                      , B.UOM_NM
                  FROM  TB_CM_CONFIGURATION A
                        INNER JOIN
                        TB_CM_UOM B
                     ON A.ID = B.CONF_ID
                 WHERE B.ACTV_YN = 'Y'
             ) A
         ORDER BY A.CD ASC
         ;
    ELSIF p_GRP_CD = 'INCOTERMS' -- UI_ID : DP_11
      THEN
        OPEN pRESULT
        FOR SELECT  A.ID
                  , A.CD
                  , A.CD_NM
        FROM (
                SELECT  ''  AS ID
                      , UPPER(P_TYPE)  AS CD
                      , UPPER(P_TYPE)  AS CD_NM
                FROM dual      
                WHERE UPPER(P_TYPE) = 'ALL'
                UNION ALL
                SELECT  B.ID  AS ID
                  , B.INCOTERMS  AS CD
                  , B.INCOTERMS  AS CD_NM
                  FROM TB_CM_CONFIGURATION A
                     , TB_CM_INCOTERMS B
                 WHERE A.ID = B.CONF_ID
                   AND UPPER(A.CONF_NM) = 'CM_INCOTERMS'
                   AND B.ACTV_YN = 'Y'
             ) A
         ORDER BY  A.CD ASC
         ;
    ELSIF p_GRP_CD = 'DP_CHANNEL_TP' -- UI_ID : DP_11
      THEN

        OPEN pRESULT
        FOR SELECT  A.ID
            , A.CD
            , A.CD_NM
            , A.VMI_YN
        FROM (
                SELECT  NULL  AS ID
                      , UPPER(P_TYPE)  AS CD
                      , UPPER(P_TYPE)  AS CD_NM
                      , ' ' AS VMI_YN
                FROM dual      
                WHERE UPPER(P_TYPE) = 'ALL'
                UNION ALL
                SELECT  B.ID  AS ID
                      , B.CHANNEL_ID  AS CD
                      , B.CHANNEL_NM  AS CD_NM
                      , B.VMI_YN      AS VMI_YN
                  FROM  TB_CM_CONFIGURATION A
                      , TB_CM_CHANNEL_TYPE B
                 WHERE  A.ID = B.CONF_ID
                   AND  B.ACTV_YN = 'Y'
             ) A
         ORDER BY  A.CD ASC
         ;

    ELSIF p_GRP_CD = 'UI_ID' -- UI_ID : DP_18, DP_19, SR_04, SR_05
      THEN
          OPEN pRESULT
          FOR 
          SELECT REPLACE(VIEW_CD, 'SR_', 'SRP_') AS CD
               , REPLACE(VIEW_CD, 'SR_', 'SRP_') AS CD_NM
            FROM TB_AD_USER_PREF_MST
           WHERE 1=1
             AND AUTO_CREATE_YN = 'Y'
             AND (VIEW_CD LIKE '%' || REPLACE(SUBSTR(P_TYPE, 0, 2), 'SR', 'SRP') || '%' -- SR_ ESCAPE
                  or VIEW_CD LIKE '%' || CASE WHEN P_TYPE = 'DP' THEN 'BP' ELSE 'SRP' END || '%' )
           GROUP BY VIEW_CD 
           ORDER BY VIEW_CD
            ;
    ELSIF p_GRP_CD = 'UI_ID_MES_SET'
        THEN
          OPEN pRESULT
          FOR 
            SELECT VIEW_CD AS CD , VIEW_CD AS CD_NM
              FROM TB_AD_USER_PREF_MST
             WHERE 1=1
                AND AUTO_CREATE_YN ='Y'
                AND (VIEW_CD LIKE '%DP_9%' or VIEW_CD LIKE '%BP_9%') 
              GROUP BY VIEW_CD
              order by VIEW_CD;
    ELSIF p_GRP_CD = 'GRID' -- UI_ID : DP_18, DP_19, SR_04, SR_05
      THEN
        OPEN pRESULT
        FOR 
        SELECT GRID_CD AS CD
             , GRID_DESCRIP AS CD_NM
--             , GRID_CD || CASE WHEN NVL(GRID_DESCRIP, '') = '' THEN NULL ELSE ' (' || GRID_DESCRIP || ')' END AS CD_NM
          FROM TB_AD_USER_PREF_MST
         WHERE VIEW_CD = P_TYPE
           AND AUTO_CREATE_YN = 'Y'
         ORDER BY GRID_CD ASC
    ;        

    ELSIF p_GRP_CD = 'BUCKET' -- UI_ID : DP_07, DP_21, DP_28, DP_29, DP_30
      THEN
        OPEN pRESULT
        FOR
            SELECT 'YEAR'         AS CD
                  ,'Year'         AS CD_NM
                  ,'Y'            AS CD_ID
                  ,1              AS SEQ
            FROM dual      UNION ALL
            SELECT 'MONTH'        AS CD
                  ,'Month'        AS CD_NM
                  , 'M'           AS CD_ID
                  ,2              AS SEQ
            FROM dual      UNION ALL
            SELECT 'WEEK'         AS CD
                  ,'Week'         AS CD_NM
                  ,'W'            AS CD_ID 
                  ,3              AS SEQ 
            FROM dual      UNION ALL
            SELECT 'PAR_WEEK'     AS CD
                  ,'Partial Week' AS CD_NM
                  ,'PW'           AS CD_ID 
                  ,4              AS SEQ
            FROM dual     -- UNION ALL
--            SELECT 'DAY'          AS CD
--                  ,'Day'          AS CD_NM
--                  ,'D'            AS CD_ID   
--                  ,5              AS SEQ
--             FROM dual
         ;
    ELSIF p_GRP_CD = 'BUCKET_REPORT' -- UI_ID : DP_28, DP_29, DP_30  Month Week
      THEN
        OPEN pRESULT
        FOR
            SELECT 'MONTH'   AS CD
                  ,'Month'   AS CD_NM
                  , 'M'      AS CD_ID
                 ,2   AS SEQ
            FROM dual      UNION ALL
            SELECT 'WEEK'   AS CD
                  ,'Week'   AS CD_NM
                  ,'W'      AS CD_ID 
                  ,3   AS SEQ
            FROM dual
         ;
    ELSIF P_GRP_CD = 'DP_PLAN_TYPE' -- UI_ID : DP_07, DP_21, DP_22, DP_23, DP_24, DP_25, DP_26, DP_28, DP_29, DP_30, DP_31, DP_36, DP_38, DP_40,...... 
      THEN
        OPEN pRESULT
        FOR
				WITH PLAN_POLICY
				  AS (
					SELECT P.PLAN_TP_ID, P.POLICY_VAL
						  ,CASE P.POLICY_VAL  
						    WHEN 'Y' THEN 4 
							WHEN 'M'  THEN 3
							WHEN 'W'  THEN 2
							WHEN 'PW' THEN 1
							WHEN 'D'  THEN 0
						  END	AS SEQ 
					 FROM TB_DP_PLAN_POLICY	P
						  INNER JOIN 
						  TB_CM_COMM_CONFIG C
					   ON P.POLICY_ID = C.ID 
					WHERE C.CONF_CD = 'B'
					), START_MONTH
					AS (
						SELECT PLAN_TP_ID, POLICY_VAL 
						  FROM TB_DP_PLAN_POLICY	P
								  INNER JOIN 
								  TB_CM_COMM_CONFIG C
							   ON P.POLICY_ID = C.ID 
							WHERE C.CONF_CD = 'SM'					
					)
					SELECT    B.ID         AS ID
							, B.CONF_GRP_CD
							, B.CONF_CD    AS CD
							, B.CONF_NM    AS CD_NM
							, B.PRIORT
							, B.ATTR_01
							, CASE P.POLICY_VAL 
								WHEN 'W'  THEN 'WEEK'
								WHEN 'PW' THEN 'PAR_WEEK'
								WHEN 'M'  THEN 'MONTH'
								WHEN 'D'  THEN 'DAY'
								WHEN 'Y'  THEN 'YEAR' END AS BUCKET
							,CASE WHEN SEQ = (SELECT MIN(SEQ) FROM PLAN_POLICY) THEN 'Y' ELSE 'N' END AS LEAF_BUKT_YN 
                            ,S.POLICY_VAL AS SM
							FROM   TB_CM_COMM_CONFIG B
								   INNER JOIN 
									PLAN_POLICY P
								ON  B.ID = P.PLAN_TP_ID 
								  INNER JOIN 
								  START_MONTH S
							   ON P.PLAN_TP_ID = S.PLAN_TP_ID 
								where  1=1 -- A.MODULE_CD = 'DP'
								AND B.CONF_GRP_CD LIKE  '%' || P_GRP_CD || '%'  --'DP_LV_TP'
                                AND B.CONF_CD LIKE  '%' || p_TYPE || '%' 
								AND B.ACTV_YN = 'Y'
						ORDER BY PRIORT ASC;
        
    ELSIF P_GRP_CD = 'DP_PRICE_TYPE' -- UI_ID : DP_20, DP_21, DP_23
      THEN
        OPEN pRESULT
        FOR 
        SELECT B.ID         AS ID
             , B.CONF_GRP_CD
             , B.CONF_CD    AS CD
             , B.CONF_NM    AS CD_NM
             , B.PRIORT
          FROM TB_CM_CONFIGURATION A
             , TB_CM_COMM_CONFIG B
         WHERE 1 = 1
           AND A.ID = B.CONF_ID
           AND B.CONF_GRP_CD LIKE '%' || P_GRP_CD || '%'
           AND B.ACTV_YN = 'Y'
         ORDER BY B.PRIORT ASC, B.CONF_CD ASC;
     
        /*
        SELECT  A.ID
            , A.CONF_GRP_CD
            , A.CD
            , A.CD_NM
            , A.DESCRIP 
        FROM (
                SELECT  NULL  AS ID
                      , NULL    AS CONF_GRP_CD
                      , UPPER(P_TYPE)  AS CD
                      , UPPER(P_TYPE)  AS CD_NM
                      , NULL    AS DESCRIP
                      ,0        AS PRORTY
                FROM dual      
                WHERE UPPER(P_TYPE) = 'ALL'                       
            UNION ALL
            SELECT  B.ID  AS ID
                , B.CONF_GRP_CD
                , B.CONF_CD AS CD
                , B.CONF_NM  AS CD_NM
                , B.DESCRIP  AS DESCRIP
                , ROW_NUMBER() OVER (ORDER BY B.CREATE_DTTM DESC, B.CONF_CD DESC) AS PRORTY
               -- , B.PRIORT AS PRIORT
              FROM   TB_CM_CONFIGURATION A
                , TB_CM_COMM_CONFIG B
                 where  1=1 
                   AND A.ID = B.CONF_ID
                   AND B.CONF_GRP_CD LIKE  '%' || p_GRP_CD || '%' 
                   AND B.ACTV_YN = 'Y'
                   AND (P_LOCALE = 'DP_PLAN_YEARLY'  AND B.CONF_CD LIKE 'B%'
                   OR   P_LOCALE = 'DP_PLAN_MONTHLY' AND B.CONF_CD LIKE 'S%'
                   OR   P_LOCALE = 'DP_PLAN_WEEKLY'  AND B.CONF_CD LIKE 'B%'
                   OR   P_LOCALE IS NULL
                   )                                  
            ) A            
        ORDER BY A.PRORTY ASC, A.CD ASC
        ;
        */

    ELSIF (P_GRP_CD = 'DP_MS_QTY_TP') THEN
        OPEN pRESULT
        FOR
        SELECT B.ID AS ID
             , B.CONF_GRP_CD
             , B.CONF_CD AS CD
             , B.CONF_NM AS CD_NM
             , B.PRIORT
             , B.DESCRIP
          FROM TB_CM_CONFIGURATION A
             , TB_CM_COMM_CONFIG B
         WHERE 1 = 1
           AND A.ID = B.CONF_ID
           AND B.CONF_GRP_CD LIKE '%' || 'DP_MS_VAL_TP' || '%'
           AND B.ACTV_YN = 'Y'
           AND SUBSTR(B.CONF_CD, 0, 3) = 'QTY'
         ORDER BY PRIORT ASC;
    ELSIF (P_GRP_CD = 'BF_SELECT_CRITERIA') THEN
        OPEN pRESULT
        FOR
        SELECT CONF_CD AS CD
          FROM TB_CM_COMM_CONFIG
         WHERE CONF_GRP_CD = P_GRP_CD
         ORDER BY PRIORT;
		ELSIF (P_GRP_CD = 'DP_LV_TP_I') -- 2021.08 add 
        THEN
        OPEN pRESULT FOR
				SELECT  B.ID  AS ID
						, B.CONF_GRP_CD  
						, B.CONF_CD AS CD 
						, B.CONF_NM  AS CD_NM
						, B.PRIORT
						, B.DESCRIP
 					FROM  TB_CM_COMM_CONFIG B
				   where  B.CONF_GRP_CD = 'DP_LV_TP' AND B.ACTV_YN = 'Y' AND CONF_CD like 'I%'
				          and case when P_TYPE = 'EXTRA' then 'I' else ' ' end != CONF_CD
				ORDER BY PRIORT
                ;
		ELSIF (P_GRP_CD = 'DP_LV_TP_S') -- 2021.08 add
        THEN 
        OPEN pRESULT FOR        
				SELECT  B.ID  AS ID
						, B.CONF_GRP_CD  
						, B.CONF_CD AS CD 
						, B.CONF_NM  AS CD_NM
						, B.PRIORT
						, B.DESCRIP
 					FROM  TB_CM_COMM_CONFIG B
				   where  B.CONF_GRP_CD = 'DP_LV_TP' AND B.ACTV_YN = 'Y' AND CONF_CD like 'S%'
				ORDER BY PRIORT
                ;         
    ELSE
        OPEN pRESULT
        FOR SELECT  A.ID
            , A.CONF_GRP_CD
            , A.CD
            , A.CD_NM
            , A.DESCRIP
        FROM (
            SELECT  ' '     AS ID
                  , ' '     AS CONF_GRP_CD
                  , p_TYPE  AS CD  
                  , p_TYPE  AS CD_NM
                  , 0       AS PRIORT
                  , NULL    AS DESCRIP
             FROM dual      
            WHERE UPPER(P_TYPE) IN ('ALL', 'NN')                       
            UNION ALL
            SELECT  B.ID             AS ID
                  , B.CONF_GRP_CD
                  , B.CONF_CD        AS CD
                  , B.CONF_NM        AS CD_NM
                  , B.PRIORT
                  , B.DESCRIP
              FROM  TB_CM_CONFIGURATION A
                 ,  TB_CM_COMM_CONFIG B
             where  1=1 
               AND  A.ID = B.CONF_ID
               AND  B.CONF_GRP_CD LIKE  '%' || p_GRP_CD || '%' -- DP_LV_TP, CM_COUNTRY, DP_CURRENCY_TYPE
               AND  B.ACTV_YN = 'Y'
            ) A            
        ORDER BY A.PRIORT ASC, A.CD ASC
        ;
    END IF;
END;
/

