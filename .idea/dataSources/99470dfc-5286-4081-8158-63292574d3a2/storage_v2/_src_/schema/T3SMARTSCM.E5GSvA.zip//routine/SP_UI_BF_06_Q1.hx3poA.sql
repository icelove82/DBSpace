create PROCEDURE                "SP_UI_BF_06_Q1"
(
    p_FROM_DATE DATE
  , p_TO_DATE   DATE
  , pRESULT     OUT SYS_REFCURSOR
)

IS 
/*
    Factor Management by Date

    History (Date / Writer / Comment)
    -- 2020.02.03 / kim sohee / Date parameter type datetime => date
    
*/
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
--SET NOCOUNT ON
BEGIN
    OPEN pRESULT
    FOR
    SELECT ID
         , BASE_DATE
         , FACTOR1 
         , FACTOR2
         , FACTOR3
         , FACTOR4
         , FACTOR5
         , FACTOR6
         , FACTOR7
         , FACTOR8
         , FACTOR9
         , FACTOR10
         , FACTOR11
         , FACTOR12
         , FACTOR13
         , FACTOR14
         , FACTOR15
         , FACTOR16
         , FACTOR17
         , FACTOR18
         , FACTOR19
         , FACTOR20
         , MODIFY_BY
         , MODIFY_DTTM
      FROM TB_BF_DATE_FACTOR
     WHERE 1=1
       AND BASE_DATE BETWEEN p_FROM_DATE AND p_TO_DATE
     ORDER BY BASE_DATE ASC
     ;
END
;
/

