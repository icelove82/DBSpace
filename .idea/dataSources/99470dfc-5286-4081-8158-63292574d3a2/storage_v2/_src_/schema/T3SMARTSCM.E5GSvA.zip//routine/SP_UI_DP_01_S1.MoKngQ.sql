create PROCEDURE                SP_UI_DP_01_S1  (
    P_ID                 IN   VARCHAR2    := ''
  , P_MODULE_CD          IN   VARCHAR2    := ''         
  , P_GRP_CONF_NM        IN   VARCHAR2    := ''    -- GRP_CONF_CD                                          
  , P_CONF_KEY           IN   VARCHAR2    := ''    -- CONF_KEY      
  , P_DESCRIP            IN   VARCHAR2     := ''
  , P_USER_ID            IN   VARCHAR2    := ''  
  , P_RT_ROLLBACK_FLAG   OUT  VARCHAR2     
  , P_RT_MSG             OUT  VARCHAR2     
) 
IS
    P_ERR_STATUS        INT := 0;
    P_ERR_MSG           VARCHAR2(4000):='';
    P_DEFAULT_TYPE      VARCHAR2(10) := '';
    V_CONF_KEY          VARCHAR(50) := '';
    V_CHECK             INT :=0; 
    V_GRP_CONF_NM_PREV  VARCHAR2(50) := '';
BEGIN
/**(1) MODULE CD, MODULE NM Validation **********************************************/
    P_RT_ROLLBACK_FLAG := 'true';
    IF (P_MODULE_CD IS NULL) THEN
        P_ERR_MSG := 'MSG_5024';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); -- RAISERROR (P_ERR_MSG,12, 1);        
    END IF;
/**(2) CONF KEY Validation *********************************************************/

    SELECT COUNT(MODULE_CD)
      INTO V_CHECK
      FROM TB_CM_CONFIGURATION
     WHERE ID = P_ID;
 
    IF V_CHECK > 0 THEN
        SELECT MODULE_CD INTO P_DEFAULT_TYPE            
          FROM TB_CM_CONFIGURATION
         WHERE ID = P_ID;
    ELSE
        P_DEFAULT_TYPE := NULL;
    END IF;
 
    IF(P_MODULE_CD != P_DEFAULT_TYPE OR P_DEFAULT_TYPE IS NULL) THEN
        SELECT CASE COUNT(C.CONF_KEY)
               WHEN 0 THEN 101
               ELSE MAX(C.CONF_KEY)+1
               END
          INTO V_CONF_KEY
          FROM TB_AD_COMN_GRP A
         INNER JOIN TB_AD_COMN_CODE B
            ON (A.ID = B.SRC_ID)
         INNER JOIN TB_CM_CONFIGURATION C
            ON (C.MODULE_CD = B.COMN_CD)
         WHERE 1=1
           AND A.GRP_CD = 'MODULE_TP'
           AND B.COMN_CD = P_MODULE_CD
        ;
    ELSE
        SELECT C.CONF_KEY INTO V_CONF_KEY
          FROM TB_AD_COMN_GRP A
         INNER JOIN TB_AD_COMN_CODE B
            ON (A.ID = B.SRC_ID)
         INNER JOIN TB_CM_CONFIGURATION C
            ON (C.MODULE_CD = B.COMN_CD)
         WHERE 1=1
           AND A.GRP_CD = 'MODULE_TP'
           AND C.ID =  P_ID
        ;
    END IF;

    IF (V_CONF_KEY IS NULL) THEN
        P_ERR_MSG := 'MSG_5025';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG);  -- RAISERROR (P_ERR_MSG,12, 1);
    END IF;

/***(3) GRP CONF NM Validation *****************************************************/
    SELECT COUNT(A.CONF_NM) INTO P_ERR_STATUS
      FROM TB_CM_CONFIGURATION A
           INNER JOIN
           TB_AD_COMN_CODE B
        ON (A.MODULE_CD = B.COMN_CD)
           INNER JOIN
           TB_AD_COMN_GRP C
        ON (B.SRC_ID = C.ID)
     WHERE 1=1
       AND A.MODULE_CD = P_MODULE_CD
       AND C.GRP_CD = 'MODULE_TP'
       AND A.CONF_NM = P_GRP_CONF_NM
       AND CONF_KEY != V_CONF_KEY;
   
    IF(P_ERR_STATUS != 0) THEN
        P_ERR_MSG := 'MSG_5026';
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); -- RAISERROR (P_ERR_MSG,12, 1);
    END IF;

    MERGE INTO TB_CM_CONFIGURATION TGT        
    USING ( SELECT
                 P_ID                               AS ID
                ,P_MODULE_CD                        AS MODULE_CD       
                ,P_GRP_CONF_NM                      AS CONF_CD   
                ,V_CONF_KEY                         AS CONF_KEY        
                ,UPPER(P_GRP_CONF_NM) || '_DESCRIP' AS DESCRIP
                ,P_USER_ID                          AS USER_ID
            FROM dual
          ) SRC
    ON (TGT.ID = SRC.ID)
    WHEN MATCHED THEN
        UPDATE       
           SET TGT.MODULE_CD    = P_MODULE_CD
             , TGT.CONF_NM      = P_GRP_CONF_NM
             , TGT.DESCRIP      = P_DESCRIP
             , TGT.MODIFY_BY    = P_USER_ID
             , TGT.MODIFY_DTTM  = SYSDATE
    WHEN NOT MATCHED THEN
        INSERT (
               ID
             , MODULE_CD
             , CONF_KEY
             , CONF_NM
             , DESCRIP
             , CREATE_BY
             , CREATE_DTTM
             , MODIFY_BY
             , MODIFY_DTTM
               )
        VALUES(
               TO_SINGLE_BYTE(SYS_GUID()) 
             , P_MODULE_CD
             , V_CONF_KEY
             , P_GRP_CONF_NM
             , SRC.DESCRIP
             , P_USER_ID
             , SYSDATE()
             , NULL
             , NULL
              )
    ;

    MERGE INTO TB_AD_LANG_PACK TGT
    USING(
        SELECT UPPER(P_GRP_CONF_NM)||'_DESCRIP' AS LANG_KEY
             , P_DESCRIP                        AS LANG_VALUE
             , 'en'                             AS LANG_CD
              FROM DUAL
         ) SRC 
    ON (SRC.LANG_KEY = TGT.LANG_KEY AND SRC.LANG_CD = TGT.LANG_CD)
    WHEN NOT MATCHED THEN
        INSERT (
               LANG_KEY
             , LANG_VALUE
             , LANG_CD
                )
        VALUES (
               SRC.LANG_KEY
             , SRC.LANG_VALUE
             , SRC.LANG_CD
                )
    ;

    SELECT COUNT(CONF_GRP_CD) INTO V_CHECK
      FROM TB_CM_COMM_CONFIG 
     WHERE CONF_ID = P_ID;
 
    IF (V_CHECK > 0) THEN
        SELECT CONF_GRP_CD INTO V_GRP_CONF_NM_PREV
          FROM TB_CM_COMM_CONFIG
         WHERE CONF_ID = P_ID
         GROUP BY CONF_GRP_CD;

        IF (V_GRP_CONF_NM_PREV != P_GRP_CONF_NM) THEN
            SELECT COUNT(A.LANG_KEY) INTO V_CHECK
              FROM TB_AD_LANG_PACK A
             WHERE A.LANG_CD = 'en' AND A.LANG_KEY LIKE 'CF_'||V_GRP_CONF_NM_PREV||'%';

            IF (V_CHECK>0) THEN
                UPDATE TB_AD_LANG_PACK A
                   SET A.LANG_KEY = REPLACE(A.LANG_KEY, V_GRP_CONF_NM_PREV, P_GRP_CONF_NM)
                 WHERE A.LANG_CD = 'en' AND A.LANG_KEY LIKE 'CF_'||V_GRP_CONF_NM_PREV||'%'
                ;
            END IF;

            UPDATE TB_CM_COMM_CONFIG
               SET CONF_GRP_CD = P_GRP_CONF_NM    
             WHERE CONF_ID = P_ID;
        END IF;
    END IF;

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';

EXCEPTION WHEN OTHERS THEN
    IF(SQLCODE = -20001) THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
--        SP_COMM_RAISE_ERR();              
        RAISE;
    END IF; 
END;
/

