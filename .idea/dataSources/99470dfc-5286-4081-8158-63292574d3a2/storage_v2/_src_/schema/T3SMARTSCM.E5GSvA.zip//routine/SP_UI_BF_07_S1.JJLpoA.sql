create PROCEDURE                "SP_UI_BF_07_S1" (
      P_ID                 CHAR
    , P_ACCOUNT_CD         VARCHAR2
    , P_ITEM_CD            VARCHAR2
    , P_BASE_DATE          DATE
    , P_SALES_FACTOR1      NUMBER 
    , P_SALES_FACTOR2      NUMBER 
    , P_SALES_FACTOR3      NUMBER 
    , P_SALES_FACTOR4      NUMBER 
    , P_SALES_FACTOR5      NUMBER 
    , P_SALES_FACTOR6      NUMBER 
    , P_SALES_FACTOR7      NUMBER 
    , P_SALES_FACTOR8      NUMBER 
    , P_SALES_FACTOR9      NUMBER 
    , P_SALES_FACTOR10     NUMBER 
    , P_SALES_FACTOR11     NUMBER 
    , P_SALES_FACTOR12     NUMBER 
    , P_SALES_FACTOR13     NUMBER 
    , P_SALES_FACTOR14     NUMBER 
    , P_SALES_FACTOR15     NUMBER 
    , P_SALES_FACTOR16     NUMBER 
    , P_SALES_FACTOR17     NUMBER 
    , P_SALES_FACTOR18     NUMBER 
    , P_SALES_FACTOR19     NUMBER 
    , P_SALES_FACTOR20     NUMBER 
    , P_USER_ID            VARCHAR2
    , P_RT_ROLLBACK_FLAG   OUT VARCHAR2 
    , P_RT_MSG             OUT VARCHAR2 
) 
IS
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

    P_ERR_STATUS    NUMBER          := 0;
    P_ERR_MSG       VARCHAR2(4000)  := '';

BEGIN
    MERGE INTO TB_BF_SALES_FACTOR TAR
    USING ( 
            SELECT  P_ID                   AS ID           
                  , P_BASE_DATE            AS BASE_DATE    
                  , P_ACCOUNT_CD           AS ACCOUNT_CD
                  , P_ITEM_CD              AS ITEM_CD
                  , P_SALES_FACTOR1        AS SALES_FACTOR1    
                  , P_SALES_FACTOR2        AS SALES_FACTOR2    
                  , P_SALES_FACTOR3        AS SALES_FACTOR3    
                  , P_SALES_FACTOR4        AS SALES_FACTOR4    
                  , P_SALES_FACTOR5        AS SALES_FACTOR5    
                  , P_SALES_FACTOR6        AS SALES_FACTOR6    
                  , P_SALES_FACTOR7        AS SALES_FACTOR7    
                  , P_SALES_FACTOR8        AS SALES_FACTOR8    
                  , P_SALES_FACTOR9        AS SALES_FACTOR9    
                  , P_SALES_FACTOR10       AS SALES_FACTOR10   
                  , P_SALES_FACTOR11       AS SALES_FACTOR11   
                  , P_SALES_FACTOR12       AS SALES_FACTOR12   
                  , P_SALES_FACTOR13       AS SALES_FACTOR13   
                  , P_SALES_FACTOR14       AS SALES_FACTOR14   
                  , P_SALES_FACTOR15       AS SALES_FACTOR15   
                  , P_SALES_FACTOR16       AS SALES_FACTOR16   
                  , P_SALES_FACTOR17       AS SALES_FACTOR17   
                  , P_SALES_FACTOR18       AS SALES_FACTOR18   
                  , P_SALES_FACTOR19       AS SALES_FACTOR19   
                  , P_SALES_FACTOR20       AS SALES_FACTOR20   
                  , P_USER_ID      AS USER_ID
            FROM DUAL
          ) SRC
    ON    (TAR.ID            = SRC.ID)
    WHEN MATCHED THEN
         UPDATE 
           SET   TAR.BASE_DATE          = SRC.BASE_DATE
                ,TAR.ACCOUNT_CD         = SRC.ACCOUNT_CD
                ,TAR.ITEM_CD            = SRC.ITEM_CD
                ,TAR.SALES_FACTOR1      = SRC.SALES_FACTOR1 
                ,TAR.SALES_FACTOR2      = SRC.SALES_FACTOR2 
                ,TAR.SALES_FACTOR3      = SRC.SALES_FACTOR3 
                ,TAR.SALES_FACTOR4      = SRC.SALES_FACTOR4 
                ,TAR.SALES_FACTOR5      = SRC.SALES_FACTOR5 
                ,TAR.SALES_FACTOR6      = SRC.SALES_FACTOR6 
                ,TAR.SALES_FACTOR7      = SRC.SALES_FACTOR7 
                ,TAR.SALES_FACTOR8      = SRC.SALES_FACTOR8 
                ,TAR.SALES_FACTOR9      = SRC.SALES_FACTOR9 
                ,TAR.SALES_FACTOR10     = SRC.SALES_FACTOR10    
                ,TAR.SALES_FACTOR11     = SRC.SALES_FACTOR11    
                ,TAR.SALES_FACTOR12     = SRC.SALES_FACTOR12    
                ,TAR.SALES_FACTOR13     = SRC.SALES_FACTOR13    
                ,TAR.SALES_FACTOR14     = SRC.SALES_FACTOR14    
                ,TAR.SALES_FACTOR15     = SRC.SALES_FACTOR15    
                ,TAR.SALES_FACTOR16     = SRC.SALES_FACTOR16    
                ,TAR.SALES_FACTOR17     = SRC.SALES_FACTOR17    
                ,TAR.SALES_FACTOR18     = SRC.SALES_FACTOR18    
                ,TAR.SALES_FACTOR19     = SRC.SALES_FACTOR19    
                ,TAR.SALES_FACTOR20     = SRC.SALES_FACTOR20    
                ,TAR.MODIFY_BY      = SRC.USER_ID
                ,TAR.MODIFY_DTTM    = (SELECT SYSDATE FROM DUAL)
    WHEN NOT MATCHED THEN 
         INSERT (
                  ID            
                , BASE_DATE 
                , ACCOUNT_CD
                , ITEM_CD
                , SALES_FACTOR1 
                , SALES_FACTOR2 
                , SALES_FACTOR3 
                , SALES_FACTOR4 
                , SALES_FACTOR5 
                , SALES_FACTOR6 
                , SALES_FACTOR7 
                , SALES_FACTOR8 
                , SALES_FACTOR9 
                , SALES_FACTOR10    
                , SALES_FACTOR11    
                , SALES_FACTOR12    
                , SALES_FACTOR13    
                , SALES_FACTOR14    
                , SALES_FACTOR15    
                , SALES_FACTOR16    
                , SALES_FACTOR17    
                , SALES_FACTOR18    
                , SALES_FACTOR19    
                , SALES_FACTOR20    
                , CREATE_BY 
                , CREATE_DTTM
                ) 
         VALUES (
                 RAWTOHEX(SYS_GUID())
                ,SRC.BASE_DATE
                ,SRC.ACCOUNT_CD
                ,SRC.ITEM_CD
                ,SRC.SALES_FACTOR1
                ,SRC.SALES_FACTOR2
                ,SRC.SALES_FACTOR3
                ,SRC.SALES_FACTOR4
                ,SRC.SALES_FACTOR5
                ,SRC.SALES_FACTOR6
                ,SRC.SALES_FACTOR7
                ,SRC.SALES_FACTOR8
                ,SRC.SALES_FACTOR9
                ,SRC.SALES_FACTOR10
                ,SRC.SALES_FACTOR11
                ,SRC.SALES_FACTOR12
                ,SRC.SALES_FACTOR13
                ,SRC.SALES_FACTOR14
                ,SRC.SALES_FACTOR15
                ,SRC.SALES_FACTOR16
                ,SRC.SALES_FACTOR17
                ,SRC.SALES_FACTOR18
                ,SRC.SALES_FACTOR19
                ,SRC.SALES_FACTOR20
                ,SRC.USER_ID
                ,(SELECT SYSDATE FROM DUAL)
                ) 
    ;

    P_RT_ROLLBACK_FLAG  := 'true';
    P_RT_MSG            := 'MSG_0001';  --저장 되었습니다.

EXCEPTION WHEN OTHERS THEN
    IF (SQLERRM = P_ERR_MSG) THEN
        P_ERR_MSG := SQLERRM;
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;
    ELSE 
        RAISE_APPLICATION_ERROR (SQLCODE, SQLERRM);
--              EXEC SP_COMM_RAISE_ERR
   END IF;
END;
/

