create PROCEDURE SP_UI_CM_15_Q2 (
    P_MODULE_ID   IN VARCHAR2 := '',
    PRESULT       OUT SYS_REFCURSOR
)
IS

BEGIN
    OPEN PRESULT FOR 
    SELECT  A.ID,
		    A.COMN_CD AS MODULE_CD,
		    A.COMN_CD_NM AS MODULE_NM,
            A.VER_ID AS PLAN_POLICY_VER_ID,
            B.PLAN_POLICY_VAL_01 AS DESCP,
            C.PLAN_POLICY_NM AS PLAN_TYPE,
            A.CREATE_DTTM
      FROM  (
                SELECT
                    A.ID,
                    B.COMN_CD,
                    B.COMN_CD_NM,
                    A.VER_ID,
                    A.CREATE_DTTM,
                    C.PLAN_POLICY_VAL_01 AS MODULE_ID
                FROM
                    TB_CM_PLAN_POLICY_MGMT A
                    INNER JOIN TB_CM_PLAN_POLICY_VALUE C ON ( A.ID = C.PLAN_POLICY_MGMT_ID )
                    INNER JOIN TB_CM_PLAN_POLICY_MST D ON ( C.PLAN_POLICY_MST_ID = D.ID )
                    INNER JOIN TB_AD_COMN_CODE B ON ( C.PLAN_POLICY_VAL_01 = B.ID )
                WHERE
                    1 = 1
                    AND D.PLAN_POLICY_ITEM_ID = 'M00010000'
            ) A
            LEFT OUTER JOIN (
                SELECT
                    A.PLAN_POLICY_MGMT_ID,
                    A.PLAN_POLICY_VAL_01
                FROM
                    TB_CM_PLAN_POLICY_VALUE A,
                    TB_CM_PLAN_POLICY_MST B
                WHERE
                    1 = 1
                    AND A.PLAN_POLICY_MST_ID = B.ID
                    AND B.PLAN_POLICY_ITEM_ID = 'M00020000'
            ) B 
            ON ( A.ID = B.PLAN_POLICY_MGMT_ID )
            LEFT OUTER JOIN (
                SELECT
                    A.PLAN_POLICY_MGMT_ID,
                    C.PLAN_POLICY_NM
                FROM
                    TB_CM_PLAN_POLICY_VALUE A,
                    TB_CM_PLAN_POLICY_MST B,
                    TB_CM_PLAN_POLICY_DTL C
                WHERE
                    1 = 1
                    AND A.PLAN_POLICY_MST_ID = B.ID
                    AND B.PLAN_POLICY_ITEM_ID = 'M00030000'
                    AND A.PLAN_POLICY_DTL_ID = C.ID
            ) C 
            ON ( A.ID = C.PLAN_POLICY_MGMT_ID )
      WHERE A.MODULE_ID LIKE '%'|| P_MODULE_ID || '%'
      ORDER BY A.COMN_CD_NM, A.VER_ID;

END;

/

