create PROCEDURE                "SP_UI_DP_20_S1" (
    V_ACCOUNT_ID        IN  VARCHAR2     := ''         
  , p_ACCOUNT_CD        IN  VARCHAR2     := ''         
  , V_ITEM_MST_ID       IN  VARCHAR2     := ''      
  , p_ITEM_CD           IN  VARCHAR2     := ''      
  , p_BASE_DATE         IN  DATE         := NULL
  , p_UTPIC             IN  DECIMAL      := 0
  , P_PRICE_TP_CD       IN  VARCHAR2     := ''         
  , p_USER_ID           IN  VARCHAR2     := ''      
  , p_EMP_NO            IN  VARCHAR2     := ''      
  , p_AUTH_TP_ID        IN  VARCHAR2     := ''      
  , P_RT_ROLLBACK_FLAG  OUT VARCHAR2		 
  , P_RT_MSG            OUT VARCHAR2 		 
) 
IS
/*************************************************************************
    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / EMP_NO => USER_ID 
    - 2020.03.12 / Kim sohee / MSSQL Converting     
************************************************************************/           
		-- Paremeter
    V_ITEM_LV_ID     VARCHAR2(32)   := NULL;
    P_ERR_STATUS     INT            := 0;
    P_ERR_MSG        VARCHAR2(4000) :='';
    P_PRICE_TP_ID    CHAR(32);
    P_EMP_ID         CHAR(32);
    P_ACCOUNT_ID     CHAR(32)       := V_ACCOUNT_ID;
    P_ITEM_MST_ID    CHAR(32)       := V_ITEM_MST_ID;

BEGIN
    P_RT_ROLLBACK_FLAG := 'true';
/*** MESSAGE VALIDATION ******************************************************************************************************************************************************************/
-- Price type
    IF(p_PRICE_TP_ID IS NULL)
    THEN
    	SELECT ID INTO P_PRICE_TP_ID
    	  FROM TB_CM_COMM_CONFIG
    	 WHERE CONF_CD = p_PRICE_TP_CD;
    END IF;
-- Employee 
	SELECT ID INTO p_EMP_ID 
	  FROM TB_AD_USER
	WHERE USERNAME = p_EMP_NO
    ;
/* 1. */
    IF (p_ACCOUNT_ID IS NULL)
    THEN
        SELECT ID  INTO p_ACCOUNT_ID
          FROM TB_DP_ACCOUNT_MST
         WHERE ACCOUNT_CD = p_ACCOUNT_CD;
    END IF;


    IF (p_ITEM_MST_ID IS NULL)
    THEN
        SELECT ID  INTO P_ITEM_MST_ID
          FROM TB_CM_ITEM_MST
         WHERE ITEM_CD = P_ITEM_CD;
    END IF;

/********************************** Validation **************************************/
    IF (P_ACCOUNT_ID IS NULL)
	THEN
	    P_ERR_MSG := 'MSG_0015'; 
	    RAISE_APPLICATION_ERROR(-20000, P_ERR_MSG);		
	END IF;
	
    IF (P_ITEM_MST_ID IS NULL)
	THEN
	    P_ERR_MSG := 'MSG_0017'; 
	    RAISE_APPLICATION_ERROR(-20000, P_ERR_MSG);		
	END IF;
	
    SELECT count(*) INTO P_ERR_STATUS
      FROM TABLE(FN_DP_TEMP_USER_ITEM_ACCOUNT(P_EMP_ID, P_AUTH_TP_ID))
     WHERE ITEM_ID = P_ITEM_MST_ID
       AND ACCOUNT_ID = P_ACCOUNT_ID;
   
    IF P_ERR_STATUS = 0 THEN
        P_ERR_MSG := 'This Item, Account Mapping is not valid.';
        RAISE_APPLICATION_ERROR(-20000, P_ERR_MSG);
    END IF;
	

 /*** 본 프로시저 시작 *****************************************************************************************************************************************************************/
				MERGE INTO TB_DP_UNIT_PRICE TGT
				USING ( 
						SELECT
						  TO_SINGLE_BYTE(SYS_GUID())             AS  ID              
						,p_ACCOUNT_ID        AS  ACCOUNT_ID      
						,p_ITEM_MST_ID       AS  ITEM_MST_ID     
						,p_BASE_DATE         AS  BASE_DATE       
						,p_UTPIC             AS  UTPIC    
						,p_PRICE_TP_ID       AS  PRICE_TP_ID  
						,p_USER_ID           AS  USER_ID
						FROM DUAL
					  ) SRC
				ON (    TGT.ACCOUNT_ID  = SRC.ACCOUNT_ID
    				AND TGT.ITEM_MST_ID = SRC.ITEM_MST_ID
    				AND TGT.BASE_DATE   = SRC.BASE_DATE
    				AND TGT.PRICE_TP_ID = SRC.PRICE_TP_ID
				)
				WHEN MATCHED THEN
					 UPDATE 
					   SET   TGT.UTPIC         = SRC.UTPIC      
							,TGT.MODIFY_BY     = SRC.USER_ID       
							,TGT.MODIFY_DTTM   = SYSDATE      
				WHEN NOT MATCHED THEN 
					 INSERT (
							 ID          
							,ACCOUNT_ID 
							,ITEM_MST_ID
							,BASE_DATE  
							,UTPIC     
							,PRICE_TP_ID  -- CURCY_CD_ID
							,CREATE_BY
							,CREATE_DTTM
							) 
					 VALUES (
                             SRC.ID
							,SRC.ACCOUNT_ID    
							,SRC.ITEM_MST_ID   
							,SRC.BASE_DATE     
							,SRC.UTPIC    
							,SRC.PRICE_TP_ID     
							,SRC.USER_ID 
							,SYSDATE           
 							) 
		          ;    

    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';  
       /* ============================================================================*/
EXCEPTION WHEN OTHERS THEN  --  e_products_invalid    
    IF(SQLCODE = -20001)
    THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
    --SP_COMM_RAISE_ERR();              
        RAISE;
    END IF; 	

END;
/

