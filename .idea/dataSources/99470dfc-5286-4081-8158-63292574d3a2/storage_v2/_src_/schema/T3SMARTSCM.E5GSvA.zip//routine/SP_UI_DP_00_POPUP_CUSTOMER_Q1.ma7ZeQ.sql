create PROCEDURE                "SP_UI_DP_00_POPUP_CUSTOMER_Q1" (
    p_CUST_CD     IN VARCHAR2 := ''
  , p_CUST_NM     IN VARCHAR2 := ''
  , pRESULT       OUT SYS_REFCURSOR
) IS 

BEGIN

    OPEN pRESULT          
    FOR 
    SELECT DC.ID
          ,CUST_CD
          ,CUST_NM
          ,c.CONF_CD as COUNTRY_CD
          ,c.CONF_NM as COUNTRY_NM
          ,ADDR
          --,ATTR1
          --,ATTR2
          --,ATTR3
          --,ATTR4
          --,CREATE_BY
          --,CREATE_DTTM
          --,MODIFY_BY
          --,MODIFY_DTTM
      FROM TB_CM_CUSTOMER DC
      left outer join TB_CM_COMM_CONFIG c on c.id =  DC.COUNTRY_ID
     WHERE UPPER(DC.CUST_CD) LIKE '%' || UPPER(RTRIM(p_CUST_CD)) || '%'            
       AND UPPER(DC.CUST_NM) LIKE '%' || UPPER(RTRIM(p_CUST_NM)) || '%'            
       ORDER BY CUST_CD ASC
    ;

END
;
/

