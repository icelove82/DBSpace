create PROCEDURE "SP_UI_DP_23_MEASURE_Q1" 
(
 p_VERSION_ID  IN VARCHAR2 := ''
,p_START_DATE IN DATE
,p_END_DATE IN DATE
, pRESULT       OUT SYS_REFCURSOR
) 
IS 

    V_START_MONTH               CHAR(2);
    V_START_YEAR                CHAR(4);
    V_PLAN_TP_ID                CHAR(32);


BEGIN

       SELECT TO_CHAR(FROM_DATE,'YYYY') 
            , PLAN_TP_ID
         INTO V_START_YEAR
            , V_PLAN_TP_ID
         FROM TB_DP_CONTROL_BOARD_VER_MST 
        WHERE VER_ID = p_VERSION_ID             
        ; 

        SELECT LPAD(TO_NUMBER(A.POLICY_VAL), 2, '0') INTO V_START_MONTH
        FROM TB_DP_PLAN_POLICY A
        INNER JOIN TB_CM_COMM_CONFIG B ON B.CONF_GRP_CD ='DP_POLICY' AND B.CONF_CD = 'SM' AND A.POLICY_ID = B.ID       
        where PLAN_TP_ID = V_PLAN_TP_ID
        ;

OPEN pRESULT          
FOR 
                SELECT ITEM_CD
                     , ACCOUNT_CD
                     , BASE_DATE AS BASE_DATE
                     , SUM(BF_MEAS_QTY) AS BF_MEAS_QTY
                     , SUM(ACT_QTY) AS ACT_SALES_QTY
                     , SUM(ACT_AMT) AS ACT_SALES_AMT
                     , SUM(ANNUAL_QTY) AS ANNUAL_QTY
                     , SUM(ANNUAL_AMT) AS ANNUAL_AMT
                     , SUM(RTF_QTY) AS RTF_QTY
                     , SUM(YOY_QTY) AS YOY_QTY
                     , SUM(YTD_QTY) AS YTD_QTY
                  FROM
                      (
                        SELECT i.ITEM_CD AS ITEM_CD
                             , a.ACCOUNT_CD AS ACCOUNT_CD
                             , EX.BASE_DATE AS BASE_DATE
                             , EX.BF_MEAS_QTY
                             , NVL(S.QTY,0) AS ACT_QTY
                             , NVL(S.AMT,0) AS ACT_AMT
                             , EX.RTF_QTY
                             , EX.YOY_QTY
                             , EX.YTD_QTY
                             , EX.ANNUAL_QTY
                             , EX.ANNUAL_AMT
                          FROM TB_DP_MEASURE_DATA EX
                              INNER JOIN TB_CM_ITEM_MST i ON i.id = ex.item_mst_id and i.dp_plan_yn = 'Y'
                              INNER JOIN TB_DP_ACCOUNT_MST a ON i.id = ex.item_mst_id and a.actv_yn = 'Y'
                              LEFT OUTER JOIN TB_CM_ACTUAL_SALES         S  ON (S.ACCOUNT_ID = EX.ACCOUNT_ID AND S.ITEM_MST_ID = EX.ITEM_MST_ID AND S.BASE_DATE = EX.BASE_DATE)
                          WHERE 1=1
                          AND EX.BASE_DATE BETWEEN p_START_DATE AND p_END_DATE
                      )
		          	 GROUP BY ITEM_CD, ACCOUNT_CD, base_date
                          ;

END
;
/

