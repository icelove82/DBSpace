create PROCEDURE "SP_COMM_SRH_LOCAT_Q" (
    pResult OUT SYS_REFCURSOR
)
IS

BEGIN
	
    OPEN pResult FOR
    SELECT  B.ID			AS LOCAT_MST_ID
            ,B.LOCAT_TP_ID 
            ,A.COMN_CD_NM	    AS LOCAT_TP_NM
            ,B.LOCAT_LV
            ,C.ID			    AS LOCAT_ID
            ,C.LOCAT_CD
            ,C.LOCAT_NM
            ,D.ID			    AS LOCAT_MGMT_ID
       FROM  TB_AD_COMN_CODE A 
         INNER JOIN TB_CM_LOC_MST   B  
           ON A.ID = B.LOCAT_TP_ID
         INNER JOIN TB_CM_LOC_DTL   C   
           ON B.ID = C.LOCAT_MST_ID
         INNER JOIN TB_CM_LOC_MGMT  D   
           ON C.ID = D.LOCAT_ID 
       WHERE 1=1
        AND B.ACTV_YN = 'Y'
        AND C.ACTV_YN = 'Y'
        AND D.ACTV_YN = 'Y'
      ORDER BY A.SEQ, B.LOCAT_LV, C.LOCAT_CD;

END;

/

