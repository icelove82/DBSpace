create PROCEDURE                SP_UI_DP_21_S1 (
    p_ACCOUNT_CD        IN  VARCHAR2     := ''         
  , p_ITEM_CD           IN  VARCHAR2     := ''      
  , p_BASE_DATE         IN  DATE         := NULL
  , p_UTPIC             IN  DECIMAL      := 0
  , p_PRICE_TP_CD       IN  VARCHAR2     := ''         
  , p_USER_ID           IN  VARCHAR2     := ''      
  , P_RT_ROLLBACK_FLAG  OUT VARCHAR2  
  , P_RT_MSG            OUT VARCHAR2 
) 
IS
    P_CNT           INT := 0;
    P_ERR_MSG       VARCHAR2(4000):='';
    p_ACCOUNT_ID    VARCHAR2(4000):='';   
    p_ITEM_ID       VARCHAR2(4000):='';   
    P_PRICE_TP_ID   CHAR(32);
BEGIN

    SELECT ID INTO p_ACCOUNT_ID 
      FROM TB_DP_ACCOUNT_MST  
     WHERE 1=1
       AND ACCOUNT_CD = p_ACCOUNT_CD
       AND COALESCE(DEL_YN, 'N') = 'N'
       AND ACTV_YN = 'Y';
   
    SELECT ID INTO p_ITEM_ID 
      FROM TB_CM_ITEM_MST 
     WHERE 1=1
       AND ITEM_CD = p_ITEM_CD
       AND COALESCE(DEL_YN, 'N') = 'N'
       AND DP_PLAN_YN = 'Y';
   
    SELECT ID INTO P_PRICE_TP_ID
      FROM TB_CM_COMM_CONFIG
     WHERE CONF_CD = P_PRICE_TP_CD;

  /* 1.  */
    IF (p_ACCOUNT_ID IS NULL)
    THEN
        P_ERR_MSG := 'MSG_0015' ;
        RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); 		
    END IF;
    
    IF (p_ITEM_ID IS NULL)
    THEN
       P_ERR_MSG := 'MSG_0017' ;
       RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); 			
    END IF;

    IF (p_BASE_DATE IS NULL)
    THEN
       P_ERR_MSG := 'MSG_0006' ;
       RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); 			
    END IF;

    IF (p_PRICE_TP_ID IS NULL)
    THEN
       P_ERR_MSG := 'MSG_0006' ;
       RAISE_APPLICATION_ERROR(-20001, P_ERR_MSG); 			
    END IF;

    /* MERGE */
    
    MERGE INTO TB_DP_UNIT_PRICE TGT
    USING ( 
        SELECT p_ACCOUNT_ID     AS  ACCOUNT_ID
             , p_ITEM_ID        AS  ITEM_ID
             , p_BASE_DATE      AS  BASE_DATE
             , p_UTPIC          AS  UTPIC
             , p_PRICE_TP_ID    AS  PRICE_TP_ID
             , p_USER_ID        AS  USER_ID
          FROM DUAL
    ) SRC
    ON (    TGT.ACCOUNT_ID  = SRC.ACCOUNT_ID 
        AND TGT.ITEM_MST_ID = SRC.ITEM_ID
        AND TGT.BASE_DATE   = SRC.BASE_DATE
        AND TGT.PRICE_TP_ID = SRC.PRICE_TP_ID)
    WHEN MATCHED THEN
        UPDATE 
           SET TGT.UTPIC        = SRC.UTPIC      
             , TGT.MODIFY_BY    = SRC.USER_ID       
             , TGT.MODIFY_DTTM  = SYSDATE 
    WHEN NOT MATCHED THEN 
        INSERT (
            ID          
          , ACCOUNT_ID 
          , ITEM_MST_ID
          , BASE_DATE  
          , UTPIC      
          , PRICE_TP_ID  
          , CREATE_BY
          , CREATE_DTTM
        ) 
        VALUES (
            TO_SINGLE_BYTE(SYS_GUID()) 
          , SRC.ACCOUNT_ID
          , SRC.ITEM_ID
          , SRC.BASE_DATE     
          , SRC.UTPIC         
          , SRC.PRICE_TP_ID
          , SRC.USER_ID 
          , SYSDATE           
        ) 
    ;    
      
    P_RT_ROLLBACK_FLAG := 'true';
    P_RT_MSG := 'MSG_0001';  

/* ============================================================================*/
EXCEPTION WHEN OTHERS THEN  --  e_products_invalid    
    IF(SQLCODE = -20001)
    THEN
        P_RT_ROLLBACK_FLAG := 'false';
        P_RT_MSG := P_ERR_MSG;   
    ELSE
      --SP_COMM_RAISE_ERR();              
        RAISE;
    END IF; 	

END;
/

