create PROCEDURE SP_UI_CM_01_POP_334_S(
    P_WRK_TYPE             IN VARCHAR2 := ''
   ,P_ID                   IN CHAR := ''
   ,P_CONF_CD              IN VARCHAR2 := ''
   ,P_CONF_NM              IN VARCHAR2 := ''
   ,P_ACTV_YN              IN CHAR := ''
   ,P_DESCRIP              IN VARCHAR2 := ''
   ,P_USER_ID              IN VARCHAR2 := ''
   ,P_RT_ROLLBACK_FLAG     OUT VARCHAR2
   ,P_RT_MSG               OUT VARCHAR2
)IS
    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';
    P_CNT     INT := 0;
    BEGIN
        
        IF P_WRK_TYPE = 'SAVE'
        THEN
            P_ERR_MSG := 'MSG_0006';
            IF P_CONF_CD IS NULL OR P_CONF_NM IS NULL
                THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;
            P_ERR_MSG := 'MSG_0013';
            SELECT COUNT(*) INTO P_CNT FROM TB_CM_CONFIGURATION A, TB_CM_COMM_CONFIG B WHERE A.CONF_KEY = '334' AND A.ID = B.CONF_ID AND B.CONF_CD = P_CONF_CD;
            IF P_CNT > 0
                THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG); END IF;
            MERGE INTO TB_CM_COMM_CONFIG A
            USING(
                SELECT P_ID      AS ID
                      ,P_CONF_CD AS CONF_CD
                      ,P_CONF_NM AS CONF_NM
                      ,P_ACTV_YN AS ACTV_YN
                      ,P_DESCRIP AS DESCRIP
                      ,P_USER_ID AS USER_ID
                FROM DUAL
            )B 
            ON(A.ID = B.ID)
            WHEN MATCHED THEN
            UPDATE
            SET A.CONF_NM = B.CONF_NM
               ,A.DESCRIP = B.DESCRIP
               ,A.ACTV_YN = B.ACTV_YN
               ,A.MODIFY_BY = B.USER_ID
               ,A.MODIFY_DTTM = SYSDATE
            WHEN NOT MATCHED THEN
            INSERT (
                ID
               ,CONF_ID
               ,CONF_GRP_CD
               ,CONF_CD
               ,CONF_NM
               ,DEFAT_VAL
               ,ACTV_YN
               ,USE_YN
               ,DESCRIP
               ,CREATE_BY
               ,CREATE_DTTM
            )
            VALUES(
                TO_SINGLE_BYTE(SYS_GUID()),
                (SELECT ID FROM TB_CM_CONFIGURATION WHERE CONF_KEY ='334'),
                (SELECT CONF_NM FROM TB_CM_CONFIGURATION WHERE CONF_KEY ='334'),
                B.CONF_CD,
                B.CONF_NM,
                'N',
                B.ACTV_YN,
                'Y',
                B.DESCRIP,
                B.USER_ID,
                SYSDATE
            );
            P_RT_ROLLBACK_FLAG := 'true';
            P_RT_MSG := 'MSG_0001';
        ELSIF P_WRK_TYPE ='DELETE'
        THEN
            DELETE TB_CM_COMM_CONFIG
            WHERE ID = P_ID;
            
            P_RT_ROLLBACK_FLAG := 'true';
            P_RT_MSG := 'MSG_0002';
        END IF;
EXCEPTION
	WHEN OTHERS THEN
		P_RT_ROLLBACK_FLAG := 'false';
		IF(SQLCODE = -20012)
		  THEN
			  P_RT_MSG := P_ERR_MSG;
		  ELSE
			  P_RT_MSG := SQLERRM;
		  END IF;
    END;

/

