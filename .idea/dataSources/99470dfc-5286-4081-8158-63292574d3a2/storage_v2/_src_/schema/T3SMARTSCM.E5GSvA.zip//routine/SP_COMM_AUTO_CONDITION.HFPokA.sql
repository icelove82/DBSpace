create PROCEDURE SP_COMM_AUTO_CONDITION (
    R_RT_MSG           OUT VARCHAR2
)
IS
    V_CALL_YN       CHAR(1);

BEGIN
	/** Add logic for Engine execution condition **/
	SELECT	A.ATTR_01_VAL INTO V_CALL_YN
	FROM	TB_AD_COMN_CODE A
	WHERE	A.COMN_CD = 'MP_ENGINE_CALL_FLAG';

	IF NVL(V_CALL_YN, 'N') = 'Y' THEN
		R_RT_MSG := 'TRUE'; -- This setting should not be changed.
	ELSE
		R_RT_MSG := 'The engine cannot be run.'; -- Enter a message to be displayed when it cannot be executed.
    END IF;

EXCEPTION
WHEN OTHERS THEN
    RAISE;
END;
/

