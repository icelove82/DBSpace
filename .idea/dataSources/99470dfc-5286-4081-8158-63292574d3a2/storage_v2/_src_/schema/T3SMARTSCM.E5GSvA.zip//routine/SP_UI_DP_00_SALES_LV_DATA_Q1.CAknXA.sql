create PROCEDURE                "SP_UI_DP_00_SALES_LV_DATA_Q1" (
    p_LEAF_TP               IN  VARCHAR2 := '' 
  , p_TYPE                  IN  VARCHAR2 := '' 
  , P_LV_CD                 IN  VARCHAR2 := '' 
  , p_SALES_LV_CD           IN  VARCHAR2 := '' 
  , p_SALES_LV_NM           IN  VARCHAR2 := '' 
  , P_PARENT_SALES_LV_CD    IN  VARCHAR2 := '' 
  , pRESULT                 OUT SYS_REFCURSOR
) IS 

    V_LEAF_TP VARCHAR(2) := 'N';
    v_LV_TP   varchar2(100) :=  'S';

BEGIN
    IF p_LEAF_TP = 'LEAF'   
    THEN
        V_LEAF_TP := 'Y' ;
    END IF;
    
    IF (p_TYPE like '%AD%') THEN
        SELECT CONF_CD into v_LV_TP from TB_CM_COMM_CONFIG where CONF_GRP_CD = 'DP_LV_TP' and conf_cd like 'S%' and ATTR_01 like '%'|| p_TYPE ;
    END IF;


   /*
   EXCEPTION
    	WHEN NO_DATA_FOUND THEN
        	v_LV_TP := 'E';
*/
    OPEN pRESULT          
    FOR
    SELECT * 
      FROM ( 
            SELECT ''   AS ID 
                 , P_TYPE   AS SALES_LV_CD
                 , P_TYPE   AS SALES_LV_NM
                 , 0    AS SEQ
                 , NULL AS LV_MGMT_ID
                 , NULL AS LV_CD
                 , NULL AS LV_NM
                 , 0    AS LV_SEQ
                 , NULL AS PARENT_SALES_LV_ID
                 , NULL AS PARENT_SALES_LV_CD
                 , NULL AS PARENT_SALES_LV_NM
                 , NULL AS CURCY_CD_ID
                 , NULL AS CURCY_CD_NM
                 , NULL AS ACTV_YN
              FROM dual      
             WHERE 'ALL' = UPPER(P_TYPE) 
            UNION ALL 
            SELECT SL.ID
                  ,SL.SALES_LV_CD        AS SALES_LV_CD 
                  ,SL.SALES_LV_NM        AS SALES_LV_NM 
                  ,SL.SEQ
                  ,SL.LV_MGMT_ID
                  ,LM.LV_CD
                  ,LM.LV_NM
                  ,LM.SEQ               AS LV_SEQ
                  ,SL.PARENT_SALES_LV_ID
                  ,SL2.SALES_LV_CD  AS PARENT_SALES_LV_CD
                  ,SL2.SALES_LV_NM  AS PARENT_SALES_LV_NM  
                  ,SL.CURCY_CD_ID
                  ,CU.COMN_CD_NM        AS CURCY_CD_NM
                  ,SL.ACTV_YN       
              FROM TB_CM_LEVEL_MGMT  LM
                   INNER JOIN 
                   TB_DP_SALES_LEVEL_MGMT  SL               
                ON LM.ID = SL.LV_MGMT_ID 
               AND SL.ACTV_YN = 'Y'
               AND LM.ACTV_YN = 'Y'
               AND COALESCE(LM.DEL_YN, 'N') = 'N'
		   	   INNER JOIN TB_CM_COMM_CONFIG B
                ON B.CONF_GRP_CD = 'DP_LV_TP' and lm.lv_tp_id = B.ID
                AND B.CONF_CD = v_LV_TP               
    	           LEFT OUTER JOIN  
                   TB_DP_SALES_LEVEL_MGMT SL2 
                ON SL.PARENT_SALES_LV_ID = SL2.ID
               AND COALESCE(SL2.DEL_YN, 'N') = 'N'
               AND SL2.ACTV_YN = 'Y'
                   LEFT OUTER JOIN 
                   TB_AD_COMN_CODE CU
                ON CU.ID = SL.CURCY_CD_ID
             WHERE 1=1
               AND CASE WHEN REPLACE(p_LEAF_TP,'LEAF', 'Y') IS NULL THEN LM.LV_LEAF_YN ELSE REPLACE(p_LEAF_TP,'LEAF','Y') END =  LM.LV_LEAF_YN               
    --           AND (REGEXP_LIKE(LM.LV_CD, P_LV_CD) OR P_LV_CD IS NULL)
               AND (UPPER(LM.LV_CD) IN (
                                SELECT distinct regexp_substr(A.TXT, '[^|]+', 1, LEVEL) TXT
                                  FROM (SELECT UPPER(P_LV_CD) TXT FROM dual) A
                               CONNECT BY LEVEL <= length(regexp_replace(A.TXT, '[^|]+',''))+1
                               ) OR P_LV_CD IS NULL)
               AND UPPER(SL.SALES_LV_CD) LIKE '%' || UPPER(RTRIM(p_SALES_LV_CD)) ||'%'
               AND UPPER(SL.SALES_LV_NM) LIKE '%' || UPPER(RTRIM(p_SALES_LV_NM)) ||'%'
               AND (SL2.SALES_LV_CD = P_PARENT_SALES_LV_CD OR P_PARENT_SALES_LV_CD IS NULL)
         )  A
    ;


END
;
/

