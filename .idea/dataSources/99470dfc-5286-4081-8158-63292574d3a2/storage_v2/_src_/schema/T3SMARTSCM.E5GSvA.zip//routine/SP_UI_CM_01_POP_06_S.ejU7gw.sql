create PROCEDURE "SP_UI_CM_01_POP_06_S" (
	 P_ID                   IN VARCHAR2 := ''
	,P_CONVN_NM	            IN VARCHAR2 := ''
	,P_ACTV_YN	            IN VARCHAR2 := ''
    ,P_WRK_TYPE	            IN VARCHAR2 := ''
    ,P_LANG_CD              IN VARCHAR2 := ''
    ,P_USER_ID	            IN VARCHAR2 := ''
    ,P_RT_ROLLBACK_FLAG     OUT VARCHAR2 
    ,P_RT_MSG               OUT VARCHAR2
)
IS
    P_ERR_STATUS INT :=0;
    P_ERR_MSG VARCHAR2(4000) := '';
    V_ATTR_NM VARCHAR(10);

BEGIN
	IF P_WRK_TYPE = 'SAVE'
	THEN
	    P_ERR_MSG := 'MSG_0005';
        SELECT	COUNT(*) INTO P_ERR_STATUS
		FROM	TB_CM_ITEM_ATTRIBUTE A
				LEFT OUTER JOIN TB_AD_LANG_PACK B
				ON B.LANG_KEY = A.CONVN_NM
				AND B.LANG_CD = P_LANG_CD
		WHERE	A.ID <> P_ID
		AND		A.CONVN_NM = P_CONVN_NM;

        IF P_ERR_STATUS > 0 THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
	    END IF;
	
	    P_ERR_MSG := 'MSG_0006';
        IF NVL(P_CONVN_NM,'') ='' THEN RAISE_APPLICATION_ERROR(-20012, P_ERR_MSG);
	    END IF;
        
	    SELECT 'ATTR_' || LPAD(TO_CHAR(TO_NUMBER(NVL(MAX(SUBSTR(ATTR_NM, -2)),'0')) + 1),2,'0') INTO V_ATTR_NM
	    FROM TB_CM_ITEM_ATTRIBUTE;        
	            
	    MERGE INTO TB_CM_ITEM_ATTRIBUTE B 
        USING (SELECT P_ID AS ID FROM DUAL) A
        ON  (B.ID = A.ID)
        WHEN MATCHED THEN
            UPDATE 
               SET ACTV_YN	    = P_ACTV_YN
                 , MODIFY_BY	= P_USER_ID
                 , MODIFY_DTTM	= SYSDATE
        WHEN NOT MATCHED THEN
            INSERT (
                ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
                , CONF_ID
                , ATTR_NM
                , CONVN_NM
                , ACTV_YN
                )
            VALUES 
                (
                TO_SINGLE_BYTE(SYS_GUID()), P_USER_ID, SYSDATE, P_USER_ID, SYSDATE
                , (SELECT ID FROM TB_CM_CONFIGURATION WHERE CONF_KEY = '006')
                , V_ATTR_NM
				, 'ITEM_'||V_ATTR_NM
                , P_ACTV_YN
            );

		MERGE INTO TB_AD_LANG_PACK B
		USING (
				SELECT	P_LANG_CD	AS LANG_CD, 
						A.CONVN_NM  AS LANG_KEY
				FROM	TB_CM_ITEM_ATTRIBUTE A
				WHERE	A.ID = P_ID
			  ) A
		ON	  (B.LANG_KEY = A.LANG_KEY
		   AND A.LANG_CD = B.LANG_CD 
		      )
		WHEN MATCHED THEN
			UPDATE
				SET LANG_VALUE	= P_CONVN_NM
		WHEN NOT MATCHED THEN
			INSERT (
				LANG_CD,
				LANG_KEY,
				LANG_VALUE
				)
			VALUES 
			  	(
				A.LANG_CD,
				A.LANG_KEY,
				P_CONVN_NM
			);
	
        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0001';
	
	ELSIF P_WRK_TYPE = 'DELETE'
	THEN
	    DELETE FROM TB_CM_ITEM_ATTRIBUTE WHERE ID = P_ID;
	
        P_RT_ROLLBACK_FLAG := 'true';
        P_RT_MSG := 'MSG_0002';
	END IF;

EXCEPTION
WHEN OTHERS THEN
    IF(SQLCODE = -20012)
      THEN
          P_RT_ROLLBACK_FLAG := 'false';
          P_RT_MSG := P_ERR_MSG;   
      ELSE
          RAISE;
      END IF;
END;
/

