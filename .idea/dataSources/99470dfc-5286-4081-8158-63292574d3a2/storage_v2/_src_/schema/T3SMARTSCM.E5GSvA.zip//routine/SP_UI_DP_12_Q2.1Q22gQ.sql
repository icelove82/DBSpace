create PROCEDURE                "SP_UI_DP_12_Q2" (p_SALES_LV_ID IN VARCHAR2 := ''
								             ,pRESULT       OUT SYS_REFCURSOR ) IS 

                                                     
/*************************************************************************
      ITEM LEVEL  
    USED UI : UI_DP_POPUP_ITEM_TREE

    History ( Date / Writer / Comment)
    - 2020.03.12 / Kim sohee / add USER_ID 
    
************************************************************************/
BEGIN

OPEN pRESULT
FOR
SELECT SA.ID 
      ,SA.SALES_LV_ID
	  ,SL.SALES_LV_CD
      ,SL.SALES_LV_NM
      ,SA.STRT_DATE_AUTH    AS STRT_DATE_AUTH
      ,SA.END_DATE_AUTH   AS END_DATE_AUTH
      ,SA.EMP_ID
	  ,DE.USERNAME AS USER_ID
      ,DE.USERNAME AS EMP_NO
	  ,DE.DISPLAY_NAME AS EMP_NM
      ,SA.CREATE_BY
      ,SA.CREATE_DTTM
      ,SA.MODIFY_BY
      ,SA.MODIFY_DTTM
  FROM TB_DP_SALES_AUTH_MAP SA
         LEFT OUTER JOIN TB_DP_SALES_LEVEL_MGMT SL ON SA.SALES_LV_ID = SL.ID
	     LEFT OUTER JOIN TB_AD_USER DE             ON SA.EMP_ID      = DE.ID
  WHERE SA.SALES_LV_ID   =  p_SALES_LV_ID  
  ORDER BY SA.STRT_DATE_AUTH
;		
END
;
/

