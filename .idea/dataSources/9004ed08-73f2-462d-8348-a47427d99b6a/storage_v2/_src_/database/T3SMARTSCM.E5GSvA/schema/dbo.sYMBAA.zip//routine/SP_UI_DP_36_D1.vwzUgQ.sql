CREATE PROCEDURE [dbo].[SP_UI_DP_36_D1] (
					@P_ID	CHAR(32) = ''
				   ,@P_USER_ID	NVARCHAR(100) = ''
				   ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'  OUTPUT
				   ,@P_RT_MSG            NVARCHAR(4000) = ''		OUTPUT
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''
BEGIN TRY
/*********************************************************************************************************
		Policy CD : PB
*********************************************************************************************************/
	IF EXISTS (
			SELECT C.CONF_CD 
			  FROM TB_DP_PLAN_POLICY P
				   INNER JOIN
				   TB_CM_COMM_CONFIG C 
				ON P.POLICY_ID = C.ID 
			 WHERE P.ID = @P_ID 
			   AND CONF_CD = 'PB'
			)
			BEGIN
				UPDATE TB_CM_COMM_CONFIG
				  SET ATTR_01 = NULL
			    WHERE CONF_GRP_CD = 'DP_BUKT_TP'
				  AND CONF_CD = 'PB'
				;
			END
			;
/*********************************************************************************************************
		PLAN POLICY 삭제 프로시저
*********************************************************************************************************/
	DELETE FROM TB_DP_PLAN_POLICY
	WHERE ID = @P_ID

	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0002'  --삭제 되었습니다.

END TRY

BEGIN CATCH
     
	   SET @P_ERR_MSG = ERROR_MESSAGE()
	   SET @P_RT_ROLLBACK_FLAG = 'false'
	   SET @P_RT_MSG = @P_ERR_MSG

END CATCH

go

