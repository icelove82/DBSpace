/*****************************************************************************
Title : [SP_UI_DP_35_VALID_ITEM_LV_CD_P_LV_Q2] 
최초 작성자 : 이고은
최초 생성일 : 2017.08.30
 
설명 
 - DP VALIDATION (ITEM_LV_CD_P_LEVEL)-- ALL
 
History (수정일자 / 수정자 / 수정내용)
-  2017.08.30 / 이고은 / 최초 작성
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_35_Q3_ITEM_LV_CD_P_LV] 
--(	
--	 @p_EMP_ID		NVARCHAR(100) = ''
--	,@p_AUTH_TP_ID	NVARCHAR(50) = ''
--) 
AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN


	SELECT	A.ID, A.ITEM_LV_CD, A.ITEM_LV_NM , B.LV_CD, B.LV_NM
	FROM	TB_CM_ITEM_LEVEL_MGMT			A 
			INNER JOIN TB_CM_LEVEL_MGMT	B  ON A.LV_MGMT_ID = B.ID AND B.ACTV_YN = 'Y'
	WHERE	A.ACTV_YN = 'Y'
	AND		A.SEQ NOT IN (
						SELECT	MIN(X.SEQ) 
						FROM	TB_CM_ITEM_LEVEL_MGMT			X 
								INNER JOIN TB_CM_LEVEL_MGMT	Y  ON A.LV_MGMT_ID = B.ID AND Y.ACTV_YN = 'Y'
						)
	AND		A.LV_MGMT_ID IN ( SELECT ID FROM TB_CM_LEVEL_MGMT  WHERE ACTV_YN = 'Y')
	AND		ISNULL(A.PARENT_ITEM_LV_ID, '') NOT IN	(
													SELECT ID FROM TB_CM_ITEM_LEVEL_MGMT 
													)

END








go

