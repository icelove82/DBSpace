/********************************************************************************************************************************
Title : [SP_UI_DP_07_S1_J]

	Exchange Rate Save (Json Param Bulk Insert)
 
설명 
  - Exchange Rate
  - OPENJSON : https://docs.microsoft.com/ko-kr/sql/t-sql/functions/openjson-transact-sql?view=sql-server-ver15

 
History (수정일자 / 수정자 / 수정내용)
- 2022.01.11 / kim sohee / json bulk insert draft

*********************************************************************************************************************************/


CREATE PROCEDURE [dbo].[SP_UI_DP_07_S1_J]  (     
								       @P_JSON				  NVARCHAR(MAX)
									  ,@p_USER_ID             NVARCHAR(100)     = ''
									  ,@P_RT_ROLLBACK_FLAG    NVARCHAR(10)      = 'true'  OUTPUT
									  ,@P_RT_MSG              NVARCHAR(4000)    = ''	  OUTPUT									        
	  								   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
DECLARE 
        @P_ERR_MSG NVARCHAR(4000)  

BEGIN TRY
---------- ID 추출 ----------
/*	BEGIN TRY

		SELECT @p_FROM_CURCY_CD_ID = ID FROM TB_AD_COMN_CODE WHERE COMN_CD = @V_FROM_CURCY_CD;
		SELECT @p_TO_CURCY_CD_ID = ID FROM TB_AD_COMN_CODE WHERE COMN_CD = @V_TO_CURCY_CD;
	END TRY
	BEGIN CATCH
		IF(@p_FROM_CURCY_CD_ID IS NULL OR @p_TO_CURCY_CD_ID IS NULL)
			BEGIN
				SET @P_ERR_MSG = 'MSG_0006'
			END
	END CATCH;
---------- VALIDATION ------------------
    IF (@p_FROM_CURCY_CD_ID = @p_TO_CURCY_CD_ID)
	   BEGIN
			SET @P_ERR_MSG = 'MSG_5100'
			RAISERROR (@P_ERR_MSG,12, 1);
	   END
*/

		SELECT TOP 1 @P_ERR_MSG = V.[key]	--R.key, R.value, V.key, V.value
		  FROM OPENJSON(@P_JSON) AS R
			   CROSS APPLY 
			   OPENJSON ( R.value) AS V
		 WHERE V.[value] IS NULL 
		   AND V.[key] IN ( 'FROM_CURCY_CD'
		   				   ,'TO_CURCY_CD'	
		   				   ,'BASE_DATE'
		   				   ,'EXCHANGE_RATE'
		   				   ,'CURCY_TP_CD'	
						  )
		 ;
	IF @P_ERR_MSG IS NOT NULL 
	BEGIN
		SET @P_ERR_MSG = 'Check Empty Value : '+@P_ERR_MSG		
		RAISERROR (@P_ERR_MSG,12, 1);
	END
	;

	  -- 프로시저 시작 
		  WITH CURRENCY
			AS (   SELECT C.ID, C.COMN_CD
					 FROM TB_AD_COMN_CODE C
						  INNER JOIN 
						  TB_AD_COMN_GRP G 
					   ON C.SRC_ID = G.ID 
				   WHERE G.GRP_CD = 'CURRENCY'		
				)
				MERGE TB_DP_EXCHANGE_RATE TGT
				USING ( 
						SELECT   M.ID				  
								,F.ID				  AS FROM_CURCY_CD_ID
								,T.ID				  AS TO_CURCY_CD_ID
								,M.BASE_DATE		  AS BASE_DATE
								,M.EXCHANGE_RATE	  AS EXCHANGE_RATE
								,C.ID				  AS CURCY_TP_ID	
								--,M.ROW_STATUS		
						  FROM OPENJSON(@P_JSON) 
						  WITH (ID					CHAR(32)		'$.ID'
							   ,FROM_CURCY_CD		NVARCHAR(100)	'$.FROM_CURCY_CD'
							   ,TO_CURCY_CD			NVARCHAR(100)	'$.TO_CURCY_CD'
							   ,BASE_DATE			DATETIME		'$.BASE_DATE'
							   ,EXCHANGE_RATE		DECIMAL(20,5)	'$.EXCHANGE_RATE'
							   ,CURCY_TP_CD			NVARCHAR(100)	'$.CURCY_TP_CD'
							  --,ROW_STATUS			NVARCHAR(50)	'$.ROW_STATUS'
							   ) M
							   INNER JOIN
							   CURRENCY F
							ON M.FROM_CURCY_CD = F.COMN_CD
							   INNER JOIN 
							   CURRENCY T
							ON M.TO_CURCY_CD = T.COMN_CD 
							   INNER JOIN 
							   TB_CM_COMM_CONFIG C
							ON M.CURCY_TP_CD = C.CONF_CD
						   AND C.CONF_GRP_CD = 'DP_CURRENCY_TYPE'
					  ) SRC
				ON (  TGT.FROM_CURCY_CD_ID = SRC.FROM_CURCY_CD_ID 
				  AND TGT.TO_CURCY_CD_ID   = SRC.TO_CURCY_CD_ID 
				  AND TGT.BASE_DATE        = SRC.BASE_DATE
				  AND TGT.CURCY_TP_ID      = SRC.CURCY_TP_ID )
				WHEN MATCHED THEN
					 UPDATE 
					   SET         
							 TGT.EXCHANGE_RATE       	= SRC.EXCHANGE_RATE   
--							,TGT.UNIT_UOM_VAL    		= SRC.UNIT_UOM_VAL    
							,TGT.MODIFY_BY              = @P_USER_ID   
							,TGT.MODIFY_DTTM            = GETDATE()       
				WHEN NOT MATCHED THEN 
					 INSERT (
							 ID               
							,FROM_CURCY_CD_ID
							,TO_CURCY_CD_ID  
							,BASE_DATE       
							,EXCHANGE_RATE   
							,UNIT_UOM_VAL
							,CURCY_TP_ID    
							,CREATE_BY
							,CREATE_DTTM
							) 
					 VALUES (
							 REPLACE(NEWID(),'-','') 
							,SRC.FROM_CURCY_CD_ID   
							,SRC.TO_CURCY_CD_ID     
							,SRC.BASE_DATE          
							,SRC.EXCHANGE_RATE      
							,NULL
							,SRC.CURCY_TP_ID      
							,@P_USER_ID    
							,GETDATE()            
 							) 
							;    

	
	   SET @P_RT_ROLLBACK_FLAG = 'true'

	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;



go

