/*****************************************************************************
Title : [SP_UI_BF_15_Q1]
최초 작성자 : 김소희
최초 생성일 : 2019.11.21
 
설명 
 - BF Control Board Master
 
History (수정일자 / 수정자 / 수정내용)
- 2019.11.21 / 김소희 / Draft
- 2020.01.17 / KSH / When Item, Sales level is empty, Set leaf level code
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_BF_15_S1] 
(
		 @P_ID					CHAR(32)			
		,@P_ENGINE_TP_CD		NVARCHAR(30)				
		,@P_DESCRIP				NVARCHAR(200)
		,@P_SEQ					INT
		,@P_BF_DIST_RULE_CD		NVARCHAR(30)
		,@P_INPUT_HORIZ			NVARCHAR(100)
		,@P_INPUT_BUKT_CD		NVARCHAR(30)
		,@P_TARGET_HORIZ		NVARCHAR(100)
		,@P_TARGET_BUKT_CD		NVARCHAR(30)
		,@P_SALES_LV_CD			NVARCHAR(100)
		,@P_ITEM_LV_CD			NVARCHAR(100)
		,@P_VAL_TP				NVARCHAR(100)
		,@P_ATTR_01				NVARCHAR(100)
		,@P_ATTR_02				NVARCHAR(100)
		,@P_ATTR_03				NVARCHAR(100)
		,@P_ATTR_04				NVARCHAR(100)
		,@P_ATTR_05				NVARCHAR(100)
		,@P_ATTR_06				NVARCHAR(100)
		,@P_ATTR_07				NVARCHAR(100)
		,@P_ATTR_08				NVARCHAR(100)
		,@P_ATTR_09				NVARCHAR(100)
		,@P_ATTR_10				NVARCHAR(100)
		,@P_USER_ID				NVARCHAR(100)
		,@P_RT_ROLLBACK_FLAG	NVARCHAR(10)   = 'true'     OUTPUT
		,@P_RT_MSG				NVARCHAR(4000) = ''			OUTPUT		
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	DECLARE @P_ERR_STATUS INT = 0
		   ,@P_ERR_MSG NVARCHAR(4000)=''
	DECLARE @P_DEFAT_ITEM_CD	NVARCHAR(100)
		   ,@P_DEFAT_ACCT_CD	NVARCHAR(100)
BEGIN TRY
IF(@P_SALES_LV_CD  IS NULL)
BEGIN
	SELECT @P_SALES_LV_CD = LV_CD
	  FROM TB_CM_LEVEL_MGMT
	WHERE 1=1
	  AND ACTV_YN = 'Y'
	  AND ISNULL(DEL_YN,'N') = 'N'
	  AND ACCOUNT_LV_YN = 'Y'
	  AND LEAF_YN = 'Y'
END
IF(@P_ITEM_LV_CD   IS NULL)
BEGIN
	SELECT @P_ITEM_LV_CD = LV_CD
	  FROM TB_CM_LEVEL_MGMT
	WHERE ACTV_YN = 'Y'
	  AND ISNULL(DEL_YN,'N') = 'N'
	  AND ACCOUNT_LV_YN = 'N'
	  AND SALES_LV_YN = 'N'
	  AND LEAF_YN = 'Y'
END
IF NOT EXISTS (
				SELECT LV_CD
				  FROM TB_CM_LEVEL_MGMT
				WHERE 1=1
				  AND ACTV_YN = 'Y'
				  AND ISNULL(DEL_YN,'N') = 'N'
				  AND ACCOUNT_LV_YN = 'Y'
				  AND LV_CD = @P_SALES_LV_CD
			  )
			BEGIN
					SET @P_ERR_MSG = 'Sales Level Code is not valid'
					RAISERROR (@P_ERR_MSG,12, 1);
			END
IF NOT EXISTS (
				SELECT LV_CD
				  FROM TB_CM_LEVEL_MGMT
				WHERE ACTV_YN = 'Y'
				  AND ISNULL(DEL_YN,'N') = 'N'
				  AND ACCOUNT_LV_YN = 'N'
				  AND SALES_LV_YN = 'N'
				  AND LV_CD = @P_ITEM_LV_CD
			  )
			BEGIN
					SET @P_ERR_MSG = 'Item Level Code is not valid'
					RAISERROR (@P_ERR_MSG,12, 1);
			END
IF(@P_seq				IS NULL) BEGIN	SET @P_ERR_MSG = 'Sequence is empty'		 RAISERROR (@P_ERR_MSG,12, 1); END
IF(@P_INPUT_HORIZ		IS NULL) BEGIN	SET @P_ERR_MSG = 'Input Horizon is empty'		 RAISERROR (@P_ERR_MSG,12, 1); END
IF(@P_INPUT_BUKT_CD		IS NULL) BEGIN	SET @P_ERR_MSG = 'Input Bucket is empty'		 RAISERROR (@P_ERR_MSG,12, 1); END
IF(@P_TARGET_HORIZ		IS NULL) BEGIN	SET @P_ERR_MSG = 'Target Horizon is empty'		 RAISERROR (@P_ERR_MSG,12, 1); END
IF(@P_TARGET_BUKT_CD	IS NULL) BEGIN	SET @P_ERR_MSG = 'Target Bucket is empty'		 RAISERROR (@P_ERR_MSG,12, 1); END
--IF(@P_BF_DIST_RULE_CD	IS NULL) BEGIN	SET @P_ERR_MSG = 'Disaggregate Rule is empty' RAISERROR (@P_ERR_MSG,12, 1); 		END

/******************************************************************
	-- Main Procedure
*******************************************************************/
	MERGE INTO TB_BF_CONTROL_BOARD_MST TGT
	USING ( SELECT @P_ID					AS 	ID				
				  ,@P_ENGINE_TP_CD			AS 	ENGINE_TP_CD		
				  ,@P_DESCRIP				AS 	DESCRIP			
				  ,@P_SEQ					AS 	SEQ				
				  ,@P_BF_DIST_RULE_CD		AS 	BF_DIST_RULE_CD	
				  ,@P_INPUT_HORIZ			AS 	INPUT_HORIZ		
				  ,@P_INPUT_BUKT_CD			AS 	INPUT_BUKT_CD		
				  ,@P_TARGET_HORIZ			AS 	TARGET_HORIZ		
				  ,@P_TARGET_BUKT_CD		AS 	TARGET_BUKT_CD	
				  ,@P_SALES_LV_CD			AS 	SALES_LV_CD		
				  ,@P_ITEM_LV_CD			AS 	ITEM_LV_CD
				  ,@P_VAL_TP				AS  VAL_TP
				  ,@P_ATTR_01				AS 	ATTR_01			
				  ,@P_ATTR_02				AS 	ATTR_02			
				  ,@P_ATTR_03				AS 	ATTR_03			
				  ,@P_ATTR_04				AS 	ATTR_04			
				  ,@P_ATTR_05				AS 	ATTR_05			
				  ,@P_ATTR_06				AS 	ATTR_06			
				  ,@P_ATTR_07				AS 	ATTR_07			
				  ,@P_ATTR_08				AS 	ATTR_08			
				  ,@P_ATTR_09				AS 	ATTR_09			
				  ,@P_ATTR_10				AS 	ATTR_10			
				  ,@P_USER_ID				AS 	[USER_ID]	
				  ,GETDATE()				AS  DTTM
		  ) SRC 
		ON TGT.ENGINE_TP_CD = SRC.ENGINE_TP_CD
WHEN MATCHED THEN
	UPDATE SET DESCRIP			= SRC.DESCRIP			
			  ,SEQ				= SRC.SEQ				
			  ,BF_DIST_RULE_CD	= SRC.BF_DIST_RULE_CD	
			  ,INPUT_HORIZ		= SRC.INPUT_HORIZ		
			  ,INPUT_BUKT_CD	= SRC.INPUT_BUKT_CD			
			  ,TARGET_HORIZ		= SRC.TARGET_HORIZ		
			  ,TARGET_BUKT_CD	= SRC.TARGET_BUKT_CD	
			  ,SALES_LV_CD		= SRC.SALES_LV_CD		
			  ,ITEM_LV_CD		= SRC.ITEM_LV_CD
			  ,VAL_TP			= SRC.VAL_TP
			  ,ATTR_01			= SRC.ATTR_01			
			  ,ATTR_02			= SRC.ATTR_02			
			  ,ATTR_03			= SRC.ATTR_03			
			  ,ATTR_04			= SRC.ATTR_04			
			  ,ATTR_05			= SRC.ATTR_05			
			  ,ATTR_06			= SRC.ATTR_06			
			  ,ATTR_07			= SRC.ATTR_07			
			  ,ATTR_08			= SRC.ATTR_08			
			  ,ATTR_09			= SRC.ATTR_09			
			  ,ATTR_10			= SRC.ATTR_10			
			  ,MODIFY_BY		= SRC.[USER_ID]	
			  ,MODIFY_DTTM		= SRC.DTTM
 WHEN NOT MATCHED THEN
		INSERT ( ID				
				,ENGINE_TP_CD		
				,DESCRIP			
				,SEQ				
				,BF_DIST_RULE_CD	
				,INPUT_HORIZ		
				,INPUT_BUKT_CD		
				,TARGET_HORIZ		
				,TARGET_BUKT_CD	
				,SALES_LV_CD		
				,ITEM_LV_CD
				,VAL_TP
				,ATTR_01			
				,ATTR_02			
				,ATTR_03			
				,ATTR_04			
				,ATTR_05			
				,ATTR_06			
				,ATTR_07			
				,ATTR_08			
				,ATTR_09			
				,ATTR_10			
				,CREATE_BY
				,CREATE_DTTM
			   ) VALUES
			   (REPLACE(NEWID(),'-','')
			   ,SRC.ENGINE_TP_CD
			   ,SRC.DESCRIP			
			   ,SRC.SEQ				
			   ,SRC.BF_DIST_RULE_CD	
			   ,SRC.INPUT_HORIZ		
			   ,SRC.INPUT_BUKT_CD			
			   ,SRC.TARGET_HORIZ		
			   ,SRC.TARGET_BUKT_CD	
			   ,SRC.SALES_LV_CD		
			   ,SRC.ITEM_LV_CD
			   ,SRC.VAL_TP
			   ,SRC.ATTR_01			
			   ,SRC.ATTR_02			
			   ,SRC.ATTR_03			
			   ,SRC.ATTR_04			
			   ,SRC.ATTR_05			
			   ,SRC.ATTR_06			
			   ,SRC.ATTR_07			
			   ,SRC.ATTR_08			
			   ,SRC.ATTR_09			
			   ,SRC.ATTR_10			
			   ,SRC.[USER_ID]	
			   ,SRC.DTTM			   
			   )
			   ;

 	 	 
	BEGIN
	    SET @P_RT_MSG = 'MSG_0001'
	END
	    SET @P_RT_ROLLBACK_FLAG = 'true'
END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END
	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR
END CATCH


/*

SELECT *
 FROM  TB_CM_CONFIGURATION CF
		 INNER JOIN
		 TB_CM_COMM_CONFIG CC	
	  ON CF.ID = CC.CONF_ID 
	 AND CF.CONF_NM = 'BF_ENGINE_TP'
	 AND CF.MODULE_CD = 'BF'
	  -- lang_pack 문서에 반영하기!!!
	  SELECT *
	    FROM LANG_PACK
	  WHERE LANG_KEY LIKE '%ENGINE_TP%'
	    OR LANG_KEY = 'INPUT'
*/

go

