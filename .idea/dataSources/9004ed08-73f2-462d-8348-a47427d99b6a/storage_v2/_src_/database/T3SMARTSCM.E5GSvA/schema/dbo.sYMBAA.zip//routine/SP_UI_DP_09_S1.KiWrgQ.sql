/*****************************************************************************
Title : SP_UI_DP_09_S1
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 FETCH NEXT FROM
 - CM Item Master
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2019.02.11 / 김소희 / DP Item Master를 CM Item Master로 공통화
- 2019.04.29 / 김소희 / 필요값 validation 
- 2019.08.22 / 김소희 / Item type이 null일 경우 완제품으로
- 2020.11.06 / 김소희 / convert data type of item code nvarchar(100)
- 2020.12.03 / 김소희 / make entry data
- 2021.02.23 / kimsohee / RTS, EOS date re-arrange 
- 2022.04.18 /hanguls / RTS, EOS re-arange remove input date 유지
- 2022.11.21 /hanguls / CM 분리
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_09_S1] (
	 @p_ID                  NVARCHAR(32)     = ''         
	,@p_ITEM_CD             NVARCHAR(100)     = ''         
	,@p_ITEM_NM             NVARCHAR(240)    = ''         
	,@p_UOM_ID              NVARCHAR(32)     = ''      
	,@p_ITEM_TP_ID          CHAR(32)		   = ''   
	,@P_MIN_ORDER_SIZE      INT			   = NULL
	,@P_MAX_ORDER_SIZE      INT			   = NULL
	,@p_DESCRIP             NVARCHAR(3000)   = ''      
	,@p_DP_PLAN_YN          CHAR(1)		   = ''      
	,@p_PARENT_ITEM_LV_ID   NVARCHAR(32)     = ''      
	,@p_RTS                 DATETIME         = NULL
	,@p_EOS                 DATETIME         = NULL 
	,@p_DEL_YN              CHAR(1)          = ''   
	,@p_ATTR_01             NVARCHAR(100)    = '' 
	,@p_ATTR_02				NVARCHAR(100)    = ''
	,@p_ATTR_03				NVARCHAR(100)    = ''
	,@p_ATTR_04				NVARCHAR(100)    = ''
	,@p_ATTR_05				NVARCHAR(100)    = ''
	,@p_ATTR_06				NVARCHAR(100)    = ''
	,@p_ATTR_07				NVARCHAR(100)    = ''
	,@p_ATTR_08				NVARCHAR(100)    = ''
	,@p_ATTR_09				NVARCHAR(100)    = ''
	,@p_ATTR_10				NVARCHAR(100)    = ''
	,@p_ATTR_11				NVARCHAR(100)    = ''
	,@p_ATTR_12				NVARCHAR(100)    = ''
	,@p_ATTR_13				NVARCHAR(100)    = ''
	,@p_ATTR_14				NVARCHAR(100)    = ''
	,@p_ATTR_15				NVARCHAR(100)    = ''
	,@p_ATTR_16				NVARCHAR(100)    = ''
	,@p_ATTR_17				NVARCHAR(100)    = ''
	,@p_ATTR_18				NVARCHAR(100)    = ''
	,@p_ATTR_19				NVARCHAR(100)    = ''
	,@p_ATTR_20				NVARCHAR(100)    = ''
	,@p_ATTR_21				NVARCHAR(100)    = ''
	,@p_ATTR_22				NVARCHAR(100)    = ''
	,@p_ATTR_23				NVARCHAR(100)    = ''
	,@p_ATTR_24				NVARCHAR(100)    = ''
	,@p_ATTR_25				NVARCHAR(100)    = ''
	,@p_DISPLAY_COLOR		NVARCHAR(100)    = ''
	,@p_USER_ID             NVARCHAR(50)     = ''  
	,@p_PARENT_ITEM_LV_ID_AD1   NVARCHAR(32)     = '' 
	,@p_PARENT_ITEM_LV_ID_AD2   NVARCHAR(32)     = '' 
	,@p_PARENT_ITEM_LV_ID_AD3   NVARCHAR(32)     = '' 
	,@P_RT_ROLLBACK_FLAG	NVARCHAR(10)     = 'true'  OUTPUT
	,@P_RT_MSG				NVARCHAR(4000)   = ''	   OUTPUT
) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE 
		 @P_ERR_STATUS INT = 0
        ,@P_ERR_MSG NVARCHAR(4000)=''

		, @V_ID                 NVARCHAR(32)     = ''   
		, @V_ITEM_CD          	NVARCHAR(100)     = ''   
		, @V_ITEM_NM          	NVARCHAR(240)    = ''   
		, @V_UOM_ID           	NVARCHAR(32)     = ''   
		, @V_ITEM_TP_ID       	NVARCHAR(32)     = ''   
		, @V_DESCRIP          	NVARCHAR(3000)   = ''   
		, @V_DP_PLAN_YN       	CHAR(1)		   = ''   
		, @V_PARENT_ITEM_LV_ID	NVARCHAR(32)     = ''   
		, @V_RTS              	DATETIME         = NULL
		, @V_EOS              	DATETIME         = NULL 
		, @V_DEL_YN           	CHAR(1)          = ''   
		, @V_ATTR_01          	NVARCHAR(100)    = '' 
		, @V_ATTR_02			NVARCHAR(100)    = ''
		, @V_ATTR_03			NVARCHAR(100)    = ''
		, @V_ATTR_04			NVARCHAR(100)    = ''
		, @V_ATTR_05			NVARCHAR(100)    = ''
		, @V_ATTR_06			NVARCHAR(100)    = ''
		, @V_ATTR_07			NVARCHAR(100)    = ''
		, @V_ATTR_08			NVARCHAR(100)    = ''
		, @V_ATTR_09			NVARCHAR(100)    = ''
		, @V_ATTR_10			NVARCHAR(100)    = ''
		, @V_ATTR_11			NVARCHAR(100)    = ''
		, @V_ATTR_12			NVARCHAR(100)    = ''
		, @V_ATTR_13			NVARCHAR(100)    = ''
		, @V_ATTR_14			NVARCHAR(100)    = ''
		, @V_ATTR_15			NVARCHAR(100)    = ''
		, @V_ATTR_16			NVARCHAR(100)    = ''
		, @V_ATTR_17			NVARCHAR(100)    = ''
		, @V_ATTR_18			NVARCHAR(100)    = ''
		, @V_ATTR_19			NVARCHAR(100)    = ''
		, @V_ATTR_20			NVARCHAR(100)    = ''
		, @V_ATTR_21			NVARCHAR(100)    = ''
		, @V_ATTR_22			NVARCHAR(100)    = ''
		, @V_ATTR_23			NVARCHAR(100)    = ''
		, @V_ATTR_24			NVARCHAR(100)    = ''
		, @V_ATTR_25			NVARCHAR(100)    = ''
		, @V_DISPLAY_COLOR		NVARCHAR(100)    = ''
		, @V_USER_ID          	NVARCHAR(50)     = ''
		, @V_PARENT_ITEM_LV_ID_AD1	NVARCHAR(32)     = ''   
		, @V_PARENT_ITEM_LV_ID_AD2	NVARCHAR(32)     = ''   
		, @V_PARENT_ITEM_LV_ID_AD3	NVARCHAR(32)     = ''   

	SET @p_RTS = CASE 
						WHEN @p_RTS = '1901-01-01' THEN NULL
						ELSE  @p_RTS
						END 
	SET @p_EOS = CASE 
						WHEN @p_EOS = '1901-01-01' THEN NULL
						ELSE  @p_EOS
						END

	SET @V_ID                 	= @p_ID               
	SET @V_ITEM_CD          	= @p_ITEM_CD          
	SET @V_ITEM_NM          	= @p_ITEM_NM          
	SET @V_UOM_ID           	= @p_UOM_ID           
	SET @V_ITEM_TP_ID       	= @p_ITEM_TP_ID       
	SET @V_DESCRIP          	= @p_DESCRIP          
	SET @V_DP_PLAN_YN       	= @p_DP_PLAN_YN       
	SET @V_PARENT_ITEM_LV_ID	= @p_PARENT_ITEM_LV_ID
	SET @V_RTS              	= @p_RTS
	SET @V_EOS              	= @p_EOS
	SET @V_DEL_YN           	= @p_DEL_YN
	SET @V_ATTR_01          	= @p_ATTR_01
	SET @V_ATTR_02				= @p_ATTR_02
	SET @V_ATTR_03				= @p_ATTR_03
	SET @V_ATTR_04				= @p_ATTR_04
	SET @V_ATTR_05				= @p_ATTR_05
	SET @V_ATTR_06				= @p_ATTR_06
	SET @V_ATTR_07				= @p_ATTR_07
	SET @V_ATTR_08				= @p_ATTR_08
	SET @V_ATTR_09				= @p_ATTR_09
	SET @V_ATTR_10				= @p_ATTR_10
	SET @V_ATTR_11				= @p_ATTR_11
	SET @V_ATTR_12				= @p_ATTR_12
	SET @V_ATTR_13				= @p_ATTR_13
	SET @V_ATTR_14				= @p_ATTR_14
	SET @V_ATTR_15				= @p_ATTR_15
	SET @V_ATTR_16				= @p_ATTR_16
	SET @V_ATTR_17				= @p_ATTR_17
	SET @V_ATTR_18				= @p_ATTR_18
	SET @V_ATTR_19				= @p_ATTR_19
	SET @V_ATTR_20				= @p_ATTR_20
	SET @V_ATTR_21				= @p_ATTR_21
	SET @V_ATTR_22				= @p_ATTR_22
	SET @V_ATTR_23				= @p_ATTR_23
	SET @V_ATTR_24				= @p_ATTR_24
	SET @V_ATTR_25				= @p_ATTR_25
	SET @V_DISPLAY_COLOR		= @p_DISPLAY_COLOR
	SET @V_USER_ID          	= @p_USER_ID    
	SET @V_PARENT_ITEM_LV_ID_AD1	= @p_PARENT_ITEM_LV_ID_AD1
	SET @V_PARENT_ITEM_LV_ID_AD2	= @p_PARENT_ITEM_LV_ID_AD2
	SET @V_PARENT_ITEM_LV_ID_AD3	= @p_PARENT_ITEM_LV_ID_AD3

BEGIN TRY

	/* Validation */
	IF ( ISNULL(@p_PARENT_ITEM_LV_ID,'') ='' AND @P_DP_PLAN_YN = 'Y' )
		BEGIN
			SET @P_ERR_MSG = 'MSG_5045'
			RAISERROR (@P_ERR_MSG,12, 1)
		END

	SELECT @P_ERR_STATUS = count(*)
		FROM TB_CM_ITEM_MST
		WHERE 1=1
		AND ITEM_CD = @V_ITEM_CD
		AND ID != @p_ID
		;
	IF ( @P_ERR_STATUS > 0 )
		BEGIN
			SET @P_ERR_MSG = 'MSG_0013'
			RAISERROR (@P_ERR_MSG,12, 1)
		END

	IF(ISNULL(@V_ITEM_CD,'') ='')
		BEGIN
			SET @P_ERR_MSG = 'Item Code is empty.'
			RAISERROR (@P_ERR_MSG,12, 1)
		END
	IF(ISNULL(@V_ITEM_NM,'') ='')
		BEGIN
			SET @P_ERR_MSG = 'Item Name is empty.'
			RAISERROR (@P_ERR_MSG,12, 1)
		END
		
    IF (@V_RTS > @V_EOS)
        begin
			SET @P_ERR_MSG = 'MSG_5149'
			RAISERROR (@P_ERR_MSG,12, 1)
        END;

	-- 프로시저 시작 
	MERGE TB_CM_ITEM_MST TGT
	USING ( 
			SELECT   @V_ID                    AS ID
					,@V_ITEM_CD           	  AS ITEM_CD
					,@V_ITEM_NM           	  AS ITEM_NM
					,@V_UOM_ID        	  AS UOM_ID
					,CASE WHEN @V_ITEM_TP_ID IS NOT NULL THEN @V_ITEM_TP_ID
							ELSE (SELECT CT.ID FROM TB_CM_ITEM_TYPE CT WHERE ITEM_TP = 'FERT')
						END		       		  AS ITEM_TP_ID
					,@V_DESCRIP           	  AS DESCRIP           
					,@V_DP_PLAN_YN        	  AS DP_PLAN_YN        
					,@V_PARENT_ITEM_LV_ID 	  AS PARENT_ITEM_LV_ID 
					,@V_RTS               	  AS RTS               
					,@V_EOS               	  AS EOS               
					,CASE WHEN @V_DEL_YN = 'Y' THEN 'Y' ELSE 'N' END   AS DEL_YN            
					,@V_ATTR_01           	  AS ATTR_01           
					,@V_ATTR_02				  AS ATTR_02			
					,@V_ATTR_03				  AS ATTR_03			
					,@V_ATTR_04				  AS ATTR_04			
					,@V_ATTR_05				  AS ATTR_05			
					,@V_ATTR_06				  AS ATTR_06			
					,@V_ATTR_07				  AS ATTR_07			
					,@V_ATTR_08				  AS ATTR_08			
					,@V_ATTR_09				  AS ATTR_09			
					,@V_ATTR_10				  AS ATTR_10			
					,@V_ATTR_11				  AS ATTR_11			
					,@V_ATTR_12				  AS ATTR_12			
					,@V_ATTR_13				  AS ATTR_13			
					,@V_ATTR_14				  AS ATTR_14			
					,@V_ATTR_15				  AS ATTR_15			
					,@V_ATTR_16				  AS ATTR_16			
					,@V_ATTR_17				  AS ATTR_17			
					,@V_ATTR_18				  AS ATTR_18			
					,@V_ATTR_19				  AS ATTR_19
					,@V_ATTR_20				  AS ATTR_20
					,@V_ATTR_21				  AS ATTR_21
					,@V_ATTR_22				  AS ATTR_22
					,@V_ATTR_23				  AS ATTR_23
					,@V_ATTR_24				  AS ATTR_24
					,@V_ATTR_25				  AS ATTR_25
					,@V_DISPLAY_COLOR		  AS DISPLAY_COLOR
					,@V_USER_ID           	  AS USER_ID
                    ,@P_MIN_ORDER_SIZE        AS MIN_ORDER_SIZE
                    ,@P_MAX_ORDER_SIZE        AS MAX_ORDER_SIZE
					,@V_PARENT_ITEM_LV_ID_AD1 	  AS PARENT_ITEM_LV_ID_AD1 
					,@V_PARENT_ITEM_LV_ID_AD2 	  AS PARENT_ITEM_LV_ID_AD2 
					,@V_PARENT_ITEM_LV_ID_AD3 	  AS PARENT_ITEM_LV_ID_AD3 
			) SRC
	ON     TGT.ID = SRC.ID
	WHEN MATCHED THEN
		UPDATE 
		SET   TGT.ITEM_CD              = SRC.ITEM_CD           
			,TGT.ITEM_NM           	  = SRC.ITEM_NM           
			,TGT.UOM_ID            	  = SRC.UOM_ID            
			,TGT.ITEM_TP_ID        	  = SRC.ITEM_TP_ID        
			,TGT.DESCRIP           	  = SRC.DESCRIP           
			,TGT.DP_PLAN_YN        	  = SRC.DP_PLAN_YN
			,TGT.GRADE_YN        	  = SRC.DP_PLAN_YN
			,TGT.PARENT_ITEM_LV_ID 	  = SRC.PARENT_ITEM_LV_ID 
			,TGT.RTS               	  = SRC.RTS               
			,TGT.EOS               	  = SRC.EOS               
			,TGT.DEL_YN            	  = SRC.DEL_YN            
			,TGT.ATTR_01           	  = SRC.ATTR_01           
			,TGT.ATTR_02			  = SRC.ATTR_02			
			,TGT.ATTR_03			  = SRC.ATTR_03			
			,TGT.ATTR_04			  = SRC.ATTR_04			
			,TGT.ATTR_05			  = SRC.ATTR_05			
			,TGT.ATTR_06			  = SRC.ATTR_06			
			,TGT.ATTR_07			  = SRC.ATTR_07			
			,TGT.ATTR_08			  = SRC.ATTR_08			
			,TGT.ATTR_09			  = SRC.ATTR_09			
			,TGT.ATTR_10			  = SRC.ATTR_10			
			,TGT.ATTR_11			  = SRC.ATTR_11			
			,TGT.ATTR_12			  = SRC.ATTR_12			
			,TGT.ATTR_13			  = SRC.ATTR_13			
			,TGT.ATTR_14			  = SRC.ATTR_14			
			,TGT.ATTR_15			  = SRC.ATTR_15			
			,TGT.ATTR_16			  = SRC.ATTR_16			
			,TGT.ATTR_17			  = SRC.ATTR_17			
			,TGT.ATTR_18			  = SRC.ATTR_18			
			,TGT.ATTR_19			  = SRC.ATTR_19
			,TGT.ATTR_20			  = SRC.ATTR_20
			,TGT.ATTR_21			  = SRC.ATTR_21
			,TGT.ATTR_22			  = SRC.ATTR_22
			,TGT.ATTR_23			  = SRC.ATTR_23
			,TGT.ATTR_24			  = SRC.ATTR_24
			,TGT.ATTR_25			  = SRC.ATTR_25
			,TGT.DISPLAY_COLOR		  = SRC.DISPLAY_COLOR
			,TGT.MODIFY_BY            = SRC.USER_ID       
			,TGT.MODIFY_DTTM          = GETDATE()       
            ,TGT.MIN_ORDER_SIZE       = SRC.MIN_ORDER_SIZE
            ,TGT.MAX_ORDER_SIZE       = SRC.MAX_ORDER_SIZE
			,TGT.PARENT_ITEM_LV_ID_AD1 	  = SRC.PARENT_ITEM_LV_ID_AD1 
			,TGT.PARENT_ITEM_LV_ID_AD2 	  = SRC.PARENT_ITEM_LV_ID_AD2
			,TGT.PARENT_ITEM_LV_ID_AD3 	  = SRC.PARENT_ITEM_LV_ID_AD3
	WHEN NOT MATCHED THEN 
		INSERT (
				 ID                
				,ITEM_CD           
				,ITEM_NM           
				,UOM_ID            
				,ITEM_TP_ID        
				,DESCRIP           
				,DP_PLAN_YN        
				,GRADE_YN
				,PARENT_ITEM_LV_ID 
				,RTS               
				,EOS               
				,DEL_YN            
				,ATTR_01           
				,ATTR_02			
				,ATTR_03			
				,ATTR_04			
				,ATTR_05			
				,ATTR_06			
				,ATTR_07			
				,ATTR_08			
				,ATTR_09			
				,ATTR_10			
				,ATTR_11			
				,ATTR_12			
				,ATTR_13			
				,ATTR_14			
				,ATTR_15			
				,ATTR_16			
				,ATTR_17			
				,ATTR_18			
				,ATTR_19
				,ATTR_20
				,ATTR_21
				,ATTR_22
				,ATTR_23
				,ATTR_24
				,ATTR_25
				,DISPLAY_COLOR
				,CREATE_BY
				,CREATE_DTTM
                ,MIN_ORDER_SIZE
                ,MAX_ORDER_SIZE
				,PARENT_ITEM_LV_ID_AD1
				,PARENT_ITEM_LV_ID_AD2
				,PARENT_ITEM_LV_ID_AD3
			) 
		VALUES (
				 ID --(SELECT REPLACE(NEWID(),'-','') )
				,ITEM_CD           
				,ITEM_NM           
				,UOM_ID            
				,ITEM_TP_ID        
				,DESCRIP           
				,DP_PLAN_YN        
				,DP_PLAN_YN
				,PARENT_ITEM_LV_ID 
				,RTS               
				,EOS               
				,DEL_YN            
				,ATTR_01           
				,ATTR_02			
				,ATTR_03			
				,ATTR_04			
				,ATTR_05			
				,ATTR_06			
				,ATTR_07			
				,ATTR_08			
				,ATTR_09			
				,ATTR_10			
				,ATTR_11			
				,ATTR_12			
				,ATTR_13			
				,ATTR_14			
				,ATTR_15			
				,ATTR_16			
				,ATTR_17			
				,ATTR_18			
				,ATTR_19
				,ATTR_20
				,ATTR_21
				,ATTR_22
				,ATTR_23
				,ATTR_24
				,ATTR_25			
				,DISPLAY_COLOR
				,SRC.USER_ID 
				,GETDATE()   
                ,SRC.MIN_ORDER_SIZE
                ,SRC.MAX_ORDER_SIZE
				,SRC.PARENT_ITEM_LV_ID_AD1
				,SRC.PARENT_ITEM_LV_ID_AD2
				,SRC.PARENT_ITEM_LV_ID_AD3
 			);
	/********************************************************************************************************************************************
		-- Make Entry data
	********************************************************************************************************************************************/

	DECLARE @TB_VERSION TABLE ( ID CHAR(32)) 
	DECLARE @CUR_VER_ID NVARCHAR(100)
	INSERT INTO @TB_VERSION (ID) 
	SELECT VER_ID
	  FROM ( 
			SELECT M.ID		VER_ID
				 , DENSE_RANK () OVER (PARTITION BY M.PLAN_TP_ID ORDER BY M.CREATE_DTTM DESC) AS RW 
			  FROM TB_DP_CONTROL_BOARD_VER_MST M
				   INNER JOIN 
				   TB_DP_CONTROL_bOARD_VER_DTL D
				ON M.ID = D.CONBD_VER_MST_ID 
				   INNER JOIN 
				   TB_CM_COMM_CONFIG W
				ON W.ID = D.WORK_TP_ID
			   AND W.CONF_CD = 'CL'
				   INNER JOIN 
				   TB_CM_COMM_CONFIG C
				ON D.CL_STATUS_ID = C.ID
			   AND C.CONF_CD != 'CLOSE' 
			 WHERE EXISTS (SELECT DISTINCT VER_ID FROM TB_DP_ENTRY WHERE VER_ID = M.ID) 
		    ) A
	WHERE RW = 1  
	  AND @V_DEL_YN = 'N' AND @V_DP_PLAN_YN = 'Y'
	DECLARE ITEM_CUR CURSOR FAST_FORWARD LOCAL
	FOR SELECT ID FROM @TB_VERSION
	READONLY
	;

	OPEN ITEM_CUR
    FETCH NEXT FROM ITEM_CUR INTO @CUR_VER_ID 
	;
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
--			SELECT *
--			 FROM @TB_VERSION
--			 WHERE ID = @CUR_VER_ID 
			-- Cursor로 나온 Version ID의 새로운 데이터 중복 여부 판별
			 IF NOT EXISTS
			 (  SELECT 1 
				 FROM TB_DP_ENTRY
				WHERE VER_ID = @CUR_VER_ID
				  AND ITEM_MST_ID = @V_ID				  
			 )
			 BEGIN
			   EXECUTE dbo.SP_UI_DP_93_ITEM_ACCT_CREATE 
						 @P_ITEM_MST_ID		= @V_ID   		-- Item Account User Map / Item Master 
						,@P_ITEM_LV_ID		= NULL		
						,@P_ACCOUNT_ID		= NULL				-- Item Account User Map / Account Master 
						,@P_ACCT_LV_ID		= NULL    	
						,@P_USER_ID			= NULL			-- Mapping data
						,@P_AUTH_TP_ID		= NULL		
						,@P_VER_ID			= @CUR_VER_ID 	
						;   
			END
			  FETCH NEXT FROM ITEM_CUR INTO @CUR_VER_ID
		END 
	   ;
		CLOSE ITEM_CUR
		DEALLOCATE ITEM_CUR 
		;	
	SET @P_RT_ROLLBACK_FLAG = 'true'
	SET @P_RT_MSG = 'MSG_0001'

END TRY
BEGIN CATCH
	IF (ERROR_MESSAGE()= @P_ERR_MSG)
		BEGIN
			SET @P_ERR_MSG = ERROR_MESSAGE()
			SET @P_RT_ROLLBACK_FLAG = 'false'
			SET @P_RT_MSG = @P_ERR_MSG
		END
	ELSE
		THROW;
		;	
END CATCH;

go

