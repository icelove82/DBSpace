CREATE PROCEDURE [dbo].[SP_UI_BF_16_FC_INPUT_S1] 
(	 @P_ENGINE_TP_CD			NVARCHAR(30) = 'HISTORIC_FP'
	,@P_VER_CD					NVARCHAR(50)
	,@P_RT_ROLLBACK_FLAG		NVARCHAR(10)   = 'true'			OUTPUT
	,@P_RT_MSG					NVARCHAR(4000) = ''				OUTPUT		

)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
/*************************************************************************************************************
	-- Create BF Input Data by Actual Sales (시계열 & 회귀)
	- INPUT 기간 내에 실적 데이터가 없으면?
	-- INPUT_TO_DATE를 2019-12-19로 설정했는데 실적은 9월까지 들어있으면...
	-- Validation을 주지 않았다면 OUTPUT_DATE가 10월부터 만들어진다. => target으로 설정한 기간과 틀어짐

	-- History (Date / Writer / comment)
	- 2019.12.10 / Kimsohee / draft	
	- 2020.01.08 / Kimsohee / version Code를 UI에서 가져와 조회하게 수정
	-- 2020.02.28 / kim sohee / change week rule : DP_WK (53 week per a year) 
*************************************************************************************************************/
-- DECLARE  @P_ENGINE_TP_CD		NVARCHAR(30) = 'STATISTIC_FP'
-- 		,@P_PPY					INT			 = 52
-- 		,@P_PPC					INT			 = 52
	DECLARE @P_ERR_STATUS INT = 0
		   ,@P_ERR_MSG NVARCHAR(4000)=''

		-- 1. For Setting Version Data
DECLARE  @P_INPUT_FROM_DATE		DATE			
		,@P_INPUT_TO_DATE		DATE
		,@P_INPUT_BUKT_CD		NVARCHAR(30)
		,@P_INPUT_HORIZ			INT				
		,@P_SALES_LV_CD			NVARCHAR(100)
		,@P_ITEM_LV_CD			NVARCHAR(100)
		,@P_STD_WEEK			NVARCHAR(30)		
		,@P_LEAF_ITEM_LV_CD		NVARCHAR(100)	-- LEAF LEVEL
		,@P_LEAF_ITEM_CD		NVARCHAR(100)	-- LEAF ITEM
		,@P_LEAF_SALES_LV_CD	NVARCHAR(100)    
		,@P_LEAF_ACCT_CD		NVARCHAR(100)
		;	
BEGIN try
--IF EXISTS ( SELECT *
--			  FROM TB_BF_CONTROL_BOARD_VER_DTL
--			 WHERE VER_CD = @P_VER_CD
--			   AND PROCESS_NO = 1000
--			   AND [STATUS] = 'Completed'
--		 )
--	BEGIN
--	   SET @P_ERR_MSG = 'This version is aleady closed.'
--	   RAISERROR (@P_ERR_MSG,12, 1);  		
--	END
/*************************************************************************************************************
	-- 0. Change Version Detail Data
*************************************************************************************************************/
	UPDATE TB_BF_CONTROL_BOARD_VER_DTL
	   SET RUN_STRT_DATE = GETDATE()
	 WHERE VER_CD = @P_VER_CD
	   AND ENGINE_TP_CD = @P_ENGINE_TP_CD
	;
/*************************************************************************************************************
	-- 1. Setting Version Data
*************************************************************************************************************/
	 SELECT  @P_INPUT_FROM_DATE	= INPUT_FROM_DATE
			,@P_INPUT_TO_DATE	= INPUT_TO_DATE
			,@P_INPUT_BUKT_CD	= INPUT_BUKT_CD
			,@P_INPUT_HORIZ		= INPUT_HORIZ
			,@P_SALES_LV_CD		= SALES_LV_CD
			,@P_ITEM_LV_CD		= ITEM_LV_CD
	  FROM TB_BF_CONTROL_BOARD_VER_DTL
	 WHERE ENGINE_TP_CD = @P_ENGINE_TP_CD 
	   AND VER_CD = @P_VER_CD
	;
	 SELECT @P_STD_WEEK = UPPER(CONF_CD) 
	   FROM TB_CM_COMM_CONFIG 
	  WHERE CONF_GRP_CD = 'DP_STD_WEEK' 
	    AND ACTV_YN = 'Y' 
	    AND USE_YN = 'Y'
--	SET @P_STD_WEEK = 'MON'
	  SELECT @P_LEAF_ITEM_LV_CD = LV_CD 
		FROM TB_CM_LEVEL_MGMT 
	  WHERE ISNULL(SALES_LV_YN  ,'N') = 'N'
		AND ISNULL(ACCOUNT_LV_YN,'N') = 'N'
		AND LV_LEAF_YN = 'Y' 
		AND ISNULL(DEL_YN,'N') = 'N' 
		AND ACTV_YN = 'Y'
	  SELECT @P_LEAF_ITEM_CD = LV_CD 
		FROM TB_CM_LEVEL_MGMT 
	  WHERE ISNULL(SALES_LV_YN  ,'N') = 'N'
		AND ISNULL(ACCOUNT_LV_YN,'N') = 'N'
		AND LEAF_YN = 'Y' 
		AND ISNULL(DEL_YN,'N') = 'N' 
		AND ACTV_YN = 'Y'
	  SELECT @P_LEAF_SALES_LV_CD = LV_CD 
		FROM TB_CM_LEVEL_MGMT 
	  WHERE ISNULL(ACCOUNT_LV_YN,'N') = 'Y'
		AND LV_LEAF_YN = 'Y' 
		AND ISNULL(DEL_YN,'N') = 'N' 
		AND ACTV_YN = 'Y'
	  SELECT @P_LEAF_ACCT_CD = LV_CD 
		FROM TB_CM_LEVEL_MGMT 
	  WHERE ISNULL(ACCOUNT_LV_YN,'N') = 'Y'
		AND LEAF_YN = 'Y' 
		AND ISNULL(DEL_YN,'N') = 'N' 
		AND ACTV_YN = 'Y'
		;																 
---- FOR TEST					
--	SET @P_INPUT_BUKT_CD = 'W'
--	SET @P_INPUT_TO_DATE = '2017-12-04'
--	SET @P_ITEM_LV_CD = 'ITEM_ALL'
--	SET @P_SALES_LV_CD = 'TEAM'
--	SELECT TOP 1 @P_INPUT_FROM_DATE	
--				,@P_INPUT_TO_DATE	
--				,@P_INPUT_BUKT_CD	
--				,@P_INPUT_HORIZ		
--				,@P_SALES_LV_CD		
--				,@P_ITEM_LV_CD		
--	;
/*************************************************************************************************************
	-- 2. Crete Temp Result Input Table
*************************************************************************************************************/
CREATE TABLE #TB_TMP_INPUT 
(	 ITEMID0		NVARCHAR(100)	COLLATE DATABASE_DEFAULT
	,ITEMID1		NVARCHAR(100)	COLLATE DATABASE_DEFAULT
	,[DESCRIPTION]	NVARCHAR(250)	
	,HIST_YEAR		INT
	,HIST_PERIOD	INT
	,PPY			INT
	,PPC			INT
	,HIST_VALUE		numeric(15, 0)
)		
;
/*************************************************************************************************************
	-- 3. Making Input data
*************************************************************************************************************/
WITH CALENDAR
AS (
	SELECT DAT		AS STRT_DATE
		, ISNULL ((LEAD(DAT,1)  OVER ( ORDER BY YYYYMMDD)) -1,@P_INPUT_TO_DATE) AS END_DATE
		, YYYY
		, DP_WK AS [WEEK]
		, [MM]		
		, YYYYMMDD
		, CASE @P_INPUT_BUKT_CD
		 			WHEN 'W' THEN (SELECT MAX(DP_WK) FROM TB_CM_CALENDAR WHERE YYYY = M.YYYY) --52
		 			WHEN 'M' THEN 12
		 			WHEN 'D' THEN 365
		  END								AS PP
	  FROM TB_CM_CALENDAR M
     WHERE DAT BETWEEN @P_INPUT_FROM_DATE AND @P_INPUT_TO_DATE
	   AND CASE WHEN @P_INPUT_BUKT_CD = 'M' THEN DD ELSE 1 END = 1 
	   AND CASE WHEN @P_INPUT_BUKT_CD = 'W' THEN DOW_NM ELSE @P_STD_WEEK END = @P_STD_WEEK 	 
   ), ACT_SALES
AS (
	--SELECT  BASE_DATE
	--	 ,  'ITEM' ITEM_MST_ID
	--	 ,  'ACCT' ACCOUNT_ID
	--	 ,  QTY
	--  FROM TB_BF_TMP_DATA
	-- WHERE BASE_DATE BETWEEN @P_INPUT_FROM_DATE AND @P_INPUT_TO_DATE	  
	SELECT  BASE_DATE
		 ,  ITEM_MST_ID
		 ,  ACCOUNT_ID
		 ,  CASE CORRECTION_YN WHEN 'Y' THEN QTY_CORRECTION ELSE QTY END  AS QTY
	  FROM TB_CM_ACTUAL_SALES
	 WHERE BASE_DATE BETWEEN @P_INPUT_FROM_DATE AND @P_INPUT_TO_DATE	  
  ), TB_PR_ITEM_LEVEL_MGMT 
  ( ID
  , PATH_CD
  , PATH_ID
  , LV_CD
  , LEAF_ITEM_LV_ID
  , LEAF_ITEM_LV_CD
  ) 
AS(
		SELECT SL.ID
			 , CONVERT(NVARCHAR(4000), SL.ITEM_LV_CD) PATH_CD
			 , CONVERT(NVARCHAR(4000), SL.ID) [PATH_ID]
			 , LM.LV_CD
			 , SL.ID	AS LEAF_ITEM_LV_ID
			 , SL.ITEM_LV_CD AS LEAF_ITEM_LV_CD
		  FROM TB_CM_ITEM_LEVEL_MGMT SL
			   INNER JOIN
			   TB_CM_LEVEL_MGMT LM
			ON SL.LV_MGMT_ID = LM.ID
		 WHERE LV_CD = @P_ITEM_LV_CD
		UNION ALL	
		SELECT SL.ID
			 , CONVERT(NVARCHAR(4000), PATH_CD+'/'+SL.ITEM_LV_CD) AS PATH_CD		
			 , CONVERT(NVARCHAR(4000), [PATH_ID]+'/'+SL.ID) AS [PATH_ID]		
			 , LM.LV_CD
			 , SL.ID	AS LEAF_ITEM_LV_ID
			 , SL.ITEM_LV_CD AS LEAF_ITEM_LV_CD
		  FROM TB_CM_ITEM_LEVEL_MGMT SL
			   INNER JOIN
			   TB_PR_ITEM_LEVEL_MGMT PL
			ON SL.PARENT_ITEM_LV_ID = PL.ID
			   INNER JOIN
			   TB_CM_LEVEL_MGMT LM
			ON SL.LV_MGMT_ID = LM.ID
		 WHERE ISNULL(LM.DEL_YN,'N') = 'N'
		   AND ISNULL(SL.DEL_YN,'N') = 'N'
		   AND ISNULL(LM.SALES_LV_YN  ,'N') = 'N'
		   AND LM.ACTV_YN = 'Y'
		   AND SL.ACTV_YN = 'Y'
), TB_PR_SALES_LEVEL_MGMT 
 ( ID
 , PATH_CD
 , PATH_ID
 , LV_CD
 , LEAF_SALES_LV_ID
 , LEAF_SALES_LV_CD
 ) 
AS(
		SELECT SL.ID
			 , CONVERT(NVARCHAR(4000), SL.SALES_LV_CD) PATH_CD
			 , CONVERT(NVARCHAR(4000), SL.ID) [PATH_ID]
			 , LM.LV_CD
			 , SL.ID	AS LEAF_SALES_LV_ID
			 , SL.SALES_LV_CD AS LEAF_SALES_LV_CD
		  FROM TB_DP_SALES_LEVEL_MGMT SL
			   INNER JOIN
			   TB_CM_LEVEL_MGMT LM
			ON SL.LV_MGMT_ID = LM.ID
		 WHERE LV_CD = @P_SALES_LV_CD
		UNION ALL	
		SELECT SL.ID
			 , CONVERT(NVARCHAR(4000), PATH_CD+'/'+SL.SALES_LV_CD) AS PATH_CD		
			 , CONVERT(NVARCHAR(4000), [PATH_ID]+'/'+SL.ID) AS [PATH_ID]		
			 , LM.LV_CD
			 , SL.ID	AS LEAF_SALES_LV_ID
			 , SL.SALES_LV_CD AS LEAF_SALES_LV_CD
		  FROM TB_DP_SALES_LEVEL_MGMT SL
			   INNER JOIN
			   TB_PR_SALES_LEVEL_MGMT PL
			ON SL.PARENT_SALES_LV_ID = PL.ID
			   INNER JOIN
			   TB_CM_LEVEL_MGMT LM
			ON SL.LV_MGMT_ID = LM.ID
		 WHERE ISNULL(LM.DEL_YN,'N') = 'N'
		   AND ISNULL(SL.DEL_YN,'N') = 'N'
		   AND ISNULL(LM.SALES_LV_YN  ,'N') = 'Y'
		   AND LM.ACTV_YN = 'Y'
		   AND SL.ACTV_YN = 'Y'
), ITEM
AS (
		 SELECT I.ITEM_CD
			  , I.ID			AS ITEM_ID
			  , PATH_CD
			  , CASE WHEN @P_ITEM_LV_CD = @P_LEAF_ITEM_LV_CD THEN LEAF_ITEM_LV_CD ELSE LEFT(M.[PATH_CD], CHARINDEX('/', M.[PATH_CD])-1)  END AS TOP_ITEM_LV
  		   FROM TB_CM_ITEM_MST I
				LEFT OUTER JOIN
				( SELECT M.LEAF_ITEM_LV_ID
						,M.LEAF_ITEM_LV_CD
  						,M.PATH_CD	AS PATH_CD
				    FROM TB_PR_ITEM_LEVEL_MGMT M
   				   WHERE M.LV_CD =@P_LEAF_ITEM_LV_CD
				) M
			ON  LEAF_ITEM_LV_ID = I.PARENT_ITEM_LV_ID
		  WHERE ISNULL(I.DEL_YN,'N') = 'N'
		    AND I.PARENT_ITEM_LV_ID IS NOT NULL
), ACCT
AS (
		 SELECT A.ACCOUNT_CD	AS ACCT_CD
			  , A.ID			AS ACCT_ID
			  , PATH_CD
			  , CASE WHEN @P_SALES_LV_CD = @P_LEAF_SALES_LV_CD THEN LEAF_SALES_LV_CD ELSE LEFT(M.[PATH_CD], CHARINDEX('/', M.[PATH_CD])-1)  END AS TOP_SALES_LV
  		   FROM TB_DP_ACCOUNT_MST A
				LEFT OUTER JOIN
				( SELECT M.LEAF_SALES_LV_ID
						,M.LEAF_SALES_LV_CD
  						,M.PATH_CD	AS PATH_CD
				    FROM TB_PR_SALES_LEVEL_MGMT M
   				   WHERE M.LV_CD =@P_LEAF_SALES_LV_CD
				) M
			ON  LEAF_SALES_LV_ID = A.PARENT_SALES_LV_ID
		  WHERE ISNULL(A.DEL_YN,'N') = 'N'
		    AND A.PARENT_SALES_LV_ID IS NOT NULL
)
/*************************************************************************************************************
	-- 3. Insert actual sales into temp table
*************************************************************************************************************/
INSERT INTO #TB_TMP_INPUT
(	ITEMID0, ITEMID1, [DESCRIPTION], HIST_YEAR, HIST_PERIOD, PPY, PPC, HIST_VALUE
)
	SELECT CASE WHEN @P_ITEM_LV_CD = @P_LEAF_ITEM_CD 
				THEN I.ITEM_CD 
				ELSE I.TOP_ITEM_LV 
			END											AS ITEMID0
		 , CASE WHEN @P_SALES_LV_CD = @P_LEAF_ACCT_CD 
				THEN A.ACCT_CD 
				ELSE A.TOP_SALES_LV 
			END											AS ITEMID1
		, CASE WHEN @P_ITEM_LV_CD = @P_LEAF_ITEM_CD 
				THEN I.ITEM_CD 
				ELSE I.TOP_ITEM_LV 
			END											AS [DESCRIPTION]
		 , C.YYYY										AS HIST_YEAR
		 , CASE @P_INPUT_BUKT_CD 
			WHEN 'W' THEN C.[WEEK]
			WHEN 'M' THEN C.MM
			WHEN 'D' THEN YYYYMMDD
		   END 											AS HIST_PERIOD
		 , C.PP											AS PPY						-- MAX_WK
		 , C.PP											AS PPC						-- MAX_WK
		 , SUM(ISNULL(S.QTY,0))							AS HIST_VALUE
	  FROM CALENDAR C
		   LEFT OUTER JOIN
		   ACT_SALES S ON S.BASE_DATE BETWEEN C.STRT_DATE AND C.END_DATE 
		   INNER JOIN
		   ITEM I	   ON S.ITEM_MST_ID = I.ITEM_ID 
		   INNER JOIN
		   ACCT A	   ON S.ACCOUNT_ID = A.ACCT_ID
  GROUP BY CASE WHEN @P_ITEM_LV_CD = @P_LEAF_ITEM_CD THEN I.ITEM_CD ELSE I.TOP_ITEM_LV END
		 , CASE WHEN @P_SALES_LV_CD = @P_LEAF_ACCT_CD THEN A.ACCT_CD ELSE A.TOP_SALES_LV END
		 , C.YYYY
		 , C.PP
--		 , MAX_WK
		 , CASE @P_INPUT_BUKT_CD 
			WHEN 'W' THEN C.[WEEK]
			WHEN 'M' THEN C.MM
			WHEN 'D' THEN YYYYMMDD
		   END 		 
OPTION(maxrecursion 0) 		   
	  ;
/*************************************************************************************************************
	-- 3. Insert real input table
	REGRESSION_FP
	STATISTIC_FP
*************************************************************************************************************/
IF (@P_ENGINE_TP_CD = 'REGRESSION_FP')
	BEGIN
		TRUNCATE TABLE TB_BF_FC_REG_INPUT	-- Regression
		INSERT INTO TB_BF_FC_REG_INPUT 
		(	ITEMID0, ITEMID1, [DESCRIPTION], HIST_YEAR, HIST_PERIOD, PPY, PPC, HIST_VALUE
		)
		SELECT INP.ITEMID0
			 , INP.ITEMID1
			 , INP.[DESCRIPTION]
			 , INP.HIST_YEAR
			 , INP.HIST_PERIOD
			 , INP.PPY
			 , INP.PPC
			 , INP.HIST_VALUE	 
		  FROM #TB_TMP_INPUT INP
			  INNER JOIN
			  ( SELECT ITEM_CD, ACCOUNT_CD
			      FROM TB_BF_ITEM_ACCOUNT_MODEL_MAP
				 WHERE 1=1
				   AND ACTV_YN = 'Y'
				   AND ENGINE_TP_CD = @P_ENGINE_TP_CD
			  GROUP BY ITEM_CD, ACCOUNT_CD
			  ) IAM
		   ON INP.ITEMID0 = IAM.ITEM_CD
		  AND INP.ITEMID1 = IAM.ACCOUNT_CD
		-- START TO EXECUTE FACTOR PROCEDURE
		EXEC SP_UI_BF_16_FC_INPUT_FAC  @P_ENGINE_TP_CD      = @P_ENGINE_TP_CD
									  ,@P_INPUT_FROM_DATE	= @P_INPUT_FROM_DATE		
									  ,@P_INPUT_TO_DATE		= @P_INPUT_TO_DATE		
									  ,@P_INPUT_BUKT_CD		= @P_INPUT_BUKT_CD		
									  ,@P_INPUT_HORIZ		= @P_INPUT_HORIZ			
									  ,@P_SALES_LV_CD		= @P_SALES_LV_CD			
									  ,@P_ITEM_LV_CD		= @P_ITEM_LV_CD			
									  ,@P_STD_WEEK			= @P_STD_WEEK			
									  ,@P_LEAF_ITEM_LV_CD	= @P_LEAF_ITEM_LV_CD		
									  ,@P_LEAF_ITEM_CD		= @P_LEAF_ITEM_CD		
									  ,@P_LEAF_SALES_LV_CD	= @P_LEAF_SALES_LV_CD	
									  ,@P_LEAF_ACCT_CD		= @P_LEAF_ACCT_CD		
									  ,@P_RT_ROLLBACK_FLAG	= @P_RT_ROLLBACK_FLAG	OUTPUT
									  ,@P_RT_MSG			= @P_RT_MSG				OUTPUT		
									  ;
	-- Extract correct data
	DELETE 
	  FROM TB_BF_FC_REG_INPUT
	 WHERE ITEMID0+'_'+ITEMID1  IN
	 ( 	 SELECT ITEMID0+'_'+ITEMID1
		  FROM TB_BF_FC_REG_INPUT
		 GROUP BY ITEMID0, ITEMID1 
		 HAVING COUNT(HIST_PERIOD) <= 2
	)
	END
ELSE IF (@P_ENGINE_TP_CD = 'STATISTIC_FP')
	BEGIN
		TRUNCATE TABLE TB_BF_FC_BYPRDT_INPUT	-- 시계열
		INSERT INTO TB_BF_FC_BYPRDT_INPUT 
		(	ITEMID0, ITEMID1, [DESCRIPTION], HIST_YEAR, HIST_PERIOD, PPY, PPC, HIST_VALUE
		)
		SELECT INP.ITEMID0
			 , INP.ITEMID1
			 , INP.[DESCRIPTION]
			 , INP.HIST_YEAR
			 , INP.HIST_PERIOD
			 , INP.PPY
			 , INP.PPC
			 , INP.HIST_VALUE	 	 
		  FROM #TB_TMP_INPUT INP
			  INNER JOIN
			  ( SELECT ITEM_CD, ACCOUNT_CD
			      FROM TB_BF_ITEM_ACCOUNT_MODEL_MAP
				 WHERE 1=1
				   AND ACTV_YN = 'Y'
				   AND ENGINE_TP_CD = @P_ENGINE_TP_CD
			  GROUP BY ITEM_CD, ACCOUNT_CD
			  ) IAM
		   ON INP.ITEMID0 = IAM.ITEM_CD
		  AND INP.ITEMID1 = IAM.ACCOUNT_CD

	END
	 

	    SET @P_RT_MSG = 'MSG_0001'
	    SET @P_RT_ROLLBACK_FLAG = 'true'
END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END
	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR
END CATCH



go

