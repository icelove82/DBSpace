/*****************************************************************************
Title : SP_UI_MP_06_Q4
최초 작성자 : 조아람
최초 생성일 : 2017.08.10
 
설명 
 - MP Resource Management(UI_MP_06) Resource - Resource Management Period Capa 조회 프로시저
 
History (수정일자 / 수정자 / 수정내용)
- 2017.08.10 / 조아람 / 최초 작성
*****************************************************************************/
CREATE PROCEDURE [dbo].[SP_UI_MP_06_Q4] (
	 @P_RES_DTL_ID		CHAR(32) = ''
) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN
	
    SELECT PRM.ID				AS ID
         , DTL.ID			    AS RES_ID
         , DTL.RES_CD
         , DTL.RES_DESCRIP
         , PRM.STRT_DATE
         , PRM.END_DATE
         , PRM.CAPA_VAL
         , PRM.OVR_CAPA_VAL
         , PRM.EFFICY_VAL
         , PRM.MAX_PRDUCT_MODEL_VAL
         , PRM.GRP_APPY_YN
         , PRM.ACTV_YN
      FROM TB_MP_RES_MGMT_DTL DTL
           INNER JOIN TB_MP_PERIOD_RES_MGMT PRM
           ON DTL.ID = PRM.RES_ID
     WHERE DTL.ID = @P_RES_DTL_ID
     ORDER BY PRM.STRT_DATE, PRM.END_DATE

END

go

