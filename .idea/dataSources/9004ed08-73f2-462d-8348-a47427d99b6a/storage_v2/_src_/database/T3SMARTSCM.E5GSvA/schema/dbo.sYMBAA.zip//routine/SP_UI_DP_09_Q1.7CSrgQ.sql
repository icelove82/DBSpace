/*****************************************************************************
Title : SP_UI_DP_09_Q1
최초 작성자 : 민희영
최초 생성일 : 2017.06.20
 
설명 
 - CM Item Master
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 민희영 / 최초 작성
- 2019.01.17 / 민경훈 / 다중검색 특수기호 처리
- 2019.01.17 / 김소희 / 대소문자 구분 없이 조회
DP -------------------------------------------- CM
- 2019.02.12 / 김소희 / CM 공통화
- 2019.04.29 / 김소희 / Item Name이 null일때 조회 가능하게
DP---------------------------------------------
- 2022.11.21 /서은하 / CM 과 분리
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_09_Q1] (
	@p_ITEM_TREE	NVARCHAR(30) = '',
	@P_ITEM_TP_ID	CHAR(32) = '',
	@p_ITEM_CD		NVARCHAR(4000) = '',
	@p_ITEM_NM		NVARCHAR(4000) = '',
	@p_DEL_YN		CHAR(1) = '',
	@p_DP_PLAN_YN	NVARCHAR(1),
	@p_ATTR_01		NVARCHAR(4000) = '',
	@p_ATTR_02		NVARCHAR(4000) = '',
	@p_ATTR_03		NVARCHAR(4000) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN
        SELECT  A.ID 
			, A.ITEM_CD
			, A.ITEM_NM
			, A.ITEM_TP_ID
            , A.MIN_ORDER_SIZE
            , A.MAX_ORDER_SIZE
			, CONVERT(DATETIME, A.EOS,112)  AS EOS      
			, CONVERT(DATETIME, A.RTS,112)  AS RTS  
			, A.UOM_ID
			--, C.UOM_NM
			, C.UOM_NM
			, A.DESCRIP
			, A.DP_PLAN_YN
			, A.DEL_YN
			, A.PARENT_ITEM_LV_ID 
			, A.PARENT_ITEM_LV_ID_AD1 
			, A.PARENT_ITEM_LV_ID_AD2 
			, A.PARENT_ITEM_LV_ID_AD3 
			, D.ITEM_LV_CD   AS PARENT_ITEM_LV_CD
			, D.ITEM_LV_NM   AS PARENT_ITEM_LV_NM
			, A.ATTR_01
			, A.ATTR_02
			, A.ATTR_03
			, A.ATTR_04
			, A.ATTR_05
			, A.ATTR_06
			, A.ATTR_07
			, A.ATTR_08
			, A.ATTR_09
			, A.ATTR_10
			, A.ATTR_11
			, A.ATTR_12
			, A.ATTR_13
			, A.ATTR_14
			, A.ATTR_15
			, A.ATTR_16
			, A.ATTR_17
			, A.ATTR_18
			, A.ATTR_19
			, A.ATTR_20
			, A.ATTR_21
			, A.ATTR_22
			, A.ATTR_23
			, A.ATTR_24
			, A.ATTR_25
			, A.DISPLAY_COLOR
			, A.CREATE_BY
			, A.CREATE_DTTM
			, A.MODIFY_BY
			, A.MODIFY_DTTM
		FROM    TB_CM_ITEM_MST A
			    LEFT OUTER JOIN  TB_CM_UOM C             ON A.UOM_ID = C.ID	 AND  C.ACTV_YN = 'Y'
				LEFT OUTER JOIN  TB_CM_ITEM_LEVEL_MGMT D ON A.PARENT_ITEM_LV_ID = D.ID  AND  D.ACTV_YN = 'Y'
		WHERE 1=1
		AND (A.PARENT_ITEM_LV_ID LIKE '%' + @p_ITEM_TREE + '%' OR ISNULL(@p_ITEM_TREE,'')='')
		AND (A.ITEM_TP_ID LIKE '%' + @P_ITEM_TP_ID + '%' OR ISNULL(@P_ITEM_TP_ID,'')='')
		AND ISNULL(A.DEL_YN,'N') LIKE '%' + RTRIM(@p_DEL_YN) + '%'
		AND ISNULL(A.DP_PLAN_YN,'N') LIKE '%' + RTRIM(@P_DP_PLAN_YN) + '%'
		AND (  'Y' = CASE WHEN @P_ITEM_CD = '' THEN 'Y'
		        ELSE ( case when
		         UPPER(A.ITEM_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_CD),''),'|'))
		          OR
		         UPPER(A.ITEM_CD) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_CD),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
		          then 'Y' else 'N' end
				  )
				 END
		  )

		AND (  'Y' = CASE WHEN @p_ITEM_NM = '' THEN 'Y'
		        ELSE ( case when
		         UPPER(A.ITEM_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@p_ITEM_NM),''),'|'))
		          OR
		         UPPER(A.ITEM_NM) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@p_ITEM_NM),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
		          then 'Y' else 'N' end
				  )
				 END
		  )
			
		AND (  'Y' = CASE WHEN @p_ATTR_01 = '' THEN 'Y'
			        ELSE ( 
			         case when
			          UPPER(A.ATTR_01) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@p_ATTR_01),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
			          then 'Y' else 'N' end
			         )
			         END
			  )
		AND (  'Y' = CASE WHEN @p_ATTR_02 = '' THEN 'Y'
			        ELSE ( 
			         case when
			          UPPER(A.ATTR_02) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@p_ATTR_02),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
			          then 'Y' else 'N' end
			         )
			         END
			  )
		AND (  'Y' = CASE WHEN @p_ATTR_03 = '' THEN 'Y'
			        ELSE ( 
			         case when
			          UPPER(A.ATTR_03) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@p_ATTR_03),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
			          then 'Y' else 'N' end
			         )
			         END
			  )
		ORDER BY D.SEQ, D.ITEM_LV_CD, A.ITEM_CD
		;
END

go

