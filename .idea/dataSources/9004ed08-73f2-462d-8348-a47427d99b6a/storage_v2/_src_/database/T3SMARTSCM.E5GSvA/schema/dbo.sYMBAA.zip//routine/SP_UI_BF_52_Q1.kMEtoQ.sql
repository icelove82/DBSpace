/*
	-- History (Date / Writer / Comment)
	-- 2020.01.17 / Kim sohee / make accuracy data dynamically by using a function of Cross tab 
	-- 2020.01.20 / Kim sohee / get Best Engine Type for marking on a grid 
    -- 2021.07.28 / suchang.park / Version PROCESS_NO 변경 (best selection 990 -> 990000)
*/
CREATE PROCEDURE [dbo].[SP_UI_BF_52_Q1] 
	@P_VER_CD NVARCHAR(100) = NULL
  , @P_ITEM_CD		NVARCHAR(1000) = ''
  , @P_ITEM_NM		NVARCHAR(1000) = ''
  , @P_ACCOUNT_CD	NVARCHAR(1000) = ''
  , @P_ACCOUNT_NM	NVARCHAR(1000) = ''
AS 

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON;

SET @P_ACCOUNT_CD = CASE WHEN @P_ACCOUNT_CD = '' THEN NULL ELSE @P_ACCOUNT_CD END
SET @P_ACCOUNT_NM = CASE WHEN @P_ACCOUNT_NM = '' THEN NULL ELSE @P_ACCOUNT_NM END
SET @P_ITEM_CD = CASE WHEN @P_ITEM_CD = '' THEN NULL ELSE @P_ITEM_CD END
SET @P_ITEM_NM = CASE WHEN @P_ITEM_NM = '' THEN NULL ELSE @P_ITEM_NM END

DECLARE @P_ACCURACY NVARCHAR(30);

SELECT @P_ACCURACY = RULE_01
  FROM TB_BF_CONTROL_BOARD_VER_DTL
 WHERE VER_CD = @P_VER_CD
   AND PROCESS_NO = '990000'

BEGIN

WITH RF
AS (
	SELECT RF.ITEM_CD
		 , IM.ITEM_NM 
		 , IM.ATTR_05						 
		 , RF.ACCOUNT_CD					 
		 , AM.ACCOUNT_NM					 
		 , ENGINE_TP_CD						 
		 , CASE @P_ACCURACY					 
			WHEN 'MAPE'		THEN MAPE		 
			WHEN 'MAE'		THEN MAE		 
			WHEN 'MAE_P'	THEN MAE_P		 
			WHEN 'RMSE'		THEN RMSE		 
			WHEN 'RMSE_P'	THEN RMSE_P
			WHEN 'MAPE_W'	THEN MAPE_W		
			WHEN 'WAPE'		THEN WAPE		
		   END								AS ACCRY
		 , RF.CREATE_BY
		 , RF.CREATE_DTTM
		 , RF.MODIFY_BY
		 , RF.MODIFY_DTTM	
		 , RF.SELECT_SEQ
		 , RF.VER_CD						 
	  FROM TB_BF_RT_ACCRCY RF
		   INNER JOIN
		   TB_CM_ITEM_MST IM
		ON RF.ITEM_CD = IM.ITEM_CD
		   INNER JOIN
		   TB_DP_ACCOUNT_MST AM
		ON RF.ACCOUNT_CD = AM.ACCOUNT_CD		   

	 WHERE 1=1
	 	AND VER_CD = @P_VER_CD
	 	AND (  ( @P_ACCOUNT_CD LIKE '%|%' AND UPPER(RF.ACCOUNT_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_CD),''),'|')) 
     		)OR(@P_ACCOUNT_CD NOT LIKE '%|%' AND UPPER(RF.ACCOUNT_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
     		OR @P_ACCOUNT_CD IS NULL 
     		)
	 	AND (  ( @P_ACCOUNT_NM LIKE '%|%' AND UPPER(AM.ACCOUNT_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_NM),''),'|')) 
     		)OR(@P_ACCOUNT_NM NOT LIKE '%|%' AND UPPER(AM.ACCOUNT_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
     		OR @p_ACCOUNT_NM IS NULL 
     		)
	 	AND (  ( @P_ITEM_CD LIKE '%|%' AND UPPER(RF.ITEM_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_CD),''),'|')) 
     		)OR(@P_ITEM_CD NOT LIKE '%|%' AND UPPER(RF.ITEM_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
     		OR @P_ITEM_CD IS NULL 
     		)
	 	AND (  ( @P_ITEM_NM LIKE '%|%' AND UPPER(IM.ITEM_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_NM),''),'|')) 
     		)OR(@P_ITEM_NM NOT LIKE '%|%' AND UPPER(IM.ITEM_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
     		OR @P_ITEM_NM IS NULL 
     		)
), RF_BEST 
AS (
	SELECT ITEM_CD
		 , ACCOUNT_CD
		 , ENGINE_TP_CD 
	  FROM RF 
	 WHERE SELECT_SEQ = 1 
)
	SELECT DISTINCT
		   RF.ITEM_CD
		 , RF.ITEM_NM 
		 , RF.ATTR_05						AS ITEM_GRADE
		 , RF.ACCOUNT_CD
		 , RF.ACCOUNT_NM
		 , RF.ENGINE_TP_CD					AS ENGINE_TP_CD 
		 , RF.ACCRY
		 , RF.CREATE_BY
		 , RF.CREATE_DTTM
		 , RF.MODIFY_BY
		 , RF.MODIFY_DTTM	
		 , 'ENGINE_TP_CD_'+RB.ENGINE_TP_CD					AS BEST_ENGINE
		 , RF.VER_CD						AS VER_ID 
	  FROM RF
		   LEFT OUTER JOIN
		   RF_BEST RB
		ON RF.ITEM_CD =  RB.ITEM_CD
	   AND RF.ACCOUNT_CD = RB.ACCOUNT_CD



--	IF @P_ACCURACY = 'MAPE'
--	BEGIN
--		 SELECT VER_CD AS VER_ID
--				  , RF.ACCOUNT_CD
--				  , AM.ACCOUNT_NM
--				  , RFITEM_CD
--				  , IM.ITEM_NM
--				  , IM.ATTR_01 AS ITEM_GRADE
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'REGRESSION_FP' THEN MAPE
--															     ELSE null END) AS REG_ACCRY
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'STATISTIC_FP'  THEN MAPE
--															     ELSE null END) AS STATISTIC_ACCRY
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'TF'            THEN MAPE
--															     ELSE null END) AS TF_ACCRY
--				  , MAX(RFCREATE_BY)	AS CREATE_BY
--				  , MAX(RFCREATE_DTTM) AS CREATE_DTTM
--				  , MAX(RFMODIFY_BY  )	AS MODIFY_BY
--				  , MAX(RFMODIFY_DTTM)	AS MODIFY_DTTM
--			   FROM TB_BF_RT_ACCRCY AC
--			  INNER JOIN TB_DP_ACCOUNT_MST AM ON RF.ACCOUNT_CD = AM.ACCOUNT_CD
--			  INNER JOIN TB_CM_ITEM_MST    IM ON RFITEM_CD    = IM.ITEM_CD
--			  WHERE 1=1
--				AND VER_CD = @P_VER_CD
--				AND (  ( @P_ACCOUNT_CD LIKE '%|%' AND UPPER(RF.ACCOUNT_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_CD),''),'|')) 
--        			)OR(@P_ACCOUNT_CD NOT LIKE '%|%' AND UPPER(RF.ACCOUNT_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ACCOUNT_CD IS NULL 
--        			)
--				AND (  ( @P_ACCOUNT_NM LIKE '%|%' AND UPPER(AM.ACCOUNT_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_NM),''),'|')) 
--        			)OR(@P_ACCOUNT_NM NOT LIKE '%|%' AND UPPER(AM.ACCOUNT_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @p_ACCOUNT_NM IS NULL 
--        			)
--				AND (  ( @P_ITEM_CD LIKE '%|%' AND UPPER(RFITEM_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_CD),''),'|')) 
--        			)OR(@P_ITEM_CD NOT LIKE '%|%' AND UPPER(RFITEM_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ITEM_CD IS NULL 
--        			)
--				AND (  ( @P_ITEM_NM LIKE '%|%' AND UPPER(IM.ITEM_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_NM),''),'|')) 
--        			)OR(@P_ITEM_NM NOT LIKE '%|%' AND UPPER(IM.ITEM_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ITEM_NM IS NULL 
--        			)
--			GROUP BY VER_CD, RF.ACCOUNT_CD, AM.ACCOUNT_NM, RFITEM_CD, IM.ITEM_NM, IM.ATTR_01
--			  ;
--	END
--	ELSE IF @P_ACCURACY = 'MAE'
--	BEGIN
--		 SELECT VER_CD AS VER_ID
--				  , RF.ACCOUNT_CD
--				  , AM.ACCOUNT_NM
--				  , RFITEM_CD
--				  , IM.ITEM_NM
--				  , IM.ATTR_01 AS ITEM_GRADE
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'REGRESSION_FP' THEN MAE
--															     ELSE null END) AS REG_ACCRY
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'STATISTIC_FP'  THEN MAE
--															     ELSE null END) AS STATISTIC_ACCRY
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'TF'            THEN MAE
--															     ELSE null END) AS TF_ACCRY
--				  , MAX(RFCREATE_BY)	AS CREATE_BY
--				  , MAX(RFCREATE_DTTM) AS CREATE_DTTM
--				  , MAX(RFMODIFY_BY  )	AS MODIFY_BY
--				  , MAX(RFMODIFY_DTTM)	AS MODIFY_DTTM
--			   FROM TB_BF_RT_ACCRCY AC
--			  INNER JOIN TB_DP_ACCOUNT_MST AM ON RF.ACCOUNT_CD = AM.ACCOUNT_CD
--			  INNER JOIN TB_CM_ITEM_MST    IM ON RFITEM_CD    = IM.ITEM_CD
--			  WHERE 1=1
--				AND VER_CD = @P_VER_CD
--				AND (  ( @P_ACCOUNT_CD LIKE '%|%' AND UPPER(RF.ACCOUNT_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_CD),''),'|')) 
--        			)OR(@P_ACCOUNT_CD NOT LIKE '%|%' AND UPPER(RF.ACCOUNT_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ACCOUNT_CD IS NULL 
--        			)
--				AND (  ( @P_ACCOUNT_NM LIKE '%|%' AND UPPER(AM.ACCOUNT_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_NM),''),'|')) 
--        			)OR(@P_ACCOUNT_NM NOT LIKE '%|%' AND UPPER(AM.ACCOUNT_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @p_ACCOUNT_NM IS NULL 
--        			)
--				AND (  ( @P_ITEM_CD LIKE '%|%' AND UPPER(RFITEM_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_CD),''),'|')) 
--        			)OR(@P_ITEM_CD NOT LIKE '%|%' AND UPPER(RFITEM_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ITEM_CD IS NULL 
--        			)
--				AND (  ( @P_ITEM_NM LIKE '%|%' AND UPPER(IM.ITEM_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_NM),''),'|')) 
--        			)OR(@P_ITEM_NM NOT LIKE '%|%' AND UPPER(IM.ITEM_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ITEM_NM IS NULL 
--        			)
--			GROUP BY VER_CD, RF.ACCOUNT_CD, AM.ACCOUNT_NM, RFITEM_CD, IM.ITEM_NM, IM.ATTR_01
--			  ;
--	END
--	ELSE IF @P_ACCURACY = 'MAE_P'
--	BEGIN
--		 SELECT VER_CD AS VER_ID
--				  , RF.ACCOUNT_CD
--				  , AM.ACCOUNT_NM
--				  , RFITEM_CD
--				  , IM.ITEM_NM
--				  , IM.ATTR_01 AS ITEM_GRADE
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'REGRESSION_FP' THEN MAE_P
--															     ELSE null END) AS REG_ACCRY
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'STATISTIC_FP'  THEN MAE_P
--															     ELSE null END) AS STATISTIC_ACCRY
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'TF'            THEN MAE_P
--															     ELSE null END) AS TF_ACCRY
--				  , MAX(RFCREATE_BY)	AS CREATE_BY
--				  , MAX(RFCREATE_DTTM) AS CREATE_DTTM
--				  , MAX(RFMODIFY_BY  )	AS MODIFY_BY
--				  , MAX(RFMODIFY_DTTM)	AS MODIFY_DTTM
--			   FROM TB_BF_RT_ACCRCY AC
--			  INNER JOIN TB_DP_ACCOUNT_MST AM ON RF.ACCOUNT_CD = AM.ACCOUNT_CD
--			  INNER JOIN TB_CM_ITEM_MST    IM ON RFITEM_CD    = IM.ITEM_CD
--			  WHERE 1=1
--				AND VER_CD = @P_VER_CD
--				AND (  ( @P_ACCOUNT_CD LIKE '%|%' AND UPPER(RF.ACCOUNT_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_CD),''),'|')) 
--        			)OR(@P_ACCOUNT_CD NOT LIKE '%|%' AND UPPER(RF.ACCOUNT_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ACCOUNT_CD IS NULL 
--        			)
--				AND (  ( @P_ACCOUNT_NM LIKE '%|%' AND UPPER(AM.ACCOUNT_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_NM),''),'|')) 
--        			)OR(@P_ACCOUNT_NM NOT LIKE '%|%' AND UPPER(AM.ACCOUNT_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @p_ACCOUNT_NM IS NULL 
--        			)
--				AND (  ( @P_ITEM_CD LIKE '%|%' AND UPPER(RFITEM_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_CD),''),'|')) 
--        			)OR(@P_ITEM_CD NOT LIKE '%|%' AND UPPER(RFITEM_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ITEM_CD IS NULL 
--        			)
--				AND (  ( @P_ITEM_NM LIKE '%|%' AND UPPER(IM.ITEM_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_NM),''),'|')) 
--        			)OR(@P_ITEM_NM NOT LIKE '%|%' AND UPPER(IM.ITEM_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ITEM_NM IS NULL 
--        			)
--			GROUP BY VER_CD, RF.ACCOUNT_CD, AM.ACCOUNT_NM, RFITEM_CD, IM.ITEM_NM, IM.ATTR_01
--			  ;
--	END
--	ELSE IF @P_ACCURACY = 'RMSE'
--	BEGIN
--		 SELECT VER_CD AS VER_ID
--				  , RF.ACCOUNT_CD
--				  , AM.ACCOUNT_NM
--				  , RFITEM_CD
--				  , IM.ITEM_NM
--				  , IM.ATTR_01 AS ITEM_GRADE
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'REGRESSION_FP' THEN RMSE
--															     ELSE null END) AS REG_ACCRY
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'STATISTIC_FP'  THEN RMSE
--															     ELSE null END) AS STATISTIC_ACCRY
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'TF'            THEN RMSE
--															     ELSE null END) AS TF_ACCRY
--				  , MAX(RFCREATE_BY)	AS CREATE_BY
--				  , MAX(RFCREATE_DTTM) AS CREATE_DTTM
--				  , MAX(RFMODIFY_BY  )	AS MODIFY_BY
--				  , MAX(RFMODIFY_DTTM)	AS MODIFY_DTTM
--			   FROM TB_BF_RT_ACCRCY AC
--			  INNER JOIN TB_DP_ACCOUNT_MST AM ON RF.ACCOUNT_CD = AM.ACCOUNT_CD
--			  INNER JOIN TB_CM_ITEM_MST    IM ON RFITEM_CD    = IM.ITEM_CD
--			  WHERE 1=1
--				AND VER_CD = @P_VER_CD
--				AND (  ( @P_ACCOUNT_CD LIKE '%|%' AND UPPER(RF.ACCOUNT_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_CD),''),'|')) 
--        			)OR(@P_ACCOUNT_CD NOT LIKE '%|%' AND UPPER(RF.ACCOUNT_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ACCOUNT_CD IS NULL 
--        			)
--				AND (  ( @P_ACCOUNT_NM LIKE '%|%' AND UPPER(AM.ACCOUNT_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_NM),''),'|')) 
--        			)OR(@P_ACCOUNT_NM NOT LIKE '%|%' AND UPPER(AM.ACCOUNT_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @p_ACCOUNT_NM IS NULL 
--        			)
--				AND (  ( @P_ITEM_CD LIKE '%|%' AND UPPER(RFITEM_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_CD),''),'|')) 
--        			)OR(@P_ITEM_CD NOT LIKE '%|%' AND UPPER(RFITEM_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ITEM_CD IS NULL 
--        			)
--				AND (  ( @P_ITEM_NM LIKE '%|%' AND UPPER(IM.ITEM_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_NM),''),'|')) 
--        			)OR(@P_ITEM_NM NOT LIKE '%|%' AND UPPER(IM.ITEM_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ITEM_NM IS NULL 
--        			)
--			GROUP BY VER_CD, RF.ACCOUNT_CD, AM.ACCOUNT_NM, RFITEM_CD, IM.ITEM_NM, IM.ATTR_01
--			  ;
--	END
--	ELSE IF @P_ACCURACY = 'RMSE_P'
--	BEGIN
--		 SELECT VER_CD AS VER_ID
--				  , RF.ACCOUNT_CD
--				  , AM.ACCOUNT_NM
--				  , RFITEM_CD
--				  , IM.ITEM_NM
--				  , IM.ATTR_01 AS ITEM_GRADE
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'REGRESSION_FP' THEN RMSE_P
--															     ELSE null END) AS REG_ACCRY
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'STATISTIC_FP'  THEN RMSE_P
--															     ELSE null END) AS STATISTIC_ACCRY
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'TF'            THEN RMSE_P
--															     ELSE null END) AS TF_ACCRY
--				  , MAX(RFCREATE_BY)	AS CREATE_BY
--				  , MAX(RFCREATE_DTTM) AS CREATE_DTTM
--				  , MAX(RFMODIFY_BY  )	AS MODIFY_BY
--				  , MAX(RFMODIFY_DTTM)	AS MODIFY_DTTM
--			   FROM TB_BF_RT_ACCRCY AC
--			  INNER JOIN TB_DP_ACCOUNT_MST AM ON RF.ACCOUNT_CD = AM.ACCOUNT_CD
--			  INNER JOIN TB_CM_ITEM_MST    IM ON RFITEM_CD    = IM.ITEM_CD
--			  WHERE 1=1
--				AND VER_CD = @P_VER_CD
--				AND (  ( @P_ACCOUNT_CD LIKE '%|%' AND UPPER(RF.ACCOUNT_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_CD),''),'|')) 
--        			)OR(@P_ACCOUNT_CD NOT LIKE '%|%' AND UPPER(RF.ACCOUNT_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ACCOUNT_CD IS NULL 
--        			)
--				AND (  ( @P_ACCOUNT_NM LIKE '%|%' AND UPPER(AM.ACCOUNT_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_NM),''),'|')) 
--        			)OR(@P_ACCOUNT_NM NOT LIKE '%|%' AND UPPER(AM.ACCOUNT_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @p_ACCOUNT_NM IS NULL 
--        			)
--				AND (  ( @P_ITEM_CD LIKE '%|%' AND UPPER(RFITEM_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_CD),''),'|')) 
--        			)OR(@P_ITEM_CD NOT LIKE '%|%' AND UPPER(RFITEM_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ITEM_CD IS NULL 
--        			)
--				AND (  ( @P_ITEM_NM LIKE '%|%' AND UPPER(IM.ITEM_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_NM),''),'|')) 
--        			)OR(@P_ITEM_NM NOT LIKE '%|%' AND UPPER(IM.ITEM_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ITEM_NM IS NULL 
--        			)
--			GROUP BY VER_CD, RF.ACCOUNT_CD, AM.ACCOUNT_NM, RFITEM_CD, IM.ITEM_NM, IM.ATTR_01
--			  ;
--	END
--	ELSE IF @P_ACCURACY = 'MAPE_W'
--	BEGIN
--		 SELECT VER_CD AS VER_ID
--				  , RF.ACCOUNT_CD
--				  , AM.ACCOUNT_NM
--				  , RFITEM_CD
--				  , IM.ITEM_NM
--				  , IM.ATTR_01 AS ITEM_GRADE
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'REGRESSION_FP' THEN MAPE_W
--															     ELSE null END) AS REG_ACCRY
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'STATISTIC_FP'  THEN MAPE_W
--															     ELSE null END) AS STATISTIC_ACCRY
--				  , SUM(CASE WHEN ENGINE_TP_CD = 'TF'            THEN MAPE_W
--															     ELSE null END) AS TF_ACCRY
--				  , MAX(RFCREATE_BY)	AS CREATE_BY
--				  , MAX(RFCREATE_DTTM) AS CREATE_DTTM
--				  , MAX(RFMODIFY_BY  )	AS MODIFY_BY
--				  , MAX(RFMODIFY_DTTM)	AS MODIFY_DTTM
--			   FROM TB_BF_RT_ACCRCY AC
--			  INNER JOIN TB_DP_ACCOUNT_MST AM ON RF.ACCOUNT_CD = AM.ACCOUNT_CD
--			  INNER JOIN TB_CM_ITEM_MST    IM ON RFITEM_CD    = IM.ITEM_CD
--			  WHERE 1=1
--				AND VER_CD = @P_VER_CD
--				AND (  ( @P_ACCOUNT_CD LIKE '%|%' AND UPPER(RF.ACCOUNT_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_CD),''),'|')) 
--        			)OR(@P_ACCOUNT_CD NOT LIKE '%|%' AND UPPER(RF.ACCOUNT_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ACCOUNT_CD IS NULL 
--        			)
--				AND (  ( @P_ACCOUNT_NM LIKE '%|%' AND UPPER(AM.ACCOUNT_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_NM),''),'|')) 
--        			)OR(@P_ACCOUNT_NM NOT LIKE '%|%' AND UPPER(AM.ACCOUNT_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @p_ACCOUNT_NM IS NULL 
--        			)
--				AND (  ( @P_ITEM_CD LIKE '%|%' AND UPPER(RFITEM_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_CD),''),'|')) 
--        			)OR(@P_ITEM_CD NOT LIKE '%|%' AND UPPER(RFITEM_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ITEM_CD IS NULL 
--        			)
--				AND (  ( @P_ITEM_NM LIKE '%|%' AND UPPER(IM.ITEM_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_NM),''),'|')) 
--        			)OR(@P_ITEM_NM NOT LIKE '%|%' AND UPPER(IM.ITEM_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        			OR @P_ITEM_NM IS NULL 
--        			)
--			GROUP BY VER_CD, RF.ACCOUNT_CD, AM.ACCOUNT_NM, RFITEM_CD, IM.ITEM_NM, IM.ATTR_01
--			  ;
--	END
--	 SELECT *
--	   FROM TB_BF_RT_ACCRCY AC
--	  INNER JOIN TB_DP_ACCOUNT_MST AM ON RF.ACCOUNT_CD = AM.ACCOUNT_CD
--	  INNER JOIN TB_CM_ITEM_MST    IM ON RFITEM_CD    = IM.ITEM_CD
--      WHERE 1=1
--        AND VER_CD = @P_VER_CD
--        AND (  ( @P_ACCOUNT_CD LIKE '%|%' AND UPPER(RF.ACCOUNT_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_CD),''),'|')) 
--        	)OR(@P_ACCOUNT_CD NOT LIKE '%|%' AND UPPER(RF.ACCOUNT_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        	OR @P_ACCOUNT_CD IS NULL 
--        	)
--        AND (  ( @P_ACCOUNT_NM LIKE '%|%' AND UPPER(AM.ACCOUNT_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_NM),''),'|')) 
--        	)OR(@P_ACCOUNT_NM NOT LIKE '%|%' AND UPPER(AM.ACCOUNT_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        	OR @p_ACCOUNT_NM IS NULL 
--        	)
--        AND (  ( @P_ITEM_CD LIKE '%|%' AND UPPER(RFITEM_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_CD),''),'|')) 
--        	)OR(@P_ITEM_CD NOT LIKE '%|%' AND UPPER(RFITEM_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        	OR @P_ITEM_CD IS NULL 
--        	)
--        AND (  ( @P_ITEM_NM LIKE '%|%' AND UPPER(IM.ITEM_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_NM),''),'|')) 
--        	)OR(@P_ITEM_NM NOT LIKE '%|%' AND UPPER(IM.ITEM_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--        	OR @P_ITEM_NM IS NULL 
--        	)
--	  ;







--    -- 수요예측 결과 비교
--	SELECT *
--	  INTO #BF_52_Q1
--	  FROM TB_BF_ACCRY_REF A		 
--	 WHERE A.VER_ID = @VER_ID
--	   AND 0        < A.BYPRDT_ACCRY + A.CL_ACCRY + A.BYITEM_ACCRY
----	   AND EXISTS (SELECT 1
----		             FROM TB_BF_TOT_RESULT B 
----		            WHERE B.VER_ID     = A.VER_ID
----					  AND B.ITEM_CD    = A.ITEM_CD 
----					  AND B.ACCOUNT_CD = A.ACCOUNT_CD				
----					  AND 0            < ISNULL(B.BYPRDT_QTY, 0) + ISNULL(B.CL_QTY, 0) + ISNULL(B.BYITEM_QTY, 0)
----				  )
--
--	SELECT R.VER_ID               AS VER_ID           -- 수요예측 버전
--		 , TRIM(R.ACCOUNT_CD)           AS ACCOUNT_CD       -- 거래처 코드
--		 , A.ACCOUNT_NM           AS ACCOUNT_NM       -- 거래처 명
--		 , TRIM(R.ITEM_CD)              AS ITEM_CD          -- 품목 코드
--		 , I.ITEM_NM              AS ITEM_NM          -- 품목 명
--		 , I.ATTR_04              AS ITEM_GRADE       -- 품목 등급
--		 , R.BYPRDT_ACCRY         AS BYPRDT_ACCRY
--		 , R.CL_ACCRY             AS CL_ACCRY         -- 클러스터링 정확도
--		 , R.BYITEM_ACCRY         AS BYITEM_ACCRY
--		 , R.SELECTION + '_ACCRY' AS SELECTION        -- 선택모델
--		 , CASE WHEN R.SELECTION = 'BYPRDT'    
--				THEN R.BYPRDT_ACCRY
--		        WHEN R.SELECTION = 'BYITEM'        
--				THEN R.BYITEM_ACCRY
--		        WHEN R.SELECTION = 'CL'        
--				THEN R.CL_ACCRY
--		        ELSE NULL
--		    END                   AS SELECT_ACCRY	  -- BSET 정확도 (선택모델 정확도)			-- 2019.08.20 AJS 추가
--		 , R.CREATE_BY            AS CREATE_BY
--		 , R.CREATE_DTTM          AS CREATE_DTTM
--		 , R.MODIFY_BY            AS MODIFY_BY
--		 , R.MODIFY_DTTM          AS MODIFY_DTTM
--	  FROM #BF_52_Q1 R
--	 INNER 
--	  JOIN TB_DP_ACCOUNT_MST A 
--	    ON R.ACCOUNT_CD = A.ACCOUNT_CD
--     INNER 
--	  JOIN TB_CM_ITEM_MST I 
--	    ON I.ITEM_CD = R.ITEM_CD	     	   
--	 WHERE 1=1
--		AND (  ( @P_ACCOUNT_CD LIKE '%|%' AND UPPER(A.ACCOUNT_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_CD),''),'|')) 
--			)OR(@P_ACCOUNT_CD NOT LIKE '%|%' AND UPPER(A.ACCOUNT_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--			OR @P_ACCOUNT_CD IS NULL 
--			)
--		AND (  ( @P_ACCOUNT_NM LIKE '%|%' AND UPPER(A.ACCOUNT_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_NM),''),'|')) 
--			)OR(@P_ACCOUNT_NM NOT LIKE '%|%' AND UPPER(A.ACCOUNT_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--			OR @p_ACCOUNT_NM IS NULL 
--			)
--		AND (  ( @P_ITEM_CD LIKE '%|%' AND UPPER(I.ITEM_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_CD),''),'|')) 
--			)OR(@P_ITEM_CD NOT LIKE '%|%' AND UPPER(I.ITEM_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--			OR @P_ITEM_CD IS NULL 
--			)
--		AND (  ( @P_ITEM_NM LIKE '%|%' AND UPPER(I.ITEM_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_NM),''),'|')) 
--			)OR(@P_ITEM_NM NOT LIKE '%|%' AND UPPER(I.ITEM_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
--			OR @P_ITEM_NM IS NULL 
--			)
--
--	 ORDER BY R.ACCOUNT_CD
--		    , A.ACCOUNT_NM
--		    , CONVERT(float, R.ITEM_CD)
--		    , I.ITEM_NM
      
END			





 

go

