CREATE PROCEDURE [dbo].[SP_UI_DP_42_S1_J] (
	  @P_JSON				  NVARCHAR(MAX)
	 ,@P_USER_ID             NVARCHAR(100)     = ''
	 ,@P_RT_ROLLBACK_FLAG    NVARCHAR(10)      = 'true'  OUTPUT
	 ,@P_RT_MSG              NVARCHAR(4000)    = ''		 OUTPUT	

--	 @P_ITEM_CD				NVARCHAR(100)
--	,@P_ACCT_CD				NVARCHAR(100)
--	,@P_BASE_DATE			DATE
--	,@P_QTY					decimal(20,3)
--	,@P_AMT					decimal(20,3)
--	,@P_SO_STATUS_CD	    NVARCHAR(200)
--	,@P_USER_ID				NVARCHAR(25)

)
/*****************************************************************************
Title : [SP_UI_CM_20_S1_J]
  - Actual Sales Save (Json Param Bulk Insert)

 
설명 
  - OPENJSON : https://docs.microsoft.com/ko-kr/sql/t-sql/functions/openjson-transact-sql?view=sql-server-ver15

History (수정일자 / 수정자 / 수정내용)
- 2022.01.11 / kim sohee / json bulk insert draft
*****************************************************************************/

AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	DECLARE @P_ERR_MSG NVARCHAR(4000) 

BEGIN TRY
/*
	-- Find ID
	SELECT @P_ITEM_MST_ID = ID FROM TB_CM_ITEM_MST WHERE ITEM_CD =@P_ITEM_CD
	SELECT @P_ACCOUNT_ID = ID FROM TB_DP_ACCOUNT_MST WHERE ACCOUNT_CD = @P_ACCT_CD
--	SELECT @P_SO_STATUS_ID = ID FROM TB_CM_COMM_CONFIG WHERE CONF_CD = @P_SO_STATUS_CD
	-- VALIDATION ABOUT ID 
	IF(@P_ITEM_MST_ID IS NULL)
	BEGIN 
		SET @P_ERR_MSG = 'Item Code is not valid'
		RAISERROR (@P_ERR_MSG,12, 1);
	END
	IF(@P_ACCOUNT_ID IS NULL)
	BEGIN 
		SET @P_ERR_MSG = 'Account Code is not valid'
		RAISERROR (@P_ERR_MSG,12, 1);
	END
--	IF(@P_SO_STATUS_ID IS NULL)
--	BEGIN 
--		SET @P_ERR_MSG = 'SO Status is not valid'
--		RAISERROR (@P_ERR_MSG,12, 1);
--	END
*/
		SELECT TOP 1 @P_ERR_MSG = V.[key]	--R.key, R.value, V.key, V.value
		  FROM OPENJSON(@P_JSON) AS R
			   CROSS APPLY 
			   OPENJSON ( R.value) AS V
		 WHERE V.[value] IS NULL 
		   AND V.[key] IN ( 'ITEM_CD'	
		   				   ,'ACCOUNT_CD'
		   				   ,'BASE_DATE'	
						   ,'SO_STATUS_CD'	
						  ) ;
	IF @P_ERR_MSG IS NOT NULL 
	BEGIN
		SET @P_ERR_MSG = 'Check Empty Value : '+@P_ERR_MSG		
		RAISERROR (@P_ERR_MSG,12, 1);
	END
	;

	MERGE INTO TB_CM_ACTUAL_SALES TGT
		 USING ( SELECT
				 I.ID		AS ITEM_MST_ID
				,A.ID		AS ACCOUNT_ID
				,BASE_DATE	AS BASE_DATE
				,QTY		AS QTY
				,AMT		AS AMT
				,C.ID		AS SO_STATUS_ID
				FROM OPENJSON(@P_JSON) 
				WITH (  ITEM_CD			NVARCHAR(100)  '$.ITEM_CD'
					  , ACCOUNT_CD		NVARCHAR(100)  '$.ACCOUNT_CD'
					  , BASE_DATE		DATE		   '$.BASE_DATE'
					  , QTY				DECIMAL(20,3)  '$.QTY'
					  , AMT				DECIMAL(20,3)  '$.AMT'
					  , SO_STATUS_CD	NVARCHAR(200)  '$.SO_STATUS_CD'													   
					) M
					INNER JOIN 
					TB_CM_ITEM_MST I
				 ON M.ITEM_CD = I.ITEM_CD 
					INNER JOIN
					TB_DP_ACCOUNT_MST A 
				 ON M.ACCOUNT_CD = A.ACCOUNT_CD 
					INNER JOIN 
					TB_CM_COMM_CONFIG C
				 ON M.SO_STATUS_CD = C.CONF_CD
				AND C.CONF_GRP_CD = 'DP_SO_STATUS'
		 	   ) SRC
			ON SRC.ITEM_MST_ID = TGT.ITEM_MST_ID
		   AND SRC.ACCOUNT_ID = TGT.ACCOUNT_ID
		   AND SRC.BASE_DATE = TGT.BASE_DATE
		   AND SRC.SO_STATUS_ID = TGT.SO_STATUS_ID
	WHEN MATCHED THEN 
		 UPDATE SET QTY		    = SRC.QTY
			       ,AMT		    = SRC.AMT
				   ,MODIFY_BY   = @P_USER_ID
				   ,MODIFY_DTTM = GETDATE()
	WHEN NOT MATCHED THEN
		   INSERT  ( ID
				    ,ITEM_MST_ID
				    ,ACCOUNT_ID
				    ,BASE_DATE
				    ,SO_STATUS_ID
				    ,QTY
				    ,AMT
				    ,CREATE_BY
				    ,CREATE_DTTM
				   ) VALUES
				  ( REPLACE(NEWID(),'-','')
				   ,SRC.ITEM_MST_ID
				   ,SRC.ACCOUNT_ID
				   ,SRC.BASE_DATE
				   ,SRC.SO_STATUS_ID
				   ,SRC.QTY
				   ,SRC.AMT
				   ,@P_USER_ID
				   ,GETDATE()		 				   
				  );
				   
	    SET @P_RT_MSG = 'MSG_0001'

	    SET @P_RT_ROLLBACK_FLAG = 'true'
END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END
	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR
END CATCH

go

