/*****************************************************************************
Title : SP_UI_DP_00_DATETIME_SCOPE_Q1
최초 작성자 : 김소희
최초 생성일 : 2018.04.19
 
설명 
 - DP 날짜/시간 조회 범위 값 설정 (FROM_DATE, TO_DATE)
 
History (수정일자 / 수정자 / 수정내용)
- 2018.04.19 / 김소희 / 최초 작성
- 2019.03.08 / 김소희 ./ DP_21, DP_07 추가 ( Engine 동기화 기능에 대한 기본 날짜값)
*****************************************************************************/
CREATE PROCEDURE [dbo].[SP_UI_DP_00_DATETIME_SCOPE_Q1] (
									 @P_UI_ID				 NVARCHAR(50) =''
									,@P_TIME_UOM_CD			 NVARCHAR(50) =''	/* DATEADD 함수의 TYPE 으로 */
									,@P_FROM_DATETIME_VAL	 INT		  =NULL	/*오늘날짜 기준으로 시간단위체크해서 몇을 감(가)산 할지 계산 */
									,@P_TO_DATETIME_VAL		 INT		  =NULL	/*오늘날짜 기준으로 시간단위체크해서 몇을 감(가)산 할지 계산 */									
								   ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	DECLARE @V_VER_CNT INT= 0
		  , @P_ERR_STATUS INT = 0

		  , @V_UI_ID				NVARCHAR(50) = ''
		  , @V_TIME_UOM_CD			NVARCHAR(50)=''
		  , @V_FROM_DATETIME_VAL	INT = NULL
		  , @V_TO_DATETIME_VAL		INT = NULL
		  ;
	SET @V_UI_ID				= @P_UI_ID
	SET @V_TIME_UOM_CD			= @P_TIME_UOM_CD
	SET @V_FROM_DATETIME_VAL	= @P_FROM_DATETIME_VAL
	SET @V_TO_DATETIME_VAL		= @P_TO_DATETIME_VAL

BEGIN

	SELECT @V_VER_CNT = COUNT(*)
	  FROM TB_DP_CONTROL_BOARD_VER_MST
	  ;

		/* 화면별 날짜값 세팅 */
		IF(@V_UI_ID = 'UI_ZN_05')
			BEGIN
				SELECT DATEADD(DAY, @V_FROM_DATETIME_VAL, GETDATE())		AS FROM_DATE
					  ,DATEADD(DAY, @V_TO_DATETIME_VAL  , GETDATE())		AS TO_DATE
			END
        ELSE IF(@P_UI_ID = 'UI_DP_07')
            BEGIN
				SELECT MAX(BASE_DATE)				  AS TO_DATE
					 , CASE WHEN MAX(BASE_DATE) = MIN(BASE_DATE)
							THEN MIN(BASE_DATE)
							ELSE DATEADD(DAY,1, MIN(BASE_DATE)) 
					   END							  AS FROM_DATE
				 FROM(
					SELECT DISTINCT TOP 2
						  BASE_DATE 
					  FROM TB_DP_EXCHANGE_RATE   
					) A
					;    
             END    ;
        ELSE IF(@P_UI_ID = 'UI_DP_21')
            BEGIN
				SELECT MAX(BASE_DATE)				  AS TO_DATE
					 , CASE WHEN MAX(BASE_DATE) = MIN(BASE_DATE)
							THEN MIN(BASE_DATE)
							ELSE DATEADD(DAY,1, MIN(BASE_DATE)) 
					   END							  AS FROM_DATE
				 FROM(
					SELECT DISTINCT TOP 2
						  BASE_DATE 
					  FROM TB_DP_UNIT_PRICE   
					) A
					;    
			END
		/* 시간 단위 따져서 DATETIME 범위 계산 */
		ELSE IF ( @V_UI_ID='VERSION' AND @V_VER_CNT != 0 )
			BEGIN
				SELECT FROM_DATE
					 , TO_DATE
				  FROM (
						SELECT FROM_DATE, TO_DATE, ROW_NUMBER() OVER(ORDER BY VER_ID DESC) AS ROWN
						  FROM TB_DP_CONTROL_BOARD_VER_MST
                         WHERE PLAN_TP_ID = (SELECT ID
                                               FROM TB_CM_COMM_CONFIG
                                              WHERE CONF_GRP_CD = 'DP_PLAN_TYPE'
                                                AND DEFAT_VAL = 'Y'
                                              )
						) A
				 WHERE ROWN=1;
			END
		ELSE
			BEGIN
				SELECT CASE UPPER(@V_TIME_UOM_CD)
							WHEN 'YEAR'   THEN DATEADD ( YEAR,  @V_FROM_DATETIME_VAL, GETDATE()) 
							WHEN 'MONTH'  THEN DATEADD ( MONTH, @V_FROM_DATETIME_VAL, GETDATE()) 
							WHEN 'DAY'    THEN DATEADD ( DAY,   @V_FROM_DATETIME_VAL, GETDATE()) 
							WHEN 'WEEK'   THEN DATEADD ( WEEK,  @V_FROM_DATETIME_VAL, GETDATE()) 
							WHEN 'HOUR'   THEN DATEADD ( HOUR,  @V_FROM_DATETIME_VAL, GETDATE()) 
							WHEN 'MINUTE' THEN DATEADD ( MINUTE,@V_FROM_DATETIME_VAL, GETDATE()) 
							WHEN 'SECOND' THEN DATEADD ( SECOND,@V_FROM_DATETIME_VAL, GETDATE()) 
						END AS FROM_DATE
					  ,CASE UPPER(@V_TIME_UOM_CD)
							WHEN 'YEAR'   THEN DATEADD ( YEAR,  @V_TO_DATETIME_VAL, GETDATE()) 
							WHEN 'MONTH'  THEN DATEADD ( MONTH, @V_TO_DATETIME_VAL, GETDATE()) 
							WHEN 'DAY'    THEN DATEADD ( DAY,   @V_TO_DATETIME_VAL, GETDATE()) 
							WHEN 'WEEK'   THEN DATEADD ( WEEK,  @V_TO_DATETIME_VAL, GETDATE()) 
							WHEN 'HOUR'   THEN DATEADD ( HOUR,  @V_TO_DATETIME_VAL, GETDATE()) 
							WHEN 'MINUTE' THEN DATEADD ( MINUTE,@V_TO_DATETIME_VAL, GETDATE()) 
							WHEN 'SECOND' THEN DATEADD ( SECOND,@V_TO_DATETIME_VAL, GETDATE()) 
						END AS TO_DATE				 
			END		
		


END

go

