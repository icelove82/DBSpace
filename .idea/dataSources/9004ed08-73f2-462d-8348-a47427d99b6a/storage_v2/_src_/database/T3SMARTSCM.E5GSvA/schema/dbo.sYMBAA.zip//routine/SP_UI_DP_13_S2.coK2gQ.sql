/*****************************************************************************
Title : SP_DP_13_S2
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP User Mapping (Item)
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2020.03.12 / KSH / EMP_NO => USER_ID  
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER
- 2020.12.02 / 김소희 / Make Initial Data into Entry
- 2020.12.07 / kim sohee / execute making dynamic user data procedure 
- 2021.03.10 / kim sohee / call a procedure to create User Group
*****************************************************************************/



-- UI에서는 새로 추가만 하고
-- 엑셀도 새로 추가만 해야 하는데 기존 ID와 새로 생성한 ID를 어차피 비교 못함
-- 따라서 ID는 필요없음
CREATE PROCEDURE [dbo].[SP_UI_DP_13_S2]  (	 -- Search area
											 @p_EMP_NO				NVARCHAR(50)      = ''   
											,@p_AUTH_TP_ID          NVARCHAR(32)      = ''		
--											,@p_LV_MGMT_ID          NVARCHAR(32)      = ''		-- Only UI
											,@p_LV_CD				NVARCHAR(50)      = ''		-- for EXCEL  
--											,@P_ITEM_ID		        NVARCHAR(32)      = NULL    -- Only UI 
											,@p_ITEM_CD             NVARCHAR(200)      = ''     -- for EXCEL
											,@p_ACTV_YN             CHAR(1)           = ''   
											,@p_USER_ID             NVARCHAR(50)      = ''
											,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)		  = 'true'   OUTPUT
											,@P_RT_MSG            NVARCHAR(4000)	  = ''		 OUTPUT											      
											
				                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''
	   ,@V_EMP_ID	  CHAR(32)
	   ,@V_ITEM_YN	  CHAR(1)
	   ,@v_LV_MGMT_ID CHAR(32)	  
	   ,@V_ITEM_ID    CHAR(32)
	   ,@V_ITEM_LV_ID CHAR(32) 
BEGIN TRY
	if(ISNULL(@p_ACTV_YN,'') = '')
	BEGIN
		SET @p_ACTV_YN = 'Y' -- None of personal data
	END
	-- EMP_NO => EMP_ID
	SELECT @V_EMP_ID = ID
	  FROM TB_AD_USER
	 WHERE USERNAME = @p_EMP_NO
	-- LV_CD => LV_MGMT_ID
	SELECT @v_LV_MGMT_ID = m.ID
		,  @V_ITEM_YN = LEAF_YN
	  FROM TB_CM_LEVEL_MGMT m
	  inner join TB_CM_COMM_CONFIG c on c.id = m.LV_TP_ID and c.CONF_CD = 'I'
	 WHERE LV_CD = @p_LV_CD
	IF(@V_ITEM_YN = 'Y')
	BEGIN
		SELECT @V_ITEM_ID = ID
		  FROM TB_CM_ITEM_MST
		 WHERE ITEM_CD = @P_ITEM_CD
	END
	ELSE
	BEGIN
		SELECT @V_ITEM_ID = ID
			  ,@V_ITEM_LV_ID = ID
		  FROM TB_CM_ITEM_LEVEL_MGMT
		 WHERE ITEM_LV_CD = @P_ITEM_CD
		   AND LV_MGMT_ID = @V_LV_MGMT_ID
	END

	-- Validation 
	-- key ID == null?
	IF ( @v_LV_MGMT_ID IS NULL)
	BEGIN
		SET @P_RT_ROLLBACK_FLAG = 'false'
		SET @P_ERR_MSG = 'MSG_5029'
		RAISERROR(@P_ERR_MSG,12,1)
	END
	IF ( @V_ITEM_ID IS NULL)
	BEGIN
		SET @P_RT_ROLLBACK_FLAG = 'false'
		SET @P_ERR_MSG = 'MSG_0017'
		RAISERROR(@P_ERR_MSG,12,1)
	END
	IF ( @p_AUTH_TP_ID IS NULL)
	BEGIN
		SET @P_RT_ROLLBACK_FLAG = 'false'
		SET @P_ERR_MSG = 'MSG_5044'
		RAISERROR(@P_ERR_MSG,12,1)
	END
	-- 중복													
	SELECT @P_ERR_STATUS = COUNT(*)
	  FROM TB_DP_USER_ITEM_MAP
	 WHERE 1=1
	   AND CASE  @V_ITEM_YN WHEN 'Y' THEN ITEM_MST_ID ELSE ITEM_LV_ID END = @V_ITEM_ID
	   AND EMP_ID = @V_EMP_ID
	   AND ACTV_YN = @p_ACTV_YN -- 유일 수정 값인 활성화 여부로 INSERT와 UPDATE 구분
	IF ( @P_ERR_STATUS != 0 )
	BEGIN
		SET @P_RT_ROLLBACK_FLAG = 'false'
		SET @P_ERR_MSG = 'MSG_0013'
		RAISERROR(@P_ERR_MSG,12,1)
	END
								
    -- 수정 시작 
	MERGE [TB_DP_USER_ITEM_MAP]  TGT
	USING ( 
			SELECT  REPLACE(NEWID(),'-','')						  AS  ID 
				   ,@V_EMP_ID									  AS  EMP_ID
				   ,@P_AUTH_TP_ID								  AS  AUTH_TP_ID
				   ,@V_LV_MGMT_ID								  AS  LV_MGMT_ID
				   ,CASE @V_ITEM_YN WHEN 'N' THEN @V_ITEM_ID END  AS  ITEM_LV_ID
				   ,CASE @V_ITEM_YN WHEN 'Y' THEN @V_ITEM_ID END  AS  ITEM_MST_ID
				   ,@p_ACTV_YN									  AS  ACTV_YN
				   ,@p_USER_ID									  AS  [USER_ID]
		  ) SRC
	ON (TGT.EMP_ID					= SRC.EMP_ID
   AND  TGT.AUTH_TP_ID				= SRC.AUTH_TP_ID
   AND  TGT.LV_MGMT_ID				= SRC.LV_MGMT_ID
   AND  ISNULL(TGT.ITEM_LV_ID  ,'') = ISNULL(SRC.ITEM_LV_ID	,'')
   AND  ISNULL(TGT.ITEM_MST_ID ,'') = ISNULL(SRC.ITEM_MST_ID,'') 
		)
	WHEN MATCHED THEN
		 UPDATE 
		    SET  TGT.ACTV_YN     = SRC.ACTV_YN 
				,TGT.MODIFY_BY   = SRC.USER_ID       
				,TGT.MODIFY_DTTM = GETDATE()       
	WHEN NOT MATCHED THEN 
		 INSERT (
		            ID
				  , EMP_ID
				  , AUTH_TP_ID
				  , LV_MGMT_ID
				  , ITEM_LV_ID
				  , ITEM_MST_ID
				  , ACTV_YN
				  , CREATE_BY
				  , CREATE_DTTM
				) 
		 VALUES (
		            SRC.ID 
				  , SRC.EMP_ID
				  , SRC.AUTH_TP_ID
				  , SRC.LV_MGMT_ID
				  , SRC.ITEM_LV_ID
				  , SRC.ITEM_MST_ID
				  , SRC.ACTV_YN --- Becasure of none of personal data
				  , SRC.USER_ID 
				  , GETDATE()            
 				) 
				;    	

	  /****************************************************************************************************************************
		-- Add new Demand into Entry 
	  ***************************************************************************************************************************/	   
	/************************************************************************************************************************************
		공통. close 되지 않은 버전 이면서 TB_DP_ENTRY에 data가 존재하는 버전 : 엔진을 사용한다면 entry에 데이타가 없으므로

		2. TB_DP_ENTRY 에 추가하려는 demand가   존재하는 경우 무시 
		     - 삭제되었다가 다시 추가되는 상황인 경우 이럴 수 있음
			 - level을 추가하는 경우 특정 품목은 이미 추가되었을수 있음
        3. level이 추가 될 수 있거나
		    - 해당 level의 모든 하위 item의 demand가 추가되어야 함
		4. item이 추가될 수 있거나 
			 - 이경우 mapping에 있는 level에 품목이 추가되는 case와 동일함 

		공통. Plan type별로 version이 있을수 있음 : 여러개일 가능성 있음 
				SELECT  CONBD_VER_MST_ID as VER_ID, max(create_dttm) OVER (PARTITION BY PLAN_TP_ID ORDER BY create_dttm DESC)  
				FROM TB_DP_CONTROL_BOARD_VER_DTL 
				WHERE WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
						AND CL_STATUS_ID IN (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD != 'CLOSE')

		공통. plan type 별로 해당 version의 auth type을 구함
				select  LV_MGMT_ID from TB_DP_CONTROL_BOARD_VER_DTL where CONBD_VER_MST_ID  = 'F4F716D3FBDD4252BDDC28B9575BD690' and LV_MGMT_ID is not null
		공통. 각 auth type별로 초기값 반영은 2차로 진행해도 될듯... 일단 value가 0인 상태로 demand만 추가 되도록 필요
	************************************************************************************************************************************/
	/********************************************************************************************************************************************
		-- Make Entry data
	********************************************************************************************************************************************/

		  	

	DECLARE @TB_VERSION TABLE ( ID CHAR(32)	COLLATE DATABASE_DEFAULT ) 
	DECLARE @CUR_VER_ID NVARCHAR(100)
	INSERT INTO @TB_VERSION (ID) 
	SELECT VER_ID
	  FROM ( 
			SELECT M.ID AS VER_ID 
				 , DENSE_RANK () OVER (PARTITION BY M.PLAN_TP_ID ORDER BY M.CREATE_DTTM DESC) AS RW 
			  FROM TB_DP_CONTROL_BOARD_VER_MST M
				   INNER JOIN 
				   TB_DP_CONTROL_bOARD_VER_DTL D
				ON M.ID = D.CONBD_VER_MST_ID 
				   INNER JOIN 
				   TB_CM_COMM_CONFIG W
				ON W.ID = D.WORK_TP_ID
			   AND W.CONF_CD = 'CL'
				   INNER JOIN 
				   TB_CM_COMM_CONFIG C
				ON D.CL_STATUS_ID = C.ID
			   AND C.CONF_CD != 'CLOSE' 
			 WHERE EXISTS (SELECT DISTINCT VER_ID FROM TB_DP_ENTRY WHERE VER_ID = M.ID) 
		    ) A
	WHERE RW = 1  
	DECLARE USER_ITEM_CUR CURSOR FAST_FORWARD LOCAL
	FOR SELECT ID FROM @TB_VERSION
	READONLY
	;

	OPEN USER_ITEM_CUR
    FETCH NEXT FROM USER_ITEM_CUR INTO @CUR_VER_ID 
	;
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
--			 IF NOT EXISTS
--			 (  SELECT 1 
--				 FROM TB_DP_ENTRY 
--				WHERE VER_ID = @CUR_VER_ID
--				  AND ITEM_MST_ID IN (SELECT DESCENDANT_ID FROM TB_DPD_ITEM_HIER_CLOSURE WHERE ANCESTER_ID = @V_ITEM_ID AND LEAF_YN = 'Y')
--			 )
--			 BEGIN
			   IF (@V_ITEM_YN = 'N')
				BEGIN
					SET @V_ITEM_ID = NULL ;
				END
			   EXECUTE dbo.SP_UI_DP_93_ITEM_ACCT_CREATE 
						 @P_ITEM_MST_ID		= @V_ITEM_ID   		-- Item Account User Map / Item Master 
						,@P_ITEM_LV_ID		= @V_ITEM_LV_ID		
						,@P_ACCOUNT_ID		= NULL				-- Item Account User Map / Account Master 
						,@P_ACCT_LV_ID		= NULL    	
						,@P_USER_ID			= @P_USER_ID			-- Mapping data
						,@P_AUTH_TP_ID		= @P_AUTH_TP_ID		
						,@P_VER_ID			= @CUR_VER_ID 	
						;   
--			END
			  FETCH NEXT FROM USER_ITEM_CUR INTO @CUR_VER_ID
		END 
	   ;

		CLOSE USER_ITEM_CUR
		DEALLOCATE USER_ITEM_CUR 
		;


		EXEC SP_UI_DP_00_MAKE_USER_GROUP @P_USER_ID = @V_EMP_ID, @P_USER_NAME = @P_EMP_NO, @P_AUTH_TP_ID = @P_AUTH_TP_ID ;
		EXEC SP_UI_DPD_MAKE_HIER_USER;

	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR
END CATCH;


go

