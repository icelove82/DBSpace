
CREATE PROCEDURE [dbo].[SP_UI_BF_06_S1]  (
									  @P_ID					CHAR(32)
									, @P_BASE_DATE			DATE
									, @P_FACTOR1			FLOAT
									, @P_FACTOR2			FLOAT
									, @P_FACTOR3			FLOAT
									, @P_FACTOR4			FLOAT
									, @P_FACTOR5			FLOAT
									, @P_FACTOR6			FLOAT
									, @P_FACTOR7			FLOAT
									, @P_FACTOR8			FLOAT
									, @P_FACTOR9			FLOAT
									, @P_FACTOR10			FLOAT
									, @P_FACTOR11			FLOAT
									, @P_FACTOR12			FLOAT
									, @P_FACTOR13			FLOAT
									, @P_FACTOR14			FLOAT
									, @P_FACTOR15			FLOAT
									, @P_FACTOR16			FLOAT
									, @P_FACTOR17			FLOAT
									, @P_FACTOR18			FLOAT
									, @P_FACTOR19			FLOAT
									, @P_FACTOR20			FLOAT
									, @P_FACTOR21			FLOAT
									, @P_FACTOR22			FLOAT
									, @P_FACTOR23			FLOAT
									, @P_FACTOR24			FLOAT
									, @P_FACTOR25			FLOAT
									, @P_FACTOR26			FLOAT
									, @P_FACTOR27			FLOAT
									, @P_FACTOR28			FLOAT
									, @P_FACTOR29			FLOAT
									, @P_FACTOR30			FLOAT
									, @P_FACTOR31			FLOAT
									, @P_FACTOR32			FLOAT
									, @P_FACTOR33			FLOAT
									, @P_FACTOR34			FLOAT
									, @P_FACTOR35			FLOAT
									, @P_FACTOR36			FLOAT
									, @P_FACTOR37			FLOAT
									, @P_FACTOR38			FLOAT
									, @P_FACTOR39			FLOAT
									, @P_FACTOR40			FLOAT
									, @P_FACTOR41			FLOAT
									, @P_FACTOR42			FLOAT
									, @P_FACTOR43			FLOAT
									, @P_FACTOR44			FLOAT
									, @P_FACTOR45			FLOAT
									, @P_FACTOR46			FLOAT
									, @P_FACTOR47			FLOAT
									, @P_FACTOR48			FLOAT
									, @P_FACTOR49			FLOAT
									, @P_FACTOR50			FLOAT
									, @P_USER_ID			NVARCHAR(50)
									, @P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'  OUTPUT
									, @P_RT_MSG            NVARCHAR(4000) = ''		OUTPUT
				                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''

BEGIN TRY
	  BEGIN
    	  
    	        IF EXISTS (SELECT BASE_DATE FROM TB_BF_DATE_FACTOR WHERE BASE_DATE = @P_BASE_DATE)
    	            BEGIN
        	            SET @P_ERR_MSG = 'Factors for desired date already exist.'
        	            RAISERROR (@P_ERR_MSG, 12, 1);
    	            END
	  
				MERGE TB_BF_DATE_FACTOR TAR
				USING ( 
						SELECT  @P_ID			AS ID			
							  , @P_BASE_DATE	AS BASE_DATE	
							  , @P_FACTOR1		AS FACTOR1	
							  , @P_FACTOR2		AS FACTOR2	
							  , @P_FACTOR3		AS FACTOR3	
							  , @P_FACTOR4		AS FACTOR4	
							  , @P_FACTOR5		AS FACTOR5	
							  , @P_FACTOR6		AS FACTOR6	
							  , @P_FACTOR7		AS FACTOR7	
							  , @P_FACTOR8		AS FACTOR8	
							  , @P_FACTOR9		AS FACTOR9	
							  , @P_FACTOR10		AS FACTOR10	
							  , @P_FACTOR11		AS FACTOR11	
							  , @P_FACTOR12		AS FACTOR12	
							  , @P_FACTOR13		AS FACTOR13	
							  , @P_FACTOR14		AS FACTOR14	
							  , @P_FACTOR15		AS FACTOR15	
							  , @P_FACTOR16		AS FACTOR16	
							  , @P_FACTOR17		AS FACTOR17	
							  , @P_FACTOR18		AS FACTOR18	
							  , @P_FACTOR19		AS FACTOR19	
							  , @P_FACTOR20		AS FACTOR20	
							  , @P_FACTOR21		AS FACTOR21	
							  , @P_FACTOR22		AS FACTOR22	
							  , @P_FACTOR23		AS FACTOR23	
							  , @P_FACTOR24		AS FACTOR24	
							  , @P_FACTOR25		AS FACTOR25	
							  , @P_FACTOR26		AS FACTOR26	
							  , @P_FACTOR27		AS FACTOR27	
							  , @P_FACTOR28		AS FACTOR28	
							  , @P_FACTOR29		AS FACTOR29	
							  , @P_FACTOR30		AS FACTOR30	
							  , @P_FACTOR31		AS FACTOR31	
							  , @P_FACTOR32		AS FACTOR32	
							  , @P_FACTOR33		AS FACTOR33	
							  , @P_FACTOR34		AS FACTOR34	
							  , @P_FACTOR35		AS FACTOR35	
							  , @P_FACTOR36		AS FACTOR36	
							  , @P_FACTOR37		AS FACTOR37	
							  , @P_FACTOR38		AS FACTOR38	
							  , @P_FACTOR39		AS FACTOR39	
							  , @P_FACTOR40		AS FACTOR40	
							  , @P_FACTOR41		AS FACTOR41	
							  , @P_FACTOR42		AS FACTOR42	
							  , @P_FACTOR43		AS FACTOR43	
							  , @P_FACTOR44		AS FACTOR44	
							  , @P_FACTOR45		AS FACTOR45	
							  , @P_FACTOR46		AS FACTOR46	
							  , @P_FACTOR47		AS FACTOR47	
							  , @P_FACTOR48		AS FACTOR48	
							  , @P_FACTOR49		AS FACTOR49	
							  , @P_FACTOR50		AS FACTOR50	
							  , @P_USER_ID		AS USER_ID	
					  ) SRC
				ON	  TAR.ID			= SRC.ID	
				WHEN MATCHED THEN
					 UPDATE 
					   SET   TAR.ID				= SRC.ID		
							,TAR.BASE_DATE		= SRC.BASE_DATE
							,TAR.FACTOR1		= SRC.FACTOR1	
							,TAR.FACTOR2		= SRC.FACTOR2	
							,TAR.FACTOR3		= SRC.FACTOR3	
							,TAR.FACTOR4		= SRC.FACTOR4	
							,TAR.FACTOR5		= SRC.FACTOR5	
							,TAR.FACTOR6		= SRC.FACTOR6	
							,TAR.FACTOR7		= SRC.FACTOR7	
							,TAR.FACTOR8		= SRC.FACTOR8	
							,TAR.FACTOR9		= SRC.FACTOR9	
							,TAR.FACTOR10		= SRC.FACTOR10	
							,TAR.FACTOR11		= SRC.FACTOR11	
							,TAR.FACTOR12		= SRC.FACTOR12	
							,TAR.FACTOR13		= SRC.FACTOR13	
							,TAR.FACTOR14		= SRC.FACTOR14	
							,TAR.FACTOR15		= SRC.FACTOR15	
							,TAR.FACTOR16		= SRC.FACTOR16	
							,TAR.FACTOR17		= SRC.FACTOR17	
							,TAR.FACTOR18		= SRC.FACTOR18	
							,TAR.FACTOR19		= SRC.FACTOR19	
							,TAR.FACTOR20		= SRC.FACTOR20	
							,TAR.FACTOR21		= SRC.FACTOR21	
							,TAR.FACTOR22		= SRC.FACTOR22	
							,TAR.FACTOR23		= SRC.FACTOR23	
							,TAR.FACTOR24		= SRC.FACTOR24	
							,TAR.FACTOR25		= SRC.FACTOR25	
							,TAR.FACTOR26		= SRC.FACTOR26	
							,TAR.FACTOR27		= SRC.FACTOR27	
							,TAR.FACTOR28		= SRC.FACTOR28	
							,TAR.FACTOR29		= SRC.FACTOR29	
							,TAR.FACTOR30		= SRC.FACTOR30	
							,TAR.FACTOR31		= SRC.FACTOR31	
							,TAR.FACTOR32		= SRC.FACTOR32	
							,TAR.FACTOR33		= SRC.FACTOR33	
							,TAR.FACTOR34		= SRC.FACTOR34	
							,TAR.FACTOR35		= SRC.FACTOR35	
							,TAR.FACTOR36		= SRC.FACTOR36	
							,TAR.FACTOR37		= SRC.FACTOR37	
							,TAR.FACTOR38		= SRC.FACTOR38	
							,TAR.FACTOR39		= SRC.FACTOR39	
							,TAR.FACTOR40		= SRC.FACTOR40	
							,TAR.FACTOR41		= SRC.FACTOR41	
							,TAR.FACTOR42		= SRC.FACTOR42	
							,TAR.FACTOR43		= SRC.FACTOR43	
							,TAR.FACTOR44		= SRC.FACTOR44	
							,TAR.FACTOR45		= SRC.FACTOR45	
							,TAR.FACTOR46		= SRC.FACTOR46	
							,TAR.FACTOR47		= SRC.FACTOR47	
							,TAR.FACTOR48		= SRC.FACTOR48	
							,TAR.FACTOR49		= SRC.FACTOR49	
							,TAR.FACTOR50		= SRC.FACTOR50	
							,TAR.MODIFY_BY		= SRC.USER_ID
							,TAR.MODIFY_DTTM	= GETDATE()
				WHEN NOT MATCHED THEN 
					 INSERT (
							  ID			
							, BASE_DATE	
							, FACTOR1	
							, FACTOR2	
							, FACTOR3	
							, FACTOR4	
							, FACTOR5	
							, FACTOR6	
							, FACTOR7	
							, FACTOR8	
							, FACTOR9	
							, FACTOR10	
							, FACTOR11	
							, FACTOR12	
							, FACTOR13	
							, FACTOR14	
							, FACTOR15	
							, FACTOR16	
							, FACTOR17	
							, FACTOR18	
							, FACTOR19	
							, FACTOR20	
							, FACTOR21	
							, FACTOR22	
							, FACTOR23	
							, FACTOR24	
							, FACTOR25	
							, FACTOR26	
							, FACTOR27	
							, FACTOR28	
							, FACTOR29	
							, FACTOR30	
							, FACTOR31	
							, FACTOR32	
							, FACTOR33	
							, FACTOR34	
							, FACTOR35	
							, FACTOR36	
							, FACTOR37	
							, FACTOR38	
							, FACTOR39	
							, FACTOR40	
							, FACTOR41	
							, FACTOR42	
							, FACTOR43	
							, FACTOR44	
							, FACTOR45	
							, FACTOR46	
							, FACTOR47	
							, FACTOR48	
							, FACTOR49	
							, FACTOR50	
							, CREATE_BY	
							, CREATE_DTTM
							) 
					 VALUES (
							 (SELECT REPLACE(NEWID(),'-','') )
							,SRC.BASE_DATE
							,SRC.FACTOR1
							,SRC.FACTOR2
							,SRC.FACTOR3
							,SRC.FACTOR4
							,SRC.FACTOR5
							,SRC.FACTOR6
							,SRC.FACTOR7
							,SRC.FACTOR8
							,SRC.FACTOR9
							,SRC.FACTOR10
							,SRC.FACTOR11
							,SRC.FACTOR12
							,SRC.FACTOR13
							,SRC.FACTOR14
							,SRC.FACTOR15
							,SRC.FACTOR16
							,SRC.FACTOR17
							,SRC.FACTOR18
							,SRC.FACTOR19
							,SRC.FACTOR20
							,SRC.FACTOR21
							,SRC.FACTOR22
							,SRC.FACTOR23
							,SRC.FACTOR24
							,SRC.FACTOR25
							,SRC.FACTOR26
							,SRC.FACTOR27
							,SRC.FACTOR28
							,SRC.FACTOR29
							,SRC.FACTOR30
							,SRC.FACTOR31
							,SRC.FACTOR32
							,SRC.FACTOR33
							,SRC.FACTOR34
							,SRC.FACTOR35
							,SRC.FACTOR36
							,SRC.FACTOR37
							,SRC.FACTOR38
							,SRC.FACTOR39
							,SRC.FACTOR40
							,SRC.FACTOR41
							,SRC.FACTOR42
							,SRC.FACTOR43
							,SRC.FACTOR44
							,SRC.FACTOR45
							,SRC.FACTOR46
							,SRC.FACTOR47
							,SRC.FACTOR48
							,SRC.FACTOR49
							,SRC.FACTOR50
							,SRC.USER_ID
							,GETDATE()
 							) 
							
							;    

         
	  END
			


	   SET @P_RT_ROLLBACK_FLAG = 'true'

	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;

go

