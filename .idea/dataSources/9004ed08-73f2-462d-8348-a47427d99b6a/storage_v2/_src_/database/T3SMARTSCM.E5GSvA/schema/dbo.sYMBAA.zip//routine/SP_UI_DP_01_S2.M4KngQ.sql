/*****************************************************************************
Title : SP_DP_01_S2
최초 작성자 : 김소희
최초 생성일 : 2018.03.08
 
설명 
 - DP Configuration 하단 그리드 저장
 
History (수정일자 / 수정자 / 수정내용)
- 2018.03.08 / 김소희 / 첫번째 작성
- 2019.02.15 / 김소희 / Lang Pack 등록 룰 변경에 따라 conf name, description을 update만 가능하게 수정
- 2020.02.28 / 김소희 / DP_STD_WEEK 변경하면 캘린더 DP_WK 데이터 재생성
- 2020.07.08 / 김소희 / PERSONAL PIVOT OPTION, option type= type value change 
- 2020.09.28 / hanguls / 개인화테이블 변경 반영
- 2021.04.29 / 김소희 / DP WK 계산방식 변경
- 2021.06.15 / KSH / comment editable property
- 2021.06.21 / KSH / change a rule of DP_WK
- 2021.08.04 / KSH / DP_DMND_CUSTOM, add column by config cd
- 2023.01.25 / KSH / LEAF level add when CONFIG LEVEL TYPE ADD
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_01_S2] (	
										 @P_ID			  NVARCHAR(32)		
										,@P_CONF_ID		  NVARCHAR(32)	
										,@P_CONF_GRP_CD	  NVARCHAR(100)	   = NULL
										,@P_CONF_CD		  NVARCHAR(100)	   = NULL
										,@P_LANG_CONF_NM  NVARCHAR(100)	   = NULL
										,@P_CONF_NM		  NVARCHAR(100)	   = NULL
										,@P_DEFAT_VAL	  NVARCHAR(1)	   = NULL
										,@P_ACTV_YN		  NVARCHAR(1)	   = NULL
										,@P_PRIORT		  INT			   = NULL
										,@P_USE_YN		  NVARCHAR(1)	   = NULL
										,@P_LANG_DESCRIP  NVARCHAR(100)	   = NULL
										,@P_DESCRIP		  NVARCHAR(100)	   = NULL
										,@P_ATTR_01		  NVARCHAR(100)	   = NULL
										,@P_ATTR_02		  NVARCHAR(100)	   = NULL
										,@P_ATTR_03		  NVARCHAR(100)	   = NULL
										,@P_ATTR_04		  NVARCHAR(100)	   = NULL
										,@P_ATTR_05		  NVARCHAR(100)	   = NULL
										,@P_ATTR_06		  NVARCHAR(100)	   = NULL
										,@P_ATTR_07		  NVARCHAR(100)	   = NULL
										,@P_ATTR_08		  NVARCHAR(100)	   = NULL
										,@P_ATTR_09		  NVARCHAR(100)	   = NULL
										,@P_ATTR_10		  NVARCHAR(100)	   = NULL	
										,@P_USER_ID		  NVARCHAR(50)	 
  									    ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)    = 'true'  OUTPUT
  									    ,@P_RT_MSG            NVARCHAR(4000)  = ''	    OUTPUT
								   ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE  @P_ERR_STATUS INT = 0
        ,@P_ERR_MSG NVARCHAR(4000)=''		
		
		,@V_ID				NVARCHAR(32)
		,@V_CONF_ID			NVARCHAR(32)
		,@V_CONF_GRP_CD		NVARCHAR(100) = NULL
		,@V_CONF_CD			NVARCHAR(100) = NULL
		,@V_LANG_CONF_NM	NVARCHAR(100) = NULL
		,@V_CONF_NM			NVARCHAR(100) = NULL
		,@V_DEFAT_VAL		NVARCHAR(1)	  = NULL
		,@V_ACTV_YN			NVARCHAR(1)	  = NULL
		,@V_PRIORT			INT			  = NULL
		,@V_USE_YN			NVARCHAR(1)	  = NULL
		,@V_LANG_DESCRIP	NVARCHAR(100) = NULL
		,@V_DESCRIP			NVARCHAR(100) = NULL
		,@V_ATTR_01			NVARCHAR(100) = NULL
		,@V_ATTR_02			NVARCHAR(100) = NULL
		,@V_ATTR_03			NVARCHAR(100) = NULL
		,@V_ATTR_04			NVARCHAR(100) = NULL
		,@V_ATTR_05			NVARCHAR(100) = NULL
		,@V_ATTR_06			NVARCHAR(100) = NULL
		,@V_ATTR_07			NVARCHAR(100) = NULL
		,@V_ATTR_08			NVARCHAR(100) = NULL
		,@V_ATTR_09			NVARCHAR(100) = NULL
		,@V_ATTR_10			NVARCHAR(100) = NULL
		,@V_USER_ID			NVARCHAR(50)
		
SET @V_ID			= @P_ID
SET @V_CONF_ID		= @P_CONF_ID
SET @V_CONF_GRP_CD	= @P_CONF_GRP_CD
SET @V_CONF_CD		= @P_CONF_CD
SET @V_LANG_CONF_NM	= @P_LANG_CONF_NM
SET @V_CONF_NM		= @P_CONF_NM
SET @V_DEFAT_VAL	= @P_DEFAT_VAL
SET @V_ACTV_YN		= @P_ACTV_YN
SET @V_PRIORT		= @P_PRIORT
SET @V_USE_YN		= @P_USE_YN
SET @V_LANG_DESCRIP	= @P_LANG_DESCRIP
SET @V_DESCRIP		= @P_DESCRIP
SET @V_ATTR_01		= @P_ATTR_01
SET @V_ATTR_02		= @P_ATTR_02
SET @V_ATTR_03		= @P_ATTR_03
SET @V_ATTR_04		= @P_ATTR_04
SET @V_ATTR_05		= @P_ATTR_05
SET @V_ATTR_06		= @P_ATTR_06
SET @V_ATTR_07		= @P_ATTR_07
SET @V_ATTR_08		= @P_ATTR_08
SET @V_ATTR_09		= @P_ATTR_09
SET @V_ATTR_10		= @P_ATTR_10
SET @V_USER_ID		= @P_USER_ID
						   
BEGIN TRY
/***************************************************************************************************************************************************************************/
IF(@V_ATTR_01	='') SET @V_ATTR_01 = NULL	
IF(@V_ATTR_02	='') SET @V_ATTR_02 = NULL	
IF(@V_ATTR_03	='') SET @V_ATTR_03 = NULL	
IF(@V_ATTR_04	='') SET @V_ATTR_04 = NULL	
IF(@V_ATTR_05	='') SET @V_ATTR_05 = NULL	
IF(@V_ATTR_06	='') SET @V_ATTR_06 = NULL	
IF(@V_ATTR_07	='') SET @V_ATTR_07 = NULL	
IF(@V_ATTR_08	='') SET @V_ATTR_08 = NULL	
IF(@V_ATTR_09	='') SET @V_ATTR_09 = NULL	
IF(@V_ATTR_10	='') SET @V_ATTR_10 = NULL	
/********** Validation ************************************************************************************************************************************************/               
/* NULL 처리 VALIDATION */
IF(ISNULL(@V_CONF_CD,'') = '' OR ISNULL(@V_CONF_GRP_CD,'') ='')
    BEGIN
		SET @P_ERR_MSG = 'MSG_0006'
		RAISERROR (@P_ERR_MSG,11, 1);	    
	END
	;
/*CONF CODE 중복 VALIDATION*/
SELECT @P_ERR_STATUS =  COUNT(*)
 FROM TB_CM_COMM_CONFIG
WHERE 1=1
  AND CONF_CD = @V_CONF_CD
  AND CONF_GRP_CD = @V_CONF_GRP_CD
  AND ID != @V_ID
  ;
IF(@P_ERR_STATUS > 0)
    BEGIN
        SET @P_ERR_MSG = 'MSG_0005';
		RAISERROR (@P_ERR_MSG,11, 1);	    
    END;  
/******** Main Procedure ***********************************************************************************************************************************************/        
    -- 1) KEY값인 CONF_CD가 변경됐을 경우의 LANG_PACK UPDATE 
		/* @V_CONF_CD 이 변경됐을 경우 */
		DECLARE @V_ORG_CONF_CD		NVARCHAR(50) = ''
			  , @V_CONF_CNT		INT = 0
		-- 기존에 CONFIGURATION 값이 있는지 체크하고
		SELECT @V_CONF_CNT = COUNT(CONF_CD)
		  FROM TB_CM_COMM_CONFIG 
		 WHERE 1=1
		   AND ID = @V_ID
		IF(@V_CONF_CNT != 0)
			BEGIN
				-- 기존 값과 현재 변경된 CONF NAME이 다르면
				SELECT @V_ORG_CONF_CD = CONF_CD
--					  ,@V_CONF_NM = CONF_NM
				  FROM TB_CM_COMM_CONFIG
				 WHERE 1=1
				   AND ID = @V_ID				 
				-- LANG_PACK에 데이터가 이미 존재하는 경우
				IF(@V_CONF_CD != @V_ORG_CONF_CD)
				BEGIN
				IF EXISTS( -- data가 이미 있는 경우엔 변경 전 데이터만 삭제
							SELECT *
							  FROM TB_AD_LANG_PACK
							 WHERE LANG_KEY = 'CF_'+UPPER(@V_CONF_GRP_CD)+'_'+UPPER(@V_CONF_CD)
						)
						BEGIN
							DELETE FROM TB_AD_LANG_PACK WHERE LANG_KEY = 'CF_'+UPPER(@V_CONF_GRP_CD)+'_'+UPPER(@V_ORG_CONF_CD)
							DELETE FROM TB_AD_LANG_PACK WHERE LANG_KEY = 'CF_'+UPPER(@V_CONF_GRP_CD)+'_'+UPPER(@V_ORG_CONF_CD)+'_DESCRIP'
						END
						ELSE
						BEGIN
							UPDATE TB_AD_LANG_PACK
							   SET LANG_KEY = 'CF_'+UPPER(@V_CONF_GRP_CD)+'_'+UPPER(@V_CONF_CD	   )
							 WHERE LANG_KEY = 'CF_'+UPPER(@V_CONF_GRP_CD)+'_'+UPPER(@V_ORG_CONF_CD)
								;
							UPDATE TB_AD_LANG_PACK
							   SET LANG_KEY = 'CF_'+UPPER(@V_CONF_GRP_CD)+'_'+UPPER(@V_CONF_CD)	   +'_DESCRIP'
							 WHERE LANG_KEY = 'CF_'+UPPER(@V_CONF_GRP_CD)+'_'+UPPER(@V_ORG_CONF_CD)+'_DESCRIP'
						END
                        ;
				END
			END
			;
    --2) TB_DP_COMN_CONFIG 테이블 데이터 변경
		/*TB_CM_COMM_CONFIG 변경*/
		MERGE TB_CM_COMM_CONFIG TGT		
		USING (		SELECT
				     @V_ID							AS ID			
				    ,@V_CONF_ID						AS CONF_ID		
				    ,@V_CONF_GRP_CD					AS CONF_GRP_CD	
				    ,@V_CONF_CD						AS CONF_CD		
				    ,'CF_'+UPPER(@V_CONF_GRP_CD)
					+'_'+UPPER(@V_CONF_CD)			AS CONF_NM		
				    ,@V_DEFAT_VAL					AS DEFAT_VAL	
				    ,@V_ACTV_YN						AS ACTV_YN		
				    ,@V_PRIORT						AS PRIORT		
				    ,@V_USE_YN						AS USE_YN		
					,'CF_'+UPPER(@V_CONF_GRP_CD)
					+'_'+UPPER(@V_CONF_CD)
					+'_DESCRIP'						AS DESCRIP
				    ,@V_ATTR_01						AS ATTR_01		
				    ,@V_ATTR_02						AS ATTR_02		
				    ,@V_ATTR_03						AS ATTR_03		
				    ,@V_ATTR_04						AS ATTR_04		
				    ,@V_ATTR_05						AS ATTR_05		
				    ,@V_ATTR_06						AS ATTR_06		
				    ,@V_ATTR_07						AS ATTR_07		
				    ,@V_ATTR_08						AS ATTR_08		
				    ,@V_ATTR_09						AS ATTR_09		
				    ,@V_ATTR_10						AS ATTR_10		
					,@V_USER_ID						AS USER_ID
			  ) SRC
		 ON (TGT.ID = SRC.ID)
		 WHEN MATCHED THEN
				 UPDATE       
				SET  TGT.CONF_CD	 = SRC.CONF_CD				
					,TGT.CONF_NM	 = SRC.CONF_NM			
					,TGT.DEFAT_VAL	 = SRC.DEFAT_VAL	
					,TGT.ACTV_YN	 = SRC.ACTV_YN			
					,TGT.PRIORT		 = SRC.PRIORT		
					,TGT.USE_YN		 = SRC.USE_YN		
					,TGT.DESCRIP	 = SRC.DESCRIP			
					,TGT.ATTR_01	 = SRC.ATTR_01			
					,TGT.ATTR_02	 = SRC.ATTR_02			
					,TGT.ATTR_03	 = SRC.ATTR_03			
					,TGT.ATTR_04	 = SRC.ATTR_04			
					,TGT.ATTR_05	 = SRC.ATTR_05			
					,TGT.ATTR_06	 = SRC.ATTR_06			
					,TGT.ATTR_07	 = SRC.ATTR_07			
					,TGT.ATTR_08	 = SRC.ATTR_08			
					,TGT.ATTR_09	 = SRC.ATTR_09			
					,TGT.ATTR_10	 = SRC.ATTR_10			
					,TGT.MODIFY_BY	 = SRC.USER_ID
					,TGT.MODIFY_DTTM = GETDATE()
										 
		WHEN NOT MATCHED THEN
				INSERT (
						 ID			
						,CONF_ID		
						,CONF_GRP_CD	
						,CONF_CD		
						,CONF_NM		
						,DEFAT_VAL		
						,ACTV_YN		
						,PRIORT			
						,USE_YN		
						,DESCRIP		
						,ATTR_01		
						,ATTR_02		
						,ATTR_03		
						,ATTR_04		
						,ATTR_05		
						,ATTR_06		
						,ATTR_07		
						,ATTR_08		
						,ATTR_09		
						,ATTR_10		
						,CREATE_BY		
						,CREATE_DTTM	
						,MODIFY_BY		
						,MODIFY_DTTM	
					   )
			    VALUES(
						 REPLACE(NEWID(),'-','')				
						,SRC.CONF_ID			
						,SRC.CONF_GRP_CD		
						,SRC.CONF_CD			
						,SRC.CONF_NM			
						,SRC.DEFAT_VAL		
						,SRC.ACTV_YN			
						,SRC.PRIORT			
						,SRC.USE_YN			
						,SRC.DESCRIP	
						,SRC.ATTR_01	
						,SRC.ATTR_02	
						,SRC.ATTR_03	
						,SRC.ATTR_04	
						,SRC.ATTR_05	
						,SRC.ATTR_06	
						,SRC.ATTR_07	
						,SRC.ATTR_08	
						,SRC.ATTR_09	
						,SRC.ATTR_10	
						,SRC.USER_ID	
						,GETDATE()
						,NULL
						,NULL					 
					  )
					  ;
/******************************************************************** 
	-- SAVE 후 VALIDATION
*********************************************************************/
	/* DP_MS_AL_TP 일 때 */
--	IF(@P_CONF_GRP_CD = 'DP_MS_VAL_TP')
--	BEGIN
--		IF EXISTS (
--					SELECT REPLACE(CONF_CD,'QTY','AMT')
--					  FROM TB_CM_COMM_CONFIG
--					 WHERE CONF_GRP_CD = 'DP_MS_VAL_TP'
--					   AND ACTV_YN = 'Y'
--					   AND USE_YN = 'Y'
--					   AND REPLACE(CONF_CD,'QTY','AMT') IN (SELECT CONF_CD 
--				 											 FROM TB_CM_COMM_CONFIG 
--				 											WHERE CONF_GRP_CD = 'DP_MS_VAL_TP'
--				 					  						  AND CONF_CD LIKE 'AMT%'
--				 					  						  AND ACTV_YN = 'Y' 
--															  AND USE_YN = 'Y'
--															)
--					GROUP BY REPLACE(CONF_CD,'QTY','AMT')
--					  HAVING COUNT(CONF_CD) = 1
--				) 
--		BEGIN
--			SET @P_ERR_MSG = 'A pair of quantity codes must also be activated.';
--			RAISERROR (@P_ERR_MSG,11, 1);	    	
--		END
--	END		 
/********************************************************************
	-- LANG PACK
*********************************************************************/
    -- 3) LANG_PACK INSERT
        -- (1) CONF_CD
		MERGE TB_AD_LANG_PACK TGT		
		USING (		SELECT
					  'CF_'+UPPER(@V_CONF_GRP_CD)+'_'+UPPER(@V_CONF_CD)	AS LANG_KEY
					, @V_CONF_NM										AS LANG_VALUE
					, 'en'												AS LANG_CD

			  ) SRC
		 ON (TGT.LANG_KEY = SRC.LANG_KEY AND TGT.LANG_CD = SRC.LANG_CD)
		WHEN NOT MATCHED THEN
				INSERT (
						 LANG_CD
						,LANG_KEY
						,LANG_VALUE	
					   )
			    VALUES(				
						 SRC.LANG_CD
						,SRC.LANG_KEY
						,SRC.LANG_VALUE	 
					  )
					  ;
		-- (2) DESCRIP
		MERGE TB_AD_LANG_PACK TGT		
		USING (		SELECT
					  'CF_'+UPPER(@V_CONF_GRP_CD)+'_'+UPPER(@V_CONF_CD)+'_DESCRIP'  AS LANG_KEY
					, ISNULL(@V_DESCRIP,' ')										AS LANG_VALUE
					, 'en'															AS LANG_CD

			  ) SRC
		 ON (TGT.LANG_KEY = SRC.LANG_KEY AND TGT.LANG_CD = SRC.LANG_CD)
		WHEN NOT MATCHED THEN
				INSERT (
						 LANG_CD
						,LANG_KEY
						,LANG_VALUE	
					   )
			    VALUES(				
						 SRC.LANG_CD
						,SRC.LANG_KEY
						,SRC.LANG_VALUE	 
					  )
					  ;

/* DP_STD_WEEK 일때 정해진 코드로만 저장될 수 있도록  ****/
IF ( @V_CONF_GRP_CD = 'DP_STD_WEEK')
	BEGIN
		SELECT @P_ERR_STATUS = count(*)
		 WHERE @V_CONF_CD IN ( 'Sun','Mon','Tue','Wed','Thu','Fri','Sat')
		 ;
		 IF ( @P_ERR_STATUS = 0)
		 BEGIN
			set @P_ERR_MSG = 'MSG_5109'
			RAISERROR (@P_ERR_MSG,11, 1);	    
		 END

-- Calendar DP_WK calculation 2021.06.21
	DECLARE @P_DOW INT;
	SET @P_DOW =CASE UPPER(@V_CONF_CD) 
					WHEN 'MON' THEN 1
					WHEN 'TUE' THEN 2
					WHEN 'WED' THEN 3
					WHEN 'THU' THEN 4
					WHEN 'FRI' THEN 5
					WHEN 'SAT' THEN 6
					ELSE 7	--'SUN'
				END
				;
	SET DATEFIRST @P_DOW;	 

	-- WEEK로 UPDATE
	UPDATE TB_CM_CALENDAR
	  SET DP_WK = DATEPART(WEEK, DAT)
	;
 	-- 그 해의 가장 큰수가 7보다 작은 경우, 1A로 UPDATE 
	-- 그 다음해의 가장 작은 수가 7보다 작은 경우 1B로 UPDATE
	MERGE INTO TB_CM_CALENDAR TGT
	  USING (	
				SELECT YYYY
					 , MIN(MM) AS MM
					 , DP_WK 
					 , COUNT(DAT) AS CNT 
					 , CASE WHEN DP_WK = '1' THEN YYYY+'01' ELSE CONVERT(CHAR(4),CONVERT(INT,YYYY)+1)+'01' END AS NEW_DP_WK
--					 , CASE WHEN DP_WK = '1' THEN '1B' ELSE '1A' END AS NEW_DP_WK
				  FROM TB_CM_CALENDAR
			  GROUP BY YYYY, DP_WK 
				HAVING COUNT(DAT) < 7 
		--	  ORDER BY YYYY,MM, DP_WK  DESC
			) SRC
		ON TGT.YYYY = SRC.YYYY
	   AND TGT.MM = SRC.MM
	   AND TGT.DP_WK = SRC.DP_WK
WHEN MATCHED THEN
	   UPDATE SET DP_WK = SRC.NEW_DP_WK ;

	UPDATE TB_CM_CALENDAR
	  SET DP_WK = YYYY+ REPLICATE('0',2-LEN(DP_WK))+ DP_WK
	 WHERE LEN(DP_WK) < 3
	 ;

--	-- VALUE 확인
--	SELECT YYYY, MM, DD, DP_WK 
--	 FROM TB_CM_CALENDAR
--	 WHERE DP_WK IN ('52', '1A','53','54', '1B', '1', '2')	--'52',
--	 ORDER BY DAT 
	 
/*
-- Calendar DP_WK calculation 2021.04.29
DECLARE @p_MIN_DATE DATE
	 ,  @p_MIN_CNT  INT;
SELECT @p_MIN_DATE = MIN(DAT) FROM TB_CM_CALENDAR WHERE DOW_NM = UPPER(@V_CONF_CD)
;	 
 SELECT @p_MIN_CNT = COUNT(DAT) 
   FROM TB_CM_CALENDAR
  WHERE DAT < @p_MIN_DATE
 ;
 
 UPDATE TB_CM_CALENDAR
   SET DP_WK = 1
 WHERE DAT < @p_MIN_DATE
 ;
WITH M
 AS (
	SELECT DAT, CASE WHEN @p_MIN_CNT>0 THEN 2 ELSE 1 END + FLOOR((ROW_NUMBER() OVER( ORDER BY DAT ASC)-1)/7) AS DP_WK
	 FROM TB_CM_CALENDAR
	WHERE DAT >= @p_MIN_DATE 
 )
 UPDATE TB_CM_CALENDAR
   SET DP_WK = M.DP_WK
  FROM M
 WHERE TB_CM_CALENDAR.DAT = M.DAT 
 ;
 -- 예전방식
	DECLARE @P_DOW INT;
	SET @P_DOW =CASE UPPER(@P_CONF_CD) 
					WHEN 'MON' THEN 1
					WHEN 'TUE' THEN 2
					WHEN 'WED' THEN 3
					WHEN 'THU' THEN 4
					WHEN 'FRI' THEN 5
					WHEN 'SAT' THEN 6
					ELSE 7	--'SUN'
				END
				;
	SET DATEFIRST @P_DOW;

	UPDATE TB_CM_CALENDAR
	  SET DP_WK = DATEPART(WEEK, DAT)
	;
	UPDATE TB_CM_CALENDAR
	  SET DP_WK = 53
	WHERE DP_WK = 54;
*/
	update TB_AD_USER_PREF_OPT  
	set OPT_VALUE = 'BASE.'+UPPER(@P_CONF_CD) 
	from TB_AD_USER_PREF_MST m where m.id = USER_PREF_MST_ID and LEFT(m.VIEW_CD, 5) = 'UI_DP'  AND OPT_TP = 'type'
	 ;
	END
/********************************************************************	
	--	DP_USE_COMMENT
********************************************************************/
IF (@V_CONF_GRP_CD = 'DP_USE_COMMENT')
	BEGIN
		UPDATE TB_AD_USER_PREF_DTL
		  SET EDIT_TARGET_YN = @P_ACTV_YN
		 WHERE 1=1
--		   AND USER_PREF_MST_ID IN (SELECT ID FROM TB_AD_USER_PREF_MST WHERE VIEW_CD LIKE 'UI_DP%' OR VIEW_CD LIKE 'UI_BP%')
		   AND DIM_MEASURE_TP = 'DEFAULT'
		   AND FLD_CD = @P_CONF_CD 
		   AND FLD_APPLY_CD = '_'+@P_CONF_CD
		   ;
	END
	;
/********************************************************************
	-- Measure Setting Data Handling
*********************************************************************/
IF (ISNULL(@P_ACTV_YN,'N') = 'N' OR ISNULL(@P_USE_YN,'N') = 'N') AND @P_CONF_GRP_CD = 'DP_MS_VAL_TP'
	BEGIN
		DELETE 
		  FROM TB_DP_MEASURE_SETTING
		 WHERE MEASURE_VAL_TP_ID = (SELECT ID 
									  FROM TB_CM_COMM_CONFIG 
									 WHERE CONF_CD = @P_CONF_CD 
									   AND CONF_GRP_CD = 'DP_MS_VAL_TP'
									)
	END
/************************************************************************
	-- DP_DMND_CUSTOM

	-- attr_01 : double, integer, string, boolean, date
************************************************************************/
IF (@V_CONF_GRP_CD = 'DP_DMND_CUSTOM' AND @P_ACTV_YN = 'Y')
	BEGIN
		IF NOT EXISTS (
						SELECT 1
						  FROM INFORMATION_SCHEMA.COLUMNS
						 WHERE TABLE_CATALOG = DB_NAME()
						   AND TABLE_NAME = 'TB_DP_DIMENSION_DATA'
						   AND COLUMN_NAME = @P_CONF_CD
					 )
			BEGIN
				DECLARE @V_DATA_TYPE NVARCHAR(50);

				SELECT @V_DATA_TYPE = 
					CASE @P_ATTR_01
						WHEN 'double'	THEN 'DECIMAL(10,3)'
						WHEN 'integer'	THEN 'INT'
						WHEN 'string'	THEN 'NVARCHAR(100)'
						WHEN 'boolean'	THEN 'CHAR(1)'
						WHEN 'date'		THEN 'DATETIME'
					  ELSE NULL END 
				;
                IF(@V_DATA_TYPE IS NULL) 
				BEGIN
					SET @P_ERR_MSG = 'Check Attribute 01 (data type)';
					RAISERROR (@P_ERR_MSG,11, 1);	    
                END
                ;       
				SET @P_CONF_CD = TRIM(@P_CONF_CD);
				EXECUTE ('ALTER TABLE TB_DP_DIMENSION_DATA ADD ['+@P_CONF_CD+'] '+@V_DATA_TYPE);
			END
			;
	END 
	;
/************************************************************************
	-- Level Type
************************************************************************/
IF (@P_CONF_GRP_CD = 'DP_LV_TP' AND @P_ACTV_YN = 'Y')
	DECLARE @P_LV_TP_ID CHAR(32)
		  , @P_LV_TP_CD NVARCHAR(100)
	;
	 SELECT TOP 1 @P_LV_TP_ID = ID 
			    , @P_LV_TP_CD = CONF_CD 
	  FROM TB_CM_COMM_CONFIG 
	 WHERE CONF_CD = @P_CONF_CD 
	   AND CONF_GRP_CD = 'DP_LV_TP'
	;

	SELECT @V_CONF_CNT = COUNT(1)  
	 FROM TB_CM_LEVEL_MGMT
	WHERE LV_TP_ID = @P_LV_TP_ID
	  ;
IF (@V_CONF_CNT = 0)
	BEGIN 
		INSERT INTO TB_CM_LEVEL_MGMT 
			  ( ID
			  , LV_TP_ID
			  , LV_CD
			  , LV_NM
			  , SEQ
			  , LV_LEAF_YN
			  , SRP_LV_YN
			  , LEAF_YN
			  , ACTV_YN
			  , SALES_LV_YN
			  , ACCOUNT_LV_YN
			  , DEL_YN
			  , CREATE_BY
			  , CREATE_DTTM
			  )
		SELECT REPLACE(NEWID(),'-','')
			 , @P_LV_TP_ID 
			 , LV.LV_CD 
			 , LV.LV_NM 
			 , LV.SEQ 
			 , 'N'  AS LV_LEAF_YN 
			 , 'N'  AS SRP_LV_YN 
			 , 'Y'  AS LEAF_YN 
			 , 'Y'  AS ACTV_YN 
			 , LV.SALES_LV_YN
			 , LV.ACCOUNT_LV_YN
			 , 'N'  AS DEL_YN 
			 , @P_USER_ID
			 , GETDATE() 
		  FROM TB_CM_LEVEL_MGMT LV 
			   INNER JOIN 
			   TB_CM_COMM_CONFIG CC 
			ON LV.LV_TP_ID = CC.ID 	   
		   AND CC.DEFAT_VAL = 'Y' 
		  WHERE COALESCE(LV.DEL_YN, 'N') = 'N'
			AND LV.ACTV_YN = 'Y' 
			AND CC.ACTV_YN = 'Y' 
			AND LV.LEAF_YN = 'Y' 
			AND COALESCE(SALES_LV_YN,'N') = 'N' 
			AND CC.CONF_CD = LEFT(@P_LV_TP_CD,1)	 
			; 	 
	END
	
	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
--				THROW;
				EXEC SP_COMM_RAISE_ERR

END CATCH;


go

