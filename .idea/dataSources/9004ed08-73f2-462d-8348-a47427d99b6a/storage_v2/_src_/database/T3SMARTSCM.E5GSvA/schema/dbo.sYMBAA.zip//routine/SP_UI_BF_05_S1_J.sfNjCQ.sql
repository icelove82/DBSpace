
CREATE PROCEDURE [dbo].[SP_UI_BF_05_S1_J]  (
									  @P_JSON				NVARCHAR(MAX)
									, @P_USER_ID			NVARCHAR(50)
									, @P_RT_ROLLBACK_FLAG  	NVARCHAR(10)   = 'true'  OUTPUT
									, @P_RT_MSG            	NVARCHAR(4000) = ''		OUTPUT
				                   ) 
AS
/*
	History (date / writer / comment)
	-- 2020.02.03 / kim sohee / change data type of correction comment : char(32) => nvarchar(50) for excel import 
    -- 2020.03.08 / Yeunkyung Nam / update 대상 dp_wk가 동일한 실적 모두 update
                                  / ID 가 동일한 날짜는 화면에서 받은 QTY_CORRECTION 로 update
                                  / ID 가 다른 날짜는 null 로 update
*/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''
;
	   
--IF  (@P_CORRECTION_COMMENT IS NOT NULL AND @P_QTY_CORRECTION IS NULL)  
--BEGIN
--   SET @P_ERR_MSG = 'Calibration QTY is required' 
--   RAISERROR (@P_ERR_MSG,12, 1);
--END

BEGIN TRY
	WITH CHECK_ERR AS 
	(
		SELECT CASE WHEN CORRECTION_COMMENT <> 'NN' AND QTY_CORRECTION IS NULL THEN 1 ELSE 0 END ERR
		FROM OpenJson(@P_JSON)
			WITH
			(
				CORRECTION_COMMENT 	NVARCHAR(50)	'$.CORRECTION_COMMENT'
			  , QTY_CORRECTION		decimal(20, 3)	'$.QTY_CORRECTION'
			)
	)
	SELECT TOP (1) @P_ERR_MSG = 'Calibration QTY is required' 
	FROM   CHECK_ERR 
	WHERE  ERR = 1;
	IF @P_ERR_MSG <> ''
		RAISERROR (@P_ERR_MSG,12, 1)
		
	;


	WITH JSON AS 
	(
		SELECT JS.*
			 --, CC.ID AS SO_STATUS_ID
			 , AM.ID AS ACCOUNT_ID
			 , IM.ID AS ITEM_ID
             , CL.DP_WK AS DP_WK
		FROM OpenJson(@P_JSON) 
			WITH
			(
			    ID					CHAR(32)		'$.ID'
			  , ACCOUNT_CD			NVARCHAR(100)	'$.ACCOUNT_CD'
			  , ITEM_CD				NVARCHAR(100)	'$.ITEM_CD'
			  , BASE_DATE			DATETIME		'$.BASE_DATE'
			  , STATUS				NVARCHAR(50)	'$.STATUS'
			  , QTY					decimal(20, 3)	'$.QTY'
			  , QTY_CORRECTION		decimal(20, 3)	'$.QTY_CORRECTION'
			  , CORRECTION_COMMENT 	NVARCHAR(50)	'$.CORRECTION_COMMENT'
			) JS
		--INNER JOIN TB_CM_COMM_CONFIG CC
		--	ON CC.CONF_CD = JS.STATUS
		--	AND CC.CONF_GRP_CD = 'DP_SO_STATUS'
		INNER JOIN TB_CM_ITEM_MST IM 
			ON JS.ITEM_CD = IM.ITEM_CD 
		INNER JOIN TB_DP_ACCOUNT_MST AM 
			ON JS.ACCOUNT_CD = AM.ACCOUNT_CD 
        INNER JOIN TB_CM_CALENDAR CL
            ON JS.BASE_DATE = CL.DAT
	),
	CORRECTION_DAT AS 
	(
		SELECT SA.ID 				AS ID
			 , CASE WHEN SA.ID = JSON.ID THEN JSON.QTY_CORRECTION ELSE NULL END 	AS QTY_CORRECTION
             , CASE WHEN SA.ID = JSON.ID THEN ROUND(CAST(JSON.QTY_CORRECTION AS FLOAT) * (sum(SA.AMT) over (partition by sa.item_mst_id,sa.account_id,CAL.dp_wk)/sum(SA.QTY) over (partition by sa.item_mst_id,sa.account_id,CAL.dp_wk) ),0) ELSE NULL END 	AS AMT_CORRECTION
			 , CASE WHEN CORRECTION_COMMENT = 'NN' 
			 		THEN NULL 
			 		ELSE (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_CD = CORRECTION_COMMENT AND CONF_GRP_CD = 'BF_SO_MODIFY_REASON') END AS CORRECTION_COMMENT_ID
			 , CASE WHEN JSON.QTY_CORRECTION IS NOT NULL 
			 		THEN 'Y' 
			 		ELSE 'N' END 	AS CORRECTION_YN
			 , @P_USER_ID 			AS MODIFY_BY
			 , GETDATE() 			AS MODIFY_DTTM
		FROM TB_CM_ACTUAL_SALES SA 
             INNER JOIN TB_CM_CALENDAR CAL
          ON SA.BASE_DATE = CAL.DAT
             INNER JOIN JSON
		  ON SA.ITEM_MST_ID = JSON.ITEM_ID
		 AND SA.ACCOUNT_ID = JSON.ACCOUNT_ID
		 AND CAL.DP_WK = JSON.DP_WK
	)
	
	UPDATE  TAR
	    SET QTY_CORRECTION			= SRC.QTY_CORRECTION 
          , AMT_CORRECTION			= SRC.AMT_CORRECTION 
		  , CORRECTION_COMMENT_ID 	= SRC.CORRECTION_COMMENT_ID
		  , CORRECTION_YN		   	= SRC.CORRECTION_YN
		  , MODIFY_BY			   	= @P_USER_ID
		  , MODIFY_DTTM		   		= GETDATE()
	FROM TB_CM_ACTUAL_SALES AS TAR
	INNER JOIN CORRECTION_DAT SRC
	  	ON TAR.ID = SRC.ID

--				MERGE TB_CM_ACTUAL_SALES TAR
--				USING ( 
--						SELECT
--						  @P_ID						AS 	ID					
--						, @V_ACCOUNT_ID				AS 	ACCOUNT_ID
--						, @V_ITEM_MST_ID			AS 	ITEM_MST_ID
--						, @P_BASE_DATE				AS 	BASE_DATE			
--						, @V_SO_STATUS_ID			AS 	SO_STATUS_ID
--						, @P_QTY				    AS 	QTY			
--						, @P_QTY_CORRECTION		 	AS 	QTY_CORRECTION
--						, @P_CORRECTION_COMMENT     AS 	CORRECTION_COMMENT_ID
--						, @P_USER_ID				AS  USER_ID
--					  ) SRC
--				ON	  (TAR.ID			= SRC.ID	
--					  )
--				WHEN MATCHED THEN
--					 UPDATE 
--					   SET   TAR.QTY_CORRECTION		   = SRC.QTY_CORRECTION
--							,TAR.CORRECTION_COMMENT_ID = SRC.CORRECTION_COMMENT_ID
--							,TAR.CORRECTION_YN		   = 'Y'
--							,TAR.MODIFY_BY			   = SRC.USER_ID
--							,TAR.MODIFY_DTTM		   = GETDATE()    
--				WHEN NOT MATCHED THEN 
--					 INSERT (
--							  ID					
--							, ACCOUNT_ID	
--							, ITEM_MST_ID		
--							, BASE_DATE			
--							, SO_STATUS_ID		
--							, QTY				
--							, QTY_CORRECTION		
--							, CORRECTION_COMMENT_ID
--							, CREATE_BY			
--							, CREATE_DTTM
--							) 
--					 VALUES (
--							 (SELECT REPLACE(NEWID(),'-','') )
--							,SRC.ACCOUNT_ID	
--							,SRC.ITEM_MST_ID		
--							,SRC.BASE_DATE			
--							,SRC.SO_STATUS_ID		
--							,SRC.QTY				
--							,SRC.QTY_CORRECTION	
--							,SRC.CORRECTION_COMMENT_ID
--							,SRC.USER_ID			
--							,GETDATE()		  
-- 							) 
--							
--						;    

     
	   SET @P_RT_ROLLBACK_FLAG = 'true'

	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;

go

