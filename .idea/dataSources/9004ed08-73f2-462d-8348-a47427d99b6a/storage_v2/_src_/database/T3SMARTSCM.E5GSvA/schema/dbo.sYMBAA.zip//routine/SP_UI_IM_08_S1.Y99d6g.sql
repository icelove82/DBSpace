CREATE PROCEDURE [dbo].[SP_UI_IM_08_S1] (
	 @P_ID					CHAR(32)
	,@P_SABC_VAL			NVARCHAR(50)
	,@P_PRPSAL_SVC_LV		DECIMAL(20, 3)
	,@P_FIXED_YN			CHAR(1)
	,@P_ACTV_YN				CHAR(1)	
	,@P_USER_ID				NVARCHAR (100)
	,@P_RT_ROLLBACK_FLAG	NVARCHAR(10)   = 'true' OUTPUT
	,@P_RT_MSG				NVARCHAR(4000) = '' OUTPUT
) 
AS
/*****************************************************************************
 * System Name : T3Enterprise IM
 * Business Name : SABC Analysis
 * Program Name(ID) :SP_UI_IM_08_S1
 * Program Description : Save operation for SABC Analysis
 *
 * Create Date : 2017.08.02
 * Author : Han youngseok
 *
 * Modifier    Modified Date    Revision History
 * --------    -------------    ----------------------------------------------
 * Kim S.H.    2018/02/06       Error message validation 
 * RSK         2019/03/11       Added comments & Formatting
 *
 *****************************************************************************/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_MSG NVARCHAR(4000)=''

BEGIN TRY
	MERGE TB_IM_SABC_ANALYSIS_MST TARGET
	USING ( 
			SELECT
				 @P_ID					AS SABC_ID
				,@P_SABC_VAL			AS SABC_VAL
				,@P_PRPSAL_SVC_LV		AS PRPSAL_SVC_LV 
				,@P_FIXED_YN			AS FIXED_YN
				,@P_ACTV_YN				AS ACTY_YN	
				,@P_USER_ID				AS USER_ID				
			) SOURCE
	ON  TARGET.ID = SOURCE.SABC_ID
	WHEN MATCHED THEN
			UPDATE 
			SET   
				 TARGET.SABC_VAL				= SOURCE.SABC_VAL
				,TARGET.PRPSAL_SVC_LV			= SOURCE.PRPSAL_SVC_LV
				,TARGET.FIXED_YN				= SOURCE.FIXED_YN
				,TARGET.ACTV_YN					= SOURCE.ACTY_YN		
				,TARGET.MODIFY_BY				= SOURCE.USER_ID       
				,TARGET.MODIFY_DTTM				= GETDATE();    
	/*WHEN NOT MATCHED */

	SET @P_RT_ROLLBACK_FLAG = 'true'
	SET @P_RT_MSG = 'MSG_0001'  -- Saved successfully.
END TRY

BEGIN CATCH
	IF(ERROR_MESSAGE() LIKE 'MSG_%')
		BEGIN
			SET @P_ERR_MSG = ERROR_MESSAGE()
			SET @P_RT_ROLLBACK_FLAG = 'false'
			SET @P_RT_MSG = @P_ERR_MSG
		END
	ELSE
		THROW;
END CATCH;

go

