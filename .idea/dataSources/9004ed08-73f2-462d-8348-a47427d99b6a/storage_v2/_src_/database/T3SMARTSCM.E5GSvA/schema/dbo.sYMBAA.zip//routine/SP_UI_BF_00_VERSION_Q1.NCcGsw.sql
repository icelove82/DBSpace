CREATE PROCEDURE [dbo].[SP_UI_BF_00_VERSION_Q1] (
	@P_CLOSE_YN	CHAR(1)
) AS 

/*
	정확도 계산하고 Best Selection까지 끝난 BF Version 조회 

	Used View
	-- UI_BF_50, UI_BF_51, UI_BF_52, UI_BF_55
	History (Date / Writer / Comment)
	-- 
    2021-07-28 / suchang.park / 버전 Best Selection PROCESS_NO 변경 (990 -> 990000)
*/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN
	SELECT M.VER_CD
		 , M.RW 
		 , RULE_01
	  FROM (
		SELECT VER_CD
			,  ROW_NUMBER() OVER (ORDER BY VM.VER_CD DESC)  RW
			,  RULE_01
		  FROM TB_BF_CONTROL_BOARD_VER_DTL VM
	     WHERE (VM.PROCESS_NO = 990000 OR VM.PROCESS_NO = 990)
		   AND CASE WHEN ISNULL(@P_CLOSE_YN,'Y') = 'Y' THEN [STATUS]  ELSE 'Completed' END = 'Completed'
			) M
	 WHERE RW <= 5
END
;

go

