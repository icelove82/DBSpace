/*****************************************************************************
Title : [SP_DP_00_SALES_LV_DATA_Q1]
최초 작성자 : 민희영
최초 생성일 : 2017.06.23
 
설명 
 - DP 콤보(LEVEL Management) 조회 프로시저 
  
History (수정일자 / 수정자 / 수정내용)
- 2017.06.23 / 민희영 / 최초 작성
- 2019.01.22 / 김소희 /  p_LV_CD 등 파라미터 추가 (특정 레벨만 활용하기 위해)
    2019.01.25 / 김소희 / 필요없는 테이블 JOIN 제거    
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_00_SALES_LV_DATA_Q1] (@p_LEAF_TP			 NVARCHAR(30) = ''
                                                     , @p_TYPE				 NVARCHAR(10) = ''
													 , @P_LV_CD				 NVARCHAR(4000) = ''
													 , @P_SALES_LV_CD		 NVARCHAR(30) = ''
													 , @P_SALES_LV_NM		 NVARCHAR(30) = ''
													 , @P_PARENT_SALES_LV_CD NVARCHAR(30) = ''
								                 ) AS 

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

DECLARE @V_LEAF_TP NVARCHAR(2) = 'N'
, @V_LV_TP		NVARCHAR(30) = ''
;
SET @V_LV_TP    = 'S'

IF @p_LEAF_TP = 'LEAF'   
BEGIN 
    SET @V_LEAF_TP = 'Y' ;
END

IF @p_TYPE like '%AD%'
BEGIN
 SELECT @V_LV_TP = CONF_CD from TB_CM_COMM_CONFIG where CONF_GRP_CD = 'DP_LV_TP' and conf_cd like 'S%' and ATTR_01 like '%'+@p_TYPE ;
END 


SELECT * 
FROM ( 
		SELECT    '' AS ID 
              , @P_TYPE   AS SALES_LV_CD
              , @P_TYPE   AS SALES_LV_NM
              , 0 AS SEQ
              , NULL AS LV_MGMT_ID
              , NULL AS LV_CD
              , NULL AS LV_NM
              , 0 AS LV_SEQ
              , NULL AS PARENT_SALES_LV_ID
              , NULL AS PARENT_SALES_LV_CD
              , NULL AS PARENT_SALES_LV_NM
              , NULL AS CURCY_CD_ID
              , NULL AS CURCY_CD_NM
              , NULL AS ACTV_YN
		WHERE 'ALL' = UPPER(@P_TYPE)
		UNION ALL 
        SELECT SL.ID
              ,SL.SALES_LV_CD        AS SALES_LV_CD 
              ,SL.SALES_LV_NM        AS SALES_LV_NM 
              ,SL.SEQ
              ,SL.LV_MGMT_ID
              ,LM.LV_CD
              ,LM.LV_NM
              ,LM.SEQ               AS LV_SEQ
              ,SL.PARENT_SALES_LV_ID
              ,SL2.SALES_LV_CD  AS PARENT_SALES_LV_CD
              ,SL2.SALES_LV_NM  AS PARENT_SALES_LV_NM  
              ,SL.CURCY_CD_ID
              ,CU.COMN_CD_NM        AS CURCY_CD_NM
              ,SL.ACTV_YN                            
          FROM TB_CM_LEVEL_MGMT  LM     
               INNER JOIN
               TB_DP_SALES_LEVEL_MGMT  SL               
            ON LM.ID = SL.LV_MGMT_ID 
           AND SL.ACTV_YN = 'Y'
           AND LM.ACTV_YN = 'Y'
           AND ISNULL(LM.DEL_YN, 'N') = 'N'
		   	   INNER JOIN TB_CM_COMM_CONFIG B
			ON B.CONF_GRP_CD = 'DP_LV_TP'
			AND B.CONF_CD = @V_LV_TP
			AND B.ID = LM.LV_TP_ID 
	           LEFT OUTER JOIN  
               TB_DP_SALES_LEVEL_MGMT SL2 
            ON  SL.PARENT_SALES_LV_ID = SL2.ID AND ISNULL(SL2.DEL_YN, 'N') = 'N' AND SL2.ACTV_YN = 'Y'
               LEFT OUTER JOIN 
               TB_AD_COMN_CODE CU
            ON CU.ID = SL.CURCY_CD_ID
          WHERE 1=1
            AND CASE WHEN  ISNULL(@V_LEAF_TP,'') ='' THEN LM.LV_LEAF_YN ELSE @V_LEAF_TP END = LM.LV_LEAF_YN                 
            AND (LM.LV_CD IN (SELECT Value VAL 
								FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_LV_CD),''),'|')) OR ISNULL(@P_LV_CD,'') ='')
            AND UPPER(SL.SALES_LV_CD) LIKE '%' + UPPER(RTRIM(@p_SALES_LV_CD)) +'%'
            AND UPPER(SL.SALES_LV_NM) LIKE '%' + UPPER(RTRIM(@p_SALES_LV_NM)) +'%'
			AND (SL2.SALES_LV_CD = @P_PARENT_SALES_LV_CD OR ISNULL(@P_PARENT_SALES_LV_CD,'') ='')
     )  A
ORDER BY A.LV_SEQ, A.SEQ
 ;


END

go

