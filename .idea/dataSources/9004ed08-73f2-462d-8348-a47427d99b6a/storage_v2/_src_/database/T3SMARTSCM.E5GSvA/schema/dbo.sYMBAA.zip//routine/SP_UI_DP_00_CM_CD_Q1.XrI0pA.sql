/*****************************************************************************
Title : SP_DP_00_CM_CD
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP 콤보(공통코드) 조회 프로시저 
  
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2019.01.25 / 김소희 / 코드 정리 및 UI 사용 스타일 분석 :Interfaced YN, Currency code
                         / 사용 코드 추가 : MODULE_TP 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_00_CM_CD_Q1] (@p_GRP_CD NVARCHAR(30) = ''
                                            , @p_TYPE   NVARCHAR(30) = ''
								   ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
DECLARE @V_GRP_CD NVARCHAR(30) = ''
	  , @V_TYPE   NVARCHAR(30) = ''

SET @V_GRP_CD = @p_GRP_CD
SET @V_TYPE   = @p_TYPE

BEGIN
IF @p_GRP_CD = 'MODULE_TP'
      BEGIN          
        SELECT NULL           AS ID
             , NULL           AS CD 
             , UPPER(@P_TYPE)  AS CD_NM
             , 0              AS SEQ 
             , 'ALL' AS ALL_YN   
        WHERE UPPER(@p_TYPE) = 'ALL'
        UNION
        SELECT B.ID          AS ID
              ,B.COMN_CD     AS CD
              ,B.COMN_CD_NM  AS CD_NM
              ,CASE B.COMN_CD WHEN 'DP' THEN 1 ELSE SEQ  END  AS SEQ
              , @P_TYPE AS ALL_YN
        FROM TB_AD_COMN_GRP A
           INNER JOIN
           TB_AD_COMN_CODE B
          ON (A.ID = B.SRC_ID)
         WHERE 1=1
           AND A.GRP_CD = 'MODULE_TP'
           AND (B.COMN_CD = 'DP'
             OR B.COMN_CD = 'SRP'
             OR B.COMN_CD = 'BF'
			 OR B.COMN_CD = 'CM'
               )
         ORDER BY SEQ;
	END
ELSE IF  @p_GRP_CD = 'ITEM_TYPE'
	BEGIN
		SELECT	A.ID					AS ID,
				A.ITEM_TP				AS CD,
				A.CONVN_NM				AS CD_NM
		FROM	TB_CM_ITEM_TYPE A		
	END
ELSE IF  @p_GRP_CD = 'UOM'
	BEGIN
	SELECT	A.ID		            AS ID,
			A.UOM_CD	            AS CD,
			A.UOM_NM	            AS CD_NM
	FROM	TB_CM_UOM A
	WHERE	ISNULL(A.TIME_UOM_YN, 'N') = 'N'
	END
ELSE

	     		SELECT A.ID
					 , A.CD
					 , A.CD_NM
				FROM (
						SELECT  ''  AS ID
							  , CASE WHEN @V_GRP_CD ='CURRENCY' THEN UPPER(@V_TYPE) ELSE '' END  AS CD  -- CUrrency 는 CD 값을 combo에 value 로 사용 
							  , UPPER(@P_TYPE)  AS CD_NM
							  , 0   AS SEQ 
						WHERE UPPER(@V_TYPE) = 'ALL'
						UNION ALL 
						SELECT  CD.ID
							  , CD.COMN_CD  AS CD
							  , CD.COMN_CD_NM  AS CD_NM
							  , CD.SEQ
						  FROM TB_AD_COMN_GRP CM
							  , TB_AD_COMN_CODE CD 
						  WHERE CM.ID = CD.SRC_ID
						   AND CM.GRP_CD = @V_GRP_CD 
						) A
				ORDER BY A.SEQ ASC, A.CD ASC
				;
			



END







go

