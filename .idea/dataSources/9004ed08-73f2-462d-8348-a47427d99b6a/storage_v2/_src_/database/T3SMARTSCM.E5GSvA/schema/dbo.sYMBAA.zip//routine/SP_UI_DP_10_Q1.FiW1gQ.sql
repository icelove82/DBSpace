/*****************************************************************************
Title : SP_DP_10_Q1
최초 작성자 : 민희영
최초 생성일 : 2017.06.20
 
설명 
 - DP Sales Hierarchy Management
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 민희영 / 최초 작성
- 2019.04.25 / 김소희 / DEL_YN Null처리 
- 2019.06.21 / 김소희 / 불필요한 config 테이블 정리
- 2021.10.06 / kim sohee / add Level Type 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_10_Q1] (@p_SALES_LV    NVARCHAR(50) = ''
									  , @P_SRP_LV_YN	NVARCHAR(1)
									  , @p_ACTV_YN     NVARCHAR(1) = ''
									   ,@p_LV_TP_ID     NVARCHAR(32) = ''
								   ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON 
 

BEGIN

SELECT SL.ID
      ,SL.SALES_LV_CD
      ,SL.SALES_LV_NM
      ,SL.LV_MGMT_ID
      ,SL.PARENT_SALES_LV_ID
	  ,SL2.SALES_LV_CD  AS PARENT_SALES_LV_CD
	  ,SL2.SALES_LV_NM  AS PARENT_SALES_LV_NM  
	  ,SL.CURCY_CD_ID
      ,SL.SEQ
	  ,SL.VIRTUAL_YN
      ,SL.ACTV_YN
	  ,SL.DEL_YN
	  ,SL.SRP_YN
      ,SL.CREATE_BY
      ,SL.CREATE_DTTM
      ,SL.MODIFY_BY
      ,SL.MODIFY_DTTM	  
	  ,B.CONF_CD AS LV_TP_CD
  FROM TB_DP_SALES_LEVEL_MGMT SL
	   INNER JOIN  
	   TB_CM_LEVEL_MGMT LM
	ON SL.LV_MGMT_ID = LM.ID
	AND LM.ACTV_YN = 'Y'
	AND ISNULL(LM.DEL_YN,'N') = 'N'
	AND LM.SRP_LV_YN LIKE '%' + LTRIM(RTRIM(@P_SRP_LV_YN)) +'%'	
	   INNER JOIN 
	   TB_CM_COMM_CONFIG B
	ON B.ID = LM.LV_TP_ID
	   LEFT OUTER JOIN  
	   TB_DP_SALES_LEVEL_MGMT SL2 
	ON SL.PARENT_SALES_LV_ID = SL2.ID 
   AND ISNULL(SL2.DEL_YN,'N') = 'N' 
   AND SL2.ACTV_YN = 'Y'
  WHERE 1=1
	AND SL.LV_MGMT_ID LIKE '%' + LTRIM(RTRIM(@P_SALES_LV)) +'%'	
	AND ISNULL(SL.ACTV_YN,'N') LIKE '%' + RTRIM(@P_ACTV_YN) +'%'
	AND LM.LV_TP_ID = @P_LV_TP_ID
  ORDER BY LM.SEQ, SL.SEQ
 ;
END

go

