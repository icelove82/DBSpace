/*****************************************************************************
Title : SP_DP_12_Q2
최초 작성자 : 민희영
최초 생성일 : 2017.06.20

설명 
 - DP Sales Authority Management

History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 민희영 / 최초 작성
- 2020.03.12 / KSH / ADD USER_ID 
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_12_Q2] (@p_SALES_LV_ID  NVARCHAR(50) = ''
								   ) AS 

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN


SELECT SA.ID 
      ,SA.SALES_LV_ID
	  ,SL.SALES_LV_CD
      ,SL.SALES_LV_NM
      ,CONVERT(DATETIME, SA.STRT_DATE_AUTH,112)  AS STRT_DATE_AUTH
      ,CONVERT(DATETIME, SA.END_DATE_AUTH,112)   AS END_DATE_AUTH
      ,SA.EMP_ID
	  ,DE.USERNAME AS USER_ID
	  ,DE.USERNAME  as EMP_NO
	  ,DE.DISPLAY_NAME  as EMP_NM
      ,SA.CREATE_BY
      ,SA.CREATE_DTTM
      ,SA.MODIFY_BY
      ,SA.MODIFY_DTTM
  FROM TB_DP_SALES_AUTH_MAP SA
         LEFT OUTER JOIN TB_DP_SALES_LEVEL_MGMT SL ON SA.SALES_LV_ID = SL.ID
	     LEFT OUTER JOIN TB_AD_USER DE             ON SA.EMP_ID      = DE.ID
  WHERE SA.SALES_LV_ID   =  @p_SALES_LV_ID  
  ORDER BY SA.STRT_DATE_AUTH
;		
END

go

