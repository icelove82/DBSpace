CREATE PROCEDURE [dbo].[SP_UI_DP_00_MAKE_USER_GROUP]  (
     @P_USER_ID        CHAR(32)
    ,@P_USER_NAME      NVARCHAR
    ,@P_AUTH_TP_ID     CHAR(32)
) 
AS
/**********************************************************************************************
	Create User Group By Auth type ( User mapping )

	History ( date / writer / comment)
	- 2021.03.10 / kim sohee / draft  
**********************************************************************************************/
	DECLARE 
     @P_GRP_ID CHAR(32),
     @P_IF_CNT   INT;
BEGIN

    -- Insert User Group
    SELECT @P_GRP_ID = ID 
      FROM TB_AD_GROUP
     WHERE GRP_CD = (SELECT LV_CD 
                       FROM TB_CM_LEVEL_MGMT 
                      WHERE ID = @P_AUTH_TP_ID
                     )
     ;
     SELECT @P_IF_CNT = COUNT(*)  
       FROM TB_AD_USER_GROUP
      WHERE USER_ID = @P_USER_ID 
        AND GRP_ID = @P_GRP_ID
          ;
              
    IF (@P_IF_CNT = 0)
        BEGIN
           INSERT INTO TB_AD_USER_GROUP 
                       ( ID
                       , USER_ID
                       , GRP_ID
                       , PREF_DEFAULT_YN
                       , CREATE_BY
                       , CREATE_DTTM
                       )
            VALUES ( REPLACE(NEWID(),'-','')
                    ,@P_USER_ID
                    ,@P_GRP_ID
                    ,'N'
                    ,@P_USER_NAME
                    , GETDATE() 
                    )
                    ;
		END
		;

END
;

go

