/*****************************************************************************
Title : SP_DP_08_S1
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP Item Level Management
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2018.12.24 / 김소희 / PARENT_ITEM_LV_ID 공백 제거 (TREE 조회 오류)  
	- 2020.11.10 / Kim sohee / data type of CODE NVARCHAR(100)
*****************************************************************************/


CREATE PROCEDURE [dbo].[SP_UI_DP_08_S1]  (
                                       @p_ID                   NVARCHAR(32)     = NULL         
									  ,@p_ITEM_LV_CD           NVARCHAR(100)     = NULL         
									  ,@p_ITEM_LV_NM           NVARCHAR(240)    = NULL         
									  ,@p_LV_MGMT_ID           NVARCHAR(32)     = NULL      
									  ,@p_PARENT_ITEM_LV_ID    NVARCHAR(32)     = NULL   -- cast(@p_SEQ AS int)   AS  SEQ
									  ,@p_SEQ                  INT				= NULL  
									  ,@p_ACTV_YN              CHAR(1)          = NULL  
									  ,@p_DEL_YN               CHAR(1)          = NULL  
									  ,@p_USER_ID              NVARCHAR(100)      
									  ,@p_ATTR_01			   NVARCHAR(100)
									  ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'  OUTPUT
									  ,@P_RT_MSG            NVARCHAR(4000) = ''		 OUTPUT									       
					                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
	   ,@P_ERR_STATUS_02 INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''
	    
	   ,@V_ID					NVARCHAR(32)	= NULL
	   ,@V_ITEM_LV_CD        	NVARCHAR(100)	= NULL
	   ,@V_ITEM_LV_NM        	NVARCHAR(240)	= NULL
	   ,@V_LV_MGMT_ID        	NVARCHAR(32)	= NULL
	   ,@V_PARENT_ITEM_LV_ID 	NVARCHAR(32)	= NULL
	   ,@V_SEQ               	INT				= NULL
	   ,@V_ACTV_YN           	NVARCHAR(1)		= NULL
	   ,@V_DEL_YN            	NVARCHAR(1)		= NULL
	   ,@V_USER_ID           	NVARCHAR(100)
	   ,@V_ATTR_01				NVARCHAR(100)

	   SET @V_ID				= @p_ID                
	   SET @V_ITEM_LV_CD       	= @p_ITEM_LV_CD        
	   SET @V_ITEM_LV_NM       	= @p_ITEM_LV_NM        
	   SET @V_LV_MGMT_ID       	= @p_LV_MGMT_ID        
	   SET @V_PARENT_ITEM_LV_ID	= @p_PARENT_ITEM_LV_ID 
	   SET @V_SEQ              	= @p_SEQ               
	   SET @V_ACTV_YN          	= @p_ACTV_YN           
	   SET @V_DEL_YN           	= @p_DEL_YN            
	   SET @V_USER_ID          	= @p_USER_ID           
	   SET @V_ATTR_01			= @p_ATTR_01			

BEGIN TRY

/******************************************************************************************************************************************************************************************/

-- IF(LTRIM(RTRIM(@V_ITEM_LV_CD)) = '')		 SET @V_ITEM_LV_CD = NULL
--IF(LTRIM(RTRIM(@V_ITEM_LV_NM)) = '')		 SET @V_ITEM_LV_NM = NULL
--IF(LTRIM(RTRIM(@V_LV_MGMT_ID)) = '')		 SET @V_LV_MGMT_ID = NULL
--IF(LTRIM(RTRIM(@V_PARENT_ITEM_LV_ID)) = '') SET @V_PARENT_ITEM_LV_ID = NULL

IF(@V_ITEM_LV_CD = '' OR @V_ITEM_LV_CD = NULL)
BEGIN
	   SET @P_ERR_MSG = 'MSG_5037' 
	   RAISERROR (@P_ERR_MSG,12, 1);
END
SELECT @P_ERR_STATUS = COUNT(*)
  FROM TB_CM_ITEM_LEVEL_MGMT
 WHERE 1=1
   AND ITEM_LV_CD = @V_ITEM_LV_CD
   AND ID != @V_ID;
IF ( @P_ERR_STATUS > 0 )
BEGIN
	SET @P_ERR_MSG = 'MSG_0013'
	RAISERROR (@P_ERR_MSG,12, 1);
END
IF (@V_LV_MGMT_ID = '' OR @V_LV_MGMT_ID = NULL)
BEGIN
	   SET @P_ERR_MSG = 'MSG_5032' 
	   RAISERROR (@P_ERR_MSG,12, 1);
END

--IF EXISTS(
--SELECT *
--  FROM TB_CM_ITEM_LEVEL_MGMT
-- WHERE 1=1
--   AND ITEM_LV_CD = @V_ITEM_LV_CD
--   AND ID != @V_ID
--	     )
--		 BEGIN
--			   SET @P_ERR_MSG = 'MSG_0013' 
--			   RAISERROR (@P_ERR_MSG,12, 1);
--		 END


       SELECT @P_ERR_STATUS = SEQ
         FROM TB_CM_LEVEL_MGMT 
        WHERE 1=1
          AND ID = @V_LV_MGMT_ID
		  ;

   SELECT @P_ERR_STATUS_02 = MIN(SEQ) 
     FROM TB_CM_LEVEL_MGMT
    WHERE 1=1
      AND ACTV_YN = 'Y'
      AND ISNULL(DEL_YN,'N') = 'N'
      AND SALES_LV_YN = 'N'
      AND ACCOUNT_LV_YN = 'N'
	  ;
/* 가장 최상위의 ITEM LEVEL이면 상위품목레벨코드 = NULL */
IF (@P_ERR_STATUS = @P_ERR_STATUS_02 AND ISNULL(@V_PARENT_ITEM_LV_ID, '') != '')
    BEGIN
	   SET @P_ERR_MSG = '상위품목레벨이 비어야 합니다.' 
	   RAISERROR (@P_ERR_MSG,12, 1);
	END
/* 가장 최상위의 ITEM LEVEL이 아니면 상위품목레벨코드 != NULL */
IF (@P_ERR_STATUS != @P_ERR_STATUS_02 AND ISNULL(@V_PARENT_ITEM_LV_ID,'') ='')
    BEGIN
	   SET @P_ERR_MSG = 'MSG_5051' 
	   RAISERROR (@P_ERR_MSG,12, 1);
	END
IF (RTRIM(@V_PARENT_ITEM_LV_ID) ='')
	BEGIN
		SET @V_PARENT_ITEM_LV_ID = NULL;
	END
	;
	  -- 프로시저 시작 
	  /*
	           -- 1. Loop 확인 
               -- @p_PARENT_ITEM_LV_CD  이 있을 경우 ITEM_LV 보다 상위 레벨인지 확인 

			   SET @p_LV = (
						   SELECT    L1.SEQ
						   FROM      (
									 SELECT     'A'       AS GB
											 ,  '10D51'   AS ITEM_LV_CD
											 , 'LEVEL2'   AS ITEM_LV
									 ) SRC 
									 LEFT OUTER JOIN  TB_DP_LEVEL_MANAGEMENT L1
									 ON L1.LV_TP = 'I'  
									 AND SRC.ITEM_LV = L1.LV_CD 
						    ) 

			   SET @p_PARENT_LV = (
						   SELECT    L1.SEQ
						   FROM      (
									  SELECT    'B'       AS GB
    								            , 'C11200'   AS ITEM_LV_CD
									            , (SELECT L2.ITEM_LV FROM TB_DP_ITEM_LEVEL L2 WHERE L2.ITEM_LV_CD = 'C11200') AS ITEM_LV  -- ENGINE
									 ) SRC 
									 LEFT OUTER JOIN  TB_DP_LEVEL_MANAGEMENT L1
									 ON L1.LV_TP = 'I'  
									 AND SRC.ITEM_LV = L1.LV_CD 
						    ) 

             --@p_PARENT_LV 값이 없으면 최상위 LEVEL 이므로 PASS 
			 IF  @p_PARENT_LV IS NOT NULL AND @p_LV - @p_PARENT_LV > 1  
			 GOTO SKIPED; 

			 */




			    -- 2. 저장
				MERGE TB_CM_ITEM_LEVEL_MGMT TGT
				USING ( 
						SELECT 
						      @V_ID                   AS ID               
							 ,@V_ITEM_LV_CD           AS ITEM_LV_CD       
							 ,@V_ITEM_LV_NM           AS ITEM_LV_NM       
							 ,@V_LV_MGMT_ID           AS LV_MGMT_ID       
							 ,@V_PARENT_ITEM_LV_ID    AS PARENT_ITEM_LV_ID
							 ,@V_SEQ				  AS SEQ   
							 ,@V_ACTV_YN              AS ACTV_YN
							 ,ISNULL(@V_DEL_YN,'N')   AS DEL_YN
                             ,@V_USER_ID              AS  USER_ID
							 ,@V_ATTR_01			  AS ATTR_01
					  ) SRC
				ON     TGT.ID = SRC.ID
				WHEN MATCHED THEN
					 UPDATE 
					   SET   TGT.ITEM_LV_CD           = SRC.ITEM_LV_CD       
							,TGT.ITEM_LV_NM           = SRC.ITEM_LV_NM       
							,TGT.LV_MGMT_ID           = SRC.LV_MGMT_ID        
							,TGT.PARENT_ITEM_LV_ID    = SRC.PARENT_ITEM_LV_ID        
							,TGT.SEQ                  = SRC.SEQ   
							,TGT.ACTV_YN              = SRC.ACTV_YN
							,TGT.DEL_YN               = SRC.DEL_YN
							,TGT.MODIFY_BY            = SRC.USER_ID       
							,TGT.MODIFY_DTTM          = GETDATE()       
							,TGT.ATTR_01			  = SRC.ATTR_01
				WHEN NOT MATCHED THEN 
					 INSERT (
							  ID               
							, ITEM_LV_CD       
							, ITEM_LV_NM       
							, LV_MGMT_ID       
							, PARENT_ITEM_LV_ID
							, SEQ   
							, ACTV_YN
							, DEL_YN
							, CREATE_BY
							, CREATE_DTTM
							, ATTR_01
							) 
					 VALUES (
							  SRC.ID --(SELECT REPLACE(NEWID(),'-','') )
							, SRC.ITEM_LV_CD       
							, SRC.ITEM_LV_NM       
							, SRC.LV_MGMT_ID       
							, SRC.PARENT_ITEM_LV_ID
							, SRC.SEQ   
							, SRC.ACTV_YN
							, 'N'      -- DEL_YN
							, SRC.USER_ID
							, GETDATE()
							, SRC.ATTR_01
 							) 
							;    	
							
	         
	   SET @P_RT_ROLLBACK_FLAG = 'true'

	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;

go

