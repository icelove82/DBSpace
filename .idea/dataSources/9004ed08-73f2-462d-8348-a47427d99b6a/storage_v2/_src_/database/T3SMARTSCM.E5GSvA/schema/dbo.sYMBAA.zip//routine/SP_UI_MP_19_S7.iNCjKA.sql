CREATE PROCEDURE [dbo].[SP_UI_MP_19_S7] (
     @P_ID				    CHAR(32) = ''
    ,@P_DMND_OVERVIEW_ID	CHAR(32) = ''
    ,@P_WIP_MST_ID		    CHAR(32) = ''
	,@P_WIP_QTY				INT = ''
    ,@P_QTY			        INT = ''
    ,@P_ASSIGN_YN           CHAR(1) = ''
    ,@P_ACTV_YN				CHAR(1) = ''
	,@P_USER_ID				NVARCHAR(100) = ''
	,@P_RT_ROLLBACK_FLAG	NVARCHAR(10) = 'true'   OUTPUT
	,@P_RT_MSG				NVARCHAR(4000) = ''     OUTPUT
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE
	@P_ERR_STATUS INT = 0 ,
	@P_ERR_MSG  NVARCHAR(4000) = '',
	@V_ORG_QTY DECIMAL(20,3) = NULL

BEGIN TRY
	IF @P_WIP_MST_ID IS NOT NULL
	BEGIN
		SET @P_ERR_MSG = 'MSG_5143'
		IF (@P_QTY > @P_WIP_QTY) RAISERROR (@P_ERR_MSG,12, 1);

		MERGE INTO TB_MP_DEMAND_WIP_ASSIGN A
			USING ( SELECT @P_ID AS ID ) B
			ON ( A.ID = B.ID )
			WHEN MATCHED THEN
				UPDATE 
				SET   A.QTY                  = @P_QTY
					, A.ASSIGN_YN            = @P_ASSIGN_YN
					, A.ACTV_YN              = @P_ACTV_YN
					, A.MODIFY_BY            = @P_USER_ID
					, A.MODIFY_DTTM          = GETDATE()
			WHEN NOT MATCHED THEN 
				INSERT ( 
							ID
						, DMND_OVERVIEW_ID
						, WIP_MST_ID
						, QTY
						, ASSIGN_YN
						, ACTV_YN             
						, CREATE_BY	
						, CREATE_DTTM	
						) 
				VALUES (
						REPLACE(NEWID(),'-','')
						, @P_DMND_OVERVIEW_ID
						, @P_WIP_MST_ID
						, @P_QTY
						, @P_ASSIGN_YN
						, @P_ACTV_YN
						, @P_USER_ID
						, GETDATE()
						);

		SET @P_RT_ROLLBACK_FLAG = 'true'
		SET @P_RT_MSG = 'MSG_0001'
	END

END TRY

BEGIN CATCH
	IF(ERROR_MESSAGE() LIKE 'MSG_%')
		BEGIN
			SET @P_ERR_MSG = ERROR_MESSAGE()
			SET @P_RT_ROLLBACK_FLAG = 'false'
			SET @P_RT_MSG = @P_ERR_MSG
		END
	ELSE
		THROW
END CATCH

go

