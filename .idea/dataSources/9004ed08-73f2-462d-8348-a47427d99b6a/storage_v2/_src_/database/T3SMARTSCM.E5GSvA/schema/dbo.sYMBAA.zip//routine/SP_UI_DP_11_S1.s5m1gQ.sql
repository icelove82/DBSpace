/*****************************************************************************
Title : SP_DP_11_S1
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP Account Master
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2019.04.29 / 김소희 / 필수값 validation 추가 
- 2020.01.23 / 김소희 / Currency 필수값 validation
- 2020.12.03 / 김소희 / make entry data
*****************************************************************************/




CREATE PROCEDURE [dbo].[SP_UI_DP_11_S1]  (
                                       @p_ID                  NVARCHAR(32)     = ''         
                                      ,@p_ACCOUNT_CD          NVARCHAR(30)     = ''         
									  ,@p_ACCOUNT_NM          NVARCHAR(240)    = ''         
									  ,@p_PARENT_SALES_LV_ID  NVARCHAR(32)     = ''      
									  ,@p_PARENT_SALES_LV_ID_AD1  NVARCHAR(32)     = ''      
									  ,@p_PARENT_SALES_LV_ID_AD2  NVARCHAR(32)     = ''      
									  ,@p_PARENT_SALES_LV_ID_AD3  NVARCHAR(32)     = ''      
									  ,@p_CURCY_CD_ID         NVARCHAR(32)     = ''      
									  ,@p_COUNTRY_ID          NVARCHAR(32)     = ''      
									  ,@p_CHANNEL_ID          NVARCHAR(32)     = ''      
									  ,@p_SOLD_TO_ID          NVARCHAR(32)     = ''      
									  ,@p_SHIP_TO_ID          NVARCHAR(32)    = ''      
									  ,@p_BILL_TO_ID          NVARCHAR(32)    = ''      
									  ,@p_INCOTERMS_ID        NVARCHAR(32)    = ''      
									  ,@p_SRP_YN              CHAR(1)         = ''      
									  ,@p_VMI_YN              CHAR(1)         = ''      
									  ,@p_DIRECT_SHPP_YN  CHAR(1)         = ''      
									  ,@p_ACTV_YN             CHAR(1)         = ''
									  ,@p_PRIORT              INT        = ''									  
									  ,@p_ATTR_01             NVARCHAR(100)       = '' 
			                          ,@p_ATTR_02			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_03			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_04			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_05			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_06			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_07			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_08			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_09			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_10			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_11			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_12			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_13			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_14			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_15			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_16			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_17			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_18			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_19			  NVARCHAR(100)       = ''
			                          ,@p_ATTR_20			  NVARCHAR(100)       = ''
									  ,@p_DEL_YN              CHAR(1)         = ''      
									  ,@p_USER_ID             NVARCHAR(50)    = ''    
									  ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'  OUTPUT
									  ,@P_RT_MSG            NVARCHAR(4000) = ''		OUTPUT
									    
				                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE  
	     @P_ERR_STATUS INT = 0
        ,@P_ERR_MSG NVARCHAR(4000)=''

		,@V_ID                  NVARCHAR(32)     = ''   
		,@V_ACCOUNT_CD          NVARCHAR(30)     = ''   
		,@V_ACCOUNT_NM          NVARCHAR(240)    = ''   
		,@V_PARENT_SALES_LV_ID  NVARCHAR(32)     = ''   
		,@V_PARENT_SALES_LV_ID_AD1  NVARCHAR(32)     = ''   
		,@V_PARENT_SALES_LV_ID_AD2  NVARCHAR(32)     = ''   
		,@V_PARENT_SALES_LV_ID_AD3  NVARCHAR(32)     = ''   
		,@V_CURCY_CD_ID         NVARCHAR(32)     = ''   
		,@V_COUNTRY_ID          NVARCHAR(32)     = ''   
		,@V_CHANNEL_ID          NVARCHAR(32)     = ''   
		,@V_SOLD_TO_ID          NVARCHAR(32)     = ''   
		,@V_SHIP_TO_ID          NVARCHAR(32)    = ''    
		,@V_BILL_TO_ID          NVARCHAR(32)    = ''    
		,@V_INCOTERMS_ID        NVARCHAR(32)    = ''    
		,@V_SRP_YN              CHAR(1)         = ''    
		,@V_VMI_YN              CHAR(1)         = ''    
		,@V_DIRECT_SHPP_YN		CHAR(1)         = ''      
		,@V_ACTV_YN             CHAR(1)         = ''
		,@V_PRIORT  			INT				= 0
		,@V_ATTR_01             NVARCHAR(100)       = ''
		,@V_ATTR_02				NVARCHAR(100)       = ''
		,@V_ATTR_03				NVARCHAR(100)       = ''
		,@V_ATTR_04				NVARCHAR(100)       = ''
		,@V_ATTR_05				NVARCHAR(100)       = ''
		,@V_ATTR_06				NVARCHAR(100)       = ''
		,@V_ATTR_07				NVARCHAR(100)       = ''
		,@V_ATTR_08				NVARCHAR(100)       = ''
		,@V_ATTR_09				NVARCHAR(100)       = ''
		,@V_ATTR_10				NVARCHAR(100)       = ''
		,@V_ATTR_11				NVARCHAR(100)       = ''
		,@V_ATTR_12				NVARCHAR(100)       = ''
		,@V_ATTR_13				NVARCHAR(100)       = ''
		,@V_ATTR_14				NVARCHAR(100)       = ''
		,@V_ATTR_15				NVARCHAR(100)       = ''
		,@V_ATTR_16				NVARCHAR(100)       = ''
		,@V_ATTR_17				NVARCHAR(100)       = ''
		,@V_ATTR_18				NVARCHAR(100)       = ''
		,@V_ATTR_19				NVARCHAR(100)       = ''
		,@V_ATTR_20				NVARCHAR(100)       = ''
		,@V_DEL_YN              CHAR(1)         = ''    
		,@V_USER_ID             NVARCHAR(50)    = ''    

SET @V_ID					= @p_ID                
SET @V_ACCOUNT_CD			= @p_ACCOUNT_CD        
SET @V_ACCOUNT_NM			= @p_ACCOUNT_NM        
SET @V_PARENT_SALES_LV_ID	= @p_PARENT_SALES_LV_ID
SET @V_PARENT_SALES_LV_ID_AD1	= @p_PARENT_SALES_LV_ID_AD1
SET @V_PARENT_SALES_LV_ID_AD2	= @p_PARENT_SALES_LV_ID_AD2
SET @V_PARENT_SALES_LV_ID_AD3	= @p_PARENT_SALES_LV_ID_AD3
SET @V_CURCY_CD_ID			= @p_CURCY_CD_ID       
SET @V_COUNTRY_ID			= @p_COUNTRY_ID        
SET @V_CHANNEL_ID			= @p_CHANNEL_ID        
SET @V_SOLD_TO_ID			= @p_SOLD_TO_ID        
SET @V_SHIP_TO_ID			= @p_SHIP_TO_ID        
SET @V_BILL_TO_ID			= @p_BILL_TO_ID        
SET @V_INCOTERMS_ID			= @p_INCOTERMS_ID      
SET @V_SRP_YN				= @p_SRP_YN            
SET @V_VMI_YN				= @p_VMI_YN            
SET @V_DIRECT_SHPP_YN		= @p_DIRECT_SHPP_YN
SET @V_ACTV_YN				= @p_ACTV_YN   
SET @V_PRIORT				= @p_PRIORT
SET @V_ATTR_01				= @p_ATTR_01           
SET @V_ATTR_02				= @p_ATTR_02			
SET @V_ATTR_03				= @p_ATTR_03			
SET @V_ATTR_04				= @p_ATTR_04			
SET @V_ATTR_05				= @p_ATTR_05			
SET @V_ATTR_06				= @p_ATTR_06			
SET @V_ATTR_07				= @p_ATTR_07			
SET @V_ATTR_08				= @p_ATTR_08			
SET @V_ATTR_09				= @p_ATTR_09			
SET @V_ATTR_10				= @p_ATTR_10			
SET @V_ATTR_11				= @p_ATTR_11			
SET @V_ATTR_12				= @p_ATTR_12			
SET @V_ATTR_13				= @p_ATTR_13			
SET @V_ATTR_14				= @p_ATTR_14			
SET @V_ATTR_15				= @p_ATTR_15			
SET @V_ATTR_16				= @p_ATTR_16			
SET @V_ATTR_17				= @p_ATTR_17			
SET @V_ATTR_18				= @p_ATTR_18			
SET @V_ATTR_19				= @p_ATTR_19			
SET @V_ATTR_20				= @p_ATTR_20			
SET @V_DEL_YN				= @p_DEL_YN            
SET @V_USER_ID				= @p_USER_ID           

BEGIN TRY


		IF(LTRIM(RTRIM(@V_PARENT_SALES_LV_ID)) = '' OR @V_PARENT_SALES_LV_ID IS NULL)
		BEGIN
		   SET @P_ERR_MSG = 'MSG_5046' 
		   RAISERROR (@P_ERR_MSG,12, 1);			
		END
 		--IF(EXISTS(SELECT * FROM TB_DP_ACCOUNT_MST WHERE ACCOUNT_CD = @V_ACCOUNT_CD AND ID != @V_ID))
 		--BEGIN
 		--   SET @P_ERR_MSG = 'MSG_0013' 
 		--   RAISERROR (@P_ERR_MSG,12, 1);			
 		--END
		IF(ISNULL(@V_ACCOUNT_CD,'') ='')
			BEGIN
				SET @P_ERR_MSG = 'Account Code is empty'
				RAISERROR (@P_ERR_MSG,12, 1)
			END
		IF(ISNULL(@V_ACCOUNT_NM,'') ='')
			BEGIN
				SET @P_ERR_MSG = 'Account Name is empty'
				RAISERROR (@P_ERR_MSG,12, 1)
			END
		IF(ISNULL(@V_CURCY_CD_ID,'') ='')
			BEGIN
				SET @P_ERR_MSG = 'Currency code is empty'
				RAISERROR (@P_ERR_MSG,12, 1)
			END

		SELECT @P_ERR_STATUS = COUNT(*)
		  FROM TB_DP_ACCOUNT_MST
		 WHERE 1=1
		   AND ACCOUNT_CD = @V_ACCOUNT_CD
		   AND ID != @V_ID
		   ;
		IF ( @P_ERR_STATUS > 0 )
			BEGIN
				SET @p_ERR_MSG = 'MSG_0013'
				RAISERROR(@P_ERR_MSG,12,1)
			END


	  -- 프로시저 시작 

				MERGE [TB_DP_ACCOUNT_MST] TGT
				USING ( 
						SELECT   @V_ID                  AS  ID                         
                                ,@V_ACCOUNT_CD          AS  ACCOUNT_CD                 
								,@V_ACCOUNT_NM          AS  ACCOUNT_NM                 
								,@V_PARENT_SALES_LV_ID  AS  PARENT_SALES_LV_ID      
								,@V_PARENT_SALES_LV_ID_AD1  AS  PARENT_SALES_LV_ID_AD1      
								,@V_PARENT_SALES_LV_ID_AD2  AS  PARENT_SALES_LV_ID_AD2      
								,@V_PARENT_SALES_LV_ID_AD3  AS  PARENT_SALES_LV_ID_AD3      
								,@V_CURCY_CD_ID         AS  CURCY_CD_ID             
								,@V_COUNTRY_ID          AS  COUNTRY_ID              
								,@V_CHANNEL_ID          AS  CHANNEL_ID              
								,@V_SOLD_TO_ID          AS  SOLD_TO_ID              
								,@V_SHIP_TO_ID          AS  SHIP_TO_ID             
								,@V_BILL_TO_ID          AS  BILL_TO_ID             
								,@V_INCOTERMS_ID        AS  INCOTERMS_ID           
								,@V_SRP_YN              AS  SRP_YN                 
								,@V_VMI_YN              AS  VMI_YN                 
								,@V_DIRECT_SHPP_YN  AS  DIRECT_SHPP_YN     
								,@V_ACTV_YN             AS  ACTV_YN
								,@V_PRIORT				AS  PRIORT
								,@V_ATTR_01             AS  ATTR_01            
			                    ,@V_ATTR_02			  	AS  ATTR_02			  
			                    ,@V_ATTR_03			  	AS  ATTR_03			  
			                    ,@V_ATTR_04			  	AS  ATTR_04			  
			                    ,@V_ATTR_05			  	AS  ATTR_05			  
			                    ,@V_ATTR_06			  	AS  ATTR_06			  
			                    ,@V_ATTR_07			  	AS  ATTR_07			  
			                    ,@V_ATTR_08			  	AS  ATTR_08			  
			                    ,@V_ATTR_09			  	AS  ATTR_09			  
			                    ,@V_ATTR_10			  	AS  ATTR_10			  
			                    ,@V_ATTR_11			  	AS  ATTR_11			  
			                    ,@V_ATTR_12			  	AS  ATTR_12			  
			                    ,@V_ATTR_13			  	AS  ATTR_13			  
			                    ,@V_ATTR_14			  	AS  ATTR_14			  
			                    ,@V_ATTR_15			  	AS  ATTR_15			  
			                    ,@V_ATTR_16			  	AS  ATTR_16			  
			                    ,@V_ATTR_17			  	AS  ATTR_17			  
			                    ,@V_ATTR_18			  	AS  ATTR_18			  
			                    ,@V_ATTR_19			  	AS  ATTR_19			  
			                    ,@V_ATTR_20			  	AS  ATTR_20			  
								,@V_DEL_YN              AS  DEL_YN                 
								,@V_USER_ID             AS  USER_ID               
					  ) SRC
				ON     TGT.ID = SRC.ID
				WHEN MATCHED THEN
					 UPDATE 
					   SET    TGT.ACCOUNT_CD          = SRC.ACCOUNT_CD         
							, TGT.ACCOUNT_NM          = SRC.ACCOUNT_NM         
							, TGT.PARENT_SALES_LV_ID  = SRC.PARENT_SALES_LV_ID 
							, TGT.PARENT_SALES_LV_ID_AD1  = SRC.PARENT_SALES_LV_ID_AD1      
							, TGT.PARENT_SALES_LV_ID_AD2  =  SRC.PARENT_SALES_LV_ID_AD2      
							, TGT.PARENT_SALES_LV_ID_AD3  =  SRC.PARENT_SALES_LV_ID_AD3      
							, TGT.CURCY_CD_ID         = SRC.CURCY_CD_ID        
							, TGT.COUNTRY_ID          = SRC.COUNTRY_ID         
							, TGT.CHANNEL_ID          = SRC.CHANNEL_ID         
							, TGT.SOLD_TO_ID          = SRC.SOLD_TO_ID         
							, TGT.SHIP_TO_ID          = SRC.SHIP_TO_ID         
							, TGT.BILL_TO_ID          = SRC.BILL_TO_ID         
							, TGT.INCOTERMS_ID        = SRC.INCOTERMS_ID       
							, TGT.SRP_YN              = SRC.SRP_YN             
							, TGT.VMI_YN              = SRC.VMI_YN             
							, TGT.DIRECT_SHPP_YN  = SRC.DIRECT_SHPP_YN 
							, TGT.ACTV_YN             = SRC.ACTV_YN
							, TGT.PRIORT              = SRC.PRIORT
							, TGT.ATTR_01             = SRC.ATTR_01            
							, TGT.ATTR_02			  = SRC.ATTR_02			  
							, TGT.ATTR_03			  = SRC.ATTR_03			  
							, TGT.ATTR_04			  = SRC.ATTR_04			  
							, TGT.ATTR_05			  = SRC.ATTR_05			  
							, TGT.ATTR_06			  = SRC.ATTR_06			  
							, TGT.ATTR_07			  = SRC.ATTR_07			  
							, TGT.ATTR_08			  = SRC.ATTR_08			  
							, TGT.ATTR_09			  = SRC.ATTR_09			  
							, TGT.ATTR_10			  = SRC.ATTR_10			  
							, TGT.ATTR_11			  = SRC.ATTR_11			  
							, TGT.ATTR_12			  = SRC.ATTR_12			  
							, TGT.ATTR_13			  = SRC.ATTR_13			  
							, TGT.ATTR_14			  = SRC.ATTR_14			  
							, TGT.ATTR_15			  = SRC.ATTR_15			  
							, TGT.ATTR_16			  = SRC.ATTR_16			  
							, TGT.ATTR_17			  = SRC.ATTR_17			  
							, TGT.ATTR_18			  = SRC.ATTR_18			  
							, TGT.ATTR_19			  = SRC.ATTR_19			  
							, TGT.ATTR_20			  = SRC.ATTR_20			  
							, TGT.DEL_YN              = SRC.DEL_YN             
							, TGT.MODIFY_BY           = SRC.USER_ID       
							, TGT.MODIFY_DTTM         = GETDATE()       
				WHEN NOT MATCHED THEN 
					 INSERT (
					              ID                 
								, ACCOUNT_CD         
								, ACCOUNT_NM         
								, PARENT_SALES_LV_ID 
								, PARENT_SALES_LV_ID_AD1 
								, PARENT_SALES_LV_ID_AD2 
								, PARENT_SALES_LV_ID_AD3 
								, CURCY_CD_ID        
								, COUNTRY_ID         
								, CHANNEL_ID         
								, SOLD_TO_ID         
								, SHIP_TO_ID         
								, BILL_TO_ID         
								, INCOTERMS_ID       
								, SRP_YN             
								, VMI_YN             
								, DIRECT_SHPP_YN 
								, ACTV_YN
								, PRIORT
								, ATTR_01            
								, ATTR_02			  
								, ATTR_03			  
								, ATTR_04			  
								, ATTR_05			  
								, ATTR_06			  
								, ATTR_07			  
								, ATTR_08			  
								, ATTR_09			  
								, ATTR_10			  
								, ATTR_11			  
								, ATTR_12			  
								, ATTR_13			  
								, ATTR_14			  
								, ATTR_15			  
								, ATTR_16			  
								, ATTR_17			  
								, ATTR_18			  
								, ATTR_19			  
								, ATTR_20			  
								, DEL_YN             
							    , CREATE_BY
							    , CREATE_DTTM
							) 
					 VALUES (
                                  SRC.ID -- (SELECT REPLACE(NEWID(),'-','') )
								, SRC.ACCOUNT_CD         
								, SRC.ACCOUNT_NM         
								, SRC.PARENT_SALES_LV_ID 
								, SRC.PARENT_SALES_LV_ID_AD1 
								, SRC.PARENT_SALES_LV_ID_AD2 
								, SRC.PARENT_SALES_LV_ID_AD3 
								, SRC.CURCY_CD_ID        
								, SRC.COUNTRY_ID         
								, SRC.CHANNEL_ID         
								, SRC.SOLD_TO_ID         
								, SRC.SHIP_TO_ID         
								, SRC.BILL_TO_ID         
								, SRC.INCOTERMS_ID       
								, SRC.SRP_YN             
								, SRC.VMI_YN             
								, SRC.DIRECT_SHPP_YN 
								, SRC.ACTV_YN  
								, SRC.PRIORT
								, SRC.ATTR_01            
								, SRC.ATTR_02			  
								, SRC.ATTR_03			  
								, SRC.ATTR_04			  
								, SRC.ATTR_05			  
								, SRC.ATTR_06			  
								, SRC.ATTR_07			  
								, SRC.ATTR_08			  
								, SRC.ATTR_09			  
								, SRC.ATTR_10			  
								, SRC.ATTR_11			  
								, SRC.ATTR_12			  
								, SRC.ATTR_13			  
								, SRC.ATTR_14			  
								, SRC.ATTR_15			  
								, SRC.ATTR_16			  
								, SRC.ATTR_17			  
								, SRC.ATTR_18			  
								, SRC.ATTR_19			  
								, SRC.ATTR_20			  
								, 'N' --SRC.DEL_YN      
							    , SRC.USER_ID 
							    , GETDATE()            
 							) 
							;    	
							
							
	  -- 프로시저 종료 
	/********************************************************************************************************************************************
		-- Make Entry data
	********************************************************************************************************************************************/

	DECLARE @TB_VERSION TABLE ( ID CHAR(32)) 
	DECLARE @CUR_VER_ID CHAR(32) 
	INSERT INTO @TB_VERSION (ID) 
	SELECT VER_ID
	  FROM ( 
			SELECT M.ID AS VER_ID
				 , DENSE_RANK () OVER (PARTITION BY M.PLAN_TP_ID ORDER BY M.CREATE_DTTM DESC) AS RW 
			  FROM TB_DP_CONTROL_BOARD_VER_MST M
				   INNER JOIN 
				   TB_DP_CONTROL_bOARD_VER_DTL D
				ON M.ID = D.CONBD_VER_MST_ID 
				   INNER JOIN 
				   TB_CM_COMM_CONFIG W
				ON W.ID = D.WORK_TP_ID
			   AND W.CONF_CD = 'CL'
				   INNER JOIN 
				   TB_CM_COMM_CONFIG C
				ON D.CL_STATUS_ID = C.ID
			   AND C.CONF_CD != 'CLOSE' 
			 WHERE EXISTS (SELECT DISTINCT VER_ID FROM TB_DP_ENTRY WHERE VER_ID = M.ID) 
		    ) A
	WHERE RW = 1  
	  AND @V_DEL_YN = 'N' AND @V_ACTV_YN = 'Y'
	DECLARE ACCT_CUR CURSOR FAST_FORWARD LOCAL
	FOR SELECT ID FROM @TB_VERSION
	READONLY
	;

	OPEN ACCT_CUR
    FETCH NEXT FROM ACCT_CUR INTO @CUR_VER_ID 
	;
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
--			SELECT *
--			 FROM @TB_VERSION
--			 WHERE ID = @CUR_VER_ID 
			-- Cursor로 나온 Version ID의 새로운 데이터 중복 여부 판별
			 IF NOT EXISTS
			 (  SELECT 1 
				 FROM TB_DP_ENTRY 
				WHERE VER_ID = @CUR_VER_ID
				  AND ACCOUNT_ID = @V_ID				  
			 )
			 BEGIN
			   EXECUTE dbo.SP_UI_DP_93_ITEM_ACCT_CREATE 
						 @P_ITEM_MST_ID		= NULL   		-- Item Account User Map / Item Master 
						,@P_ITEM_LV_ID		= NULL		
						,@P_ACCOUNT_ID		= @V_ID				-- Item Account User Map / Account Master 
						,@P_ACCT_LV_ID		= NULL    	
						,@P_USER_ID			= NULL			-- Mapping data
						,@P_AUTH_TP_ID		= NULL		
						,@P_VER_ID			= @CUR_VER_ID 	
						;   
			END
			  FETCH NEXT FROM ACCT_CUR INTO @CUR_VER_ID
		END 
	   ;

		CLOSE ACCT_CUR
		DEALLOCATE ACCT_CUR 
		;		              
	   SET @P_RT_ROLLBACK_FLAG = 'true'

	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE()= @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END
	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;



go

