CREATE PROCEDURE [dbo].[SP_DP_MAKE_EX_MEASURE] (
	@P_STRT_DATE		 DATE
  ,	@P_END_DATE			 DATE
  , @P_BUCKET			 NVARCHAR(2)
  , @P_DATA_TP			 CHAR(4)		= 'EXAM'	
  , @P_DEL_YN			 CHAR(1)		= 'Y'  
  , @P_USER_ID			 NVARCHAR(100)  = 'admin'
  , @P_UI_ID			NVARCHAR(100)
  , @P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'    OUTPUT
  , @P_RT_MSG            NVARCHAR(4000) = ''		OUTPUT
)
AS 
/*
	[SP_DP_MAKE_EX_MEASURE] 프로시저 정리 프로시저
	- create by : kim sohee
	- create datetime  : 2019 10 15
	- 고정 범위 0부터 45사이의 랜덤 값 생성
	- 기준 날짜 값을 갖고 Config 데이터를 활용하여 날짜 범위 생성
	- mapping정보가 있는 Item, account만 생성
	- amount는 qty*1000

	- history ( date / writer / comment)
	- 2019.10.15 / ksh / create only mapping data
	- 2019.11.11 / ksh / dynamically creating
*/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON;
DECLARE @P_QTY_COL_NM NVARCHAR(4000)
	  , @P_AMT_SQL NVARCHAR(4000)
	  , @P_COL_CNT INT
	  , @P_SQL    NVARCHAR(4000);
-- For ANNUAL_DP 
DECLARE @P_MM_BUKT		 NVARCHAR(2)
	   ,@P_YY_BUKT		 NVARCHAR(2)
	   ,@P_YY_VER_ID	 CHAR(32)
	   ,@P_CL_LV_MGMT_ID CHAR(32)
	   ;

DECLARE  
	     @P_ERR_STATUS INT = 0
        ,@P_ERR_MSG NVARCHAR(4000)=''
BEGIN try
/******************************************************************************
	-- 1. Set Config Data (Bucket, Date,....)
******************************************************************************/
 
/******************************************************************************
	-- 2. Find ITEM, ACCOUNT MAPPING
******************************************************************************/
IF(@P_DATA_TP = 'EXAM')
	BEGIN
	/*******************************************************************************
		-- 3. Make Dynamic insert Query (about Quantity)
	******************************************************************************/
		SELECT @P_QTY_COL_NM = STUFF((
									SELECT ','+COLUMN_NAME
									  FROM INFORMATION_SCHEMA.COLUMNS
									 WHERE TABLE_NAME = 'TB_DP_MEASURE_DATA' 
									   AND COLUMN_NAME NOT IN ('ID', 'ITEM_MST_ID', 'ACCOUNT_ID', 'BASE_DATE', 'CREATE_DTTM', 'CREATE_BY', 'MODIFY_DTTM', 'MODIFY_BY')
									   AND COLUMN_NAME LIKE '%_QTY'
									   AND COLUMN_NAME NOT LIKE 'YTD%'
									   AND TABLE_CATALOG =  DB_NAME()
									  FOR XML PATH('')
									),1,1,'') 
		SELECT @P_COL_CNT = COUNT(COLUMN_NAME)
		  FROM INFORMATION_SCHEMA.COLUMNS
		 WHERE TABLE_NAME = 'TB_DP_MEASURE_DATA' 
		   AND COLUMN_NAME NOT IN ('ID', 'ITEM_MST_ID', 'ACCOUNT_ID', 'BASE_DATE', 'CREATE_DTTM', 'CREATE_BY', 'MODIFY_DTTM', 'MODIFY_BY')
		   AND COLUMN_NAME LIKE '%_QTY'
		   AND COLUMN_NAME NOT LIKE 'YTD%'
		   AND TABLE_CATALOG =  DB_NAME()
	SET @P_SQL = 'INSERT INTO TB_DP_MEASURE_DATA ('
				+'ID, ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, CREATE_DTTM, CREATE_BY'
				+','+@P_QTY_COL_NM+')'
				+'SELECT REPLACE(NEWID(),''-'',''''), ITEM_ID, ACCT_ID, DAT, GETDATE(), @P_USER_ID'			
	-- COLUMN 갯수만큼 반복문      ,
	WHILE(@P_COL_CNT>0)
	BEGIN
		SELECT @P_SQL = @P_SQL + ',+CONVERT(NVARCHAR(2),ROUND(RAND(CONVERT(VARBINARY,NEWID()))*50,0)+10)'	
		SET @P_COL_CNT = @P_COL_CNT-1;
	END
	SET @P_SQL = @P_SQL + ' FROM FN_DP_TEMP_ITEM_ACCOUNT_DATE(@p_STRT_DATE, @p_END_DATE, @P_BUCKET)'
	/******************************************************************************
		-- 4. Run Dynamic Insert Query 
	******************************************************************************/
	IF(@P_DEL_YN = 'Y')
	BEGIN
		TRUNCATE TABLE TB_DP_MEASURE_DATA;
	END
	ELSE
	BEGIN
		DELETE FROM TB_DP_MEASURE_DATA
		WHERE BASE_DATE BETWEEN @P_STRT_DATE AND @P_END_DATE
	END
--	SELECT @P_SQL
	EXEC SP_EXECUTESQL @P_SQL, N'@P_STRT_DATE AS DATE, @P_END_DATE AS DATE, @P_BUCKET AS NVARCHAR(2), @P_USER_ID AS NVARCHAR(100)', @P_STRT_DATE, @P_END_DATE, @P_BUCKET, @P_USER_ID


	/******************************************************************************
		-- 6. Make Update Query (about Amount)
	*******************************************************************************/
	--	DECLARE @P_AMT_SQL NVARCHAR(4000)
		SET @P_AMT_SQL = STUFF((
									SELECT ','+COLUMN_NAME+' = '+REPLACE(COLUMN_NAME,'_AMT','_QTY*1000')
									  FROM INFORMATION_SCHEMA.COLUMNS
									 WHERE TABLE_NAME = 'TB_DP_MEASURE_DATA' 
									   AND COLUMN_NAME NOT IN ('ID', 'ITEM_MST_ID', 'ACCOUNT_ID', 'BASE_DATE', 'CREATE_DTTM', 'CREATE_BY', 'MODIFY_DTTM', 'MODIFY_BY')
									   AND COLUMN_NAME LIKE '%_AMT'
									   AND TABLE_CATALOG =  DB_NAME()
									  FOR XML PATH('')
									),1,1,'') 
		SET @P_AMT_SQL = 'UPDATE TB_DP_MEASURE_DATA SET '+@P_AMT_SQL+' WHERE BASE_DATE BETWEEN @p_STRT_DATE AND @P_END_DATE '
--		SELECT @P_AMT_SQL
	EXEC SP_EXECUTESQL @P_AMT_SQL, N'@p_STRT_DATE AS DATE, @p_END_DATE AS DATE', @P_STRT_DATE, @P_END_DATE


	END
-- ELSE 
-- BEGIN END
	/*******************************************************************************
		-- Common
	*******************************************************************************/
--	/******************************************************************************
--		-- 3. Update YTD
--	*******************************************************************************/
--	IF EXISTS(  SELECT COLUMN_NAME
--				  FROM INFORMATION_SCHEMA.COLUMNS
--				 WHERE TABLE_NAME = 'TB_DP_MEASURE_DATA' 
--				   AND COLUMN_NAME = 'YTD_QTY'
--				   AND TABLE_CATALOG =  DB_NAME()
--			) BEGIN		 
--				SELECT @P_STRT_DATE = CONVERT(DATE, CONVERT(CHAR(4), DATEPART(YEAR, @P_STRT_DATE))+'-'+POLICY_VAL+'-1')
--				  FROM TB_DP_PLAN_POLICY PP
--					   INNER JOIN
--					   TB_CM_COMM_CONFIG CF
--					ON PP.POLICY_ID = CF.ID
--				   AND CF.CONF_CD = 'SM'
--					   INNER JOIN
--					   TB_CM_COMM_CONFIG PT
--					ON PP.PLAN_TP_ID = PT.ID
--				   AND PT.ATTR_01 = 'M'
--				   ;
--				   SELECT @P_END_DATE = DATEADD(DAY,-1,DATEADD(YEAR, 1, @P_STRT_DATE))
--					;
--				WITH MM
--				AS (SELECT ITEM_MST_ID, ACCOUNT_ID
--						 , BASE_DATE																				AS STRT_DATE 
--						 , ISNULL(DATEADD(DAY, -1, LEAD(BASE_DATE, 1) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID ORDER BY BASE_dATE ASC)), @P_END_DATE) AS END_DATE  
--					  FROM TB_DP_MEASURE_DATA
--				     WHERE BASE_DATE BETWEEN @P_STRT_DATE AND @P_END_DATE						 
--				), SA
--				AS (
--					SELECT MM.ITEM_MST_ID
--						 , MM.ACCOUNT_ID
--						 , MM.STRT_DATE					AS BASE_DATE 
--						 , ISNULL(SUM(SA.QTY),0)		AS QTY 
--						 , ISNULL(SUM(SA.AMT),0)		AS AMT
--					  FROM MM 
--						   LEFT OUTER JOIN
--						   TB_CM_ACTUAL_SALES SA
--						ON SA.BASE_DATE BETWEEN MM.STRT_DATE AND MM.END_DATE				
--					   AND MM.ITEM_MST_ID = SA.ITEM_MST_ID
--					   AND MM.ACCOUNT_ID = SA.ACCOUNT_ID   				
--					GROUP BY MM.ITEM_MST_ID
--							,MM.ACCOUNT_ID 
--							,MM.STRT_dATE
--				), YTD_SUM
--				AS (
--					SELECT ITEM_MST_ID
--						 , ACCOUNT_ID
--						 , BASE_DATE
--						 -- SO_STATUS_ID
--						 , SUM(QTY) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID, DATEPART(YEAR, BASE_DATE)  ORDER BY BASE_DATE) AS QTY 
--						 , SUM(AMT) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID, DATEPART(YEAR, BASE_DATE)  ORDER BY BASE_DATE) AS AMT 
--					  FROM SA
--					) UPDATE TB_DP_MEASURE_DATA 
--						 SET TB_DP_MEASURE_DATA.YTD_QTY = A.QTY
--							,TB_DP_MEASURE_DATA.YTD_AMT = A.AMT
--						FROM YTD_SUM A
--					WHERE TB_DP_MEASURE_DATA.ITEM_MST_ID  = A.ITEM_MST_ID
--					  AND TB_DP_MEASURE_DATA.ACCOUNT_ID  =  A.ACCOUNT_ID
--					  AND TB_DP_MEASURE_DATA.BASE_DATE   =  A.BASE_DATE 
--				  				 
--			  END
--	IF EXISTS(  SELECT COLUMN_NAME
--				  FROM INFORMATION_SCHEMA.COLUMNS
--				 WHERE TABLE_NAME = 'TB_DP_MEASURE_DATA' 
--				   AND COLUMN_NAME = 'YTD_ANNUAL_QTY'
--				   AND TABLE_CATALOG =  DB_NAME()
--			) AND
--	  EXISTS (
--				SELECT COLUMN_NAME
--				  FROM INFORMATION_SCHEMA.COLUMNS
--				 WHERE TABLE_NAME = 'TB_DP_MEASURE_DATA' 
--				   AND COLUMN_NAME = 'ANNUAL_QTY'
--				   AND TABLE_CATALOG =  DB_NAME()					
--			 )			
--			BEGIN		 
--				SELECT @P_STRT_DATE = CONVERT(DATE, CONVERT(CHAR(4), DATEPART(YEAR, @P_STRT_DATE))+'-'+POLICY_VAL+'-1')
--				  FROM TB_DP_PLAN_POLICY PP
--					   INNER JOIN
--					   TB_CM_COMM_CONFIG CF
--					ON PP.POLICY_ID = CF.ID
--				   AND CF.CONF_CD = 'SM'
--					   INNER JOIN
--					   TB_CM_COMM_CONFIG PT
--					ON PP.PLAN_TP_ID = PT.ID
--				   AND PT.ATTR_01 = 'M'
--				   ;
--				   SELECT @P_END_DATE = DATEADD(DAY,-1,DATEADD(YEAR, 1, @P_STRT_DATE))
--					;
--				WITH YTD_SUM
--				AS (	--SELECT * FROM TB_DP_MEASURE_DATA
--					SELECT ITEM_MST_ID
--						 , ACCOUNT_ID
--						 , BASE_DATE
--						 , SUM(ANNUAL_QTY) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID, DATEPART(YEAR, BASE_DATE)  ORDER BY BASE_DATE) AS QTY 
--						 , SUM(ANNUAL_AMT) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID, DATEPART(YEAR, BASE_DATE)  ORDER BY BASE_DATE) AS AMT 
--					  FROM TB_DP_MEASURE_DATA
--					 WHERE BASE_DATE BETWEEN  @P_STRT_DATE AND @P_END_DATE
--					) UPDATE TB_DP_MEASURE_DATA 
--						 SET TB_DP_MEASURE_DATA.YTD_ANNUAL_QTY = A.QTY
--							,TB_DP_MEASURE_DATA.YTD_ANNUAL_AMT = A.AMT
--						FROM YTD_SUM A
--					WHERE TB_DP_MEASURE_DATA.ITEM_MST_ID  = A.ITEM_MST_ID
--					  AND TB_DP_MEASURE_DATA.ACCOUNT_ID  =  A.ACCOUNT_ID
--					  AND TB_DP_MEASURE_DATA.BASE_DATE   =  A.BASE_DATE 
--					  AND TB_DP_MEASURE_DATA.BASE_DATE BETWEEN @P_STRT_DATE AND @P_END_DATE
--				  				 								
--			  END
--	IF EXISTS (   SELECT COLUMN_NAME
--				  FROM INFORMATION_SCHEMA.COLUMNS
--				 WHERE TABLE_NAME = 'TB_DP_MEASURE_DATA' 
--				   AND COLUMN_NAME = 'ANNUAL_QTY'
--				   AND TABLE_CATALOG =  DB_NAME()					
--			  ) 
--			  BEGIN
--					SELECT TOP 1 @P_MM_BUKT  = BUKT
--								,@P_STRT_DATE = FROM_DATE
--								,@P_END_DATE  = TO_DATE
--					 FROM TB_DP_CONTROL_BOARD_VER_MST
--					WHERE PLAN_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01 = 'M' AND ACTV_YN = 'Y')
--					ORDER BY CREATE_DTTM DESC
--					;
--					SELECT TOP 1 @P_YY_VER_ID = M.ID
--							   , @P_CL_LV_MGMT_ID = CL_LV_MGMT_ID
--					 FROM TB_DP_CONTROL_BOARD_VER_MST M
--						  INNER JOIN
--						  TB_DP_CONTROL_BOARD_VER_DTL D
--					   ON M.ID = D.CONBD_VER_MST_ID
--					  AND D.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP'AND CONF_CD = 'CL')
--					WHERE M.PLAN_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01 = 'Y' AND ACTV_YN = 'Y')	  
--					ORDER BY M.CREATE_DTTM DESC
--					;
--				WITH CA
--				AS (
--					SELECT MIN(DAT)				AS STRT_DATE
--						 , MAX(DAT)				AS END_DATE
--						 , MIN(YYYYMM)			AS YYYYMM
--						 , COUNT(DAT)			AS DAT_CNT
--					  FROM TB_CM_CALENDAR	
--					 WHERE DAT BETWEEN @P_STRT_DATE AND @P_END_DATE 
--				  GROUP BY YYYY
--						 , CASE WHEN @P_MM_BUKT IN ('M', 'PW') THEN MM    ELSE 1 END
--						 , CASE WHEN @P_MM_BUKT IN ('PW', 'W') THEN DP_WK ELSE 1 END 
--				), YY
--				AS (
--					SELECT ITEM_MST_ID
--						 , ACCOUNT_ID
--						 , BASE_DATE		AS STRT_DATE
--						 , ISNULL(DATEADD(DAY, -1, LEAD(BASE_DATE, 1) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID ORDER BY BASE_DATE ASC)), @P_END_DATE) AS END_DATE
----						 , DATEDIFF(DAY, BASE_DATE, ISNULL(DATEADD(DAY, -1, LEAD(BASE_DATE, 1) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID ORDER BY BASE_DATE ASC)), @P_END_DATE) ) +1 AS DAT_CNT
--						 , QTY
--						 , AMT		
--					  FROM TB_DP_ENTRY
--					 WHERE PLAN_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01 = 'Y' AND ACTV_YN = 'Y')
--					   AND BASE_DATE BETWEEN @P_STRT_DATE AND @P_END_DATE
--					 AND VER_ID = @P_YY_VER_ID
--					 AND AUTH_TP_ID = @P_CL_LV_MGMT_ID
--				)
--					UPDATE TB_DP_MEASURE_DATA
--					  SET ANNUAL_QTY = YY.QTY * CA.DAT_CNT  / (DATEDIFF(DAY, YY.STRT_DATE, YY.END_DATE) + 1)
--						, ANNUAL_AMT = YY.AMT * CA.DAT_CNT  / (DATEDIFF(DAY, YY.STRT_DATE, YY.END_DATE) + 1)
--					  FROM CA 
--						   INNER JOIN
--						   YY 
--						ON CA.STRT_DATE BETWEEN YY.STRT_DATE AND YY.END_DATE	-- 연간 Bucket 단위가 월간 Bucket 단위보다 무조건 커야 함
--					WHERE TB_DP_MEASURE_DATA.ITEM_MST_ID = YY.ITEM_MST_ID
--					  AND TB_DP_MEASURE_DATA.ACCOUNT_ID = YY.ACCOUNT_ID
--					  AND TB_DP_MEASURE_DATA.BASE_DATE = CA.STRT_DATE
--			  END
	/******************************************************************************
		-- 7. Output
	*******************************************************************************/
;
WITH  RESULT 
AS(
	SELECT 'UI_DP_41'		  AS UI_ID
		,  'TB_DP_MEASURE_DATA' AS TABLE_NM
		,  COUNT(*)			  AS CNT
	  FROM TB_DP_MEASURE_DATA
	UNION
	SELECT 'UI_DP_42'		  AS UI_ID
		,  'TB_CM_ACTUAL_SALES' AS TABLE_NM
		,  COUNT(*)			  AS CNT
	  FROM TB_CM_ACTUAL_SALES
	   )
SELECT *
  FROM RESULT 
WHERE UI_ID IN (SELECT VALUE FROM FN_SPLIT(@P_UI_ID, '|'))
/*
DECLARE @P_BUCKET	NVARCHAR(50)
	  , @V_VER_HORIZON	INT
	  , @P_DOW_NM	CHAR(3)
	  , @V_VER_DOW		INT
	  , @V_PAR_BUCKET	NVARCHAR(50)
	  , @V_PAR_HORIZON	INT = 0
	  , @v_VER_STAT_BUCKET INT
	  , @P_STRT_DATE   DATE
	  , @P_END_DATE	   DATE	  
	  , @P_MIN_MEASURE_VAL	INT = 0
	  , @P_MAX_MEASURE_VAL	INT = 45


IF(@P_DATE IS NULL)
	BEGIN
		SET @P_DATE = GETDATE()
	END

	 SELECT @P_BUCKET = C.POLICY_VAL
              FROM   TB_CM_COMM_CONFIG B
                     INNER JOIN
                     TB_DP_PLAN_POLICY C
                ON  (B.ID = C.PLAN_TP_ID)
                     INNER JOIN
                     TB_CM_COMM_CONFIG D
                ON  (C.POLICY_ID = D.ID)                     
                 where  1=1 -- A.MODULE_CD = 'DP'
                   AND B.ACTV_YN = 'Y'
                   AND D.CONF_CD = 'B'
                   AND B.CONF_CD = @P_PLAN_TP_CD
                   ;
          SELECT @V_VER_HORIZON = C.POLICY_VAL
              FROM   TB_CM_COMM_CONFIG B
                     INNER JOIN
                     TB_DP_PLAN_POLICY C
                ON  (B.ID = C.PLAN_TP_ID)
                     INNER JOIN
                     TB_CM_COMM_CONFIG D
                ON  (C.POLICY_ID = D.ID)                     
                 where  1=1 
                   AND B.ACTV_YN = 'Y'
                   AND D.CONF_CD = 'H'
                   AND B.CONF_CD = @P_PLAN_TP_CD      
                   ;
            SELECT @P_DOW_NM = UPPER(CONF_CD)
              FROM TB_CM_COMM_CONFIG 
             WHERE 1=1
               AND CONF_GRP_CD = 'DP_STD_WEEK' 
               AND ACTV_YN = 'Y' 
               AND USE_YN = 'Y' 
             ;
          SELECT @v_VER_STAT_BUCKET = C.POLICY_VAL
              FROM   TB_CM_COMM_CONFIG B
                     INNER JOIN
                     TB_DP_PLAN_POLICY C
                ON  (B.ID = C.PLAN_TP_ID)
                     INNER JOIN
                     TB_CM_COMM_CONFIG D
                ON  (C.POLICY_ID = D.ID)                     
                 where  1=1 
                   AND B.ACTV_YN = 'Y'
                   AND D.CONF_CD = 'SM'
                   AND B.CONF_CD = @P_PLAN_TP_CD      
                   ;
             SELECT @V_VER_DOW = CASE UPPER(@P_DOW_NM) 
                    WHEN 'SUN'  THEN 1 
                    WHEN 'MON'  THEN 2
                    WHEN 'TUE'  THEN 3 
                    WHEN 'WED'  THEN 4 
                    WHEN 'THU'  THEN 5 
                    WHEN 'FRI'  THEN 6
                    WHEN 'SAT'  THEN 7
                    END
            ;
	 SELECT @p_STRT_DATE = CASE @P_BUCKET	
						   	WHEN 'Y'  THEN DATEADD(YEAR,  @v_VER_STAT_BUCKET, (DATENAME(YEAR, @P_DATE) + '0101'))
						   	WHEN 'M'  THEN DATEADD(MONTH, @v_VER_STAT_BUCKET, (DATENAME(YEAR, @P_DATE) + DATENAME(MONTH, @P_DATE) + '01'))
						   	WHEN 'W'  THEN DATEADD(WEEK,  @v_VER_STAT_BUCKET, (DATEADD(DAY, - DATEPART(DW, @P_DATE) + @V_VER_DOW ,CONVERT(DATE, @P_DATE))) )	
						   	WHEN 'PW' THEN DATEADD(WEEK,  @v_VER_STAT_BUCKET, (DATEADD(DAY, - DATEPART(DW, @P_DATE) + @V_VER_DOW ,CONVERT(DATE, @P_DATE))) )	
						   	WHEN 'D'  THEN DATEADD(DAY,   @v_VER_STAT_BUCKET, @P_DATE)
						   END
	 SELECT @P_END_DATE	= CASE @P_BUCKET	
						  	WHEN 'Y' THEN  DATEADD(DAY, -1, DATEADD(YEAR, @v_VER_HORIZON+1, @p_STRT_DATE))	  
						  	WHEN 'M' THEN  DATEADD(DAY, -1, DATEADD(MONTH,  @v_VER_HORIZON,   @p_STRT_DATE))  
						  	WHEN 'W'  THEN  DATEADD(WEEK, @v_VER_HORIZON, @p_STRT_DATE)						  
						  	WHEN 'PW' THEN  DATEADD(WEEK, @v_VER_HORIZON, @p_STRT_DATE)						  
						  	WHEN 'D' THEN  DATEADD(DAY ,@v_VER_HORIZON, @P_DATE )
						  END 
---		 SELECT @p_STRT_DATE, @P_END_DATE;	END


/******************************************************************************************************
	-- Main Procedure 1. Example Data (Code : EXAM)
*******************************************************************************************************/
IF(@P_DATA_TP = 'EXAM')
BEGIN
	---------------------------------------------------------------------------------------------------
	-- Delete
	---------------------------------------------------------------------------------------------------
	DELETE FROM TB_DP_MEASURE_DATA;
	---------------------------------------------------------------------------------------------------
	-- Insert
	---------------------------------------------------------------------------------------------------
	WITH
	ITEM_ACCT
	AS (
		-- New Example Measure
		SELECT A.ACCT_ID
			,  A.ACCT_CD
			,  I.ITEM_ID
			,  I.ITEM_CD
		  FROM (
			SELECT AM.ID AS ACCT_ID
				 , AM.ACCOUNT_CD AS ACCT_CD
				 , EMP_ID
				 , AUTH_TP_ID
			  FROM TB_DP_USER_ACCOUNT_MAP  UA
				   INNER JOIN
				   FN_DP_TEMP_ACCT_TREE() TR
				ON TR.PATH_ID LIKE '%'+UA.SALES_LV_ID+'%'
				   INNER JOIN
				   TB_DP_ACCOUNT_MST AM
				ON TR.LEAF_SALES_LV_ID = AM.PARENT_SALES_LV_ID
			GROUP BY AM.ID, AM.ACCOUNT_CD
				 , EMP_ID
				 , AUTH_TP_ID
			UNION
			SELECT AM.ID AS ACCT_ID
				 , AM.ACCOUNT_CD
				 , EMP_ID
				 , AUTH_TP_ID
			  FROM TB_DP_USER_ACCOUNT_MAP  UA
				   INNER JOIN
				   TB_DP_ACCOUNT_MST AM
				ON UA.ACCOUNT_ID = AM.ID
			GROUP BY AM.ID, AM.ACCOUNT_CD
				 , EMP_ID
				 , AUTH_TP_ID
		) A INNER JOIN
		(
			SELECT AM.ID AS ITEM_ID
				 , AM.ITEM_CD
				 , EMP_ID
				 , AUTH_TP_ID
			  FROM TB_DP_USER_ITEM_MAP  UA
				   INNER JOIN
				   FN_DP_TEMP_ITEM_TREE() TR
				ON TR.PATH_ID LIKE '%'+UA.ITEM_LV_ID+'%'
				   INNER JOIN
				   TB_CM_ITEM_MST AM
				ON TR.LEAF_ITEM_LV_ID = AM.PARENT_ITEM_LV_ID
			GROUP BY AM.ID, AM.ITEM_CD
				 , EMP_ID
				 , AUTH_TP_ID
			UNION
			SELECT AM.ID AS ITEM_ID
				 , AM.ITEM_CD
				 , EMP_ID
				 , AUTH_TP_ID

			  FROM TB_DP_USER_ITEM_MAP  UA
				   INNER JOIN
				   TB_CM_ITEM_MST AM
				ON UA.ITEM_MST_ID = AM.ID
			GROUP BY AM.ID, AM.ITEM_CD
				 , EMP_ID
				 , AUTH_TP_ID

		) I  ON A.EMP_ID = I.EMP_ID
			AND A.AUTH_TP_ID = I.AUTH_TP_ID
		GROUP BY  A.ACCT_ID, A.ACCT_CD, I.ITEM_ID, I.ITEM_CD
		UNION
		SELECT AM.ID AS ACCT_ID
			 , AM.ACCOUNT_CD
			 , IM.ID AS ITEM_ID
			 , IM.ITEM_CD
		  FROM TB_DP_USER_ITEM_ACCOUNT_MAP UA
			   INNER JOIN
			   TB_DP_ACCOUNT_MST AM
			ON UA.ACCOUNT_ID = AM.ID
			   INNER JOIN
			   TB_CM_ITEM_MST IM
			ON UA.ITEM_MST_ID = IM.ID 
		GROUP BY AM.ID, AM.ACCOUNT_CD, IM.ID, IM.ITEM_CD
		)
	,CAL
	AS (
		SELECT DAT 
		  FROM TB_CM_CALENDAR
		WHERE 
			( DAT BETWEEN @p_STRT_DATE AND @P_END_DATE 
		  AND CASE WHEN @P_BUCKET = 'M' OR @P_BUCKET = 'Y' THEN DD ELSE 1 END= 1 
		  AND CASE WHEN @P_BUCKET = 'Y' THEN MM ELSE 1 END = 1
		  AND CASE WHEN @P_BUCKET = 'M' THEN DD ELSE 1 END = 1
		  AND CASE WHEN @P_BUCKET = 'W' OR @P_BUCKET = 'PW' THEN @P_DOW_NM ELSE DOW_NM END = DOW_NM
			)
		OR CASE WHEN @P_BUCKET = 'PW' THEN DD ELSE 0 END = 1
		)

	INSERT INTO TB_DP_MEASURE_DATA
				( ITEM_MST_ID
				, ACCOUNT_ID
				, BASE_DATE 
				, ACT_SALES_QTY
				, ANNUAL_QTY
				, BF_MEAS_QTY
				, IN_TRAN_QTY
				, ISSUED_PO_QTY
				, RTF_QTY
				, STOCK_QTY
				, YOY_QTY
				, YTD_QTY
				)
		SELECT --REPLACE(NEWID(),'-','')  AS ID,
			   ITEM_ID 
			 , ACCT_ID
			 , DAT 
			 /*********** Sample data **/
			 , ROUND( (@P_MAX_MEASURE_VAL - @P_MIN_MEASURE_VAL + 1) * RAND(cast( NEWID() AS varbinary )) + @P_MIN_MEASURE_VAL , 0, 1)   AS ACT_SALES_QTY
			 , ROUND( (@P_MAX_MEASURE_VAL - @P_MIN_MEASURE_VAL + 1) * RAND(cast( NEWID() AS varbinary )) + @P_MIN_MEASURE_VAL , 0, 1)   AS ANNUAL_QTY
			 , ROUND( (@P_MAX_MEASURE_VAL - @P_MIN_MEASURE_VAL + 1) * RAND(cast( NEWID() AS varbinary )) + @P_MIN_MEASURE_VAL , 0, 1)   AS BF_MEAS_QTY
			 , ROUND( (@P_MAX_MEASURE_VAL - @P_MIN_MEASURE_VAL + 1) * RAND(cast( NEWID() AS varbinary )) + @P_MIN_MEASURE_VAL , 0, 1)   AS IN_TRAN
			 , ROUND( (@P_MAX_MEASURE_VAL - @P_MIN_MEASURE_VAL + 1) * RAND(cast( NEWID() AS varbinary )) + @P_MIN_MEASURE_VAL , 0, 1)   AS ISSUED_PO
			 , ROUND( (@P_MAX_MEASURE_VAL - @P_MIN_MEASURE_VAL + 1) * RAND(cast( NEWID() AS varbinary )) + @P_MIN_MEASURE_VAL , 0, 1)   AS RTF_QTY
			 , ROUND( (@P_MAX_MEASURE_VAL - @P_MIN_MEASURE_VAL + 1) * RAND(cast( NEWID() AS varbinary )) + @P_MIN_MEASURE_VAL , 0, 1)   AS STOCK
			 , ROUND( (@P_MAX_MEASURE_VAL - @P_MIN_MEASURE_VAL + 1) * RAND(cast( NEWID() AS varbinary )) + @P_MIN_MEASURE_VAL , 0, 1)   AS YOY_QTY
			 , ROUND( (@P_MAX_MEASURE_VAL - @P_MIN_MEASURE_VAL + 1) * RAND(cast( NEWID() AS varbinary )) + @P_MIN_MEASURE_VAL , 0, 1)   AS YTD_QTY
		  FROM ITEM_ACCT 
			   CROSS JOIN
			   CAL 
	UPDATE TB_DP_MEASURE_DATA
		SET ACT_SALES_AMT = ACT_SALES_QTY* 1000
		  , ANNUAL_AMT	  = ANNUAL_QTY   * 1000
		  , RTF_AMT		  = RTF_QTY		 * 1000	
		  , YOY_AMT		  = YOY_QTY		 * 1000	
		  , YTD_AMT		  = YTD_QTY		 * 1000	
--		  , IN_TRAN_AMT
--		  , BF_MEAS_AMT
--		  , ISSUED_PO_AMT
--		  , STOCK_AMT
	;
	---------------------------------------------------------------------------------------------------
		-- Result
	---------------------------------------------------------------------------------------------------
	SELECT 'UI_DP_17'		  AS UI_ID
		,  'TB_DP_MEASURE_DATA' AS TABLE_NM
		,  COUNT(*)			  AS CNT
	  FROM TB_DP_MEASURE_DATA
END
ELSE
*/
/******************************************************************************************************
	-- Main Procedure 2. Real Data (Code : REAL)
*******************************************************************************************************/
BEGIN
	SELECT ''	  
END



	              
	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0003'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE()= @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;

go

