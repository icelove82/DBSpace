/*****************************************************************************
Title : SP_DP_01_D2
최초 작성자 : 김소희
최초 생성일 : 2018.03.08
 
설명 
 - DP Configuration 하단 그리드 삭제
 
History (수정일자 / 수정자 / 수정내용)
- 2018.03.08 / 김소희 / 첫번째 작성
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_01_D2] (
										 @P_ID			  NVARCHAR(32)		
  									    ,@P_USER_ID		  NVARCHAR(50)
										,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)    = 'true'  OUTPUT
  									    ,@P_RT_MSG            NVARCHAR(4000)  = ''	    OUTPUT
								   ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED								   

DECLARE  @P_ERR_STATUS INT = 0
        ,@P_ERR_MSG NVARCHAR(4000)=''					
		
		,@V_ID		NVARCHAR(32)
		,@V_USER_ID NVARCHAR(50)			   

SET @V_ID = @P_ID
SET @V_USER_ID = @P_USER_ID

BEGIN TRY

		DECLARE @v_LANG_CONF_GRP_CD NVARCHAR(100)
			   ,@V_CONF_GRP_CD NVARCHAR(50)
		SELECT @v_LANG_CONF_GRP_CD = CONF_GRP_CD+'_'+CONF_CD
			  ,@V_CONF_GRP_CD     = CONF_GRP_CD
		  FROM TB_CM_COMM_CONFIG
		 WHERE ID = @V_ID

		-- LANG_PACK 데이터 삭제
		DELETE
		FROM TB_AD_LANG_PACK 
		WHERE 1=1
		AND LANG_CD = 'en'
		AND LANG_KEY LIKE 'CF_'+@v_LANG_CONF_GRP_CD+'%'

	   DELETE 
	     FROM TB_CM_COMM_CONFIG 
	    WHERE ID = @V_ID
/********************************************************************
	-- DELETE 후 VALIDATION
*********************************************************************/
	/* DP_MS_AL_TP 일 때 */
	IF(@V_CONF_GRP_CD = 'DP_MS_VAL_TP')
	BEGIN
		IF EXISTS (
					SELECT REPLACE(CONF_CD,'QTY','AMT')
					  FROM TB_CM_COMM_CONFIG
					 WHERE CONF_GRP_CD = 'DP_MS_VAL_TP'
					   AND ACTV_YN = 'Y'
					   AND USE_YN = 'Y'
					   AND REPLACE(CONF_CD,'QTY','AMT') IN (SELECT CONF_CD 
				 											 FROM TB_CM_COMM_CONFIG 
				 											WHERE CONF_GRP_CD = 'DP_MS_VAL_TP'
				 					  						  AND CONF_CD LIKE 'AMT%'
				 					  						  AND ACTV_YN = 'Y' 
															  AND USE_YN = 'Y'
															)
					GROUP BY REPLACE(CONF_CD,'QTY','AMT')
					  HAVING COUNT(CONF_CD) = 1
				) 
		BEGIN
			SET @P_ERR_MSG = 'A pair of quantity codes must also be activated.';
			RAISERROR (@P_ERR_MSG,11, 1);	    	
		END
	END		
/********************************************************************
	-- Measure Setting Data Handling
*********************************************************************/
IF @V_CONF_GRP_CD = 'DP_MS_VAL_TP'
	BEGIN
		DELETE 
		  FROM TB_DP_MEASURE_SETTING
		 WHERE MEASURE_VAL_TP_ID = @P_ID
	END

	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0002'  --삭제 되었습니다.

END TRY

BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR 

END CATCH;





go

