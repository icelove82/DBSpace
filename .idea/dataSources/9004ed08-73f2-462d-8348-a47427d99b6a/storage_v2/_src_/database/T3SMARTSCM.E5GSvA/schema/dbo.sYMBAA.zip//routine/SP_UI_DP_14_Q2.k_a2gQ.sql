/*****************************************************************************
Title : SP_DP_14_Q2
최초 작성자 : 민희영
최초 생성일 : 2017.06.20
 
설명 
 - DP User Mapping (Account)
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 민희영 / 최초 작성
- 2019.04.25 / 김소희 / DEL_YN Null처리 
- 2019.06.21 / 김소희 / 활성화 안된 Account 및 Sales Level 매핑 색상 변경 처리를 위한 DP_PLAN_YN 컬럼 추가
- 2020.03.12 / KSH / EMP_NO => USER_ID 
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER

*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_14_Q2] (@p_EMP_CD    NVARCHAR(50) = ''
										,@p_AUTH_TP_ID    NVARCHAR(32) = ''
								   ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN


 SELECT   UA.ID
        , UA.AUTH_TP_ID 
		, LM2.LV_CD AS  AUTH_TYPE
		, LM2.LV_NM AS  AUTH_TYPE_NM
		, UA.EMP_ID
		, DE.USERNAME AS EMP_NO
		, DE.USERNAME AS USER_ID
		, DE.DISPLAY_NAME AS EMP_NM
		, UA.LV_MGMT_ID
		, LM.LV_CD
		, LM.LV_NM
		, ISNULL(UA.SALES_LV_ID ,UA.ACCOUNT_ID)  AS ACCOUNT_ID
		, ISNULL(SL.SALES_LV_CD ,AM.ACCOUNT_CD)  AS ACCOUNT_CD
		, ISNULL(SL.SALES_LV_NM, AM.ACCOUNT_NM) AS ACCOUNT_NM    
		, UA.ACTV_YN 
        , UA.CREATE_BY
        , UA.CREATE_DTTM
        , UA.MODIFY_BY
        , UA.MODIFY_DTTM
		, CASE WHEN AM.ID IS NULL THEN (CASE WHEN SL.DEL_YN = 'Y' OR ISNULL(SL.ACTV_YN,'N') = 'N' THEN 'N' ELSE 'Y' END)
			   WHEN SL.ID IS NULL THEN (CASE WHEN AM.DEL_YN = 'Y' OR ISNULL(AM.ACTV_YN,'N') = 'N' THEN 'N' ELSE 'Y' END)
		  END			AS DP_PLAN_YN
  FROM    TB_CM_COMM_CONFIG B
        , TB_CM_LEVEL_MGMT LM   
		, TB_CM_COMM_CONFIG B2
        , TB_CM_LEVEL_MGMT LM2   
		, TB_DP_USER_ACCOUNT_MAP UA LEFT OUTER JOIN TB_DP_SALES_LEVEL_MGMT SL ON UA.SALES_LV_ID = SL.ID
		                                          LEFT OUTER JOIN TB_DP_ACCOUNT_MST AM ON UA.ACCOUNT_ID = AM.ID
		, TB_AD_USER   DE
  WHERE    B.CONF_GRP_CD =  'DP_LV_TP'
	   AND B.CONF_CD = 'S'
	   AND B.ACTV_YN = 'Y'
	   AND B.ID = LM.LV_TP_ID
	   AND ISNULL(LM.DEL_YN,'N') = 'N'
	   AND LM.ID = UA.LV_MGMT_ID    -- Level Type 
       AND B2.CONF_GRP_CD =  'DP_LV_TP' 
	   AND B2.CONF_CD = 'S'
	   AND B2.ACTV_YN = 'Y'
	   AND B2.ID = LM2.LV_TP_ID
	   AND ISNULL(LM2.DEL_YN,'N') = 'N'
	   AND LM2.ID = UA.AUTH_TP_ID -- Auth Type
	   AND UA.EMP_ID = DE.ID
	   AND DE.USERNAME =  @p_EMP_CD   --'admin'
	   AND UA.AUTH_TP_ID = @p_AUTH_TP_ID
ORDER BY LM.SEQ,  SL.SEQ, AM.ACCOUNT_CD
;





END

go

