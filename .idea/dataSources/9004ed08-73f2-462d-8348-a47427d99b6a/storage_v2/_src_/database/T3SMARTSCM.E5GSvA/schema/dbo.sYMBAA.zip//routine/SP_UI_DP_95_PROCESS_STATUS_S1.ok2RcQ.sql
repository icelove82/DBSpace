CREATE PROCEDURE [dbo].[SP_UI_DP_95_PROCESS_STATUS_S1](
  @P_USER_CD		NVARCHAR(50)	
 ,@P_LOGIN_USER_CD	NVARCHAR(50)
 ,@P_AUTH_TP_CD		NVARCHAR(100)
 ,@P_VER_CD			NVARCHAR(50)
 ,@P_STATUS			NVARCHAR(50)
 ,@P_AUTO_APPV_YN   CHAR(1)
)
AS 	 
BEGIN
/*****************************************************************************************************
	[SP_UI_DP_95_PROCESS_STATUS_S1]
    History ( date / writer / comment )
    - 2021.06.02 / ksh / upper class user also can be approve such as salesman, when approve constraint attribute 01 is 'ALL' 
	- 2021.06.24 / ksh / add code to get auth type ID & version ID
	- 2021.12.22 / KSH / change method to get top level because of adding level type
	- 2022.08.18 / ksh / add a param @P_LOGIN_USER_CD and @P_AUTO_APPV_YN
****************************************************************************************************/
DECLARE @P_AUTH_TP_ID	CHAR(32)
	 ,  @p_VER_ID		CHAR(32)
	 ,  @P_APPV_CONST_CD   NVARCHAR(50)
	 ,  @P_TOP_LV_ID	CHAR(32)
	 ;

	 SELECT @P_TOP_LV_ID = LV_MGMT_ID 
	   FROM TB_DP_SALES_LEVEL_MGMT SL 
		    INNER JOIN 
			TB_CM_LEVEL_MGMT CL 
		 ON SL.LV_MGMT_ID = CL.ID 		
		    INNER JOIN 
			TB_CM_COMM_CONFIG CC
		 ON CL.LV_TP_ID = CC.ID 
		AND CC.CONF_CD = 'S' 
	  WHERE SL.ACTV_YN = 'Y' AND COALESCE(SL.DEL_YN,'N') != 'Y' 
	    AND CL.ACTV_YN = 'Y'
		AND COALESCE(CL.DEL_YN,'N') != 'Y'
	   AND SL.PARENT_SALES_LV_ID IS NULL

		SELECT @P_AUTH_TP_ID = ID 
		  FROM TB_CM_LEVEL_MGMT
		 WHERE LV_CD = @P_AUTH_TP_CD
		 ;
	   SELECT @P_VER_ID = ID  
		 FROM TB_DP_CONTROL_BOARD_VER_MST
	   WHERE VER_ID = @P_VER_CD 
	   ;     
    SELECT @P_APPV_CONST_CD = CC.ATTR_01  
 	  FROM TB_DP_CONTROL_BOARD_VER_DTL CB
		   INNER JOIN
		   TB_CM_COMM_CONFIG CC
		ON CB.APPV_CONST_ID = CC.ID 
	 WHERE CONBD_VER_MST_ID = @p_VER_ID
	   AND LV_MGMT_ID = @P_AUTH_TP_ID 
	   ;

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Main Procedure
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
IF (@P_APPV_CONST_CD = 'ALL')
    BEGIN
/*    
          SELECT DESC_ID INTO P_TOP_SALES_LV
               FROM TB_dPD_USER_HIER_CLOSURE 
            GROUP BY DESC_ID 
            HAVING COUNT(DESC_ID) = 1
            ;
*/            
        WITH PARENT_LV 
        AS (-- 최상위 사용자가 아닐 때
            SELECT TOP 1 UH.ANCS_ROLE_ID, ANCS_ROLE_CD
                 , ANCS_ID , ANCS_CD
--                 , DENSE_RANK() OVER (ORDER BY LV.SEQ  DESC) AS SEQ           
              FROM TB_DPD_USER_HIER_CLOSURE UH
                   INNER JOIN 
                   TB_CM_LEVEL_MGMT LV
               ON UH.ANCS_ROLE_ID = LV.ID		
              AND LV.ACTV_YN = 'Y'
              AND COALESCE(LV.DEL_YN,'N') = 'N'
              AND DESC_ROLE_ID = @P_AUTH_TP_ID   
              AND DESC_CD = @P_USER_CD
              AND DESC_CD != ANCS_CD 
			  ORDER BY LV.SEQ  DESC
            ) , APPV_USER
        AS (
            SELECT DISTINCT
                   M.DESC_ROLE_ID 
                 , M.DESC_ROLE_CD 
                 , M.DESC_ID
                 , M.DESC_CD 
              FROM TB_DPD_USER_HIER_CLOSURE M
                   INNER JOIN
                   PARENT_LV P 
                ON M.ANCS_ROLE_ID = P.ANCS_ROLE_ID
               AND M.ANCS_ID = P.ANCS_ID
               AND M.DESC_ROLE_ID = @P_AUTH_TP_ID 
               AND M.DESC_CD != @P_USER_CD
            )
			INSERT INTO TB_DP_PROCESS_STATUS_LOG
			(    ID
			   , VER_CD
			   , AUTH_TYPE
			   , OPERATOR_ID
			   , STATUS
			   , STATUS_DATE
			   , AUTO_APPV_YN 
			 )
		   SELECT REPLACE(NEWID(),'-','')
                  ,@P_VER_CD
                  ,DESC_ROLE_CD
                  ,DESC_CD  
                  ,@p_STATUS  
                  ,GETDATE()  
				  ,@P_AUTO_APPV_YN
              FROM TB_DPD_USER_HIER_CLOSURE 
            WHERE DESC_ROLE_ID = @P_TOP_LV_ID   
              AND DESC_ROLE_ID = @P_AUTH_TP_ID
              AND DESC_CD != @P_USER_CD 
            UNION 
            SELECT REPLACE(NEWID(),'-','')
                  ,@P_VER_CD
                  ,DESC_ROLE_CD
                  ,DESC_CD 
                  ,@P_STATUS
                  ,GETDATE()
				  ,@P_AUTO_APPV_YN
              FROM APPV_USER
            ;
    END
    ;	
END

go

