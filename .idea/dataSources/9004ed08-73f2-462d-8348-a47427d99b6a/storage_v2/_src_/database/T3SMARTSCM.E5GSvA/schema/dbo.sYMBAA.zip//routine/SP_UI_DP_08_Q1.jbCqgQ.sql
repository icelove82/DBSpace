/*****************************************************************************
Title : SP_DP_08_Q1
최초 작성자 : 민희영
최초 생성일 : 2017.06.20
 
설명 
 - DP Item Level Management
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 민희영 / 최초 작성
- 2019.04.25 / 김소희 / DEL_YN NULL처리
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_08_Q1] (@p_ITEM_LV    NVARCHAR(32) = ''
									   ,@p_ACTV_YN     NVARCHAR(1) = ''
									   ,@p_LV_TP_ID     NVARCHAR(32) = ''
								   ) AS 

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @V_ITEM_LV	NVARCHAR(32) = ''
	  , @V_ACTV_YN	NVARCHAR(1) = ''
	   , @V_LV_TP_ID	NVARCHAR(32) = ''
SET @V_ITEM_LV = @p_ITEM_LV
SET @V_ACTV_YN = @p_ACTV_YN
SET @V_LV_TP_ID = @p_LV_TP_ID
BEGIN

--SELECT IL.ID
--      ,IL.ITEM_LV_CD
--      ,IL.ITEM_LV_NM
--      ,IL.LV_MGMT_ID
--      ,ISNULL(IL.PARENT_ITEM_LV_ID,'') AS PARENT_ITEM_LV_ID
--	  ,IL2.ITEM_LV_CD  AS PARENT_ITEM_LV_CD
--	  ,IL2.ITEM_LV_NM  AS PARENT_ITEM_LV_NM  
--      ,IL.SEQ
--      ,IL.ACTV_YN
--	  ,IL.DEL_YN
--	  ,IL.ATTR_01 AS ATTR_01
--      ,IL.CREATE_BY
--      ,IL.CREATE_DTTM
--      ,IL.MODIFY_BY
--      ,IL.MODIFY_DTTM
--  FROM TB_CM_CONFIGURATION A
--	 , TB_CM_COMM_CONFIG B
--	 , TB_CM_LEVEL_MGMT  LM
--	 , TB_CM_ITEM_LEVEL_MGMT IL 
--	      LEFT OUTER JOIN  TB_CM_ITEM_LEVEL_MGMT IL2 ON  IL.PARENT_ITEM_LV_ID = IL2.ID AND ISNULL(IL2.DEL_YN,'N') = 'N' AND IL2.ACTV_YN = 'Y'
--  WHERE A.MODULE_CD = 'DP'
--	AND A.ID = B.CONF_ID
--	AND B.CONF_GRP_CD = 'DP_LV_TP'
--	AND B.CONF_CD = 'I'
--	AND B.ID = LM.LV_TP_ID  -- S/C/I
--	AND ISNULL(LM.DEL_YN,'N') = 'N'
--	AND LM.ACTV_YN = 'Y'
--	AND LM.ID = IL.LV_MGMT_ID 
--	--AND IL.DEL_YN = 'N'
--	AND IL.LV_MGMT_ID  LIKE '%' + LTRIM(RTRIM(@p_ITEM_LV)) +'%'	
--	AND ISNULL(IL.DEL_YN,'N') LIKE '%' + RTRIM(LTRIM(@p_ACTV_YN)) +'%'	
--  ORDER BY LM.SEQ, IL.SEQ
--;

 SELECT IL.ID
       ,IL.ITEM_LV_CD
       ,IL.ITEM_LV_NM
       ,IL.LV_MGMT_ID
       ,IL.ATTR_01
       ,IL.PARENT_ITEM_LV_ID AS PARENT_ITEM_LV_ID
       ,IL2.ITEM_LV_CD  AS PARENT_ITEM_LV_CD
       ,IL2.ITEM_LV_NM  AS PARENT_ITEM_LV_NM        
       ,IL.SEQ
       ,IL.ACTV_YN
       ,IL.DEL_YN
       ,IL.CREATE_BY
       ,IL.CREATE_DTTM
       ,IL.MODIFY_BY
       ,IL.MODIFY_DTTM
	   ,B.CONF_CD AS LV_TP_CD
 --      ,IL.ITEM_LV_NM+(CASE WHEN ITEM_CNT = 0 OR ITEM_CNT IS NULL THEN NULL ELSE' ('+ ITEM_CNT+')' END) AS ITEM_LV_TREE_NM
   FROM TB_CM_CONFIGURATION A
      , TB_CM_COMM_CONFIG B
      , TB_CM_LEVEL_MGMT  LM
      , TB_CM_ITEM_LEVEL_MGMT IL 
           LEFT OUTER JOIN  TB_CM_ITEM_LEVEL_MGMT IL2 ON  IL.PARENT_ITEM_LV_ID = IL2.ID AND ISNULL(IL2.DEL_YN,'N') = 'N' AND IL2.ACTV_YN = 'Y'  
   WHERE A.MODULE_CD = 'DP'
     AND A.ID = B.CONF_ID
     AND B.CONF_GRP_CD = 'DP_LV_TP'
     --AND B.CONF_CD = 'I'
     AND B.ID = LM.LV_TP_ID  -- S/C/I
	 AND LM.LV_TP_ID = @V_LV_TP_ID
     AND ISNULL(LM.DEL_YN,'N') = 'N'
     AND LM.ACTV_YN = 'Y'
     AND LM.ID = IL.LV_MGMT_ID 
 --    AND IL.DEL_YN = 'N'
     AND IL.LV_MGMT_ID  LIKE '%' + LTRIM(RTRIM(@V_ITEM_LV)) + '%'    
     AND (IL.ACTV_YN LIKE '%' + RTRIM(@V_ACTV_YN) + '%'   OR RTRIM(@V_ACTV_YN) IS NULL)
   ORDER BY LM.SEQ, IL.SEQ

   
END
 
   





go

