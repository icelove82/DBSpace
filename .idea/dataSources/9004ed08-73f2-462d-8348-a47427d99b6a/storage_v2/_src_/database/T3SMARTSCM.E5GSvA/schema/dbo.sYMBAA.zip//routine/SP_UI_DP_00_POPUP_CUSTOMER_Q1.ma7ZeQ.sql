/*****************************************************************************
Title : [SP_DP_00_POPUP_CUSTOMER_Q1]
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP CUSTOMER POPUP 조회 프로시저 
  
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
 	- 2020.11.10 / Kim sohee / data type of CODE NVARCHAR(100)
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_00_POPUP_CUSTOMER_Q1]  (@p_CUST_CD      NVARCHAR(100) = ''
                                              ,@p_CUST_NM      NVARCHAR(240) = ''
            								  ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
DECLARE @V_CUST_CD NVARCHAR(100) = ''
	  , @V_CUST_NM NVARCHAR(240) = ''

	SET @V_CUST_CD = @p_CUST_CD
	SET @V_CUST_NM = @p_CUST_NM

BEGIN


SELECT DC.ID
      ,CUST_CD
      ,CUST_NM
      ,c.CONF_CD as COUNTRY_CD
      ,c.CONF_NM as COUNTRY_NM
      ,ADDR
      --,ATTR1
      --,ATTR2
      --,ATTR3
      --,ATTR4
      --,CREATE_BY
      --,CREATE_DTTM
      --,MODIFY_BY
      --,MODIFY_DTTM
  FROM TB_CM_CUSTOMER DC
  left outer join TB_CM_COMM_CONFIG c on c.id =  DC.COUNTRY_ID
 WHERE UPPER(DC.CUST_CD) LIKE '%' + UPPER(RTRIM(@V_CUST_CD)) + '%'            
   AND UPPER(DC.CUST_NM) LIKE '%' + UPPER(RTRIM(@V_CUST_NM)) + '%'            
   ORDER BY CUST_CD ASC
    ;

END

go

