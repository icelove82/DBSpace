/*****************************************************************************
Title : SP_UI_DP_07_Q2
최초 작성자 : 김소희
최초 생성일 : 2018.06.29

설명
  - DP Exchange Rate

History (수정일자 / 수정자 / 수정내용)
- 2018.07.03 / 김소희 / MSSQL로 컨버팅

*****************************************************************************/
CREATE PROCEDURE      [dbo].[SP_UI_DP_07_Q2] 
(
          @P_FROM_DATE			 DATETIME
         ,@P_TO_DATE			 DATETIME
         ,@P_FROM_CURCY_CD_ID    CHAR(32)
         ,@P_TO_CURCY_CD_ID      CHAR(32)
         ,@P_CURCY_TP_ID		 CHAR(32)
         ,@P_BUCKET_CD			 NVARCHAR(100)
) AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

    -- 필요한 변수
DECLARE
--     @P_BUCKET_CD     NVARCHAR(10) = ''
     @V_FROM_DATE  DATETIME         = null
    ,@V_TO_DATE    DATETIME         = null

	,@V_FROM_CURCY_CD_ID CHAR(32)
	,@V_TO_CURCY_CD_ID   CHAR(32)  
	,@V_CURCY_TP_ID		 CHAR(32)
	,@V_BUCKET_CD		 NVARCHAR(100)

SET @V_FROM_CURCY_CD_ID	= @P_FROM_CURCY_CD_ID   
SET @V_TO_CURCY_CD_ID  	= @P_TO_CURCY_CD_ID     
SET @V_CURCY_TP_ID		= @P_CURCY_TP_ID		
SET @V_BUCKET_CD		= @P_BUCKET_CD			

BEGIN
    --------------------------------------------
        --01 BUCKET 구하기
    --------------------------------------------
--     SELECT @V_BUCKET_CD = COUNT(PP.POLICY_VAL)         
--      FROM TB_DP_PLAN_POLICY PP
--           LEFT OUTER JOIN
--           TB_CM_COMM_CONFIG BK
--        ON(PP.POLICY_ID = BK.ID)
--           LEFT OUTER JOIN
--           TB_CM_COMM_CONFIG PT
--        ON(PP.PLAN_TP_ID = PT.ID)   
--     WHERE 1=1
--       AND BK.CONF_GRP_CD = 'DP_POLICY'
--       AND BK.CONF_CD     = 'B'
--       AND PT.CONF_GRP_CD = 'DP_PLAN_TYPE'
--       AND PT.CONF_CD     = RTRIM(@P_PLAN_TP_CD)    -- 'DP_PLAN_MONTHLY'
--       ;
--
--    IF(@V_BUCKET_CD != 0)
--        BEGIN
--
--    SELECT @V_BUCKET_CD = UPPER(RTRIM(PP.POLICY_VAL))        
--      FROM TB_DP_PLAN_POLICY PP
--           LEFT OUTER JOIN
--           TB_CM_COMM_CONFIG BK
--        ON(PP.POLICY_ID = BK.ID)
--           LEFT OUTER JOIN
--           TB_CM_COMM_CONFIG PT
--        ON(PP.PLAN_TP_ID = PT.ID)   
--     WHERE 1=1
--       AND BK.CONF_GRP_CD = 'DP_POLICY'
--       AND BK.CONF_CD     = 'B'
--       AND PT.CONF_GRP_CD = 'DP_PLAN_TYPE'
--       AND PT.CONF_CD     = RTRIM(@P_PLAN_TP_CD)    -- 'DP_PLAN_MONTHLY'
--       ;
--	    END
--    ELSE
--		BEGIN
--			SET @V_BUCKET_CD = 'NONE'
--		END
--       P_BUCKET_CD := 'PW'; 
    ----------------------------------------------------------------------------------------------------------------------
        --02 시작일, 마감일 BUCKET 값따라 재계산
    ----------------------------------------------------------------------------------------------------------------------

    SET @V_FROM_DATE = CONVERT(DATETIME, @P_FROM_DATE);
    SET @V_TO_DATE   = CONVERT(DATETIME, @P_TO_DATE);


    ----------------------------------------------------------------------------------------------------------------------
        --03 버킷에 의한 날짜별 UNIT PRICE 프로시저 (M/W/PW/D)
    ----------------------------------------------------------------------------------------------------------------------
     IF(@V_BUCKET_CD = 'Year')     --↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙
        BEGIN -- 거의 완성한 쿼리 (다른 버켓에도 반영해줘야 함) TEST DATA : B71F7E8A067C48C79172AC82A2D441D5 (ID) (CREATE_BY = 'TEST')
		SELECT  M.FROM_CURCY_CD_ID
			   ,FROM_CURCY_CD
			   ,FROM_CURCY_CD_NM
			   ,M.TO_CURCY_CD_ID
			   ,TO_CURCY_CD
			   ,TO_CURCY_CD_NM
		 	   ,DAT
			   ,EXCHANGE_RATE
		  FROM TB_DP_EXCHANGE_RATE M
		       INNER JOIN
			   (
				SELECT P.FROM_CURCY_CD_ID
					 , F.COMN_CD            AS FROM_CURCY_CD
					 , F.COMN_CD_NM         AS FROM_CURCY_CD_NM
					 , P.TO_CURCY_CD_ID
					 , T.COMN_CD            AS TO_CURCY_CD
					 , T.COMN_CD_NM         AS TO_CURCY_CD_NM
					 
					 , CONVERT(DATE, DAT) AS DAT
					 , MAX(P.BASE_DATE)			AS BASE_DATE -- DAT 가 어떤 BAASE_DATE의 값을 갖고오는 지 참고용
				  FROM TB_CM_CALENDAR C
					   LEFT OUTER JOIN
					   TB_DP_EXCHANGE_RATE P
					ON (C.DAT >= P.BASE_DATE)-- AND ADD_MONTHS(P.BASE_DATE, 1)> C.DAT) 
					   LEFT OUTER JOIN
					   TB_AD_COMN_CODE F
					ON (F.ID = P.FROM_CURCY_CD_ID)
					   LEFT OUTER JOIN
					   TB_AD_COMN_CODE T
					ON (T.ID = P.TO_CURCY_CD_ID)                
				 WHERE 1=1
					   AND DAT BETWEEN @V_FROM_DATE AND @V_TO_DATE 
					   AND DD = CONVERT(INT, DATEPART(DD, @V_FROM_DATE))   -- 한달 BUCKET
             AND MM = CONVERT(INT, DATEPART(MM, @V_FROM_DATE))   -- 한달 BUCKET
					   AND P.CURCY_TP_ID = @V_CURCY_TP_ID
					   AND (P.FROM_CURCY_CD_ID = @V_FROM_CURCY_CD_ID OR ISNULL(RTRIM(@V_FROM_CURCY_CD_ID),'')  = '')
					   AND (P.TO_CURCY_CD_ID = @V_TO_CURCY_CD_ID     OR ISNULL(RTRIM(@V_TO_CURCY_CD_ID)  ,'')  = '')
		               GROUP BY FROM_CURCY_CD_ID, F.COMN_CD, F.COMN_CD_NM, P.TO_CURCY_CD_ID, T.COMN_CD, T.COMN_CD_NM, DAT
				) B
			ON (M.FROM_CURCY_CD_ID = B.FROM_CURCY_CD_ID AND M.TO_CURCY_CD_ID = B.TO_CURCY_CD_ID AND M.BASE_DATE = B.BASE_DATE)
               ORDER BY FROM_CURCY_CD_ID, TO_CURCY_CD_ID, DAT
		END   
    
    ELSE IF (@V_BUCKET_CD = 'Month')     --↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙
        BEGIN -- 거의 완성한 쿼리 (다른 버켓에도 반영해줘야 함) TEST DATA : B71F7E8A067C48C79172AC82A2D441D5 (ID) (CREATE_BY = 'TEST')
		SELECT  M.FROM_CURCY_CD_ID
			   ,FROM_CURCY_CD
			   ,FROM_CURCY_CD_NM
			   ,M.TO_CURCY_CD_ID
			   ,TO_CURCY_CD
			   ,TO_CURCY_CD_NM
			   
		 	   ,DAT
			   ,EXCHANGE_RATE
		  FROM TB_DP_EXCHANGE_RATE M
		       INNER JOIN
			   (
				SELECT P.FROM_CURCY_CD_ID
					 , F.COMN_CD            AS FROM_CURCY_CD
					 , F.COMN_CD_NM         AS FROM_CURCY_CD_NM
					 , P.TO_CURCY_CD_ID
					 , T.COMN_CD            AS TO_CURCY_CD
					 , T.COMN_CD_NM         AS TO_CURCY_CD_NM
					 
					 , CONVERT(DATE, DAT) AS DAT
					 , MAX(P.BASE_DATE)			AS BASE_DATE -- DAT 가 어떤 BAASE_DATE의 값을 갖고오는 지 참고용
--					 , MAX(P.EXCHANGE_RATE) KEEP(DENSE_RANK FIRST ORDER BY BASE_DATE DESC) AS EXCHANGE_RATE -- MAX(BASE_DATE) 의 값과 같은 ROW인 UTPIC의 값
				  FROM TB_CM_CALENDAR C
					   LEFT OUTER JOIN
					   TB_DP_EXCHANGE_RATE P
					ON (C.DAT >= P.BASE_DATE)-- AND ADD_MONTHS(P.BASE_DATE, 1)> C.DAT) 
					   LEFT OUTER JOIN
					   TB_AD_COMN_CODE F
					ON (F.ID = P.FROM_CURCY_CD_ID)
					   LEFT OUTER JOIN
					   TB_AD_COMN_CODE T
					ON (T.ID = P.TO_CURCY_CD_ID)                
				 WHERE 1=1
					   AND DAT BETWEEN @V_FROM_DATE AND @V_TO_DATE 
					   AND DD = CONVERT(INT, DATEPART(DD, @V_FROM_DATE))   -- 한달 BUCKET
					   AND P.CURCY_TP_ID = @V_CURCY_TP_ID
					   AND (P.FROM_CURCY_CD_ID = @V_FROM_CURCY_CD_ID OR ISNULL(RTRIM(@V_FROM_CURCY_CD_ID),'')  = '')
					   AND (P.TO_CURCY_CD_ID = @V_TO_CURCY_CD_ID     OR ISNULL(RTRIM(@V_TO_CURCY_CD_ID)  ,'')  = '')
		               GROUP BY FROM_CURCY_CD_ID, F.COMN_CD, F.COMN_CD_NM, P.TO_CURCY_CD_ID, T.COMN_CD, T.COMN_CD_NM, DAT
				) B
			ON (M.FROM_CURCY_CD_ID = B.FROM_CURCY_CD_ID AND M.TO_CURCY_CD_ID = B.TO_CURCY_CD_ID AND M.BASE_DATE = B.BASE_DATE)
               ORDER BY FROM_CURCY_CD_ID, TO_CURCY_CD_ID, DAT

		END
              
    ELSE IF (@V_BUCKET_CD = 'Week') --↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙
        BEGIN
		SELECT  M.FROM_CURCY_CD_ID
			   ,FROM_CURCY_CD
			   ,FROM_CURCY_CD_NM
			   ,M.TO_CURCY_CD_ID
			   ,TO_CURCY_CD
			   ,TO_CURCY_CD_NM
			   
		 	   ,CONVERT(DATE, DAT) AS DAT
			   ,EXCHANGE_RATE
		  FROM TB_DP_EXCHANGE_RATE M
		       INNER JOIN
			   (
				SELECT P.FROM_CURCY_CD_ID
					 , F.COMN_CD            AS FROM_CURCY_CD
					 , F.COMN_CD_NM         AS FROM_CURCY_CD_NM
					 , P.TO_CURCY_CD_ID
					 , T.COMN_CD            AS TO_CURCY_CD
					 , T.COMN_CD_NM         AS TO_CURCY_CD_NM
					 
					 , C.DAT
					 , MAX(P.BASE_DATE)			AS BASE_DATE -- DAT 가 어떤 BAASE_DATE의 값을 갖고오는 지 참고용
--					 , MAX(P.EXCHANGE_RATE) KEEP(DENSE_RANK FIRST ORDER BY BASE_DATE DESC) AS EXCHANGE_RATE -- MAX(BASE_DATE) 의 값과 같은 ROW인 UTPIC의 값
				  FROM TB_CM_CALENDAR C
					   LEFT OUTER JOIN
					   TB_DP_EXCHANGE_RATE P
					ON (C.DAT >= P.BASE_DATE)-- AND ADD_MONTHS(P.BASE_DATE, 1)> C.DAT) 
					   LEFT OUTER JOIN
					   TB_AD_COMN_CODE F
					ON (F.ID = P.FROM_CURCY_CD_ID)
					   LEFT OUTER JOIN
					   TB_AD_COMN_CODE T
					ON (T.ID = P.TO_CURCY_CD_ID)                
				 WHERE 1=1
                       AND DAT BETWEEN @V_FROM_DATE AND @V_TO_DATE 
                       AND DOW_NM = ( SELECT UPPER(CONF_CD) FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_STD_WEEK' AND ACTV_YN = 'Y' AND USE_YN = 'Y')
					   AND P.CURCY_TP_ID = @V_CURCY_TP_ID
					   AND (P.FROM_CURCY_CD_ID = @V_FROM_CURCY_CD_ID OR ISNULL(RTRIM(@V_FROM_CURCY_CD_ID),'')  = '')
					   AND (P.TO_CURCY_CD_ID = @V_TO_CURCY_CD_ID     OR ISNULL(RTRIM(@V_TO_CURCY_CD_ID)  ,'')  = '')
		               GROUP BY FROM_CURCY_CD_ID, F.COMN_CD, F.COMN_CD_NM, P.TO_CURCY_CD_ID, T.COMN_CD, T.COMN_CD_NM, DAT
				) B
			ON (M.FROM_CURCY_CD_ID = B.FROM_CURCY_CD_ID AND M.TO_CURCY_CD_ID = B.TO_CURCY_CD_ID AND M.BASE_DATE = B.BASE_DATE)
               ORDER BY FROM_CURCY_CD_ID, TO_CURCY_CD_ID, DAT

		END
              ;
    ELSE IF (@V_BUCKET_CD = 'PAR_WEEK') --↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙
        BEGIN
		SELECT  M.FROM_CURCY_CD_ID
			   ,FROM_CURCY_CD
			   ,FROM_CURCY_CD_NM
			   ,M.TO_CURCY_CD_ID
			   ,TO_CURCY_CD
			   ,TO_CURCY_CD_NM
			   
		 	   ,CONVERT(DATE, DAT) AS DAT
			   ,EXCHANGE_RATE
		  FROM TB_DP_EXCHANGE_RATE M
		       INNER JOIN
			   (
				SELECT P.FROM_CURCY_CD_ID
					 , F.COMN_CD            AS FROM_CURCY_CD
					 , F.COMN_CD_NM         AS FROM_CURCY_CD_NM
					 , P.TO_CURCY_CD_ID
					 , T.COMN_CD            AS TO_CURCY_CD
					 , T.COMN_CD_NM         AS TO_CURCY_CD_NM
					 
					 , C.DAT
					 , MAX(P.BASE_DATE)			AS BASE_DATE -- DAT 가 어떤 BAASE_DATE의 값을 갖고오는 지 참고용
--					 , MAX(P.EXCHANGE_RATE) KEEP(DENSE_RANK FIRST ORDER BY BASE_DATE DESC) AS EXCHANGE_RATE -- MAX(BASE_DATE) 의 값과 같은 ROW인 UTPIC의 값
				  FROM TB_CM_CALENDAR C
					   LEFT OUTER JOIN
					   TB_DP_EXCHANGE_RATE P
					ON (C.DAT >= P.BASE_DATE)-- AND ADD_MONTHS(P.BASE_DATE, 1)> C.DAT) 
					   LEFT OUTER JOIN
					   TB_AD_COMN_CODE F
					ON (F.ID = P.FROM_CURCY_CD_ID)
					   LEFT OUTER JOIN
					   TB_AD_COMN_CODE T
					ON (T.ID = P.TO_CURCY_CD_ID)                
				 WHERE 1=1
                       AND DAT BETWEEN @V_FROM_DATE AND @V_TO_DATE 
                       AND ( DOW_NM = ( SELECT UPPER(CONF_CD) FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_STD_WEEK' AND ACTV_YN = 'Y' AND USE_YN = 'Y')
							OR DD = 1
						   )
					   AND P.CURCY_TP_ID = @V_CURCY_TP_ID
					   AND (P.FROM_CURCY_CD_ID = @V_FROM_CURCY_CD_ID OR ISNULL(RTRIM(@V_FROM_CURCY_CD_ID),'')  = '')
					   AND (P.TO_CURCY_CD_ID = @V_TO_CURCY_CD_ID     OR ISNULL(RTRIM(@V_TO_CURCY_CD_ID)  ,'')  = '')
		               GROUP BY FROM_CURCY_CD_ID, F.COMN_CD, F.COMN_CD_NM, P.TO_CURCY_CD_ID, T.COMN_CD, T.COMN_CD_NM, DAT
				) B
			ON (M.FROM_CURCY_CD_ID = B.FROM_CURCY_CD_ID AND M.TO_CURCY_CD_ID = B.TO_CURCY_CD_ID AND M.BASE_DATE = B.BASE_DATE)
               ORDER BY FROM_CURCY_CD_ID, TO_CURCY_CD_ID, DAT
                ;
		END
    ELSE IF (@V_BUCKET_CD = 'Day')     --↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙↙
        BEGIN    
		SELECT  M.FROM_CURCY_CD_ID
			   ,FROM_CURCY_CD
			   ,FROM_CURCY_CD_NM
			   ,M.TO_CURCY_CD_ID
			   ,TO_CURCY_CD
			   ,TO_CURCY_CD_NM
			   
		 	   ,CONVERT(DATE, DAT) AS DAT
			   ,EXCHANGE_RATE
		  FROM TB_DP_EXCHANGE_RATE M
		       INNER JOIN
			   (
				SELECT P.FROM_CURCY_CD_ID
					 , F.COMN_CD            AS FROM_CURCY_CD
					 , F.COMN_CD_NM         AS FROM_CURCY_CD_NM
					 , P.TO_CURCY_CD_ID
					 , T.COMN_CD            AS TO_CURCY_CD
					 , T.COMN_CD_NM         AS TO_CURCY_CD_NM
					 
					 , C.DAT
					 , MAX(P.BASE_DATE)			AS BASE_DATE -- DAT 가 어떤 BAASE_DATE의 값을 갖고오는 지 참고용
--					 , MAX(P.EXCHANGE_RATE) KEEP(DENSE_RANK FIRST ORDER BY BASE_DATE DESC) AS EXCHANGE_RATE -- MAX(BASE_DATE) 의 값과 같은 ROW인 UTPIC의 값
				  FROM TB_CM_CALENDAR C
					   LEFT OUTER JOIN
					   TB_DP_EXCHANGE_RATE P
					ON (C.DAT >= P.BASE_DATE)-- AND ADD_MONTHS(P.BASE_DATE, 1)> C.DAT) 
					   LEFT OUTER JOIN
					   TB_AD_COMN_CODE F
					ON (F.ID = P.FROM_CURCY_CD_ID)
					   LEFT OUTER JOIN
					   TB_AD_COMN_CODE T
					ON (T.ID = P.TO_CURCY_CD_ID)                
				 WHERE 1=1
					   AND DAT BETWEEN @V_FROM_DATE AND @V_TO_DATE
					   AND P.CURCY_TP_ID = @V_CURCY_TP_ID
					   AND (P.FROM_CURCY_CD_ID = @V_FROM_CURCY_CD_ID OR ISNULL(RTRIM(@V_FROM_CURCY_CD_ID),'')  = '')
					   AND (P.TO_CURCY_CD_ID = @V_TO_CURCY_CD_ID     OR ISNULL(RTRIM(@V_TO_CURCY_CD_ID)  ,'')  = '')
		               GROUP BY FROM_CURCY_CD_ID, F.COMN_CD, F.COMN_CD_NM, P.TO_CURCY_CD_ID, T.COMN_CD, T.COMN_CD_NM, DAT
				) B
			ON (M.FROM_CURCY_CD_ID = B.FROM_CURCY_CD_ID AND M.TO_CURCY_CD_ID = B.TO_CURCY_CD_ID AND M.BASE_DATE = B.BASE_DATE)
               ORDER BY FROM_CURCY_CD_ID, TO_CURCY_CD_ID, DAT
                ;
				END				
            ELSE
				BEGIN
				 SELECT 'NO BUCKET';
				END
	
END

go

