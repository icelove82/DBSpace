
CREATE PROCEDURE [dbo].[SP_UI_DP_CONBD_MASTER_SET_GRID] 
(	 
	 @P_PLAN_TP_ID			CHAR(32)
	,@P_ID					CHAR(32)
	,@P_WORK_CD				NVARCHAR(100)
	,@P_WORK_NM				NVARCHAR(240)
	,@P_SEQ					INT
	,@P_DESCRIP				NVARCHAR(3000)
	,@P_WORK_TP_ID			CHAR(32)
	,@P_LV_MGMT_ID			CHAR(32)
	,@P_USER_ID				NVARCHAR(240)
	,@P_RT_ROLLBACK_FLAG	NVARCHAR(10)   = 'true'  OUTPUT
	,@P_RT_MSG				NVARCHAR(4000) = ''		 OUTPUT
) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
/******************************************************************************************
	History (Date / Writer / Comment)
	- 2022.09.* / kimsohee / Draft
	- 2022.10.04 / kim sohee / add a param "WORK_TP_ID"
*******************************************************************************************/
BEGIN TRY 
DECLARE @P_MODULE_ID CHAR(32);
DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''

  SELECT @P_MODULE_ID = C.ID 
	FROM TB_AD_COMN_CODE C
		 INNER JOIN 
		 TB_AD_COMN_GRP G 
	   ON C.SRC_ID = G.ID 
	WHERE C.COMN_CD = 'DP' 
	  AND G.GRP_CD = 'MODULE_TP'
	  ;

	MERGE TB_DP_CONTROL_BOARD_MST TGT
	USING ( 
			SELECT  @P_ID				AS ID
				  , @P_WORK_CD			AS WORK_CD	
				  , @P_WORK_NM			AS WORK_NM			
				  , @P_SEQ				AS SEQ				
				  , @P_DESCRIP			AS DESCRIP
				  , @P_LV_MGMT_ID	    AS LV_MGMT_ID
				  , @P_USER_ID			AS USERNAME
		  ) SRC
	ON TGT.ID = SRC.ID	
	WHEN MATCHED THEN
		 UPDATE 
		   SET   TGT.WORK_NM		= SRC.WORK_NM						  
				,TGT.SEQ			= SRC.SEQ						  			  
				,TGT.DESCRIP		= SRC.DESCRIP					  
				,TGT.LV_MGMT_ID		= SRC.LV_MGMT_ID				  
				,TGT.MODIFY_BY		= SRC.USERNAME
				,TGT.MODIFY_DTTM	= GETDATE()       
	WHEN NOT MATCHED THEN 
		 INSERT (
				 ID
				,MODULE_ID
				,WORK_CD
				,WORK_NM
				,SEQ
				,DESCRIP
				,WORK_TP_ID
				,LV_MGMT_ID
				,DEL_YN
				,PLAN_TP_ID
				,CREATE_BY
				,CREATE_DTTM
				) 
		 VALUES (
				 (SELECT REPLACE(NEWID(),'-','') )
				,@P_MODULE_ID
				,SRC.WORK_CD	
				,SRC.WORK_NM				
				,SRC.SEQ	
				,SRC.DESCRIP				
				,COALESCE(@P_WORK_TP_ID, (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_CD = 'DP' AND CONF_GRP_CD = 'DP_WK_TP'))
				,SRC.LV_MGMT_ID
				,'N'			
				,@P_PLAN_TP_ID
				,SRC.USERNAME
				,GETDATE()       
				) 
				;    
END TRY 
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;
go

