/*****************************************************************************
Title : SP_DP_01_S1
최초 작성자 : 민희영
최초 생성일 : 2017.06.20
 
설명 
 - DP Configuration
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 민희영 / 최초 작성
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_01_S1]  (
									   @p_ID				NVARCHAR(32)	= ''
									  ,@p_MODULE_CD         NVARCHAR(30)    = ''         
									  ,@p_GRP_CONF_NM       NVARCHAR(50)    = ''	-- GRP_CONF_CD								          
									  ,@P_CONF_KEY          NVARCHAR(50)    = ''	-- CONF_KEY      
									  ,@p_DESCRIP		    NVARCHAR(200)	= ''
									  ,@p_USER_ID           NVARCHAR(100)   = ''  
									  ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)    = 'true'  OUTPUT
									  ,@P_RT_MSG            NVARCHAR(4000)  = ''	  OUTPUT
					                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE  
		 @P_ERR_STATUS INT = 0
        ,@P_ERR_MSG NVARCHAR(4000)=''
		,@V_TEST INT = 0

		,@V_ID		    NVARCHAR(32)
		,@V_MODULE_CD   NVARCHAR(30)
		,@V_GRP_CONF_NM NVARCHAR(50)
		,@V_CONF_KEY   	NVARCHAR(50)
		,@V_DESCRIP		NVARCHAR(200)
		,@V_USER_ID    	NVARCHAR(100)

SET @V_ID			= @p_ID
SET @V_MODULE_CD	= @p_MODULE_CD
SET @V_GRP_CONF_NM	= @p_GRP_CONF_NM
SET @V_CONF_KEY		= @P_CONF_KEY
SET @V_DESCRIP		= @p_DESCRIP
SET @V_USER_ID		= @p_USER_ID

BEGIN TRY
--	SET @V_TEST = 'TEST_ERROR'
/**(1) MODULE CD, MODULE NM Validation **********************************************/
IF (ISNULL(@V_MODULE_CD,'')= '')
	BEGIN
		SET @P_ERR_MSG = 'MSG_5024'
		RAISERROR (@P_ERR_MSG,11, 1);		
	END
/**(2) CONF KEY Validation *********************************************************/
	BEGIN	
				-- (1) 기존 MODULE CD 찾아 UI에서 입력한 MODULE TP와 비교
				DECLARE @P_DEFAULT_TYPE NVARCHAR(10) = ''
				SELECT @P_DEFAULT_TYPE = MODULE_CD
				FROM TB_CM_CONFIGURATION
				WHERE ID = @V_ID
				IF(@V_MODULE_CD != @P_DEFAULT_TYPE)
					--(1-1)  새로 입력한 MODULE CD 가 기존의 MODULE CD와 다르다면	새로운 CONF_KEY		
					SELECT @V_CONF_KEY = CASE COUNT(C.CONF_KEY)
						       WHEN 0 THEN 101            -- 최초 생성 시
						       ELSE MAX(C.CONF_KEY)+1
						   END 
					FROM TB_AD_COMN_GRP A 
						 INNER JOIN
						 TB_AD_COMN_CODE B 
					  ON (A.ID = B.SRC_ID)
						 INNER JOIN
						 TB_CM_CONFIGURATION C 
					  ON (C.MODULE_CD = B.COMN_CD)
				   WHERE 1=1
				     AND A.GRP_CD = 'MODULE_TP'
				     AND B.COMN_CD = @V_MODULE_CD
				ELSE     
					-- (1-2) 새로 입력한 MODULE CD 가 기존의 MODULE CD와 같다면 기존의 CONF_KEY		
					SELECT @V_CONF_KEY = C.CONF_KEY	
					FROM TB_AD_COMN_GRP A 
						 INNER JOIN
						 TB_AD_COMN_CODE B 
					  ON (A.ID = B.SRC_ID)
						 INNER JOIN
						 TB_CM_CONFIGURATION C
					  ON (C.MODULE_CD = B.COMN_CD)
				   WHERE 1=1
				     AND A.GRP_CD = 'MODULE_TP'
					 AND C.ID =	@V_ID			     		   
			END

IF (ISNULL(@V_CONF_KEY, '')='')
	BEGIN
		SET @P_ERR_MSG = 'MSG_5025'
		RAISERROR (@P_ERR_MSG,11, 1);		
	END
/***(3) GRP CONF NM Validation *****************************************************/
	SELECT @P_ERR_STATUS = COUNT(A.CONF_NM)	
	  FROM TB_CM_CONFIGURATION A
		   INNER JOIN
		   TB_AD_COMN_CODE B
		ON (A.MODULE_CD = B.COMN_CD)
		   INNER JOIN
		   TB_AD_COMN_GRP C
		ON (B.SRC_ID = C.ID)
	 WHERE 1=1
	   AND A.MODULE_CD = @V_MODULE_CD
	   AND C.GRP_CD = 'MODULE_TP'
	   AND A.CONF_NM = @V_GRP_CONF_NM
	   AND CONF_KEY != @V_CONF_KEY
IF(@P_ERR_STATUS != 0)
	BEGIN
		SET @P_ERR_MSG = 'MSG_5026'
		RAISERROR (@P_ERR_MSG,11, 1);	
	END 





  

	  -- 프로시저 시작 
		-- 수정
		MERGE [TB_CM_CONFIGURATION] TGT		
		USING (		SELECT
					 @V_ID				 AS ID
					,@V_MODULE_CD        AS MODULE_CD       
					,@V_GRP_CONF_NM      AS CONF_CD   
					,@V_CONF_KEY         AS CONF_KEY        
					,@V_GRP_CONF_NM+'_DESCRIP'  	 AS DESCRIP		  
--					,@V_DESCRIP		  	 AS DESCRIP		  
					,@V_USER_ID          AS USER_ID         	
			  ) SRC
		 ON (TGT.ID = SRC.ID)
		 WHEN MATCHED THEN
				 UPDATE       
				SET  TGT.MODULE_CD		 = @V_MODULE_CD
					,TGT.CONF_NM		 = @V_GRP_CONF_NM
					,TGT.DESCRIP		 = @V_DESCRIP
					,TGT.MODIFY_BY		 = @V_USER_ID
					,TGT.MODIFY_DTTM	 = GETDATE()       
		WHEN NOT MATCHED THEN
				INSERT (
					 ID				  
					,MODULE_CD		  
					,CONF_KEY		  
					,CONF_NM		  
					,DESCRIP		  
					,CREATE_BY		  
					,CREATE_DTTM	  
					,MODIFY_BY		  
					,MODIFY_DTTM      
					   )
			    VALUES(
					 REPLACE(NEWID(),'-','')
					,@V_MODULE_CD
					,CONF_KEY
					,@V_GRP_CONF_NM
					,SRC.DESCRIP
					,@V_USER_ID
					,GETDATE()
					,NULL
					,NULL
					  )
					  ;
	  -- 프로시저 종료 
                -- Description Langpack 처리
                MERGE INTO TB_AD_LANG_PACK TGT
                USING(
                        SELECT UPPER(@p_GRP_CONF_NM)+'_DESCRIP' AS LANG_KEY
                              ,@P_DESCRIP                    AS LANG_VALUE
                              ,'en'                         AS LANG_CD
                     ) SRC 
                ON (SRC.LANG_KEY = TGT.LANG_KEY AND SRC.LANG_CD = TGT.LANG_CD)
                WHEN NOT MATCHED THEN
                    INSERT (
                                LANG_KEY
                               ,LANG_VALUE
                               ,LANG_CD
                            )
                    VALUES (
                                SRC.LANG_KEY
                               ,SRC.LANG_VALUE
                               ,SRC.LANG_CD
                            )
                            ;
	  /* 하단 그리드의 Group Configuration Column도 함께 수정*/
	  IF EXISTS(SELECT CONF_GRP_CD FROM TB_CM_COMM_CONFIG WHERE CONF_ID = @V_ID)
		  BEGIN
			  DECLARE @V_GRP_CONF_NM_PREV NVARCHAR(50) = '' -- 이전 GRP_CONF_NM 값
			  SELECT @V_GRP_CONF_NM_PREV = CONF_GRP_CD
			    FROM TB_CM_COMM_CONFIG
			   WHERE CONF_ID = @V_ID
			   GROUP BY CONF_GRP_CD

			   -- @V_GRP_CONF_NM_PREV 이 변경됐을 경우에만 처리
			   IF (@V_GRP_CONF_NM_PREV != @V_GRP_CONF_NM)
			   BEGIN
				  -- LANG PACK 에 기존에 존재하면 UPDATGE
				  IF EXISTS(
							  SELECT A.LANG_KEY
								FROM TB_AD_LANG_PACK A
							   WHERE A.LANG_CD = 'en' AND A.LANG_KEY LIKE 'CF_'+@V_GRP_CONF_NM_PREV+'_%'
						   )
							BEGIN
								-- UPDATE
							  UPDATE A
								 SET A.LANG_KEY = REPLACE(A.LANG_KEY, @v_GRP_CONF_NM_PREV, @V_GRP_CONF_NM)
								FROM TB_AD_LANG_PACK A
							   WHERE A.LANG_CD = 'en' AND A.LANG_KEY LIKE 'CF_'+@V_GRP_CONF_NM_PREV+'_%'
							END
				  -- CONF_GRP_CD 값 변경
				  UPDATE TB_CM_COMM_CONFIG
				  SET CONF_GRP_CD = @V_GRP_CONF_NM	
				  WHERE CONF_ID = @V_ID
			   END

		  END
     
		              
	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY

BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;






go

