CREATE PROCEDURE [dbo].[SP_UI_CM_21_S1] (	
	 @P_DAT_ID			NVARCHAR(100)	-- No use
	,@P_DAT				DATE		
	,@P_HOLID_YN		CHAR(1)
	,@P_HOLID_NM		NVARCHAR(100)		
	,@P_HOLID_DESCRIP	NVARCHAR(100)		
	,@P_WORK_YN			CHAR(1)			
	,@P_USER_ID			NVARCHAR(25)
	,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)    = 'true'  OUTPUT
	 ,@P_RT_MSG            NVARCHAR(4000)  = ''	  OUTPUT
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
/*******************************************************************************************************
	 -- SP_UI_CM_21_S1 
	 -- Calendar save procedure (only update query)

	 -- HISTORY ( date / writer / comment)
	 -- 2019.11.19 / KSH / draft
********************************************************************************************************/		
DECLARE  
		 @P_ERR_STATUS INT = 0
        ,@P_ERR_MSG NVARCHAR(4000)=''
BEGIN TRY
		IF(@P_DAT IS NULL)
		BEGIN
			SET @P_ERR_MSG = 'Date is none'
			RAISERROR (@P_ERR_MSG,12, 1);			
		END
		IF(@P_DAT_ID IS NULL)
		BEGIN
			SET @P_DAT_ID = CONVERT(CHAR(8), @P_DAT ,112)
		END
		 -- Calender Update
		 UPDATE TB_CM_CALENDAR
			SET HOLID_YN	  = @P_HOLID_YN
			  , HOLID_NM	  = @P_HOLID_NM		
			  , HOLID_DESCRIP = @P_HOLID_DESCRIP		
			  , WORK_YN		  = @P_WORK_YN		
			  , MODIFY_BY     = @P_USER_ID
			  , MODIFY_DTTM   = GETDATE()
		  WHERE DAT_ID = @P_DAT_ID
/*******************************************************************************************************
		 -- BF Factor Calculating (Base Column : WORK_YN) 
********************************************************************************************************/		 
		DECLARE @V_DAT DATE = @P_DAT	-- '20100101'
			   ,@V_PR_WK_DAY DATE 
			   ,@V_NX_WK_DAY DATE 
		SELECT @V_NX_WK_DAY = MIN(DAT) 
		  FROM TB_CM_CALENDAR
		WHERE DAT > @V_dAT 
		  AND WORK_YN = 'N'
		SELECT @V_PR_WK_DAY = MAX(DAT)
		  FROM TB_CM_CALENDAR
		WHERE DAT < @V_dAT 
		  AND WORK_YN = 'N'
		;
WITH 
SRC
AS ( 	 
	 SELECT DAT_ID, DAT, PR_HOLID, NX_HOLID
	 	   ,CASE WHEN WORK_YN = 'N' THEN 0
	 	       WHEN LEAD(WORK_YN,1) OVER ( ORDER BY DAT ASC ) = 'N' THEN 1
	 	       WHEN LEAD(WORK_YN,2) OVER ( ORDER BY DAT ASC ) = 'N' THEN 2
	 	       WHEN LEAD(WORK_YN,3) OVER ( ORDER BY DAT ASC ) = 'N' THEN 3
	 	       WHEN LEAD(WORK_YN,4) OVER ( ORDER BY DAT ASC ) = 'N' THEN 4
	 	       WHEN LEAD(WORK_YN,5) OVER ( ORDER BY DAT ASC ) = 'N' THEN 5
	 	       WHEN LEAD(WORK_YN,6) OVER ( ORDER BY DAT ASC ) = 'N' THEN 6
	 	       WHEN LEAD(WORK_YN,7) OVER ( ORDER BY DAT ASC ) = 'N' THEN 7
	 	    ELSE 8 END  AS PR_HOLID_CAL
	 	   ,CASE WHEN WORK_YN = 'N' THEN 0
	 	       WHEN LAG(WORK_YN,1) OVER ( ORDER BY DAT ASC ) = 'N' THEN 1
	 	       WHEN LAG(WORK_YN,2) OVER ( ORDER BY DAT ASC ) = 'N' THEN 2
	 	       WHEN LAG(WORK_YN,3) OVER ( ORDER BY DAT ASC ) = 'N' THEN 3
	 	       WHEN LAG(WORK_YN,4) OVER ( ORDER BY DAT ASC ) = 'N' THEN 4
	 	       WHEN LAG(WORK_YN,5) OVER ( ORDER BY DAT ASC ) = 'N' THEN 5
	 	       WHEN LAG(WORK_YN,6) OVER ( ORDER BY DAT ASC ) = 'N' THEN 6
	 	       WHEN LAG(WORK_YN,7) OVER ( ORDER BY DAT ASC ) = 'N' THEN 7
	 	    ELSE 8 END  AS NX_HOLID_CAL
	   FROM TB_CM_CALENDAR
	  WHERE DAT BETWEEN @V_PR_WK_DAY AND @V_NX_WK_DAY --'20191101' AND '20191130' --					
   )
UPDATE TB_CM_CALENDAR
   SET PR_HOLID = SRC.PR_HOLID_CAL
	,  NX_HOLID = SRC.NX_HOLID_CAL 
  FROM SRC 
 WHERE (SRC.PR_HOLID != SRC.PR_HOLID_CAL
    OR SRC.NX_HOLID != SRC.NX_HOLID_CAL)
   AND TB_CM_CALENDAR.DAT_ID = SRC.DAT_ID
  
		              
	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY

BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;




go

