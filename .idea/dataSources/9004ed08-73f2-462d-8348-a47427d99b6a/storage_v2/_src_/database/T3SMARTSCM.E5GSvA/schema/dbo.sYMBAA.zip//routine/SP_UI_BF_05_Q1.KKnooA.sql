CREATE PROCEDURE [dbo].[SP_UI_BF_05_Q1]
(
	@p_FROM_DATE	date
  , @p_TO_DATE		date
  , @p_ITEM_CD		NVARCHAR(100)  
  , @p_ITEM_NM		NVARCHAR(240)  
  , @p_ACCOUNT_CD	NVARCHAR(100)  
  , @p_ACCOUNT_NM	NVARCHAR(240)  
  , @p_STATUS		NVARCHAR(50)  
--  , @p_OUTLIER_YN	CHAR(1)
)
AS 
SET NOCOUNT ON
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
/*  
	Load Correction of Actual Sales
	
	History (date / writer / comment)
	-- 2020.02.03 / kim sohee / Status로 구분 되어있던 IF문을 CASE WHEN 으로 변경 
							  / CORRECTION_COMMENT 를 Code로 보여주게 변경 	
    -- 2020.03.08 / Yeunkyung Nam / DP_WK 으로 group by 한 결과 조회
                                  / base_date 는 TB_CM_CALENDAR 의 DP_WK 첫번 째 날짜 (월요일)
                                  / ID 는 TB_CM_ACTUAL_SALES 의 DP_WK 첫 번 째 실적 ID
*/
BEGIN	

    WITH DP_WK AS (
    SELECT D.DP_WK
         , MIN(D.DAT) AS MON_DT
         , DATEPART(WEEKDAY,MIN(D.DAT)) AS WK_NUM
      FROM TB_CM_CALENDAR D WITH(NOLOCK)
     WHERE D.DAT BETWEEN DATEADD(WK,-1,@p_FROM_DATE) AND @p_TO_DATE
     GROUP BY D.DP_WK HAVING DATEPART(WEEKDAY,MIN(D.DAT)) = 2
    )
    
    SELECT T.ID
         , M.ACCOUNT_CD
         , M.ACCOUNT_NM
         , M.ITEM_CD
         , M.ITEM_NM
         , M.MON_DT AS BASE_DATE
         , NULL AS [STATUS]
         , M.QTY
         , M.QTY_CORRECTION
         , T.CORRECTION_COMMENT
         , T.MODIFY_BY
         , T.MODIFY_DTTM
      FROM (
    	   SELECT L.ACCOUNT_ID
                , A.ACCOUNT_CD AS ACCOUNT_CD
                , A.ACCOUNT_NM AS ACCOUNT_NM
                , L.ITEM_MST_ID
                , I.ITEM_CD AS ITEM_CD
                , I.ITEM_NM AS ITEM_NM
                , MIN(L.BASE_DATE) AS MIN_DT
                , SUM(L.QTY) AS QTY
                , SUM(L.QTY_CORRECTION) AS QTY_CORRECTION
                , W.DP_WK
                , W.MON_DT
    	     FROM TB_CM_ACTUAL_SALES L
                  INNER JOIN TB_CM_CALENDAR CAL WITH(NOLOCK) ON L.BASE_DATE = CAL.DAT
                  INNER JOIN DP_WK W ON W.DP_WK = CAL.DP_WK
    	          INNER JOIN TB_DP_ACCOUNT_MST A ON L.ACCOUNT_ID = A.ID
    	          INNER JOIN TB_CM_ITEM_MST I ON L.ITEM_MST_ID = I.ID
    	          INNER JOIN TB_CM_COMM_CONFIG C ON L.SO_STATUS_ID = C.ID --AND C.CONF_GRP_CD='DP_SO_STATUS'
    
    	    WHERE 1=1
    	      AND (  ( @P_ACCOUNT_CD LIKE '%|%' AND UPPER(A.ACCOUNT_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_CD),''),'|')) 
    	   		)OR(@P_ACCOUNT_CD NOT LIKE '%|%' AND UPPER(A.ACCOUNT_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
    	   		OR @p_ACCOUNT_CD IS NULL 
    	   	   )
    	      AND (  ( @P_ACCOUNT_NM LIKE '%|%' AND UPPER(A.ACCOUNT_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ACCOUNT_NM),''),'|')) 
    	   		)OR(@P_ACCOUNT_NM NOT LIKE '%|%' AND UPPER(A.ACCOUNT_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCOUNT_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
    	   		OR @P_ACCOUNT_NM IS NULL 
    	   	   )
    	      AND (  ( @P_ITEM_CD LIKE '%|%' AND UPPER(I.ITEM_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_CD),''),'|')) 
    	   		)OR(@P_ITEM_CD NOT LIKE '%|%' AND UPPER(I.ITEM_CD)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_CD),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
    	   		OR @P_ITEM_CD IS NULL 
    	   	   )
    	      AND (  ( @P_ITEM_NM LIKE '%|%' AND UPPER(I.ITEM_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@P_ITEM_NM),''),'|')) 
    	   		)OR(@P_ITEM_NM NOT LIKE '%|%' AND UPPER(I.ITEM_NM)  LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_NM),'[','#['),']','#]'),')','#)'),'(','#(') + '%' ESCAPE '#' )
    	   		OR @P_ITEM_NM IS NULL 
    	   	   )
    --	      AND (BASE_DATE BETWEEN @P_FROM_DATE AND @P_TO_DATE )
    	      AND CASE WHEN @p_STATUS = 'ALL' THEN 'ALL' 
    	      			WHEn @p_STATUS = '' THEN ''
    	      			ELSE C.CONF_CD END = @p_STATUS
            GROUP BY L.ITEM_MST_ID
                   , L.ACCOUNT_ID
                   , I.ITEM_CD
                   , I.ITEM_NM
                   , A.ACCOUNT_CD
                   , A.ACCOUNT_NM
                   , W.DP_WK
                   , W.MON_DT
          ) M
          CROSS APPLY (
                       SELECT TOP 1 S.ID,ISNULL(R.CONF_CD, 'NN') AS CORRECTION_COMMENT, S.MODIFY_BY, S.MODIFY_DTTM
                         FROM TB_CM_ACTUAL_SALES S WITH(NOLOCK)
                      	       LEFT OUTER JOIN TB_CM_COMM_CONFIG R ON S.CORRECTION_COMMENT_ID = R.ID
                        WHERE M.ITEM_MST_ID = S.ITEM_MST_ID
                          AND M.ACCOUNT_ID  = S.ACCOUNT_ID
                          AND M.MIN_DT      = S.BASE_DATE
                        ORDER BY S.ID
                       ) T
    WHERE 1=1
      AND M.MON_DT BETWEEN @P_FROM_DATE AND @P_TO_DATE 
    ORDER BY ITEM_CD, ACCOUNT_CD, MON_DT
    ;
END

go

