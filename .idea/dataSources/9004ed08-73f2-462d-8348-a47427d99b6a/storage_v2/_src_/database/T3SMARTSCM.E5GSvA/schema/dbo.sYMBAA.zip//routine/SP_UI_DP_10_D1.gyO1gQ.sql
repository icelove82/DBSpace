/*****************************************************************************
Title : SP_DP_10_D1
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP Sales Hierarchy Management
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_10_D1]  (
                                        @p_ID                   NVARCHAR(32)      = ''         
									   ,@p_USER_ID              NVARCHAR(100)     = '' 

									  ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'  OUTPUT
									  ,@P_RT_MSG            NVARCHAR(4000) = ''		 OUTPUT		
					                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON 
DECLARE	 @P_ERR_STATUS INT = 0
        ,@P_ERR_MSG NVARCHAR(4000)=''
BEGIN TRY

	  -- 프로시저 시작 

	  --   UPDATE  TB_DP_SALES_LEVEL_MGMT
		 --SET     DEL_YN = 'Y'
			--	,ACTV_YN = 'N'
		 --        , MODIFY_BY = @p_USER_ID
			--	 , MODIFY_DTTM = GETDATE() 
		 --WHERE ID = @p_ID
   --      ; 
		DELETE FROM TB_DP_SALES_LEVEL_MGMT
		      WHERE ID = @p_ID
	  -- 프로시저 종료 




		              
	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0002'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;


go

