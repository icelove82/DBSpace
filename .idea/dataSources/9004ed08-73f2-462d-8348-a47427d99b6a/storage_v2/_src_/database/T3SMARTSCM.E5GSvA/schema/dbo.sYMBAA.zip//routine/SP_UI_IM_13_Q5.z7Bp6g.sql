CREATE PROCEDURE [dbo].[SP_UI_IM_13_Q5] (
	@P_INTRANSIT_INV_MST_ID char(32)
)
AS
/*****************************************************************************
Title : SP_UI_IM_13_Q5
최초 작성자 : 한영석
최초 생성일 : 2017.09.19
 
설명 
 -  
History (수정일자 / 수정자 / 수정내용)
- 2017.09.19 / 한영석 / 최초 작성
 
*****************************************************************************/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	SELECT ID 
			,INTRANSIT_INV_MST_ID 
			,INV_QTY_TP_ID 
			,(SELECT INV_QTY_TP_NM 
				FROM   TB_IM_STOCK_QTY_TYPE A 
				WHERE  A.ID = INV_QTY_TP_ID) AS [INV_QTY_TP_NM] 
			,PLAN_YN 
			,QTY 
			,ACTV_YN 
			,CREATE_BY 
			,CREATE_DTTM 
			,MODIFY_BY 
			,MODIFY_DTTM 
	FROM   TB_CM_INTRANSIT_STOCK_QTY A 
	WHERE  A.INTRANSIT_INV_MST_ID = @P_INTRANSIT_INV_MST_ID

go

