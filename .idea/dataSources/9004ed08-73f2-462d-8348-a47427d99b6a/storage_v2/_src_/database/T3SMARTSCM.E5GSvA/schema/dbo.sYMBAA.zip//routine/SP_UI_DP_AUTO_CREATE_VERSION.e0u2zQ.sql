CREATE PROCEDURE [dbo].[SP_UI_DP_AUTO_CREATE_VERSION] 
(	 @P_VER_CD		NVARCHAR(100)	--  'DPM-20211229-001-00-W52'
   , @p_STRT_DATE   DATE 
   , @P_END_DATE    DATE 
   , @P_DTF_DATE    DATE 
	-- Make new Version code by Internal Service, called "CreateVersion"
)
AS 
BEGIN

/*****************************************************************************************************
	[SP_UI_DP_AUTO_CREATE_VERSION]
	Description : Version Auto Create
	Service : MakeDemandPlanVersion	

	History ( date / writer / comment )
	- 2021.12.29 / kim sohee / draft
	- 2022.11.17 / kim sohee / param add 
******************************************************************************************************/
	-- You need to define parameters (Price type, Currency type, User ID).
	DECLARE @V_PRICE_TYPE		NVARCHAR(100) = (SELECT TOP 1 ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD ='DP_PRICE_TYPE' AND ACTV_YN = 'Y' AND USE_YN = 'Y' )
		  , @V_CURRENCY_TYPE	NVARCHAR(100) = (SELECT TOP 1 ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD ='DP_CURRENCY_TYPE' AND ACTV_YN = 'Y' AND USE_YN = 'Y')		  
		  , @P_USER_ID		NVARCHAR(250) = 'system'
	-- out params for executing procedures
	DECLARE @V_RT_ROLLBACK_FLAG			 NVARCHAR(10)
	DECLARE @V_RT_MSG					 NVARCHAR(3000)

/*****************************************************************************************************
	-- (2) get period & bucket info by config
			to call SP_UI_DP_23_VER_CREATE_S1
******************************************************************************************************/
	DECLARE	@V_TODAY DATE = GETDATE()
		  , @V_PLAN_TP_ID CHAR(32) = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD ='DP_PLAN_TYPE' AND ATTR_01 = 'M')
	
	DECLARE @TB_TMP_PERIOD_BUKT_INFO TABLE
		(	 VER_BUCLET			NVARCHAR(10)
			,VER_HORIZON		INT
			,VER_DTF			INT
			,VER_STAT_BUCKET	INT
			,VER_FROM_DATE		DATE
			,VER_TO_DATE		DATE
			,PAR_DATE			DATE
			,PAR_BUCKET			NVARCHAR(10)
			,PAR_HORIZON		INT
			,DTF_DATE			DATE
			,PAR_DATE2			DATE
			,PAR_BUCKET2		NVARCHAR(10)
			,PAR_HORIZON2		INT
			,PAR_TO_DATE		DATE	-- 안쓰임
			,PAR_TO_DATE2		DATE	-- 안쓰임
			,STD_WEEK			NVARCHAR(3)
		)

	INSERT INTO @TB_TMP_PERIOD_BUKT_INFO
		(	VER_BUCLET			
		  , VER_HORIZON		
		  , VER_DTF			
		  , VER_STAT_BUCKET			
		)
	EXEC SP_UI_DP_23_VER_POP_Q1 @V_PLAN_TP_ID
	;

	INSERT INTO @TB_TMP_PERIOD_BUKT_INFO 
		 (  VER_FROM_DATE	
		  , VER_TO_DATE	
		  , PAR_DATE		
		  , PAR_BUCKET		
		  , PAR_HORIZON	
		  , DTF_DATE		
		  , PAR_DATE2		
		  , PAR_BUCKET2	
		  , PAR_HORIZON2	
		  , PAR_TO_DATE	
		  , PAR_TO_DATE2	
		  , STD_WEEK			
		 )
	EXEC [SP_UI_DP_23_VER_POP_Q3]
		 'OPEN',	-- It's same to open pop-up (Control Board version pop-up)
		 @V_TODAY,
		 NULL,
		 @V_TODAY,
		 @V_PLAN_TP_ID


/*****************************************************************************************************
	-- (3) create Version : call SP_UI_DP_23_VER_CREATE_S1
******************************************************************************************************/
	DECLARE @V_VER_BUCKET		NVARCHAR(50)
	DECLARE @V_VER_HORIZON		NVARCHAR(50)
	DECLARE @V_VER_DTF			NVARCHAR(50)
	DECLARE @V_VER_STAT_BUCKET	NVARCHAR(50)
	DECLARE @V_VER_FROM_DATE	DATE
	DECLARE @V_VER_TO_DATE		DATE
	DECLARE @V_PARTIAL_DATE		DATE
	DECLARE @V_PARTIAL_BUCKET	NVARCHAR(100)
	DECLARE @V_PARTIAL_HORIZON  NVARCHAR(100)
	DECLARE @V_VER_DTF_DATE		DATE
	DECLARE @V_PARTIAL_DATE2	DATE
	DECLARE @V_PARTIAL_BUCKET2  NVARCHAR(100)
	DECLARE @V_PARTIAL_HORIZON2 NVARCHAR(100)

	SELECT  @V_VER_BUCKET		 = MAX(VER_BUCLET	)
		   ,@V_VER_HORIZON		 = MAX(VER_HORIZON	)
		   ,@V_VER_DTF			 = MAX(VER_DTF		)
		   ,@V_VER_STAT_BUCKET	 = MAX(VER_STAT_BUCKET)
		   ,@V_VER_FROM_DATE	 = COALESCE(@p_STRT_DATE, MAX(VER_FROM_DATE))
		   ,@V_VER_TO_DATE		 = COALESCE(@p_END_DATE, MAX(VER_TO_DATE)	)
		   ,@V_PARTIAL_DATE		 = MAX(PAR_DATE	)
		   ,@V_PARTIAL_BUCKET	 = MAX(PAR_BUCKET	)
		   ,@V_PARTIAL_HORIZON   = MAX(PAR_HORIZON	)
		   ,@V_VER_DTF_DATE		 = COALESCE(@P_DTF_DATE, MAX(DTF_DATE	))
		   ,@V_PARTIAL_DATE2	 = MAX(PAR_DATE2	)
		   ,@V_PARTIAL_BUCKET2   = MAX(PAR_BUCKET2	)
		   ,@V_PARTIAL_HORIZON2  = MAX(PAR_HORIZON2)
	  FROM @TB_TMP_PERIOD_BUKT_INFO
	  ;
	
	

	EXECUTE [SP_UI_DP_23_VER_CREATE_S1]
			 @P_VER_CD
			,@V_VER_BUCKET
			,@V_VER_HORIZON
			,@V_VER_FROM_DATE
			,@V_VER_TO_DATE
			,@V_VER_DTF
			,@V_VER_DTF_DATE
			,@V_VER_STAT_BUCKET
			,NULL	-- description 
			,@V_PARTIAL_BUCKET
			,@V_PARTIAL_HORIZON
			,@V_PARTIAL_DATE
			,@V_PARTIAL_BUCKET2
			,@V_PARTIAL_HORIZON2
			,@V_PARTIAL_DATE2
			,@V_PLAN_TP_ID
			,@V_PRICE_TYPE
			,@V_CURRENCY_TYPE
			,@P_USER_ID
			,@V_RT_ROLLBACK_FLAG OUTPUT
			,@V_RT_MSG			 OUTPUT

/*****************************************************************************************************
	-- (4) get Control board Version Detail
		to call SP_UI_DP_23_VER_CREATE_S2
******************************************************************************************************/
	DECLARE @TB_TMP_VER_DETAIL TABLE
	(	 ID							CHAR(32)
		,MODULE_ID					CHAR(32)
		,WORK_CD					NVARCHAR(30)
		,WORK_NM					NVARCHAR(240)
		,SEQ						INT
		,DESCRIP					NVARCHAR(3000)
		,WORK_TP_ID					CHAR(32)
		,LINK						NVARCHAR(1000)
		,LV_MGMT_ID					CHAR(32)
		,INIT_VAL_TP_ID				CHAR(32)
		,INIT_VAL_ID				CHAR(32)
		,INPUT_TP_ID				CHAR(32)
		,CONST_INPUT_YN				CHAR(1)
		,INIT_CONST_INPUT_VAL		INT
		,INIT_CONST_INPUT_TIME_VAL	INT
		,INIT_CONST_INPUT_DATETIME	DATETIME
		,APPV_CONST_ID				CHAR(32)
		,APPV_EVENT_ID				CHAR(32)
		,AUTO_APPV_YN				CHAR(1)
		,INIT_AUTO_APPV_VAL			INT
		,INIT_AUTO_APPV_TIME_VAL	INT
		,INIT_AUTO_APPV_DATETIME	DATETIME
		,CANC_CONST_ID				CHAR(32)
		,CANC_EVENT_ID				CHAR(32)
		,CL_TP_ID					CHAR(32)
		,CL_LV_MGMT_ID				CHAR(32)
		,CREATE_BY					NVARCHAR(100)
		,CREATE_DTTM				DATETIME
		,MODIFY_BY					NVARCHAR(100)
		,MODIFY_DTTM				DATETIME
	)
	INSERT INTO @TB_TMP_VER_DETAIL
	EXEC [SP_UI_DP_23_VER_POP_Q2]
		 @V_PLAN_TP_ID,
		 @V_TODAY	
/*****************************************************************************************************
	-- (5) Create Version Detail : call SP_UI_DP_23_VER_CREATE_S2
******************************************************************************************************/
	-- execute procedure parameters
	DECLARE @V_CNTRL_BOARD_MST_ID		 CHAR(32)
	DECLARE @V_MODULE_ID				 NVARCHAR(100)
	DECLARE @V_WORK_CD					 NVARCHAR(100)
	DECLARE @V_WORK_NM					 NVARCHAR(100)
	DECLARE @V_DESCRIP					 NVARCHAR(100)
	DECLARE @V_SEQ						 NVARCHAR(100)
	DECLARE @V_WORK_TP_ID				 CHAR(32)
	DECLARE @V_LINK						 NVARCHAR(100)
	DECLARE @V_LV_MGMT_ID				 CHAR(32)
	DECLARE @V_INIT_VAL_TP_ID			 CHAR(32)
	DECLARE @V_INIT_VAL_ID				 CHAR(32)
	DECLARE @V_INPUT_TP_ID				 CHAR(32)
	DECLARE @V_CONST_INPUT_YN			 NVARCHAR(1)
	DECLARE @V_INIT_CONST_INPUT_DATETIME DATETIME
	DECLARE @V_APPV_CONST_ID			 CHAR(32)
	DECLARE @V_APPV_EVENT_ID			 CHAR(32)
	DECLARE @V_AUTO_APPV_YN				 NVARCHAR(100)
	DECLARE @V_INIT_AUTO_APPV_DATETIME	 DATETIME
	DECLARE @V_CANC_CONST_ID			 CHAR(32)
	DECLARE @V_CANC_EVENT_ID			 CHAR(32)
	DECLARE @V_CL_TP_ID					 CHAR(32)
	DECLARE @V_CL_LV_MGMT_ID			 CHAR(32)

	DECLARE EXEC_CUR CURSOR FOR
	SELECT  MODULE_ID					
		  , WORK_CD					
		  , WORK_NM					
		  , SEQ						
		  , DESCRIP					
		  , WORK_TP_ID					
		  , LINK						
		  , LV_MGMT_ID					
		  , INIT_VAL_TP_ID				
		  , INIT_VAL_ID				
		  , INPUT_TP_ID				
		  , CONST_INPUT_YN				
		  , INIT_CONST_INPUT_DATETIME	
		  , APPV_CONST_ID				
		  , APPV_EVENT_ID				
		  , AUTO_APPV_YN				
		  , INIT_AUTO_APPV_DATETIME	
		  , CANC_CONST_ID				
		  , CANC_EVENT_ID				
		  , CL_TP_ID					
		  , CL_LV_MGMT_ID				
	  FROM @TB_TMP_VER_DETAIL
	  ORDER BY SEQ 
	;
	OPEN EXEC_CUR;

	WHILE 1=1
	BEGIN
		FETCH NEXT 
		 FROM EXEC_CUR
		 INTO @V_MODULE_ID				 
		     ,@V_WORK_CD					 
		     ,@V_WORK_NM					 
		     ,@V_SEQ						 
		     ,@V_DESCRIP					 
		     ,@V_WORK_TP_ID				 
		     ,@V_LINK						 
		     ,@V_LV_MGMT_ID				 
		     ,@V_INIT_VAL_TP_ID			 
		     ,@V_INIT_VAL_ID				 
		     ,@V_INPUT_TP_ID				 
		     ,@V_CONST_INPUT_YN			 
		     ,@V_INIT_CONST_INPUT_DATETIME 
		     ,@V_APPV_CONST_ID			 
		     ,@V_APPV_EVENT_ID			 
		     ,@V_AUTO_APPV_YN				 
		     ,@V_INIT_AUTO_APPV_DATETIME	 
		     ,@V_CANC_CONST_ID			 
		     ,@V_CANC_EVENT_ID			 
		     ,@V_CL_TP_ID					 
		     ,@V_CL_LV_MGMT_ID		
		 	;
		IF (@@FETCH_STATUS <> 0)
			BREAK;

		EXECUTE [SP_UI_DP_23_VER_CREATE_S2] 
			    @P_VER_CD
			  , @V_PLAN_TP_ID
			  , @V_CNTRL_BOARD_MST_ID
			  , @V_MODULE_ID
			  , @V_WORK_CD
			  , @V_WORK_NM
			  , @V_DESCRIP
			  , @V_SEQ
			  , @V_WORK_TP_ID
			  , @V_LINK
			  , @V_LV_MGMT_ID
			  , @V_INIT_VAL_TP_ID
			  , @V_INIT_VAL_ID
			  , @V_INPUT_TP_ID
			  , @V_CONST_INPUT_YN
			  , @V_INIT_CONST_INPUT_DATETIME
			  , @V_APPV_CONST_ID
			  , @V_APPV_EVENT_ID
			  , @V_AUTO_APPV_YN
			  , @V_INIT_AUTO_APPV_DATETIME
			  , @V_CANC_CONST_ID
			  , @V_CANC_EVENT_ID
			  , @V_CL_TP_ID
			  , @V_CL_LV_MGMT_ID
			  , @P_USER_ID
			  , @V_RT_ROLLBACK_FLAG OUTPUT
			  , @V_RT_MSG			OUTPUT	
	END
	;
	CLOSE EXEC_CUR;
	DEALLOCATE EXEC_CUR;
/*****************************************************************************************************
	-- (6) Create Entry Data
******************************************************************************************************/		
	EXECUTE SP_UI_DP_93_VER_CREATE_S3
			 @P_VER_CD
			,@V_PLAN_TP_ID
END
go

