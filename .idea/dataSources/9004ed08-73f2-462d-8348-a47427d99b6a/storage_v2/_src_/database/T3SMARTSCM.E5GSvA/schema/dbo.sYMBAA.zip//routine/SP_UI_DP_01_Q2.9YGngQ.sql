/*****************************************************************************
Title : SP_DP_01_Q2
최초 작성자 : 김소희
최초 생성일 : 2018.03.07
 
설명 
 - DP Configuration
 
History (수정일자 / 수정자 / 수정내용)
- 2018.03.07 / 김소희 / 첫번째 작성
- 2019.02.15 / 김소희 / Config data로 보이도록 수정 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_01_Q2] (
										@P_CONF_ID NVARCHAR(32) = ''
								   ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @V_CONF_ID NVARCHAR(32) = ''

SET @V_CONF_ID = @P_CONF_ID

BEGIN

SELECT  A.ID						AS ID			
	   ,A.CONF_ID					AS CONF_ID		
	   ,A.CONF_GRP_CD				AS CONF_GRP_CD	
	   ,A.CONF_CD					AS CONF_CD		
	   , 'CF_'+UPPER(A.CONF_GRP_CD)+'_'+UPPER(A.CONF_CD)	AS LANG_CONF_NM
--	   , 'CF_'+UPPER(A.CONF_GRP_CD)+'_'+UPPER(A.CONF_CD)	AS CONF_NM
	   ,A.CONF_NM					AS CONF_NM		
	   ,ISNULL(A.DEFAT_VAL ,'N')	AS DEFAT_VAL		
	   ,ISNULL(A.ACTV_YN   ,'N')	AS ACTV_YN		
	   ,A.PRIORT					AS PRIORT			
	   ,ISNULL(A.USE_YN,'N')		AS USE_YN		
	   , 'CF_'+UPPER(A.CONF_GRP_CD)+'_'+UPPER(A.CONF_CD)+'_DESCRIP'	AS LANG_DESCRIP
--	   , 'CF_'+UPPER(A.CONF_GRP_CD)+'_'+UPPER(A.CONF_CD)+'_DESCRIP'	AS DESCRIP
	   ,A.DESCRIP					AS DESCRIP		
	   ,A.ATTR_01					AS ATTR_01		
	   ,A.ATTR_02					AS ATTR_02		
	   ,A.ATTR_03					AS ATTR_03		
	   ,A.ATTR_04					AS ATTR_04		
	   ,A.ATTR_05					AS ATTR_05		
	   ,A.ATTR_06					AS ATTR_06		
	   ,A.ATTR_07					AS ATTR_07		
	   ,A.ATTR_08					AS ATTR_08		
	   ,A.ATTR_09					AS ATTR_09		
	   ,A.ATTR_10					AS ATTR_10		
	   ,A.CREATE_BY					AS CREATE_BY		
	   ,A.CREATE_DTTM				AS CREATE_DTTM	
	   ,A.MODIFY_BY					AS MODIFY_BY		
	   ,A.MODIFY_DTTM				AS MODIFY_DTTM	
 FROM TB_CM_COMM_CONFIG A 
      INNER JOIN
  	  TB_CM_CONFIGURATION B 
   ON (A.CONF_ID = B.ID)
WHERE 1=1
 AND B.ID = @V_CONF_ID
 order by  PRIORT


END





go

