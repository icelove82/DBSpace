
CREATE PROCEDURE [dbo].[SP_UI_BF_52_Q2] 
(
	@P_VER_ID	  NVARCHAR(100) = NULL,
	@P_ITEM_CD	  NVARCHAR(100) = NULL,
	@P_ACCOUNT_CD NVARCHAR(100) = NULL
)
AS 
/***************************************************************************************************************
	[BF Accuracy & Forecast Report]

	Load data of a chart which is dept between forecast and actual sales 

	Hitory (date / writer / comment)
	-- 2020.01.** / MKH / draft
	-- 2020.01.17 / KSH / TB_BF_RT => TB_BF_RT_HISTORY
						/ change method of getting qty by engine type
						/ devide actual sales by 4 weeks
	-- 2020.02.28 / kim sohee / change week rule : DP_WK (53 week per a year) 
	-- 2020.06.22 / 김소희 / 주차 외에 다른 버킷 단위로 조회 가능하게
**************************************************************************************************************/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
DECLARE @V_FROM_DATE DATE     = ''
	  , @V_TO_DATE   DATE     = ''
	  , @V_BUKT      NVARCHAR(10) = ''
      , @P_ACCURACY_WK		INT = 4


BEGIN

	--SELECT @V_BUKT      = TARGET_BUKT_CD 
	--	 , @V_FROM_DATE = INPUT_FROM_DATE
	--	 , @V_TO_DATE   = INPUT_TO_DATE  
	--  FROM (
	--	 SELECT DISTINCT  TARGET_BUKT_CD
	--				   ,  INPUT_TO_DATE
	--			   ,  (SELECT TOP 1 LEAD(MIN(DAT),4) OVER(ORDER BY DP_WK DESC) 
	--					 FROM TB_CM_CALENDAR 
	--					WHERE DAT BETWEEN DATEADD(MONTH, -1, DATEADD(DAY,+1,INPUT_TO_DATE)) 
	--					  AND DATEADD(DAY,+1,INPUT_TO_DATE)
	--					GROUP BY DP_WK
	--				  )  AS INPUT_FROM_DATE
	--		FROM TB_BF_CONTROL_BOARD_VER_DTL
	--	   WHERE VER_CD = @P_VER_ID
	--		 AND ENGINE_TP_CD IS NOT NULL
	--	) A


	SELECT DISTINCT @V_BUKT   = TARGET_BUKT_CD
				  , @V_TO_DATE   = INPUT_TO_DATE
				  , @V_FROM_DATE = (SELECT TOP 1 LEAD(MIN(DAT),@P_ACCURACY_WK) OVER(ORDER BY CASE WHEN TARGET_BUKT_CD='M' THEN MM ELSE DP_WK END  DESC) -- DP_WK DESC) 
										   FROM TB_CM_CALENDAR 
										  --WHERE DAT BETWEEN DATEADD(WEEK, @P_ACCURACY_WK*-1, DATEADD(DAY,+1,INPUT_TO_DATE)) 
										  WHERE DAT BETWEEN CASE WHEN TARGET_BUKT_CD='M' THEN DATEADD(MONTH, @P_ACCURACY_WK*-1, DATEADD(DAY,+1,INPUT_TO_DATE)) ELSE DATEADD(WEEK, @P_ACCURACY_WK*-1, DATEADD(DAY,+1,INPUT_TO_DATE)) END
											AND DATEADD(DAY,+1,INPUT_TO_DATE)
									   GROUP BY  CASE WHEN TARGET_BUKT_CD='M' THEN MM ELSE DP_WK END 
					 )
	 FROM TB_BF_CONTROL_BOARD_VER_DTL
    WHERE VER_CD = @P_VER_ID
	  AND ENGINE_TP_CD IS NOT NULL


		;

	/*************************************************************************************************************
		-- 주차 시작 요일 바꼈을 경우 대비해서 버전 날짜 범위 변경 처리
	************************************************************************************************************/

	IF (@V_BUKT = 'W')
	BEGIN
		SELECT --@P_FROM_dATE    = MIN(STRT_DATE),
			   @V_TO_DATE	   = MAX(END_DATE)
		  FROM (
				SELECT --YYYY
					  DP_WK
					 , MIN(DAT) AS STRT_DATE
					 , MAX(DAT) AS END_DATE
				  FROM TB_CM_CALENDAR C
				 WHERE DAT BETWEEN @V_FROM_DATE AND @V_TO_DATE
			  GROUP BY --YYYY, 
                        DP_WK
			  HAVING COUNT(DP_WK) >= 7
			  ) A
	END
	; 
	
WITH RT
AS (
	SELECT ITEM_CD
		 , ACCOUNT_CD
		 , BASE_DATE 
		 , ENGINE_TP_CD
		 , QTY
	  FROM TB_BF_RT_HISTORY RF
	 WHERE BASE_DATE BETWEEN @V_FROM_DATE and @V_TO_DATE
	   AND RF.ITEM_CD    = @P_ITEM_CD	 
	   AND RF.ACCOUNT_CD = @P_ACCOUNT_CD
), 
CALENDAR
AS (
	SELECT DAT 
         , YYYY
         , YYYYMM
         , YYYYMMDD
		 , CASE @V_BUKT
			WHEN 'W' THEN DATEPART(ISO_WEEK, DAT)
			WHEN 'PW'THEN DATEPART(ISO_WEEK, DAT)
			WHEN 'M' THEN YYYYMM
			--WHEN 'D' THEN YYYYMMDD 
		   END AS BUKT		
		 --, CASE WHEN @P_TARGET_BUKT_CD = 'W' THEN YYYY+'-'+CONVERT(NVARCHAR(2),(DP_WK % 52))
			--    WHEN @P_TARGET_BUKT_CD = 'M' THEN YYYYMM 
		 --  END AS BUKT 		 
	  FROM TB_CM_CALENDAR
	 WHERE DAT BETWEEN @V_FROM_DATE AND @V_TO_DATE

), CA
AS (
	SELECT MIN(DAT)	AS STRT_DATE
		,  MAX(DAT) AS END_DATE 
		--,  BUKT
           , CASE @V_BUKT
                WHEN 'W' THEN CONVERT(VARCHAR(4), MIN(YYYY)) + ' w' +REPLICATE('0', 2-LEN(BUKT)) + CONVERT(NVARCHAR(2), BUKT)
                WHEN 'PW' THEN CONVERT(VARCHAR(6), MIN(YYYYMM)) + ' w' +REPLICATE('0', 2-LEN(BUKT)) + CONVERT(NVARCHAR(2), BUKT)
                WHEN 'M' THEN CONVERT(VARCHAR(6), MIN(YYYYMM))
                --WHEN 'D' THEN CONVERT(VARCHAR(8), MIN(YYYYMMDD))
               END AS BUKT
	  FROM CALENDAR 
  GROUP BY BUKT
 )
--CA
--AS (
--	SELECT MIN(DAT)	 STRT_DATE
--		 , CASE @V_BUKT
--			WHEN 'W' THEN YYYY+' w'+CONVERT(NVARCHAR(2),DP_WK)
--			WHEN 'PW'THEN YYYYMM+' w'+CONVERT(NVARCHAR(2),DP_WK) 
--			WHEN 'M' THEN YYYYMM
--			WHEN 'D' THEN YYYYMMDD 
--		   END AS BUKT	
--		 , MAX(DAT)	 END_DATE
--	  FROM TB_CM_CALENDAR CA
--	 WHERE DAT between @V_FROM_DATE and @V_TO_DATE 
--   GROUP BY CASE @V_BUKT
--			WHEN 'W' THEN YYYY+' w'+CONVERT(NVARCHAR(2),DP_WK)
--			WHEN 'PW'THEN YYYYMM+' w'+CONVERT(NVARCHAR(2),DP_WK) 
--			WHEN 'M' THEN YYYYMM
--			WHEN 'D' THEN YYYYMMDD 
--		   END  
--)
, SA
AS (
	SELECT ITEM_CD
		  , ACCOUNT_CD
		  , CA.BUKT 
		  , CA.STRT_DATE
		  , SUM(QTY)	QTY 
	  FROM TB_CM_ACTUAL_SALES S
	       INNER JOIN
		   CA
		ON S.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
		   INNER JOIN 
		   TB_CM_ITEM_MST IM 
		ON S.ITEM_MST_ID = IM.ID
	   AND ISNULL(IM.DEL_YN,'N') = 'N'
		   INNER JOIN 
		   TB_DP_ACCOUNT_MST AM
		ON S.ACCOUNT_ID = AM.ID
	   AND ISNULL(AM.DEL_YN,'N') = 'N'
	   AND AM.ACTV_YN = 'Y'
	 WHERE ITEM_CD = @P_ITEM_CD
	   AND ACCOUNT_CD = @P_ACCOUNT_CD
  GROUP BY ITEM_CD, ACCOUNT_CD
		  , CA.BUKT
		  , CA.STRT_DATE
), N
AS (
	SELECT RT.ITEM_CD					AS ITEM_CD
	     , RT.ACCOUNT_CD				AS ACCOUNT_CD
		 , BUKT
		 , RT.ENGINE_TP_CD
		 , SUM(RT.QTY)					AS QTY			 
	  FROM RT 
		   INNER JOIN 
		   CA 
		ON RT.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE 
GROUP BY ITEM_CD, ACCOUNT_CD, BUKT, ENGINE_TP_CD
	 UNION
	SELECT SA.ITEM_CD
		 , SA.ACCOUNT_CD
		 , BUKT
		 , 'Z_ACT_SALES'						AS ENGINE_TP_CD
		 , SA.QTY 
	  FROM SA
), M
AS (
	SELECT ITEM_CD
		  ,ACCOUNT_CD 
		  ,ENGINE_TP_CD
		  ,BUKT
	  FROM CA 
		   CROSS JOIN
		   ( SELECT ITEM_CD
				   ,ACCOUNT_CD 
				   ,ENGINE_TP_CD
			   FROM N  
		   GROUP BY ITEM_CD
		 		   ,ACCOUNT_CD 
		 		   ,ENGINE_TP_CD
		   ) RT
)
SELECT M.ITEM_CD
	 , M.ACCOUNT_CD
	 , M.ENGINE_TP_CD
	 , M.BUKT MMWW
	 , N.QTY	 
  FROM M
	   LEFT OUTER JOIN
	   N ON M.ITEM_CD = N.ITEM_CD
		  AND M.ACCOUNT_CD = N.ACCOUNT_CD
		  AND M.BUKT = N.BUKT
		  AND M.ENGINE_TP_CD = N.ENGINE_TP_CD
 ORDER BY M.BUKT

END

 

go

