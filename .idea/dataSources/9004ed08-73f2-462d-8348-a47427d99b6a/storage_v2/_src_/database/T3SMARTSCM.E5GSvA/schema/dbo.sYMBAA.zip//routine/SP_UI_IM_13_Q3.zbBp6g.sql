CREATE PROCEDURE [dbo].[SP_UI_IM_13_Q3] (
	@P_INTRANSIT_INV_MST_ID char(32)
)
AS
/*****************************************************************************
Title : SP_UI_IM_13_Q3
최초 작성자 : 한영석
최초 생성일 : 2017.09.19
 
설명 
 -  Demand Pegging 팝업 쿼리
 -  SP_UI_IM_12_Q3과 동일한 로직

History (수정일자 / 수정자 / 수정내용)
- 2017.09.19 / 한영석 / 최초 작성
 
*****************************************************************************/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	SELECT A.ID, A.PEGGING_GRP, A.PEGGING_ATTR
	, (		
		SELECT 1
		FROM VW_PEGGING_TYPE B
		WHERE 1=1
		AND B.ID = A.ID
		AND A.ID =	(	
								SELECT PEGGING_GRP_ID
								FROM TB_CM_INTRANSIT_STOCK_DTL A
 								WHERE A.ID = @P_INTRANSIT_INV_MST_ID 
						)
		)  AS ACTV_YN			   
	FROM VW_PEGGING_TYPE A

go

