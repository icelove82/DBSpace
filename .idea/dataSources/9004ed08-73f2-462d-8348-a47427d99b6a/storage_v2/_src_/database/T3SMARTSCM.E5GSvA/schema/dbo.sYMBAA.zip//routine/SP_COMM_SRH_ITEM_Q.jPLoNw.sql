/*****************************************************************************
Title : SP_COMM_SRH_ITEM_Q
최초 작성자 : 조아람
최초 생성일 : 2017.11.08
 
설명 
 - 검색조건 : 아이쳄 정보 조회
 
History (수정일자 / 수정자 / 수정내용)
- 2017.11.08 / 조아람 / 최초 작성
 
*****************************************************************************/
CREATE PROCEDURE [dbo].[SP_COMM_SRH_ITEM_Q] (
	@P_ITEM_CD			NVARCHAR(100) = '',
	@P_ITEM_NM			NVARCHAR(100) = '',
	@P_ITEM_TP_ID		NVARCHAR(100) = '',
	@P_ITEM_DESCRIP		NVARCHAR(100) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

	 SELECT A.ID			AS ITEM_MST_ID
           ,A.ITEM_CD		AS ITEM_CD
           ,A.ITEM_NM		AS ITEM_NM
           ,A.DESCRIP		AS ITEM_DESCRIP
           ,A.ITEM_TP_ID	AS ITEM_TP_ID
           ,B.CONVN_NM		AS ITEM_TP_NM
           ,A.UOM_ID		AS ITEM_UOM_ID
           ,C.UOM_NM		AS ITEM_UOM_NM
           ,A.DEL_YN		
       FROM TB_CM_ITEM_MST A
			INNER JOIN TB_CM_ITEM_TYPE B
				ON (A.ITEM_TP_ID = B.ID)
			LEFT OUTER JOIN TB_CM_UOM C
				ON (A.UOM_ID = C.ID)
      WHERE 1=1
        AND A.ITEM_CD LIKE '%'+@P_ITEM_CD+'%'
        AND ISNULL(A.ITEM_NM,'') LIKE '%'+@P_ITEM_NM+'%'
        AND ISNULL(A.DESCRIP,'') LIKE '%'+@P_ITEM_DESCRIP+'%' 
        AND A.ITEM_TP_ID =  CASE WHEN @P_ITEM_TP_ID = 'ALL' THEN A.ITEM_TP_ID
								 ELSE @P_ITEM_TP_ID
							 END
      ORDER BY B.ITEM_TP, A.ITEM_CD

END

go

