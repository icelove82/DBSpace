/*****************************************************************************
Title : SP_DP_04_Q1
최초 작성자 : 민희영
최초 생성일 : 2017.06.20
 
설명 
 - DP Customer
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 민희영 / 최초 작성
- 2019.01.17 / 김소희 / UPPER 처리 
	- 2020.11.10 / Kim sohee / data type of CODE NVARCHAR(100)
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_04_Q1] (@p_CUST_CD NVARCHAR(100) = ''
                                      , @p_CUST_NM NVARCHAR(240) = ''
								   ) AS 

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

SELECT
	   C.ID				AS ID
	  ,C.CUST_CD		AS CUST_CD	
	  ,C.CUST_NM		AS CUST_NM	
	  ,C.COUNTRY_ID		AS COUNTRY_ID	
	  ,B.CONF_CD		AS COUNTRY_CD
	  ,C.ADDR			AS ADDR		
	  ,C.CREATE_BY		AS CREATE_BY	
	  ,C.CREATE_DTTM	AS CREATE_DTTM
	  ,C.MODIFY_BY		AS MODIFY_BY	
	  ,C.MODIFY_DTTM	AS MODIFY_DTTM   
  FROM [TB_CM_CUSTOMER] C 
       LEFT OUTER JOIN
	   TB_CM_COMM_CONFIG B 
	ON (C.COUNTRY_ID = B.ID)
  WHERE 1=1
    AND UPPER(CUST_CD) LIKE '%' + UPPER(@p_CUST_CD) + '%'
    AND UPPER(CUST_NM) LIKE '%' + UPPER(@p_CUST_NM) + '%'
--	AND (  ( '' <> @p_CUST_NM AND UPPER(CUST_NM) IN (SELECT Value VAL
--												FROM SplitTableNVARCHAR(UPPER(@p_CUST_NM),'|')) 
--				) OR
--				( ''  =  @p_CUST_NM AND ISNULL(CUST_NM,'')  LIKE  '%'  )	                                        
--			)
   


END






go

