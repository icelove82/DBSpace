/*****************************************************************************
Title : SP_DP_02_S1
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP Level Management
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2020.10.05 / ksh / insert or remove group data  
- 2020.11.20 / KSH / about ad group 
- 2021.08.05 / level type 별 level code check
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_02_S1]  (
                                       @p_ID                CHAR(32)			= ''         
                                      ,@p_LV_TP_ID          CHAR(32)			= ''         
									  ,@p_LV_CD             NVARCHAR(30)		= ''         
									  ,@p_LV_NM             NVARCHAR(240)	    = ''      
									  ,@p_SEQ               NVARCHAR(100)	    = ''   -- cast(@p_SEQ AS int)   AS  SEQ
									  ,@p_LV_LEAF_YN        NVARCHAR(1)         = ''  
									  ,@p_SRP_LV_YN         NVARCHAR(1)         = ''  
									  ,@p_LEAF_YN           NVARCHAR(1)         = ''  
									  ,@p_ACTV_YN           NVARCHAR(1)         = ''  
									  ,@p_SALES_LV_YN       NVARCHAR(1)         = ''  
									  ,@p_ACCOUNT_LV_YN     NVARCHAR(1)         = ''  
									  ,@p_USER_ID           NVARCHAR(100)		= ''  
									  ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)        = 'true'  OUTPUT
									  ,@P_RT_MSG            NVARCHAR(4000)      = ''	  OUTPUT									      
					                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''

	   ,@V_ID            CHAR(32)		= ''
	   ,@V_LV_TP_ID      CHAR(32)		= ''
	   ,@V_LV_CD         NVARCHAR(30)	= ''
	   ,@V_LV_NM         NVARCHAR(240)	= ''
	   ,@V_SEQ           NVARCHAR(100)	= ''
	   ,@V_LV_LEAF_YN    NVARCHAR(1)	= ''
	   ,@V_SRP_LV_YN     NVARCHAR(1)	= ''
	   ,@V_LEAF_YN       NVARCHAR(1)	= ''
	   ,@V_ACTV_YN       NVARCHAR(1)	= ''
	   ,@V_SALES_LV_YN   NVARCHAR(1)	= ''
	   ,@V_ACCOUNT_LV_YN NVARCHAR(1)	= ''
	   ,@V_USER_ID       NVARCHAR(100)	= ''

SET @V_ID           	= @p_ID            
SET @V_LV_TP_ID     	= @p_LV_TP_ID      
SET @V_LV_CD        	= @p_LV_CD         
SET @V_LV_NM        	= @p_LV_NM         
SET @V_SEQ          	= @p_SEQ           
SET @V_LV_LEAF_YN   	= @p_LV_LEAF_YN    
SET @V_SRP_LV_YN    	= @p_SRP_LV_YN     
SET @V_LEAF_YN      	= @p_LEAF_YN       
SET @V_ACTV_YN      	= @p_ACTV_YN       
SET @V_SALES_LV_YN  	= @p_SALES_LV_YN   
SET @V_ACCOUNT_LV_YN	= @p_ACCOUNT_LV_YN 
SET @V_USER_ID			= @p_USER_ID       

BEGIN TRY
/***** Validation 1] Level Type *******************************************************/
SELECT @P_ERR_STATUS = COUNT(CONF_NM)
 FROM TB_CM_COMM_CONFIG
 WHERE ID = @V_LV_TP_ID
IF(@P_ERR_STATUS = 0 OR @V_LV_TP_ID IS NULL)
BEGIN
	SET @P_ERR_MSG = 'MSG_5031'
	RAISERROR (@P_ERR_MSG,12, 1);
END
/****** Validation 2] Level Code *****************************************************/

IF(@V_LV_CD IS NULL)
BEGIN
	SET @P_ERR_MSG = 'MSG_5032'
	RAISERROR (@P_ERR_MSG,12, 1);
END
SELECT @P_ERR_STATUS = COUNT(LV_CD)
 FROM TB_CM_LEVEL_MGMT
 WHERE LV_CD = @V_LV_CD  AND ID != @V_ID and @V_LV_TP_ID = LV_TP_ID
IF(@P_ERR_STATUS !=0)
BEGIN
	SET @P_ERR_MSG = 'MSG_5033'
	RAISERROR (@P_ERR_MSG,12, 1);
END



   
			 --RAISERROR ('Error raised in TRY block.', -- Message text.
    --           16, -- Severity.
    --           1 -- State.
    --           );






	  -- 프로시저 시작 


				MERGE TB_CM_LEVEL_MGMT TGT
				USING ( SELECT @V_ID                 AS  ID
							  ,@V_LV_TP_ID           AS  LV_TP_ID          
							  ,@V_LV_CD              AS  LV_CD      
							  ,@V_LV_NM              AS  LV_NM      
							  ,cast(@V_SEQ AS int)   AS  SEQ   
							  ,CASE WHEN @V_LV_LEAF_YN IS NULL OR @V_LV_LEAF_YN ='' THEN 'N' ELSE @V_LV_LEAF_YN END			 AS  LV_LEAF_YN      
							  ,CASE WHEN @V_SRP_LV_YN IS NULL OR @V_SRP_LV_YN ='' THEN 'N' ELSE @V_SRP_LV_YN END			 AS  SRP_LV_YN 
							  ,CASE WHEN @V_LEAF_YN IS NULL OR @V_LEAF_YN ='' THEN 'N' ELSE @V_LEAF_YN END					 AS  LEAF_YN 
							  ,CASE WHEN @V_ACTV_YN IS NULL OR @V_ACTV_YN ='' THEN 'N' ELSE @V_ACTV_YN END					 AS  ACTV_YN 
							  ,CASE WHEN @V_SALES_LV_YN IS NULL OR @V_SALES_LV_YN ='' THEN 'N' ELSE @V_SALES_LV_YN END		 AS  SALES_LV_YN 
							  ,CASE WHEN @V_ACCOUNT_LV_YN IS NULL OR @V_ACCOUNT_LV_YN ='' THEN 'N' ELSE @V_ACCOUNT_LV_YN END AS  ACCOUNT_LV_YN 
							  ,@V_USER_ID            AS  USER_ID
					  ) SRC
				ON     TGT.ID = SRC.ID
				WHEN MATCHED THEN
					 UPDATE 
					   SET   TGT.LV_TP_ID      = SRC.LV_TP_ID        
							,TGT.LV_CD         = SRC.LV_CD       
							,TGT.LV_NM         = SRC.LV_NM          
							,TGT.SEQ           = SRC.SEQ           
							,TGT.LV_LEAF_YN    = SRC.LV_LEAF_YN     
							,TGT.SRP_LV_YN     = SRC.SRP_LV_YN 
							,TGT.LEAF_YN       = SRC.LEAF_YN 
							,TGT.ACTV_YN       = SRC.ACTV_YN 
							,TGT.SALES_LV_YN   = SRC.SALES_LV_YN 
							,TGT.ACCOUNT_LV_YN = SRC.ACCOUNT_LV_YN
							--,TGT.DEL_YN        = SRC.DEL_YN 
							,TGT.MODIFY_BY     = SRC.USER_ID       
							,TGT.MODIFY_DTTM   = GETDATE()       
				WHEN NOT MATCHED THEN 
					 INSERT (
							   ID
							,  LV_TP_ID     
							,  LV_CD      
							,  LV_NM        
							,  SEQ      
							,  LV_LEAF_YN   
							,  SRP_LV_YN 
							,  LEAF_YN 
							,  ACTV_YN 
							,  SALES_LV_YN 
							,  ACCOUNT_LV_YN
							,  DEL_YN 
							,  CREATE_BY
							,  CREATE_DTTM
							) 
					 VALUES (
							   REPLACE(NEWID(),'-','')
							,  LV_TP_ID     
							,  LV_CD      
							,  LV_NM        
							,  SEQ      
							,  LV_LEAF_YN   
							,  SRP_LV_YN 
							,  LEAF_YN 
							,  ACTV_YN 
							,  SALES_LV_YN 
							,  ACCOUNT_LV_YN
							,  'N'--DEL_YN 
							, SRC.USER_ID 
							, GETDATE()            
 							) 
							; 
-- Insert Group Code 
IF EXISTS (
 				SELECT  LM.ID
					  , LM.LV_CD
					  , LM.LV_NM
					  , LM.SEQ
				 FROM TB_CM_COMM_CONFIG CO
					  INNER JOIN
					  TB_CM_LEVEL_MGMT LM
				   ON CO.ID = LM.LV_TP_ID
				WHERE CO.CONF_GRP_CD =  'DP_LV_TP'
				  AND CO.ACTV_YN = 'Y'
				  AND CO.CONF_CD = 'S'
				  AND ISNULL(LM.DEL_YN,'N') = 'N'
				  AND LM.ACTV_YN = 'Y'
				  AND LM.SALES_LV_YN = 'Y' 
				  AND LM.LV_CD = @P_LV_CD 
			)
	AND NOT EXISTS
	(
		SELECT 1 
		  FROM TB_AD_GROUP 
		  WHERE GRP_CD = @P_LV_CD 	
	)
	BEGIN
		INSERT INTO TB_AD_GROUP
		(	 ID
			,GRP_CD
			,GRP_NM
			,GRP_DESCRIP	
		) VALUES
		(	REPLACE(NEWID(),'-','')
		   ,@P_LV_CD
		   ,@P_LV_NM
		   ,@P_LV_NM 
		)
		;
	END 
--ELSE IF EXISTS (
-- 				SELECT  LM.ID
--					  , LM.LV_CD
--					  , LM.LV_NM
--					  , LM.SEQ
--				 FROM TB_CM_COMM_CONFIG CO
--					, TB_CM_LEVEL_MGMT LM
--				WHERE CO.CONF_GRP_CD =  'DP_LV_TP'
--				  AND CO.ACTV_YN = 'Y'
--				  AND CO.CONF_CD = 'S'
--				  AND CO.ID = LM.LV_TP_ID
--				  AND (ISNULL(LM.DEL_YN,'N') = 'Y'
--					OR LM.ACTV_YN = 'N')
--				  AND LM.SALES_LV_YN = 'Y' 
--				  AND LM.LV_CD = @P_LV_CD 
--			)
--	BEGIN	
--		DELETE FROM TB_AD_GROUP
--		 WHERE GRP_CD = @P_LV_CD 
--		 ;
--	END

	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;





go

