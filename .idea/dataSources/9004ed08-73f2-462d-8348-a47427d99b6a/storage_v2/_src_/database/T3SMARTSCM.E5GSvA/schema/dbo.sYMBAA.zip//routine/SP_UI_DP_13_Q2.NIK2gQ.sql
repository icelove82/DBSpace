/*****************************************************************************
Title : SP_DP_13_Q2
최초 작성자 : 민희영
최초 생성일 : 2017.06.20
 
설명 
 - DP User Mapping (Item)
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 민희영 / 최초 작성
- 2019.04.25 / 김소희 / DEL_YN Null처리 
- 2019.06.21 / 김소희 / 활성화 안된 Item 및 Item Level 매핑 색상 변경 처리를 위한 DP_PLAN_YN 컬럼 추가
- 2020.03.12 / KSH / EMP_NO => USER_ID 
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_13_Q2] ( @p_EMP_CD    NVARCHAR(50) = ''
										,@p_AUTH_TP_ID    NVARCHAR(32) = ''
								   ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

 SELECT   UI.ID
        , UI.AUTH_TP_ID 
		, LM2.LV_CD AS  AUTH_TYPE
		, LM2.LV_NM AS  AUTH_TYPE_NM
		, UI.EMP_ID
		, DE.USERNAME	AS USER_ID
		, DE.USERNAME   AS EMP_NO
		, DE.DISPLAY_NAME AS EMP_NM
		, UI.LV_MGMT_ID
		, LM.LV_CD
		, LM.LV_NM
		, ISNULL(UI.ITEM_LV_ID ,UI.ITEM_MST_ID)  AS ITEM_ID
		, ISNULL(IL.ITEM_LV_CD ,IM.ITEM_CD)  AS ITEM_CD
		, ISNULL(IL.ITEM_LV_NM, IM.ITEM_NM) AS ITEM_NM    
		, CASE WHEN IM.ID IS NULL THEN (CASE WHEN IL.DEL_YN = 'Y' OR ISNULL(IL.ACTV_YN, 'N')   = 'N' THEN 'N' ELSE 'Y' END)
			   WHEN IL.ID IS NULL THEN (CASE WHEN IM.DEL_YN = 'Y' OR ISNULL(IM.DP_PLAN_YN,'N') = 'N' THEN 'N' ELSE 'Y' END)
		  END			AS DP_PLAN_YN
		, UI.ACTV_YN 
        , UI.CREATE_BY
        , UI.CREATE_DTTM
        , UI.MODIFY_BY
        , UI.MODIFY_DTTM
  FROM    TB_CM_COMM_CONFIG B
        , TB_CM_LEVEL_MGMT LM   
		, TB_CM_COMM_CONFIG B2
        , TB_CM_LEVEL_MGMT LM2   
		, TB_DP_USER_ITEM_MAP UI LEFT OUTER JOIN TB_CM_ITEM_LEVEL_MGMT IL ON UI.ITEM_LV_ID = IL.ID
		                                          LEFT OUTER JOIN TB_CM_ITEM_MST IM ON UI.ITEM_MST_ID = IM.ID
		, TB_AD_USER   DE
  WHERE    B.CONF_GRP_CD =  'DP_LV_TP'
	   AND B.CONF_CD = 'I'
	   AND B.ACTV_YN = 'Y'
	   AND B.ID = LM.LV_TP_ID    -- Level Type 
	   AND ISNULL(LM.DEL_YN,'N') = 'N'
	   AND LM.ID = UI.LV_MGMT_ID
       AND B2.CONF_GRP_CD =  'DP_LV_TP'
	   AND B2.CONF_CD = 'S'
	   AND B2.ACTV_YN = 'Y'
	   AND B2.ID = LM2.LV_TP_ID
	   AND ISNULL(LM2.DEL_YN,'N') = 'N'
	   AND LM2.ID = UI.AUTH_TP_ID -- Auth Type
	   AND UI.EMP_ID = DE.ID
	   AND DE.USERNAME =  @p_EMP_CD   --'admin'
	   AND UI.AUTH_TP_ID = @p_AUTH_TP_ID
ORDER BY LM.SEQ,  IL.SEQ, IM.ITEM_CD
;

END




go

