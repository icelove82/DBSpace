
CREATE PROCEDURE [dbo].[SP_UI_MP_18_Q1] (
	 @P_CUTOFF_DATE     DATE = NULL
    ,@P_LOCAT_TP_NM  	NVARCHAR(100) = ''
	,@P_LOCAT_LV  		NVARCHAR(100) = ''
    ,@P_LOCAT_CD       	NVARCHAR(100) = ''
	,@P_LOCAT_NM       	NVARCHAR(100) = ''
	,@P_ITEM_CD         NVARCHAR(100) = ''
    ,@P_ITEM_NM     	NVARCHAR(100) = ''
    ,@P_PO_NO           NVARCHAR(50) = ''
    ,@P_INVOICE_NO	  	NVARCHAR(50) = ''
    ,@P_CONTAINER_NO    NVARCHAR(50) = ''
	,@P_ETA_FROM        DATE = NULL
	,@P_ETA_TO        	DATE = NULL
	,@P_ATA_FROM        DATE = NULL
	,@P_ATA_TO        	DATE = NULL
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

   SELECT  
           A.LOCAT_TP_NM
          ,A.LOCAT_LV
          ,A.LOCAT_CD
          ,A.LOCAT_NM
          ,A.ITEM_NM
          ,A.ITEM_CD
          ,A.DESCRIP
          ,B.UOM_NM
          ,C.VENDOR_NM
          ,C.VENDOR_DESCRIP
          ,RTRIM(A.PO_NO) AS PO_NO
          ,A.BOOKING_DATE AS BOOKING_DATE
          ,A.ETD		  AS ETD
          ,A.ATD		  AS ATD
          ,A.ETA		  AS ETA
          ,A.ATA		  AS ATA
          ,A.GR_QTY
          ,A.GR_AMT
          ,D.WAHOUS_TP_NM
          ,D.INV_LOCAT_NM
          ,D.INV_LOCAT_DESCRIP
          ,RTRIM(A.INVOICE_NO) AS INVOICE_NO
          ,RTRIM(A.CONTAINER_NO) AS CONTAINER_NO
          ,A.CREATE_BY
          ,A.CREATE_DTTM
          ,A.MODIFY_BY
          ,A.MODIFY_DTTM
     FROM (
           SELECT  F.COMN_CD_NM AS LOCAT_TP_NM
                  ,A.LOCAT_LV
                  ,B.LOCAT_CD
                  ,B.LOCAT_NM
                  ,G.ITEM_NM
                  ,G.ITEM_CD
                  ,G.DESCRIP
                  ,G.UOM_ID
                  ,E.LOCAT_ITEM_ID
                  ,E.VENDOR_ID
                  ,E.BOOKING_DATE
                  ,E.ETD
                  ,E.ATD
                  ,E.ETA
                  ,E.ATA
                  ,E.GR_QTY
                  ,E.GR_AMT
                  ,E.INV_LOCAT_ID
                  ,E.PO_NO
                  ,E.INVOICE_NO
                  ,E.CONTAINER_NO
                  ,E.CREATE_BY
                  ,E.CREATE_DTTM
                  ,E.MODIFY_BY
                  ,E.MODIFY_DTTM
     		FROM  TB_CM_LOC_MST A
                INNER JOIN TB_CM_LOC_DTL B
                ON  A.ID = B.LOCAT_MST_ID
                INNER JOIN TB_CM_LOC_MGMT C
                ON B.ID = C.LOCAT_ID
                INNER JOIN TB_CM_SITE_ITEM D
                ON C.ID = D.LOCAT_MGMT_ID
                INNER JOIN TB_MP_MAT_SUPPLY_CALENDAR E
                ON D.ID = E.LOCAT_ITEM_ID
                INNER JOIN TB_AD_COMN_CODE F
                ON A.LOCAT_TP_ID = F.ID
                INNER JOIN TB_CM_ITEM_MST G
                ON D.ITEM_MST_ID = G.ID
            WHERE 1=1
              AND CAST(CAST(E.CUTOFF_DATE AS DATE) AS DATETIME) = @P_CUTOFF_DATE
              AND ISNULL(F.COMN_CD_NM, ' ')     LIKE '%'+@P_LOCAT_TP_NM+'%'
              AND A.LOCAT_LV 				    LIKE '%'+@P_LOCAT_LV+'%'
              AND ISNULL(B.LOCAT_CD, ' ') 		LIKE '%'+@P_LOCAT_CD+'%'
              AND ISNULL(B.LOCAT_NM, ' ') 		LIKE '%'+@P_LOCAT_NM+'%'
              AND ISNULL(G.ITEM_CD, ' ') 		LIKE '%'+@P_ITEM_CD+'%'
              AND ISNULL(G.ITEM_NM, ' ') 		LIKE '%'+@P_ITEM_NM+'%'
              AND ISNULL(E.PO_NO, ' ') 			LIKE '%'+@P_PO_NO+'%'
              AND ISNULL(E.INVOICE_NO, ' ') 	LIKE '%'+@P_INVOICE_NO+'%'
              AND ISNULL(E.CONTAINER_NO, ' ')	LIKE '%'+@P_CONTAINER_NO+'%'
              
              AND 1 = CASE WHEN @P_ETA_FROM = '' AND @P_ETA_TO = '' THEN 1
                           WHEN @P_ETA_FROM = '' AND @P_ETA_TO != '' THEN 
                           CASE WHEN E.ETA <= @P_ETA_TO THEN 1 END
                           WHEN @P_ETA_FROM != '' AND @P_ETA_TO = '' THEN 
                           CASE WHEN E.ETA >= @P_ETA_FROM THEN 1 END
                           WHEN @P_ETA_FROM != ''  AND @P_ETA_TO != '' THEN 
                           CASE WHEN E.ETA BETWEEN @P_ETA_FROM AND @P_ETA_TO THEN 1 END
                    END
              AND 1 = CASE WHEN @P_ATA_FROM = '' AND @P_ATA_TO = '' THEN 1
                           WHEN @P_ATA_FROM = '' AND @P_ATA_TO != '' THEN 
                           CASE WHEN E.ATA <= @P_ATA_TO THEN 1 END
                           WHEN @P_ATA_FROM != '' AND @P_ATA_TO = '' THEN 
                           CASE WHEN E.ATA >= @P_ATA_FROM THEN 1 END
                           WHEN @P_ATA_FROM != '' AND @P_ATA_TO != '' THEN 
                           CASE WHEN E.ATA BETWEEN @P_ATA_FROM AND @P_ATA_TO THEN 1 END
                    END
          ) A
          LEFT OUTER JOIN 
          TB_CM_UOM B
       ON (A.UOM_ID = B.ID)
          LEFT OUTER JOIN 
          TB_CM_VENDOR_MST C
       ON (A.VENDOR_ID = C.ID)
          LEFT OUTER JOIN 
          (
           SELECT  A.ID
                  ,B.CONF_NM AS WAHOUS_TP_NM
                  ,A.INV_LOCAT_NM
                  ,A.INV_LOCAT_DESCRIP
             FROM  TB_CM_STORAGE_LOCATION A
                  LEFT OUTER JOIN 
                  (
                   SELECT  Z.ID
                          ,Z.CONF_NM
                     FROM  TB_CM_CONFIGURATION X
                     INNER JOIN TB_CM_COMM_CONFIG Z
                     ON X.ID = Z.CONF_ID
                    WHERE 1=1
                    AND  X.CONF_KEY = '313'
                  ) B
               ON (A.WAHOUS_TP_ID = B.ID)
          ) D
       ON (A.INV_LOCAT_ID = D.ID);

go

