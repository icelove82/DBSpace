/*****************************************************************************
Title : SP_DP_11_Q1
최초 작성자 : 민희영
최초 생성일 : 2017.06.20
 
설명 
 - DP Account Master
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 민희영 / 최초 작성
- 2019.01.17 / 민경훈 / 다중검색 특수기호 처리
- 2019.01.17 / 김소희 / 대소문자 구분 없이 조회 
- 2019.04.29 / 김소희 / Account Name이 Null일 때 조회할 수 있도록 수정
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_11_Q1] ( @p_PARENT_SALES_LV_ID  CHAR(32) = ''
										,@P_ACCT_CD				NVARCHAR(100)  = ''
										,@P_ACCT_NM				NVARCHAR(100)  = ''
										,@p_SOLD_TO_CD			NVARCHAR(4000) = ''
										,@p_SOLD_TO_NM			NVARCHAR(4000) = ''
										,@p_SHIP_TO_CD			NVARCHAR(4000) = ''
										,@p_SHIP_TO_NM			NVARCHAR(4000) = ''
										,@p_BILL_TO_CD			NVARCHAR(4000) = ''
										,@p_BILL_TO_NM			NVARCHAR(4000) = ''
										,@P_DEL_YN				CHAR(1)		= ''
										,@P_ATTR_01				NVARCHAR(4000) = ''
										,@P_ATTR_02				NVARCHAR(4000) = ''
										,@P_ATTR_03				NVARCHAR(4000) = ''
								 

								   ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE   @V_PARENT_SALES_LV_ID	NVARCHAR(32) = ''
		, @V_ACCT_CD			NVARCHAR(100)  = ''
		, @V_ACCT_NM			NVARCHAR(100)  = ''
		, @V_SOLD_TO_CD			NVARCHAR(4000) = ''
		, @V_SOLD_TO_NM			NVARCHAR(4000) = ''
		, @V_SHIP_TO_CD			NVARCHAR(4000) = ''
		, @V_SHIP_TO_NM			NVARCHAR(4000) = ''
		, @V_BILL_TO_CD			NVARCHAR(4000) = ''
		, @V_BILL_TO_NM			NVARCHAR(4000) = ''
		, @V_DEL_YN				CHAR(1)		= ''
		, @V_ATTR_01			NVARCHAR(4000) = ''
		, @V_ATTR_02			NVARCHAR(4000) = ''
		, @V_ATTR_03			NVARCHAR(4000) = ''

SET @V_PARENT_SALES_LV_ID	= @p_PARENT_SALES_LV_ID  
SET @V_ACCT_CD				= @P_ACCT_CD				
SET @V_ACCT_NM				= @P_ACCT_NM				
SET @V_SOLD_TO_CD			= @p_SOLD_TO_CD			
SET @V_SOLD_TO_NM			= @p_SOLD_TO_NM			
SET @V_SHIP_TO_CD			= @p_SHIP_TO_CD			
SET @V_SHIP_TO_NM			= @p_SHIP_TO_NM			
SET @V_BILL_TO_CD			= @p_BILL_TO_CD			
SET @V_BILL_TO_NM			= @p_BILL_TO_NM			
SET @V_DEL_YN				= @P_DEL_YN		
SET @V_ATTR_01              = @P_ATTR_01
SET @V_ATTR_02              = @P_ATTR_02	
SET @V_ATTR_03              = @P_ATTR_03	

BEGIN

		SELECT AM.ID
              ,AM.ACCOUNT_CD
              ,AM.ACCOUNT_NM
              ,AM.PARENT_SALES_LV_ID
              ,AM.PARENT_SALES_LV_ID_AD1
              ,AM.PARENT_SALES_LV_ID_AD2
              ,AM.PARENT_SALES_LV_ID_AD3
              ,AM.CURCY_CD_ID
              , CUR.COMN_CD  AS CURCY_CD
              , CUR.COMN_CD_NM  AS CURCY_NM
              ,AM.COUNTRY_ID
              ,CON.CONF_CD  AS COUNTRY_CD
              ,CON.CONF_NM  AS COUNTRY_NM
              ,AM.CHANNEL_ID
              ,CHA.CONF_CD  AS CHANNEL_CD
              ,CHA.CONF_NM  AS CHANNEL_NM
              ,AM.SOLD_TO_ID
              ,SO.CUST_CD AS SOLD_TO_CD              
              ,SO.CUST_NM AS SOLD_TO_NM
              ,AM.SHIP_TO_ID
              ,SH.CUST_CD AS SHIP_TO_CD
              ,SH.CUST_NM AS SHIP_TO_NM
              ,AM.BILL_TO_ID
              ,BI.CUST_CD AS BILL_TO_CD
              ,BI.CUST_NM AS BILL_TO_NM
              ,AM.SRP_YN
              ,AM.INCOTERMS_ID
              , INC.INCOTERMS  AS INCOTERMS_CD
              ,AM.VMI_YN
              ,AM.DIRECT_SHPP_YN
              ,AM.ACTV_YN
              ,AM.DEL_YN
              ,AM.PRIORT
              ,AM.ATTR_01
              ,AM.ATTR_02
              ,AM.ATTR_03
              ,AM.ATTR_04
              ,AM.ATTR_05
              ,AM.ATTR_06
              ,AM.ATTR_07
              ,AM.ATTR_08
              ,AM.ATTR_09
              ,AM.ATTR_10
              ,AM.ATTR_11
              ,AM.ATTR_12
              ,AM.ATTR_13
              ,AM.ATTR_14
              ,AM.ATTR_15
              ,AM.ATTR_16
              ,AM.ATTR_17
              ,AM.ATTR_18
              ,AM.ATTR_19
              ,AM.ATTR_20
              ,AM.CREATE_BY
              ,AM.CREATE_DTTM
              ,AM.MODIFY_BY
              ,AM.MODIFY_DTTM
          FROM TB_DP_ACCOUNT_MST AM
                 LEFT OUTER JOIN ( SELECT CD.ID, CD.COMN_CD, CD.COMN_CD_NM 
                                 FROM TB_AD_COMN_GRP CM
                                    , TB_AD_COMN_CODE CD 
       WHERE CM.ID = CD.SRC_ID AND CM.GRP_CD = 'CURRENCY' 
                             ) CUR ON AM.CURCY_CD_ID = CUR.ID 
               LEFT OUTER JOIN (
                                SELECT  B.ID  AS ID
                                      , B.CONF_CD 
                                      , B.CONF_NM 
                                  FROM   TB_CM_CONFIGURATION A
                                      , TB_CM_COMM_CONFIG B
                                         where  A.ID = B.CONF_ID
                                           AND B.CONF_GRP_CD = 'CM_COUNTRY'
                                           AND B.ACTV_YN = 'Y'
                                ) CON  ON AM.COUNTRY_ID = CON.ID 
               LEFT OUTER JOIN (
                                SELECT  B.ID  AS ID
                                      , B.CONF_CD 
                                      , B.CONF_NM 
                                  FROM   TB_CM_CONFIGURATION A
                                      , TB_CM_COMM_CONFIG B
                                         where  A.ID = B.CONF_ID
                                           AND B.CONF_GRP_CD = 'DP_CHANNEL_TP'
                                           AND B.ACTV_YN = 'Y'
                                ) CHA  ON AM.CHANNEL_ID = CON.ID  
               LEFT OUTER JOIN (
                                 SELECT B.ID  AS ID
                                      , B.INCOTERMS
                                  FROM   TB_CM_CONFIGURATION A
                                      , TB_CM_INCOTERMS B
                                         where  A.ID = B.CONF_ID
                                           AND A.CONF_NM = 'INCOTERMS'
                                           AND B.ACTV_YN = 'Y'
                               ) INC  ON AM.INCOTERMS_ID = INC.ID  
              --LEFT OUTER JOIN  TB_DP_SALES_LEVEL_MGMT SL ON  AM.PARENT_SALES_LV_ID = SL.ID 
              LEFT OUTER JOIN TB_CM_CUSTOMER SO ON SO.ID = AM.SOLD_TO_ID
              LEFT OUTER JOIN TB_CM_CUSTOMER SH ON SH.ID = AM.SHIP_TO_ID
              LEFT OUTER JOIN TB_CM_CUSTOMER BI ON BI.ID = AM.BILL_TO_ID              
		  WHERE (ISNULL(AM.DEL_YN,'N') = @V_DEL_YN OR ISNULL(@V_DEL_YN,'') = '')
		    --AND ISNULL(SL.ID,'')   LIKE '%' + LTRIM(RTRIM(@V_PARENT_SALES_LV_ID)) +'%'	
			AND (  'Y' = CASE WHEN @V_PARENT_SALES_LV_ID = '' THEN 'Y'
				        ELSE ( case when  AM.PARENT_SALES_LV_ID = @V_PARENT_SALES_LV_ID then 'Y'
				        			when  AM.PARENT_SALES_LV_ID_AD1 = @V_PARENT_SALES_LV_ID then 'Y'
				        			when  AM.PARENT_SALES_LV_ID_AD2 = @V_PARENT_SALES_LV_ID then 'Y'
				        			when  AM.PARENT_SALES_LV_ID_AD3 = @V_PARENT_SALES_LV_ID then 'Y'
				                    else 'N' 
				               end
						  )
					 END
			  )
		    AND (  'Y' = CASE WHEN @V_ACCT_CD = '' THEN 'Y'
		        ELSE ( case when
		         UPPER(AM.ACCOUNT_CD) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@V_ACCT_CD),''),'|'))
		          OR
		         UPPER(AM.ACCOUNT_CD) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@V_ACCT_CD),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
		          then 'Y' else 'N' end
				  )
				 END
		  	)
			AND (  'Y' = CASE WHEN @V_ACCT_NM = '' THEN 'Y'
			        ELSE ( case when
			         UPPER(AM.ACCOUNT_NM) IN (SELECT Value VAL FROM SplitTableNVARCHAR(ISNULL(UPPER(@V_ACCT_NM),''),'|'))
			          OR
			         UPPER(AM.ACCOUNT_NM) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@V_ACCT_NM),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
			          then 'Y' else 'N' end
					  )
					 END
			  )							  
			AND (  'Y' = CASE WHEN @V_ATTR_01 = '' THEN 'Y'
				        ELSE ( 
				         case when
				          UPPER(AM.ATTR_01) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@V_ATTR_01),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
				          then 'Y' else 'N' end
				         )
				         END
				  )
			AND (  'Y' = CASE WHEN @V_ATTR_02 = '' THEN 'Y'
				        ELSE ( 
				         case when
				          UPPER(AM.ATTR_02) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@V_ATTR_02),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
				          then 'Y' else 'N' end
				         )
				         END
				  )
			AND (  'Y' = CASE WHEN @V_ATTR_03 = '' THEN 'Y'
				        ELSE ( 
				         case when
				          UPPER(AM.ATTR_03) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@V_ATTR_03),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
				          then 'Y' else 'N' end
				         )
				         END
				  )
	    ORDER BY  AM.ACCOUNT_CD 			    
	    ;

END







go

