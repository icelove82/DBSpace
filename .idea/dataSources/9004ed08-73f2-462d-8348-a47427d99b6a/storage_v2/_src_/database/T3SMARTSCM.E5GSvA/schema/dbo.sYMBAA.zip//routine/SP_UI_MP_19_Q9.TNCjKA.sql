/*****************************************************************************
Title : SP_UI_MP_19_Q9
최초 작성자 : 곽명근
최초 생성일 : 2018.01.26
 
설명 
 - Demand Overview 에서 신규추가 팝업에서 2번째 탭 DMND_ID 넣기
 
 History (수정일자 / 수정자 / 수정내용)
- 2018.01.26 / 곽명근 / 최초 작성
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_MP_19_Q9] (
	@P_DEMAND_VER_ID		NVARCHAR(100) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

DECLARE @P_DMD_ID_PREFIX NVARCHAR(100) = 'DMND_',
        @P_NEW_DMD_ID NVARCHAR(100) 
        
	SELECT @P_NEW_DMD_ID = @P_DMD_ID_PREFIX +  DBO.FN_G_LPAD(  CAST(ISNULL(MAX(CAST(REPLACE(X.DMND_ID,@P_DMD_ID_PREFIX,'') AS INT)) ,0) + 1 AS NVARCHAR(100)),10,'0')
	  FROM TB_CM_DEMAND_OVERVIEW X
	 WHERE 1=1
	   AND X.MODULE_VAL = 'DP' 
	   AND X.T3SERIES_VER_ID = @P_DEMAND_VER_ID
	   AND EXISTS (
				   SELECT  1
					 FROM TB_AD_COMN_GRP A
						  INNER JOIN 
               		   TB_AD_COMN_CODE B
               		ON (A.ID = B.SRC_ID)
					WHERE 1=1
					  AND A.GRP_CD = 'DEMAND_TYPE'
					  AND B.COMN_CD= 'DMND_TYPE_07' --BOM Requirement
					  AND X.DMND_TP_ID <> B.ID
				  )

	SELECT REPLACE(NEWID(), '-', '') AS NEW_ID,
		   @P_NEW_DMD_ID			 AS DEMAND_ID

END

go

