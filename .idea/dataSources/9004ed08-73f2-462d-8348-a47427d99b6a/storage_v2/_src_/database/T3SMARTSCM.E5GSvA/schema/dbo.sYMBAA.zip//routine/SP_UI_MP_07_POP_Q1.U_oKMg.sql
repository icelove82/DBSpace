/*****************************************************************************
Title : SP_UI_MP_07_POP_Q1
최초 작성자 : 조아람
최초 생성일 : 2017.09.05
 
설명 
 - MP Resource Preference Analysis - 계산 조건 팝업 조회 프로시저
 
History (수정일자 / 수정자 / 수정내용)
- 2017.09.05 / 조아람 / 최초 작성
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_MP_07_POP_Q1] (
	 @P_LOCAT_MGMT_ID   NVARCHAR (100)
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

	SELECT RCR.ID					AS RES_CAL_RULE_ID
		 , RCR.LOCAT_MGMT_ID		AS LOCAT_MGMT_ID
		 , ACD1.COMN_CD_NM			AS LOCAT_TP
		 , LMS.LOCAT_LV				AS LOCAT_LV
		 , LDT.LOCAT_CD				AS LOCAT_CD
		 , LDT.LOCAT_NM				AS LOCAT_NM
		 , RCR.ALLOC_RULE_VAL		AS ALLOC_RULE_VAL
		 , RCR.APPY_ITEM			AS APPY_ITEM
		 , RCR.APPY_ITEM_DTL		AS APPY_ITEM_DTL
		 , RCR.APPY_YN				AS APPY_YN
		 , RCR.ATTR_01				AS ATTR_01
		 , RCR.ATTR_01_VAL			AS ATTR_01_VAL
		 , CASE WHEN LEN(RCR.ATTR_01) > 2 
				THEN 'Y'
				ELSE 'N'
			END						AS ATTR_01_STATUS
		 , RCR.ATTR_02				AS ATTR_02
		 , RCR.ATTR_02_VAL			AS ATTR_02_VAL
		 , CASE WHEN LEN(RCR.ATTR_02) > 2 
				THEN 'Y'
				ELSE 'N'
			END						AS ATTR_02_STATUS
	  FROM TB_MP_RES_PREFER_ANLYS_RULE RCR
		 , TB_CM_LOC_MGMT LMG
		 , TB_CM_LOC_DTL LDT
		 , TB_CM_LOC_MST LMS
			LEFT OUTER JOIN TB_AD_COMN_CODE ACD1
				ON LMS.LOCAT_TP_ID = ACD1.ID
	 WHERE RCR.LOCAT_MGMT_ID = LMG.ID
	   AND LMG.LOCAT_ID = LDT.ID
	   AND LDT.LOCAT_MST_ID = LMS.ID

   ---------------------------------------------------------------
   -- 조회 조건
   ---------------------------------------------------------------
	   AND RCR.LOCAT_MGMT_ID = @P_LOCAT_MGMT_ID
END

go

