/*****************************************************************************
Title : SP_UI_MP_06_Q1
최초 작성자 : 조아람
최초 생성일 : 2017.08.03
 
설명 
 - MP Resource Management(UI_MP_06) Resource Group-  조회 프로시저
 
History (수정일자 / 수정자 / 수정내용)
- 2017.08.03 / 조아람 / 최초 작성
 
*****************************************************************************/
CREATE PROCEDURE [dbo].[SP_UI_MP_06_Q1] (
	  @P_LOCAT_TP		NVARCHAR(100) = '',
	  @P_LOCAT_LV		NVARCHAR(100) = '',
	  @P_LOCAT_CD		NVARCHAR(100) = '',
	  @P_LOCAT_NM		NVARCHAR(100) = ''
) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

	SELECT	RMS.ID							AS RES_MST_ID
		  , RGP.ID							AS RES_GRP_ID
		  , ACM.COMN_CD_NM					AS LOCAT_TP_NM
		  , LMS.LOCAT_LV					AS LOCAT_LV
		  , LDT.LOCAT_CD					AS LOCAT_CD
		  , LDT.LOCAT_NM					AS LOCAT_NM
		  , LMG.LGCY_PLANT_CD				AS LGCY_PLANT_CD
		  , RMS.ROUTE_GRP					AS ROUTE_GRP
		  , RMS.ROUTE_GRP_DESCRIP			AS ROUTE_GRP_DESCRIP
		  , RMS.OPERATION					AS OPERATION
		  , RMS.OPERATION_DESCRIP			AS OPERATION_DESCRIP
		  , RMS.WC							AS WC
		  , RMS.WC_DESCRIP					AS WC_DESCRIP
		  , RMS.OUTSRC_YN					AS OUTSRC_YN
		  , RGP.RES_GRP_CD					AS RES_GRP_CD
		  , RGP.DESCRIP						AS RES_GRP_DESCRIP
		  , RGP.RES_GRP_TP_ID				AS RES_GRP_TP_ID
		  , ACD.COMN_CD_NM					AS RES_GRP_TP
		  , 'N'								AS DEL_YN
		  , RMS.ACTV_YN						AS ACTV_YN
		  , RMS.CREATE_BY
		  , RMS.CREATE_DTTM
		  , RMS.MODIFY_BY
		  , RMS.MODIFY_DTTM
	   FROM TB_MP_RES_MGMT_MST RMS
			INNER JOIN TB_CM_RES_GROUP RGP
			ON RMS.RES_GRP_ID = RGP.ID
			INNER JOIN TB_AD_COMN_CODE ACD
			ON RGP.RES_GRP_TP_ID = ACD.ID
			INNER JOIN TB_CM_LOC_MGMT LMG
			ON  RMS.LOCAT_MGMT_ID = LMG.ID
			INNER JOIN TB_CM_LOC_DTL LDT
			ON LMG.LOCAT_ID = LDT.ID
			INNER JOIN TB_CM_LOC_MST LMS
			ON  LDT.LOCAT_MST_ID = LMS.ID
			INNER JOIN TB_AD_COMN_CODE ACM
			ON LMS.LOCAT_TP_ID = ACM.ID
	 WHERE 1=1
	   ---------------------------------------------------------------
	   -- 조회 조건
	   ---------------------------------------------------------------
	   AND UPPER(ACM.COMN_CD_NM) LIKE '%'+UPPER(@P_LOCAT_TP)+'%'
	   AND LMS.LOCAT_LV LIKE '%'+@P_LOCAT_LV+'%'
	   AND UPPER(LDT.LOCAT_CD) LIKE '%'+UPPER(@P_LOCAT_CD)+'%'
	   AND UPPER(LDT.LOCAT_NM) LIKE '%'+UPPER(@P_LOCAT_NM)+'%'
	 ORDER BY ACM.SEQ, LMS.LOCAT_LV, LDT.LOCAT_CD, RGP.RES_GRP_CD

END

go

