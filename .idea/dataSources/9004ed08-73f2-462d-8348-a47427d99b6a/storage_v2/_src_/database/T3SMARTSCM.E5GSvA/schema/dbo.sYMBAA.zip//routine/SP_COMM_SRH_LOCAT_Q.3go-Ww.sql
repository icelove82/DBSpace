/*****************************************************************************
Title : SP_COMM_SRH_LOCAT_Q
최초 작성자 : 조아람
최초 생성일 : 2017.11.08
 
설명 
 - 검색조건 : 거점 정보 조회
 
History (수정일자 / 수정자 / 수정내용)
- 2017.11.08 / 조아람 / 최초 작성
 
*****************************************************************************/
CREATE PROCEDURE [dbo].[SP_COMM_SRH_LOCAT_Q]
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

	 SELECT  B.ID			AS LOCAT_MST_ID
            ,B.LOCAT_TP_ID 
            ,A.COMN_CD_NM	AS LOCAT_TP_NM
            ,B.LOCAT_LV
            ,C.ID			AS LOCAT_ID
            ,C.LOCAT_CD
            ,C.LOCAT_NM
            ,D.ID			AS LOCAT_MGMT_ID
       FROM  TB_AD_COMN_CODE A
            ,TB_CM_LOC_MST   B
            ,TB_CM_LOC_DTL   C
            ,TB_CM_LOC_MGMT  D
       WHERE 1=1
        AND A.ID = B.LOCAT_TP_ID
        AND B.ID = C.LOCAT_MST_ID
        AND C.ID = D.LOCAT_ID
        AND B.ACTV_YN = 'Y'
        AND C.ACTV_YN = 'Y'
        AND D.ACTV_YN = 'Y'
      ORDER BY A.SEQ, B.LOCAT_LV, C.LOCAT_CD
	
END

go

