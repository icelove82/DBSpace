
CREATE PROCEDURE [dbo].[SP_UI_CM_08_Q1] (
    @P_BOD_TYPE              NVARCHAR(100) = '' ,
    @P_CONSUME_LOCAT_TP_NM   NVARCHAR(100) = '' ,
    @P_CONSUME_LOCAT_LV      NVARCHAR(100) = '' ,
    @P_CONSUME_LOCAT_CD      NVARCHAR(100) = '' ,
    @P_CONSUME_LOCAT_NM      NVARCHAR(100) = '' ,
    @P_SUPPLY_LOCAT_TP_NM    NVARCHAR(100) = '' ,
    @P_SUPPLY_LOCAT_LV       NVARCHAR(100) = '' ,
    @P_SUPPLY_LOCAT_CD       NVARCHAR(100) = '' ,
    @P_SUPPLY_LOCAT_NM       NVARCHAR(100) = '' ,
    @P_ACCOUNT_CD            NVARCHAR(100) = '' ,
    @P_ACCOUNT_NM            NVARCHAR(100) = '' ,
    @P_VEHICL_VAL            NVARCHAR(100) = '' 
) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

    SELECT  ACM.COMN_CD_NM                          AS BOD_TYPE,
            CONSUME.ID                              AS CONSUME_LOC_MGMT_ID,
            CONSUME.LOCAT_TP_NM                     AS CONSUME_LOC_TP,
            CONSUME.LOCAT_LV                        AS CONSUME_LOC_LV,
            CONSUME.LOCAT_CD                        AS CONSUME_LOC_CD,
            CONSUME.LOCAT_NM                        AS CONSUME_LOC_NM,
            SLM.ACCOUNT_ID,
            ACC.ACCOUNT_CD,
            ACC.ACCOUNT_NM,
            CNT.CHANNEL_NM,
            ICT.INCOTERMS,
            SUPPLY.ID                               AS SUPPLY_LOC_MGMT_ID,
            SUPPLY.LOCAT_TP_NM                      AS SUPPLY_LOC_TP,
            SUPPLY.LOCAT_LV                         AS SUPPLY_LOC_LV,
            SUPPLY.LOCAT_CD                         AS SUPPLY_LOC_CD,
            SUPPLY.LOCAT_NM                         AS SUPPLY_LOC_NM,
            SLM.VEHICL_TP_ID,
            VHC.VEHICL_TP,
            BLT.BOD_LEADTIME_SEQ,
            BLT.BOD_LEADTIME_PERIOD,
            SLD.ID                                  AS SHPP_LEADTIME_DTL_ID,
            LT.COMN_CD_NM                           AS LEADTIME_TP,
            SLD.LEADTIME                            AS BOD_LEADTIME,
            UOM.UOM_NM,
            SLD.SHPP_SCHDL_TP_ID,
            SCT.COMN_CD                             AS SHPP_SCHDL_TP_CD,
            CASE WHEN SCT.COMN_CD = 'DAILY' 
                 THEN ISNULL(EXD.EXIST_EX_SCH, 'N')
                 ELSE ISNULL(EXM.EXIST_EX_SCH, 'N') 
            END                                     AS EXIST_EXCEPTION,
            ISNULL(HOL.EXIST_HOLIDAY, 'N')          AS EXIST_HOLIDAY,
			SLD.ACTV_YN,
            SLD.CREATE_BY,
            SLD.CREATE_DTTM,
            SLD.MODIFY_BY,
            SLD.MODIFY_DTTM
    FROM    TB_CM_SHIP_LT_MST SLM
            LEFT OUTER JOIN TB_DP_ACCOUNT_MST ACC
            ON ACC.ID = SLM.ACCOUNT_ID
            LEFT OUTER JOIN TB_CM_INCOTERMS ICT
            ON ICT.ID = ACC.INCOTERMS_ID
            LEFT OUTER JOIN TB_CM_CHANNEL_TYPE CNT
            ON CNT.ID = ACC.CHANNEL_ID
			INNER JOIN TB_CM_SHIP_LT_DTL SLD
			ON SLM.ID = SLD.SHPP_LEADTIME_MST_ID
            LEFT OUTER JOIN TB_AD_COMN_CODE SCT
            ON SCT.ID = SLD.SHPP_SCHDL_TP_ID
            LEFT OUTER JOIN TB_CM_UOM UOM
            ON UOM.ID = SLD.UOM_ID
            LEFT OUTER JOIN
            (
            SELECT  SHPP_LEADTIME_DTL_ID, 
                    CASE WHEN COUNT(*) > 0 THEN 'Y' ELSE 'N' END AS EXIST_EX_SCH
            FROM    TB_CM_SHIP_LT_EXCEPTION_SCH
            WHERE   ACTV_YN = 'Y'
            AND     TRANSFER_DD IS NULL
            GROUP   BY SHPP_LEADTIME_DTL_ID
            ) EXD
            ON SLD.ID = EXD.SHPP_LEADTIME_DTL_ID
            LEFT OUTER JOIN
            (
            SELECT  SHPP_LEADTIME_DTL_ID, 
                    CASE WHEN COUNT(*) > 0 THEN 'Y' ELSE 'N' END AS EXIST_EX_SCH
            FROM    TB_CM_SHIP_LT_EXCEPTION_SCH
            WHERE   ACTV_YN = 'Y'
            AND     TRANSFER_DD IS NOT NULL
            GROUP   BY SHPP_LEADTIME_DTL_ID
            ) EXM
            ON SLD.ID = EXM.SHPP_LEADTIME_DTL_ID
            LEFT OUTER JOIN 
            (
            SELECT  SHPP_LEADTIME_DTL_ID, 
                    CASE WHEN COUNT(*) > 0 THEN 'Y' ELSE 'N' END AS EXIST_HOLIDAY
            FROM    TB_CM_HOLIDAY
            WHERE   ACTV_YN = 'Y'
            GROUP   BY SHPP_LEADTIME_DTL_ID
            ) HOL
            ON SLD.ID = HOL.SHPP_LEADTIME_DTL_ID
			LEFT OUTER JOIN
            (
            SELECT  LMG.ID, LDT.LOCAT_MST_ID, ACM.COMN_CD_NM AS LOCAT_TP_NM, 
                    LMS.LOCAT_LV, LDT.LOCAT_CD, LDT.LOCAT_NM, ACM.SEQ
            FROM    TB_CM_LOC_MGMT LMG,
                    TB_CM_LOC_DTL LDT,
                    TB_CM_LOC_MST LMS,
                    TB_AD_COMN_CODE ACM
            WHERE   LDT.ID = LMG.LOCAT_ID
            AND     LMS.ID = LDT.LOCAT_MST_ID
            AND     ACM.ID = LMS.LOCAT_TP_ID
            ) CONSUME
			ON CONSUME.ID = SLM.CONSUME_LOCAT_ID
			INNER JOIN
            (
            SELECT  LMG.ID, LDT.LOCAT_MST_ID, ACM.COMN_CD_NM AS LOCAT_TP_NM, 
                    LMS.LOCAT_LV, LDT.LOCAT_CD, LDT.LOCAT_NM, ACM.SEQ
            FROM    TB_CM_LOC_MGMT LMG,
                    TB_CM_LOC_DTL LDT,
                    TB_CM_LOC_MST LMS,
                    TB_AD_COMN_CODE ACM
            WHERE   LDT.ID = LMG.LOCAT_ID
            AND     LMS.ID = LDT.LOCAT_MST_ID
            AND     ACM.ID = LMS.LOCAT_TP_ID
            ) SUPPLY
			ON SUPPLY.ID = SLM.SUPPLY_LOCAT_ID
			INNER JOIN TB_AD_COMN_CODE ACM
			ON ACM.ID = SLM.BOD_TP_ID
            LEFT OUTER JOIN TB_CM_VEHICLE VHC
			ON VHC.ID = SLM.VEHICL_TP_ID
            INNER JOIN TB_CM_BOD_LT BLT
			ON BLT.ID = SLD.BOD_LEADTIME_ID
			AND SLM.VEHICL_TP_ID = BLT.VEHICL_TP_ID
            LEFT OUTER JOIN TB_AD_COMN_CODE LT
            ON LT.ID = BLT.LEADTIME_TP_ID
    WHERE   1=1
	AND 	ACM.ID = CASE WHEN @P_BOD_TYPE = 'ALL' OR @P_BOD_TYPE = ''
                     THEN ACM.ID
                     ELSE @P_BOD_TYPE
                     END
    AND     ISNULL(UPPER(CONSUME.LOCAT_TP_NM), '') 	LIKE '%'+UPPER(@P_CONSUME_LOCAT_TP_NM)+'%'
    AND     ISNULL(UPPER(CONSUME.LOCAT_LV), '') 	LIKE '%'+@P_CONSUME_LOCAT_LV+'%'
    AND     ISNULL(UPPER(CONSUME.LOCAT_CD), '')	 	LIKE '%'+UPPER(@P_CONSUME_LOCAT_CD)+'%'
    AND     ISNULL(UPPER(CONSUME.LOCAT_NM), '')	 	LIKE '%'+UPPER(@P_CONSUME_LOCAT_NM)+'%'
    AND     ISNULL(UPPER(SUPPLY.LOCAT_TP_NM), '') 	LIKE '%'+UPPER(@P_SUPPLY_LOCAT_TP_NM)+'%'
    AND     ISNULL(UPPER(SUPPLY.LOCAT_LV), '')		LIKE '%'+@P_SUPPLY_LOCAT_LV+'%'
    AND     ISNULL(UPPER(SUPPLY.LOCAT_CD), '')	 	LIKE '%'+UPPER(@P_SUPPLY_LOCAT_CD)+'%'
    AND     ISNULL(UPPER(SUPPLY.LOCAT_NM), '')	 	LIKE '%'+UPPER(@P_SUPPLY_LOCAT_NM)+'%'
    AND     ISNULL(UPPER(ACC.ACCOUNT_CD), '')		LIKE '%'+UPPER(@P_ACCOUNT_CD)+'%'
    AND     ISNULL(UPPER(ACC.ACCOUNT_NM), '')		LIKE '%'+DBO.FN_CONVERT_PARAM(@P_ACCOUNT_NM)+'%'
    AND		VHC.VEHICL_TP = CASE WHEN @P_VEHICL_VAL = 'ALL' OR @P_VEHICL_VAL = ''
								 THEN VHC.VEHICL_TP
								 ELSE @P_VEHICL_VAL
							END
    ORDER   BY ACM.COMN_CD_NM, CONSUME.SEQ, CONSUME.LOCAT_LV, CONSUME.LOCAT_CD, ACC.ACCOUNT_CD, 
              SUPPLY.SEQ, SUPPLY.LOCAT_LV, SUPPLY.LOCAT_CD, VHC.VEHICL_TP, BLT.BOD_LEADTIME_SEQ

END

go

