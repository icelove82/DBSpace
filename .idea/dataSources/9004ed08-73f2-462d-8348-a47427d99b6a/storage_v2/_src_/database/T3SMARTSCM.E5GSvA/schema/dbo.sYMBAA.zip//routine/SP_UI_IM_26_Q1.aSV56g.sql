
CREATE PROCEDURE [dbo].[SP_UI_IM_26_Q1] (
	@P_LOCAT_TP NVARCHAR(100) = '' 
   ,@P_LOCAT_LV NVARCHAR(100) = '' 
   ,@P_LOCAT_CD NVARCHAR(100) = '' 
   ,@P_LOCAT_NM NVARCHAR(100) = '' 
   ,@P_ITEM_CD  NVARCHAR(100) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN
    SELECT  A.ID
			,'TOTAL' AS TOTAL_GROUP
            ,E.LOCAT_TP_NM
            ,E.LOCAT_LV
            ,RTRIM(E.LOCAT_CD) AS LOCAT_CD
            ,E.LOCAT_NM
            ,D.ITEM_CD
            ,D.ITEM_NM
            ,D.DESCRIP
            ,J.CONVN_NM	AS ITEM_TP
            ,B.VAL_01
			,H.DESCRIP AS QUADRANT_DESCRIP
            ,B.VAL_02
            ,B.VAL_03
            ,B.VAL_04
            ,B.VAL_05
            ,B.VAL_06
            ,B.VAL_07
            ,B.VAL_08
            ,B.VAL_09
            ,B.VAL_10
            ,B.VAL_11
            ,B.VAL_12
            ,B.VAL_13
            ,B.VAL_14
            ,B.VAL_15
            ,B.VAL_16
            ,B.VAL_17
            ,B.VAL_18
            ,B.VAL_19
            ,B.VAL_20
            ,I.UOM_NM
            ,A.INV_LV_QTY
			,C.STD_UTPIC * A.INV_LV_QTY AS WAREHOUSE_AMT
            ,A.INTRANSIT_QTY
			,C.STD_UTPIC * A.INTRANSIT_QTY AS INTRANSIT_AMT
			,ISNULL(A.INV_LV_QTY, 0) + ISNULL(A.INTRANSIT_QTY, 0) AS INV_QTY
			,C.STD_UTPIC * (ISNULL(A.INV_LV_QTY, 0) + ISNULL(A.INTRANSIT_QTY, 0)) AS INV_AMT
            ,RTRIM(CAST(A.SHPP_ACTUAL_PERIOD AS CHAR)) + ' ' + ISNULL(P.UOM_NM, '')  AS SHPP_ACTUAL_PERIOD
            ,A.AVG_SHPP_ACTUAL_QTY
            ,A.INVTURN
            ,RTRIM(K.COMN_CD_NM)					AS PRPSAL_INV_MGMT_SYSTEM_TP_ID
			,RTRIM(F.COMN_CD_NM)					AS INV_MGMT_SYSTEM_TP_ID
            ,F.COMN_CD                              AS INV_MGMT_SYSTEM_TP_CD
            ,RTRIM(L.COMN_CD_NM)		            AS PO_CYCL_CD
            ,RTRIM(A.PO_CYCL_CALENDAR_ID)           AS PO_CYCL_CALENDAR_ID
            ,G.CALENDAR_ID                          AS PO_CYCL_CALENDAR
			,RTRIM(M.COMN_CD_NM)					AS OPERT_BASE_TP
			,RTRIM(N.COMN_CD_NM)					AS INV_PLACE_STRTGY_ID
            ,SUPPLY_LEADTIME_PRPSAL_VAL
            ,SUPPLY_LEADTIME
            ,SUPPLY_LEADTIME_YN
            ,PO_CYCL_YN
            ,REPLSH_LEADTIME
            ,OPERT_LV_VAL
            ,OPERT_TARGET_VAL
            ,PRPSAL_SVC_LV
            ,SFST_SVC_LV
            ,SFST_DEMDVAR_CONSID_YN
            ,SFST_DEMDVAR_STDDEV
            ,SFST_SUPYVAR_CONSID_YN
            ,RTRIM(SFST_DMND_RATE_CAL_TP_ID)        AS SFST_DMND_RATE_CAL_TP_ID
            ,SFST_DMND_RATE
            ,SUPYVAR_STDDEV
            ,SFST_PRPSAL_VAL
            ,SFST_VAL
			,C.STD_UTPIC * SFST_VAL					AS SFST_AMT
            ,RTRIM(ROP_CAL_TP_ID)                   AS ROP_CAL_TP_ID
            ,ROP_SFST_CONSID_YN
            ,ROP_OPERT_INV_CONSID_YN
            ,ROP_RIGHT_RATE_YN
            ,RTRIM(ROP_DMND_RATE_CAL_MTD_ID )       AS ROP_DMND_RATE_CAL_MTD_ID
            ,ROP_DMND_RATE
            ,ROP_RIGHT_RATE_TARGET
            ,ROP_PRPSAL_VAL
            ,ROP_VAL
			,C.STD_UTPIC * ROP_VAL					AS ROP_AMT
            ,RTRIM(EOQ_CAL_TP_ID)                   AS EOQ_CAL_TP_ID
            ,EOQ_RIGHT_RATE_YN
            ,RTRIM(EOQ_DMND_RATE_CAL_MTD_ID)        AS EOQ_DMND_RATE_CAL_MTD_ID
            ,EOQ_DMND_RATE
            ,EOQ_RIGHT_RATE_TARGET
			,EOQ_MULTIPLE
            ,EOQ_PRPSAL_VAL
            ,EOQ_VAL
			,C.STD_UTPIC * EOQ_VAL					AS EOQ_AMT
            ,RTRIM(OPERT_INV_DMND_RATE_CAL_MTD_ID)  AS OPT_INV_DMND_RATE_CAL_MTD_ID
            ,OPERT_INV_DMND_RATE
            ,OPERT_INV_PRPSAL_VAL
            ,OPERT_INV_VAL
			,C.STD_UTPIC * OPERT_INV_VAL			AS OPERT_INV_AMT
            ,TARGET_INV_SFST_CONSID_YN
            ,TARGET_INV_OPERT_INV_CONSID_YN
            ,TARGET_INV_PRPSAL_VAL
            ,TARGET_INV_VAL
			,C.STD_UTPIC * TARGET_INV_VAL			AS TARGET_INV_AMT
			,A.MOQ
			,A.MULTIPLIER
            ,A.FIXED_YN
            ,A.ACTV_YN
            ,A.CREATE_BY
            ,A.CREATE_DTTM
            ,A.MODIFY_BY
            ,A.MODIFY_DTTM
    FROM   TB_IM_INV_POLICY_ITEM A
            INNER JOIN
            TB_CM_SITE_ITEM C
        ON A.LOCAT_ITEM_ID = C.ID
            INNER JOIN
            TB_IM_SITE_ITEM_SEG_SUMM B
        ON C.ID = B.LOCAT_ITEM_ID
            INNER JOIN
            TB_CM_ITEM_MST D
        ON C.ITEM_MST_ID = D.ID
            INNER JOIN
            VW_LOCAT_INFO E
        ON C.LOCAT_MGMT_ID = E.LOCAT_MGMT_ID
            INNER JOIN
            TB_AD_COMN_CODE F
        ON (A.INV_MGMT_SYSTEM_TP_ID = F.ID)
            LEFT OUTER JOIN
            TB_IM_PO_CALENDAR G
        ON (A.PO_CYCL_CALENDAR_ID = G.ID)
			LEFT OUTER JOIN 
			TB_AD_COMN_CODE H
		ON (H.COMN_CD = B.VAL_01)
			LEFT OUTER JOIN
			TB_CM_UOM I
		ON (I.ID = D.UOM_ID)
			INNER JOIN TB_CM_ITEM_TYPE J
		ON (J.ID = D.ITEM_TP_ID)
            LEFT OUTER JOIN
            TB_AD_COMN_CODE K
        ON (A.PRPSAL_INV_MGMT_SYSTEM_TP_ID = K.ID)
			LEFT OUTER JOIN 
			TB_AD_COMN_CODE L
		ON (A.PO_CYCL_CD_ID = L.ID)
			LEFT OUTER JOIN 
			TB_AD_COMN_CODE M
		ON (A.OPERT_BASE_TP_ID = M.ID)
			LEFT OUTER JOIN 
			TB_AD_COMN_CODE N
		ON (A.INV_PLACE_STRTGY_ID = N.ID)
			LEFT OUTER JOIN 
	        TB_IM_VARIABILITY_ACT_PRIOD O
		ON (O.LOCAT_ID = E.LOCAT_DTL_ID
		AND CATAGY_VAL = 'FINAL_PRODUCT_GR_ITEM_INVTURN')
		    LEFT OUTER JOIN
			TB_CM_UOM P
	    ON (P.ID = O.UOM_ID)
    WHERE   1=1
        AND UPPER(E.LOCAT_TP_NM) LIKE '%'+ UPPER(@P_LOCAT_TP)+'%'
        AND E.LOCAT_LV LIKE '%'+ UPPER(@P_LOCAT_LV) +'%'
        AND RTRIM(E.LOCAT_CD) LIKE '%'+UPPER(@P_LOCAT_CD) +'%'
        AND UPPER(E.LOCAT_NM) LIKE '%' +UPPER(@P_LOCAT_NM) +'%'
		AND UPPER(D.ID) IN (SELECT ID FROM FN_IM_TEMP_FIND_ITEM(ISNULL(@P_ITEM_CD, '')))
END;
go

