CREATE PROCEDURE [dbo].[SP_UI_CM_03_S1] (
     @P_ITEM_SCOPE_MST_ID CHAR(32) = NULL
    ,@P_ITEM_CLASS_VAL    NVARCHAR(50) = NULL
	,@P_DESCRIP           NVARCHAR(50) = NULL
	,@P_CONTINU_PRDUCT_YN CHAR(1) = NULL
	,@P_PROD_MIX_YN       CHAR(1) = NULL
	,@P_ATTR_01           CHAR(32) = NULL
	,@P_ATTR_02           CHAR(32) = NULL
	,@P_ATTR_03           CHAR(32) = NULL
	,@P_ATTR_04           CHAR(32) = NULL
	,@P_ATTR_05           CHAR(32) = NULL
	,@P_ATTR_06           CHAR(32) = NULL
	,@P_ATTR_07           CHAR(32) = NULL
	,@P_ATTR_08           CHAR(32) = NULL
	,@P_ATTR_09           CHAR(32) = NULL
	,@P_ATTR_10           CHAR(32) = NULL
	,@P_ATTR_11           CHAR(32) = NULL
	,@P_ATTR_12           CHAR(32) = NULL
	,@P_ATTR_13           CHAR(32) = NULL
	,@P_ATTR_14           CHAR(32) = NULL
	,@P_ATTR_15           CHAR(32) = NULL
	,@P_ATTR_16           CHAR(32) = NULL
	,@P_ATTR_17           CHAR(32) = NULL
	,@P_ATTR_18           CHAR(32) = NULL
	,@P_ATTR_19           CHAR(32) = NULL
	,@P_ATTR_20           CHAR(32) = NULL
	,@P_ACTV_YN           CHAR(32) = NULL
	,@P_USER_ID           NVARCHAR(100) = NULL
    ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10) = 'true' OUTPUT
    ,@P_RT_MSG            NVARCHAR(4000) = ''	OUTPUT
) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS	INT = 0
       ,@P_ERR_MSG		NVARCHAR(4000)=''
	   ,@V_DUP_ITEM_CLASS INT = 0

BEGIN TRY
	SET @P_ERR_MSG = 'MSG_0006'
	IF ISNULL(@P_ITEM_SCOPE_MST_ID, '') = '' RAISERROR(@P_ERR_MSG, 12, 1);
	IF ISNULL(@P_ITEM_CLASS_VAL, '') = '' RAISERROR(@P_ERR_MSG, 12, 1);

	IF @P_CONTINU_PRDUCT_YN = 'Y'
		BEGIN
			SELECT	@V_DUP_ITEM_CLASS = COUNT(1)
			FROM	TB_CM_ITEM_CLASS_MST
			WHERE	ITEM_SCOPE_MST_ID = @P_ITEM_SCOPE_MST_ID
			AND		CONTINU_PRDUCT_YN = 'Y'

			SET @P_ERR_MSG = 'MSG_5147'
			IF @V_DUP_ITEM_CLASS > 0 RAISERROR(@P_ERR_MSG, 12, 1);
		END

	IF @P_PROD_MIX_YN = 'Y'
		BEGIN
			SELECT	@V_DUP_ITEM_CLASS = COUNT(1)
			FROM	TB_CM_ITEM_CLASS_MST
			WHERE	ITEM_SCOPE_MST_ID = @P_ITEM_SCOPE_MST_ID
			AND		ITEM_CLASS_VAL != @P_ITEM_CLASS_VAL
			AND     ISNULL(ATTR_01, '') = ISNULL(@P_ATTR_01, '')
			AND     ISNULL(ATTR_02, '') = ISNULL(@P_ATTR_02, '')
			AND     ISNULL(ATTR_03, '') = ISNULL(@P_ATTR_03, '')
			AND     ISNULL(ATTR_04, '') = ISNULL(@P_ATTR_04, '')
			AND     ISNULL(ATTR_05, '') = ISNULL(@P_ATTR_05, '')
			AND     ISNULL(ATTR_06, '') = ISNULL(@P_ATTR_06, '')
			AND     ISNULL(ATTR_07, '') = ISNULL(@P_ATTR_07, '')
			AND     ISNULL(ATTR_08, '') = ISNULL(@P_ATTR_08, '')
			AND     ISNULL(ATTR_09, '') = ISNULL(@P_ATTR_09, '')
			AND     ISNULL(ATTR_10, '') = ISNULL(@P_ATTR_10, '')
			AND     ISNULL(ATTR_11, '') = ISNULL(@P_ATTR_11, '')
			AND     ISNULL(ATTR_12, '') = ISNULL(@P_ATTR_12, '')
			AND     ISNULL(ATTR_13, '') = ISNULL(@P_ATTR_13, '')
			AND     ISNULL(ATTR_14, '') = ISNULL(@P_ATTR_14, '')
			AND     ISNULL(ATTR_15, '') = ISNULL(@P_ATTR_15, '')
			AND     ISNULL(ATTR_16, '') = ISNULL(@P_ATTR_16, '')
			AND     ISNULL(ATTR_17, '') = ISNULL(@P_ATTR_17, '')
			AND     ISNULL(ATTR_18, '') = ISNULL(@P_ATTR_18, '')
			AND     ISNULL(ATTR_19, '') = ISNULL(@P_ATTR_19, '')
			AND     ISNULL(ATTR_20, '') = ISNULL(@P_ATTR_20, '')
			AND		PROD_MIX_YN = 'Y'

			SET @P_ERR_MSG = 'MSG_5022'
			IF @V_DUP_ITEM_CLASS > 0 RAISERROR(@P_ERR_MSG, 12, 1);
		END

	MERGE INTO TB_CM_ITEM_CLASS_MST A
    USING (
          SELECT @P_ITEM_SCOPE_MST_ID   AS ITEM_SCOPE_MST_ID
            	,@P_ITEM_CLASS_VAL	    AS ITEM_CLASS_VAL
	      ) B
	ON (A.ITEM_SCOPE_MST_ID = @P_ITEM_SCOPE_MST_ID AND A.ITEM_CLASS_VAL = @P_ITEM_CLASS_VAL)
	WHEN MATCHED THEN 
		UPDATE 
		SET 	 DESCRIP				= @P_DESCRIP
				,CONTINU_PRDUCT_YN		= @P_CONTINU_PRDUCT_YN
				,PROD_MIX_YN			= @P_PROD_MIX_YN
				,ATTR_01				= @P_ATTR_01
				,ATTR_02				= @P_ATTR_02
				,ATTR_03				= @P_ATTR_03
				,ATTR_04				= @P_ATTR_04
				,ATTR_05				= @P_ATTR_05
				,ATTR_06				= @P_ATTR_06
				,ATTR_07				= @P_ATTR_07
				,ATTR_08				= @P_ATTR_08
				,ATTR_09				= @P_ATTR_09
				,ATTR_10				= @P_ATTR_10
				,ATTR_11				= @P_ATTR_11
				,ATTR_12				= @P_ATTR_12
				,ATTR_13				= @P_ATTR_13
				,ATTR_14				= @P_ATTR_14
				,ATTR_15				= @P_ATTR_15
				,ATTR_16				= @P_ATTR_16
				,ATTR_17				= @P_ATTR_17
				,ATTR_18				= @P_ATTR_18
				,ATTR_19				= @P_ATTR_19
				,ATTR_20				= @P_ATTR_20
				,ACTV_YN				= @P_ACTV_YN
				,MODIFY_BY				= @P_USER_ID
				,MODIFY_DTTM			= GETDATE()
	WHEN NOT MATCHED THEN 
        INSERT (
                ID
                ,ITEM_SCOPE_MST_ID
                ,ITEM_CLASS_VAL
                ,DESCRIP
                ,CONTINU_PRDUCT_YN
                ,PROD_MIX_YN
                ,ATTR_01
                ,ATTR_02
                ,ATTR_03
                ,ATTR_04
                ,ATTR_05
                ,ATTR_06
                ,ATTR_07
                ,ATTR_08
                ,ATTR_09
                ,ATTR_10
                ,ATTR_11
                ,ATTR_12
                ,ATTR_13
                ,ATTR_14
                ,ATTR_15
                ,ATTR_16
                ,ATTR_17
                ,ATTR_18
                ,ATTR_19
                ,ATTR_20
                ,ACTV_YN
                ,CREATE_BY
                ,CREATE_DTTM
			)			
		VALUES (
                REPLACE(NEWID(),'-','')
                ,@P_ITEM_SCOPE_MST_ID 
                ,@P_ITEM_CLASS_VAL	 
                ,@P_DESCRIP			
                ,@P_CONTINU_PRDUCT_YN
                ,@P_PROD_MIX_YN
                ,@P_ATTR_01
                ,@P_ATTR_02
                ,@P_ATTR_03
                ,@P_ATTR_04
                ,@P_ATTR_05
                ,@P_ATTR_06
                ,@P_ATTR_07
                ,@P_ATTR_08
                ,@P_ATTR_09
                ,@P_ATTR_10
                ,@P_ATTR_11
                ,@P_ATTR_12
                ,@P_ATTR_13
                ,@P_ATTR_14
                ,@P_ATTR_15
                ,@P_ATTR_16
                ,@P_ATTR_17
                ,@P_ATTR_18
                ,@P_ATTR_19
                ,@P_ATTR_20
                ,@P_ACTV_YN
                ,@P_USER_ID
                ,GETDATE()
			);

	SET @P_RT_ROLLBACK_FLAG = 'true'
	SET @P_RT_MSG = 'MSG_0001'

END TRY
BEGIN CATCH
	IF (ERROR_MESSAGE() LIKE 'MSG_%')
		BEGIN
			SET @P_ERR_MSG = ERROR_MESSAGE()
			SET @P_RT_ROLLBACK_FLAG = 'false'
			SET @P_RT_MSG = @P_ERR_MSG
		END
	ELSE
		THROW;
END CATCH

go

