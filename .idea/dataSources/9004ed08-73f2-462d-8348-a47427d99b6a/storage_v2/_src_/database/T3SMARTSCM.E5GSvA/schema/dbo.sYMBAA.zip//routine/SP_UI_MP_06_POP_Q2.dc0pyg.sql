/*****************************************************************************
Title : SP_UI_MP_06_POP_Q2
최초 작성자 : 조아람
최초 생성일 : 2017.08.09
 
설명 
 - MP Resource Management(POP_UI_MP_06_04) Resource Group-  조회 프로시저
 
History (수정일자 / 수정자 / 수정내용)
- 2017.08.09 / 조아람 / 최초 작성
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_MP_06_POP_Q2] (
	 @P_VIEW_ID	NVARCHAR(50) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

	SELECT	RGP.ID							AS RES_GRP_ID
		  , RGP.RES_GRP_CD					AS RES_GRP_CD
		  , RGP.DESCRIP						AS RES_GRP_DESCRIP
		  , RGP.RES_GRP_TP_ID				AS RES_GRP_TP_ID
		  , ACD.COMN_CD_NM					AS RES_GRP_TP
		  , @P_VIEW_ID						AS VIEW_ID
	  FROM TB_CM_RES_GROUP	RGP
		   INNER JOIN TB_AD_COMN_CODE	ACD
		   ON RGP.RES_GRP_TP_ID = ACD.ID
	 WHERE 1=1

END

go

