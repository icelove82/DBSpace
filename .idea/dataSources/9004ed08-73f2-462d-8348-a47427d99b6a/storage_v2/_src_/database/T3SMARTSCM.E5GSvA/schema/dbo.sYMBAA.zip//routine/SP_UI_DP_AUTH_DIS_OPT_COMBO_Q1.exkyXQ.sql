/*****************************************************************************
Title : [SP_UI_DP_AUTH_DIS_OPT_COMBO_Q1]
최초 작성자 : 이고은
최초 생성일 : 2017.07.21
 
설명 
 - DP Entry Dis.Oprion Combo
  
History (수정일자 / 수정자 / 수정내용)
- 2017.07.21 / 이고은 / 최초 작성
- 2019.04.25 / 김소희 / DEL_YN Null처리 
- 2020.11.02 / KSH / add a condition about group ID
	- 2020.11.10 / Kim sohee / data type of CODE NVARCHAR(100)
- 2020.11.17 / Kim sohee / auth type ID => Group ID 
- 2021.01.10 / Kim sohee / add a param (UI ID, Grid ID)
- 2021.01.29 / Kim sohee / code 정리 
- 2021.01.06 / kim sohee / convert grid ID
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_AUTH_DIS_OPT_COMBO_Q1]  
(
	@p_AUTH_TP		NVARCHAR(100)
	,@p_UI_ID		NVARCHAR(50)
	,@P_GRID_ID		NVARCHAR(100)
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
BEGIN


DECLARE @V_GRP_ID	char(32) -- CD를 ID로 변환
	SET @P_GRID_ID = REPLACE(@P_GRID_ID, @P_UI_ID+'-', '');

--AUTH TP CD를 ID로 변환
--SELECT	@V_GRP_ID	= LV.ID
--FROM	TB_CM_COMM_CONFIG GRP			
--		INNER JOIN TB_CM_LEVEL_MGMT LV	ON GRP.ID = LV.LV_TP_ID 
--WHERE	1=1
--AND		GRP.CONF_GRP_CD	= 'DP_LV_TP'
--AND		GRP.ACTV_YN		= 'Y'
--AND		GRP.CONF_CD		= 'S'
--AND		LV.ACTV_YN		= 'Y'
--AND		ISNULL(LV.DEL_YN,'N')		= 'N'
--AND		LV.LV_CD		= @p_AUTH_TP
SELECT @V_GRP_ID = ID 
  FROM TB_AD_GROUP 
WHERE GRP_CD = @p_AUTH_TP
 

 
 
		
SELECT	DISTINCT A.ID, A.CD, A.DISP_NM AS CD_NM, A.DIS_SEQ,A.SEQ, CONCAT(CONCAT(A.CD, '|'), A.R_TYPE) as D_RULE
                   , MS_KEY
                   , VAL_TP
                   , R_TYPE
FROM	(
			SELECT	 @p_UI_ID		AS UI_ID
					,@p_GRID_ID		AS GRID_ID
					,@V_GRP_ID AS GRP_ID
					,'N'			AS ID
					,'N'			AS CD
					,'1/N'			AS DISP_NM
					,0				AS DIS_SEQ
					,0				AS SEQ
					,'N' as R_TYPE
                        ,NULL   AS MS_KEY
                        ,NULL   AS VAL_TP
			UNION 

			SELECT	 @p_UI_ID		AS UI_ID
					,@p_GRID_ID		AS GRID_ID
					,@V_GRP_ID  
					,'SAME'			AS ID
					,'SAME'			AS CD
					,'Same Value'	AS DISP_NM
					,0				AS DIS_SEQ
					,1				AS SEQ
					,'SAME' as R_TYPE
                        ,NULL   AS MS_KEY
                        ,NULL   AS VAL_TP
			UNION  
/*
			SELECT	 A.UI_ID
					,A.GRID_ID
					,@V_GRP_ID --A.AUTH_TP_ID
					,A.ID
					,C.LV_CD AS CD
					,A.DISP_NM
					--,E.CONF_CD
					,1 AS DIS_SEQ
					,A.SEQ
					,'DEMAND' as R_TYPE
			FROM	[TB_DP_MEASURE_SETTING] A 
					LEFT OUTER JOIN TB_CM_COMM_CONFIG B  ON A.MEASURE_CONF_TP_ID = B.ID
					LEFT OUTER JOIN (SELECT  B.ID, B.LV_CD
									FROM	TB_CM_COMM_CONFIG A
											LEFT OUTER JOIN TB_CM_LEVEL_MGMT B  ON A.ID = B.LV_TP_ID
									WHERE	1=1
									AND		A.CONF_GRP_CD	= 'DP_LV_TP'
									AND		A.CONF_CD		= 'S'
									AND		A.ACTV_YN		= 'Y'
									AND		B.ACTV_YN		= 'Y'
									AND		ISNULL(B.DEL_YN,'N')		= 'N'
									AND		B.SALES_LV_YN = 'Y') C ON A.LV_MGMT_ID = C.ID
			WHERE	1=1
			AND		B.CONF_GRP_CD = 'DP_MS_INPUT_TP'
			AND		B.ACTV_YN = 'Y'
			AND		A.GRP_ID  = @V_GRP_ID
			AND		B.CONF_CD = 'DEMAND'

			UNION 

			SELECT	 A.UI_ID
					,A.GRID_ID
					,@V_GRP_ID
					,A.ID
					,C.MEASURE_CD AS CD
					,A.DISP_NM
					,2 AS DIS_SEQ
					,A.SEQ AS SEQ
					,'ADDITION' as R_TYPE
			FROM	TB_DP_MEASURE_SETTING A 
					LEFT OUTER JOIN TB_CM_COMM_CONFIG B  ON A.MEASURE_CONF_TP_ID = B.ID
					LEFT OUTER JOIN TB_DP_MEASURE_MST C  ON A.MEASURE_MST_ID = C.ID
					LEFT OUTER JOIN TB_CM_COMM_CONFIG D  ON C.MEASURE_VAL_TP_ID = D.ID
			WHERE	1=1
			AND		B.CONF_GRP_CD = 'DP_MS_INPUT_TP'
			AND		B.ACTV_YN = 'Y'
			AND		A.GRP_ID  = @V_GRP_ID
			AND		B.CONF_CD = 'ADDITION'
			AND		D.CONF_GRP_CD	= 'DP_MS_VAL_TP'
			AND		D.ACTV_YN		= 'Y'
*/			
			SELECT 
              MS.UI_ID
            , MS.GRID_ID
            , MS.GRP_ID
            , MS.ID 
            , CASE CF.CONF_CD 
					WHEN 'ADDITION' THEN ME.MEASURE_CD
					WHEN 'DEMAND'	THEN LV.LV_CD 
				   END	AS CD
            ,MS.DISP_NM
            ,CASE CF.CONF_CD 
					WHEN 'ADDITION' THEN 2
					WHEN 'DEMAND'	THEN 1 
				   END	AS DIS_SEQ
            ,MS.SEQ
			, CF.CONF_CD		AS R_TYPE
            ,   CASE CF.CONF_CD 
					WHEN 'ADDITION' THEN (CASE WHEN CF.CONF_CD LIKE 'RTF%' THEN ME.TBL_NM ELSE 'TB_DP_MEASURE_DATA' END )
					WHEN 'DEMAND'	THEN LV.ID  
				   END	AS MS_KEY
				 , VT.CONF_CD		AS VAL_TP
			 FROM TB_DP_MEASURE_SETTING MS
				  INNER JOIN 
				  TB_CM_COMM_CONFIG CF  
			   ON MS.MEASURE_CONF_TP_ID = CF.ID
			      LEFT OUTER JOIN
				  TB_DP_MEASURE_MST ME
			   ON MS.MEASURE_MST_ID = ME.ID
			      LEFT OUTER JOIN
				  TB_CM_LEVEL_MGMT LV
			   ON MS.LV_MGMT_ID = LV.ID 
			      INNER JOIN
				  TB_CM_COMM_CONFIG VT
			   ON MS.MEASURE_VAL_TP_ID = VT.ID    
            WHERE UI_ID = @p_UI_ID
              AND GRID_ID = @p_GRID_ID
              AND GRP_ID = @v_GRP_ID 
			  AND MS.ACTV_YN = 'Y'
			) A
WHERE 1=1
-- AND		A.UI_ID = @p_UI_ID
-- AND		A.GRID_ID = @p_GRID_ID
-- AND		A.GRP_ID = @V_GRP_ID
ORDER BY A.DIS_SEQ, A.SEQ
	


END





go

