
CREATE PROCEDURE [dbo].[SP_UI_CM_18_S1] (
     @P_WRK_TYPE            AS NVARCHAR(10)
    ,@P_ID                  AS NVARCHAR(32)     = ''
    ,@P_ITEM_CD             AS NVARCHAR(100)    = ''
    ,@P_ITEM_NM             AS NVARCHAR(240)    = ''
    ,@P_UOM_ID              AS NVARCHAR(32)     = ''
    ,@P_ITEM_TP_ID          AS CHAR(32)         = ''
    ,@P_MIN_ORDER_SIZE      AS INT              = NULL
    ,@P_MAX_ORDER_SIZE      AS INT              = NULL
    ,@P_DESCRIP             AS NVARCHAR(3000)   = ''
    ,@P_DP_PLAN_YN          AS CHAR(1)          = ''
    ,@P_PARENT_ITEM_LV_ID   AS NVARCHAR(32)     = ''
    ,@P_RTS                 AS DATETIME         = NULL
    ,@P_EOS                 AS DATETIME         = NULL
    ,@P_DEL_YN              AS CHAR(1)          = ''
    ,@P_ATTR_01             AS NVARCHAR(100)    = ''
    ,@P_ATTR_02             AS NVARCHAR(100)    = ''
    ,@P_ATTR_03             AS NVARCHAR(100)    = ''
    ,@P_ATTR_04             AS NVARCHAR(100)    = ''
    ,@P_ATTR_05             AS NVARCHAR(100)    = ''
    ,@P_ATTR_06             AS NVARCHAR(100)    = ''
    ,@P_ATTR_07             AS NVARCHAR(100)    = ''
    ,@P_ATTR_08             AS NVARCHAR(100)    = ''
    ,@P_ATTR_09             AS NVARCHAR(100)    = ''
    ,@P_ATTR_10             AS NVARCHAR(100)    = ''
    ,@P_ATTR_11             AS NVARCHAR(100)    = ''
    ,@P_ATTR_12             AS NVARCHAR(100)    = ''
    ,@P_ATTR_13             AS NVARCHAR(100)    = ''
    ,@P_ATTR_14             AS NVARCHAR(100)    = ''
    ,@P_ATTR_15             AS NVARCHAR(100)    = ''
    ,@P_ATTR_16             AS NVARCHAR(100)    = ''
    ,@P_ATTR_17             AS NVARCHAR(100)    = ''
    ,@P_ATTR_18             AS NVARCHAR(100)    = ''
    ,@P_ATTR_19             AS NVARCHAR(100)    = ''
    ,@P_ATTR_20             AS NVARCHAR(100)    = ''
    ,@P_ATTR_21             AS NVARCHAR(100)    = ''
    ,@P_ATTR_22             AS NVARCHAR(100)    = ''
    ,@P_ATTR_23             AS NVARCHAR(100)    = ''
    ,@P_ATTR_24             AS NVARCHAR(100)    = ''
    ,@P_ATTR_25             AS NVARCHAR(100)    = ''
    ,@P_DISPLAY_COLOR       AS NVARCHAR(100)    = ''
    ,@P_USER_ID             AS NVARCHAR(50)     = ''  
    ,@P_RT_ROLLBACK_FLAG    AS NVARCHAR(10)     = 'true'  OUTPUT
    ,@P_RT_MSG              AS NVARCHAR(4000)   = ''      OUTPUT
) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE 
	 @P_ERR_STATUS INT = 0
	,@P_ERR_MSG NVARCHAR(4000) =''
    ,@V_RTS DATETIME = NULL
    ,@V_EOS DATETIME = NULL 

	SET @P_RTS = CASE WHEN @P_RTS = '1901-01-01' THEN NULL
				      ELSE @P_RTS END
	SET @P_EOS = CASE WHEN @P_EOS = '1901-01-01' THEN NULL
					  ELSE @P_EOS END

	SET @V_RTS              	= @P_RTS
	SET @V_EOS              	= @P_EOS

BEGIN TRY
	IF @P_WRK_TYPE = 'SAVE'
		BEGIN
			SELECT @P_ERR_STATUS = count(*)
				FROM TB_CM_ITEM_MST
				WHERE 1=1
				AND ITEM_CD = @P_ITEM_CD
				AND ID != @P_ID
				;
			IF ( @P_ERR_STATUS > 0 )
				BEGIN
					SET @P_ERR_MSG = 'MSG_0013'
					RAISERROR (@P_ERR_MSG,12, 1)
				END

			IF (ISNULL(@P_ITEM_CD,'') ='')
				BEGIN
					SET @P_ERR_MSG = 'Item Code is empty.'
					RAISERROR (@P_ERR_MSG,12, 1)
				END
			IF (ISNULL(@P_ITEM_NM,'') ='')
				BEGIN
					SET @P_ERR_MSG = 'Item Name is empty.'
					RAISERROR (@P_ERR_MSG,12, 1)
				END
			IF (ISNULL(@P_ITEM_TP_ID,'') ='')
				BEGIN
					SET @P_ERR_MSG = 'Item Type is empty.'
					RAISERROR (@P_ERR_MSG,12, 1)
				END
		
			IF (@V_RTS > @V_EOS)
				begin
					SET @P_ERR_MSG = 'MSG_5149'
					RAISERROR (@P_ERR_MSG,12, 1)
				END;

			-- 프로시저 시작 
			MERGE TB_CM_ITEM_MST TGT
			USING ( 
					SELECT   @P_ID                    AS ID
							,@P_ITEM_CD           	  AS ITEM_CD
							,@P_ITEM_NM           	  AS ITEM_NM
							,@P_UOM_ID        		  AS UOM_ID
							,@P_ITEM_TP_ID			  AS ITEM_TP_ID
							,@P_DESCRIP           	  AS DESCRIP
							,@P_DP_PLAN_YN        	  AS DP_PLAN_YN
							,@P_PARENT_ITEM_LV_ID 	  AS PARENT_ITEM_LV_ID
							,@V_RTS               	  AS RTS
							,@V_EOS               	  AS EOS
							,@P_DEL_YN             	  AS DEL_YN
							,@P_ATTR_01           	  AS ATTR_01
							,@P_ATTR_02				  AS ATTR_02
							,@P_ATTR_03				  AS ATTR_03
							,@P_ATTR_04				  AS ATTR_04
							,@P_ATTR_05				  AS ATTR_05
							,@P_ATTR_06				  AS ATTR_06
							,@P_ATTR_07				  AS ATTR_07
							,@P_ATTR_08				  AS ATTR_08
							,@P_ATTR_09				  AS ATTR_09
							,@P_ATTR_10				  AS ATTR_10
							,@P_ATTR_11				  AS ATTR_11
							,@P_ATTR_12				  AS ATTR_12
							,@P_ATTR_13				  AS ATTR_13
							,@P_ATTR_14				  AS ATTR_14
							,@P_ATTR_15				  AS ATTR_15
							,@P_ATTR_16				  AS ATTR_16
							,@P_ATTR_17				  AS ATTR_17
							,@P_ATTR_18				  AS ATTR_18
							,@P_ATTR_19				  AS ATTR_19
							,@P_ATTR_20				  AS ATTR_20
							,@P_ATTR_21				  AS ATTR_21
							,@P_ATTR_22				  AS ATTR_22
							,@P_ATTR_23				  AS ATTR_23
							,@P_ATTR_24				  AS ATTR_24
							,@P_ATTR_25				  AS ATTR_25
							,@P_DISPLAY_COLOR		  AS DISPLAY_COLOR
							,@P_USER_ID           	  AS USER_ID
							,@P_MIN_ORDER_SIZE        AS MIN_ORDER_SIZE
							,@P_MAX_ORDER_SIZE        AS MAX_ORDER_SIZE
					) SRC
			ON     TGT.ID = SRC.ID
			WHEN MATCHED THEN
				UPDATE 
				SET  TGT.ITEM_CD              = SRC.ITEM_CD           
					,TGT.ITEM_NM           	  = SRC.ITEM_NM           
					,TGT.UOM_ID            	  = SRC.UOM_ID            
					,TGT.ITEM_TP_ID        	  = SRC.ITEM_TP_ID        
					,TGT.DESCRIP           	  = SRC.DESCRIP           
					,TGT.DP_PLAN_YN        	  = SRC.DP_PLAN_YN
					,TGT.GRADE_YN        	  = SRC.DP_PLAN_YN
					,TGT.PARENT_ITEM_LV_ID 	  = SRC.PARENT_ITEM_LV_ID 
					,TGT.RTS               	  = SRC.RTS               
					,TGT.EOS               	  = SRC.EOS               
					,TGT.DEL_YN            	  = SRC.DEL_YN            
					,TGT.ATTR_01           	  = SRC.ATTR_01           
					,TGT.ATTR_02			  = SRC.ATTR_02			
					,TGT.ATTR_03			  = SRC.ATTR_03			
					,TGT.ATTR_04			  = SRC.ATTR_04			
					,TGT.ATTR_05			  = SRC.ATTR_05			
					,TGT.ATTR_06			  = SRC.ATTR_06			
					,TGT.ATTR_07			  = SRC.ATTR_07			
					,TGT.ATTR_08			  = SRC.ATTR_08			
					,TGT.ATTR_09			  = SRC.ATTR_09			
					,TGT.ATTR_10			  = SRC.ATTR_10			
					,TGT.ATTR_11			  = SRC.ATTR_11			
					,TGT.ATTR_12			  = SRC.ATTR_12			
					,TGT.ATTR_13			  = SRC.ATTR_13			
					,TGT.ATTR_14			  = SRC.ATTR_14			
					,TGT.ATTR_15			  = SRC.ATTR_15			
					,TGT.ATTR_16			  = SRC.ATTR_16			
					,TGT.ATTR_17			  = SRC.ATTR_17			
					,TGT.ATTR_18			  = SRC.ATTR_18			
					,TGT.ATTR_19			  = SRC.ATTR_19
					,TGT.ATTR_20			  = SRC.ATTR_20
					,TGT.ATTR_21			  = SRC.ATTR_21
					,TGT.ATTR_22			  = SRC.ATTR_22
					,TGT.ATTR_23			  = SRC.ATTR_23
					,TGT.ATTR_24			  = SRC.ATTR_24
					,TGT.ATTR_25			  = SRC.ATTR_25
					,TGT.DISPLAY_COLOR		  = SRC.DISPLAY_COLOR
					,TGT.MODIFY_BY            = SRC.USER_ID       
					,TGT.MODIFY_DTTM          = GETDATE()       
					,TGT.MIN_ORDER_SIZE       = SRC.MIN_ORDER_SIZE
					,TGT.MAX_ORDER_SIZE       = SRC.MAX_ORDER_SIZE
			WHEN NOT MATCHED THEN 
				INSERT (
						 ID                
						,ITEM_CD           
						,ITEM_NM           
						,UOM_ID            
						,ITEM_TP_ID        
						,DESCRIP           
						,DP_PLAN_YN        
						,GRADE_YN
						,PARENT_ITEM_LV_ID 
						,RTS               
						,EOS               
						,DEL_YN            
						,ATTR_01           
						,ATTR_02			
						,ATTR_03			
						,ATTR_04			
						,ATTR_05			
						,ATTR_06			
						,ATTR_07			
						,ATTR_08			
						,ATTR_09			
						,ATTR_10			
						,ATTR_11			
						,ATTR_12			
						,ATTR_13			
						,ATTR_14			
						,ATTR_15			
						,ATTR_16			
						,ATTR_17			
						,ATTR_18			
						,ATTR_19
						,ATTR_20
						,ATTR_21
						,ATTR_22
						,ATTR_23
						,ATTR_24
						,ATTR_25
						,DISPLAY_COLOR
						,CREATE_BY
						,CREATE_DTTM
						,MIN_ORDER_SIZE
						,MAX_ORDER_SIZE
					) 
				VALUES (
						 REPLACE(NEWID(),'-','')
						,ITEM_CD           
						,ITEM_NM           
						,UOM_ID            
						,ITEM_TP_ID        
						,DESCRIP           
						,DP_PLAN_YN        
						,DP_PLAN_YN
						,PARENT_ITEM_LV_ID 
						,RTS               
						,EOS               
						,DEL_YN            
						,ATTR_01           
						,ATTR_02			
						,ATTR_03			
						,ATTR_04			
						,ATTR_05			
						,ATTR_06			
						,ATTR_07			
						,ATTR_08			
						,ATTR_09			
						,ATTR_10			
						,ATTR_11			
						,ATTR_12			
						,ATTR_13			
						,ATTR_14			
						,ATTR_15			
						,ATTR_16			
						,ATTR_17			
						,ATTR_18			
						,ATTR_19
						,ATTR_20
						,ATTR_21
						,ATTR_22
						,ATTR_23
						,ATTR_24
						,ATTR_25			
						,DISPLAY_COLOR
						,SRC.USER_ID 
						,GETDATE()   
						,SRC.MIN_ORDER_SIZE
						,SRC.MAX_ORDER_SIZE
 					);
			SET @P_RT_MSG = 'MSG_0001'
		END

	ELSE IF @P_WRK_TYPE = 'DELETE'
		BEGIN
			 UPDATE  TB_CM_ITEM_MST
			 SET     DEL_YN = 'Y'
				   , MODIFY_BY = @P_USER_ID
				   , MODIFY_DTTM = GETDATE()
			 WHERE ID = @P_ID;

			 SET @P_RT_MSG = 'MSG_0002'
		END

	SET @P_RT_ROLLBACK_FLAG = 'true'
END TRY

BEGIN CATCH
	IF (ERROR_MESSAGE() LIKE 'MSG_%')
		BEGIN
			SET @P_ERR_MSG = ERROR_MESSAGE()
			SET @P_RT_ROLLBACK_FLAG = 'false'
			SET @P_RT_MSG = @P_ERR_MSG
		END
	ELSE
		THROW;
END CATCH

go

