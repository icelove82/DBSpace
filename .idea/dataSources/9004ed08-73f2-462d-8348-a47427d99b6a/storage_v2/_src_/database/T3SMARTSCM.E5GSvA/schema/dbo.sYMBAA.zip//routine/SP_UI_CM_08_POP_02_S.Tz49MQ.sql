CREATE PROCEDURE [dbo].[SP_UI_CM_08_POP_02_S] (
     @P_WRK_TYPE				AS NVARCHAR(100) = ''
	,@P_ID						AS CHAR(32) = ''
	,@P_SHPP_LEADTIME_DTL_ID	AS NVARCHAR(100) = ''
	,@P_STRT_DATE				AS DATETIME = ''
	,@P_END_DATE				AS DATETIME = ''
	,@P_MON_YN					AS CHAR(32) = 'N'
	,@P_TUE_YN					AS CHAR(32) = 'N'
	,@P_WED_YN					AS CHAR(32) = 'N'
	,@P_THU_YN					AS CHAR(32) = 'N'
	,@P_FRI_YN					AS CHAR(32) = 'N'
	,@P_SAT_YN					AS CHAR(32) = 'N'
	,@P_SUN_YN					AS CHAR(32) = 'N'
    ,@P_ACTV_YN              	AS CHAR(32) = ''
	,@P_USER_ID					AS NVARCHAR(100) = ''
    ,@P_RT_ROLLBACK_FLAG     	NVARCHAR(10)   = 'true'  OUTPUT
	,@P_RT_MSG               	NVARCHAR(4000) = ''		 OUTPUT
)
AS SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000) = ''

BEGIN TRY

    IF @P_WRK_TYPE = 'SAVE'
     	BEGIN
	        MERGE INTO TB_CM_SHIP_LT_EXCEPTION_SCH B 
	        USING (SELECT @P_ID AS ID
	               ) A
	           ON (B.ID = A.ID)
	        WHEN MATCHED THEN
	            UPDATE 
	               SET STRT_DATE    = @P_STRT_DATE
					 , END_DATE     = @P_END_DATE
					 , MON_YN	    = @P_MON_YN
	                 , TUE_YN		= @P_TUE_YN
	                 , WED_YN		= @P_WED_YN
	                 , THU_YN		= @P_THU_YN
	                 , FRI_YN		= @P_FRI_YN
	                 , SAT_YN		= @P_SAT_YN
	                 , SUN_YN		= @P_SUN_YN
	                 , ACTV_YN      = @P_ACTV_YN
	                 , MODIFY_BY	= @P_USER_ID
	                 , MODIFY_DTTM	= GETDATE()
	        WHEN NOT MATCHED THEN
	            INSERT (
	                ID
	                ,SHPP_LEADTIME_DTL_ID
	                ,STRT_DATE
	                ,END_DATE
	                ,MON_YN
	                ,TUE_YN
	                ,WED_YN
	                ,THU_YN
	                ,FRI_YN
	                ,SAT_YN
	                ,SUN_YN
	                ,ACTV_YN
	                ,CREATE_BY
	                ,CREATE_DTTM
	                )
	            VALUES 
	                (
	                REPLACE(NEWID(),'-','')
	                ,@P_SHPP_LEADTIME_DTL_ID
	                ,@P_STRT_DATE	
	                ,@P_END_DATE	
	                ,@P_MON_YN
	                ,@P_TUE_YN
	                ,@P_WED_YN
	                ,@P_THU_YN
	                ,@P_FRI_YN
	                ,@P_SAT_YN
	                ,@P_SUN_YN
	                ,@P_ACTV_YN
	                ,@P_USER_ID
	                ,GETDATE()
	            );
	            
		    SET @P_RT_ROLLBACK_FLAG = 'true'
		    SET @P_RT_MSG = 'MSG_0001'
	     	
	    END

    ELSE IF @P_WRK_TYPE = 'DELETE'
    	BEGIN
	    	
	        DELETE 
	          FROM TB_CM_SHIP_LT_EXCEPTION_SCH
	         WHERE ID = @P_ID
	
	        SET @P_RT_ROLLBACK_FLAG = 'true'
			SET @P_RT_MSG = 'MSG_0002'
	    	
	    END

END TRY

BEGIN CATCH

	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
	       BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
		       SET @P_RT_MSG = @P_ERR_MSG
		   END
	   ELSE
	       THROW

END CATCH

go

