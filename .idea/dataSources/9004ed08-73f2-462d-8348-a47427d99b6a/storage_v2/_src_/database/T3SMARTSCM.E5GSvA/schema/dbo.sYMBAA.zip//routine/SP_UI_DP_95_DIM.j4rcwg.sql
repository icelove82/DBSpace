-- =============================================
-- AUTHOR:		EUNHA

-- HISTORY (Date/  writer / comment)
-- 2021.09.28 / kim sohee /
-- 2021.11.08 / kim sohee / add custom type (double, integer 이면 sum, string, boolean, date면 max로 처리하고자) 
-- 2022.01.04 / Kim sohee / convert grid ID parameter (remain only grid ID, not Menu ID)
-- 2023.01.31 / kim sohee / IDX null value bug fix 
-- =============================================
CREATE PROCEDURE [dbo].[SP_UI_DP_95_DIM](
                 @USER_ID   NVARCHAR(50) = ''
                ,@AUTH_TP   NVARCHAR(50) = ''
                ,@UI_ID     NVARCHAR(30) = ''
				,@GRID_ID	NVARCHAR(100) = ''
)AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
BEGIN
	SET @GRID_ID = REPLACE(@GRID_ID, @UI_ID+'-', '');

WITH LV
  AS (
		SELECT M.ID
			 , C.CONF_CD AS LV_TP_CD
			 , M.LV_TP_ID AS LV_TP_ID
			 , LV_CD
			 , SALES_LV_YN
			 , ACCOUNT_LV_YN
			 , LEAF_YN
			 , ROW_NUMBER() OVER (PARTITION BY CONF_CD ORDER BY CONF_CD, SEQ) AS IDX 
		 FROM TB_CM_LEVEL_MGMT M
			  INNER JOIN 
			  TB_CM_COMM_CONFIG C 
		   ON C.ID = M.LV_TP_ID 
		WHERE ACCOUNT_LV_YN = 'Y'   
		  AND DEL_YN = 'N' 
		  AND M.ACTV_YN = 'Y'					
		UNION ALL					
		SELECT L.ID
			 , C.CONF_CD AS LV_TP_CD
			 , L.LV_TP_ID AS LV_TP_ID
			 , LV_CD
			 , SALES_LV_YN
			 , ACCOUNT_LV_YN
			 , LEAF_YN
			 , ROW_NUMBER() OVER (PARTITION BY CONF_CD ORDER BY  CONF_CD, SEQ ) AS IDX 					
		FROM TB_CM_LEVEL_MGMT L
		     INNER JOIN 
		     TB_CM_COMM_CONFIG C 
		   ON L.LV_TP_ID = C.ID
		WHERE L.DEL_YN = 'N'	AND L.ACTV_YN = 'Y'	AND ACCOUNT_LV_YN = 'N' AND SALES_LV_YN = 'N' 	AND L.ACTV_YN = 'Y'		
		  
  ), MAIN
AS (
	  SELECT A.FLD_CD
			,A.FLD_APPLY_CD
			,A.FLD_WIDTH
			,A.FLD_SEQ
			,COALESCE(UP.FLD_ACTIVE_YN,COALESCE(A.FLD_ACTIVE_YN,'N')) AS FLD_ACTV_YN 
			,A.APPLY_YN
			,A.REFER_VALUE
			,A.CROSSTAB_ITEM_CD
			,A.CATEGORY_GROUP
			,A.DIM_MEASURE_TP
			,A.SUMMARY_TP
			,A.SUMMARY_YN
			,A.EDIT_MEASURE_YN
			,A.EDIT_TARGET_YN
			,A.DATA_KEY_YN
			,A.CROSSTAB_YN
		   , B.GRP_ID
		   , B.COL_NM
		   , B.DISP_NM 
		   , A.USER_PREF_MST_ID 
		 , V.LV_TP_CD				
		 , (CASE WHEN (V.SALES_LV_YN = 'Y' OR V.ACCOUNT_LV_YN = 'Y')   THEN 'S' 					
		 		WHEN (V.SALES_LV_YN = 'N' OR V.ACCOUNT_LV_YN = 'N')   THEN 'I'   					
		 		ELSE 'C'	
		 	END ) AS TYPE		
		 , (CASE WHEN (V.SALES_LV_YN = 'Y' AND V.LEAF_YN = 'N') THEN 'SALES_LV' 					
		 	    WHEN (V.ACCOUNT_LV_YN = 'Y' AND V.LEAF_YN = 'Y') THEN 'ACCOUNT'  					
		 	    WHEN (V.SALES_LV_YN = 'N' AND V.LEAF_YN = 'N') THEN 'ITEM_LV'  					
		 	    WHEN (V.SALES_LV_YN = 'N' AND V.LEAF_YN = 'Y') THEN 'ITEM'					
		 		ELSE 'NONE'		
		 	END ) AS LEVEL		
		 , V.LV_CD AS LEVEL_CD		
		 , COALESCE(V.IDX,0) AS 	IDX			
		 , V.LEAF_YN 
		 , C.ATTR_01   AS CUSTOM_TYPE
	    FROM TB_AD_USER_PREF_DTL A 
			INNER JOIN 
			TB_AD_USER_PREF_MST M 
		 ON M.ID = A.USER_PREF_MST_ID 
		AND M.VIEW_CD = @UI_ID 
		AND M.GRID_CD = @GRID_ID 
			INNER JOIN 
			TB_AD_GROUP G 
		 ON G.ID = A.GRP_ID 
		AND GRP_CD = @AUTH_TP
			INNER JOIN 
			TB_DP_DIM_SETTING B 
		 ON A.REFER_VALUE = B.ID	
			LEFT OUTER JOIN 
			LV V 
		 ON V.ID = B.LV_MGMT_ID	
			LEFT OUTER JOIN 
			TB_AD_USER_PREF UP 
		 ON	A.USER_PREF_MST_ID = UP.USER_PREF_MST_ID 
		AND B.GRP_ID = UP.GRP_ID	
		AND	A.FLD_CD = UP.FLD_CD	
		AND UP.USER_ID = (SELECT ID FROM TB_AD_USER WHERE USERNAME =  @USER_ID)	
		    LEFT OUTER JOIN
			TB_CM_COMM_CONFIG C
		ON  B.LV_MGMT_ID = C.CONF_ID 
	   AND  B.COL_NM = C.CONF_CD
	WHERE A.DIM_MEASURE_TP = 'DIMENSION'  
)
	SELECT M.FLD_CD AS DISPLAY	
		 , M.TYPE
		 , M.LEVEL
		 , M.LEVEL_CD
		 , M.IDX
		 , M.LEAF_YN 
		 , CASE WHEN (RIGHT(M.COL_NM, 2) = 'CD' OR  RIGHT(M.COL_NM, 2) = 'NM') THEN M.DISP_NM  ELSE M.COL_NM END  AS FIELD					
		 , LV_TP_CD
		 , CUSTOM_TYPE
	FROM	MAIN  M
	WHERE FLD_ACTV_YN = 'Y'
	  OR ( EXISTS (SELECT 1 FROM MAIN WHERE TYPE = 'C' AND FLD_ACTV_YN = 'Y') AND LEAF_YN = 'Y' )
	 ORDER BY FLD_SEQ 
	-- CUSTOM DIMENSION인 케이스에 ACTV_YN 상관 없이 LEAF_YN = 'Y' 인 레벨도 나오게 처리. 
	
	;

END;

go

