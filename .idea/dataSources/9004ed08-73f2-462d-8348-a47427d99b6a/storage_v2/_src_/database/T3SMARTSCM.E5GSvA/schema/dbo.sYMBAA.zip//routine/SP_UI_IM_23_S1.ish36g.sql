CREATE PROCEDURE [dbo].[SP_UI_IM_23_S1] (
	 @P_CONBD_MAIN_VER_DTL_ID    NVARCHAR(32) = ''
    ,@P_SIMUL_VER_ID             NVARCHAR(100) = ''
    ,@P_LOCAT_CD                 NVARCHAR(100) = ''
    ,@P_CONFRM_YN                NVARCHAR(1) = ''
    ,@P_VAL_01                   NVARCHAR(100) = ''
    ,@P_VAL_02                   NVARCHAR(100) = ''
    ,@P_VAL_03                   NVARCHAR(100) = ''
    ,@P_VAL_04                   NVARCHAR(100) = ''
    ,@P_VAL_05                   NVARCHAR(100) = ''
    ,@P_VAL_06                   NVARCHAR(100) = ''
    ,@P_VAL_07                   NVARCHAR(100) = ''
    ,@P_VAL_08                   NVARCHAR(100) = ''
    ,@P_VAL_09                   NVARCHAR(100) = ''
    ,@P_VAL_10                   NVARCHAR(100) = ''
    ,@P_VAL_11                   NVARCHAR(100) = ''
    ,@P_USER_ID                  NVARCHAR(100) = ''
	,@P_RT_ROLLBACK_FLAG		 NVARCHAR(10) = 'true' OUTPUT
	,@P_RT_MSG					 NVARCHAR(4000) = ''   OUTPUT
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_MSG NVARCHAR(4000)=''

BEGIN TRY
		
	MERGE INTO TB_RT_INV_POLICY_ITEM TARGET
    USING (
        SELECT
             @P_CONBD_MAIN_VER_DTL_ID        AS CONBD_MAIN_VER_DTL_ID
            ,@P_SIMUL_VER_ID                 AS SIMUL_VER_ID
            ,@P_LOCAT_CD                     AS LOCAT_CD
            ,@P_CONFRM_YN                    AS CONFRM_YN
            ,@P_VAL_01                       AS VAL_01
            ,@P_VAL_02                       AS VAL_02
            ,@P_VAL_03                       AS VAL_03
            ,@P_VAL_04                       AS VAL_04
            ,@P_VAL_05                       AS VAL_05
            ,@P_VAL_06                       AS VAL_06
            ,@P_VAL_07                       AS VAL_07
            ,@P_VAL_08                       AS VAL_08
            ,@P_VAL_09                       AS VAL_09
            ,@P_VAL_10                       AS VAL_10
            ,@P_VAL_11                       AS VAL_11
            ,@P_USER_ID                      AS USER_ID
            ,C.ID                           AS LOCAT_ITEM_ID
        FROM
            TB_CM_LOC_DTL A
            INNER JOIN
            TB_CM_LOC_MGMT B
            ON (B.LOCAT_ID = A.ID)
            INNER JOIN
            TB_CM_SITE_ITEM C
            ON (B.ID = C.LOCAT_MGMT_ID)
            INNER JOIN
            TB_RT_SITE_ITEM_SEG_SUMM D
            ON (D.CONBD_MAIN_VER_DTL_ID = @P_CONBD_MAIN_VER_DTL_ID AND D.LOCAT_ITEM_ID = C.ID)
        WHERE
            A.LOCAT_CD = @P_LOCAT_CD
            AND ISNULL(D.VAL_01,-1) = ISNULL(@P_VAL_01,-1)
            AND ISNULL(D.VAL_02,-1) = ISNULL(@P_VAL_02,-1)
            AND ISNULL(D.VAL_03,-1) = ISNULL(@P_VAL_03,-1)
            AND ISNULL(D.VAL_04,-1) = ISNULL(@P_VAL_04,-1)
            AND ISNULL(D.VAL_05,-1) = ISNULL(@P_VAL_05,-1)
            AND ISNULL(D.VAL_06,-1) = ISNULL(@P_VAL_06,-1)
            AND ISNULL(D.VAL_07,-1) = ISNULL(@P_VAL_07,-1)
            AND ISNULL(D.VAL_08,-1) = ISNULL(@P_VAL_08,-1)
            AND ISNULL(D.VAL_09,-1) = ISNULL(@P_VAL_09,-1)
            AND ISNULL(D.VAL_10,-1) = ISNULL(@P_VAL_10,-1)
            AND ISNULL(D.VAL_11,-1) = ISNULL(@P_VAL_11,-1)
    ) SOURCE
    ON  (
            TARGET.CONBD_MAIN_VER_DTL_ID = SOURCE.CONBD_MAIN_VER_DTL_ID
            AND TARGET.LOCAT_ITEM_ID = SOURCE.LOCAT_ITEM_ID
        )
    WHEN MATCHED THEN
        UPDATE
            SET
                    TARGET.FIXED_YN            = SOURCE.CONFRM_YN
                ,TARGET.MODIFY_BY           = SOURCE.USER_ID
                ,TARGET.MODIFY_DTTM         = GETDATE();

    MERGE INTO TB_IM_INV_POLICY_ITEM TARGET
        USING (
            SELECT
                 E.LOCAT_ITEM_ID                AS LOCAT_ITEM_ID
                ,E.INV_LV_QTY
                ,E.INTRANSIT_QTY
                ,E.SHPP_ACTUAL_PERIOD
                ,E.AVG_SHPP_ACTUAL_QTY
                ,E.INVTURN
                ,E.PRPSAL_INV_MGMT_SYSTEM_TP_ID
                ,E.INV_MGMT_SYSTEM_TP_ID
                ,E.PO_CYCL_CD_ID
                ,E.PO_CYCL_CALENDAR_ID
                ,E.OPERT_BASE_TP_ID
                ,E.INV_PLACE_STRTGY_ID
                ,E.SUPPLY_LEADTIME_PRPSAL_VAL
                ,E.SUPPLY_LEADTIME
                ,E.SUPPLY_LEADTIME_YN
                ,E.PO_CYCL_YN
                ,E.REPLSH_LEADTIME
                ,E.OPERT_LV_VAL
                ,E.OPERT_TARGET_VAL
                ,E.PRPSAL_SVC_LV
                ,E.SFST_SVC_LV
                ,E.SFST_DEMDVAR_CONSID_YN
                ,E.SFST_DEMDVAR_STDDEV
                ,E.SFST_SUPYVAR_CONSID_YN
                ,E.SFST_DMND_RATE_CAL_TP_ID
                ,E.SFST_DMND_RATE
                ,E.SUPYVAR_STDDEV
                ,E.SFST_PRPSAL_VAL
                ,E.SFST_VAL
                ,E.ROP_CAL_TP_ID
                ,E.ROP_SFST_CONSID_YN
                ,E.ROP_DMND_RATE_CAL_MTD_ID
                ,E.ROP_DMND_RATE
                ,E.ROP_RIGHT_RATE_TARGET
                ,E.ROP_OPERT_INV_CONSID_YN
                ,E.ROP_RIGHT_RATE_YN
                ,E.ROP_PRPSAL_VAL
                ,E.ROP_VAL
                ,E.EOQ_CAL_TP_ID
                ,E.EOQ_DMND_RATE_CAL_MTD_ID
                ,E.EOQ_DMND_RATE
                ,E.EOQ_RIGHT_RATE_TARGET
                ,E.EOQ_RIGHT_RATE_YN
                ,E.EOQ_PRPSAL_VAL
                ,E.EOQ_VAL
                ,E.OPERT_INV_DMND_RATE_CAL_MTD_ID
                ,E.OPERT_INV_DMND_RATE
                ,E.OPERT_INV_PRPSAL_VAL
                ,E.OPERT_INV_VAL
                ,E.TARGET_INV_SFST_CONSID_YN
                ,E.TARGET_INV_OPERT_INV_CONSID_YN
                ,E.TARGET_INV_PRPSAL_VAL
                ,E.TARGET_INV_VAL
                ,@P_USER_ID                      AS USER_ID
            FROM
                TB_CM_LOC_DTL A
                INNER JOIN
                TB_CM_LOC_MGMT B
                ON (B.LOCAT_ID = A.ID)
                INNER JOIN
                TB_CM_SITE_ITEM C
                ON (B.ID = C.LOCAT_MGMT_ID)
                INNER JOIN
                TB_RT_SITE_ITEM_SEG_SUMM D
                ON (D.CONBD_MAIN_VER_DTL_ID = @P_CONBD_MAIN_VER_DTL_ID AND D.LOCAT_ITEM_ID = C.ID)
                INNER JOIN
                TB_RT_INV_POLICY_ITEM E
                ON (E.CONBD_MAIN_VER_DTL_ID = @P_CONBD_MAIN_VER_DTL_ID AND E.LOCAT_ITEM_ID = D.LOCAT_ITEM_ID AND ISNULL(E.FIXED_YN,'N')='Y')
            WHERE
                A.LOCAT_CD = @P_LOCAT_CD
                AND ISNULL(D.VAL_01,-1) = ISNULL(@P_VAL_01,-1)
                AND ISNULL(D.VAL_02,-1) = ISNULL(@P_VAL_02,-1)
                AND ISNULL(D.VAL_03,-1) = ISNULL(@P_VAL_03,-1)
                AND ISNULL(D.VAL_04,-1) = ISNULL(@P_VAL_04,-1)
                AND ISNULL(D.VAL_05,-1) = ISNULL(@P_VAL_05,-1)
                AND ISNULL(D.VAL_06,-1) = ISNULL(@P_VAL_06,-1)
                AND ISNULL(D.VAL_07,-1) = ISNULL(@P_VAL_07,-1)
                AND ISNULL(D.VAL_08,-1) = ISNULL(@P_VAL_08,-1)
                AND ISNULL(D.VAL_09,-1) = ISNULL(@P_VAL_09,-1)
                AND ISNULL(D.VAL_10,-1) = ISNULL(@P_VAL_10,-1)
                AND ISNULL(D.VAL_11,-1) = ISNULL(@P_VAL_11,-1)
        ) SOURCE
        ON  (
                TARGET.LOCAT_ITEM_ID = SOURCE.LOCAT_ITEM_ID
            )
        WHEN MATCHED THEN
            UPDATE
                SET
                     TARGET.INV_LV_QTY                      = SOURCE.INV_LV_QTY
                    ,TARGET.INTRANSIT_QTY                   = SOURCE.INTRANSIT_QTY
                    ,TARGET.SHPP_ACTUAL_PERIOD              = SOURCE.SHPP_ACTUAL_PERIOD
                    ,TARGET.AVG_SHPP_ACTUAL_QTY             = SOURCE.AVG_SHPP_ACTUAL_QTY
                    ,TARGET.INVTURN                         = SOURCE.INVTURN
                    ,TARGET.PRPSAL_INV_MGMT_SYSTEM_TP_ID    = SOURCE.PRPSAL_INV_MGMT_SYSTEM_TP_ID
                    ,TARGET.INV_MGMT_SYSTEM_TP_ID           = SOURCE.INV_MGMT_SYSTEM_TP_ID
                    ,TARGET.PO_CYCL_CD_ID                   = SOURCE.PO_CYCL_CD_ID
                    ,TARGET.PO_CYCL_CALENDAR_ID             = SOURCE.PO_CYCL_CALENDAR_ID
                    ,TARGET.OPERT_BASE_TP_ID                = SOURCE.OPERT_BASE_TP_ID
                    ,TARGET.INV_PLACE_STRTGY_ID             = SOURCE.INV_PLACE_STRTGY_ID
                    ,TARGET.SUPPLY_LEADTIME_PRPSAL_VAL      = SOURCE.SUPPLY_LEADTIME_PRPSAL_VAL
                    ,TARGET.SUPPLY_LEADTIME                 = SOURCE.SUPPLY_LEADTIME
                    ,TARGET.SUPPLY_LEADTIME_YN              = SOURCE.SUPPLY_LEADTIME_YN
                    ,TARGET.PO_CYCL_YN                      = SOURCE.PO_CYCL_YN
                    ,TARGET.REPLSH_LEADTIME                 = SOURCE.REPLSH_LEADTIME
                    ,TARGET.OPERT_LV_VAL                    = SOURCE.OPERT_LV_VAL
                    ,TARGET.OPERT_TARGET_VAL                = SOURCE.OPERT_TARGET_VAL
                    ,TARGET.PRPSAL_SVC_LV                   = SOURCE.PRPSAL_SVC_LV
                    ,TARGET.SFST_SVC_LV                     = SOURCE.SFST_SVC_LV
                    ,TARGET.SFST_DEMDVAR_CONSID_YN          = SOURCE.SFST_DEMDVAR_CONSID_YN
                    ,TARGET.SFST_DEMDVAR_STDDEV             = SOURCE.SFST_DEMDVAR_STDDEV
                    ,TARGET.SFST_SUPYVAR_CONSID_YN          = SOURCE.SFST_SUPYVAR_CONSID_YN
                    ,TARGET.SFST_DMND_RATE_CAL_TP_ID        = SOURCE.SFST_DMND_RATE_CAL_TP_ID
                    ,TARGET.SFST_DMND_RATE                  = SOURCE.SFST_DMND_RATE
                    ,TARGET.SUPYVAR_STDDEV                  = SOURCE.SUPYVAR_STDDEV
                    ,TARGET.SFST_PRPSAL_VAL                 = SOURCE.SFST_PRPSAL_VAL
                    ,TARGET.SFST_VAL                        = SOURCE.SFST_VAL
                    ,TARGET.ROP_CAL_TP_ID                   = SOURCE.ROP_CAL_TP_ID
                    ,TARGET.ROP_SFST_CONSID_YN              = SOURCE.ROP_SFST_CONSID_YN
                    ,TARGET.ROP_DMND_RATE_CAL_MTD_ID        = SOURCE.ROP_DMND_RATE_CAL_MTD_ID
                    ,TARGET.ROP_DMND_RATE                   = SOURCE.ROP_DMND_RATE
                    ,TARGET.ROP_RIGHT_RATE_TARGET           = SOURCE.ROP_RIGHT_RATE_TARGET
                    ,TARGET.ROP_OPERT_INV_CONSID_YN         = SOURCE.ROP_OPERT_INV_CONSID_YN
                    ,TARGET.ROP_RIGHT_RATE_YN               = SOURCE.ROP_RIGHT_RATE_YN
                    ,TARGET.ROP_PRPSAL_VAL                  = SOURCE.ROP_PRPSAL_VAL
                    ,TARGET.ROP_VAL                         = SOURCE.ROP_VAL
                    ,TARGET.EOQ_CAL_TP_ID                   = SOURCE.EOQ_CAL_TP_ID
                    ,TARGET.EOQ_DMND_RATE_CAL_MTD_ID        = SOURCE.EOQ_DMND_RATE_CAL_MTD_ID
                    ,TARGET.EOQ_DMND_RATE                   = SOURCE.EOQ_DMND_RATE
                    ,TARGET.EOQ_RIGHT_RATE_TARGET           = SOURCE.EOQ_RIGHT_RATE_TARGET
                    ,TARGET.EOQ_RIGHT_RATE_YN               = SOURCE.EOQ_RIGHT_RATE_YN
                    ,TARGET.EOQ_PRPSAL_VAL                  = SOURCE.EOQ_PRPSAL_VAL
                    ,TARGET.EOQ_VAL                         = SOURCE.EOQ_VAL
                    ,TARGET.OPERT_INV_DMND_RATE_CAL_MTD_ID  = SOURCE.OPERT_INV_DMND_RATE_CAL_MTD_ID
                    ,TARGET.OPERT_INV_DMND_RATE             = SOURCE.OPERT_INV_DMND_RATE
                    ,TARGET.OPERT_INV_PRPSAL_VAL            = SOURCE.OPERT_INV_PRPSAL_VAL
                    ,TARGET.OPERT_INV_VAL                   = SOURCE.OPERT_INV_VAL
                    ,TARGET.TARGET_INV_SFST_CONSID_YN       = SOURCE.TARGET_INV_SFST_CONSID_YN
                    ,TARGET.TARGET_INV_OPERT_INV_CONSID_YN  = SOURCE.TARGET_INV_OPERT_INV_CONSID_YN
                    ,TARGET.TARGET_INV_PRPSAL_VAL           = SOURCE.TARGET_INV_PRPSAL_VAL
                    ,TARGET.TARGET_INV_VAL                  = SOURCE.TARGET_INV_VAL
                    ,TARGET.MODIFY_BY                       = SOURCE.USER_ID
                    ,TARGET.MODIFY_DTTM                     = GETDATE();

	SET @P_RT_ROLLBACK_FLAG = 'true'
	SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY

BEGIN CATCH
	IF(ERROR_MESSAGE() LIKE 'MSG_%')
		BEGIN
			SET @P_ERR_MSG = ERROR_MESSAGE()
			SET @P_RT_ROLLBACK_FLAG = 'false'
			SET @P_RT_MSG = @P_ERR_MSG
		END
	ELSE
		THROW
END CATCH

go

