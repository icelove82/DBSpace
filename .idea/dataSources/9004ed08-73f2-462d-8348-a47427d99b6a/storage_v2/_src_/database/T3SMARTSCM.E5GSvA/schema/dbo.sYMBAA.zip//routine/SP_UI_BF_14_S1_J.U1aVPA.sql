
CREATE PROCEDURE [dbo].[SP_UI_BF_14_S1_J]  (
									  @P_JSON				NVARCHAR(MAX)
									, @P_USER_ID			NVARCHAR(50)
									, @P_RT_ROLLBACK_FLAG   NVARCHAR(10)   = 'true'  OUTPUT
									, @P_RT_MSG             NVARCHAR(4000) = ''		OUTPUT
				                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''

BEGIN TRY
	BEGIN		
		MERGE TB_BF_NEW_ITEM_ACCOUNT_MAP TAR
				USING ( 
						SELECT  ID			
							  , FROM_ACCOUNT_CD
							  , TO_ACCOUNT_CD	
							  , FROM_ITEM_CD	
							  , TO_ITEM_CD		
							  , CASE WHEN USE_YN = 'true' then 'Y' ELSE 'N' END AS USE_YN			
							  , FROM_DATE
							  , TO_DATE
							  , APPLY_PCT
							  , @P_USER_ID	AS USER_ID
						FROM OpenJson(@P_JSON)
						WITH
							(
					  	    ID					CHAR(32)		'$.ID'
						  , FROM_ACCOUNT_CD		NVARCHAR(100)	'$.FROM_ACCOUNT_CD'
						  , TO_ACCOUNT_CD		NVARCHAR(100)	'$.TO_ACCOUNT_CD'
						  , FROM_ITEM_CD		NVARCHAR(100)	'$.FROM_ITEM_CD'
						  , TO_ITEM_CD			NVARCHAR(100)	'$.TO_ITEM_CD'
						  , USE_YN				NVARCHAR(10)	'$.USE_YN'
						  , FROM_DATE			DATE			'$.FROM_APPLY_DATE'
						  , TO_DATE				DATE			'$.TO_APPLY_DATE'
						  , APPLY_PCT			DECIMAL(23,3)	'$.APPLY_PCT'
							)
					  ) SRC
				ON	  (TAR.ID = SRC.ID)
				WHEN MATCHED THEN
					 UPDATE 
					   SET    TAR.FROM_ACCOUNT_CD = SRC.FROM_ACCOUNT_CD	
							, TAR.TO_ACCOUNT_CD	  = SRC.TO_ACCOUNT_CD	
							, TAR.FROM_ITEM_CD	  = SRC.FROM_ITEM_CD		
							, TAR.TO_ITEM_CD	  = SRC.TO_ITEM_CD		
							, TAR.USE_YN		  = SRC.USE_YN			
							, TAR.FROM_APPLY_DATE = SRC.FROM_DATE
							, TAR.TO_APPLY_DATE	  = SRC.TO_DATE
							, TAR.APPLY_PCT		  = SRC.APPLY_PCT
							, TAR.MODIFY_BY		  = SRC.USER_ID			
							, TAR.MODIFY_DTTM	  = GETDATE()
				WHEN NOT MATCHED THEN 
					 INSERT (
							  ID				
							, FROM_ACCOUNT_CD	
							, TO_ACCOUNT_CD	
							, FROM_ITEM_CD		
							, TO_ITEM_CD		
							, USE_YN
							, FROM_APPLY_DATE
							, TO_APPLY_DATE
							, APPLY_PCT
							, CREATE_BY
							, CREATE_DTTM
							) 
					 VALUES (
							 (SELECT REPLACE(NEWID(),'-','') )
							,SRC.FROM_ACCOUNT_CD	
							,SRC.TO_ACCOUNT_CD	
							,SRC.FROM_ITEM_CD		
							,SRC.TO_ITEM_CD		
							,SRC.USE_YN
							,SRC.FROM_DATE
							,SRC.TO_DATE
							,SRC.APPLY_PCT
							,SRC.USER_ID
							,GETDATE()
 							) 
							;   
	  END

	   SET @P_RT_ROLLBACK_FLAG = 'true'

	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;

go

