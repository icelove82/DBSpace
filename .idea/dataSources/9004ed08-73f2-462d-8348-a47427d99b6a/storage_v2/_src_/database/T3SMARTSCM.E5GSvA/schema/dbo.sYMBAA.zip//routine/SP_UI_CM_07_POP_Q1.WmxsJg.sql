CREATE PROCEDURE [dbo].[SP_UI_CM_07_POP_Q1] (
	 @P_JOB_TYPE					NVARCHAR(50) = '',
	 @P_BOD_TP_ID					CHAR(32) = '',
	 @P_CONSUME_LOC_MGMT_ID			CHAR(32) = '',
	 @P_ACCOUNT_ID					CHAR(32) = '',
	 @P_SUPPLY_LOC_MGMT_ID			CHAR(32) = ''
) 
AS SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @vBOD_TP	NVARCHAR(100)

    SELECT @vBOD_TP = COMN_CD
      FROM TB_AD_COMN_CODE 
     WHERE ID = @P_BOD_TP_ID

BEGIN

	IF @P_JOB_TYPE = 'N'
		BEGIN
			IF @vBOD_TP IS NOT NULL AND @vBOD_TP = 'SALES_BOD'
				BEGIN
					SELECT DISTINCT		   
						   NULL						    AS SHPP_LEADTIME_MST_ID
						 , @P_BOD_TP_ID                 AS BOD_TP_ID
						 , NULL                         AS CONSUME_LOCAT_MGMT_ID
						 , ACC.ID                       AS ACCOUNT_ID
						 , LMG.ID                       AS SUPPLY_LOCAT_MGMT_ID
						 , 'Y'					        AS ACTV_YN
						 , VHC.ID						AS VEHICL_TP_ID
						 , VHC.VEHICL_TP				AS VEHICL_TP
						 , NULL					        AS PRIORT
						 , NULL					        AS TRANSP_COST_CAL_BASE_ID
						 , NULL					        AS WEIGHT_UOM_ID
						 , NULL					        AS TRANSP_UTPIC
						 , NULL					        AS CURCY_CD_ID
					   FROM TB_CM_LOC_MGMT LMG,
							TB_CM_LOC_DTL LDT,
							TB_CM_LOC_MST LMS,
							TB_DP_ACCOUNT_MST ACC,
							(
							SELECT	A.ID
							FROM	TB_CM_LOC_MST A
									INNER JOIN TB_AD_COMN_CODE B
									ON B.ID = A.LOCAT_TP_ID
							WHERE	B.COMN_CD = 'LOC_ACCOUNT'
							) CUS,
							TB_CM_BOD_LT BLT,
							TB_CM_VEHICLE VHC
					  WHERE 1=1
						AND LDT.ID = LMG.LOCAT_ID
						AND LMS.ID = LDT.LOCAT_MST_ID
						AND CUS.ID = BLT.TO_LOCAT_MST_ID
						AND LMS.ID = BLT.FROM_LOCAT_MST_ID
						AND VHC.ID = BLT.VEHICL_TP_ID
						AND ACC.ID = @P_ACCOUNT_ID
						AND LMG.ID = @P_SUPPLY_LOC_MGMT_ID
				END
			ELSE
				BEGIN
					SELECT DISTINCT		   
						   NULL						    AS SHPP_LEADTIME_MST_ID
						 , @P_BOD_TP_ID                 AS BOD_TP_ID
						 , LMG.ID                       AS CONSUME_LOCAT_MGMT_ID
						 , NULL                         AS ACCOUNT_ID
						 , LMG2.ID                      AS SUPPLY_LOCAT_MGMT_ID
						 , 'Y'					        AS ACTV_YN
						 , VHC.ID						AS VEHICL_TP_ID
						 , VHC.VEHICL_TP				AS VEHICL_TP
						 , NULL					        AS PRIORT
						 , NULL					        AS TRANSP_COST_CAL_BASE_ID
						 , NULL					        AS WEIGHT_UOM_ID
						 , NULL					        AS TRANSP_UTPIC
						 , NULL					        AS CURCY_CD_ID
					  FROM TB_CM_BOD_LT BLT  ,
						   TB_CM_LOC_MST LMS  ,
						   TB_CM_LOC_DTL LDT  ,
						   TB_CM_LOC_MGMT LMG  ,
						   TB_CM_LOC_MST LMS2  ,
						   TB_CM_LOC_DTL LDT2  ,
						   TB_CM_LOC_MGMT LMG2  ,
						   TB_CM_VEHICLE VHC  
					 WHERE LMS.ID = BLT.TO_LOCAT_MST_ID
					   AND LMS.ID = LDT.LOCAT_MST_ID
					   AND LDT.ID = LMG.LOCAT_ID
					   AND LMS2.ID = BLT.FROM_LOCAT_MST_ID
					   AND LMS2.ID = LDT2.LOCAT_MST_ID
					   AND LDT2.ID = LMG2.LOCAT_ID
					   AND VHC.ID = BLT.VEHICL_TP_ID
					   AND LMG.ID = @P_CONSUME_LOC_MGMT_ID
					   AND LMG2.ID = @P_SUPPLY_LOC_MGMT_ID
					 ORDER BY VHC.VEHICL_TP
				END
		END

	IF @P_JOB_TYPE = 'U'
		BEGIN
			SELECT 
				   SLM.ID						AS SHPP_LEADTIME_MST_ID
                 , SLM.BOD_TP_ID                AS BOD_TP_ID
                 , SLM.CONSUME_LOCAT_ID         AS CONSUME_LOCAT_MGMT_ID
                 , SLM.ACCOUNT_ID               AS ACCOUNT_ID
                 , SLM.SUPPLY_LOCAT_ID          AS SUPPLY_LOCAT_MGMT_ID
				 , SLM.ACTV_YN					AS ACTV_YN
				 , VHC.ID						AS VEHICL_TP_ID
				 , VHC.VEHICL_TP				AS VEHICL_TP
				 , SLM.PRIORT					AS PRIORT
                 , SLM.TRANSP_COST_CAL_BASE_ID  AS TRANSP_COST_CAL_BASE_ID
                 , SLM.WEIGHT_UOM_ID            AS WEIGHT_UOM_ID
                 , SLM.TRANSP_UTPIC             AS TRANSP_UTPIC
                 , SLM.CURCY_CD_ID              AS CURCY_CD_ID
			 FROM  TB_CM_SHIP_LT_MST SLM  ,
                   TB_CM_VEHICLE VHC  
			 WHERE 1=1
               AND VHC.ID = SLM.VEHICL_TP_ID
			   AND (SLM.CONSUME_LOCAT_ID = @P_CONSUME_LOC_MGMT_ID
                 OR SLM.ACCOUNT_ID = @P_ACCOUNT_ID)
			   AND SLM.SUPPLY_LOCAT_ID = @P_SUPPLY_LOC_MGMT_ID
		     ORDER BY VHC.VEHICL_TP;
		END
		   
END

go

