CREATE PROCEDURE [dbo].[SP_UI_BF_00_POPUP_ACCT_Q1] (
	  @P_LV_MGMT_ID CHAR(32)
	, @P_ACCT_CD NVARCHAR(100)
	, @P_ACCT_NM NVARCHAR(240)
	, @P_ITEM_CD NVARCHAR(100)
) AS 
BEGIN	
/******************************************************************************************
	Account & Account level

	history ( date / writer / comment)
	- 2020.09.01 / ksh / draft 
******************************************************************************************/
IF EXISTS (
	SELECT 1
	  FROM TB_CM_LEVEL_MGMT
	 WHERE (ID = @P_LV_MGMT_ID AND LEAF_YN = 'Y')
	 	OR @P_LV_MGMT_ID = ''
)
	BEGIN
		SELECT DISTINCT 
			   AM.ID
			 , AM.ACCOUNT_CD  
			 , AM.ACCOUNT_NM 
		  FROM TB_DP_ACCOUNT_MST AM
--		    INNER JOIN TB_BF_ITEM_ACCOUNT_MODEL_MAP IAM
--			  		ON IAM.ACCOUNT_CD = AM.ACCOUNT_CD
--			  	   AND IAM.ACTV_YN = 'Y'
--				   AND 'Y' = CASE WHEN @P_ITEM_CD = '' THEN 'Y'
--				   				  ELSE (CASE WHEN @P_ITEM_CD = IAM.ITEM_CD THEN 'Y' ELSE 'N' END)
--								   END
		 WHERE AM.DEL_YN = 'N'
		   AND AM.ACTV_YN = 'Y'	
		   AND AM.PARENT_SALES_LV_ID IS NOT NULL
		   AND ('Y' = CASE WHEN @P_ACCT_CD = '' THEN 'Y'
						   ELSE ( case when UPPER(AM.ACCOUNT_CD)  LIKE '%' + UPPER(RTRIM(ISNULL(@P_ACCT_CD,''))) + '%'	then 'Y' else 'N' end) 
						   END)
 		   AND ('Y' = CASE WHEN @P_ACCT_NM = '' THEN 'Y'
						   ELSE ( case when UPPER(AM.ACCOUNT_NM)  LIKE '%' + UPPER(RTRIM(ISNULL(@P_ACCT_NM,''))) + '%'	then 'Y' else 'N' end) 
						   END)
	END
ELSE 
	BEGIN
		SELECT ID 
			  ,SALES_LV_CD	AS ACCOUNT_CD  
			  ,SALES_LV_NM 	AS ACCOUNT_NM
		  FROM TB_DP_SALES_LEVEL_MGMT IL
		 WHERE LV_MGMT_ID = @P_LV_MGMT_ID 
		   AND ACTV_YN = 'Y'
		   AND DEL_YN = 'N'
		   AND ('Y' = CASE WHEN @P_ACCT_CD = '' THEN 'Y'
						   ELSE ( case when UPPER(SALES_LV_CD)  LIKE '%' + UPPER(RTRIM(ISNULL(@P_ACCT_CD,''))) + '%'	then 'Y' else 'N' end) 
						   END)
 		   AND ('Y' = CASE WHEN @P_ACCT_NM = '' THEN 'Y'
						   ELSE ( case when UPPER(SALES_LV_NM)  LIKE '%' + UPPER(RTRIM(ISNULL(@P_ACCT_NM,''))) + '%'	then 'Y' else 'N' end) 
						   END)
	END
END

go

