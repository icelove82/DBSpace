/*****************************************************************************
Title : SP_UI_CM_08_POP_01_S
최초 작성자 : 김광수
최초 생성일 : 2017.06.27
 
설명 
 - Shipping Schedule - add Exception (Monthly)
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.26 / 김광수 / 최초 작성
 
*****************************************************************************/
CREATE PROCEDURE [dbo].[SP_UI_CM_08_POP_01_S] (
	 @P_SHPP_LEADTIME_DTL_ID	AS NVARCHAR(100) = ''
	,@P_SHPP_SCHDL_TP_CD	    AS NVARCHAR(100) = ''
	,@P_MON_YN					AS CHAR(32) = 'N' 
	,@P_TUE_YN					AS CHAR(32) = 'N'
	,@P_WED_YN					AS CHAR(32) = 'N'
	,@P_THU_YN					AS CHAR(32) = 'N'
	,@P_FRI_YN					AS CHAR(32) = 'N'
	,@P_SAT_YN					AS CHAR(32) = 'N'
	,@P_SUN_YN					AS CHAR(32) = 'N'
	,@P_DD						AS INT = 0
	,@P_ACTV_YN					AS CHAR(1) = ''
	,@P_USER_ID					AS NVARCHAR(100) = ''
    ,@P_RT_ROLLBACK_FLAG     	NVARCHAR(10)   = 'true'  OUTPUT
	,@P_RT_MSG               	NVARCHAR(4000) = ''		 OUTPUT
)
AS SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_SHPP_SCHDL_TP_ID NVARCHAR(100) = ''
		,@P_ERR_STATUS INT = 0
		,@P_ERR_MSG NVARCHAR(4000) = ''

BEGIN TRY

    SELECT @P_SHPP_SCHDL_TP_ID = A.ID
      FROM TB_AD_COMN_CODE A,
           TB_AD_COMN_GRP B
    WHERE B.ID = A.SRC_ID
      AND B.GRP_CD = 'SHIPPING_SCHEDULE_TYPE'
      AND A.COMN_CD = @P_SHPP_SCHDL_TP_CD
        
	SET @P_ERR_MSG = 'MSG_0020'
	IF @P_SHPP_SCHDL_TP_ID IS NULL
		RAISERROR (@P_ERR_MSG, 12, 1)
        
    UPDATE TB_CM_SHIP_LT_DTL
       SET SHPP_SCHDL_TP_ID = @P_SHPP_SCHDL_TP_ID
         , MODIFY_BY		= @P_USER_ID
         , MODIFY_DTTM	    = GETDATE()
     WHERE ID = @P_SHPP_LEADTIME_DTL_ID

    IF @P_SHPP_SCHDL_TP_CD = 'DAILY'
    	BEGIN
	        MERGE INTO TB_CM_SHIP_LT_DAILY_SCH B 
	        USING (SELECT @P_SHPP_LEADTIME_DTL_ID AS ID) A
	           ON (B.SHPP_LEADTIME_DTL_ID = A.ID)
	        WHEN MATCHED THEN
	            UPDATE 
	               SET MON_YN		= @P_MON_YN
	                 , TUE_YN		= @P_TUE_YN
	                 , WED_YN		= @P_WED_YN
	                 , THU_YN		= @P_THU_YN
	                 , FRI_YN		= @P_FRI_YN
	                 , SAT_YN		= @P_SAT_YN
	                 , SUN_YN		= @P_SUN_YN
	                 , ACTV_YN      = @P_ACTV_YN
	                 , MODIFY_BY	= @P_USER_ID
	                 , MODIFY_DTTM	= GETDATE()
	        WHEN NOT MATCHED THEN
	            INSERT (
	                    ID
	                    ,SHPP_LEADTIME_DTL_ID
	                    ,MON_YN
	                    ,TUE_YN
	                    ,WED_YN
	                    ,THU_YN
	                    ,FRI_YN
	                    ,SAT_YN
	                    ,SUN_YN
	                    ,ACTV_YN
	                    ,CREATE_BY
	                    ,CREATE_DTTM
	                    ,MODIFY_BY
	                    ,MODIFY_DTTM
	                    )
	                VALUES 
	                    (
	                    REPLACE(NEWID(),'-','')
	                    ,@P_SHPP_LEADTIME_DTL_ID
	                    ,@P_MON_YN
	                    ,@P_TUE_YN
	                    ,@P_WED_YN
	                    ,@P_THU_YN
	                    ,@P_FRI_YN
	                    ,@P_SAT_YN
	                    ,@P_SUN_YN
	                    ,@P_ACTV_YN
	                    ,@P_USER_ID
	                    ,GETDATE()
	                    ,@P_USER_ID
	                    ,GETDATE()
	                    );
	    	
	    END
    
    ELSE 
        
        IF @P_ACTV_YN = 'Y'
        	BEGIN
	            MERGE INTO TB_CM_SHIP_LT_MONTHLY_SCH B 
	            USING (
	                   SELECT @P_SHPP_LEADTIME_DTL_ID AS ID,
	                          @P_DD AS DD
	                  ) A
	               ON (B.SHPP_LEADTIME_DTL_ID = A.ID
	               AND B.DD = A.DD)
	            WHEN MATCHED THEN
	                UPDATE 
	                   SET ACTV_YN	   = @P_ACTV_YN
	                     , MODIFY_BY   = @P_USER_ID
	                     , MODIFY_DTTM = GETDATE()
	            WHEN NOT MATCHED THEN
	                INSERT (
	                        ID
	                        ,SHPP_LEADTIME_DTL_ID
	                        ,DD
	                        ,ACTV_YN
	                        ,CREATE_BY
	                        ,CREATE_DTTM
	                        ,MODIFY_BY
	                        ,MODIFY_DTTM
	                        )
	                    VALUES 
	                        (
	                        REPLACE(NEWID(),'-','')
	                        ,@P_SHPP_LEADTIME_DTL_ID
	                        ,@P_DD
	                        ,@P_ACTV_YN
	                        ,@P_USER_ID
	                        ,GETDATE()
	                        ,@P_USER_ID
	                        ,GETDATE()
	                        );	        	
	        	
	       	END 

        ELSE
        	BEGIN

	        	DELETE TB_CM_SHIP_LT_MONTHLY_SCH
	             WHERE SHPP_LEADTIME_DTL_ID = @P_SHPP_LEADTIME_DTL_ID
	               AND DD = @P_DD
        	
	        END

    SET @P_RT_ROLLBACK_FLAG = 'true'
	SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY

BEGIN CATCH

	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
	       BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
		       SET @P_RT_MSG = @P_ERR_MSG
		   END
	   ELSE
	       THROW

END CATCH

go

