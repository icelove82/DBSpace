CREATE PROCEDURE [dbo].[SP_UI_IM_08_Q2] (
	@P_SABC_ID		NVARCHAR (32) 
)
AS
/*****************************************************************************
 * System Name : T3Enterprise IM
 * Business Name : SABC Analysis
 * Program Name(ID) :SP_UI_IM_08_Q2
 * Program Description : Search operation for SABC Analysis sub grid
 *
 * Create Date : HYS
 * Author : 2017/07/24
 *
 * Modifier    Modified Date    Revision History
 * --------    -------------    ----------------------------------------------
 * Roh S.K.    2019.03.12       Formatting & Comments
 * Roh S.K.    2020.01.20       Year-on-year Shipment (Quantity, Sales)
 *                              Shipment of previous month (quantity, sales)
 *                              Demand plan (quantity, sales)
 *****************************************************************************/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

SELECT  
	 A.COMN_CD_NM	AS LOCAT_TP_NM
    ,B.LOCAT_LV
	,C.LOCAT_CD
	,C.LOCAT_NM
	,G.ITEM_CD
	,G.ITEM_NM
	,G.DESCRIP		AS DESCRIP
	,H.CONVN_NM		AS ITEM_TP 
	,I.UOM_NM
	,P.COMN_CD_NM	AS CURCY_NM
	,N.COMN_CD_NM   AS SHIPTO_LOCAT_TP_NM 
	,M.LOCAT_LV     AS SHIPTO_LOCAT_LV 
	,L.LOCAT_CD		AS SHIPTO_LOCAT_CD 
	,L.LOCAT_NM		AS SHIPTO_LOCAT_NM 
	,O.ACCOUNT_CD
	,O.ACCOUNT_NM
	,K.LASTYEAR_SHPP_ACTUAL_QTY
    ,K.LASTYEAR_SHPP_ACTUAL_REVENUE
    ,K.LASTMOTH_SHPP_ACTUAL_QTY
    ,K.LASTMOTH_SHPP_ACTUAL_REVENUE
    ,K.SALES_PLAN_QTY
    ,K.SALES_PLAN_REVENUE
    ,K.QTY			AS SUM_QTY
    ,K.REVENUE		AS SUM_REVENUE
    ,K.QTY_COMPSITN_RATE
    ,K.CUMUL_QTY_COMPSITN_RATE
    ,K.CUMUL_QTY
    ,K.REVENUE_COMPSITN_RATE
    ,K.CUMUL_REVENUE_COMPSITN_RATE
    ,K.CUMUL_REVENUE
    ,K.SABC_VAL
    ,K.PRPSAL_SVC_LV
FROM 
	TB_AD_COMN_CODE A
	INNER JOIN TB_CM_LOC_MST B ON (A.ID = B.LOCAT_TP_ID)
	INNER JOIN TB_CM_LOC_DTL C ON (B.ID = C.LOCAT_MST_ID)
	INNER JOIN TB_CM_LOC_MGMT D ON (C.ID = D.LOCAT_ID)
	INNER JOIN TB_CM_SITE_ITEM F ON (D.ID = F.LOCAT_MGMT_ID)
	INNER JOIN TB_CM_ITEM_MST G ON (F.ITEM_MST_ID = G.ID)
	INNER JOIN TB_CM_ITEM_TYPE H ON (G.ITEM_TP_ID = H.ID)
	INNER JOIN TB_CM_UOM I ON (G.UOM_ID = I.ID)
	INNER JOIN TB_IM_SABC_ANALYSIS_MST J ON (F.ID = J.LOCAT_ITEM_ID)
	LEFT OUTER JOIN TB_IM_SABC_ANALYSIS_DTL K ON (J.ID = K.SABC_ANLYS_MST_ID)
	LEFT OUTER JOIN TB_CM_LOC_DTL L ON (K.LOCAT_ID = L.ID)
	LEFT OUTER JOIN TB_CM_LOC_MST M ON (L.LOCAT_MST_ID = M.ID)
	LEFT OUTER JOIN TB_AD_COMN_CODE N ON (M.LOCAT_TP_ID = N.ID)
	LEFT OUTER JOIN TB_DP_ACCOUNT_MST O ON (K.ACCOUNT_ID = O.ID)
	LEFT OUTER JOIN TB_AD_COMN_CODE P ON (F.CURCY_CD_ID = P.ID)
WHERE 
	1 = 1 
	AND J.ID= @P_SABC_ID;

go

