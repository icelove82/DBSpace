/*****************************************************************************
Title : SP_UI_DP_15_POP_Q1
 
설명 
 - DP User Mapping - New Item mapping 
 
History (수정일자 / 수정자 / 수정내용)
- 2022.11.23 /hanguls create
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_15_POP_Q1] ( @p_EMP_NO         NVARCHAR(50) = ''
									  		, @p_AUTH_TP_ID	  NVARCHAR(50) = ''
                                      		, @p_ITEM_MST_ID        NVARCHAR(32) = ''
								   ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE   @V_EMP_CD         NVARCHAR(50) = ''
		, @V_AUTH_TP_ID		NVARCHAR(50) = ''
		, @V_ITEM_ID        NVARCHAR(4000) = ''
		, @P_EMP_ID         NVARCHAR(32)      = NULL 

		
SET @V_EMP_CD       = @p_EMP_NO     
SET @V_AUTH_TP_ID	= @p_AUTH_TP_ID	
SET @V_ITEM_ID      = @p_ITEM_MST_ID    

BEGIN
	SELECT @P_EMP_ID = ID 
	  FROM TB_AD_USER
	WHERE USERNAME = @P_EMP_NO
	;

		 
	with map as (
	 select distinct  m.EMP_ID , m.AUTH_TP_ID, m.ACCOUNT_ID, @P_ITEM_MST_ID as ITEM_MST_ID
	 from TB_DP_USER_ITEM_ACCOUNT_MAP m	
	 where AUTH_TP_ID = @P_AUTH_TP_ID
	 and EMP_ID = @P_EMP_ID
	) select EMP_ID, AUTH_TP_ID, ACCOUNT_ID, ITEM_MST_ID, a.ACCOUNT_CD, a.ACCOUNT_NM ,  i.ITEM_CD, i.ITEM_NM, 'Y' AS ACTV_YN
	  from map
	 inner join TB_DP_ACCOUNT_MST a on a.id = map.ACCOUNT_ID
	 inner join TB_CM_ITEM_MST i  on i.id = map.ITEM_MST_ID  
		 
;


END


		   





go

