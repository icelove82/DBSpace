CREATE PROCEDURE [dbo].[SP_UI_RP_29_Q1] (
    @P_SIMUL_VER_ID         NVARCHAR(100) = ''
   ,@P_LOCAT_TP_NM          NVARCHAR(100) = ''
   ,@P_LOCAT_LV             NVARCHAR(100) = ''
   ,@P_LOCAT_CD             NVARCHAR(100) = ''
   ,@P_LOCAT_NM             NVARCHAR(100) = ''
   ,@P_ITEM_CD              NVARCHAR(100) = ''
   ,@P_ITEM_NM              NVARCHAR(100) = ''
   ,@P_ITEM_TP_NM           NVARCHAR(100) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_CONBD_MAIN_VER_DTL_ID    CHAR(32) = ''

BEGIN
    SET @P_CONBD_MAIN_VER_DTL_ID = (SELECT ID FROM TB_CM_CONBD_MAIN_VER_DTL WHERE SIMUL_VER_ID = @P_SIMUL_VER_ID)

    SELECT	F.COMN_CD_NM					AS LOCAT_TP_NM
            ,E.LOCAT_LV
            ,D.LOCAT_CD
            ,D.LOCAT_NM
			,DA.COMN_CD						AS LOCAT_GRP_CD
			,D.BUSINESS_UNIT				AS BUSINESS_UNIT
			,DC.COMN_CD						AS IN_OUT_FLAG
            ,G.ITEM_CD
            ,G.DESCRIP						AS ITEM_DESCRIP
            ,G.ITEM_NM
            ,H.UOM_NM   
            ,J.COMN_CD						AS STOCK_MGMT_SYSTEM_TP
            ,J.COMN_CD_NM					AS STOCK_MGMT_SYSTEM_TP_NM
            ,K.COMN_CD_NM					AS STOCK_PLACE_STRTGY_NM
            ,G.ATTR_01
            ,G.ATTR_02
            ,G.ATTR_03
            ,G.ATTR_04
            ,G.ATTR_05
            ,G.ATTR_06
            ,G.ATTR_07
            ,G.ATTR_08
            ,G.ATTR_09
            ,G.ATTR_10
            ,G.ATTR_11
            ,G.ATTR_12
            ,G.ATTR_13
            ,G.ATTR_14
            ,G.ATTR_15
            ,G.ATTR_16
            ,G.ATTR_17
            ,G.ATTR_18
            ,G.ATTR_19
            ,G.ATTR_20
            ,Q.COMN_CD_NM					AS OPERT_BASE_TP_NM
            ,I.OPERT_TARGET_VAL				AS OPERT_TARGET
            ,I.INVTURN						AS INVTURN
            ,A.PREDICT_LV					AS PREDICT_LV
            ,I.SFST_SVC_LV					AS TARGET_SVC_LV
            ,A.LIVE_FILL_RATE
            ,A.PLAN_FILL_RATE
            ,T.ACCOUNT_CD
            ,T.ACCOUNT_NM
            ,S.DAT
            ,S.DMND_QTY
            ,ISNULL(S.PDT_DELIVY, 0)		AS PREDICT_DELIVY
            ,S.BACK_ORD
            ,S.FILL_RATE
			,S.CONFRM_OUT_PREDICT
			,S.SHPP_PLAN					AS SHIPPING_PLAN
            ,S.SHPP_PLAN_MP					AS SHIPPING_PLAN_MP
			,S.INDEPEND_PO_REQ
            ,S.BOH
			,S.DUE_IN AS DUE_IN
            ,S.DUE_IN_MP
			,S.DUE_IN_DIFF
			,S.CONFRM_DUE_IN
			,S.PO_PREDICT
            ,S.EOH
            ,S.TARGET_INV					AS TARGET_STOCK
			,S.INV_PLAN_DIFF
			,IIF(F.COMN_CD = 'LOC_FERT', S.PRDUCT_PLAN, NULL)  AS PRDUCT_PLAN
    FROM	TB_RT_RP_RETURN_MST A
            LEFT OUTER JOIN TB_CM_SITE_ITEM B
            ON A.LOCAT_ITEM_ID = B.ID
            LEFT OUTER JOIN TB_CM_LOC_MGMT C
            ON B.LOCAT_MGMT_ID = C.ID
            LEFT OUTER JOIN TB_CM_LOC_DTL D
            ON D.ID = C.LOCAT_ID
			LEFT OUTER JOIN TB_AD_COMN_CODE DA
			ON DA.ID = D.LOCAT_GRP_ID
			LEFT OUTER JOIN TB_AD_COMN_CODE DC
			ON DC.ID = D.IN_OUT_FLAG_ID
            LEFT OUTER JOIN TB_CM_LOC_MST E
            ON E.ID = D.LOCAT_MST_ID
            LEFT OUTER JOIN TB_AD_COMN_CODE F
            ON F.ID = E.LOCAT_TP_ID
            LEFT OUTER JOIN TB_CM_ITEM_MST G
			ON G.ID = B.ITEM_MST_ID
            LEFT OUTER JOIN TB_CM_UOM H
            ON H.ID = G.UOM_ID
            LEFT OUTER JOIN TB_IM_INV_POLICY_ITEM I
			ON I.LOCAT_ITEM_ID = B.ID
            LEFT OUTER JOIN TB_AD_COMN_CODE J
            ON J.ID = I.INV_MGMT_SYSTEM_TP_ID
            LEFT OUTER JOIN TB_AD_COMN_CODE K
            ON K.ID = I.INV_PLACE_STRTGY_ID
            LEFT OUTER JOIN TB_IM_SITE_ITEM_SEG_SUMM L
            ON L.LOCAT_ITEM_ID = B.ID
            LEFT OUTER JOIN TB_CM_ITEM_TYPE N
            ON N.ITEM_TP = L.VAL_03
            LEFT OUTER JOIN TB_AD_COMN_CODE Q
            ON Q.ID = I.OPERT_BASE_TP_ID
            LEFT OUTER JOIN TB_IM_INV_POLICY_PROPRIETY R
            ON R.LOCAT_ITEM_ID = B.ID
            LEFT OUTER JOIN TB_RT_RP_RETURN_DATA S
            ON S.RP_RETURN_MST_ID = A.ID
            LEFT OUTER JOIN TB_DP_ACCOUNT_MST T
            ON S.ACCOUNT_ID = T.ID
    WHERE	1=1
      AND	A.CONBD_MAIN_VER_DTL_ID  = @P_CONBD_MAIN_VER_DTL_ID
      AND	ISNULL(F.COMN_CD_NM, '') LIKE '%'+ISNULL(@P_LOCAT_TP_NM, '')+'%'
      AND	ISNULL(E.LOCAT_LV, 1)	 LIKE '%'+ISNULL(@P_LOCAT_LV, 1)+'%'
      AND	ISNULL(D.LOCAT_CD, '')   LIKE '%'+ISNULL(@P_LOCAT_CD, '')+'%'
      AND	ISNULL(D.LOCAT_NM, '')   LIKE '%'+ISNULL(@P_LOCAT_NM, '')+'%'
      AND	ISNULL(G.ITEM_CD, '')	 LIKE '%'+ISNULL(@P_ITEM_CD, '')+'%'
      AND	ISNULL(G.ITEM_NM, '')	 LIKE '%'+ISNULL(@P_ITEM_NM, '')+'%'
      AND	ISNULL(N.CONVN_NM, '')	 LIKE '%'+ISNULL(@P_ITEM_TP_NM, '')+'%'

END

go

