/*****************************************************************************
Title : SP_UI_DP_SALES_AUTH_LV_COMBO
최초 작성자 : 이고은
최초 생성일 : 2017.08.14
 
설명 
 - SP_UI_DP_SALES_AUTH_LV_COMBO
  
History (수정일자 / 수정자 / 수정내용)
- 2017.08.14 / 이고은 / 최초 작성
- 2019.04.25 / 김소희 / DEL_YN Null처리 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_SALES_AUTH_LV_COMBO] 

AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN


SELECT	 LV.ID				AS ID
		,GRP.CONF_CD
		,LV.LV_CD
		,LV.LV_NM			AS CD_NM
		,LV.SALES_LV_YN
		,LV.ACCOUNT_LV_YN
		,LV.LEAF_YN
FROM	TB_CM_CONFIGURATION CON 
		INNER JOIN TB_CM_COMM_CONFIG GRP  ON CON.ID = GRP.CONF_ID AND CON.CONF_NM = GRP.CONF_GRP_CD
		INNER JOIN TB_CM_LEVEL_MGMT LV	 ON GRP.ID = LV.LV_TP_ID 
WHERE	CON.MODULE_CD		= 'DP'
AND		GRP.CONF_GRP_CD		= 'DP_LV_TP'
AND		GRP.ACTV_YN			= 'Y'
AND		GRP.CONF_CD			= 'S'
AND		LV.ACTV_YN			= 'Y'
AND		ISNULL(LV.DEL_YN,'N')			= 'N'
							

END





go

