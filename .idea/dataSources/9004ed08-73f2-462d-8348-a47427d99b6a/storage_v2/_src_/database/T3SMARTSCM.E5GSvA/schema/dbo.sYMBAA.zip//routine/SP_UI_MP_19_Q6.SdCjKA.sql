/*****************************************************************************
Title : SP_UI_MP_19_Q6
최초 작성자 : 곽명근
최초 생성일 : 2018.01.15
 
설명 
 - Demand Overview 에서 신규추가 팝업에서 2번째 탭 Due Date 설정하면 그거 파라미터로 받아서 4번째 탭 Due Date Fence 설정해줌.
 
History (수정일자 / 수정자 / 수정내용)
- 2018.01.15 / 곽명근 / 최초 작성
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_MP_19_Q6] (
	@P_DUE_DATE	DATE = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

	SELECT  A.CATAGY_CD
		  , A.CATAGY_VAL
		  , A.UOM_ID
		  , B.UOM_CD
		  , CASE WHEN ISNULL(A.ACTV_YN, 'N') = 'N' OR CAST(ISNULL(A.CATAGY_VAL, 0) AS NUMERIC) < 1 THEN NULL
				 WHEN B.UOM_CD = 'DAY'   THEN DATEADD(DD, CAST(A.CATAGY_VAL AS NUMERIC), @P_DUE_DATE)
 		         WHEN B.UOM_CD = 'WEEK'  THEN DATEADD(WK, CAST(A.CATAGY_VAL AS NUMERIC), @P_DUE_DATE)
 			     WHEN B.UOM_CD = 'MONTH' THEN DATEADD(MM, CAST(A.CATAGY_VAL AS NUMERIC), @P_DUE_DATE)
 			     WHEN B.UOM_CD = 'YEAR'  THEN DATEADD(YY, CAST(A.CATAGY_VAL AS NUMERIC), @P_DUE_DATE)
		    END  AS DUE_DATE_FENCE
   FROM TB_CM_BASE_ORDER A
      , TB_CM_UOM B
   WHERE A.CATAGY_CD = 'BASE_ORDER_DUE_DATE_FENCE'
     AND A.UOM_ID = B.ID

END

go

