CREATE PROCEDURE [dbo].[SP_UI_CM_03_POP_01_Q] (
	 @P_CONF_KEY 			AS NVARCHAR(30)
	,@P_VIEW_ID 			AS NVARCHAR(50) = ''
	,@P_ITEM_LV_ID 			AS NVARCHAR(32) = ''
	,@P_ITEM_CLASS 			AS NVARCHAR(32) = ''
	,@P_ITEM_CLASS_DTL_ID	AS CHAR(32) = ''
	,@P_LANG_CD 			AS NVARCHAR(32) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_MAX_INT INT = 0

BEGIN
  IF @P_CONF_KEY ='001' /* SITE ITEM */
      BEGIN
		SELECT B.ITEM_SCOPE_NM AS ITEM_LV_NM
			 , A.ITEM_CLASS_VAL 
			 , A.DESCRIP
			 , @P_VIEW_ID AS VIEW_ID
		  FROM TB_CM_ITEM_CLASS_MST A 
			 , TB_CM_ITEM_SCOPE_MST B 
		 WHERE A.ITEM_SCOPE_MST_ID = B.ID
		   AND A.ID LIKE '%'+ RTRIM(@P_ITEM_LV_ID) +'%'
      END	

   IF @P_CONF_KEY ='002' /* ITEM_ATTRIBUTE */
      BEGIN
		SELECT A.ID
			  ,A.CONF_ID
			  ,A.ATTR_NM
			  ,B.LANG_VALUE AS CONVN_NM
			  ,A.ACTV_YN
			  ,CAST(SUBSTRING(A.ATTR_NM, LEN(A.ATTR_NM)-1, LEN(A.ATTR_NM)) AS INT) AS SEQ
			  ,A.CREATE_BY
			  ,A.CREATE_DTTM
			  ,A.MODIFY_BY
			  ,A.MODIFY_DTTM
		  FROM TB_CM_ITEM_ATTRIBUTE A
			   LEFT OUTER JOIN TB_AD_LANG_PACK B
			   ON B.LANG_KEY = A.CONVN_NM
			   AND B.LANG_CD = @P_LANG_CD
		 WHERE B.LANG_VALUE IS NOT NULL
	     ORDER BY A.ATTR_NM ASC
      END

   IF @P_CONF_KEY ='003' /* @P_ITEM_CLASS */
      BEGIN
		SELECT ATTRS
				, VAL
				FROM
			(SELECT DISTINCT 
					CASE WHEN A.ATTR_01 IS NOT NULL THEN ISNULL(B.ATTR_01, '') END AS ATTR_01
					, CASE WHEN A.ATTR_02 IS NOT NULL THEN ISNULL(B.ATTR_02, '') END AS ATTR_02
					, CASE WHEN A.ATTR_03 IS NOT NULL THEN ISNULL(B.ATTR_03, '') END AS ATTR_03
					, CASE WHEN A.ATTR_04 IS NOT NULL THEN ISNULL(B.ATTR_04, '') END AS ATTR_04
					, CASE WHEN A.ATTR_05 IS NOT NULL THEN ISNULL(B.ATTR_05, '') END AS ATTR_05
					, CASE WHEN A.ATTR_06 IS NOT NULL THEN ISNULL(B.ATTR_06, '') END AS ATTR_06
					, CASE WHEN A.ATTR_07 IS NOT NULL THEN ISNULL(B.ATTR_07, '') END AS ATTR_07
					, CASE WHEN A.ATTR_08 IS NOT NULL THEN ISNULL(B.ATTR_08, '') END AS ATTR_08
					, CASE WHEN A.ATTR_09 IS NOT NULL THEN ISNULL(B.ATTR_09, '') END AS ATTR_09
					, CASE WHEN A.ATTR_10 IS NOT NULL THEN ISNULL(B.ATTR_10, '') END AS ATTR_10
					, CASE WHEN A.ATTR_11 IS NOT NULL THEN ISNULL(B.ATTR_11, '') END AS ATTR_11
					, CASE WHEN A.ATTR_12 IS NOT NULL THEN ISNULL(B.ATTR_12, '') END AS ATTR_12
					, CASE WHEN A.ATTR_13 IS NOT NULL THEN ISNULL(B.ATTR_13, '') END AS ATTR_13
					, CASE WHEN A.ATTR_14 IS NOT NULL THEN ISNULL(B.ATTR_14, '') END AS ATTR_14
					, CASE WHEN A.ATTR_15 IS NOT NULL THEN ISNULL(B.ATTR_15, '') END AS ATTR_15
					, CASE WHEN A.ATTR_16 IS NOT NULL THEN ISNULL(B.ATTR_16, '') END AS ATTR_16
					, CASE WHEN A.ATTR_17 IS NOT NULL THEN ISNULL(B.ATTR_17, '') END AS ATTR_17
					, CASE WHEN A.ATTR_18 IS NOT NULL THEN ISNULL(B.ATTR_18, '') END AS ATTR_18
					, CASE WHEN A.ATTR_19 IS NOT NULL THEN ISNULL(B.ATTR_19, '') END AS ATTR_19
					, CASE WHEN A.ATTR_20 IS NOT NULL THEN ISNULL(B.ATTR_20, '') END AS ATTR_20
				FROM TB_CM_ITEM_CLASS_MST A
					, TB_CM_ITEM_CLASS_DTL B
				WHERE A.ID = B.ITEM_CLASS_ID
				AND B.ID = @P_ITEM_CLASS_DTL_ID) B UNPIVOT (VAL FOR ATTRS IN (ATTR_01
                                                                            ,ATTR_02
                                                                            ,ATTR_03
                                                                            ,ATTR_04
                                                                            ,ATTR_05
                                                                            ,ATTR_06
                                                                            ,ATTR_07
                                                                            ,ATTR_08
                                                                            ,ATTR_09
                                                                            ,ATTR_10
                                                                            ,ATTR_11
                                                                            ,ATTR_12
                                                                            ,ATTR_13
                                                                            ,ATTR_14
                                                                            ,ATTR_15
                                                                            ,ATTR_16
                                                                            ,ATTR_17
                                                                            ,ATTR_18
                                                                            ,ATTR_19
                                                                            ,ATTR_20)) UnPVT;
	  END

  IF @P_CONF_KEY ='004' /* ITEM_ATTRIBUTE CANDIDATE */
      BEGIN
		SELECT A.ID
			  ,A.ATTR_NM
			  ,B.LANG_VALUE AS CONVN_NM
		 FROM TB_CM_ITEM_ATTRIBUTE A
		      LEFT OUTER JOIN TB_AD_LANG_PACK B
			  ON B.LANG_KEY = A.CONVN_NM
			  AND B.LANG_CD = @P_LANG_CD
	  END

  IF @P_CONF_KEY ='005'
	BEGIN
		SELECT ATTRS
					 , VAL_ID
				  FROM
				(SELECT DISTINCT 
					   A.ATTR_01
					 , A.ATTR_02
					 , A.ATTR_03
					 , A.ATTR_04
					 , A.ATTR_05
					 , A.ATTR_06
					 , A.ATTR_07
					 , A.ATTR_08
					 , A.ATTR_09
					 , A.ATTR_10
					 , A.ATTR_11
					 , A.ATTR_12
					 , A.ATTR_13
					 , A.ATTR_14
					 , A.ATTR_15
					 , A.ATTR_16
					 , A.ATTR_17
					 , A.ATTR_18
					 , A.ATTR_19
					 , A.ATTR_20
				  FROM TB_CM_ITEM_CLASS_MST A
				 WHERE 1=1
				   AND A.ITEM_CLASS_VAL = @P_ITEM_CLASS) B UNPIVOT (VAL_ID FOR ATTRS IN (ATTR_01
                                                                                        ,ATTR_02
                                                                                        ,ATTR_03
                                                                                        ,ATTR_04
                                                                                        ,ATTR_05
                                                                                        ,ATTR_06
                                                                                        ,ATTR_07
                                                                                        ,ATTR_08
                                                                                        ,ATTR_09
                                                                                        ,ATTR_10
                                                                                        ,ATTR_11
                                                                                        ,ATTR_12
                                                                                        ,ATTR_13
                                                                                        ,ATTR_14
                                                                                        ,ATTR_15
                                                                                        ,ATTR_16
                                                                                        ,ATTR_17
                                                                                        ,ATTR_18
                                                                                        ,ATTR_19
                                                                                        ,ATTR_20)) UnPVT;
	END

	IF @P_CONF_KEY ='006'
	BEGIN
		SET @P_MAX_INT =(
		SELECT 
            ISNULL(MAX(CAST(RIGHT(A.ITEM_GRP, 4) AS INT)), 0)+1 

        FROM TB_CM_ITEM_CLASS_DTL A
            ,TB_CM_ITEM_CLASS_MST B
        WHERE 1=1
        AND A.ITEM_CLASS_ID = B.ID)

        SELECT 'Item Group - ' + DBO.FN_G_LPAD(@P_MAX_INT, 4, '0') AS ITEM_GRP_NM;
	END

END

go

