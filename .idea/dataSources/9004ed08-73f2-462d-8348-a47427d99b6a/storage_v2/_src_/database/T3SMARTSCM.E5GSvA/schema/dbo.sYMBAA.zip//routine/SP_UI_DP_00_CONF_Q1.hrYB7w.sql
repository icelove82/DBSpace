/*****************************************************************************
Title : [SP_UI_DP_00_CONF_Q1]
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP 콤보(공통코드) 조회 프로시저 
  
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2018.12.21 / 김소희 / Repor Bucket 추가 
- 2019.01.24 / 김소희 / 코드 삭제 : MODULE_TP, MODULE_TP_EDIT, CONF_KEY, CUSTOMER
- 2019.03.19 / 김소희 / INCOTERMS => CM_INCOTERMS로 설정 코드 그룹명 변경
- 2020.02.03 / 김소희 / ALL과 유사 기능을 하는 NN 처리 추가 : 선택하고자 하는 값이 콤보에 없을 경우에 대한 처리 
- 2020.09.28 / hanguls / 개인화테이블 변경 반영
- 2021.08.05 /hanguls / Level type I or S 
- 2022.05.31/ kim sohee / add sm config value, when @p_grp_cd is plan type
- 2023.03.07 / kim sohee / add attributes
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_00_CONF_Q1] (@p_GRP_CD    NVARCHAR(30) = ''
                                           , @p_TYPE      NVARCHAR(30) = ''
										   , @p_LOCALE    NVARCHAR(32) = ''
								   ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
set nocount on
DECLARE @V_GRP_CD NVARCHAR(30) = ''
	  , @V_TYPE	  NVARCHAR(30) = ''
	  , @V_LOCALE NVARCHAR(32) = ''

SET @V_GRP_CD   = @p_GRP_CD
SET @V_TYPE		= @p_TYPE
SET @V_LOCALE	= @p_LOCALE

BEGIN

		-- CONFIGURATION
		IF @V_GRP_CD = 'UOM'
			BEGIN	
	   
				SELECT  A.ID 
					  , A.CD
					  , A.CD_NM
				FROM (
						SELECT  ''  AS ID 
							  , CASE WHEN @V_TYPE = 'All' THEN 'ALL' ELSE '' END  AS CD
							  , CASE WHEN @V_TYPE = 'All' THEN 'ALL' ELSE '' END  AS CD_NM
						UNION ALL 
						SELECT  B.ID
							  , B.UOM_CD
							  , B.UOM_NM
						  FROM  TB_CM_CONFIGURATION A 
							  , TB_CM_UOM B
						 WHERE A.ID = B.CONF_ID
						   AND B.ACTV_YN = 'Y'
					   ) A
				 ORDER BY  A.CD ASC
				 ;

		   END
		ELSE IF @V_GRP_CD = 'INCOTERMS'
			BEGIN	
	   
				SELECT  A.ID 
					  , A.CD
					  , A.CD_NM
				FROM (
						SELECT  ''  AS ID 
							  , CASE WHEN @V_TYPE = 'All' THEN 'ALL' ELSE '' END  AS CD
							  , CASE WHEN @V_TYPE = 'All' THEN 'ALL' ELSE '' END  AS CD_NM
						UNION ALL 
						SELECT  B.ID  AS ID
							, B.INCOTERMS  AS CD
							, B.INCOTERMS  AS CD_NM
 						FROM   TB_CM_CONFIGURATION A
							, TB_CM_INCOTERMS B
								where  A.ID = B.CONF_ID
								AND A.CONF_NM = 'CM_INCOTERMS'
								AND B.ACTV_YN = 'Y'
					   ) A
				 ORDER BY  A.CD ASC
				 ;

		   END
		ELSE IF @V_GRP_CD = 'DP_CHANNEL_TP'
			BEGIN	

				SELECT  A.ID 
					  , A.CD
					  , A.CD_NM
					  , A.VMI_YN
				FROM (
						SELECT  ''  AS ID 
							  , CASE WHEN @V_TYPE = 'All' THEN 'ALL' ELSE '' END  AS CD
							  , CASE WHEN @V_TYPE = 'All' THEN 'ALL' ELSE '' END  AS CD_NM
							  , '' AS VMI_YN
						UNION ALL 
						SELECT  B.ID  AS ID
							, B.CHANNEL_ID  AS CD
							, B.CHANNEL_NM  AS CD_NM
							, B.VMI_YN      AS VMI_YN
 						FROM   TB_CM_CONFIGURATION A
							, TB_CM_CHANNEL_TYPE B
								where  A.ID = B.CONF_ID
								AND B.ACTV_YN = 'Y'
					   ) A
				 ORDER BY  A.CD ASC
				 ;

		   END

		ELSE IF @V_GRP_CD = 'UI_ID'
			BEGIN	
					
					SELECT REPLACE(VIEW_CD,'SR_','SRP_') AS CD
						 , REPLACE(VIEW_CD,'SR_','SRP_') AS CD_NM
					  FROM TB_AD_USER_PREF_MST
					 WHERE 1=1
					    AND AUTO_CREATE_YN ='Y'
						AND (VIEW_CD LIKE '%' + REPLACE(LEFT(@V_TYPE,2),'SR','SRP') + '%'
						     or VIEW_CD LIKE '%' + (CASE WHEN @V_TYPE = 'DP' THEN 'BP' ELSE 'SRP' END) + '%' 
						    )
					  GROUP BY VIEW_CD
					  order by VIEW_CD

		   END
		ELSE IF @V_GRP_CD = 'UI_ID_MES_SET'
			BEGIN						
					SELECT VIEW_CD AS CD , VIEW_CD AS CD_NM
					  FROM TB_AD_USER_PREF_MST
					 WHERE 1=1
					    AND AUTO_CREATE_YN ='Y'
						AND (VIEW_CD LIKE '%DP_9%' or VIEW_CD LIKE '%BP_9%' or VIEW_CD = 'UI_DP_ENTRY_NOTIFY') 
					  GROUP BY VIEW_CD
					  order by VIEW_CD;
		   END


		ELSE IF @V_GRP_CD = 'GRID'
			BEGIN	
	   
				SELECT GRID_CD AS CD
					, GRID_DESCRIP AS CD_NM
--					 , GRID_CD + CASE WHEN ISNULL(GRID_DESCRIP,'')='' THEN NULL ELSE ' ('+GRID_DESCRIP+')' END AS CD_NM
				  FROM TB_AD_USER_PREF_MST
				 WHERE VIEW_CD=@V_TYPE
				   AND AUTO_CREATE_YN='Y'
				 ORDER BY GRID_CD ASC
				 ;

		   END
		ELSE IF @V_GRP_CD = 'BUCKET'
			BEGIN	
	   
					SELECT 'YEAR'   AS CD
						  ,'Year'   AS CD_NM
						  ,'Y'      AS CD_ID
						  ,1   AS SEQ
					UNION ALL
					SELECT 'MONTH'   AS CD
						  ,'Month'   AS CD_NM
						  , 'M'      AS CD_ID
						  ,2   AS SEQ
					UNION ALL
					SELECT 'WEEK'   AS CD
						  ,'Week'   AS CD_NM
						  ,'W'      AS CD_ID 
						,3   AS SEQ
					UNION ALL
					SELECT 'PAR_WEEK'   AS CD
						  ,'Partial Week'   AS CD_NM
						  ,'PW'      AS CD_ID 
						  ,4   AS SEQ
--					UNION ALL
--					SELECT 'DAY'   AS CD
--						  ,'Day'   AS CD_NM
--						  ,'D'     AS CD_ID   
--						  ,5   AS SEQ
				 ;
		   END
		  ELSE IF @V_GRP_CD = 'BUCKET_REPORT'
			BEGIN
				SELECT 'MONTH'   AS CD
					  ,'Month'   AS CD_NM
					  , 'M'      AS CD_ID
					,2   AS SEQ
				UNION ALL
				SELECT 'WEEK'   AS CD
					  ,'Week'   AS CD_NM
					  ,'W'      AS CD_ID 
					,3   AS SEQ
			END		
		ELSE IF(@V_GRP_CD = 'DP_PLAN_TYPE')
			BEGIN
				
				WITH PLAN_POLICY
				  AS (
					SELECT P.PLAN_TP_ID, P.POLICY_VAL
						  ,CASE P.POLICY_VAL  
						    WHEN 'Y' THEN 4 
							WHEN 'M'  THEN 3
							WHEN 'W'  THEN 2
							WHEN 'PW' THEN 1
							WHEN 'D'  THEN 0
						  END	AS SEQ 
					 FROM TB_DP_PLAN_POLICY	P
						  INNER JOIN 
						  TB_CM_COMM_CONFIG C
					   ON P.POLICY_ID = C.ID 
					WHERE C.CONF_CD = 'B'
					), START_MONTH
					AS (
						SELECT PLAN_TP_ID, POLICY_VAL 
						  FROM TB_DP_PLAN_POLICY	P
								  INNER JOIN 
								  TB_CM_COMM_CONFIG C
							   ON P.POLICY_ID = C.ID 
							WHERE C.CONF_CD = 'SM'					
					)
					SELECT    B.ID         AS ID
							, B.CONF_GRP_CD
							, B.CONF_CD    AS CD
							, B.CONF_NM    AS CD_NM
							, B.PRIORT
							, B.ATTR_01
							, CASE P.POLICY_VAL 
								WHEN 'W'  THEN 'WEEK'
								WHEN 'PW' THEN 'PAR_WEEK'
								WHEN 'M'  THEN 'MONTH'
								WHEN 'D'  THEN 'DAY'
								WHEN 'Y'  THEN 'YEAR' END AS BUCKET
							,CASE WHEN SEQ = (SELECT MIN(SEQ) FROM PLAN_POLICY) THEN 'Y' ELSE 'N' END AS LEAF_BUKT_YN 
							,S.POLICY_VAL AS SM
							FROM   TB_CM_COMM_CONFIG B
								   INNER JOIN 
									PLAN_POLICY P
								ON  B.ID = P.PLAN_TP_ID 
								  INNER JOIN 
								  START_MONTH S
							   ON P.PLAN_TP_ID = S.PLAN_TP_ID 
								WHERE  1=1 -- A.MODULE_CD = 'DP'
								AND B.CONF_GRP_CD LIKE  '%' + @V_GRP_CD + '%'  --'DP_LV_TP'
								AND B.CONF_CD LIKE  '%' + @p_TYPE + '%' 
								AND B.ACTV_YN = 'Y'
						ORDER BY PRIORT ASC;
			END
		ELSE IF(@V_GRP_CD = 'DP_PRICE_TYPE')
			BEGIN
						SELECT  B.ID  AS ID
							  , B.CONF_GRP_CD  
							  , B.CONF_CD AS CD 
							  , B.CONF_NM  AS CD_NM
							  , B.PRIORT
 						 FROM   TB_CM_CONFIGURATION A
							  , TB_CM_COMM_CONFIG B
								 where  1=1 -- A.MODULE_CD = 'DP'
								   AND A.ID = B.CONF_ID
								   AND B.CONF_GRP_CD LIKE '%'+ @V_GRP_CD + '%'  --'DP_PRICE_TYPE'
								   AND B.ACTV_YN = 'Y'
						ORDER BY B.PRIORT ASC, B.CONF_CD ASC
			END
		ELSE IF(@V_GRP_CD = 'DP_SO_STATUS')
			BEGIN
						SELECT  B.ID  AS ID
							  , B.CONF_GRP_CD  
							  , B.CONF_CD AS CD 
							  , B.CONF_NM  AS CD_NM
							  , B.PRIORT
 						 FROM   TB_CM_COMM_CONFIG B
								 where  1=1 
								   AND B.CONF_GRP_CD LIKE '%'+ @V_GRP_CD + '%' 
								   AND B.ACTV_YN = 'Y'
						ORDER BY B.PRIORT ASC, B.CONF_CD ASC
			END
		ELSE IF(@V_GRP_CD = 'DP_MS_QTY_TP')
			BEGIN
						SELECT  B.ID  AS ID
							  , B.CONF_GRP_CD  
							  , B.CONF_CD AS CD 
							  , B.CONF_NM  AS CD_NM
							  , B.PRIORT
							  , B.DESCRIP
 						 FROM   TB_CM_CONFIGURATION A
							  , TB_CM_COMM_CONFIG B
								 where  1=1 
								   AND A.ID = B.CONF_ID
								   AND B.CONF_GRP_CD LIKE '%'+ 'DP_MS_VAL_TP' + '%'  
								   AND B.ACTV_YN = 'Y'
								   AND LEFT(B.CONF_CD,3) = 'QTY'
						ORDER BY PRIORT ASC
			END
		ELSE IF (@V_GRP_CD = 'BF_SELECT_CRITERIA')
			BEGIN
				SELECT CONF_CD		AS CD
				  FROM TB_CM_COMM_CONFIG
				 WHERE CONF_GRP_CD = @V_GRP_CD
				   AND ACTV_YN = 'Y'
				ORDER BY PRIORT 
			END
		ELSE IF (@V_GRP_CD = 'DP_LV_TP_I') -- 2021.08 add
			BEGIN
				SELECT  B.ID  AS ID
						, B.CONF_GRP_CD  
						, B.CONF_CD AS CD 
						, B.CONF_NM  AS CD_NM
						, B.PRIORT
						, B.DESCRIP
 					FROM  TB_CM_COMM_CONFIG B
				   where  B.CONF_GRP_CD = 'DP_LV_TP' AND B.ACTV_YN = 'Y' and CONF_CD like 'I%'
				          and case when @V_TYPE = 'EXTRA' then 'I' else '' end != CONF_CD
				ORDER BY PRIORT
			END
		ELSE IF (@V_GRP_CD = 'DP_LV_TP_S') -- 2021.08 add
			BEGIN
				SELECT  B.ID  AS ID
						, B.CONF_GRP_CD  
						, B.CONF_CD AS CD 
						, B.CONF_NM  AS CD_NM
						, B.PRIORT
						, B.DESCRIP
 					FROM  TB_CM_COMM_CONFIG B
				   where  B.CONF_GRP_CD = 'DP_LV_TP' AND B.ACTV_YN = 'Y' and CONF_CD like 'S%'
				ORDER BY PRIORT
			END
		ELSE 
			BEGIN

				SELECT  A.ID 
					  , A.CONF_GRP_CD
					  , A.CD
					  , A.CD_NM
					  , A.DESCRIP
					  , ATTR_01
					  , ATTR_02 
					  , ATTR_03 
					  , ATTR_04 
				FROM (
						SELECT  ''  AS ID 
							  , ''  AS CONF_GRP_CD
							  , UPPER(@V_TYPE)  AS CD
							  , UPPER(@V_TYPE)  AS CD_NM
							  , 0   AS PRIORT 
							  , NULL AS DESCRIP
							  , NULL ATTR_01
							  , NULL ATTR_02 
							  , NULL ATTR_03 
							  , NULL ATTR_04 
						WHERE UPPER(@V_TYPE) IN ('ALL', 'NN')	-- NN : None
						UNION ALL 
						SELECT  B.ID  AS ID
							  , B.CONF_GRP_CD  
							  , B.CONF_CD AS CD 
							  , B.CONF_NM  AS CD_NM
							  , B.PRIORT
							  , B.DESCRIP
							  , B.ATTR_01
							  , B.ATTR_02 
							  , B.ATTR_03 
							  , B.ATTR_04 
 						 FROM   TB_CM_CONFIGURATION A
							  , TB_CM_COMM_CONFIG B
								 where  1=1 -- A.MODULE_CD = 'DP'
								   AND A.ID = B.CONF_ID
								   AND B.CONF_GRP_CD LIKE '%'+ @V_GRP_CD + '%'  --'DP_LV_TP'
								   AND B.ACTV_YN = 'Y'
						) A
				ORDER BY A.PRIORT ASC, A.CD ASC
				;
		END
END







go

