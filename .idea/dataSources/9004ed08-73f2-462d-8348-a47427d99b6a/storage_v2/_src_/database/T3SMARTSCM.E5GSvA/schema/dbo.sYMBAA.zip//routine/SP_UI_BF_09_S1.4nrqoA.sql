
CREATE PROCEDURE [dbo].[SP_UI_BF_09_S1]  (
									  @P_TYPE NVARCHAR(10) = ''
									, @P_FACTOR_CD NVARCHAR(50) = ''
									, @P_DESCRIP NVARCHAR(100) = ''
									, @P_COLUMN_NAME NVARCHAR(50) = ''
									, @P_ACTV_YN CHAR(1) = ''
									, @P_USER_ID			NVARCHAR(50) = ''
									, @P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'  OUTPUT
									, @P_RT_MSG            NVARCHAR(4000) = ''		OUTPUT
				                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''
	   ,@V_TYPE CHAR(1) =''

IF (@P_TYPE='extend')
BEGIN
   SET @V_TYPE = 'N'
END
ELSE
BEGIN
   SET @V_TYPE = 'Y'
END

BEGIN TRY
	  BEGIN
	  --SELECT * FROM TB_BF_FACTOR_MGMT
				MERGE TB_BF_FACTOR_MGMT TAR
				USING ( 
						SELECT  @V_TYPE					AS EXTEND_YN			
							  , @P_FACTOR_CD			AS FACTOR_CD
							  , @P_DESCRIP				AS DESCRIP
							  , @P_COLUMN_NAME			AS COL_NM
							  , @P_ACTV_YN    			AS ACTV_YN
							  , @P_USER_ID		AS USER_ID	
					  ) SRC
				ON	  TAR.COL_NM			= SRC.COL_NM
				WHEN MATCHED THEN
					 UPDATE 
					   SET   TAR.EXTEND_YN		= SRC.EXTEND_YN		
							,TAR.FACTOR_CD	    = SRC.FACTOR_CD
							,TAR.DESCRIP		= SRC.DESCRIP
							,TAR.ACTV_YN        = SRC.ACTV_YN
							,TAR.MODIFY_BY		= SRC.USER_ID
							,TAR.MODIFY_DTTM	= GETDATE()
				WHEN NOT MATCHED THEN 
					 INSERT (
							  FACTOR_CD
							, COL_NM	
							, DESCRIP
							, EXTEND_YN
							, ACTV_YN
							, CREATE_BY
							, CREATE_DTTM
							) 
					 VALUES (
							  SRC.FACTOR_CD
							, SRC.COL_NM
							, SRC.DESCRIP
							, SRC.EXTEND_YN
							, SRC.ACTV_YN
							,SRC.USER_ID
							,GETDATE()
 							) 
							;
	  END


	   SET @P_RT_ROLLBACK_FLAG = 'true'

	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;

go

