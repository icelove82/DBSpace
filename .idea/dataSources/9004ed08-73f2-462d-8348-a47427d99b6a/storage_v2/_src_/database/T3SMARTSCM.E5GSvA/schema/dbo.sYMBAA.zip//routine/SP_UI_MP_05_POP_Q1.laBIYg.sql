/*****************************************************************************
Title : SP_UI_MP_05_POP_Q1
최초 작성자 : 조아람
최초 생성일 : 2017.08.03
 
설명 
 - 검색조건 팝업창 조회 프로시저
 
History (수정일자 / 수정자 / 수정내용)
- 2017.08.03 / 조아람 / 최초 작성
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_MP_05_POP_Q1] (
	 @P_CONF_KEY NVARCHAR(30) 
	,@P_VIEW_ID NVARCHAR(50) = ''
	,@P_LOC_CD	NVARCHAR(50) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

IF @P_CONF_KEY = 'LOC'
	BEGIN 
		SELECT MST.ID			AS ID
			 , DTL.ID			AS SRC_ID
			 , ACM.COMN_CD_NM	AS LOCAT_TP
			 , MST.LOCAT_LV
			 , DTL.LOCAT_CD
			 , DTL.LOCAT_NM
			 , @P_VIEW_ID		AS VIEW_ID
		  FROM TB_CM_LOC_MST MST
				INNER JOIN TB_AD_COMN_CODE	ACM
					ON MST.LOCAT_TP_ID = ACM.ID
			 , TB_CM_LOC_DTL DTL
		 WHERE MST.ID = DTL.LOCAT_MST_ID
	 END
ELSE IF @P_CONF_KEY = 'MAT'
	BEGIN
		SELECT DISTINCT 
			   ITM.ID			AS ITEM_ID
			 , ITM.ITEM_CD		AS ITEM_CD
			 , ITM.ITEM_NM		AS ITEM_NM
			 , ITM.DESCRIP		AS ITEM_DESC
			 , ITY.ITEM_TP
			 , @P_VIEW_ID		AS VIEW_ID
		  FROM TB_CM_SITE_ITEM	SIT
				INNER JOIN TB_CM_UOM	UOM
					ON SIT.UOM_ID =  UOM.ID
				INNER JOIN TB_CM_COMM_CONFIG COF
					ON SIT.MAT_CONST_TP_ID = COF.ID
			 , TB_CM_ITEM_MST		ITM
				INNER JOIN TB_CM_ITEM_TYPE ITY
					ON ITM.ITEM_TP_ID = ITY.ID
					AND ITY.ITEM_TP = 'ROH'
			 , TB_CM_LOC_MGMT		LMG
			 , TB_CM_LOC_DTL		LDT
		WHERE 1=1
		   AND SIT.ITEM_MST_ID  = ITM.ID
		   AND SIT.LOCAT_MGMT_ID = LMG.ID
		   AND LMG.LOCAT_ID = LDT.ID
		   ---------------------------------------------------------------
		   -- 조회 조건
		   ---------------------------------------------------------------
		   AND 1 = CASE WHEN @P_LOC_CD = '' THEN 1
						WHEN LDT.LOCAT_CD = @P_LOC_CD THEN 1
					END
		ORDER BY ITM.ITEM_NM
	
	END
ELSE IF @P_CONF_KEY = 'RES'
	BEGIN
		SELECT GRP.RES_GRP_CD
			 , CMC.COMN_CD_NM
			 , GRP.DESCRIP
			 , DTL.RES_CD
			 , DTL.RES_DESCRIP
			 , DTL.OUTSRC_YN
			 , @P_VIEW_ID		AS VIEW_ID
		  FROM TB_CM_RES_GROUP	GRP
				INNER JOIN TB_AD_COMN_CODE CMC
					ON GRP.RES_GRP_TP_ID = CMC.ID
		     , TB_MP_RES_MGMT_MST MST
			 , TB_MP_RES_MGMT_DTL	DTL
		 WHERE GRP.ID = MST.RES_GRP_ID
		   AND MST.ID = DTL.RES_MGMT_MST_ID

	END

END

go

