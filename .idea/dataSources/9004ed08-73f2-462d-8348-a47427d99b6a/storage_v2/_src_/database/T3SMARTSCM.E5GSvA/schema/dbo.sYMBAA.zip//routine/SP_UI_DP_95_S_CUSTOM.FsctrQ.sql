CREATE PROCEDURE [dbo].[SP_UI_DP_95_S_CUSTOM](
	  @P_VER_ID				CHAR(32)
	 ,@P_EMP_NO				NVARCHAR(50)
	 ,@P_AUTH_TP_ID			CHAR(32)
	 ,@P_TRANSACTION_ID		CHAR(32)
	 ,@P_DIS_OPT			NVARCHAR(32)	-- 1/N, ID of Measure Setting
	 ,@P_CURCY_CD_ID		CHAR(32)
	 ,@P_ROUND_NUM			INT 
) AS
/********************************************************************************************************************************************
	Entry Save

	History (Date / Writer / Comment)
	- 2020.05.11 / Kim sohee / Draft
	- 2020.05.14 / Kim sohee / find end date in procedure
	- 2020.05.26 / Kim sohee / calculate when partial date 
	- 2020.05.28 / kim sohee / user hierarchy table에서 self_mapping_yn 과 USER_ACCT_YN 활용하여 데이터 수집
	- 2020.06.05 / Kim sohee / 분배 소수점 처리
	- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER

	- description 
	- 분배 대상이 특정 테이블 값일 경우, 해당 테이블에 없는 데이터는 분배 대상에서 제외되고, 아예 없을경우에는 계산 못함 (0)
	- 가격 정보가 없을 경우, 수량은 입력한 값으로 계산해주고, 금액만 계산 못함.
	- 1/n일 때만 가변 구간의 날짜 비율 반영해서 n처리. 다른 값을 참조하여 계산할 때는, 어차피 참조값도 범위에 따라 수량이 달라질 것이기 때문에.
	

	-- 최하위 item, account로 테스트 중
	-- Partial 구간의 값이 틀어짐
	-- 1/N로 했을 때 오류나는 것 같음... Update가 하나도 안됨! (확인 필요)

	-- target ID 로 해서.. 분배로직 태워서 
	-- 큐처럼


	-- 튜닝
	-- operation 있어야
	-- activity j unit 
	-- 가이드 결과로 나옴
	-- 테이블에 분할 사용하면 좋음

	-- 아마존에 설치해서 테스트

	-- amount에 대한 분배 처리........값이 틀어지는 문제 해결해야
	-----> 금액 분배 먼저 하고, 수량으로 바꾸는 방식도 다른파일로 해보기
*******************************************************************************************************************************************/
SET NOCOUNT ON
	-- Get Version Info
	DECLARE @P_PRICE_TP_ID  CHAR(32)
		   ,@P_STRT_DATE	DATE 
		   ,@P_END_DATE		DATE 
		   ,@P_PAR_DATE		DATE
		   ,@P_IA_CNT		INT 
		   ,@P_PAR_BUKT		NVARCHAR(50)
		   ,@P_BUKT			NVARCHAR(50)
		   ,@P_EMP_ID		CHAR(32)
		   ,@P_DATE_DIFF	INT
		   ,@P_CURCY_TP_ID	CHAR(32)
		   ;
	CREATE TABLE #TB_FINAL_RT
	(   ITEM_MST_ID CHAR(32)	COLLATE DATABASE_DEFAULT
	  , ACCOUNT_ID  CHAR(32)	COLLATE DATABASE_DEFAULT
	  , BASE_DATE	DATE
	  , COMMENT		NVARCHAR(2000)	COLLATE DATABASE_DEFAULT
--	  , QTY			INT
	  , PT_Q		FLOAT
--	  , QTY_1		INT
	  , PT_Q1		FLOAT
--	  , QTY_2		INT	
	  , PT_Q2		FLOAT
--	  , QTY_3		INT
	  , PT_Q3		FLOAT
	  , GET_ID		INT 
	  , GET_NUM		INT
	)
	IF (@P_ROUND_NUM = 0)
		BEGIN
			ALTER TABLE #TB_FINAL_RT ADD QTY	INT
									   , QTY_1  INT
									   , QTY_2  INT
									   , QTY_3  INT
		END
	ELSE IF (@P_ROUND_NUM = 1)
		BEGIN
			ALTER TABLE #TB_FINAL_RT ADD QTY	DECIMAL(20,1)
									   , QTY_1  DECIMAL(20,1)
									   , QTY_2  DECIMAL(20,1)
									   , QTY_3  DECIMAL(20,1)
		END
	ELSE IF (@P_ROUND_NUM = 2)
		BEGIN
			ALTER TABLE #TB_FINAL_RT ADD QTY	DECIMAL(20,2)
									   , QTY_1  DECIMAL(20,2)
									   , QTY_2  DECIMAL(20,2)
									   , QTY_3  DECIMAL(20,2)
		END
	ELSE IF (@P_ROUND_NUM = 3)
		BEGIN
			ALTER TABLE #TB_FINAL_RT ADD QTY	DECIMAL(20,3)
									   , QTY_1  DECIMAL(20,3)
									   , QTY_2  DECIMAL(20,3)
									   , QTY_3  DECIMAL(20,3)
		END
	ELSE IF (@P_ROUND_NUM = 4)
		BEGIN
			ALTER TABLE #TB_FINAL_RT ADD QTY	DECIMAL(20,4)
									   , QTY_1  DECIMAL(20,4)
									   , QTY_2  DECIMAL(20,4)
									   , QTY_3  DECIMAL(20,4)
		END
	ELSE IF (@P_ROUND_NUM = 5)
		BEGIN
			ALTER TABLE #TB_FINAL_RT ADD QTY	DECIMAL(20,5)
									   , QTY_1  DECIMAL(20,5)
									   , QTY_2  DECIMAL(20,5)
									   , QTY_3  DECIMAL(20,5)
		END
	ELSE
		BEGIN
			ALTER TABLE #TB_FINAL_RT ADD QTY	INT
									   , QTY_1  INT
									   , QTY_2  INT
									   , QTY_3  INT
		END

	CREATE TABLE #TB_ITEM_ACCT 
	(	ITEM_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
	   ,ACCT_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
	)
	;
	CREATE TABLE #TB_TMP_DP_RT
	(	ITEM_ID			CHAR(32)	COLLATE DATABASE_DEFAULT
	   ,ITEM_LV_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
	   ,ACCT_ID			CHAR(32)	COLLATE DATABASE_DEFAULT
	   ,SALES_LV_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
	   ,BASE_DATE		DATE
	   ,END_DATE		DATE
	   ,QTY				FLOAT
	   ,QTY_1			FLOAT
	   ,QTY_2			FLOAT
	   ,QTY_3			FLOAT
	   ,AMT				FLOAT
	   ,AMT_1 			FLOAT
	   ,AMT_2 			FLOAT
	   ,AMT_3  			FLOAT
	   ,COMMENT			NVARCHAR(2000)	COLLATE DATABASE_DEFAULT
	)	
	;
BEGIN
	SELECT @P_PRICE_TP_ID   = PRICE_TP_ID 
		  ,@P_STRT_DATE		= DTF_DATE 
		  ,@P_END_DATE		= TO_DATE 
		  ,@P_BUKT			= BUKT 
		  ,@P_PAR_DATE		= ISNULL(VER_S_HORIZON_DATE, DATEADD(DAY, 1, TO_DATE))
		  ,@P_PAR_BUKT		= VER_S_BUCKET
		  ,@P_CURCY_TP_ID	= CURCY_TP_ID
	  FROM TB_DP_CONTROL_BOARD_VER_MST
	 WHERE ID = @P_VER_ID 
	;
	 
	SELECT @P_EMP_ID = ID 
	  FROM TB_AD_USER
	 WHERE [USERNAME] = @P_EMP_NO
	 ;
	/***************************************************************************************************************************************
		-- Calculate End Date
	***************************************************************************************************************************************/
	WITH USERS_INFO
	AS (-- 나와 내 하위 사용자 정보 찾기
		SELECT DESC_ID				AS EMP_ID
			 , DESC_CD				AS EMP_CD
			 , DESC_ROLE_ID 		AS ROLE_ID
			 , DESC_ROLE_CD 		AS ROLE_CD
			 , USER_ACCT_YN
		  FROM TB_DPD_USER_HIER_CLOSURE	US -- 내 매핑 정보가 있으면 내 하위 사용자 매핑 정보는 안본다.		   
		 WHERE ANCS_ROLE_ID = @P_AUTH_TP_ID
		   AND ANCS_ID		= @P_EMP_ID 	
		   AND MAPPING_SELF_YN = 'Y'
	), ITEM
	AS (	  SELECT CASE WHEN CL.LEAF_YN = 'Y' THEN IM.ITEM_MST_ID ELSE IM.ITEM_LV_ID END	AS ID
				   , CL.LEAF_YN
				   , US.ROLE_ID
				   , US.EMP_ID
				FROM TB_DP_USER_ITEM_MAP IM 
					  INNER JOIN
					  USERS_INFO US 
				  ON (IM.EMP_ID = US.EMP_ID AND IM.AUTH_TP_ID = US.ROLE_ID)					   
					  INNER JOIN 
					  TB_CM_LEVEL_MGMT CL 
				  ON (IM.LV_MGMT_ID = CL.ID 
				 AND CL.ACTV_YN = 'Y'
				 AND CL.DEL_YN = 'N')
			   WHERE IM.ACTV_YN = 'Y'   
	) , ACCT
	AS (-- 내 매핑 ACCT 찾기
			SELECT CASE WHEN CL.LEAF_YN = 'Y' THEN AM.ACCOUNT_ID ELSE AM.SALES_LV_ID END	AS ID
				 , US.ROLE_ID
				 , US.EMP_ID
				 , CL.LEAF_YN
			  FROM TB_DP_USER_ACCOUNT_MAP AM 
				   INNER JOIN
				   USERS_INFO US
				ON AM.EMP_ID = US.EMP_ID
			   AND AM.AUTH_TP_ID = US.ROLE_ID
				   INNER JOIN
				   TB_CM_LEVEL_MGMT CL
				ON AM.LV_MGMT_ID = CL.ID 
			   AND CL.ACTV_YN = 'Y'
			   AND ISNULL(CL.DEL_YN, 'N') = 'N'
			 WHERE AM.ACTV_YN = 'Y'	 
	), EX
	AS (SELECT EX.ITEM_MST_ID 
			 , EX.ACCOUNT_ID
			 , US.ROLE_ID
			 , US.EMP_ID
		  FROM TB_DP_USER_ITEM_ACCOUNT_EXCLUD EX
			   INNER JOIN
			   USERS_INFO US
			ON EX.EMP_ID = US.EMP_ID
		   AND EX.AUTH_TP_ID = US.ROLE_ID
	), ITEM_HIER
	AS (
		SELECT ANCESTER_ID
			 , DESCENDANT_ID
		  FROM TB_DPD_ITEM_HIER_CLOSURE
		 WHERE LEAF_YN = 'Y' 	
	), SALES_HIER
	AS (
		SELECT ANCESTER_ID
			 , DESCENDANT_ID
		  FROM TB_DPD_SALES_HIER_CLOSURE
		 WHERE LEAF_YN = 'Y' 	
	), IA_LEAF	-- 사용자의 Item account 최하위 조합 정보
	AS (    SELECT ACCT.ROLE_ID
				 , ACCT.EMP_ID 
				 , CASE WHEN ITEM.LEAF_YN = 'Y' THEN ITEM.ID ELSE IH.DESCENDANT_ID END		AS ITEM_ID
				 , CASE WHEN ACCT.LEAF_YN = 'Y' THEN ACCT.ID ELSE SH.DESCENDANT_ID END		AS ACCT_ID
			  FROM ACCT		 
				   INNER JOIN
				   ITEM		 
				ON ACCT.ROLE_ID = ITEM.ROLE_ID
			   AND ACCT.EMP_ID  = ITEM.EMP_ID
				   INNER JOIN 
				   ITEM_HIER IH ON ( ITEM.ID = IH.ANCESTER_ID )
				   INNER JOIN
				   SALES_HIER SH
				ON ACCT.ID = SH.ANCESTER_ID
			 EXCEPT
			 SELECT ROLE_ID
				  , EMP_ID
				  , ITEM_MST_ID
				  , ACCOUNT_ID
			   FROM EX
	)
	INSERT INTO #TB_ITEM_ACCT
			 ( ACCT_ID
			 , ITEM_ID )
	   SELECT DISTINCT 
			   ACCT_ID 
			  ,ITEM_ID 
		 FROM IA_LEAF 
		 UNION
		SELECT DISTINCT 
			   ACCOUNT_ID
			 , ITEM_MST_ID
		  FROM TB_DP_USER_ITEM_ACCOUNT_MAP UIAM	-- item, account 각각의 매핑 정보가 있으면, 이 매핑 정보는 안본다.
			   INNER JOIN
			   USERS_INFO USIF
			ON UIAM.EMP_ID = USIF.EMP_ID
		   AND UIAM.AUTH_TP_ID = USIF.ROLE_ID
		 WHERE USIF.USER_ACCT_YN = 'N'	 
		 ;
	CREATE TABLE #TB_TMP_DP_LOG
	( ITEM_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
	 ,ACCOUNT_ID	CHAR(32)	COLLATE DATABASE_DEFAULT
	 ,BASE_DATE		DATE
	 ,END_DATE		DATE
	 ,QTY			FLOAT
	 ,QTY_1			FLOAT
	 ,QTY_2			FLOAT
	 ,QTY_3			FLOAT
	 ,AMT			FLOAT
	 ,AMT_1			FLOAT
	 ,AMT_2			FLOAT
	 ,AMT_3			FLOAT
	 ,COMMENT		NVARCHAR(2000)
	)
	INSERT INTO #TB_TMP_DP_LOG
	( ITEM_ID	
	 ,ACCOUNT_ID
	 ,BASE_DATE	
	 ,END_DATE	
	 ,QTY		
	 ,QTY_1		
	 ,QTY_2		
	 ,QTY_3		
	 ,AMT		
	 ,AMT_1		
	 ,AMT_2		
	 ,AMT_3
	 ,COMMENT	 
	)		
	SELECT ITEM_ID		 
		 , ACCOUNT_ID		 
		 , BASE_DATE
		 , ISNULL(DATEADD( DAY, -1, LEAD(BASE_DATE,1) OVER (PARTITION BY ITEM_ID, ACCOUNT_ID ORDER BY BASE_DATE ASC)), @P_END_DATE) AS END_DATE 
		 , NULLIF(QTY	,0)	 
		 , NULLIF(QTY_1	,0) 
		 , NULLIF(QTY_2	,0) 
		 , NULLIF(QTY_3 ,0)	 
		 , NULLIF(AMT 	,0)	 
		 , NULLIF(AMT_1 ,0)	 
		 , NULLIF(AMT_2 ,0)	 
		 , NULLIF(AMT_3 ,0) 	
		 , COMMENT 
	  FROM TB_DP_ENTRY_LOG
	 WHERE VER_ID = @P_VER_ID 
	   AND [USERNAME] = @P_EMP_NO
	   AND AUTH_TP_ID = @P_AUTH_TP_ID
	   AND TRANSACTION_ID = @P_TRANSACTION_ID
--		 SELECT *		 
--		  FROM #TB_ITEM_ACCT
--		  ;
	/***************************************************************************************************************************************
		-- Insert Data of Entry Log
	***************************************************************************************************************************************/
	-- For Calculating Amount
	IF EXISTS ( SELECT 1
				  FROM #TB_TMP_DP_LOG
				 WHERE COALESCE(AMT,AMT_1,AMT_2,AMT_3) IS NOT NULL	
			  )
			  BEGIN -- UNIT PRICE
					CREATE TABLE #TB_TMP_UNIT_PRICE
					(  ITEM_MST_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
					  ,ACCOUNT_ID		CHAR(32)	COLLATE DATABASE_DEFAULT				
					  ,STRT_DATE		DATE
					  ,END_DATE			DATE
					  ,AF_STRT_DATE		DATE
					  ,UTPIC			DECIMAL(20,3)	
					)
					INSERT INTO #TB_TMP_UNIT_PRICE
					( ITEM_MST_ID		
					 ,ACCOUNT_ID	
					 ,STRT_DATE	 
					 ,END_DATE		 
--					 ,AF_STRT_DATE	 
					 ,UTPIC		
					)
					SELECT ITEM_MST_ID
						 , ACCOUNT_ID 
						 , BASE_DATE																										AS STRT_DATE 
						 , ISNULL(DATEADD(DAY,-1,LEAD(BASE_DATE) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID ORDER BY  BASE_DATE )),@P_END_DATE)	AS END_DATE  	
--						 , LEAD(BASE_DATE,1) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID ORDER BY BASE_DATE) AS AF_STRT_DATE 
						 , UTPIC
					  FROM TB_DP_UNIT_PRICE UP
						   INNER JOIN
						   #TB_ITEM_ACCT IA 
						ON UP.ITEM_MST_ID = IA.ITEM_ID
					   AND UP.ACCOUNT_ID = IA.ACCT_ID	   
					 WHERE BASE_DATE	<= @P_END_DATE 
					   AND PRICE_TP_ID	 = @P_PRICE_TP_ID

					-- EXCHANGE RATE
					CREATE TABLE #TB_TMP_EXCHANGE_RATE
					(  FROM_CURCY_CD_ID	CHAR(32)	COLLATE DATABASE_DEFAULT
					  ,STRT_DATE		DATE
					  ,END_DATE			DATE
					  ,AF_STRT_DATE		DATE
					  ,EXCHANGE_RATE	DECIMAL(20,5)	
					)
					INSERT INTO #TB_TMP_EXCHANGE_RATE
					(  FROM_CURCY_CD_ID	
					  ,STRT_DATE	
					  ,END_DATE		
--					  ,AF_STRT_DATE	
					  ,EXCHANGE_RATE	
					)
					SELECT FROM_CURCY_CD_ID
						 , BASE_DATE																										AS STRT_DATE 
						 , ISNULL(DATEADD(DAY,-1,LEAD(BASE_DATE) OVER (PARTITION BY FROM_CURCY_CD_ID ORDER BY  BASE_DATE )),@P_END_DATE)	AS END_DATE  	
--						 , LEAD(BASE_DATE,1) OVER (PARTITION BY FROM_CURCY_CD_ID ORDER BY BASE_DATE)										AS AF_STRT_DATE 
						 , EXCHANGE_RATE
					  FROM TB_DP_EXCHANGE_RATE
					 WHERE 1=1
					   AND TO_CURCY_CD_ID = @p_CURCY_CD_ID 
					   AND BASE_DATE	 <= @P_END_DATE 
					   AND CURCY_TP_ID    = @P_CURCY_TP_ID 
					;					
						INSERT INTO #TB_TMP_DP_RT
						(   ITEM_ID	
						   ,ITEM_LV_ID 	
						   ,ACCT_ID	
						   ,SALES_LV_ID 
						   ,BASE_DATE	
						   ,END_DATE 
						   ,QTY			
						   ,QTY_1		
						   ,QTY_2		
						   ,QTY_3	
						   ,AMT 
						   ,AMT_1 
						   ,AMT_2 
						   ,AMT_3  		
						   ,COMMENT   		
						)
							SELECT IA.ITEM_ID
								 , EL.ITEM_ID
								 , IA.ACCT_ID
								 , EL.ACCOUNT_ID
								 , EL.BASE_DATE
								 , EL.END_DATE  
								 , ISNULL(EL.QTY,EL.AMT / UP.UTPIC / ISNULL(EC.EXCHANGE_RATE,1))
								 , ISNULL(EL.QTY_1,EL.AMT_1 / UP.UTPIC / ISNULL(EC.EXCHANGE_RATE,1)) 
								 , ISNULL(EL.QTY_2,EL.AMT_2 / UP.UTPIC / ISNULL(EC.EXCHANGE_RATE,1)) 
								 , ISNULL(EL.QTY_3,EL.AMT_3 / UP.UTPIC / ISNULL(EC.EXCHANGE_RATE,1)) 
								 , EL.AMT
								 , EL.AMT_1
								 , EL.AMT_2
								 , EL.AMT_3
								 , EL.COMMENT
							  FROM #TB_TMP_DP_LOG EL 
								   INNER JOIN
								   TB_DPD_ITEM_HIER_CLOSURE IH
								ON EL.ITEM_ID = IH.ANCESTER_ID
							   AND IH.LEAF_YN = 'Y'
								   INNER JOIN
								   TB_DPD_SALES_HIER_CLOSURE SH
								ON EL.ACCOUNT_ID = SH.ANCESTER_ID
							   AND SH.LEAF_YN = 'Y'
								   INNER JOIN
								   #TB_ITEM_ACCT IA
								ON IA.ITEM_ID = IH.DESCENDANT_ID
							   AND IA.ACCT_ID = SH.DESCENDANT_ID
								   INNER JOIN
								   #TB_TMP_UNIT_PRICE UP 
								ON IA.ITEM_ID = UP.ITEM_MST_ID
							   AND IA.ACCT_ID = UP.ACCOUNT_ID
							   AND EL.BASE_DATE BETWEEN UP.STRT_DATE AND UP.END_DATE 
								   INNER JOIN
								   TB_DP_ACCOUNT_MST AM
								ON AM.ID = IA.ACCT_ID
	 							   LEFT OUTER JOIN
								   #TB_TMP_EXCHANGE_RATE EC
							   ON EC.FROM_CURCY_CD_ID= AM.CURCY_CD_ID
							   AND EL.BASE_DATE BETWEEN EC.STRT_dATE AND EC.END_DATE 
							   ;
							DROP TABLE #TB_TMP_EXCHANGE_RATE
							DROP TABLE #TB_TMP_UNIT_PRICE
							;
						SELECT *
						 FROM #TB_TMP_DP_RT 
						 ;
			  END
		ELSE
			BEGIN	-- there is not empty Quantity.
					INSERT INTO #TB_TMP_DP_RT
					(   ITEM_ID	
					   ,ITEM_LV_ID 	
					   ,ACCT_ID	
					   ,SALES_LV_ID 
					   ,BASE_DATE	
					   ,END_DATE 
					   ,QTY			
					   ,QTY_1		
					   ,QTY_2		
					   ,QTY_3	
					   ,AMT 
					   ,AMT_1 
					   ,AMT_2 
					   ,AMT_3  	
					   ,COMMENT	   		
					)
						SELECT IA.ITEM_ID
							 , EL.ITEM_ID
							 , IA.ACCT_ID
							 , EL.ACCOUNT_ID
							 , EL.BASE_DATE
							 , EL.END_DATE  
							 , EL.QTY	 
							 , EL.QTY_1	 
							 , EL.QTY_2	 
							 , EL.QTY_3	 
							 , EL.AMT
							 , EL.AMT_1
							 , EL.AMT_2
							 , EL.AMT_3
							 , EL.COMMENT
						  FROM #TB_TMP_DP_LOG EL 
							   INNER JOIN
							   TB_DPD_ITEM_HIER_CLOSURE IH
							ON EL.ITEM_ID = IH.ANCESTER_ID
						   AND IH.LEAF_YN = 'Y'
							   INNER JOIN
							   TB_DPD_SALES_HIER_CLOSURE SH
							ON EL.ACCOUNT_ID = SH.ANCESTER_ID
						   AND SH.LEAF_YN = 'Y'
							   INNER JOIN
							   #TB_ITEM_ACCT IA
							ON IA.ITEM_ID = IH.DESCENDANT_ID
						   AND IA.ACCT_ID = SH.DESCENDANT_ID				
						;
			END

			--	SELECT *
			--	  FROM #TB_TMP_DP_RT
				TRUNCATE TABLE #TB_ITEM_ACCT;
				INSERT INTO #TB_ITEM_ACCT ( ITEM_ID, ACCT_ID )
				SELECT DISTINCT ITEM_ID, ACCT_ID
				  FROM #TB_TMP_DP_RT 
				  ;
	/****************************************************************************************************************************************************************
		-- Count ( Item, Account)
	****************************************************************************************************************************************************************/	
	IF NOT EXISTS ( SELECT 1 -- If IA_CNT = 1, aggregaton is not necessary.
					  FROM #TB_TMP_DP_RT 
					 WHERE BASE_DATE <= @P_PAR_DATE 
					GROUP BY BASE_DATE
					HAVING COUNT(ITEM_ID) > 1
				 )
				 BEGIN
					SET @P_IA_CNT  = 1 ;
				 END
	/****************************************************************************************************************************************************************
		-- Distribution Option	
	****************************************************************************************************************************************************************/	 
	DECLARE @P_MS_TP	NVARCHAR(10)
		  , @P_MS_KEY	NVARCHAR(35)	-- Table or Level Mgmt ID
		  , @P_MS_COL	NVARCHAR(50)
		  , @P_VAL_TP	NVARCHAR(10)
		  , @P_SQL		NVARCHAR(MAX)
	;
	CREATE TABLE #TB_MS_DATA
	( ITEM_MST_ID	CHAR(32)	COLLATE DATABASE_DEFAULT
	 ,ACCOUNT_ID	CHAR(32)	COLLATE DATABASE_DEFAULT
	 ,BASE_DATE		DATE 
	 ,RATE			FLOAT 
	)
	;
	SELECT @P_MS_COL = 
		   CASE CF.CONF_CD 
			WHEN 'ADDITION' THEN ME.MEASURE_CD
			WHEN 'DEMAND'	THEN LV.LV_CD 
		   END	--AS MS_CD
         , @P_MS_KEY = 
		  CASE CF.CONF_CD 
			WHEN 'ADDITION' THEN ME.TBL_NM
			WHEN 'DEMAND'	THEN LV.ID  
		   END	--AS MS_ID
		 , @P_VAL_TP = VT.CONF_CD		--AS VAL_TP
		 , @P_MS_TP = CF.CONF_CD		--AS MS_TP
	 FROM TB_DP_MEASURE_SETTING MS
		  INNER JOIN 
		  TB_CM_COMM_CONFIG CF  
	   ON MS.MEASURE_CONF_TP_ID = CF.ID
	      LEFT OUTER JOIN
		  TB_DP_MEASURE_MST ME
	   ON MS.MEASURE_MST_ID = ME.ID
	      LEFT OUTER JOIN
		  TB_CM_LEVEL_MGMT LV
	   ON MS.LV_MGMT_ID = LV.ID 
	      INNER JOIN
		  TB_CM_COMM_CONFIG VT
	   ON MS.MEASURE_VAL_TP_ID = VT.ID 
	 WHERE MS.ID = @P_DIS_OPT
	 ;		

	 IF (@P_MS_TP = 'ADDITION')
		BEGIN		
			 IF NOT EXISTS ( SELECT 1 
							   FROM INFORMATION_SCHEMA.COLUMNS  
							  WHERE TABLE_CATALOG = DB_NAME()
								AND TABLE_NAME = @P_MS_KEY
								AND COLUMN_NAME = @P_MS_COL
						   ) 
			 BEGIN
				SET @P_MS_COL = CASE WHEN @P_MS_COL LIKE '%QTY' THEN 'QTY' ELSE 'AMT' END
				;
			 END 
			 ;
			-- Run Dynamic Query
			WITH DYNAMIC_PARAM
			AS (-- (1) TB_DP_MEASURE_DATA
				SELECT ', M.'+@P_MS_COL+' AS VAL '						AS VAL_COLUMN
					 , '-- '											AS GROUP_BY
					 , ', M.BASE_DATE'									AS BASE_DATE
			     WHERE @P_MS_KEY = 'TB_DP_MEASURE_DATA'					 
			     UNION
				-- (2) Other Tables
			    SELECT +', SUM(M.'+@P_MS_COL+') AS VAL '
					 , ' GROUP BY M.ITEM_MST_ID, M.ACCOUNT_ID'
					 , ', C.STRT_DT' 
			     WHERE @p_MS_KEY != 'TB_DP_MEASURE_DATA' 
			)
			SELECT @P_SQL = ' SELECT M.ITEM_MST_ID, M.ACCOUNT_ID'+BASE_DATE
						  +  VAL_COLUMN 
					      + ' FROM '+@P_MS_KEY+ ' M'
						  + CASE WHEN @P_MS_KEY = 'TB_DP_MEASURE_DATA' THEN ''	 
								ELSE ' INNER JOIN '
									+' (SELECT MIN(DAT) STRT_DT, MAX(DAT) END_DT '
									+'FROM TB_CM_CALENDAR '
									+'WHERE DAT BETWEEN @P_STRT_DATE AND @P_END_DATE '
									+'GROUP BY YYYY '
								    + CASE WHEN @P_BUKT IN ('PW','W') THEN ',DP_WK' ELSE '' END
								    + CASE WHEN @P_BUKT IN ('PW','M') THEN ',MM' ELSE '' END
									+' ) C '
									+'ON M.BASE_DATE BETWEEN C.STRT_DT AND C.END_DT'
							END						  
						  + ' WHERE M.BASE_DATE BETWEEN @P_STRT_DATE AND @P_END_DATE' 
						  + GROUP_BY+BASE_DATE
			-- Run Dynamic Query
			  FROM DYNAMIC_PARAM
			  ;
--			SELECT @P_SQL
--			;
			INSERT INTO #TB_MS_DATA (ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, RATE)
			EXEC sp_executesql @P_SQL,N'@P_STRT_DATE DATE, @P_END_DATE DATE', @P_STRT_DATE,@P_END_DATE		
			;


		    DELETE 
			  FROM #TB_MS_DATA 
			 WHERE ITEM_MST_ID+'_'+ACCOUNT_ID NOT IN (SELECT ITEM_ID+'_'+ACCT_ID FROM #TB_ITEM_ACCT)
			
			CREATE INDEX IDX_TB_MS_DATA ON #TB_MS_DATA (ITEM_MST_ID, ACCOUNT_ID, BASE_DATE)	
			;				
--			SELECT *
--			  FROM #TB_MS_DATA
--			  ;
		END
	 ELSE IF (@P_MS_TP = 'DEMAND')
		BEGIN
		INSERT INTO #TB_MS_DATA (ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, RATE)
	 		SELECT M.ITEM_MST_ID
				 , M.ACCOUNT_ID
				 , BASE_DATE
				 , CASE @P_VAL_TP WHEN 'QTY' THEN QTY ELSE AMT END  AS VAL
			  FROM TB_DP_ENTRY M
				   INNER JOIN
				   #TB_ITEM_ACCT IA
				ON M.ITEM_MST_ID = IA.ITEM_ID
			   AND M.ACCOUNT_ID = IA.ACCT_ID
			 WHERE VER_ID = @P_VER_ID
			   AND AUTH_TP_ID = @P_MS_KEY
			   AND M.BASE_DATE BETWEEN @P_STRT_DATE AND @P_END_DATE		 
		END
	/****************************************************************************************************************************************************************
		-- Calculate and Set a temporary Reult table	 : 1. 기준일이 Partial Date 보다 작은 경우 (기준일 값 그대로)
	*****************************************************************************************************************************************************************/
	IF (@P_IA_CNT = 1)	-- Distribute X
		BEGIN	-- When Leaf Level, parameter is same to DP Entry Key. So, can not use Join of item and sales Hierarchies.
			INSERT INTO #TB_FINAL_RT 
					(  ITEM_MST_ID 
					 , ACCOUNT_ID  
					 , BASE_DATE	
					 , COMMENT
					 , QTY			
					 , QTY_1		
					 , QTY_2		
					 , QTY_3		
					)
				SELECT ITEM_ID
					 , ACCT_ID 
					 , BASE_DATE 
					 , COMMENT
					 , QTY		
					 , QTY_1	
					 , QTY_2	
					 , QTY_3	
				  FROM #TB_TMP_DP_RT 
				 WHERE BASE_DATE < @P_PAR_DATE
				   ;
		END		
	ELSE IF (@P_MS_TP IS NULL)	-- 1/n
		BEGIN	-- have to find Item & Sales Hierarchies. 				
		INSERT INTO #TB_FINAL_RT 
					(  ITEM_MST_ID 
					 , ACCOUNT_ID  
					 , BASE_DATE
					 , COMMENT	
					 , QTY			
					 , PT_Q
					 , QTY_1		
					 , PT_Q1 
					 , QTY_2		
					 , PT_Q2 
					 , QTY_3		
					 , PT_Q3 
					 , GET_ID 
					 , GET_NUM
					)	
			SELECT   ITEM_ID
				  ,  ACCT_ID 
				  ,  BASE_DATE	
				  ,  COMMENT
				  ,  QTY	    /  COUNT(QTY)   OVER (PARTITION BY ITEM_LV_ID, SALES_LV_ID, BASE_DATE)
				  ,  QTY	    /  COUNT(QTY)   OVER (PARTITION BY ITEM_LV_ID, SALES_LV_ID, BASE_DATE) 
				  ,  QTY_1	    /  COUNT(QTY_1) OVER (PARTITION BY ITEM_LV_ID, SALES_LV_ID, BASE_DATE) 	-- 1/n		 
				  ,  QTY_1	    /  COUNT(QTY_1) OVER (PARTITION BY ITEM_LV_ID, SALES_LV_ID, BASE_DATE) 	-- 1/n		 
				  ,  QTY_2	    /  COUNT(QTY_2) OVER (PARTITION BY ITEM_LV_ID, SALES_LV_ID, BASE_DATE) 		 
				  ,  QTY_2	    /  COUNT(QTY_2) OVER (PARTITION BY ITEM_LV_ID, SALES_LV_ID, BASE_DATE) 		 
				  ,  QTY_3	    /  COUNT(QTY_3) OVER (PARTITION BY ITEM_LV_ID, SALES_LV_ID, BASE_DATE) 	
				  ,  QTY_3	    /  COUNT(QTY_3) OVER (PARTITION BY ITEM_LV_ID, SALES_LV_ID, BASE_DATE) 	
				  ,  DENSE_RANK() OVER (ORDER BY ITEM_LV_ID, SALES_LV_ID, BASE_DATE) 	
				  ,  ROW_NUMBER() OVER (PARTITION BY ITEM_LV_ID, SALES_LV_ID, BASE_DATE ORDER BY ITEM_ID)
		     FROM #TB_TMP_DP_RT
		    WHERE BASE_DATE < @P_PAR_DATE
			;
		END		
	ELSE -- Specific Rate of Measure When Partial Bucket
		BEGIN	
		INSERT INTO #TB_FINAL_RT 
					(  ITEM_MST_ID 
					 , ACCOUNT_ID  
					 , BASE_DATE	
					 , COMMENT
					 , QTY			
					 , PT_Q
					 , QTY_1		
					 , PT_Q1 
					 , QTY_2		
					 , PT_Q2 
					 , QTY_3		
					 , PT_Q3 
					 , GET_ID 
					 , GET_NUM
					)		
			SELECT   RT.ITEM_ID
				  ,  RT.ACCT_ID 
				  ,  RT.BASE_DATE	
				  ,  COMMENT
				  ,  QTY	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE)	
				  ,  QTY	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE)	
				  ,  QTY_1	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE) 	
				  ,  QTY_1	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE) 	
				  ,  QTY_2	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE) 	
				  ,  QTY_2	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE) 	
				  ,  QTY_3	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE)  	
				  ,  QTY_3	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE)  	
				  ,  DENSE_RANK() OVER (ORDER BY ITEM_LV_ID, SALES_LV_ID, RT.BASE_DATE) 	
				  ,  ROW_NUMBER() OVER (PARTITION BY ITEM_LV_ID, SALES_LV_ID, RT.BASE_DATE ORDER BY ITEM_ID)
		     FROM #TB_TMP_DP_RT RT 
				  INNER JOIN
				  #TB_MS_DATA MD
			   ON RT.ITEM_ID = MD.ITEM_MST_ID
			  AND RT.ACCT_ID = MD.ACCOUNT_ID
			  AND RT.BASE_DATE = MD.BASE_DATE
		    WHERE RT.BASE_DATE < @P_PAR_DATE
				 ;			
		END	 

	/****************************************************************************************************************************************************************
		-- Calculate and Set a temporary Reult table	 : 2. 기준일이 Partial Date 보다 큰 경우
	*****************************************************************************************************************************************************************/
	IF (@P_MS_TP IS NULL AND @P_END_DATE >= @P_PAR_DATE) -- 1/n When Partial Bucket
		BEGIN	-- have to find Item & Sales Hierarchies. 
			  WITH CAL
			   AS ( SELECT MIN(DAT)		AS STRT_DATE  
						 , MAX(DAT)		AS END_DATE
						 , COUNT(DAT)	AS DT_CNT
					  FROM TB_CM_CALENDAR
					 WHERE DAT BETWEEN @P_PAR_DATE AND @P_END_DATE
				  GROUP BY YYYY
						, CASE WHEN @P_BUKT IN ('M','PW') THEN MM ELSE 1 END
						, CASE WHEN @P_BUKT IN ('W','PW') THEN DP_WK  ELSE 1 END 
			   )	
			INSERT INTO #TB_FINAL_RT 
					(  ITEM_MST_ID 
					 , ACCOUNT_ID  
					 , BASE_DATE	
					 , COMMENT
					 , QTY			
					 , PT_Q
					 , QTY_1		
					 , PT_Q1 
					 , QTY_2		
					 , PT_Q2 
					 , QTY_3		
					 , PT_Q3 
					 , GET_ID 
					 , GET_NUM
					)	
				SELECT  ITEM_ID 
					  , ACCT_ID   
					  , CAL.STRT_DATE   
					  , COMMENT
					  , QTY	  /  COUNT(QTY)   OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, CAL.STRT_DATE)  * CAL.DT_CNT / (DATEDIFF(DAY, BASE_DATE, RT.END_DATE)+1)
					  , QTY	  /  COUNT(QTY)   OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, CAL.STRT_DATE)  * CAL.DT_CNT / (DATEDIFF(DAY, BASE_DATE, RT.END_DATE)+1)
					  , QTY_1 /  COUNT(QTY_1) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, CAL.STRT_DATE)  * CAL.DT_CNT / (DATEDIFF(DAY, BASE_DATE, RT.END_DATE)+1)		-- 1/n		 
					  , QTY_1 /  COUNT(QTY_1) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, CAL.STRT_DATE)  * CAL.DT_CNT / (DATEDIFF(DAY, BASE_DATE, RT.END_DATE)+1)		-- 1/n		 
					  , QTY_2 /  COUNT(QTY_2) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, CAL.STRT_DATE)  * CAL.DT_CNT / (DATEDIFF(DAY, BASE_DATE, RT.END_DATE)+1)		 
					  , QTY_2 /  COUNT(QTY_2) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, CAL.STRT_DATE)  * CAL.DT_CNT / (DATEDIFF(DAY, BASE_DATE, RT.END_DATE)+1)		 
					  , QTY_3 /  COUNT(QTY_3) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, CAL.STRT_DATE)  * CAL.DT_CNT / (DATEDIFF(DAY, BASE_DATE, RT.END_DATE)+1)	
					  , QTY_3 /  COUNT(QTY_3) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, CAL.STRT_DATE)  * CAL.DT_CNT / (DATEDIFF(DAY, BASE_DATE, RT.END_DATE)+1)
					  , (SELECT ISNULL(MAX(GET_ID),0) FROM #TB_FINAL_RT)+DENSE_RANK() OVER (ORDER BY ITEM_LV_ID, SALES_LV_ID, BASE_DATE) 	
					  , ROW_NUMBER() OVER (PARTITION BY ITEM_LV_ID, SALES_LV_ID, BASE_DATE ORDER BY ITEM_ID)	
				 FROM  #TB_TMP_DP_RT RT
				 	   INNER JOIN
				  	   CAL 
				    ON CAL.STRT_DATE BETWEEN RT.BASE_DATE AND RT.END_DATE				
				  ;		
		END	
	ELSE IF ( @P_END_DATE >= @P_PAR_DATE)
		BEGIN	-- Specific Measure
			INSERT INTO #TB_FINAL_RT 
						(  ITEM_MST_ID 
						 , ACCOUNT_ID  
						 , BASE_DATE	
						 , COMMENT
						 , QTY			
						 , PT_Q
						 , QTY_1		
						 , PT_Q1 
						 , QTY_2		
						 , PT_Q2 
						 , QTY_3		
						 , PT_Q3 
						 , GET_ID 
						 , GET_NUM 
						)		
				SELECT   RT.ITEM_ID
					  ,  RT.ACCT_ID 
					  ,  MD.BASE_DATE 
					  ,  COMMENT
					  ,  QTY	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE)		
					  ,  QTY	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE)		
					  ,  QTY_1	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE) 		
					  ,  QTY_1	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE) 		
					  ,  QTY_2	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE) 		
					  ,  QTY_2	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE) 		
					  ,  QTY_3	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE) 	 	
					  ,  QTY_3	   * MD.RATE / SUM(MD.RATE) OVER (PARTITION BY RT.ITEM_LV_ID, RT.SALES_LV_ID, RT.BASE_DATE) 	
					  ,  (SELECT ISNULL(MAX(GET_ID),0) FROM #TB_FINAL_RT)+DENSE_RANK() OVER (ORDER BY ITEM_LV_ID, SALES_LV_ID, RT.BASE_DATE) 	
					  ,  ROW_NUMBER() OVER (PARTITION BY ITEM_LV_ID, SALES_LV_ID, RT.BASE_DATE ORDER BY ITEM_ID)
				 FROM #TB_TMP_DP_RT RT 
					  INNER JOIN
					  #TB_MS_DATA MD
				   ON RT.ITEM_ID = MD.ITEM_MST_ID
				  AND RT.ACCT_ID = MD.ACCOUNT_ID
				  AND MD.BASE_DATE BETWEEN RT.BASE_DATE AND RT.END_DATE
				WHERE RT.BASE_DATE >= @P_PAR_DATE
					 ;			
		END
		SELECT * 
		  FROM #TB_FINAL_RT
			;
	 /****************************************************************************************************************************************************************
	 -- TO_DO : Setting of below decimal point	(Parameter Y/N)
	 *****************************************************************************************************************************************************************/
	IF(@P_IA_CNT != 1 or @P_END_DATE >= @P_PAR_DATE)
		BEGIN
			WITH RT
			AS (
				SELECT ROUND(SUM(PT_Q - QTY  )	,0)	AS Q0
					 , ROUND(SUM(PT_Q1- QTY_1)	,0)	AS Q1
					 , ROUND(SUM(PT_Q2- QTY_2)	,0)	AS Q2
					 , ROUND(SUM(PT_Q3- QTY_3)	,0)	AS Q3
					 , GET_ID 
				 FROM #TB_FINAL_RT
			 GROUP BY GET_ID--, BASE_DATE  
			)
			UPDATE #TB_FINAL_RT
			   SET QTY	  = QTY	 +RT.Q0
				 , QTY_1  = QTY_1 +RT.Q1
				 , QTY_2  = QTY_2 +RT.Q2
				 , QTY_3  = QTY_3 +RT.Q3
			  FROM RT		 
			 WHERE GET_NUM = 1
			   AND #TB_FINAL_RT.GET_ID = RT.GET_ID
			   ;
		END
	 /****************************************************************************************************************************************************************
		-- Update Entry and Entry Log
	 *****************************************************************************************************************************************************************/
	-- Update Entry
	   UPDATE TB_DP_ENTRY
	      SET  QTY					   = RT.QTY			
			  ,QTY_1				   = RT.QTY_1		
			  ,QTY_2 				   = RT.QTY_2 		
			  ,QTY_3				   = RT.QTY_3		
			  ,EMP_ID				   = @P_EMP_ID		
			  ,MODIFY_BY			   = @P_EMP_NO
			  ,MODIFY_DTTM			   = GETDATE() 
			  ,comment				   = RT.comment 
	     FROM #TB_FINAL_RT RT
		WHERE TB_DP_ENTRY.VER_ID	   = @P_VER_ID			 
		  AND TB_DP_ENTRY.AUTH_TP_ID   = @P_AUTH_TP_ID	
		  AND TB_DP_ENTRY.ITEM_MST_ID  = RT.ITEM_MST_ID  
		  AND TB_DP_ENTRY.ACCOUNT_ID   = RT.ACCOUNT_ID 
		  AND TB_DP_ENTRY.BASE_DATE    = RT.BASE_DATE	-- If Bucket is not Partial Date, Base Date has only one Value.
		  AND (TB_DP_ENTRY.QTY		  != RT.QTY   OR ISNULL(TB_DP_ENTRY.comment,'') != ISNULL(RT.comment,''))
		  ; 
	 /****************************************************************************************************************************************************************
		-- To Confirm
	 *****************************************************************************************************************************************************************/
--		SELECT @P_IA_CNT		AS IA_CNT
--			 , @P_END_DATE		AS END_DATE
--			 , @P_BUKT			AS PAR_BUKT
--			 , @P_PAR_BUKT		AS BUKT
--
--		SELECT *
--		  FROM #TB_FINAL_RT			   
--		; 
	DROP TABLE #TB_FINAL_RT
	DROP TABLE #TB_ITEM_ACCT
	DROP TABLE #TB_TMP_DP_RT
	DROP TABLE #TB_MS_DATA 
	DROP TABLE #TB_TMP_DP_LOG
END

go

