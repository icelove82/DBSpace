CREATE PROCEDURE [dbo].[SP_UI_DP_28_CHART_Q3] (
										 @P_BUCK			NVARCHAR(50)	= ''
									    ,@P_STRT_DATE		DATE			= ''
										,@P_END_DATE		DATE			= ''
										,@P_USER_ID			NVARCHAR (100)	= 'admin' /* 로그인 USER (필수) */
										,@P_PLAN_TP_ID		CHAR(32)		= ''
										,@P_ITEM_CD			NVARCHAR(4000)  = NULL
										,@P_ACCT_CD			NVARCHAR(4000)  = NULL
										,@P_ITEM_LV_CD		NVARCHAR(50)	= NULL
										,@P_ACCT_LV_CD		NVARCHAR(50)	= NULL
										,@P_ITEM_ATTR_01	NVARCHAR(100)   = NULL
										,@P_ITEM_ATTR_02	NVARCHAR(100)   = NULL
										,@P_ITEM_ATTR_03	NVARCHAR(100)   = NULL
										,@P_ACCT_ATTR_01	NVARCHAR(100)   = NULL
										,@P_ACCT_ATTR_02	NVARCHAR(100)   = NULL
										,@P_ACCT_ATTR_03	NVARCHAR(100)   = NULL
										,@P_RT_MSG			NVARCHAR(4000)  = ''		 OUTPUT
																  )
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
/*****************************************************************************
Title : [SP_UI_DP_28_CHART_Q3]
최초 작성자 : 한영석
최초 생성일 : 2017.06.20
 
설명 
 - Sales Performance Report CHART 2 쿼리
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 민희영 / 최초 작성
- 2018.12.21 / 김소희 / MAIN SELECT문 컨버팅 (FN_DP_TEMP_SALES_REPORT 함수 조회)
- 2021.12.09 / KSH / add search condition about attribute
				   / add a level type
 
*****************************************************************************/

DECLARE @V_ERR_MSG NVARCHAR(4000)=''
	  , @V_ERR_STATUS INT =NULL
	  
	  , @V_STRT_DATE		DATE = ''
	  , @V_END_DATE		DATE = ''
	  , @V_PLAN_TP_ID	CHAR(32) =''
	  , @V_ITEM_CD		NVARCHAR(4000) =NULL
	  , @V_ACCT_CD		NVARCHAR(4000) =NULL
	  , @V_LAST_ITEM_LV	INT 
	  , @V_BUCK			NVARCHAR(50) = @P_BUCK
	  , @P_ITEM_LV_TP_CD NVARCHAR(10) = 'I'
	  , @P_SALES_LV_TP_CD NVARCHAR(10) = 'S'

	  ;
SET  @V_STRT_DATE		= @P_STRT_DATE	
SET  @V_END_DATE		= @P_END_DATE		
--SET  @V_PLAN_TP_ID		= @P_PLAN_TP_ID	
SET  @V_ITEM_CD		= @P_ITEM_CD		
SET  @V_ACCT_CD		= @P_ACCT_CD		
;

BEGIN TRY 

	select @V_PLAN_TP_ID = ID from TB_CM_COMM_CONFIG where conf_grp_cd = 'DP_PLAN_TYPE' and conf_cd = 'DP_PLAN_MONTHLY';

	-- Account Attribute
	DECLARE @TMP_ACCT TABLE (ACCOUNT_ID NVARCHAR(32) COLLATE DATABASE_DEFAULT) ;
 
	IF (COALESCE(@P_ACCT_ATTR_01,'') != '' OR COALESCE(@P_ACCT_ATTR_02,'') != '' OR COALESCE(@P_ACCT_ATTR_03,'') != '')
		BEGIN			
			INSERT INTO @TMP_ACCT (ACCOUNT_ID)
			SELECT ID
			  FROM TB_DP_ACCOUNT_MST SH
			 WHERE 	1=1
				AND (  'Y' = CASE WHEN COALESCE(@P_ACCT_ATTR_01,'') = '' THEN 'Y'
								ELSE ( 
									 CASE WHEN
									  UPPER(SH.ATTR_01) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCT_ATTR_01),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
									  THEN 'Y' ELSE 'N' END
									 )
							 END
					  )	  
				AND (  'Y' = CASE WHEN COALESCE(@P_ACCT_ATTR_02,'') = '' THEN 'Y'
								ELSE ( 
									 CASE WHEN
									  UPPER(SH.ATTR_02) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCT_ATTR_02),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
									  THEN 'Y' ELSE 'N' END
									 )
							 END
					  )	  
				AND (  'Y' = CASE WHEN COALESCE(@P_ACCT_ATTR_03,'') = '' THEN 'Y'
								ELSE ( 
									 CASE WHEN
									  UPPER(SH.ATTR_03) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ACCT_ATTR_03),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
									  THEN 'Y' ELSE 'N' END
									 )
							 END
					)
					;
		END
	ELSE
		BEGIN
			INSERT INTO @TMP_ACCT (ACCOUNT_ID)
			SELECT '' 
		END
	

	SELECT	@V_LAST_ITEM_LV = CAST(SUBSTRING(MAX(A.FLD_CD), 11,2) AS INT )
		  , @P_ITEM_LV_TP_CD = MAX(CC.CONF_CD)
	FROM	TB_AD_USER_PREF_DTL A 
				inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = 'UI_DP_28' and m.GRID_CD = 'RST_CPT_01' 
				inner join TB_AD_GROUP g on g.ID = A.GRP_ID 
				inner join TB_AD_USER u on u.USERNAME = @P_USER_ID 
				inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID
				INNER JOIN 
				TB_DP_DIM_SETTING DM
			 ON A.REFER_VALUE = DM.ID 
			    INNER JOIN 
				TB_CM_LEVEL_MGMT LV
			 ON DM.LV_MGMT_ID = LV.ID
			    INNER JOIN
				TB_CM_COMM_CONFIG CC
			 ON LV.LV_TP_ID = CC.ID		
				LEFT OUTER JOIN TB_AD_USER_PREF B 
			 ON	m.id = B.USER_PREF_MST_ID AND A.GRP_ID = B.GRP_ID	AND	A.FLD_CD = B.FLD_CD	AND B.USER_ID = u.ID					
	WHERE ISNULL(B.FLD_ACTIVE_YN,ISNULL(A.FLD_ACTIVE_YN,'N')) = 'Y' AND A.DIM_MEASURE_TP = 'DIMENSION'    AND SUBSTRING(A.FLD_CD, 11,2) BETWEEN 1 AND 20  ; 

	WITH CAL
	AS (
		SELECT MIN(DAT) AS STRT_DATE
			 , MAX(DAT) AS END_DATE
		  FROM TB_CM_CALENDAR
		 WHERE DAT BETWEEN @V_STRT_DATE AND @V_END_DATE
	  GROUP BY YYYY
		     , CASE WHEN @V_BUCK IN ('MONTH', 'PAR_WEEK', 'M', 'PW') THEN MM ELSE 1 END 
			 , CASE WHEN @V_BUCK IN ('PAR_WEEK', 'WEEK', 'PW', 'W') THEN DP_WK ELSE 1 END 
	), VER
	AS (   SELECT DO.ITEM_MST_ID, DO.ACCOUNT_ID
             FROM TB_DP_ENTRY_HISTORY DO  WITH (NOLOCK) 
			 	  INNER JOIN
			 	  (SELECT DISTINCT DESCENDANT_ID
			 	     FROM TB_DPD_ITEM_HIER_CLOSURE 
			 	    WHERE LEAF_YN = 'Y'
			 	      AND CASE WHEN @V_ITEM_CD LIKE '%|%' THEN ANCESTER_CD ELSE ISNULL(@V_ITEM_CD,'') END IN (SELECT ISNULL(Value,'') VAL FROM SplitTableNVARCHAR(ISNULL(@V_ITEM_CD,''),'|')) 			   
			 	      AND CASE WHEN @V_ITEM_CD NOT LIKE '%|%' THEN ANCESTER_CD ELSE ISNULL(@V_ITEM_CD,'') END LIKE '%'+ISNULL(@V_ITEM_CD,'')+'%'			     
					  AND LV_TP_CD = @P_ITEM_LV_TP_CD 
			 	  ) IH 
			   ON IH.DESCENDANT_ID = DO.ITEM_MST_ID
				   INNER JOIN
				   (SELECT DISTINCT DESCENDANT_ID 
					  FROM TB_DPD_SALES_HIER_CLOSURE 
					 WHERE LEAF_YN = 'Y' 
					   AND CASE WHEN @P_ACCT_CD LIKE '%|%' THEN ANCESTER_CD ELSE ISNULL(@P_ACCT_CD,'') END IN (SELECT ISNULL(Value,'') VAL FROM SplitTableNVARCHAR(ISNULL(@P_ACCT_CD,''),'|')) 			   
					   AND CASE WHEN @P_ACCT_CD NOT LIKE '%|%' THEN ANCESTER_CD ELSE ISNULL(@P_ACCT_CD,'') END LIKE '%'+ISNULL(@P_ACCT_CD,'')+'%'
					   AND LV_TP_CD = @P_SALES_LV_TP_CD
				) AM
				ON AM.DESCENDANT_ID = DO.ACCOUNT_ID   
            WHERE 1=1  
		      AND BASE_DATE BETWEEN @V_STRT_DATE AND @V_END_DATE
		      AND PLAN_TP_ID = @V_PLAN_TP_ID
         GROUP BY DO.ITEM_MST_ID, DO.ACCOUNT_ID
	), SA
	AS (SELECT ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, QTY 
		  FROM TB_CM_ACTUAL_SALES  WITH (NOLOCK) 
		 WHERE BASE_DATE BETWEEN @V_STRT_DATE AND @V_END_DATE
		   AND QTY > 0
	)
		SELECT  CASE @V_LAST_ITEM_LV 
				  WHEN 1             THEN  IH.LVL01_CD
				  WHEN 2             THEN  IH.LVL01_CD
				  WHEN 3             THEN  IH.LVL02_CD
				  WHEN 4             THEN  IH.LVL02_CD
				  WHEN 5             THEN  IH.LVL03_CD
				  WHEN 6             THEN  IH.LVL03_CD
				  WHEN 7             THEN  IH.LVL04_CD
				  WHEN 8             THEN  IH.LVL04_CD
				  WHEN 9             THEN  IH.LVL05_CD
				  WHEN 10            THEN  IH.LVL05_CD
				  WHEN 11            THEN  IH.LVL06_CD
				  WHEN 12            THEN  IH.LVL06_CD
				  WHEN 13            THEN  IH.LVL07_CD
				  WHEN 14            THEN  IH.LVL07_CD
				  WHEN 15            THEN  IH.LVL08_CD
				  WHEN 16            THEN  IH.LVL08_CD
				  WHEN 17            THEN  IH.LVL09_CD
				  WHEN 18            THEN  IH.LVL09_CD
				  WHEN 19            THEN  IH.LVL10_CD
				  WHEN 20            THEN  IH.LVL10_CD
				END				AS "CATEGORY"
			  , CAL.STRT_DATE	AS "DATE" 
			  , SUM(ISNULL(SA.QTY,0)) AS QTY
		  FROM  CAL
				LEFT OUTER JOIN
				SA 
			ON  SA.BASE_DATE BETWEEN CAL.STRT_DATE AND CAL.END_DATE
			    INNER JOIN 
				VER 
			 ON VER.ITEM_MST_ID = SA.ITEM_MST_ID
			AND VER.ACCOUNT_ID = SA.ACCOUNT_ID
		        INNER JOIN
			    TB_DPD_ITEM_HIERACHY2 IH 
		     ON VER.ITEM_MST_ID = IH.ITEM_ID			
		    AND IH.LV_TP_CD = @P_ITEM_LV_TP_CD
			AND (  'Y' = CASE WHEN COALESCE(@P_ITEM_ATTR_01,'') = '' THEN 'Y'
							ELSE ( 
								 CASE WHEN
								  UPPER(IH.ATTR_01) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_ATTR_01),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
								  THEN 'Y' ELSE 'N' END
								 )
				         END
				  )	  
			AND (  'Y' = CASE WHEN COALESCE(@P_ITEM_ATTR_02,'') = '' THEN 'Y'
							ELSE ( 
								 CASE WHEN
								  UPPER(IH.ATTR_02) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_ATTR_02),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
								  THEN 'Y' ELSE 'N' END
								 )
				         END
				  )	  
			AND (  'Y' = CASE WHEN COALESCE(@P_ITEM_ATTR_03,'') = '' THEN 'Y'
							ELSE ( 
								 CASE WHEN
								  UPPER(IH.ATTR_03) LIKE '%' + REPLACE(REPLACE(REPLACE(REPLACE(UPPER(@P_ITEM_ATTR_03),'[','#['),']','#]'),'_','#_'),'#','##') + '%' ESCAPE '#'         
								  THEN 'Y' ELSE 'N' END
								 )
				         END
				)	  
				INNER JOIN
				@TMP_ACCT SH
			 ON CASE WHEN SH.ACCOUNT_ID = '' THEN '' ELSE VER.ACCOUNT_ID END = SH.ACCOUNT_ID

	   GROUP BY   CASE @V_LAST_ITEM_LV 
				  WHEN 1             THEN  IH.LVL01_CD
				  WHEN 2             THEN  IH.LVL01_CD
				  WHEN 3             THEN  IH.LVL02_CD
				  WHEN 4             THEN  IH.LVL02_CD
				  WHEN 5             THEN  IH.LVL03_CD
				  WHEN 6             THEN  IH.LVL03_CD
				  WHEN 7             THEN  IH.LVL04_CD
				  WHEN 8             THEN  IH.LVL04_CD
				  WHEN 9             THEN  IH.LVL05_CD
				  WHEN 10            THEN  IH.LVL05_CD
				  WHEN 11            THEN  IH.LVL06_CD
				  WHEN 12            THEN  IH.LVL06_CD
				  WHEN 13            THEN  IH.LVL07_CD
				  WHEN 14            THEN  IH.LVL07_CD
				  WHEN 15            THEN  IH.LVL08_CD
				  WHEN 16            THEN  IH.LVL08_CD
				  WHEN 17            THEN  IH.LVL09_CD
				  WHEN 18            THEN  IH.LVL09_CD
				  WHEN 19            THEN  IH.LVL10_CD
				  WHEN 20            THEN  IH.LVL10_CD
				END	
			  , CAL.STRT_DATE
	  ;

	 SET @P_RT_MSG = 'MSG_0003'  --조회 되었습니다.
END TRY
BEGIN CATCH
IF (ERROR_MESSAGE() LIKE 'MSG_%')
	BEGIN
		SET @V_ERR_MSG = ERROR_MESSAGE()
		SET @P_RT_MSG = @V_ERR_MSG
	END
ELSE 
		THROW;
--		EXEC SP_COMM_RAISE_ERR
END CATCH;

go

