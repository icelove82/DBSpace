/*****************************************************************************
Title : [SP_DP_00_EMP_AUTH_TP_Q1]
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP 사원 권한 조회 콤보 
  
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2019.04.25 / 김소희 / DEL_YN Null처리 
- 2019.06.24 / 김소희 / Entry에는 맵핑 데이터가 있는 auth type만 나오게 수정
- 2020.03.11 / 김소희 / EMP_NO => USER_ID
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER
- 2020.10.13 / 김소희 / UI_ID exception : UI_DP_95
- 2021.01.13 / 김소희 / UI_ID exception : UI_DP_96
- 2022.04.08 / auth type code simplify
- 2022.04.20 /hanguls/ 96 화면의경우 DP mapping이 없는 사용자라면 빈 row를 무조건 리턴한다. 그외의 경우는 자신의 auth type에 map type을 구분해서 찾는다.
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_00_EMP_AUTH_TP_Q1] (@P_USER_ID NVARCHAR(50) = ''
												 ,  @P_UI_ID   NVARCHAR(50) = NULL
								   ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
DECLARE @V_USER_ID CHAR(32)
DECLARE @DP_MAP_CNT int = 1


BEGIN
 SELECT @V_USER_ID = ID FROM TB_AD_USER WHERE [USERNAME] = @P_USER_ID
 
IF (@P_UI_ID = 'UI_DP_25' OR @P_UI_ID = 'UI_DP_25_CHART' OR @P_UI_ID = 'UI_DP_26' OR @P_UI_ID = 'UI_DP_26_CHART'
 OR @P_UI_ID = 'UI_DP_95' OR @P_UI_ID = 'UI_DP_95_CHART' OR @P_UI_ID = 'UI_DP_96' OR @P_UI_ID = 'UI_DP_96_CHART'
 OR @P_UI_ID = 'UI_BP_95' OR @P_UI_ID = 'UI_BP_95_CHART'  OR @P_UI_ID = 'UI_BP_96' or @P_UI_ID = 'UI_BP_96_CHART' )
	BEGIN
		
	IF ( @P_UI_ID = 'UI_DP_96' OR @P_UI_ID = 'UI_DP_96_CHART' OR @P_UI_ID = 'UI_BP_96' or @P_UI_ID = 'UI_BP_96_CHART' ) 
	BEGIN 
		SELECT @DP_MAP_CNT = SUM(CNT) from 
		(
			SELECT COUNT(UI.EMP_ID) as CNT
			  FROM TB_DP_USER_ACCOUNT_MAP UI
			 WHERE  UI.ACTV_YN ='Y' 
			   AND UI.EMP_ID =	@V_USER_ID
			 UNION
			SELECT COUNT(EMP_ID) as CNT
			  FROM TB_DP_USER_ITEM_ACCOUNT_MAP IA 
			 WHERE IA.ACTV_YN ='Y' 
			   AND EMP_ID = @V_USER_ID
			UNION
		 	SELECT COUNT(SA.EMP_ID) as CNT
			  FROM TB_DP_SALES_AUTH_MAP SA
			 WHERE EMP_ID = @V_USER_ID
		) A
	END
	
	if @DP_MAP_CNT > 0
		BEGIN
		WITH ITEM_ACCT_MAP
		AS (
			SELECT UI.EMP_ID
				 , UI.AUTH_TP_ID
				 , '2' AS TP
			  FROM TB_DP_USER_ITEM_MAP UI
			 WHERE UI.ACTV_YN ='Y' 
			   AND UI.EMP_ID =	@V_USER_ID
		  GROUP BY EMP_ID, AUTH_TP_ID
			 UNION
			SELECT UI.EMP_ID
				 , UI.AUTH_TP_ID
				 , '2' AS TP
			  FROM TB_DP_USER_ACCOUNT_MAP UI
			 WHERE  UI.ACTV_YN ='Y' 
			   AND UI.EMP_ID =	@V_USER_ID
		  GROUP BY EMP_ID, AUTH_TP_ID
			 UNION
			SELECT EMP_ID
			     , AUTH_TP_ID 
				 , '1'AS TP
			  FROM TB_DP_USER_ITEM_ACCOUNT_MAP IA 
			 WHERE IA.ACTV_YN ='Y' 
			   AND EMP_ID = @V_USER_ID
		  GROUP BY EMP_ID, AUTH_TP_ID
			UNION
		 	SELECT SA.EMP_ID, 
		 		   SL.LV_MGMT_ID AS AUTH_TP_ID, 
		 		   '0' AS TP
			  FROM TB_DP_SALES_AUTH_MAP SA
				   INNER JOIN 
				   TB_DP_SALES_LEVEL_MGMT SL 
				ON SL.ID = SA.SALES_LV_ID 
			   AND ISNULL(SL.DEL_YN,'N') = 'N' 
			   AND SL.ACTV_YN = 'Y'
			 WHERE (STRT_DATE_AUTH  IS NULL OR STRT_DATE_AUTH <= GETDATE()) 
			   AND (END_DATE_AUTH IS NULL  OR END_DATE_AUTH >= GETDATE()) 
			   AND EMP_ID = @V_USER_ID
	 	  GROUP BY EMP_ID, SL.LV_MGMT_ID 
	   ), CM_LEVEL
	   AS (
	   SELECT ID, LV_CD, LV_NM, LEAF_YN, ROW_NUMBER () OVER(PARTITION BY LV_TP_ID ORDER BY SEQ ) AS SEQ
	     FROM TB_CM_LEVEL_MGMT 	
		WHERE SALES_LV_YN = 'Y'	
		  AND DEL_YN ='N'		
	   )
		  SELECT M.EMP_ID		
			   , M.AUTH_TP_ID	AS ID   
			   , CL.LV_CD 		AS CD
			   , CL.LV_NM 		AS CD_NM
			   , CL.LEAF_YN 	AS LEAF_YN 
			   , MAX(TP)		AS MAP_TP
			   , 2 AS MAP_TP 
			   , SEQ 
		    FROM ITEM_ACCT_MAP M 
		   	     INNER JOIN 
		   	     CM_LEVEL CL 
		      ON M.AUTH_TP_ID = CL.ID	
		GROUP BY M.EMP_ID		
			   , M.AUTH_TP_ID	 
			   , CL.LV_CD 		 
			   , CL.LV_NM 		 
			   , CL.SEQ 		 
			   , CL.LEAF_YN 	
		ORDER BY CL.SEQ 
		;
		END
		
	ELSE 
		BEGIN

			 SELECT  '' AS ID
					  , '' AS CD
					  , '' AS CD_NM
					  , 'Y' AS LEAF_YN
					  , 10 AS MAP_TP
					  , 1 

--			 SELECT  LM.ID AS ID
--					  , LM.LV_CD AS CD
--					  , LM.LV_NM AS CD_NM
--					  , 'Y' AS LEAF_YN
--					  , 10 AS MAP_TP
--					  , LM.SEQ 
--				 FROM TB_CM_COMM_CONFIG CO
--					, TB_CM_LEVEL_MGMT LM
--				WHERE CO.CONF_GRP_CD =  'DP_LV_TP'
--				  AND CO.ACTV_YN = 'Y'
--				  AND CO.CONF_CD = 'S'
--				  AND CO.ID = LM.LV_TP_ID
--				  AND ISNULL(LM.DEL_YN,'N') = 'N'
--				  AND LM.ACTV_YN = 'Y'
--				  AND LM.SALES_LV_YN = 'Y' 
--				  AND LM.LEAF_YN = 'Y'
		END
	
	END

ELSE 
	BEGIN
		SELECT A.ID
			 , A.LV_CD AS CD
			 , A.LV_NM AS CD_NM 
			 , A.SEQ
		  FROM 
			  (
				SELECT   LM.ID 
					   , LM.LV_CD 
					   , LM.LV_NM 
					   , LM.SEQ
				 FROM TB_CM_COMM_CONFIG CO
					, TB_CM_LEVEL_MGMT LM
				WHERE CO.CONF_GRP_CD =  'DP_LV_TP'
				  AND CO.ACTV_YN = 'Y'
				  AND CO.CONF_CD = 'S'
				  AND CO.ID = LM.LV_TP_ID
				  AND ISNULL(LM.DEL_YN,'N') = 'N'
				  AND LM.ACTV_YN = 'Y'
				  AND LM.SALES_LV_YN = 'Y' 
				  --AND LM.LEAF_YN = 'Y'
				   -- 조 부장님 요청으로 자기 자신 이하 값 모두 조회하는 것에서 자신것만 조회하는 것으로 변경  <=
				  AND LM.SEQ IN (          
										SELECT  LM.SEQ
										  FROM  TB_CM_COMM_CONFIG CO
											  , TB_CM_LEVEL_MGMT LM
											  , TB_DP_SALES_LEVEL_MGMT SL
											  , TB_DP_SALES_AUTH_MAP SA 
										 WHERE 	CO.CONF_GRP_CD =  'DP_LV_TP'
											AND CO.ACTV_YN = 'Y'
											AND CO.CONF_CD = 'S'
											AND CO.ID = LM.LV_TP_ID
											AND ISNULL(LM.DEL_YN,'N') = 'N'
											AND LM.ACTV_YN = 'Y'
											AND LM.SALES_LV_YN = 'Y'
											AND LM.ID = SL.LV_MGMT_ID
											AND  SL.ID  = SA.SALES_LV_ID
											AND SA.EMP_ID = @V_USER_ID -- '6CE1034002E54DB6A1A88E568D082B5E'
											AND (SA.STRT_DATE_AUTH is null or  SA.STRT_DATE_AUTH <= GETDATE() )
											AND (SA.END_DATE_AUTH is null or SA.END_DATE_AUTH >= GETDATE() )
										) 
				UNION 
				-- default Sales Man 
				SELECT  LM.ID
					  , LM.LV_CD
					  , LM.LV_NM
					  , LM.SEQ
				 FROM TB_CM_COMM_CONFIG CO
					, TB_CM_LEVEL_MGMT LM
				WHERE CO.CONF_GRP_CD =  'DP_LV_TP'
				  AND CO.ACTV_YN = 'Y'
				  AND CO.CONF_CD = 'S'
				  AND CO.ID = LM.LV_TP_ID
				  AND ISNULL(LM.DEL_YN,'N') = 'N'
				  AND LM.ACTV_YN = 'Y'
				  AND LM.SALES_LV_YN = 'Y' 
				  AND LM.LEAF_YN = 'Y'
			   )  A
		ORDER BY A.SEQ 
		; 
	END
END





go

