/*****************************************************************************
Title : SP_UI_DP_16_S1_J
  - DP Dimension Data Management
 
설명 
  - OPENJSON : https://docs.microsoft.com/ko-kr/sql/t-sql/functions/openjson-transact-sql?view=sql-server-ver15

 
History (수정일자 / 수정자 / 수정내용)
- 2022.01.12 / kim sohee / json bulk insert draft
*****************************************************************************/
CREATE PROCEDURE [dbo].[SP_UI_DP_16_S1_J] (		
			@P_JSON				  NVARCHAR(MAX)
		   ,@P_DIM				  NVARCHAR(20)
		   ,@P_USER_ID            NVARCHAR(100)     = ''
		   ,@P_RT_ROLLBACK_FLAG   NVARCHAR(10)      = 'true'  OUTPUT
		   ,@P_RT_MSG             NVARCHAR(4000)    = ''	   OUTPUT	
)AS

	DECLARE @P_ERR_MSG NVARCHAR(4000) 
		  , @P_SQL	   NVARCHAR(MAX)
		  , @P_DATA_TYPE NVARCHAR(20)

BEGIN TRY
		SELECT TOP 1 @P_ERR_MSG = V.[key]	--R.key, R.value, V.key, V.value
		  FROM OPENJSON(@P_JSON) AS R
			   CROSS APPLY 
			   OPENJSON ( R.value) AS V
		 WHERE V.[value] IS NULL 
		   AND V.[key] IN ( 'ITEM_CD'	
		   				   ,'ACCOUNT_CD'
						  ) ;
	IF @P_ERR_MSG IS NOT NULL 
	BEGIN
		SET @P_ERR_MSG = 'Check Empty Value : '+@P_ERR_MSG		
		RAISERROR (@P_ERR_MSG,12, 1);
	END
	;
		  
	   SELECT @P_DATA_TYPE = CASE ATTR_01 
					WHEN 'double'	THEN 'DECIMAL(10,3)'
					WHEN 'integer'	THEN 'INT'
					WHEN 'string'	THEN 'NVARCHAR(100)'
					WHEN 'boolean'	THEN 'CHAR(1)'
					WHEN 'date'		THEN 'DATETIME'
				  ELSE NULL END 
	    FROM TB_CM_COMM_CONFIG
	   WHERE CONF_GRP_CD = 'DP_DMND_CUSTOM'
	     AND CONF_CD = @P_DIM 
		 ;
				SET @P_SQL = 'MERGE TB_DP_DIMENSION_DATA TGT '
				+'USING ( SELECT   A.ID	AS  ACCOUNT_ID '    
								+',I.ID	AS  ITEM_MST_ID '     
								+',M.DIM_VALUE '					
					   +'FROM OPENJSON(@P_JSON) '
					   +'WITH ( ITEM_CD		NVARCHAR(100) ''$.ITEM_CD'' '
							 +',ACCOUNT_CD	NVARCHAR(100) ''$.ACCOUNT_CD'' '
							 +',DIM_VALUE	'+@P_DATA_TYPE+' ''$.DIM_VALUE'' '
							 +',ROW_STATUS	NVARCHAR(100) ''$.ROW_STATUS'' '
							 +') M '
						     +'INNER JOIN '
							 +'TB_CM_ITEM_MST I '
						  +'ON M.ITEM_CD = I.ITEM_CD '
						     +'INNER JOIN '
							 +'TB_DP_ACCOUNT_MST A '
						  +'ON M.ACCOUNT_CD = A.ACCOUNT_CD '
					  +') SRC '
					+'ON TGT.ACCOUNT_ID = SRC.ACCOUNT_ID '
				   +'AND TGT.ITEM_MST_ID = SRC.ITEM_MST_ID '
				+'WHEN MATCHED THEN '
					 +'UPDATE '
					   +'SET   TGT.'+@P_DIM+' = SRC.DIM_VALUE '
--							+',TGT.MODIFY_BY = '''+@P_USER_ID+''' '     
--							+',TGT.MODIFY_DTTM = GETDATE() '      
				+'WHEN NOT MATCHED THEN '
					 +'INSERT (ID '         
							+',ACCOUNT_ID '
							+',ITEM_MST_ID '
							+','+@P_DIM+' '   
							+',CREATE_BY '
							+',CREATE_DTTM '
							+') '
					 +'VALUES ( '
							 +'REPLACE(NEWID(),''-'','''') '
							+',SRC.ACCOUNT_ID '   
							+',SRC.ITEM_MST_ID '  
							+',SRC.DIM_VALUE '   
							+','''+@P_USER_ID+''' '
							+',GETDATE() '           
 							+');' 
							;  
--				SELECT @P_SQL ;
				EXEC SP_EXECUTESQL @P_SQL, N'@P_JSON AS NVARCHAR(MAX)', @P_JSON


	BEGIN
	    SET @P_RT_MSG = 'MSG_0001'
	END
	    SET @P_RT_ROLLBACK_FLAG = 'true'
END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END
	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR
END CATCH

go

