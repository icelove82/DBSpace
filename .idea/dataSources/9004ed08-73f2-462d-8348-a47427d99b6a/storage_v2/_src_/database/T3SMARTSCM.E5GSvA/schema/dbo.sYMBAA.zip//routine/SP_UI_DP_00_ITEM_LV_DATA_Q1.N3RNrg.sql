/*****************************************************************************
Title : SP_DP_00_ITEM_LV_DATA_Q1
최초 작성자 : 민희영
최초 생성일 : 2017.06.23
 
설명 
 - DP 콤보(LEVEL Management) 조회 프로시저 
  
History (수정일자 / 수정자 / 수정내용)
- 2017.06.23 / 민희영 / 최초 작성
- 2019.04.25 / 김소희 / DEL_YN Null 처리 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_00_ITEM_LV_DATA_Q1] (@p_LEAF_TP NVARCHAR(30) = ''
                                                    , @p_TYPE   NVARCHAR(30) = ''
													, @p_LV_TP   NVARCHAR(30) = ''
								                 ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
DECLARE @V_LEAF_TP  NVARCHAR(30) = ''
	  , @V_TYPE		NVARCHAR(30) = ''
	  , @V_Lv_TP		NVARCHAR(30) = ''

SET @V_LEAF_TP = @p_LEAF_TP
SET @V_TYPE    = @p_TYPE
SET @V_Lv_TP    = @p_LV_TP

BEGIN

IF @V_LEAF_TP = 'LEAF'   
BEGIN 
    SET @V_LEAF_TP = 'Y' ;
END

IF @p_TYPE like '%AD%'
BEGIN
 SELECT @V_Lv_TP = CONF_CD from TB_CM_COMM_CONFIG where CONF_GRP_CD = 'DP_LV_TP' and conf_cd like @V_Lv_TP+'%' and ATTR_01 like '%'+@p_TYPE ;
END 


SELECT * 
FROM ( 
		SELECT  '' AS ID 
			  , UPPER(@V_TYPE)  AS CD
			  , UPPER(@V_TYPE)  AS CD_NM
			  , 0 AS LV_SEQ
			  , 0 AS SEQ
		WHERE UPPER(@V_TYPE) = 'ALL'
		UNION ALL 
		SELECT IL.ID
			  ,IL.ITEM_LV_CD AS CD 
			  ,IL.ITEM_LV_NM AS CD_NM 
			  ,LM.SEQ AS LV_SEQ
			  ,IL.SEQ
		  FROM TB_CM_CONFIGURATION A
			 , TB_CM_COMM_CONFIG B
			 , TB_CM_LEVEL_MGMT  LM
			 , TB_CM_ITEM_LEVEL_MGMT  IL
		  WHERE A.MODULE_CD = 'DP'
			AND A.ID = B.CONF_ID
			AND B.CONF_GRP_CD = 'DP_LV_TP'
			AND B.CONF_CD = @V_Lv_TP
			AND B.ID = LM.LV_TP_ID  -- S/C/I
			AND ISNULL(LM.DEL_YN,'N') = 'N'
			AND LM.ACTV_YN = 'Y'
			AND LM.ID = IL.LV_MGMT_ID 
			AND LM.LV_LEAF_YN  LIKE '%' + @V_LEAF_TP +'%'	
			AND ISNULL(IL.DEL_YN,'N') = 'N'
			AND IL.ACTV_YN = 'Y'
     )  A
ORDER BY A.LV_SEQ, A.SEQ
 ;

END







go

