CREATE PROCEDURE [dbo].[SP_UI_DP_36_S1] (
					 @P_ID				CHAR(32)		= ''
					,@P_MODULE_ID		CHAR(32)		= ''
					,@P_PLAN_TP_ID		CHAR(32)		= ''
					,@P_POLICY_ID		CHAR(32)		= ''
					,@P_POLICY_VAL		NVARCHAR(100)	= ''
					,@P_DESCRIP			NVARCHAR(100)	= ''
					,@P_USER_ID			NVARCHAR(100)	= ''
 ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'  OUTPUT
 ,@P_RT_MSG            NVARCHAR(4000) = ''		OUTPUT
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''


	   

BEGIN TRY
/*
		PLAN POLICY 조회 프로시저
*/

/* MESSAGE VALIDATION	*/
	SELECT @P_ERR_STATUS = COUNT(*)
	  FROM TB_DP_PLAN_POLICY
	WHERE 1=1
	  AND MODULE_ID = @P_MODULE_ID
	  AND PLAN_TP_ID = @P_PLAN_TP_ID
	  AND POLICY_ID = @P_POLICY_ID   
	  AND ID != @P_ID
	IF(@P_ERR_STATUS > 0)
		BEGIN
			SET @P_ERR_MSG = 'MSG_0013' 
			RAISERROR (@P_ERR_MSG,12, 1);
	    END

				MERGE TB_DP_PLAN_POLICY TGT
				USING ( 
						SELECT
						 @P_ID				AS ID			
						,@P_MODULE_ID		AS MODULE_ID	
						,@P_PLAN_TP_ID		AS PLAN_TP_ID	
						,@P_POLICY_ID		AS POLICY_ID	
						,@P_POLICY_VAL		AS POLICY_VAL	
						,@P_DESCRIP			AS DESCRIP		
						,@P_USER_ID			AS USER_ID	
					  ) SRC
				ON TGT.ID = SRC.ID
				WHEN MATCHED THEN
					 UPDATE 
					   SET   		
							 TGT.MODULE_ID	 = SRC.MODULE_ID	
							,TGT.PLAN_TP_ID	 = SRC.PLAN_TP_ID	
							,TGT.POLICY_ID	 = SRC.POLICY_ID	
							,TGT.POLICY_VAL	 = SRC.POLICY_VAL	
							,TGT.DESCRIP	 = SRC.DESCRIP			
							,TGT.MODIFY_BY	 = SRC.USER_ID	
							,TGT.MODIFY_DTTM = GETDATE()		
				WHEN NOT MATCHED THEN 
					 INSERT (
								 ID			
								,MODULE_ID	
								,PLAN_TP_ID	
								,POLICY_ID	
								,POLICY_VAL	
								,DESCRIP		
								,CREATE_BY	
								,CREATE_DTTM	
								,MODIFY_BY	
								,MODIFY_DTTM								 
							) 
					 VALUES (
							 REPLACE(NEWID(),'-','')			
							,SRC.MODULE_ID	
							,SRC.PLAN_TP_ID	
							,SRC.POLICY_ID	
							,SRC.POLICY_VAL	
							,SRC.DESCRIP		
							,SRC.USER_ID 
							,GETDATE()  
							,NULL
							,NULL          
 							) 
							;    

/*********************************************************************************************************
	Policy CD : PB
**********************************************************************************************************/
	IF EXISTS (
			SELECT CONF_CD 
			  FROM TB_CM_COMM_CONFIG
			 WHERE CONF_CD = 'PB'
			   AND CONF_GRP_CD = 'DP_POLICY'
			   AND ID = @P_POLICY_ID
			)
			BEGIN
				UPDATE TB_CM_COMM_CONFIG
				  SET ATTR_01 = NULLIF(@P_POLICY_VAL,'')
				    , PRIORT = (SELECT PRIORT FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_BUKT_TP' AND CONF_CD = @P_POLICY_VAL)
			    WHERE CONF_GRP_CD = 'DP_BUKT_TP'
				  AND CONF_CD = 'PB'
				;
			END
			;
/**********************************************************************************************************
	Policy CD : B
		가변 아닐때			(		가변일때		)
		bucket	actv buc	( bucket	actv bucket	)
		D		D-PW-M		( D			D-PW-PB-M	)
		W		W-M			( W			W-PB-M		)
		PW		PW-M		( PW		PW-PB-M		)
		M		M-Q			( M			M-PB-Q		)
		Q		Q-Y			( Q			Q-PB-Y		)
**********************************************************************************************************/
IF EXISTS (
			SELECT CONF_CD 
			  FROM TB_CM_COMM_CONFIG
			 WHERE CONF_CD = 'B'
			   AND CONF_GRP_CD = 'DP_POLICY'
			   AND ID = @P_POLICY_ID
		  )
		  BEGIN
				UPDATE TB_CM_COMM_CONFIG  
				  SET ACTV_YN = 'N'
				WHERE CONF_GRP_CD = 'DP_BUKT_TP'
				;
				MERGE TB_CM_COMM_CONFIG TGT
				USING (
					SELECT 'D' AS MAIN
						 , 'D' AS SUB
					UNION
					SELECT 'D', 'PW'
					UNION
					SELECT 'D', 'M'		  
					UNION
					SELECT 'W', 'W'
					UNION
					SELECT 'W', 'M'
					UNION
					SELECT 'PW', 'PW'
					UNION
					SELECT 'PW', 'M'
					UNION
					SELECT 'M', 'M'
					UNION
					SELECT 'M', 'Q'
					UNION
					SELECT 'Q', 'Q'
					UNION
					SELECT 'Q', 'Y'
					UNION
					SELECT 'Y', 'Y'
				) SRC 
				ON ( TGT.CONF_GRP_CD = 'DP_BUKT_TP'
			   AND SRC.MAIN = @P_POLICY_VAL
			   AND TGT.CONF_CD = SRC.SUB 
				   )
				WHEN MATCHED THEN
				UPDATE SET ACTV_YN = 'Y'
				;
		  END
		  ;


	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY

BEGIN CATCH
     
	   SET @P_ERR_MSG = ERROR_MESSAGE()
	   SET @P_RT_ROLLBACK_FLAG = 'false'
	   SET @P_RT_MSG = @P_ERR_MSG


END CATCH

go

