/*****************************************************************************
Title : [SP_UI_DP_35_VALID_Q6_U_AUTH] 
최초 작성자 : 이고은
최초 생성일 : 2017.08.30
 
설명 
 - DP VALIDATION (U_AUTHORITY)-- ALL
 
History (수정일자 / 수정자 / 수정내용)
-  2017.08.30 / 이고은 / 최초 작성
- 2022.08.04 / kim sohee / add level type
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_35_VALID_Q6_U_AUTH] 
--(	
--	 @p_EMP_ID		NVARCHAR(100) = ''
--	,@p_AUTH_TP_ID	NVARCHAR(50) = ''
--) 
AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN


	SELECT	A.ID, A.SALES_LV_CD, A.SALES_LV_NM , B.LV_CD, B.LV_NM 
	FROM	TB_DP_SALES_LEVEL_MGMT			A 
			INNER JOIN TB_CM_LEVEL_MGMT	B  ON A.LV_MGMT_ID = B.ID AND B.ACTV_YN = 'Y'
			INNER JOIN TB_CM_COMM_CONFIG C ON B.LV_TP_ID = C.ID 
	WHERE	A.ACTV_YN = 'Y' AND A.VIRTUAL_YN = 'N'
	AND		A.LV_MGMT_ID IN ( SELECT ID FROM TB_CM_LEVEL_MGMT  WHERE ACTV_YN = 'Y') 
	AND		ISNULL(A.PARENT_SALES_LV_ID, '') IN	(
												SELECT ID 
												FROM TB_DP_SALES_LEVEL_MGMT 
												WHERE ACTV_YN = 'Y'
												)
	AND		NOT EXISTS	(
						SELECT 'X'
						FROM TB_DP_SALES_AUTH_MAP X 
						WHERE A.ID = X.SALES_LV_ID
						)
	AND C.CONF_CD = 'S'
END








go

