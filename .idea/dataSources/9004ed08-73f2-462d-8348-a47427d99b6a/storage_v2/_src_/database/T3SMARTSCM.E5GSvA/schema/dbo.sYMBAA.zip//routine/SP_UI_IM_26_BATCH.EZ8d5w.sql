CREATE PROCEDURE [dbo].[SP_UI_IM_26_BATCH] (
	 @P_APPLY_POINT_CD		NVARCHAR(100)
	,@P_OVERWRITE_DATA_YN	CHAR(1)
	,@P_USER_ID				NVARCHAR (100)
	,@P_RT_ROLLBACK_FLAG	NVARCHAR(10) = 'true' OUTPUT
	,@P_RT_MSG				NVARCHAR(4000) = ''   OUTPUT
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_MSG NVARCHAR(4000)=''

DECLARE @V_PLAN_START_DATE		DATETIME,
		@V_PLAN_END_DATE		DATETIME,
		@V_TIME_BUCKET			VARCHAR(30),
		@V_DP_VER_ID			VARCHAR(100),
		@V_OPERT_BASE_TP_ID		CHAR(32)

BEGIN TRY

	SET @P_ERR_MSG = 'MSG_5156'
	IF NOT EXISTS 
	(
	SELECT	1
	FROM	TB_IM_INV_POLICY_MST
	)
	BEGIN
		RAISERROR (@P_ERR_MSG, 12, 1);
	END

	SELECT  @V_PLAN_START_DATE = A.STRT_DATE, 
			@V_PLAN_END_DATE = A.END_DATE, 
			@V_TIME_BUCKET = B.UOM_CD
	FROM    TB_CM_HORIZON_TIME_BUCKET A
			INNER JOIN TB_CM_UOM B
			ON B.ID = A.TIME_UOM_ID
			INNER JOIN TB_CM_PLAN_SNRIO_MGMT_MST C
			ON C.ID = A.PLAN_SNRIO_MGMT_MST_ID
			INNER JOIN TB_AD_COMN_CODE D
			ON D.ID = C.MODULE_ID
	WHERE   1=1
	AND		D.COMN_CD = 'IM'

	SELECT	TOP 1
			@V_DP_VER_ID = A.VER_ID
	FROM	TB_DP_CONTROL_BOARD_VER_MST A
			INNER JOIN TB_DP_CONTROL_BOARD_VER_DTL B
			ON A.ID = B.CONBD_VER_MST_ID
	WHERE	1=1
	AND		B.WORK_TP_ID   = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_CD = 'CL' AND CONF_GRP_CD = 'DP_WK_TP') 
	AND		B.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
	AND		A.PLAN_TP_ID   = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND DEFAT_VAL = 'Y')
	ORDER BY A.CREATE_DTTM DESC

	SELECT	@V_OPERT_BASE_TP_ID = A.OPERT_BASE_TP_ID
	FROM	(
			SELECT	CASE WHEN @V_TIME_BUCKET = 'DAY'   AND A.COMN_CD = 'DOS' THEN A.ID
						 WHEN @V_TIME_BUCKET = 'WEEK'  AND A.COMN_CD = 'WOS' THEN A.ID
						 WHEN @V_TIME_BUCKET = 'MONTH' AND A.COMN_CD = 'MOS' THEN A.ID
						 ELSE NULL
					END AS OPERT_BASE_TP_ID
			FROM	TB_AD_COMN_CODE A
					INNER JOIN TB_AD_COMN_GRP B
					ON B.ID = A.SRC_ID
			WHERE	B.GRP_CD = 'INVENTORY_SUPPLY_DATE_TYPE'
			) A
	WHERE	A.OPERT_BASE_TP_ID IS NOT NULL

	/***************************************************************************************************************************************************************************
	1. 재고수준
	 - Warehouse Stock : 출하 실적 구간 내 데이터 합계
	 - In-Transit Stock : 출하 실적 구간 내 데이터 합계
	 - 출하실적 구간 : Configuration 생산 입고품 재고일수 계산 출하실적 산출 구간 참조
	 - 일 평균 출하 실적 : 출하실적 데이터의 공급거점 관점에서 출하실적 구간 만큼의 출하수량에 대한 일 평균을 구함
	 - 평균재고 : (기초재고 + 기말재고) / 2
	 - 재고일수 : 평균재고 / 일 평균 출하 실적
	***************************************************************************************************************************************************************************/
	CREATE TABLE #TEMP_WAREHOUSE_STOCK (
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		QTY							DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_INTRANSIT_STOCK (
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		QTY							DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_DAY_AVG_ACTUAL_SHIPMENT (
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		SHPP_ACTUAL_PERIOD			INT,
		QTY							DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_BOH (
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		QTY							DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_EOH (
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		QTY							DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_STOCK_INFO (
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		SHPP_ACTUAL_PERIOD			VARCHAR(100),
		AVG_SHPP_ACTUAL_QTY			DECIMAL(20,3),
		AVG_INV_QTY					DECIMAL(20,3),
		INVTURN						DECIMAL(20,3)
	)

	INSERT INTO #TEMP_WAREHOUSE_STOCK
	(
		LOCAT_ITEM_ID,
		QTY
	)
	SELECT	A.LOCAT_ITEM_ID, 
			SUM(ISNULL(B.QTY, 0)) AS QTY
	FROM	TB_CM_WAREHOUSE_STOCK_MST A
			INNER JOIN TB_CM_WAREHOUSE_STOCK_QTY B
			ON A.ID = B.WAREHOUSE_INV_MST_ID
			INNER JOIN TB_IM_STOCK_QTY_TYPE C
			ON C.ID = B.INV_QTY_TP_ID
	WHERE	1=1
	AND		A.CUTOFF_DATE = (SELECT MAX(CUTOFF_DATE) FROM TB_CM_WAREHOUSE_STOCK_MST)
	AND		ISNULL(A.ACTV_YN, 'N') = 'Y'
	AND		ISNULL(B.ACTV_YN, 'N') = 'Y'
	AND		ISNULL(C.ACTV_YN, 'N') = 'Y'
	AND		ISNULL(C.PLAN_YN, 'N') = 'Y'
	GROUP	BY A.LOCAT_ITEM_ID
	
	INSERT INTO #TEMP_INTRANSIT_STOCK
	(
		LOCAT_ITEM_ID,
		QTY
	)
	SELECT	A.TO_LOCAT_ITEM_ID AS LOCAT_ITEM_ID, 
			SUM(ISNULL(B.QTY, 0)) AS QTY
	FROM	TB_CM_INTRANSIT_STOCK_MST A
			INNER JOIN TB_CM_INTRANSIT_STOCK_QTY B
			ON A.ID = B.INTRANSIT_INV_MST_ID
			INNER JOIN TB_IM_STOCK_QTY_TYPE C
			ON C.ID = B.INV_QTY_TP_ID
	WHERE	1=1
	AND		A.CUTOFF_DATE = (SELECT MAX(CUTOFF_DATE) FROM TB_CM_INTRANSIT_STOCK_MST)
	AND		ISNULL(A.ACTV_YN, 'N') = 'Y'
	AND		ISNULL(B.ACTV_YN, 'N') = 'Y'
	AND		ISNULL(C.ACTV_YN, 'N') = 'Y'
	AND		ISNULL(C.PLAN_YN, 'N') = 'Y'
	GROUP	BY A.TO_LOCAT_ITEM_ID

	INSERT INTO #TEMP_DAY_AVG_ACTUAL_SHIPMENT
	(
		LOCAT_ITEM_ID,
		SHPP_ACTUAL_PERIOD,
		QTY
	)
	SELECT	A.SUPPLY_LOCAT_ITEM_ID, 
			A.SHPP_ACTUAL_PERIOD,
			SUM(A.QTY) / MIN(A.DAY_CNT) AS QTY
	FROM	(
			SELECT	A.SUPPLY_LOCAT_ITEM_ID,
					D.SHPP_ACTUAL_PERIOD,
					D.DAY_CNT,
					A.ATD,
					SUM(SHPP_QTY) AS QTY
			FROM	TB_CM_ACTUAL_SHIPMENT A
					INNER JOIN TB_CM_SITE_ITEM B
					ON B.ID = A.SUPPLY_LOCAT_ITEM_ID
					INNER JOIN TB_CM_LOC_MGMT C
					ON C.ID = B.LOCAT_MGMT_ID
					LEFT OUTER JOIN 
					(
					SELECT	LOCAT_ID, START_DATE, END_DATE,
							ABS(A.ACTUAL_PERIOD) AS SHPP_ACTUAL_PERIOD,
							(SELECT VAL FROM DBO.FN_G_BUCKET_CNT('DAY', A.START_DATE, A.END_DATE)) AS DAY_CNT
					FROM	(
							SELECT	LOCAT_ID, A.ACTUAL_PERIOD, B.UOM_NM,
									(SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.ACTUAL_PERIOD, 'START', B.UOM_CD)) AS START_DATE,
									(SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.ACTUAL_PERIOD, 'END', B.UOM_CD)) AS END_DATE
							FROM	TB_IM_VARIABILITY_ACT_PRIOD A
									INNER JOIN TB_CM_UOM B
									ON B.ID = A.UOM_ID
							WHERE	CATAGY_VAL = 'FINAL_PRODUCT_GR_ITEM_INVTURN'
							AND		ISNULL(A.ACTV_YN, 'N') = 'Y'
							) A
					) D
					ON D.LOCAT_ID = C.LOCAT_ID
			WHERE	1=1
			AND		ISNULL(B.ACTV_YN, 'N') = 'Y'
			AND		ISNULL(C.ACTV_YN, 'N') = 'Y'
			AND		A.ATD BETWEEN D.START_DATE AND D.END_DATE
			GROUP	BY A.SUPPLY_LOCAT_ITEM_ID, D.SHPP_ACTUAL_PERIOD, D.DAY_CNT, A.ATD
			) A
	GROUP	BY A.SUPPLY_LOCAT_ITEM_ID, A.SHPP_ACTUAL_PERIOD

	INSERT INTO #TEMP_BOH
	(
		LOCAT_ITEM_ID,
		QTY
	)
	SELECT	A.LOCAT_ITEM_ID, 
			SUM(A.QTY) AS QTY
	FROM	(
			SELECT	B.LOCAT_ITEM_ID, 
					E.LOCAT_ID,
					B.CUTOFF_DATE,
					SUM(ISNULL(C.QTY, 0)) AS QTY
			FROM	TB_CM_SITE_ITEM A
					INNER JOIN TB_CM_WAREHOUSE_STOCK_MST B
					ON A.ID = B.LOCAT_ITEM_ID
					INNER JOIN TB_CM_WAREHOUSE_STOCK_QTY C
					ON B.ID = C.WAREHOUSE_INV_MST_ID
					INNER JOIN TB_IM_STOCK_QTY_TYPE D
					ON D.ID = C.INV_QTY_TP_ID
					INNER JOIN TB_CM_LOC_MGMT E
					ON E.ID = A.LOCAT_MGMT_ID
			WHERE	1=1
			AND		ISNULL(D.ACTV_YN, 'N') = 'Y'
			AND		ISNULL(D.PLAN_YN, 'N') = 'Y'
			GROUP	BY B.LOCAT_ITEM_ID, E.LOCAT_ID, B.CUTOFF_DATE
			) A,
			(
			SELECT	B.LOCAT_ID, MIN(A.CUTOFF_DATE) AS CUTOFF_DATE
			FROM	TB_CM_WAREHOUSE_STOCK_MST A,
					(
					SELECT	A.LOCAT_ID, 
							--CONVERT(DATETIME, '20180910', 120) AS START_DATE
							(SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.ACTUAL_PERIOD, 'START', B.UOM_CD)) AS START_DATE
					FROM	TB_IM_VARIABILITY_ACT_PRIOD A
							INNER JOIN TB_CM_UOM B
							ON B.ID = A.UOM_ID
					WHERE	CATAGY_VAL = 'FINAL_PRODUCT_GR_ITEM_INVTURN'
					) B
			WHERE	A.CUTOFF_DATE = B.START_DATE
			GROUP	BY B.LOCAT_ID
			) B
	WHERE	1=1
	AND		A.LOCAT_ID = B.LOCAT_ID
	AND		A.CUTOFF_DATE = B.CUTOFF_DATE
	GROUP	BY A.LOCAT_ITEM_ID

	INSERT INTO #TEMP_EOH
	(
		LOCAT_ITEM_ID,
		QTY
	)
	SELECT	A.LOCAT_ITEM_ID, 
			SUM(A.QTY) AS QTY
	FROM	(
			SELECT	B.LOCAT_ITEM_ID, 
					E.LOCAT_ID,
					B.CUTOFF_DATE,
					SUM(ISNULL(C.QTY, 0)) AS QTY
			FROM	TB_CM_SITE_ITEM A
					INNER JOIN TB_CM_WAREHOUSE_STOCK_MST B
					ON A.ID = B.LOCAT_ITEM_ID
					INNER JOIN TB_CM_WAREHOUSE_STOCK_QTY C
					ON B.ID = C.WAREHOUSE_INV_MST_ID
					INNER JOIN TB_IM_STOCK_QTY_TYPE D
					ON D.ID = C.INV_QTY_TP_ID
					INNER JOIN TB_CM_LOC_MGMT E
					ON E.ID = A.LOCAT_MGMT_ID
			WHERE	1=1
			AND		ISNULL(D.ACTV_YN, 'N') = 'Y'
			AND		ISNULL(D.PLAN_YN, 'N') = 'Y'
			GROUP	BY B.LOCAT_ITEM_ID, E.LOCAT_ID, B.CUTOFF_DATE
			) A,
			(
			SELECT	B.LOCAT_ID, MIN(A.CUTOFF_DATE) AS CUTOFF_DATE
			FROM	TB_CM_WAREHOUSE_STOCK_MST A,
					(
					SELECT	A.LOCAT_ID, 
							--DATEADD(DD, 1, CONVERT(DATETIME, '20180909', 120)) AS END_DATE
							DATEADD(DD, 1, (SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.ACTUAL_PERIOD, 'END', B.UOM_CD))) AS END_DATE
					FROM	TB_IM_VARIABILITY_ACT_PRIOD A
							INNER JOIN TB_CM_UOM B
							ON B.ID = A.UOM_ID
					WHERE	CATAGY_VAL = 'FINAL_PRODUCT_GR_ITEM_INVTURN'
					) B
			WHERE	A.CUTOFF_DATE = B.END_DATE
			GROUP	BY B.LOCAT_ID
			) B
	WHERE	1=1
	AND		A.LOCAT_ID = B.LOCAT_ID
	AND		A.CUTOFF_DATE = B.CUTOFF_DATE
	GROUP	BY A.LOCAT_ITEM_ID

	INSERT INTO #TEMP_STOCK_INFO
	(
		LOCAT_ITEM_ID,
		SHPP_ACTUAL_PERIOD,
		AVG_SHPP_ACTUAL_QTY,
		AVG_INV_QTY,
		INVTURN
	)
	SELECT	A.LOCAT_ITEM_ID, 
			A.SHPP_ACTUAL_PERIOD,
			ISNULL(A.QTY, 0) AS AVG_SHPP_ACTUAL_QTY,
			(ISNULL(B.QTY, 0) + ISNULL(C.QTY, 0)) / 2 AS AVG_INV_QTY,
			CASE WHEN ISNULL(A.QTY, 0) = 0 THEN 0
				 ELSE ROUND(((ISNULL(B.QTY, 0) + ISNULL(C.QTY, 0)) / 2) / ISNULL(A.QTY, 0), 3) 
			END AS INVTURN
	FROM	#TEMP_DAY_AVG_ACTUAL_SHIPMENT A
			LEFT OUTER JOIN #TEMP_BOH B
			ON A.LOCAT_ITEM_ID = B.LOCAT_ITEM_ID
			LEFT OUTER JOIN #TEMP_EOH C
			ON A.LOCAT_ITEM_ID = C.LOCAT_ITEM_ID

	/***************************************************************************************************************************************************************************
	2. 운영목표
	 - 보충리드타임 : (체크된 경우) 공급리드타임 + (체크된 경우) 발주주기
	   * 공급리드타임 : 공급변동성 분석 데이터 참조
	   * 발주주기     : 발주주기 Daily Calendar : 7 / 체크된 요일 개수
				        발주주기 Monthly Calendar : 31 / 체크된 일자 개수
	 - 운영목표 : 보충 리드타임 + 운영수준
	***************************************************************************************************************************************************************************/
	CREATE TABLE #TEMP_PO_CYCL_VAL (
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		PO_CYCL_VAL					DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_OPERT_TARGET (
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		SUPPLY_LEADTIME				DECIMAL(20,3),
		PO_CYCL_VAL					DECIMAL(20,3),
		REPLSH_LEADTIME				DECIMAL(20,3),
		OPERT_TARGET_VAL			DECIMAL(20,3)
	)

	INSERT INTO #TEMP_PO_CYCL_VAL
	(
		LOCAT_ITEM_ID,
		PO_CYCL_VAL
	)
	SELECT	A.LOCAT_ITEM_ID,
			CASE WHEN SUM(CASE WHEN ISNULL(G.ACTV_YN,'N') = 'Y' THEN 1 ELSE 0 END) = 0 THEN 0
				 ELSE CAST(COUNT(*) AS DECIMAL(20,3)) / SUM(CASE WHEN ISNULL(G.ACTV_YN,'N') = 'Y' THEN 1 ELSE 0 END)
			END	 PO_CYCL_VAL
	FROM	TB_IM_SITE_ITEM_SEG_SUMM A
			INNER JOIN TB_CM_SITE_ITEM B
			ON B.ID = A.LOCAT_ITEM_ID
			INNER JOIN TB_CM_LOC_MGMT C
			ON C.ID = B.LOCAT_MGMT_ID
			INNER JOIN TB_IM_INV_POLICY_MST D
			ON C.LOCAT_ID = D.LOCAT_ID
			INNER JOIN TB_IM_PO_CALENDAR E
			ON E.ID = D.PO_CYCL_CALENDAR_ID
			INNER JOIN TB_AD_COMN_CODE F
			ON F.ID = E.PO_CYCL_TP_ID
			LEFT OUTER JOIN TB_IM_PO_MONTHLY_SCH G
			ON E.ID = G.PO_CYCL_CALENDAR_ID
	WHERE	F.COMN_CD = 'MONTHLY'
	AND		ISNULL(A.VAL_01, '') = IIF(D.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(D.VAL_01, ''))
	AND		ISNULL(A.VAL_02, '') = IIF(D.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(D.VAL_02, ''))
	GROUP   BY A.LOCAT_ITEM_ID
	UNION ALL
	SELECT	A.LOCAT_ITEM_ID,
			CASE WHEN SUM(CASE WHEN ISNULL(G.CHECK_YN,'N') = 'Y' THEN 1 ELSE 0 END) = 0 THEN 0
				 ELSE CAST(COUNT(*) AS DECIMAL(20,3)) / SUM(CASE WHEN ISNULL(G.CHECK_YN,'N') = 'Y' THEN 1 ELSE 0 END)
			END  PO_CYCL_VAL
	FROM	TB_IM_SITE_ITEM_SEG_SUMM A
			INNER JOIN TB_CM_SITE_ITEM B
			ON B.ID = A.LOCAT_ITEM_ID
			INNER JOIN TB_CM_LOC_MGMT C
			ON C.ID = B.LOCAT_MGMT_ID
			INNER JOIN TB_IM_INV_POLICY_MST D
			ON C.LOCAT_ID = D.LOCAT_ID
			INNER JOIN TB_IM_PO_CALENDAR E
			ON E.ID = D.PO_CYCL_CALENDAR_ID
			INNER JOIN TB_AD_COMN_CODE F
			ON F.ID = E.PO_CYCL_TP_ID
			LEFT OUTER JOIN
			(
			SELECT	A.PO_CYCL_CALENDAR_ID,
					A.WK_CD,
					A.CHECK_YN
			FROM	TB_IM_PO_DAILY_SCH A
					UNPIVOT (CHECK_YN FOR WK_CD IN (MON_YN, 
													TUE_YN, 
													WED_YN, 
													THU_YN, 
													FRI_YN, 
													SAT_YN, 
													SUN_YN)
        					) A
			) G
			ON E.ID = G.PO_CYCL_CALENDAR_ID
	WHERE	F.COMN_CD = 'DAILY'
	AND		ISNULL(A.VAL_01, '') = IIF(D.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(D.VAL_01, ''))
	AND		ISNULL(A.VAL_02, '') = IIF(D.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(D.VAL_02, ''))
	GROUP	BY A.LOCAT_ITEM_ID

	INSERT INTO #TEMP_OPERT_TARGET
	(
		LOCAT_ITEM_ID,
		SUPPLY_LEADTIME,
		PO_CYCL_VAL,
		REPLSH_LEADTIME,
		OPERT_TARGET_VAL
	)
	SELECT	A.LOCAT_ITEM_ID,
			A.SUPPLY_LEADTIME_AVG,
			A.PO_CYCL_VAL,
			IIF(A.REPLSH_LEADTIME = 0, 1, A.REPLSH_LEADTIME) AS REPLSH_LEADTIME,
			IIF(A.REPLSH_LEADTIME = 0, 1, A.REPLSH_LEADTIME) + ISNULL(A.OPERT_LV_VAL, 0) AS OPERT_TARGET_VAL
	FROM	(
			SELECT	A.LOCAT_ITEM_ID,
					E.SUPPLY_LEADTIME_AVG,
					F.PO_CYCL_VAL,
					D.OPERT_LV_VAL,
					(CASE WHEN D.SUPPLY_LEADTIME_YN = 'Y' THEN ISNULL(E.SUPPLY_LEADTIME_AVG, 0) ELSE 0 END) + (CASE WHEN D.PO_CYCL_YN = 'Y' THEN ISNULL(F.PO_CYCL_VAL, 0) ELSE 0 END) AS REPLSH_LEADTIME
			FROM	TB_IM_SITE_ITEM_SEG_SUMM A
					INNER JOIN TB_CM_SITE_ITEM B
					ON B.ID = A.LOCAT_ITEM_ID
					INNER JOIN TB_CM_LOC_MGMT C
					ON C.ID = B.LOCAT_MGMT_ID
					INNER JOIN TB_IM_INV_POLICY_MST D
					ON C.LOCAT_ID = D.LOCAT_ID
					LEFT OUTER JOIN TB_IM_SPPLY_VARAN_ANLYS_MST E
					ON E.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_PO_CYCL_VAL F
					ON F.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			WHERE	1=1
			AND		ISNULL(A.VAL_01, '') = IIF(D.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(D.VAL_01, ''))
			AND		ISNULL(A.VAL_02, '') = IIF(D.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(D.VAL_02, ''))
			) A

	/***************************************************************************************************************************************************************************
	3. 수요율 계산
	 Plan Start : 20190101
	 Plan End   : 20191231
	 실적 고려 구간 : 12 Month
	 운영 목표      :  2 Month

	 Actual (ALL) : Configuration '수요율 산출 출하실적 구간'에 정의된 과거 출하실적 전체의 타임버켓 기준 평균 출하실적 수량을 산출 
	 Actual (YoY) : 전년 동기 대비 구간에서 운영 목표 (L) 기간 만큼의 일 평균 출하실적 수량을 산출
	 Forecast (ALL) : 최신 Demand Overview에 존재하는 Demand 전체 기준의 일 평균 판매계획 수량을 산출
	 Forecast (Target) : 최신 Demand Overview의 각 Time Bucket 시작 시점 기준으로 운영 목표 (L) 기간 만큼의 Demand의 일 평균 판매계획 수량을 산출


													              2019                                                        2020
														            01   02   03   04   05   06   07   08   09   10   11   12   01
															         |----|----|----|----|----|----|----|----|----|----|----|----|
															         |---------------------  Plan Horizon   ---------------------|

	  2018                                                        2019                                                        2020
		01   02   03   04   05   06   07   08   09   10   11   12   01   02   03   04   05   06   07   08   09   10   11   12   01
		 |----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|
		 |-----------------------   Actual (ALL)   ------------------|--------------------   Forecast (ALL)   -------------------|

	  2018											              2019                                                        2020
		01   02   03   04   05   06   07   08   09   10   11   12   01   02   03   04   05   06   07   08   09   10   11   12   01
		 |----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|
         |-----------------------   Actual (YoY)  ------------------------|                                                      |
		 |                                                           |                                                           |
		01                                                           |                                                           |
		 |---------|                                                 |                                                           |
		 |   02                                                      |                                                           |
		 |    |---------|                                            |                                                           |
		 |        03                                                 |                                                           |
         |         |---------|                                       |                                                           |
         |             04                                            |                                                           |
         |              |---------|                                  |                                                           |
         |                  05                                       |                                                           |
         |                   |---------|                             |                                                           |
         |                       06                                  |                                                           |
         |                        |---------|                        |                                                           |
         |                            07                             |                                                           |
         |                             |---------|                   |                                                           |
         |                                 08                        |                                                           |
         |                                  |---------|              |                                                           |
         |                                      09                   |                                                           |
         |                                       |---------|         |                                                           |
         |                                           10              |                                                           |
         |                                            |---------     |                                                           |
         |                                                11         |                                                           |
         |                                                 |---------|                                                           |
         |                                                     12	 |                                                           |
         |                                                      |---------|                                                      |

	  2018											              2019                                                        2020
		01   02   03   04   05   06   07   08   09   10   11   12   01   02   03   04   05   06   07   08   09   10   11   12   01   02
		 |----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|
		                                                             |--------------------   Forecast (Target)  ----------------------|
															         |                                                           |
															         01                                                          |
															         |---------|                                                 |
															         |   02                                                      |
															         |    |---------|                                            |
															         |        03                                                 |
															         |         |---------|                                       |
															         |             04                                            |
															         |              |---------|                                  |
															         |                  05                                       |
															         |                   |---------|                             |
															         |                       06                                  |
															         |                        |---------|                        |
															         |                            07                             |
															         |                             |---------|                   |
															         |                                 08                        |
															         |                                  |---------|              |
															         |                                      09                   |
															         |                                       |---------|         |
															         |                                           10              |
															         |                                            |---------     |
															         |                                                11         |
															         |                                                 |---------|
															         |                                                     12    |
															         |                                                      |---------|
                                                      
                                                      
	***************************************************************************************************************************************************************************/
	CREATE TABLE #TEMP_DMND_CAL_METHOD_MAP (
		LOCAT_ITEM_ID			CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		CAL_MTD_CD				VARCHAR(100)
	)

	CREATE TABLE #TEMP_DMND_RATE_ACTUAL_ALL (
		LOCAT_ITEM_ID			CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		QTY						DECIMAL(20,3),
		MIN_QTY					DECIMAL(20,3),
		MAX_QTY					DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_DMND_RATE_ACTUAL_YOY (
		LOCAT_ITEM_ID			CHAR(32) COLLATE DATABASE_DEFAULT,
		STRT_DATE				DATETIME,
		END_DATE				DATETIME,
		QTY						DECIMAL(20,3),
		CONSTRAINT PK_TEMP_DMND_RATE_ACTUAL_YOY PRIMARY KEY (LOCAT_ITEM_ID, STRT_DATE, END_DATE)
	)

	CREATE TABLE #TEMP_DMND_RATE_FORECAST_ALL (
		LOCAT_ITEM_ID			CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		QTY						DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_DMND_RATE_FORECAST_TARGET (
		LOCAT_ITEM_ID			CHAR(32) COLLATE DATABASE_DEFAULT,
		STRT_DATE				DATETIME,
		END_DATE				DATETIME,
		QTY						DECIMAL(20,3),
		CONSTRAINT PK_TEMP_DMND_RATE_FORECAST_TARGET PRIMARY KEY (LOCAT_ITEM_ID, STRT_DATE, END_DATE)
	)

	CREATE TABLE #TEMP_DMND_RATE
	(
		LOCAT_ITEM_ID			CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		DMND_RATE_CAL_TP_ID		CHAR(32),
		DMND_RATE				DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_PERIOD_DMND_RATE
	(
		LOCAT_ITEM_ID			CHAR(32) COLLATE DATABASE_DEFAULT,
		STRT_DATE				DATETIME,
		END_DATE				DATETIME,
		DMND_RATE				DECIMAL(20,3),
		CONSTRAINT PK_TEMP_PERIOD_DMND_RATE PRIMARY KEY (LOCAT_ITEM_ID, STRT_DATE, END_DATE)
	)

	INSERT INTO #TEMP_DMND_CAL_METHOD_MAP
	(
		LOCAT_ITEM_ID,
		CAL_MTD_CD
	)
	SELECT	A.LOCAT_ITEM_ID, C.COMN_CD
	FROM	VW_LOCAT_ITEM_INFO A
			INNER JOIN TB_IM_CAL_METHOD_INFO B
			ON B.LOCAT_ID = A.LOCAT_ID
			INNER JOIN TB_AD_COMN_CODE C
			ON C.ID = B.CAL_MTD_ID
	WHERE	1=1
	AND		A.INV_POLICY_TARGET_YN = 'Y'
	AND		A.BOM_ITEM_TP_CD = 'FINAL_PRODUCT_GR_ITEM'
	AND		B.CATAGY_VAL = 'DEMAND_RATE_CAL_METHOD'
	AND		C.COMN_CD <> 'DRCM_01'

	INSERT INTO #TEMP_DMND_RATE_ACTUAL_ALL
	(
		LOCAT_ITEM_ID,
		QTY,
		MIN_QTY,
		MAX_QTY
	)
	SELECT	A.SUPPLY_LOCAT_ITEM_ID,
			SUM(A.QTY) / MIN(A.BUCKET_CNT) AS QTY,
			MIN(A.MIN_QTY) AS MIN_QTY,
			MAX(A.MAX_QTY) AS MAX_QTY
	FROM	(
			SELECT	A.SUPPLY_LOCAT_ITEM_ID,
					A.ATD,
					D.BUCKET_CNT,
					SUM(A.SHPP_QTY) AS QTY,
					MIN(A.SHPP_QTY) AS MIN_QTY,
					MAX(A.SHPP_QTY) AS MAX_QTY
			FROM	TB_CM_ACTUAL_SHIPMENT A
					INNER JOIN TB_CM_SITE_ITEM B
					ON B.ID = A.SUPPLY_LOCAT_ITEM_ID
					INNER JOIN TB_CM_LOC_MGMT C
					ON C.ID = B.LOCAT_MGMT_ID
					LEFT OUTER JOIN 
					(
					SELECT	LOCAT_ID, START_DATE, END_DATE,
							(SELECT VAL FROM DBO.FN_G_BUCKET_CNT(@V_TIME_BUCKET, A.START_DATE, A.END_DATE)) AS BUCKET_CNT
					FROM	(
							SELECT	LOCAT_ID, 
									(SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.ACTUAL_PERIOD, 'START', B.UOM_CD)) AS START_DATE,
									(SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.ACTUAL_PERIOD, 'END', B.UOM_CD)) AS END_DATE
							FROM	TB_IM_VARIABILITY_ACT_PRIOD A
									INNER JOIN TB_CM_UOM B
									ON B.ID = A.UOM_ID
							WHERE	CATAGY_VAL = 'DEMAND_RATE'
							) A
					) D
					ON D.LOCAT_ID = C.LOCAT_ID
			WHERE	1=1
			AND		ISNULL(B.ACTV_YN, 'N') = 'Y'
			AND		ISNULL(C.ACTV_YN, 'N') = 'Y'
			AND		A.ATD BETWEEN D.START_DATE AND D.END_DATE
			GROUP	BY A.SUPPLY_LOCAT_ITEM_ID, D.BUCKET_CNT, A.ATD
			) A
	GROUP	BY A.SUPPLY_LOCAT_ITEM_ID

	INSERT INTO #TEMP_DMND_RATE_ACTUAL_YOY
	(
		LOCAT_ITEM_ID,
		STRT_DATE,
		END_DATE,
		QTY
	)
	SELECT  A.LOCAT_ITEM_ID, 
			A.STRT_DATE, 
			A.END_DATE,
			AVG(A.SHPP_QTY) AS QTY
	FROM	(
			SELECT  A.LOCAT_ITEM_ID, A.STRT_DATE, A.END_DATE, A.FROM_DATE, A.TO_DATE, B.ATD,
					SUM(ISNULL(B.SHPP_QTY, 0)) AS SHPP_QTY
			FROM    (
					SELECT  DISTINCT 
							A.LOCAT_ITEM_ID, 
							CASE WHEN @V_TIME_BUCKET = 'MONTH' THEN MIN(B.DAT) OVER (PARTITION BY B.YYYYMM)
								 WHEN @V_TIME_BUCKET = 'WEEK'  THEN MIN(B.DAT) OVER (PARTITION BY B.WK52)
								 ELSE B.DAT 
							END AS STRT_DATE,
							CASE WHEN @V_TIME_BUCKET = 'MONTH' THEN DATEADD(MM, A.OPERT_TARGET_VAL, MAX(B.DAT) OVER (PARTITION BY B.YYYYMM))
								 WHEN @V_TIME_BUCKET = 'WEEK'  THEN DATEADD(WK, A.OPERT_TARGET_VAL, MAX(B.DAT) OVER (PARTITION BY B.WK52))
								 ELSE DATEADD(DD, A.OPERT_TARGET_VAL, B.DAT) 
							END AS END_DATE,
							CASE WHEN @V_TIME_BUCKET = 'MONTH' THEN DATEADD(YYYY, -1, MIN(B.DAT) OVER (PARTITION BY B.YYYYMM))
								 WHEN @V_TIME_BUCKET = 'WEEK'  THEN DATEADD(YYYY, -1, MIN(B.DAT) OVER (PARTITION BY B.WK52))
								 ELSE DATEADD(YYYY, -1, B.DAT) END AS FROM_DATE,
							CASE WHEN @V_TIME_BUCKET = 'MONTH' THEN DATEADD(MM, A.OPERT_TARGET_VAL, DATEADD(YYYY, -1, MAX(B.DAT) OVER (PARTITION BY B.YYYYMM)))
								 WHEN @V_TIME_BUCKET = 'WEEK'  THEN DATEADD(WK, A.OPERT_TARGET_VAL, DATEADD(YYYY, -1, MAX(B.DAT) OVER (PARTITION BY B.WK52)))
								 ELSE DATEADD(DD, A.OPERT_TARGET_VAL, DATEADD(YYYY, -1, B.DAT)) END AS TO_DATE
					FROM    #TEMP_OPERT_TARGET A
							INNER JOIN TB_CM_CALENDAR B
							ON B.DAT BETWEEN @V_PLAN_START_DATE AND @V_PLAN_END_DATE
					) A
					INNER JOIN TB_CM_ACTUAL_SHIPMENT B
					ON A.LOCAT_ITEM_ID = B.SUPPLY_LOCAT_ITEM_ID
					AND B.ATD BETWEEN A.FROM_DATE AND A.TO_DATE
			GROUP	BY A.LOCAT_ITEM_ID, A.STRT_DATE, A.END_DATE, A.FROM_DATE, A.TO_DATE, B.ATD
			) A
	WHERE	A.LOCAT_ITEM_ID IN (SELECT LOCAT_ITEM_ID FROM #TEMP_DMND_CAL_METHOD_MAP WHERE CAL_MTD_CD = 'DRCM_02')
	GROUP	BY A.LOCAT_ITEM_ID, A.STRT_DATE, A.END_DATE

	INSERT INTO #TEMP_DMND_RATE_FORECAST_ALL
	(
		LOCAT_ITEM_ID,
		QTY
	)
	SELECT  A.LOCAT_ITEM_ID, 
			AVG(DMND_QTY) AS QTY
	FROM    (
			SELECT  A.LOCAT_ITEM_ID, 
					A.FROM_DATE, 
					SUM(ISNULL(B.DMND_QTY, 0)) AS DMND_QTY
			FROM    (
					SELECT  DISTINCT 
							A.LOCAT_ITEM_ID, 
							CASE WHEN @V_TIME_BUCKET = 'MONTH' THEN MIN(B.DAT) OVER (PARTITION BY B.YYYYMM)
								 WHEN @V_TIME_BUCKET = 'WEEK'  THEN MIN(B.DAT) OVER (PARTITION BY B.WK52)
								 ELSE B.DAT END AS FROM_DATE,
							CASE WHEN @V_TIME_BUCKET = 'MONTH' THEN MAX(B.DAT) OVER (PARTITION BY B.YYYYMM)
								 WHEN @V_TIME_BUCKET = 'WEEK'  THEN MAX(B.DAT) OVER (PARTITION BY B.WK52)
								 ELSE B.DAT END AS TO_DATE
					FROM    TB_IM_SITE_ITEM_SEG_SUMM A
							INNER JOIN TB_CM_CALENDAR B
							ON B.DAT BETWEEN @V_PLAN_START_DATE AND @V_PLAN_END_DATE
					) A
					LEFT OUTER JOIN
					(
					SELECT	C.ID,
							A.DUE_DATE,
							A.DMND_QTY
					FROM	TB_CM_DEMAND_OVERVIEW A
							INNER JOIN TB_CM_DMND_SHPP_MAP_MST B
							ON A.ITEM_MST_ID = B.ITEM_MST_ID
							AND A.ACCOUNT_ID = B.ACCOUNT_ID
							INNER JOIN TB_CM_SITE_ITEM C
							ON A.ITEM_MST_ID = C.ITEM_MST_ID
							AND B.LOCAT_MGMT_ID = C.LOCAT_MGMT_ID
							INNER JOIN TB_AD_COMN_CODE D
							ON D.ID = C.BOM_ITEM_TP_ID
					WHERE	1=1
					AND		A.T3SERIES_VER_ID = @V_DP_VER_ID
					AND		D.COMN_CD = 'FINAL_PRODUCT_GR_ITEM'
					) B
					ON B.ID = A.LOCAT_ITEM_ID
					AND B.DUE_DATE BETWEEN A.FROM_DATE AND A.TO_DATE
			GROUP   BY A.LOCAT_ITEM_ID, A.FROM_DATE
			) A
	WHERE	A.LOCAT_ITEM_ID IN (SELECT LOCAT_ITEM_ID FROM #TEMP_DMND_CAL_METHOD_MAP WHERE CAL_MTD_CD = 'DRCM_03')
	GROUP	BY A.LOCAT_ITEM_ID

	INSERT INTO #TEMP_DMND_RATE_FORECAST_TARGET
	(
		LOCAT_ITEM_ID,
		STRT_DATE,
		END_DATE,
		QTY
	)
	SELECT	A.LOCAT_ITEM_ID, 
			A.FROM_DATE,
			A.TO_DATE,
			AVG(A.DMND_QTY) AS QTY
	FROM	(
			SELECT  A.LOCAT_ITEM_ID, A.FROM_DATE, A.TO_DATE, B.DUE_DATE,
					SUM(ISNULL(B.DMND_QTY, 0)) AS DMND_QTY
			FROM    (
					SELECT  DISTINCT 
							A.LOCAT_ITEM_ID, 
							CASE WHEN @V_TIME_BUCKET = 'MONTH' THEN MIN(B.DAT) OVER (PARTITION BY B.YYYYMM)
								 WHEN @V_TIME_BUCKET = 'WEEK'  THEN MIN(B.DAT) OVER (PARTITION BY B.WK52)
								 ELSE B.DAT 
							END AS FROM_DATE,
							CASE WHEN @V_TIME_BUCKET = 'MONTH' THEN DATEADD(MM, A.OPERT_TARGET_VAL, MAX(B.DAT) OVER (PARTITION BY B.YYYYMM))
								 WHEN @V_TIME_BUCKET = 'WEEK'  THEN DATEADD(WK, A.OPERT_TARGET_VAL, MAX(B.DAT) OVER (PARTITION BY B.WK52))
								 ELSE DATEADD(DD, A.OPERT_TARGET_VAL, B.DAT) 
							END AS TO_DATE
					FROM    #TEMP_OPERT_TARGET A
							INNER JOIN TB_CM_CALENDAR B
							ON B.DAT BETWEEN @V_PLAN_START_DATE AND @V_PLAN_END_DATE
					) A
					INNER JOIN
					(
					SELECT	C.ID,
							A.DUE_DATE,
							A.DMND_QTY
					FROM	TB_CM_DEMAND_OVERVIEW A
							INNER JOIN TB_CM_DMND_SHPP_MAP_MST B
							ON A.ITEM_MST_ID = B.ITEM_MST_ID
							AND A.ACCOUNT_ID = B.ACCOUNT_ID
							INNER JOIN TB_CM_SITE_ITEM C
							ON A.ITEM_MST_ID = C.ITEM_MST_ID
							AND B.LOCAT_MGMT_ID = C.LOCAT_MGMT_ID
							INNER JOIN TB_AD_COMN_CODE D
							ON D.ID = C.BOM_ITEM_TP_ID
					WHERE	1=1
					AND		A.T3SERIES_VER_ID = @V_DP_VER_ID
					AND		D.COMN_CD = 'FINAL_PRODUCT_GR_ITEM'
					) B
					ON B.ID = A.LOCAT_ITEM_ID
					AND B.DUE_DATE BETWEEN A.FROM_DATE AND A.TO_DATE
			GROUP   BY A.LOCAT_ITEM_ID, A.FROM_DATE, A.TO_DATE, B.DUE_DATE
			) A
	WHERE	A.LOCAT_ITEM_ID IN (SELECT LOCAT_ITEM_ID FROM #TEMP_DMND_CAL_METHOD_MAP WHERE CAL_MTD_CD = 'DRCM_04')
	GROUP	BY A.LOCAT_ITEM_ID, A.FROM_DATE, A.TO_DATE

	INSERT INTO #TEMP_DMND_RATE
	(
		LOCAT_ITEM_ID,
		DMND_RATE_CAL_TP_ID,
		DMND_RATE
	)
	SELECT	A.LOCAT_ITEM_ID,
			E.CAL_MTD_ID AS DMND_RATE_CAL_TP_ID,
			CASE WHEN F.COMN_CD = 'DRCM_01' THEN ROUND(ISNULL(H.QTY, 0), 3)
				 WHEN F.COMN_CD = 'DRCM_02' THEN ROUND(ISNULL(I.QTY, 0), 3)
				 WHEN F.COMN_CD = 'DRCM_03' THEN ROUND(ISNULL(J.QTY, 0), 3)
				 WHEN F.COMN_CD = 'DRCM_04' THEN ROUND(ISNULL(K.QTY, 0), 3)
			END	AS DMND_RATE
	FROM	TB_IM_SITE_ITEM_SEG_SUMM A
			INNER JOIN TB_CM_SITE_ITEM B
			ON B.ID = A.LOCAT_ITEM_ID
			INNER JOIN TB_CM_LOC_MGMT C
			ON C.ID = B.LOCAT_MGMT_ID
			LEFT OUTER JOIN TB_IM_INV_POLICY_MST D
			ON D.LOCAT_ID = C.LOCAT_ID
			LEFT OUTER JOIN TB_IM_CAL_METHOD_INFO E
			ON E.LOCAT_ID = D.LOCAT_ID
			LEFT OUTER JOIN TB_AD_COMN_CODE F
			ON F.ID = E.CAL_MTD_ID
			LEFT OUTER JOIN TB_IM_SVC_SAFTFCT_BASE G
			ON G.SVC_LV = ISNULL(D.SFST_SVC_LV, D.PRPSAL_SVC_LV)
			LEFT OUTER JOIN #TEMP_DMND_RATE_ACTUAL_ALL H
			ON H.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			LEFT OUTER JOIN
			(
			SELECT	LOCAT_ITEM_ID,
					AVG(QTY) AS QTY
			FROM	#TEMP_DMND_RATE_ACTUAL_YOY
			GROUP	BY LOCAT_ITEM_ID
			) I
			ON I.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			LEFT OUTER JOIN #TEMP_DMND_RATE_FORECAST_ALL J
			ON J.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			LEFT OUTER JOIN
			(
			SELECT	LOCAT_ITEM_ID,
					AVG(QTY) AS QTY
			FROM	#TEMP_DMND_RATE_FORECAST_TARGET
			GROUP	BY LOCAT_ITEM_ID
			) K
			ON K.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
	WHERE	1=1
	AND		ISNULL(A.VAL_01, '') = IIF(D.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(D.VAL_01, ''))
	AND		ISNULL(A.VAL_02, '') = IIF(D.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(D.VAL_02, ''))
	AND		E.CATAGY_VAL ='DEMAND_RATE_CAL_METHOD'

	INSERT INTO #TEMP_PERIOD_DMND_RATE
	(
		LOCAT_ITEM_ID,
		STRT_DATE,
		END_DATE,
		DMND_RATE
	)
	SELECT	A.LOCAT_ITEM_ID,
			IIF(F.COMN_CD = 'DRCM_02', G.STRT_DATE, H.STRT_DATE) AS STRT_DATE,
			IIF(F.COMN_CD = 'DRCM_02', G.END_DATE, H.END_DATE)   AS END_DATE,
			IIF(F.COMN_CD = 'DRCM_02', ROUND(ISNULL(G.QTY, 0), 0), ROUND(ISNULL(H.QTY, 0), 0)) AS DMND_RATE
	FROM	TB_IM_SITE_ITEM_SEG_SUMM A
			INNER JOIN TB_CM_SITE_ITEM B
			ON B.ID = A.LOCAT_ITEM_ID
			INNER JOIN TB_CM_LOC_MGMT C
			ON C.ID = B.LOCAT_MGMT_ID
			LEFT OUTER JOIN TB_IM_INV_POLICY_MST D
			ON D.LOCAT_ID = C.LOCAT_ID
			LEFT OUTER JOIN TB_IM_CAL_METHOD_INFO E
			ON E.LOCAT_ID = D.LOCAT_ID
			LEFT OUTER JOIN TB_AD_COMN_CODE F
			ON F.ID = E.CAL_MTD_ID
			LEFT OUTER JOIN #TEMP_DMND_RATE_ACTUAL_YOY G
			ON G.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			LEFT OUTER JOIN #TEMP_DMND_RATE_FORECAST_TARGET H
			ON H.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
	WHERE	1=1
	AND		ISNULL(A.VAL_01, '') = IIF(D.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(D.VAL_01, ''))
	AND		ISNULL(A.VAL_02, '') = IIF(D.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(D.VAL_02, ''))
	AND		(G.STRT_DATE IS NOT NULL OR H.STRT_DATE IS NOT NULL)
	AND		E.CATAGY_VAL = 'DEMAND_RATE_CAL_METHOD'
	AND		F.COMN_CD IN ('DRCM_02', 'DRCM_04')

	/***************************************************************************************************************************************************************************
	4. 수요변동성 표준편차
	 - 전년 동기 출하실적, 직전 출하실적, 판매 계획의 설정 구간 별 가중치를 반영한 표준편차
	***************************************************************************************************************************************************************************/
	CREATE TABLE #TEMP_INV_ANLY_PRIOD (
		LOCAT_ID		CHAR(32) COLLATE DATABASE_DEFAULT,
		PERIOD_TP		NVARCHAR(50),
		UOM_CD			NVARCHAR(50),
		START_DATE		DATETIME,
		END_DATE		DATETIME,
		BUCKET_CNT		DECIMAL(20,3),
		WTFAR			DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_LAST_SHIPMENT_ANLY (
		LOCAT_ITEM_ID	CHAR(32) COLLATE DATABASE_DEFAULT,
		STDEV_VAL		DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_ACTUAL_YOY_ANLY (
		LOCAT_ITEM_ID	CHAR(32) COLLATE DATABASE_DEFAULT,
		STDEV_VAL		DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_DMND_PLAN_ANLY (
		LOCAT_ITEM_ID	CHAR(32) COLLATE DATABASE_DEFAULT,
		STDEV_VAL		DECIMAL(20,3)
	)
	
	CREATE TABLE #TEMP_DMND_VARAN_ANLYS (
		LOCAT_ITEM_ID	CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		DEVIT			DECIMAL(20,3)
	)
	
	INSERT INTO #TEMP_INV_ANLY_PRIOD
	(
		LOCAT_ID,
		PERIOD_TP,
		UOM_CD,
		START_DATE,
		END_DATE,
		BUCKET_CNT,
		WTFAR
	)
 	SELECT  A.LOCAT_ID, A.PERIOD_TP, 
			A.UOM_CD, START_DATE, END_DATE, 
			(SELECT VAL FROM DBO.FN_G_BUCKET_CNT(@V_TIME_BUCKET, START_DATE, END_DATE)) AS BUCKET_CNT, 
			A.WTFAR
	FROM	(
			SELECT	A.LOCAT_ID, A.PERIOD_VAL, B.UOM_CD, C.COMN_CD AS PERIOD_TP, 
					ISNULL(A.WTFAR, 0) / 100 AS WTFAR,
					(SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.PERIOD_VAL, 'START', B.UOM_CD)) AS START_DATE,
					(SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.PERIOD_VAL, 'END', B.UOM_CD)) AS END_DATE
			FROM	TB_IM_INV_ANLY_PRIOD A
					INNER JOIN TB_CM_UOM B
					ON B.ID = A.UOM_ID
					INNER JOIN TB_AD_COMN_CODE C
					ON C.ID = A.INV_ANLY_PRIOD_ID
			WHERE	A.CATAGY_VAL = 'DEMAND_VARIABILITY'
			AND		C.COMN_CD IN ('LAST_SHIPPING','DEMAND_PLAN')
			AND		ISNULL(A.ACTV_YN, 'N') = 'Y'
			UNION	ALL
			SELECT	A.LOCAT_ID, A.PERIOD_VAL, B.UOM_CD, C.COMN_CD AS PERIOD_TP, 
					ISNULL(A.WTFAR, 0) / 100 AS WTFAR,
					DATEADD(YY, -1, (SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.PERIOD_VAL, 'START', B.UOM_CD))) AS START_DATE,
					DATEADD(YY, -1, (SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.PERIOD_VAL, 'END', B.UOM_CD))) AS END_DATE
			FROM	TB_IM_INV_ANLY_PRIOD A
					INNER JOIN TB_CM_UOM B
					ON B.ID = A.UOM_ID
					INNER JOIN TB_AD_COMN_CODE C
					ON C.ID = A.INV_ANLY_PRIOD_ID
			WHERE	A.CATAGY_VAL = 'DEMAND_VARIABILITY'
			AND		C.COMN_CD = 'LAST_YEAR_SHIPPING'
			AND		ISNULL(A.ACTV_YN, 'N') = 'Y'
			) A

	INSERT INTO #TEMP_LAST_SHIPMENT_ANLY
	(
		LOCAT_ITEM_ID,
		STDEV_VAL
	)
	SELECT	A.SUPPLY_LOCAT_ITEM_ID, 
			ROUND(SQRT((SUM(POWER(A.AVG_SHPP_VAL - A.SHPP_VAL, 2)) + POWER(A.AVG_SHPP_VAL - 0, 2) * MIN(A.CNT)) / (MIN(A.BUCKET_CNT) - 1)), 3) AS STDEV_VAL
	FROM	(
			SELECT  A.SUPPLY_LOCAT_ITEM_ID, A.SUPPLY_LOCAT_ID, A.DAT, 
					IIF(A.BUCKET_CNT = 1, 2, A.BUCKET_CNT) AS BUCKET_CNT, 
					A.CNT, 
					A.SHPP_VAL AS SHPP_VAL, 
					SUM(A.SHPP_VAL) OVER (PARTITION BY A.SUPPLY_LOCAT_ITEM_ID) / A.BUCKET_CNT AS AVG_SHPP_VAL
			FROM    (
					SELECT  A.SUPPLY_LOCAT_ITEM_ID, A.SUPPLY_LOCAT_ID, A.DAT, C.BUCKET_CNT,
							CASE WHEN C.BUCKET_CNT - COUNT(A.SHPP_QTY) OVER (PARTITION BY A.SUPPLY_LOCAT_ITEM_ID) < 0 THEN 0
							     ELSE C.BUCKET_CNT - COUNT(A.SHPP_QTY) OVER (PARTITION BY A.SUPPLY_LOCAT_ITEM_ID) END AS CNT,
							CASE WHEN B.QUADRANT_BASE_CD = 'QTY_BASE' THEN A.SHPP_QTY ELSE A.SHPP_AMT END AS SHPP_VAL
					FROM    (
 							SELECT	SUPPLY_LOCAT_ITEM_ID, SUPPLY_LOCAT_ID,
									CONSUME_LOCAT_ITEM_ID, CONSUME_LOCAT_ID, ACCOUNT_ID, A.DAT,
									SUM(ISNULL(SHPP_QTY * A.WTFAR, 0)) AS SHPP_QTY,
									SUM(ISNULL(SHPP_AMT * A.WTFAR, 0)) AS SHPP_AMT
							FROM	(
									SELECT	A.SUPPLY_LOCAT_ITEM_ID, A.SUPPLY_LOCAT_ID, 
											A.CONSUME_LOCAT_ITEM_ID, A.CONSUME_LOCAT_ID, A.ACCOUNT_ID,
											CASE WHEN @V_TIME_BUCKET = 'MONTH' THEN B.YYYYMM
												 WHEN @V_TIME_BUCKET = 'WEEK'  THEN B.WK52
												 ELSE B.DAT_ID
											END AS DAT,
											A.WTFAR, A.SHPP_QTY, A.SHPP_AMT
									FROM	(
											SELECT  A.SUPPLY_LOCAT_ITEM_ID, E.LOCAT_ID AS SUPPLY_LOCAT_ID,
													A.CONSUME_LOCAT_ITEM_ID, C.LOCAT_ID AS CONSUME_LOCAT_ID, A.ACCOUNT_ID, 
													A.ATD, A.SHPP_QTY, A.SHPP_AMT, H.WTFAR
											FROM    TB_CM_ACTUAL_SHIPMENT A
													LEFT OUTER JOIN TB_CM_SITE_ITEM B
													ON B.ID = A.CONSUME_LOCAT_ITEM_ID
													LEFT OUTER JOIN TB_CM_LOC_MGMT C
													ON C.ID = B.LOCAT_MGMT_ID
													INNER JOIN TB_CM_SITE_ITEM D
													ON D.ID = A.SUPPLY_LOCAT_ITEM_ID
													INNER JOIN TB_CM_LOC_MGMT E
													ON E.ID = D.LOCAT_MGMT_ID
													INNER JOIN TB_CM_LOC_DTL F
													ON F.ID = E.LOCAT_ID
													INNER JOIN TB_CM_LOC_MST G
													ON G.ID = F.LOCAT_MST_ID
													LEFT OUTER JOIN #TEMP_INV_ANLY_PRIOD H
													ON F.ID = H.LOCAT_ID
													AND H.PERIOD_TP = 'LAST_SHIPPING'
											WHERE   1=1
											AND     ISNULL(B.ACTV_YN, 'N') = IIF(B.ID IS NULL, 'N', 'Y')
											AND     ISNULL(C.ACTV_YN, 'N') = IIF(C.ID IS NULL, 'N', 'Y')
											AND     ISNULL(D.ACTV_YN, 'N') = 'Y'
											AND     ISNULL(E.ACTV_YN, 'N') = 'Y'
											AND		G.INV_POLICY_TARGET_YN = 'Y'
											AND		A.ATD BETWEEN H.START_DATE AND H.END_DATE
											) A
											INNER JOIN TB_CM_CALENDAR B
											ON B.DAT = A.ATD
									) A
							GROUP	BY SUPPLY_LOCAT_ITEM_ID, SUPPLY_LOCAT_ID, CONSUME_LOCAT_ITEM_ID, CONSUME_LOCAT_ID, ACCOUNT_ID, DAT
							) A
							INNER JOIN
							(
							SELECT  A.LOCAT_ID, B.COMN_CD AS QUADRANT_BASE_CD
							FROM    TB_IM_DMND_VARIABILITY_BASE A, 
									TB_AD_COMN_CODE B
							WHERE   B.ID = A.QUADRANT_BASE_ID
							AND     ISNULL(A.ACTV_YN, 'N') = 'Y'
							) B
							ON B.LOCAT_ID = A.SUPPLY_LOCAT_ID
							LEFT OUTER JOIN #TEMP_INV_ANLY_PRIOD C
							ON C.LOCAT_ID = A.SUPPLY_LOCAT_ID
							AND C.PERIOD_TP = 'LAST_SHIPPING'
					) A
			GROUP	BY A.SUPPLY_LOCAT_ITEM_ID, A.SUPPLY_LOCAT_ID, A.DAT, A.BUCKET_CNT, A.CNT, A.SHPP_VAL
			) A
	GROUP	BY A.SUPPLY_LOCAT_ITEM_ID, A.AVG_SHPP_VAL

	INSERT INTO #TEMP_ACTUAL_YOY_ANLY
	(
		LOCAT_ITEM_ID,
		STDEV_VAL
	)
	SELECT	A.SUPPLY_LOCAT_ITEM_ID, 
			ROUND(SQRT((SUM(POWER(A.AVG_SHPP_VAL - A.SHPP_VAL, 2)) + POWER(A.AVG_SHPP_VAL - 0, 2) * MIN(A.CNT)) / (MIN(A.BUCKET_CNT) - 1)), 3) AS STDEV_VAL
	FROM	(
			SELECT  A.SUPPLY_LOCAT_ITEM_ID, A.SUPPLY_LOCAT_ID, A.DAT, 
					IIF(A.BUCKET_CNT = 1, 2, A.BUCKET_CNT) AS BUCKET_CNT, 
					A.CNT, 
					A.SHPP_VAL AS SHPP_VAL, 
					SUM(A.SHPP_VAL) OVER (PARTITION BY A.SUPPLY_LOCAT_ITEM_ID) / A.BUCKET_CNT AS AVG_SHPP_VAL
			FROM    (
					SELECT  A.SUPPLY_LOCAT_ITEM_ID, A.SUPPLY_LOCAT_ID, A.DAT, C.BUCKET_CNT,
							C.BUCKET_CNT - COUNT(A.SHPP_QTY) OVER (PARTITION BY A.SUPPLY_LOCAT_ITEM_ID) AS CNT,
							CASE WHEN B.QUADRANT_BASE_CD = 'QTY_BASE' THEN A.SHPP_QTY ELSE A.SHPP_AMT END AS SHPP_VAL
					FROM    (
 							SELECT	SUPPLY_LOCAT_ITEM_ID, SUPPLY_LOCAT_ID,
									CONSUME_LOCAT_ITEM_ID, CONSUME_LOCAT_ID, ACCOUNT_ID, A.DAT,
									SUM(ISNULL(SHPP_QTY * A.WTFAR, 0)) AS SHPP_QTY,
									SUM(ISNULL(SHPP_AMT * A.WTFAR, 0)) AS SHPP_AMT
							FROM	(
									SELECT	A.SUPPLY_LOCAT_ITEM_ID, A.SUPPLY_LOCAT_ID, 
											A.CONSUME_LOCAT_ITEM_ID, A.CONSUME_LOCAT_ID, A.ACCOUNT_ID,
											CASE WHEN @V_TIME_BUCKET = 'MONTH' THEN B.YYYYMM
												 WHEN @V_TIME_BUCKET = 'WEEK'  THEN B.WK52
												 ELSE B.DAT_ID
											END AS DAT,
											A.WTFAR, A.SHPP_QTY, A.SHPP_AMT
									FROM	(
											SELECT  A.SUPPLY_LOCAT_ITEM_ID, E.LOCAT_ID AS SUPPLY_LOCAT_ID,
													A.CONSUME_LOCAT_ITEM_ID, C.LOCAT_ID AS CONSUME_LOCAT_ID, A.ACCOUNT_ID, 
													A.ATD, A.SHPP_QTY, A.SHPP_AMT, H.WTFAR
											FROM    TB_CM_ACTUAL_SHIPMENT A
													LEFT OUTER JOIN TB_CM_SITE_ITEM B
													ON B.ID = A.CONSUME_LOCAT_ITEM_ID
													LEFT OUTER JOIN TB_CM_LOC_MGMT C
													ON C.ID = B.LOCAT_MGMT_ID
													INNER JOIN TB_CM_SITE_ITEM D
													ON D.ID = A.SUPPLY_LOCAT_ITEM_ID
													INNER JOIN TB_CM_LOC_MGMT E
													ON E.ID = D.LOCAT_MGMT_ID
													INNER JOIN TB_CM_LOC_DTL F
													ON F.ID = E.LOCAT_ID
													INNER JOIN TB_CM_LOC_MST G
													ON G.ID = F.LOCAT_MST_ID
													LEFT OUTER JOIN #TEMP_INV_ANLY_PRIOD H
													ON F.ID = H.LOCAT_ID
													AND H.PERIOD_TP = 'LAST_YEAR_SHIPPING'
											WHERE   1=1
											AND     ISNULL(B.ACTV_YN, 'N') = IIF(B.ID IS NULL, 'N', 'Y')
											AND     ISNULL(C.ACTV_YN, 'N') = IIF(C.ID IS NULL, 'N', 'Y')
											AND     ISNULL(D.ACTV_YN, 'N') = 'Y'
											AND     ISNULL(E.ACTV_YN, 'N') = 'Y'
											AND		G.INV_POLICY_TARGET_YN = 'Y'
											AND		A.ATD BETWEEN H.START_DATE AND H.END_DATE
											) A
											INNER JOIN TB_CM_CALENDAR B
											ON B.DAT = A.ATD
									) A
							GROUP	BY SUPPLY_LOCAT_ITEM_ID, SUPPLY_LOCAT_ID, CONSUME_LOCAT_ITEM_ID, CONSUME_LOCAT_ID, ACCOUNT_ID, DAT
							) A
							INNER JOIN
							(
							SELECT  A.LOCAT_ID, B.COMN_CD AS QUADRANT_BASE_CD
							FROM    TB_IM_DMND_VARIABILITY_BASE A, 
									TB_AD_COMN_CODE B
							WHERE   B.ID = A.QUADRANT_BASE_ID
							AND     ISNULL(A.ACTV_YN, 'N') = 'Y'
							) B
							ON B.LOCAT_ID = A.SUPPLY_LOCAT_ID
							LEFT OUTER JOIN #TEMP_INV_ANLY_PRIOD C
							ON C.LOCAT_ID = A.SUPPLY_LOCAT_ID
							AND C.PERIOD_TP = 'LAST_YEAR_SHIPPING'
					) A
			GROUP	BY A.SUPPLY_LOCAT_ITEM_ID, A.SUPPLY_LOCAT_ID, A.DAT, A.BUCKET_CNT, A.CNT, A.SHPP_VAL
			) A
	GROUP	BY A.SUPPLY_LOCAT_ITEM_ID, A.AVG_SHPP_VAL

	INSERT INTO #TEMP_DMND_PLAN_ANLY
	(
		LOCAT_ITEM_ID,
		STDEV_VAL
	)
	SELECT	A.SUPPLY_LOCAT_ITEM_ID, 
			ROUND(SQRT((SUM(POWER(A.AVG_SHPP_VAL - A.SHPP_VAL, 2)) + POWER(A.AVG_SHPP_VAL - 0, 2) * MIN(A.CNT)) / (MIN(A.BUCKET_CNT) - 1)), 3) AS STDEV_VAL
	FROM	(
			SELECT  A.SUPPLY_LOCAT_ITEM_ID, A.SUPPLY_LOCAT_ID, A.DAT, 
					IIF(A.BUCKET_CNT = 1, 2, A.BUCKET_CNT) AS BUCKET_CNT, 
					A.CNT, 
					A.SHPP_VAL AS SHPP_VAL, 
					SUM(A.SHPP_VAL) OVER (PARTITION BY A.SUPPLY_LOCAT_ITEM_ID) / A.BUCKET_CNT AS AVG_SHPP_VAL
			FROM    (
					SELECT  A.SUPPLY_LOCAT_ITEM_ID, A.SUPPLY_LOCAT_ID, A.DAT, C.BUCKET_CNT,
							C.BUCKET_CNT - COUNT(A.SHPP_QTY) OVER (PARTITION BY A.SUPPLY_LOCAT_ITEM_ID) AS CNT,
							CASE WHEN B.QUADRANT_BASE_CD = 'QTY_BASE' THEN A.SHPP_QTY ELSE A.SHPP_AMT END AS SHPP_VAL
					FROM    (
							SELECT	SUPPLY_LOCAT_ITEM_ID, SUPPLY_LOCAT_ID, DAT,
									SUM(SHPP_QTY) AS SHPP_QTY, 
									SUM(SHPP_AMT) AS SHPP_AMT
							FROM	(
 									SELECT	SUPPLY_LOCAT_ITEM_ID, SUPPLY_LOCAT_ID,
											CONSUME_LOCAT_ITEM_ID, CONSUME_LOCAT_ID, ACCOUNT_ID, A.DAT,
											SUM(ISNULL(SHPP_QTY * A.WTFAR, 0)) AS SHPP_QTY,
											SUM(ISNULL(SHPP_AMT * A.WTFAR, 0)) AS SHPP_AMT
									FROM	(
											SELECT	A.SUPPLY_LOCAT_ITEM_ID, A.SUPPLY_LOCAT_ID, 
													A.CONSUME_LOCAT_ITEM_ID, A.CONSUME_LOCAT_ID, A.ACCOUNT_ID,
													CASE WHEN @V_TIME_BUCKET = 'MONTH' THEN B.YYYYMM
														 WHEN @V_TIME_BUCKET = 'WEEK'  THEN B.WK52
														 ELSE B.DAT_ID
													END AS DAT,
													A.WTFAR, A.SHPP_QTY, A.SHPP_AMT
											FROM	(
													SELECT	C.ID				AS SUPPLY_LOCAT_ITEM_ID,
															E.LOCAT_ID			AS SUPPLY_LOCAT_ID,
															NULL				AS CONSUME_LOCAT_ITEM_ID,
															NULL				AS CONSUME_LOCAT_ID,
															A.ACCOUNT_ID,
															A.DUE_DATE,
															A.DMND_QTY			AS SHPP_QTY,
															A.SALES_UNIT_PRIC	AS SHPP_AMT,
															H.WTFAR
													FROM	TB_CM_DEMAND_OVERVIEW A
															INNER JOIN TB_CM_DMND_SHPP_MAP_MST B
															ON A.ITEM_MST_ID = B.ITEM_MST_ID
															AND A.ACCOUNT_ID = B.ACCOUNT_ID
															INNER JOIN TB_CM_SITE_ITEM C
															ON A.ITEM_MST_ID = C.ITEM_MST_ID
															AND B.LOCAT_MGMT_ID = C.LOCAT_MGMT_ID
															INNER JOIN TB_AD_COMN_CODE D
															ON D.ID = C.BOM_ITEM_TP_ID
															INNER JOIN TB_CM_LOC_MGMT E
															ON E.ID = C.LOCAT_MGMT_ID
															INNER JOIN TB_CM_LOC_DTL F
															ON F.ID = E.LOCAT_ID
															INNER JOIN TB_CM_LOC_MST G
															ON G.ID = F.LOCAT_MST_ID
															LEFT OUTER JOIN #TEMP_INV_ANLY_PRIOD H
															ON F.ID = H.LOCAT_ID
															AND H.PERIOD_TP = 'DEMAND_PLAN'
													WHERE	1=1
													AND		A.T3SERIES_VER_ID = @V_DP_VER_ID
													AND		D.COMN_CD = 'FINAL_PRODUCT_GR_ITEM'
													AND     ISNULL(C.ACTV_YN, 'N') = 'Y'
													AND     ISNULL(E.ACTV_YN, 'N') = 'Y'
													AND		G.INV_POLICY_TARGET_YN = 'Y'
													AND		A.DUE_DATE BETWEEN H.START_DATE AND H.END_DATE
													) A
													INNER JOIN TB_CM_CALENDAR B
													ON B.DAT = A.DUE_DATE
											) A
									GROUP	BY SUPPLY_LOCAT_ITEM_ID, SUPPLY_LOCAT_ID, CONSUME_LOCAT_ITEM_ID, CONSUME_LOCAT_ID, ACCOUNT_ID, DAT
									) A
							GROUP	BY SUPPLY_LOCAT_ITEM_ID, SUPPLY_LOCAT_ID, DAT
							) A
							INNER JOIN
							(
							SELECT  A.LOCAT_ID, B.COMN_CD AS QUADRANT_BASE_CD
							FROM    TB_IM_DMND_VARIABILITY_BASE A, 
									TB_AD_COMN_CODE B
							WHERE   B.ID = A.QUADRANT_BASE_ID
							AND     ISNULL(A.ACTV_YN, 'N') = 'Y'
							) B
							ON B.LOCAT_ID = A.SUPPLY_LOCAT_ID
							LEFT OUTER JOIN #TEMP_INV_ANLY_PRIOD C
							ON C.LOCAT_ID = A.SUPPLY_LOCAT_ID
							AND C.PERIOD_TP = 'DEMAND_PLAN'
					) A
			GROUP	BY A.SUPPLY_LOCAT_ITEM_ID, A.SUPPLY_LOCAT_ID, A.DAT, A.BUCKET_CNT, A.CNT, A.SHPP_VAL
			) A
	GROUP	BY A.SUPPLY_LOCAT_ITEM_ID, A.AVG_SHPP_VAL

	INSERT INTO #TEMP_DMND_VARAN_ANLYS
	(
		LOCAT_ITEM_ID,
		DEVIT
	)
	SELECT	A.LOCAT_ITEM_ID,
			AVG(B.STDEV_VAL) AS DEVIT
	FROM	TB_IM_SITE_ITEM_SEG_SUMM A
			LEFT OUTER JOIN 
			(
			SELECT	LOCAT_ITEM_ID, STDEV_VAL
			FROM	#TEMP_ACTUAL_YOY_ANLY
			UNION	ALL
			SELECT	LOCAT_ITEM_ID, STDEV_VAL
			FROM	#TEMP_LAST_SHIPMENT_ANLY
			UNION	ALL
			SELECT	LOCAT_ITEM_ID, STDEV_VAL
			FROM	#TEMP_DMND_PLAN_ANLY
			) B
			ON A.LOCAT_ITEM_ID = B.LOCAT_ITEM_ID
	GROUP	BY A.LOCAT_ITEM_ID

	/***************************************************************************************************************************************************************************
	5. 안전재고
	 - 제안SL(%) : Configuration 목표 서비스 수준 산출 기준 으로 계산
	 - 목표 서비스 수준 산출 기준 : TB_IM_TARGET_SVC_CAL_BASE 테이블의 각 거점 별 목표 서비스 산출 기준에 따라 선택됨
		.COV 일 경우 수요 변동성 분석에서 서비스 수준 제안 값 (TB_IM_DMND_VARAN_ANLYS_MST.PRPSAL_SVC_LV_VAL)
		.SABC 일 경우 SABC 분석에서 서비스 수준 제안 값 (TB_IM_SABC_ANALYSIS_MST.PRPSAL_SVC_LV)

	 - 목표 SL(%) : 제안 SL 값과 동일값으로 등록 이후 사용자 변경 가능
	 - 수요변동 표준편차 : 수요변동성 분석의 표준편차 값 (TB_IM_DMND_VARAN_ANLYS_MST.DEVIT)
	 - 공급변동 표준편차 : 공급변동성 분석의 표준편차 값 (TB_IM_SPPLY_VARAN_ANLYS_MST.SUPPLY_LEADTIME_DEVIT)

	 - 수요율 : 거점 별로 선택된 수요율 산출 계산 방식에 따른 수요율 값
                Actual (All), Actual (YoY), Forecast (All), Forecast (Target)

	 - 제안 안전재고 : 수요변동성 고려 및 공급변동성 고려 체크 여부에 따라 안전재고 공식 기준으로 계산
	   [수요변동성만 고려 시]
	    => 안전계수 * SQRT(보충리드타임) * 수요변동성 표준편차
	       안전계수 : 목표 SL에 대해서 Configuration 안전재고 목표 서비스 수준 / 안전계수 기준 참조
           보충리드타임 : 목표재고 시스템(정기) : 공급리드타임 + 발주주기
                          주문점 시스템(비정기) : 공급리드타임
                          Min/Max 시스템(정기) : 공급리드타임 + 발주주기
                          Rule Based 시스템(비정기) : 공급리드타임

	   [공급변동성 고려 시]
	    => 안전계수 * SQRT(보충리드타임 * POWER(수요변동성 표준편차,2) + POWER(수요율,2) * POWER(공급리드타임 표준편차,2))

	 - 안전재고 : 제안 SL 값과 동일값으로 등록 이후 사용자 변경 가능
	***************************************************************************************************************************************************************************/
	CREATE TABLE #TEMP_SFST
	(
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		PRPSAL_SVC_LV				DECIMAL(20,3),
		SFST_SVC_LV					DECIMAL(20,3),
		SFST_DEMDVAR_CONSID_YN		CHAR(1),
		SFST_DEMDVAR_STDDEV			DECIMAL(20,3),
		SFST_SUPYVAR_CONSID_YN		CHAR(1),
		SFST_DMND_RATE_CAL_TP_ID	CHAR(32),
		SFST_DMND_RATE				DECIMAL(20,3),
		SUPYVAR_STDDEV				DECIMAL(20,3),
		SFST_PRPSAL_VAL				DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_PERIOD_SFST
	(
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT,
		STRT_DATE					DATETIME,
		END_DATE					DATETIME,
		SFST_DMND_RATE				DECIMAL(20,3),
		SFST_PRPSAL_VAL				DECIMAL(20,3),
		CONSTRAINT PK_TEMP_PERIOD_SFST PRIMARY KEY (LOCAT_ITEM_ID, STRT_DATE, END_DATE)
	)

	INSERT INTO #TEMP_SFST
	(
		LOCAT_ITEM_ID,
		PRPSAL_SVC_LV,
		SFST_SVC_LV,
		SFST_DEMDVAR_CONSID_YN,
		SFST_DEMDVAR_STDDEV,
		SFST_SUPYVAR_CONSID_YN,
		SFST_DMND_RATE_CAL_TP_ID,
		SFST_DMND_RATE,
		SUPYVAR_STDDEV,
		SFST_PRPSAL_VAL
	)
	SELECT	A.LOCAT_ITEM_ID,
			A.PRPSAL_SVC_LV,
			A.SFST_SVC_LV,
			A.SFST_DEMDVAR_CONSID_YN,
			A.SFST_DEMDVAR_STDDEV,
			A.SFST_SUPYVAR_CONSID_YN,
			A.SFST_DMND_RATE_CAL_TP_ID,
			A.SFST_DMND_RATE,
			A.SUPYVAR_STDDEV,
			CASE WHEN A.SFST_SUPYVAR_CONSID_YN = 'N' THEN A.SFST_PRPSAL_VAL_01 ELSE A.SFST_PRPSAL_VAL_02 END AS SFST_PRPSAL_VAL
	FROM	(
			SELECT	A.LOCAT_ITEM_ID,
					D.PRPSAL_SVC_LV,
					D.SFST_SVC_LV,
					D.SFST_DEMDVAR_CONSID_YN,
					ISNULL(G.DEVIT, 0) AS SFST_DEMDVAR_STDDEV,
					D.SFST_SUPYVAR_CONSID_YN,
					I.DMND_RATE_CAL_TP_ID AS SFST_DMND_RATE_CAL_TP_ID,
					ISNULL(I.DMND_RATE, 0)	AS SFST_DMND_RATE,
					ISNULL(H.SUPPLY_LEADTIME_DEVIT, 0) AS SUPYVAR_STDDEV,
					E.SAFTFCT * SQRT(F.REPLSH_LEADTIME) * ISNULL(G.DEVIT, 0) AS SFST_PRPSAL_VAL_01,
					E.SAFTFCT * SQRT(F.REPLSH_LEADTIME * POWER(ISNULL(G.DEVIT, 0), 2) + POWER(I.DMND_RATE, 2) * POWER(ISNULL(H.SUPPLY_LEADTIME_DEVIT,0), 2)) AS SFST_PRPSAL_VAL_02
			FROM	TB_IM_SITE_ITEM_SEG_SUMM A
					INNER JOIN TB_CM_SITE_ITEM B
					ON B.ID = A.LOCAT_ITEM_ID
					INNER JOIN TB_CM_LOC_MGMT C
					ON C.ID = B.LOCAT_MGMT_ID
					LEFT OUTER JOIN TB_IM_INV_POLICY_MST D
					ON D.LOCAT_ID = C.LOCAT_ID
					LEFT OUTER JOIN TB_IM_SVC_SAFTFCT_BASE E
					ON E.SVC_LV = ISNULL(D.SFST_SVC_LV, D.PRPSAL_SVC_LV)
					LEFT OUTER JOIN #TEMP_OPERT_TARGET F
					ON F.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_DMND_VARAN_ANLYS G
					ON G.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					LEFT OUTER JOIN TB_IM_SPPLY_VARAN_ANLYS_MST H
					ON H.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_DMND_RATE I
					ON I.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			WHERE	1=1
			AND		ISNULL(A.VAL_01, '') = IIF(D.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(D.VAL_01, ''))
			AND		ISNULL(A.VAL_02, '') = IIF(D.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(D.VAL_02, ''))
			) A

	INSERT INTO #TEMP_PERIOD_SFST
	(
		LOCAT_ITEM_ID,
		STRT_DATE,
		END_DATE,
		SFST_DMND_RATE,
		SFST_PRPSAL_VAL
	)
	SELECT	A.LOCAT_ITEM_ID,
			A.STRT_DATE,
			A.END_DATE,
			A.SFST_DMND_RATE,
			CASE WHEN A.SFST_SUPYVAR_CONSID_YN = 'N' THEN A.SFST_PRPSAL_VAL_01 ELSE A.SFST_PRPSAL_VAL_02 END AS SFST_PRPSAL_VAL
	FROM	(
			SELECT	A.LOCAT_ITEM_ID,
					I.STRT_DATE,
					I.END_DATE,
					D.SFST_SUPYVAR_CONSID_YN,
					ISNULL(I.DMND_RATE, 0)	AS SFST_DMND_RATE,
					E.SAFTFCT * SQRT(F.REPLSH_LEADTIME) * ISNULL(G.DEVIT, 0) AS SFST_PRPSAL_VAL_01,
					E.SAFTFCT * SQRT(F.REPLSH_LEADTIME * POWER(ISNULL(G.DEVIT, 0), 2) + POWER(ISNULL(I.DMND_RATE, 0), 2) + POWER(ISNULL(H.SUPPLY_LEADTIME_DEVIT,0), 2)) AS SFST_PRPSAL_VAL_02
			FROM	TB_IM_SITE_ITEM_SEG_SUMM A
					INNER JOIN TB_CM_SITE_ITEM B
					ON B.ID = A.LOCAT_ITEM_ID
					INNER JOIN TB_CM_LOC_MGMT C
					ON C.ID = B.LOCAT_MGMT_ID
					LEFT OUTER JOIN TB_IM_INV_POLICY_MST D
					ON D.LOCAT_ID = C.LOCAT_ID
					LEFT OUTER JOIN TB_IM_SVC_SAFTFCT_BASE E
					ON E.SVC_LV = ISNULL(D.SFST_SVC_LV, D.PRPSAL_SVC_LV)
					LEFT OUTER JOIN #TEMP_OPERT_TARGET F
					ON F.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_DMND_VARAN_ANLYS G
					ON G.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					LEFT OUTER JOIN TB_IM_SPPLY_VARAN_ANLYS_MST H
					ON H.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					INNER JOIN #TEMP_PERIOD_DMND_RATE I
					ON I.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			WHERE	1=1
			AND		ISNULL(A.VAL_01, '') = IIF(D.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(D.VAL_01, ''))
			AND		ISNULL(A.VAL_02, '') = IIF(D.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(D.VAL_02, ''))
			) A

	/***************************************************************************************************************************************************************************
	6. 운영재고
	 - 제안 운영재고 : 운영목표 * 수요율
	 - 운영재고 : 제안 운영재고 값과 동일값으로 등록 이후 사용자 변경 가능
	***************************************************************************************************************************************************************************/
	CREATE TABLE #TEMP_OPERT_INV 
	(
		LOCAT_ITEM_ID						CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		OPERT_INV_DMND_RATE_CAL_MTD_ID		CHAR(32),
		OPERT_INV_DMND_RATE					DECIMAL(20,3),
		OPERT_INV_PRPSAL_VAL				DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_PERIOD_OPERT_INV 
	(
		LOCAT_ITEM_ID						CHAR(32) COLLATE DATABASE_DEFAULT,
		STRT_DATE							DATETIME,
		END_DATE							DATETIME,
		OPERT_INV_DMND_RATE					DECIMAL(20,3),
		OPERT_INV_PRPSAL_VAL				DECIMAL(20,3),
		CONSTRAINT PK_TEMP_PERIOD_OPERT_INV PRIMARY KEY (LOCAT_ITEM_ID, STRT_DATE, END_DATE)
	)

	INSERT INTO #TEMP_OPERT_INV
	(
		LOCAT_ITEM_ID,
		OPERT_INV_DMND_RATE_CAL_MTD_ID,
		OPERT_INV_DMND_RATE,
		OPERT_INV_PRPSAL_VAL
	)
	SELECT	A.LOCAT_ITEM_ID,
			B.DMND_RATE_CAL_TP_ID AS OPERT_INV_DMND_RATE_CAL_MTD_ID,
			B.DMND_RATE AS OPERT_INV_DMND_RATE,
			A.OPERT_TARGET_VAL * B.DMND_RATE AS OPERT_INV_PRPSAL_VAL
	FROM	#TEMP_OPERT_TARGET A
			INNER JOIN #TEMP_DMND_RATE B
			ON B.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID

	INSERT INTO #TEMP_PERIOD_OPERT_INV
	(
		LOCAT_ITEM_ID,
		STRT_DATE,
		END_DATE,
		OPERT_INV_DMND_RATE,
		OPERT_INV_PRPSAL_VAL
	)
	SELECT	A.LOCAT_ITEM_ID,
			B.STRT_DATE,
			B.END_DATE,
			B.DMND_RATE AS OPERT_INV_DMND_RATE,
			A.OPERT_TARGET_VAL * B.DMND_RATE AS OPERT_INV_PRPSAL_VAL
	FROM	#TEMP_OPERT_TARGET A
			INNER JOIN #TEMP_PERIOD_DMND_RATE B
			ON B.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID

	/***************************************************************************************************************************************************************************
	7. EOQ 
	 - EOQ 계산 방식
	   EOQDR01	EOQ (경제적 주문량)
	   EOQDR02	평균 발주량

	 - EOQ
	  .제안 EOQ : EOQ 계산 공식에 의해 계산
	       - SQRT(2 * 연간소요량 * 1회 발주비) / (제품 단가*재고유지비율) or SQRT(2 * 연간소요량 * 주문비용) / 재고보관비용
		   - 연간 소요량은 FORECAST ALL 값으로 함
	   .EOQ : 제안 EOQ 값과 동일값으로 등록 이후 사용자 변경 가능
  
	 - 평균 발주량
	   .제안 EOQ : Actual (ALL) 과거 실적 기준으로 1회 평균 발주량 제시 (전체 실적의 총 평균)

	 - 정률이 체크된 경우
	  .제안 EOQ : 수요율 * 정률 Target
	   - 정률 Target : EOQ / (Time Bucket이 Day이면 일평균 출하실적, Time Bucket이 Week이면 주평균 출하실적, Time Bucket이 Month이면 월평균 출하실적)
	  .EOQ : 제안 EOQ 값과 동일값으로 등록 이후 사용자 변경 가능
	***************************************************************************************************************************************************************************/
	CREATE TABLE #TEMP_EOQ
	(
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		EOQ_CAL_TP_ID				CHAR(32),
		EOQ_DMND_RATE_CAL_MTD_ID	CHAR(32),
		EOQ_DMND_RATE				DECIMAL(20,3),
		EOQ_RIGHT_RATE_TARGET		DECIMAL(20,3),
		EOQ_RIGHT_RATE_YN			CHAR(1),
		EOQ_PRPSAL_VAL				DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_PERIOD_EOQ
	(
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT,
		STRT_DATE					DATETIME,
		END_DATE					DATETIME,
		EOQ_DMND_RATE				DECIMAL(20,3),
		EOQ_RIGHT_RATE_TARGET		DECIMAL(20,3),
		EOQ_PRPSAL_VAL				DECIMAL(20,3),
		CONSTRAINT PK_TEMP_PERIOD_EOQ PRIMARY KEY (LOCAT_ITEM_ID, STRT_DATE, END_DATE)
	)

	INSERT INTO #TEMP_EOQ
	(
		LOCAT_ITEM_ID,
		EOQ_CAL_TP_ID,
		EOQ_DMND_RATE_CAL_MTD_ID,
		EOQ_DMND_RATE,
		EOQ_RIGHT_RATE_YN,
		EOQ_RIGHT_RATE_TARGET,
		EOQ_PRPSAL_VAL
	)
	SELECT	A.LOCAT_ITEM_ID,
			A.EOQ_CAL_TP_ID,
			A.DMND_RATE_CAL_TP_ID,
			A.DMND_RATE,
			A.EOQ_RIGHT_RATE_YN,
			CASE WHEN A.EOQ_CAL_TP_CD = 'EOQDR01' THEN ISNULL(A.EOQ_RIGHT_RATE_TARGET, 0) ELSE ISNULL(A.AVG_PO_RIGHT_RATE_TARGET, 0) END AS EOQ_RIGHT_RATE_TARGET,
			CASE WHEN A.EOQ_CAL_TP_CD = 'EOQDR01' AND A.EOQ_RIGHT_RATE_YN = 'N' THEN A.EOQ * EOQ_MULTIPLE
			     WHEN A.EOQ_CAL_TP_CD = 'EOQDR01' AND A.EOQ_RIGHT_RATE_YN = 'Y' THEN ISNULL(A.DMND_RATE, 0) * ISNULL(A.EOQ_RIGHT_RATE_TARGET, 0)
				 WHEN A.EOQ_CAL_TP_CD = 'EOQDR02' AND A.EOQ_RIGHT_RATE_YN = 'N' THEN A.AVG_PO_QTY * EOQ_MULTIPLE
				 WHEN A.EOQ_CAL_TP_CD = 'EOQDR02' AND A.EOQ_RIGHT_RATE_YN = 'Y' THEN ISNULL(A.DMND_RATE, 0) * ISNULL(A.AVG_PO_RIGHT_RATE_TARGET, 0)
				 ELSE NULL
			END AS EOQ_PRPSAL_VAL
	FROM	(
			SELECT	A.LOCAT_ITEM_ID,
					D.EOQ_CAL_TP_ID,
					E.COMN_CD AS EOQ_CAL_TP_CD,
					I.DMND_RATE_CAL_TP_ID,
					I.DMND_RATE,
					F.EOQ AS EOQ,
					G.QTY AS AVG_PO_QTY,
					CASE WHEN ISNULL(H.QTY, 0) = 0 THEN 0 ELSE ROUND((ISNULL(F.EOQ, 0) * ISNULL(D.EOQ_MULTIPLE, 1)) / H.QTY, 3) END AS EOQ_RIGHT_RATE_TARGET,
					CASE WHEN ISNULL(H.QTY, 0) = 0 THEN 0 ELSE ROUND((ISNULL(G.QTY, 0) * ISNULL(D.EOQ_MULTIPLE, 1)) / H.QTY, 3) END AS AVG_PO_RIGHT_RATE_TARGET,
					D.EOQ_RIGHT_RATE_YN,
					ISNULL(D.EOQ_MULTIPLE, 1) AS EOQ_MULTIPLE
			FROM	TB_IM_SITE_ITEM_SEG_SUMM A
					INNER JOIN TB_CM_SITE_ITEM B
					ON B.ID = A.LOCAT_ITEM_ID
					INNER JOIN TB_CM_LOC_MGMT C
					ON C.ID = B.LOCAT_MGMT_ID
					LEFT OUTER JOIN TB_IM_INV_POLICY_MST D
					ON D.LOCAT_ID = C.LOCAT_ID
					LEFT OUTER JOIN TB_AD_COMN_CODE E
					ON E.ID = D.EOQ_CAL_TP_ID
					LEFT OUTER JOIN 
					(
					SELECT	A.LOCAT_ITEM_ID,
							CASE WHEN ISNULL(A.INV_KEEPING_VAL ,0) = 0 THEN 0
								 ELSE SQRT((2 * ISNULL(B.QTY, 0) * ISNULL(A.ORDER_COST_VAL, 0)) / ISNULL(A.INV_KEEPING_VAL, 0))
							END AS EOQ
					FROM	TB_IM_INV_COST A
							LEFT OUTER JOIN #TEMP_DMND_RATE_FORECAST_ALL B
							ON B.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					) F
					ON F.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_DMND_RATE_ACTUAL_ALL G
					ON G.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_DMND_RATE_ACTUAL_ALL H
					ON H.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_DMND_RATE I
					ON I.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			WHERE	1=1
			AND		ISNULL(A.VAL_01, '') = IIF(D.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(D.VAL_01, ''))
			AND		ISNULL(A.VAL_02, '') = IIF(D.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(D.VAL_02, ''))
			) A

	INSERT INTO #TEMP_PERIOD_EOQ
	(
		LOCAT_ITEM_ID,
		STRT_DATE,
		END_DATE,
		EOQ_DMND_RATE,
		EOQ_RIGHT_RATE_TARGET,
		EOQ_PRPSAL_VAL
	)
	SELECT	A.LOCAT_ITEM_ID,
			A.STRT_DATE,
			A.END_DATE,
			A.DMND_RATE,
			CASE WHEN A.EOQ_CAL_TP_CD = 'EOQDR01' THEN ISNULL(A.EOQ_RIGHT_RATE_TARGET, 0) ELSE ISNULL(A.AVG_PO_RIGHT_RATE_TARGET, 0) END AS EOQ_RIGHT_RATE_TARGET,
			CASE WHEN A.EOQ_CAL_TP_CD = 'EOQDR01' AND A.EOQ_RIGHT_RATE_YN = 'N' THEN A.EOQ * EOQ_MULTIPLE
			     WHEN A.EOQ_CAL_TP_CD = 'EOQDR01' AND A.EOQ_RIGHT_RATE_YN = 'Y' THEN ISNULL(A.DMND_RATE, 0) * ISNULL(A.EOQ_RIGHT_RATE_TARGET, 0)
				 WHEN A.EOQ_CAL_TP_CD = 'EOQDR02' AND A.EOQ_RIGHT_RATE_YN = 'N' THEN A.AVG_PO_QTY * EOQ_MULTIPLE
				 WHEN A.EOQ_CAL_TP_CD = 'EOQDR02' AND A.EOQ_RIGHT_RATE_YN = 'Y' THEN ISNULL(A.DMND_RATE, 0) * ISNULL(A.AVG_PO_RIGHT_RATE_TARGET, 0)
				 ELSE NULL
			END AS EOQ_PRPSAL_VAL
	FROM	(
			SELECT	A.LOCAT_ITEM_ID,
					I.STRT_DATE,
					I.END_DATE,
					E.COMN_CD AS EOQ_CAL_TP_CD,
					D.EOQ_RIGHT_RATE_YN,
					D.EOQ_MULTIPLE,
					I.DMND_RATE,
					F.EOQ AS EOQ,
					G.QTY AS AVG_PO_QTY,
					CASE WHEN ISNULL(H.QTY, 0) = 0 THEN 0 ELSE ROUND((ISNULL(F.EOQ, 0) * ISNULL(D.EOQ_MULTIPLE, 1)) / H.QTY, 3) END AS EOQ_RIGHT_RATE_TARGET,
					CASE WHEN ISNULL(H.QTY, 0) = 0 THEN 0 ELSE ROUND((ISNULL(G.QTY, 0) * ISNULL(D.EOQ_MULTIPLE, 1)) / H.QTY, 3) END AS AVG_PO_RIGHT_RATE_TARGET
			FROM	TB_IM_SITE_ITEM_SEG_SUMM A
					INNER JOIN TB_CM_SITE_ITEM B
					ON B.ID = A.LOCAT_ITEM_ID
					INNER JOIN TB_CM_LOC_MGMT C
					ON C.ID = B.LOCAT_MGMT_ID
					LEFT OUTER JOIN TB_IM_INV_POLICY_MST D
					ON D.LOCAT_ID = C.LOCAT_ID
					LEFT OUTER JOIN TB_AD_COMN_CODE E
					ON E.ID = D.EOQ_CAL_TP_ID
					LEFT OUTER JOIN 
					(
					SELECT	A.LOCAT_ITEM_ID,
							CASE WHEN ISNULL(A.INV_KEEPING_VAL ,0) = 0 THEN 0
								 ELSE SQRT((2 * ISNULL(B.QTY, 0) * ISNULL(A.ORDER_COST_VAL, 0)) / ISNULL(A.INV_KEEPING_VAL, 0))
							END AS EOQ
					FROM	TB_IM_INV_COST A
							LEFT OUTER JOIN #TEMP_DMND_RATE_FORECAST_ALL B
							ON B.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					) F
					ON F.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_DMND_RATE_ACTUAL_ALL G
					ON G.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_DMND_RATE_ACTUAL_ALL H
					ON H.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					INNER JOIN #TEMP_PERIOD_DMND_RATE I
					ON I.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			WHERE	1=1
			AND		ISNULL(A.VAL_01, '') = IIF(D.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(D.VAL_01, ''))
			AND		ISNULL(A.VAL_02, '') = IIF(D.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(D.VAL_02, ''))
			) A

	/***************************************************************************************************************************************************************************
	8. ROP
	 - ROP 계산 방식
	   ROPDR01	정규성
	   ROPDR02	평균 출하
	   ROPDR03	최대 출하
	   ROPDR04	최소 출하
	   ROPDR05	평균 재고

	 - 정규성
	  .제안ROP : (체크된) 안전재고 + (체크된) 운영재고
	  .ROP : 제안 ROP 값과 동일값으로 등록 이후 사용자 변경 가능

	 - 평균재고
	  .제안ROP : (Warehouse Stock + In-Transit Stock) - 발주량 / 2
	  .ROP : 제안 ROP 값과 동일값으로 등록 이후 사용자 변경 가능
  
	 - 평균/최대/최소 출하
	  .제안ROP : 과거 실적 구간에서 평균, 최대, 최소 출하 량으로 단순 계산함
	  .ROP : 제안 ROP 값과 동일값으로 등록 이후 사용자 변경 가능

	 - 정률이 체크된 경우
	  .제안 ROP : 수요율 * 정률 Target
	   - 정률 Target : ROP / (Time Bucket이 Day이면 일평균 출하실적, Time Bucket이 Week이면 주평균 출하실적, Time Bucket이 Month이면 월평균 출하실적)
	  .ROP : 제안 ROP 값과 동일값으로 등록 이후 사용자 변경 가능
	***************************************************************************************************************************************************************************/
	CREATE TABLE #TEMP_STD_ROP
	(
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		STD_ROP						DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_AVG_INV
	(
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		AVG_INV_QTY					DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_ROP
	(
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		ROP_CAL_TP_ID				CHAR(32),
		ROP_SFST_CONSID_YN			CHAR(1),
		ROP_OPERT_INV_CONSID_YN		CHAR(1),
		ROP_RIGHT_RATE_YN			CHAR(1),
		ROP_DMND_RATE_CAL_MTD_ID	CHAR(32),
		ROP_DMND_RATE				DECIMAL(20,3),
		ROP_RIGHT_RATE_TARGET		DECIMAL(20,3),
		ROP_PRPSAL_VAL				DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_PERIOD_STD_ROP
	(
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT,
		STRT_DATE					DATETIME,
		END_DATE					DATETIME,
		STD_ROP						DECIMAL(20,3),
		CONSTRAINT PK_TEMP_PERIOD_STD_ROP PRIMARY KEY (LOCAT_ITEM_ID, STRT_DATE, END_DATE)
	)

	CREATE TABLE #TEMP_PERIOD_ROP
	(
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT,
		STRT_DATE					DATETIME,
		END_DATE					DATETIME,
		ROP_DMND_RATE				DECIMAL(20,3),
		ROP_RIGHT_RATE_TARGET		DECIMAL(20,3),
		ROP_PRPSAL_VAL				DECIMAL(20,3),
		CONSTRAINT PK_TEMP_PERIOD_ROP PRIMARY KEY (LOCAT_ITEM_ID, STRT_DATE, END_DATE)
	)

	INSERT INTO #TEMP_STD_ROP
	(
		LOCAT_ITEM_ID,
		STD_ROP
	)
	SELECT	A.LOCAT_ITEM_ID,
		    CASE WHEN D.ROP_OPERT_INV_CONSID_YN = 'Y' AND D.ROP_SFST_CONSID_YN = 'Y'  THEN E.OPERT_INV_PRPSAL_VAL + F.SFST_PRPSAL_VAL
				 WHEN D.ROP_OPERT_INV_CONSID_YN = 'Y' AND D.ROP_SFST_CONSID_YN = 'N'  THEN E.OPERT_INV_PRPSAL_VAL
				 WHEN D.ROP_OPERT_INV_CONSID_YN = 'N' AND D.ROP_SFST_CONSID_YN = 'Y'  THEN F.SFST_PRPSAL_VAL
			ELSE NULL
			END STD_ROP
	FROM	TB_IM_SITE_ITEM_SEG_SUMM A
			INNER JOIN TB_CM_SITE_ITEM B
			ON B.ID = A.LOCAT_ITEM_ID
			INNER JOIN TB_CM_LOC_MGMT C
			ON C.ID = B.LOCAT_MGMT_ID
			LEFT OUTER JOIN TB_IM_INV_POLICY_MST D
			ON D.LOCAT_ID = C.LOCAT_ID
			LEFT OUTER JOIN #TEMP_OPERT_INV E
			ON E.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			LEFT OUTER JOIN #TEMP_SFST F
			ON F.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
	WHERE	1=1
	AND		ISNULL(A.VAL_01, '') = IIF(D.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(D.VAL_01, ''))
	AND		ISNULL(A.VAL_02, '') = IIF(D.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(D.VAL_02, ''))

	INSERT INTO #TEMP_AVG_INV
	(
		LOCAT_ITEM_ID,
		AVG_INV_QTY
	)
	SELECT	A.LOCAT_ITEM_ID, 
			CASE WHEN A.AVG_INV_QTY > 0 THEN A.AVG_INV_QTY ELSE 0 END AS AVG_INV_QTY
	FROM	(
			SELECT	A.LOCAT_ITEM_ID,
					(ISNULL(B.QTY, 0) + ISNULL(C.QTY, 0)) - (ISNULL(D.EOQ_PRPSAL_VAL, 0) / 2) AS AVG_INV_QTY
			FROM	TB_IM_SITE_ITEM_SEG_SUMM A
					LEFT OUTER JOIN #TEMP_WAREHOUSE_STOCK B
					ON B.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_INTRANSIT_STOCK C
					ON C.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_EOQ D
					ON D.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			) A

	INSERT INTO #TEMP_ROP
	(
		LOCAT_ITEM_ID,
		ROP_CAL_TP_ID,
		ROP_SFST_CONSID_YN,
		ROP_OPERT_INV_CONSID_YN,
		ROP_RIGHT_RATE_YN,
		ROP_DMND_RATE_CAL_MTD_ID,
		ROP_DMND_RATE,
		ROP_RIGHT_RATE_TARGET,
		ROP_PRPSAL_VAL
	)
	SELECT	A.LOCAT_ITEM_ID,
			D.ROP_CAL_TP_ID,
			D.ROP_SFST_CONSID_YN,
			D.ROP_OPERT_INV_CONSID_YN,
			D.ROP_RIGHT_RATE_YN,
			I.DMND_RATE_CAL_TP_ID,
			I.DMND_RATE,
			CASE WHEN E.COMN_CD = 'ROPDR01' THEN IIF(H.QTY = 0, 0, ISNULL(F.STD_ROP, 0)     / H.QTY)
			     WHEN E.COMN_CD = 'ROPDR02' THEN IIF(H.QTY = 0, 0, ISNULL(H.QTY, 0)         / H.QTY)
				 WHEN E.COMN_CD = 'ROPDR03' THEN IIF(H.QTY = 0, 0, ISNULL(H.MAX_QTY, 0)     / H.QTY)
				 WHEN E.COMN_CD = 'ROPDR04' THEN IIF(H.QTY = 0, 0, ISNULL(H.MIN_QTY, 0)     / H.QTY)
				 WHEN E.COMN_CD = 'ROPDR05' THEN IIF(H.QTY = 0, 0, ISNULL(G.AVG_INV_QTY, 0) / H.QTY)
				 ELSE NULL
			END AS ROP_RIGHT_RATE_TARGET,
			CASE WHEN E.COMN_CD = 'ROPDR01' AND D.ROP_RIGHT_RATE_YN = 'N' THEN F.STD_ROP
			     WHEN E.COMN_CD = 'ROPDR01' AND D.ROP_RIGHT_RATE_YN = 'Y' THEN I.DMND_RATE * (IIF(H.QTY = 0, 0, ISNULL(F.STD_ROP, 0) / H.QTY))
				 WHEN E.COMN_CD = 'ROPDR02' AND D.ROP_RIGHT_RATE_YN = 'N' THEN H.QTY
			     WHEN E.COMN_CD = 'ROPDR02' AND D.ROP_RIGHT_RATE_YN = 'Y' THEN I.DMND_RATE * (IIF(H.QTY = 0, 0, ISNULL(H.QTY, 0) / H.QTY))
				 WHEN E.COMN_CD = 'ROPDR03' AND D.ROP_RIGHT_RATE_YN = 'N' THEN H.MAX_QTY
			     WHEN E.COMN_CD = 'ROPDR03' AND D.ROP_RIGHT_RATE_YN = 'Y' THEN I.DMND_RATE * (IIF(H.QTY = 0, 0, ISNULL(H.MAX_QTY, 0) / H.QTY))
				 WHEN E.COMN_CD = 'ROPDR04' AND D.ROP_RIGHT_RATE_YN = 'N' THEN H.MIN_QTY
			     WHEN E.COMN_CD = 'ROPDR04' AND D.ROP_RIGHT_RATE_YN = 'Y' THEN I.DMND_RATE * (IIF(H.QTY = 0, 0, ISNULL(H.MIN_QTY, 0)/ H.QTY))
				 WHEN E.COMN_CD = 'ROPDR05' AND D.ROP_RIGHT_RATE_YN = 'N' THEN G.AVG_INV_QTY
			     WHEN E.COMN_CD = 'ROPDR05' AND D.ROP_RIGHT_RATE_YN = 'Y' THEN I.DMND_RATE * (IIF(H.QTY = 0, 0, ISNULL(G.AVG_INV_QTY, 0) / H.QTY))
				 ELSE NULL
			END AS ROP_PRPSAL_VAL
	FROM	TB_IM_SITE_ITEM_SEG_SUMM A
			INNER JOIN TB_CM_SITE_ITEM B
			ON B.ID = A.LOCAT_ITEM_ID
			INNER JOIN TB_CM_LOC_MGMT C
			ON C.ID = B.LOCAT_MGMT_ID
			LEFT OUTER JOIN TB_IM_INV_POLICY_MST D
			ON D.LOCAT_ID = C.LOCAT_ID
			LEFT OUTER JOIN TB_AD_COMN_CODE E
			ON E.ID = D.ROP_CAL_TP_ID
			LEFT OUTER JOIN #TEMP_STD_ROP F
			ON F.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			LEFT OUTER JOIN #TEMP_STOCK_INFO G
			ON G.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			LEFT OUTER JOIN #TEMP_DMND_RATE_ACTUAL_ALL H
			ON H.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			LEFT OUTER JOIN #TEMP_DMND_RATE I
			ON I.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
	WHERE	1=1
	AND		ISNULL(A.VAL_01, '') = IIF(D.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(D.VAL_01, ''))
	AND		ISNULL(A.VAL_02, '') = IIF(D.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(D.VAL_02, ''))

	INSERT INTO #TEMP_PERIOD_STD_ROP
	(
		LOCAT_ITEM_ID,
		STRT_DATE,
		END_DATE,
		STD_ROP
	)
	SELECT	A.LOCAT_ITEM_ID,
			E.STRT_DATE,
			E.END_DATE,
		    CASE WHEN D.ROP_OPERT_INV_CONSID_YN = 'Y' AND D.ROP_SFST_CONSID_YN = 'Y'  THEN F.OPERT_INV_PRPSAL_VAL + G.SFST_PRPSAL_VAL
				 WHEN D.ROP_OPERT_INV_CONSID_YN = 'Y' AND D.ROP_SFST_CONSID_YN = 'N'  THEN F.OPERT_INV_PRPSAL_VAL
				 WHEN D.ROP_OPERT_INV_CONSID_YN = 'N' AND D.ROP_SFST_CONSID_YN = 'Y'  THEN G.SFST_PRPSAL_VAL
			ELSE NULL
			END STD_ROP
	FROM	TB_IM_SITE_ITEM_SEG_SUMM A
			INNER JOIN TB_CM_SITE_ITEM B
			ON B.ID = A.LOCAT_ITEM_ID
			INNER JOIN TB_CM_LOC_MGMT C
			ON C.ID = B.LOCAT_MGMT_ID
			LEFT OUTER JOIN TB_IM_INV_POLICY_MST D
			ON D.LOCAT_ID = C.LOCAT_ID
			INNER JOIN #TEMP_PERIOD_DMND_RATE E
			ON E.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			LEFT OUTER JOIN #TEMP_PERIOD_OPERT_INV F
			ON (F.LOCAT_ITEM_ID = E.LOCAT_ITEM_ID AND F.STRT_DATE = E.STRT_DATE AND F.END_DATE = E.END_DATE)
			LEFT OUTER JOIN #TEMP_PERIOD_SFST G
			ON (G.LOCAT_ITEM_ID = E.LOCAT_ITEM_ID AND G.STRT_DATE = E.STRT_DATE AND G.END_DATE = E.END_DATE)
	WHERE	1=1
	AND		ISNULL(A.VAL_01, '') = IIF(D.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(D.VAL_01, ''))
	AND		ISNULL(A.VAL_02, '') = IIF(D.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(D.VAL_02, ''))

	INSERT INTO #TEMP_PERIOD_ROP
	(
		LOCAT_ITEM_ID,
		STRT_DATE,
		END_DATE,
		ROP_DMND_RATE,
		ROP_RIGHT_RATE_TARGET,
		ROP_PRPSAL_VAL
	)
	SELECT	A.LOCAT_ITEM_ID,
			I.STRT_DATE,
			I.END_DATE,
			I.DMND_RATE,
			CASE WHEN E.COMN_CD = 'ROPDR01' THEN IIF(H.QTY = 0, 0, ISNULL(F.STD_ROP, 0)     / H.QTY)
			     WHEN E.COMN_CD = 'ROPDR02' THEN IIF(H.QTY = 0, 0, ISNULL(H.QTY, 0)         / H.QTY)
				 WHEN E.COMN_CD = 'ROPDR03' THEN IIF(H.QTY = 0, 0, ISNULL(H.MAX_QTY, 0)     / H.QTY)
				 WHEN E.COMN_CD = 'ROPDR04' THEN IIF(H.QTY = 0, 0, ISNULL(H.MIN_QTY, 0)     / H.QTY)
				 WHEN E.COMN_CD = 'ROPDR05' THEN IIF(H.QTY = 0, 0, ISNULL(G.AVG_INV_QTY, 0) / H.QTY)
				 ELSE NULL
			END AS ROP_RIGHT_RATE_TARGET,
			CASE WHEN E.COMN_CD = 'ROPDR01' AND D.ROP_RIGHT_RATE_YN = 'N' THEN F.STD_ROP
			     WHEN E.COMN_CD = 'ROPDR01' AND D.ROP_RIGHT_RATE_YN = 'Y' THEN I.DMND_RATE * (IIF(H.QTY = 0, 0, ISNULL(F.STD_ROP, 0) / H.QTY))
				 WHEN E.COMN_CD = 'ROPDR02' AND D.ROP_RIGHT_RATE_YN = 'N' THEN H.QTY
			     WHEN E.COMN_CD = 'ROPDR02' AND D.ROP_RIGHT_RATE_YN = 'Y' THEN I.DMND_RATE * (IIF(H.QTY = 0, 0, ISNULL(H.QTY, 0) / H.QTY))
				 WHEN E.COMN_CD = 'ROPDR03' AND D.ROP_RIGHT_RATE_YN = 'N' THEN H.MAX_QTY
			     WHEN E.COMN_CD = 'ROPDR03' AND D.ROP_RIGHT_RATE_YN = 'Y' THEN I.DMND_RATE * (IIF(H.QTY = 0, 0, ISNULL(H.MAX_QTY, 0) / H.QTY))
				 WHEN E.COMN_CD = 'ROPDR04' AND D.ROP_RIGHT_RATE_YN = 'N' THEN H.MIN_QTY
			     WHEN E.COMN_CD = 'ROPDR04' AND D.ROP_RIGHT_RATE_YN = 'Y' THEN I.DMND_RATE * (IIF(H.QTY = 0, 0, ISNULL(H.MIN_QTY, 0)/ H.QTY))
				 WHEN E.COMN_CD = 'ROPDR05' AND D.ROP_RIGHT_RATE_YN = 'N' THEN G.AVG_INV_QTY
			     WHEN E.COMN_CD = 'ROPDR05' AND D.ROP_RIGHT_RATE_YN = 'Y' THEN I.DMND_RATE * (IIF(H.QTY = 0, 0, ISNULL(G.AVG_INV_QTY, 0) / H.QTY))
				 ELSE NULL
			END AS ROP_PRPSAL_VAL
	FROM	TB_IM_SITE_ITEM_SEG_SUMM A
			INNER JOIN TB_CM_SITE_ITEM B
			ON B.ID = A.LOCAT_ITEM_ID
			INNER JOIN TB_CM_LOC_MGMT C
			ON C.ID = B.LOCAT_MGMT_ID
			LEFT OUTER JOIN TB_IM_INV_POLICY_MST D
			ON D.LOCAT_ID = C.LOCAT_ID
			LEFT OUTER JOIN TB_AD_COMN_CODE E
			ON E.ID = D.ROP_CAL_TP_ID
			LEFT OUTER JOIN #TEMP_STOCK_INFO G
			ON G.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			LEFT OUTER JOIN #TEMP_DMND_RATE_ACTUAL_ALL H
			ON H.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			INNER JOIN #TEMP_PERIOD_DMND_RATE I
			ON I.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			LEFT OUTER JOIN #TEMP_PERIOD_STD_ROP F
			ON (F.LOCAT_ITEM_ID = I.LOCAT_ITEM_ID AND F.STRT_DATE = I.STRT_DATE AND F.END_DATE = I.END_DATE)
	WHERE	1=1
	AND		ISNULL(A.VAL_01, '') = IIF(D.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(D.VAL_01, ''))
	AND		ISNULL(A.VAL_02, '') = IIF(D.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(D.VAL_02, ''))

	/***************************************************************************************************************************************************************************
	9. 목표재고
	 - 제안 목표재고 : (체크된) 안전재고 + (체크된) 운영재고
	 - 목표재고 : 제안 목표재고값과 동일값으로 등록 이후 사용자 변경 가능
	***************************************************************************************************************************************************************************/
	CREATE TABLE #TEMP_TARGET_INV
	(
		LOCAT_ITEM_ID						CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
		TARGET_INV_SFST_CONSID_YN			CHAR(1),
		TARGET_INV_OPERT_INV_CONSID_YN		CHAR(1),
		TARGET_INV_PRPSAL_VAL				DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_PERIOD_TARGET_INV
	(
		LOCAT_ITEM_ID						CHAR(32) COLLATE DATABASE_DEFAULT,
		STRT_DATE							DATETIME,
		END_DATE							DATETIME,
		TARGET_INV_PRPSAL_VAL				DECIMAL(20,3),
		CONSTRAINT PK_TEMP_PERIOD_TARGET_INV PRIMARY KEY (LOCAT_ITEM_ID, STRT_DATE, END_DATE)
	)

	INSERT INTO #TEMP_TARGET_INV
	(
		LOCAT_ITEM_ID, 
		TARGET_INV_SFST_CONSID_YN,
		TARGET_INV_OPERT_INV_CONSID_YN,
		TARGET_INV_PRPSAL_VAL
	)
	SELECT	A.LOCAT_ITEM_ID,
			D.TARGET_INV_SFST_CONSID_YN,
			D.TARGET_INV_OPERT_INV_CONSID_YN,
			CASE WHEN D.TARGET_INV_SFST_CONSID_YN = 'Y' AND D.TARGET_INV_OPERT_INV_CONSID_YN = 'N' THEN F.SFST_PRPSAL_VAL
			     WHEN D.TARGET_INV_SFST_CONSID_YN = 'N' AND D.TARGET_INV_OPERT_INV_CONSID_YN = 'Y' THEN E.OPERT_INV_PRPSAL_VAL
				 WHEN D.TARGET_INV_SFST_CONSID_YN = 'Y' AND D.TARGET_INV_OPERT_INV_CONSID_YN = 'Y' THEN E.OPERT_INV_PRPSAL_VAL + F.SFST_PRPSAL_VAL
				 ELSE NULL
			END AS TARGET_INV_PRPSAL_VAL
	FROM	TB_IM_SITE_ITEM_SEG_SUMM A
			INNER JOIN TB_CM_SITE_ITEM B
			ON B.ID = A.LOCAT_ITEM_ID
			INNER JOIN TB_CM_LOC_MGMT C
			ON C.ID = B.LOCAT_MGMT_ID
			LEFT OUTER JOIN TB_IM_INV_POLICY_MST D
			ON D.LOCAT_ID = C.LOCAT_ID
			LEFT OUTER JOIN #TEMP_OPERT_INV E
			ON E.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			LEFT OUTER JOIN #TEMP_SFST F
			ON F.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
	WHERE	1=1
	AND		ISNULL(A.VAL_01, '') = IIF(D.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(D.VAL_01, ''))
	AND		ISNULL(A.VAL_02, '') = IIF(D.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(D.VAL_02, ''))

	INSERT INTO #TEMP_PERIOD_TARGET_INV
	(
		LOCAT_ITEM_ID,
		STRT_DATE,
		END_DATE,
		TARGET_INV_PRPSAL_VAL
	)
	SELECT	A.LOCAT_ITEM_ID,
			E.STRT_DATE,
			E.END_DATE,
			CASE WHEN D.TARGET_INV_SFST_CONSID_YN = 'Y' AND D.TARGET_INV_OPERT_INV_CONSID_YN = 'N' THEN G.SFST_PRPSAL_VAL
			     WHEN D.TARGET_INV_SFST_CONSID_YN = 'N' AND D.TARGET_INV_OPERT_INV_CONSID_YN = 'Y' THEN F.OPERT_INV_PRPSAL_VAL
				 WHEN D.TARGET_INV_SFST_CONSID_YN = 'Y' AND D.TARGET_INV_OPERT_INV_CONSID_YN = 'Y' THEN F.OPERT_INV_PRPSAL_VAL + G.SFST_PRPSAL_VAL
				 ELSE NULL
			END AS TARGET_INV_PRPSAL_VAL
	FROM	TB_IM_SITE_ITEM_SEG_SUMM A
			INNER JOIN TB_CM_SITE_ITEM B
			ON B.ID = A.LOCAT_ITEM_ID
			INNER JOIN TB_CM_LOC_MGMT C
			ON C.ID = B.LOCAT_MGMT_ID
			LEFT OUTER JOIN TB_IM_INV_POLICY_MST D
			ON D.LOCAT_ID = C.LOCAT_ID
			INNER JOIN #TEMP_PERIOD_DMND_RATE E
			ON E.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
			LEFT OUTER JOIN #TEMP_PERIOD_OPERT_INV F
			ON (F.LOCAT_ITEM_ID = E.LOCAT_ITEM_ID AND F.STRT_DATE = E.STRT_DATE AND F.END_DATE = E.END_DATE)
			LEFT OUTER JOIN #TEMP_PERIOD_SFST G
			ON (G.LOCAT_ITEM_ID = E.LOCAT_ITEM_ID AND G.STRT_DATE = E.STRT_DATE AND G.END_DATE = E.END_DATE)
	WHERE	1=1
	AND		ISNULL(A.VAL_01, '') = IIF(D.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(D.VAL_01, ''))
	AND		ISNULL(A.VAL_02, '') = IIF(D.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(D.VAL_02, ''))

	/***************************************************************************************************************************************************************************
	10. TB_IM_INV_POLICY_ITEM / TB_IM_INV_POLICY_PRIOD_INFO 생성
	  - 데이터 덮어쓰기(@P_OVERWRITE_DATA_YN) = 'Y' : 전체 삭제 후 생성
	  - 데이터 덮어쓰기(@P_OVERWRITE_DATA_YN) = 'N' : 확정 데이터(FIXED_YN = 'Y') 유지, 나머지 데이터는 삭제 후 생성
	***************************************************************************************************************************************************************************/
	IF @P_APPLY_POINT_CD = 'ALL'
	BEGIN
		DELETE FROM TB_IM_INV_POLICY_PRIOD_INFO
		WHERE  ITEM_INV_POLICY_ID IN (SELECT ID 
									  FROM   TB_IM_INV_POLICY_ITEM
									  WHERE  ISNULL(FIXED_YN, 'N') = CASE WHEN ISNULL(@P_OVERWRITE_DATA_YN, 'N') = 'N' THEN 'N' ELSE ISNULL(FIXED_YN, 'N') END)

		DELETE FROM TB_IM_INV_POLICY_ITEM
		WHERE  ISNULL(FIXED_YN, 'N') = CASE WHEN ISNULL(@P_OVERWRITE_DATA_YN, 'N') = 'N' THEN 'N' ELSE ISNULL(FIXED_YN, 'N') END
	END

    MERGE INTO TB_IM_INV_POLICY_ITEM TARGET
    USING 
    (
		SELECT	A.LOCAT_ITEM_ID,
				B.QTY								AS WAREHOUSE_QTY,
				C.QTY								AS INTRANSIT_QTY,
				D.SHPP_ACTUAL_PERIOD,
				D.AVG_SHPP_ACTUAL_QTY,
				D.INVTURN,
				G.INV_MGMT_SYSTEM_TP_ID				AS PRPSAL_INV_MGMT_SYSTEM_TP_ID,
				G.INV_MGMT_SYSTEM_TP_ID,
				G.PO_CYCL_CD_ID,
				G.PO_CYCL_CALENDAR_ID				AS PO_CYCL_CALENDAR_ID,
				@V_OPERT_BASE_TP_ID					AS OPERT_BASE_TP_ID,
				G.INV_PLACE_STRTGY_ID,
				H.SUPPLY_LEADTIME_AVG				AS SUPPLY_LEADTIME_PRPSAL_VAL,
				H.SUPPLY_LEADTIME_AVG				AS SUPPLY_LEADTIME,
				G.SUPPLY_LEADTIME_YN,
				G.PO_CYCL_YN,
				I.REPLSH_LEADTIME,
				G.OPERT_LV_VAL,
				I.OPERT_TARGET_VAL,
				J.PRPSAL_SVC_LV,
				J.SFST_SVC_LV,
				J.SFST_DEMDVAR_CONSID_YN,
				J.SFST_DEMDVAR_STDDEV,
				J.SFST_SUPYVAR_CONSID_YN,
				J.SFST_DMND_RATE_CAL_TP_ID,
				J.SFST_DMND_RATE,
				J.SUPYVAR_STDDEV,
				CEILING(J.SFST_PRPSAL_VAL)			AS SFST_PRPSAL_VAL,
				CEILING(J.SFST_PRPSAL_VAL)			AS SFST_VAL,
				L.ROP_CAL_TP_ID,
				L.ROP_SFST_CONSID_YN,
				L.ROP_DMND_RATE_CAL_MTD_ID,
				L.ROP_DMND_RATE,
				L.ROP_RIGHT_RATE_TARGET,
				L.ROP_OPERT_INV_CONSID_YN,
				L.ROP_RIGHT_RATE_YN,
				CEILING(L.ROP_PRPSAL_VAL)			AS ROP_PRPSAL_VAL,
				CEILING(L.ROP_PRPSAL_VAL)			AS ROP_VAL,
				M.EOQ_CAL_TP_ID,
				M.EOQ_DMND_RATE_CAL_MTD_ID,
				M.EOQ_DMND_RATE,
				M.EOQ_RIGHT_RATE_TARGET,
				M.EOQ_RIGHT_RATE_YN,
				G.EOQ_MULTIPLE,
				CEILING(M.EOQ_PRPSAL_VAL)			AS EOQ_PRPSAL_VAL,
				CEILING(M.EOQ_PRPSAL_VAL)			AS EOQ_VAL,
				K.OPERT_INV_DMND_RATE_CAL_MTD_ID,
				K.OPERT_INV_DMND_RATE,
				CEILING(K.OPERT_INV_PRPSAL_VAL)		AS OPERT_INV_PRPSAL_VAL,
				CEILING(K.OPERT_INV_PRPSAL_VAL)		AS OPERT_INV_VAL,
				N.TARGET_INV_SFST_CONSID_YN,
				N.TARGET_INV_OPERT_INV_CONSID_YN,
				CEILING(N.TARGET_INV_PRPSAL_VAL)	AS TARGET_INV_PRPSAL_VAL,
				CEILING(N.TARGET_INV_PRPSAL_VAL)	AS TARGET_INV_VAL
		FROM	TB_IM_SITE_ITEM_SEG_SUMM A
				LEFT OUTER JOIN #TEMP_WAREHOUSE_STOCK B
				ON A.LOCAT_ITEM_ID = B.LOCAT_ITEM_ID
				LEFT OUTER JOIN #TEMP_INTRANSIT_STOCK C
				ON A.LOCAT_ITEM_ID = C.LOCAT_ITEM_ID
				LEFT OUTER JOIN #TEMP_STOCK_INFO D
				ON A.LOCAT_ITEM_ID = D.LOCAT_ITEM_ID
				LEFT OUTER JOIN TB_CM_SITE_ITEM E
				ON A.LOCAT_ITEM_ID = E.ID
				LEFT OUTER JOIN TB_CM_LOC_MGMT F
				ON E.LOCAT_MGMT_ID = F.ID
				LEFT OUTER JOIN TB_IM_INV_POLICY_MST G
				ON F.LOCAT_ID = G.LOCAT_ID
				LEFT OUTER JOIN TB_IM_SPPLY_VARAN_ANLYS_MST H
				ON A.LOCAT_ITEM_ID = H.LOCAT_ITEM_ID
				LEFT OUTER JOIN #TEMP_OPERT_TARGET I
				ON A.LOCAT_ITEM_ID = I.LOCAT_ITEM_ID
				LEFT OUTER JOIN #TEMP_SFST J
				ON A.LOCAT_ITEM_ID = J.LOCAT_ITEM_ID
				LEFT OUTER JOIN #TEMP_OPERT_INV K
				ON A.LOCAT_ITEM_ID = K.LOCAT_ITEM_ID
				LEFT OUTER JOIN #TEMP_ROP L
				ON A.LOCAT_ITEM_ID = L.LOCAT_ITEM_ID
				LEFT OUTER JOIN #TEMP_EOQ M
				ON A.LOCAT_ITEM_ID = M.LOCAT_ITEM_ID
				LEFT OUTER JOIN #TEMP_TARGET_INV N
				ON A.LOCAT_ITEM_ID = N.LOCAT_ITEM_ID
		WHERE	1=1
		AND		ISNULL(A.VAL_01, '') = IIF(G.VAL_01 IS NULL, ISNULL(A.VAL_01, ''), ISNULL(G.VAL_01, ''))
		AND		ISNULL(A.VAL_02, '') = IIF(G.VAL_02 IS NULL, ISNULL(A.VAL_02, ''), ISNULL(G.VAL_02, ''))

    ) SOURCE 
    ON ( TARGET.LOCAT_ITEM_ID = SOURCE.LOCAT_ITEM_ID )
    WHEN MATCHED THEN
        UPDATE 
            SET   
				TARGET.INV_LV_QTY						= SOURCE.WAREHOUSE_QTY,
				TARGET.INTRANSIT_QTY					= SOURCE.INTRANSIT_QTY,
				TARGET.SHPP_ACTUAL_PERIOD				= SOURCE.SHPP_ACTUAL_PERIOD,
				TARGET.AVG_SHPP_ACTUAL_QTY				= SOURCE.AVG_SHPP_ACTUAL_QTY,
				TARGET.INVTURN							= SOURCE.INVTURN,
				TARGET.PRPSAL_INV_MGMT_SYSTEM_TP_ID		= SOURCE.PRPSAL_INV_MGMT_SYSTEM_TP_ID,
				TARGET.INV_MGMT_SYSTEM_TP_ID			= IIF(TARGET.FIXED_YN = 'Y', TARGET.INV_MGMT_SYSTEM_TP_ID, SOURCE.INV_MGMT_SYSTEM_TP_ID),
				TARGET.PO_CYCL_CD_ID					= SOURCE.PO_CYCL_CD_ID,
				TARGET.PO_CYCL_CALENDAR_ID				= ISNULL(SOURCE.PO_CYCL_CALENDAR_ID, TARGET.PO_CYCL_CALENDAR_ID),
				TARGET.OPERT_BASE_TP_ID					= SOURCE.OPERT_BASE_TP_ID,
				TARGET.INV_PLACE_STRTGY_ID				= SOURCE.INV_PLACE_STRTGY_ID,
				TARGET.SUPPLY_LEADTIME_PRPSAL_VAL		= SOURCE.SUPPLY_LEADTIME_PRPSAL_VAL,
				TARGET.SUPPLY_LEADTIME					= IIF(TARGET.FIXED_YN = 'Y', TARGET.SUPPLY_LEADTIME, SOURCE.SUPPLY_LEADTIME),
				TARGET.SUPPLY_LEADTIME_YN				= SOURCE.SUPPLY_LEADTIME_YN,
				TARGET.PO_CYCL_YN						= SOURCE.PO_CYCL_YN,
				TARGET.REPLSH_LEADTIME					= SOURCE.REPLSH_LEADTIME,
				TARGET.OPERT_LV_VAL						= SOURCE.OPERT_LV_VAL,
				TARGET.OPERT_TARGET_VAL					= SOURCE.OPERT_TARGET_VAL,
				TARGET.PRPSAL_SVC_LV					= SOURCE.PRPSAL_SVC_LV,
				TARGET.SFST_SVC_LV						= IIF(TARGET.FIXED_YN = 'Y', TARGET.SFST_SVC_LV, SOURCE.SFST_SVC_LV),
				TARGET.SFST_DEMDVAR_CONSID_YN			= SOURCE.SFST_DEMDVAR_CONSID_YN,
				TARGET.SFST_DEMDVAR_STDDEV				= SOURCE.SFST_DEMDVAR_STDDEV,
				TARGET.SFST_SUPYVAR_CONSID_YN			= SOURCE.SFST_SUPYVAR_CONSID_YN,
				TARGET.SFST_DMND_RATE_CAL_TP_ID			= SOURCE.SFST_DMND_RATE_CAL_TP_ID,
				TARGET.SFST_DMND_RATE					= SOURCE.SFST_DMND_RATE,
				TARGET.SUPYVAR_STDDEV					= SOURCE.SUPYVAR_STDDEV,
				TARGET.SFST_PRPSAL_VAL					= SOURCE.SFST_PRPSAL_VAL,
				TARGET.SFST_VAL							= IIF(TARGET.FIXED_YN = 'Y', TARGET.SFST_VAL, SOURCE.SFST_VAL),
				TARGET.ROP_CAL_TP_ID					= SOURCE.ROP_CAL_TP_ID,
				TARGET.ROP_SFST_CONSID_YN				= SOURCE.ROP_SFST_CONSID_YN,
				TARGET.ROP_DMND_RATE_CAL_MTD_ID			= SOURCE.ROP_DMND_RATE_CAL_MTD_ID,
				TARGET.ROP_DMND_RATE					= SOURCE.ROP_DMND_RATE,
				TARGET.ROP_RIGHT_RATE_TARGET			= SOURCE.ROP_RIGHT_RATE_TARGET,
				TARGET.ROP_OPERT_INV_CONSID_YN			= SOURCE.ROP_OPERT_INV_CONSID_YN,
				TARGET.ROP_RIGHT_RATE_YN				= SOURCE.ROP_RIGHT_RATE_YN,
				TARGET.ROP_PRPSAL_VAL					= SOURCE.ROP_PRPSAL_VAL,
				TARGET.ROP_VAL							= IIF(TARGET.FIXED_YN = 'Y', TARGET.ROP_VAL, SOURCE.ROP_VAL),
				TARGET.EOQ_CAL_TP_ID					= SOURCE.EOQ_CAL_TP_ID,
				TARGET.EOQ_DMND_RATE_CAL_MTD_ID			= SOURCE.EOQ_DMND_RATE_CAL_MTD_ID,
				TARGET.EOQ_DMND_RATE					= SOURCE.EOQ_DMND_RATE,
				TARGET.EOQ_RIGHT_RATE_TARGET			= SOURCE.EOQ_RIGHT_RATE_TARGET,
				TARGET.EOQ_RIGHT_RATE_YN				= SOURCE.EOQ_RIGHT_RATE_YN,
				TARGET.EOQ_MULTIPLE						= SOURCE.EOQ_MULTIPLE,
				TARGET.EOQ_PRPSAL_VAL					= SOURCE.EOQ_PRPSAL_VAL,
				TARGET.EOQ_VAL							= IIF(TARGET.FIXED_YN = 'Y', TARGET.EOQ_VAL, SOURCE.EOQ_VAL),
				TARGET.OPERT_INV_DMND_RATE_CAL_MTD_ID	= SOURCE.OPERT_INV_DMND_RATE_CAL_MTD_ID,
				TARGET.OPERT_INV_DMND_RATE				= SOURCE.OPERT_INV_DMND_RATE,
				TARGET.OPERT_INV_PRPSAL_VAL				= SOURCE.OPERT_INV_PRPSAL_VAL,
				TARGET.OPERT_INV_VAL					= IIF(TARGET.FIXED_YN = 'Y', TARGET.OPERT_INV_VAL, SOURCE.OPERT_INV_VAL),
				TARGET.TARGET_INV_SFST_CONSID_YN		= SOURCE.TARGET_INV_SFST_CONSID_YN,
				TARGET.TARGET_INV_OPERT_INV_CONSID_YN	= SOURCE.TARGET_INV_OPERT_INV_CONSID_YN,
				TARGET.TARGET_INV_PRPSAL_VAL			= SOURCE.TARGET_INV_PRPSAL_VAL,
				TARGET.TARGET_INV_VAL					= IIF(TARGET.FIXED_YN = 'Y', TARGET.TARGET_INV_VAL, SOURCE.TARGET_INV_VAL),
				TARGET.MODIFY_BY						= @P_USER_ID,
				TARGET.MODIFY_DTTM 						= GETDATE()
    WHEN NOT MATCHED THEN
        INSERT  (
				ID,
				LOCAT_ITEM_ID,
				INV_LV_QTY,
				INTRANSIT_QTY,
				SHPP_ACTUAL_PERIOD,
				AVG_SHPP_ACTUAL_QTY,
				INVTURN,
				PRPSAL_INV_MGMT_SYSTEM_TP_ID,
				INV_MGMT_SYSTEM_TP_ID,
				PO_CYCL_CD_ID,
				PO_CYCL_CALENDAR_ID,
				OPERT_BASE_TP_ID,
				INV_PLACE_STRTGY_ID,
				SUPPLY_LEADTIME_PRPSAL_VAL,
				SUPPLY_LEADTIME,
				SUPPLY_LEADTIME_YN,
				PO_CYCL_YN,
				REPLSH_LEADTIME,
				OPERT_LV_VAL,
				OPERT_TARGET_VAL,
				PRPSAL_SVC_LV,
				SFST_SVC_LV,
				SFST_DEMDVAR_CONSID_YN,
				SFST_DEMDVAR_STDDEV,
				SFST_SUPYVAR_CONSID_YN,
				SFST_DMND_RATE_CAL_TP_ID,
				SFST_DMND_RATE,
				SUPYVAR_STDDEV,
				SFST_PRPSAL_VAL,
				SFST_VAL,
				ROP_CAL_TP_ID,
				ROP_SFST_CONSID_YN,
				ROP_DMND_RATE_CAL_MTD_ID,
				ROP_DMND_RATE,
				ROP_RIGHT_RATE_TARGET,
				ROP_OPERT_INV_CONSID_YN,
				ROP_RIGHT_RATE_YN,
				ROP_PRPSAL_VAL,
				ROP_VAL,
				EOQ_CAL_TP_ID,
				EOQ_DMND_RATE_CAL_MTD_ID,
				EOQ_DMND_RATE,
				EOQ_RIGHT_RATE_TARGET,
				EOQ_RIGHT_RATE_YN,
				EOQ_MULTIPLE,
				EOQ_PRPSAL_VAL,
				EOQ_VAL,
				OPERT_INV_DMND_RATE_CAL_MTD_ID,
				OPERT_INV_DMND_RATE,
				OPERT_INV_PRPSAL_VAL,
				OPERT_INV_VAL,
				TARGET_INV_SFST_CONSID_YN,
				TARGET_INV_OPERT_INV_CONSID_YN,
				TARGET_INV_PRPSAL_VAL,
				TARGET_INV_VAL,
				FIXED_YN,
				ACTV_YN,
				CREATE_BY,
				CREATE_DTTM
				)
        VALUES  (
				REPLACE(NEWID(),'-',''),
				SOURCE.LOCAT_ITEM_ID,
				SOURCE.WAREHOUSE_QTY,
				SOURCE.INTRANSIT_QTY,
				SOURCE.SHPP_ACTUAL_PERIOD,
				SOURCE.AVG_SHPP_ACTUAL_QTY,
				SOURCE.INVTURN,
				SOURCE.PRPSAL_INV_MGMT_SYSTEM_TP_ID,
				SOURCE.INV_MGMT_SYSTEM_TP_ID,
				SOURCE.PO_CYCL_CD_ID,
				SOURCE.PO_CYCL_CALENDAR_ID,
				SOURCE.OPERT_BASE_TP_ID,
				SOURCE.INV_PLACE_STRTGY_ID,
				SOURCE.SUPPLY_LEADTIME_PRPSAL_VAL,
				SOURCE.SUPPLY_LEADTIME,
				SOURCE.SUPPLY_LEADTIME_YN,
				SOURCE.PO_CYCL_YN,
				SOURCE.REPLSH_LEADTIME,
				SOURCE.OPERT_LV_VAL,
				SOURCE.OPERT_TARGET_VAL,
				SOURCE.PRPSAL_SVC_LV,
				SOURCE.SFST_SVC_LV,
				SOURCE.SFST_DEMDVAR_CONSID_YN,
				SOURCE.SFST_DEMDVAR_STDDEV,
				SOURCE.SFST_SUPYVAR_CONSID_YN,
				SOURCE.SFST_DMND_RATE_CAL_TP_ID,
				SOURCE.SFST_DMND_RATE,
				SOURCE.SUPYVAR_STDDEV,
				SOURCE.SFST_PRPSAL_VAL,
				SOURCE.SFST_VAL,
				SOURCE.ROP_CAL_TP_ID,
				SOURCE.ROP_SFST_CONSID_YN,
				SOURCE.ROP_DMND_RATE_CAL_MTD_ID,
				SOURCE.ROP_DMND_RATE,
				SOURCE.ROP_RIGHT_RATE_TARGET,
				SOURCE.ROP_OPERT_INV_CONSID_YN,
				SOURCE.ROP_RIGHT_RATE_YN,
				SOURCE.ROP_PRPSAL_VAL,
				SOURCE.ROP_VAL,
				SOURCE.EOQ_CAL_TP_ID,
				SOURCE.EOQ_DMND_RATE_CAL_MTD_ID,
				SOURCE.EOQ_DMND_RATE,
				SOURCE.EOQ_RIGHT_RATE_TARGET,
				SOURCE.EOQ_RIGHT_RATE_YN,
				SOURCE.EOQ_MULTIPLE,
				SOURCE.EOQ_PRPSAL_VAL,
				SOURCE.EOQ_VAL,
				SOURCE.OPERT_INV_DMND_RATE_CAL_MTD_ID,
				SOURCE.OPERT_INV_DMND_RATE,
				SOURCE.OPERT_INV_PRPSAL_VAL,
				SOURCE.OPERT_INV_VAL,
				SOURCE.TARGET_INV_SFST_CONSID_YN,
				SOURCE.TARGET_INV_OPERT_INV_CONSID_YN,
				SOURCE.TARGET_INV_PRPSAL_VAL,
				SOURCE.TARGET_INV_VAL,
				'N',
				'Y',
				@P_USER_ID,
				GETDATE()
				);

    MERGE INTO TB_IM_INV_POLICY_PRIOD_INFO TARGET
    USING 
    (
		SELECT	A.ID								AS ITEM_INV_POLICY_ID,
				A.LOCAT_ITEM_ID,
				B.STRT_DATE							AS STRT_DTTM,
				B.END_DATE							AS END_DTTM,
				C.SFST_DMND_RATE,
				CEILING(C.SFST_PRPSAL_VAL)			AS SFST_PRPSAL_VAL,
				CEILING(C.SFST_PRPSAL_VAL)			AS SFST_VAL,
				D.OPERT_INV_DMND_RATE,
				CEILING(D.OPERT_INV_PRPSAL_VAL)		AS OPERT_INV_PRPSAL_VAL,
				CEILING(D.OPERT_INV_PRPSAL_VAL)		AS OPERT_INV_VAL,
				F.ROP_DMND_RATE,
				F.ROP_RIGHT_RATE_TARGET,
				CEILING(F.ROP_PRPSAL_VAL)			AS ROP_PRPSAL_VAL,
				CEILING(F.ROP_PRPSAL_VAL)			AS ROP_VAL,
				G.EOQ_DMND_RATE,
				G.EOQ_RIGHT_RATE_TARGET,
				CEILING(G.EOQ_PRPSAL_VAL)			AS EOQ_PRPSAL_VAL,
				CEILING(G.EOQ_PRPSAL_VAL)			AS EOQ_VAL,
				CEILING(H.TARGET_INV_PRPSAL_VAL)	AS TARGET_INV_PRPSAL_VAL,
				CEILING(H.TARGET_INV_PRPSAL_VAL)	AS TARGET_INV_VAL,
				A.FIXED_YN
		FROM	TB_IM_INV_POLICY_ITEM A
				INNER JOIN #TEMP_PERIOD_DMND_RATE B
				ON B.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
				LEFT OUTER JOIN #TEMP_PERIOD_SFST C
				ON (C.LOCAT_ITEM_ID = B.LOCAT_ITEM_ID AND C.STRT_DATE = B.STRT_DATE AND C.END_DATE = B.END_DATE)
				LEFT OUTER JOIN #TEMP_PERIOD_OPERT_INV D
				ON (D.LOCAT_ITEM_ID = B.LOCAT_ITEM_ID AND D.STRT_DATE = B.STRT_DATE AND D.END_DATE = B.END_DATE)
				LEFT OUTER JOIN #TEMP_PERIOD_ROP F
				ON (F.LOCAT_ITEM_ID = B.LOCAT_ITEM_ID AND F.STRT_DATE = B.STRT_DATE AND F.END_DATE = B.END_DATE)
				LEFT OUTER JOIN #TEMP_PERIOD_EOQ G
				ON (G.LOCAT_ITEM_ID = B.LOCAT_ITEM_ID AND G.STRT_DATE = B.STRT_DATE AND G.END_DATE = B.END_DATE)
				LEFT OUTER JOIN #TEMP_PERIOD_TARGET_INV H
				ON (H.LOCAT_ITEM_ID = B.LOCAT_ITEM_ID AND H.STRT_DATE = B.STRT_DATE AND H.END_DATE = B.END_DATE)
    ) SOURCE 
    ON (TARGET.ITEM_INV_POLICY_ID = SOURCE.ITEM_INV_POLICY_ID
		AND TARGET.STRT_DTTM = SOURCE.STRT_DTTM
		AND TARGET.END_DTTM  = SOURCE.END_DTTM)
    WHEN MATCHED THEN
        UPDATE 
            SET	
				TARGET.SFST_DMND_RATE			= SOURCE.SFST_DMND_RATE,
				TARGET.SFST_PRPSAL_VAL			= SOURCE.SFST_PRPSAL_VAL,
				TARGET.SFST_VAL					= IIF(SOURCE.FIXED_YN = 'Y', TARGET.SFST_VAL, SOURCE.SFST_VAL),
				TARGET.OPERT_INV_DMND_RATE		= SOURCE.OPERT_INV_DMND_RATE,
				TARGET.OPERT_INV_PRPSAL_VAL		= SOURCE.OPERT_INV_PRPSAL_VAL,
				TARGET.OPERT_INV_VAL			= IIF(SOURCE.FIXED_YN = 'Y', TARGET.OPERT_INV_VAL, SOURCE.OPERT_INV_VAL),
				TARGET.ROP_DMND_RATE			= SOURCE.ROP_DMND_RATE,
				TARGET.ROP_RIGHT_RATE_TARGET	= SOURCE.ROP_RIGHT_RATE_TARGET,
				TARGET.ROP_PRPSAL_VAL			= SOURCE.ROP_PRPSAL_VAL,
				TARGET.ROP_VAL					= IIF(SOURCE.FIXED_YN = 'Y', TARGET.ROP_VAL, SOURCE.ROP_VAL),
				TARGET.EOQ_DMND_RATE			= SOURCE.EOQ_DMND_RATE,
				TARGET.EOQ_RIGHT_RATE_TARGET	= SOURCE.EOQ_RIGHT_RATE_TARGET,
				TARGET.EOQ_PRPSAL_VAL			= SOURCE.EOQ_PRPSAL_VAL,
				TARGET.EOQ_VAL					= IIF(SOURCE.FIXED_YN = 'Y', TARGET.EOQ_VAL, SOURCE.EOQ_VAL),
				TARGET.TARGET_INV_PRPSAL_VAL	= SOURCE.TARGET_INV_PRPSAL_VAL,
				TARGET.TARGET_INV_VAL			= IIF(SOURCE.FIXED_YN = 'Y', TARGET.TARGET_INV_VAL, SOURCE.TARGET_INV_VAL),
				TARGET.MODIFY_BY				= @P_USER_ID,
				TARGET.MODIFY_DTTM				= GETDATE()
    WHEN NOT MATCHED THEN
        INSERT  (
				ID,
				ITEM_INV_POLICY_ID,
				STRT_DTTM,
				END_DTTM,
				SFST_DMND_RATE,
				SFST_PRPSAL_VAL,
				SFST_VAL,
				OPERT_INV_DMND_RATE,
				OPERT_INV_PRPSAL_VAL,
				OPERT_INV_VAL,
				ROP_DMND_RATE,
				ROP_RIGHT_RATE_TARGET,
				ROP_PRPSAL_VAL,
				ROP_VAL,
				EOQ_DMND_RATE,
				EOQ_RIGHT_RATE_TARGET,
				EOQ_PRPSAL_VAL,
				EOQ_VAL,
				TARGET_INV_PRPSAL_VAL,
				TARGET_INV_VAL,
				CREATE_BY,
				CREATE_DTTM
				)
        VALUES  (
				REPLACE(NEWID(),'-',''),
				SOURCE.ITEM_INV_POLICY_ID,
				SOURCE.STRT_DTTM,
				SOURCE.END_DTTM,
				SOURCE.SFST_DMND_RATE,
				SOURCE.SFST_PRPSAL_VAL,
				SOURCE.SFST_VAL,
				SOURCE.OPERT_INV_DMND_RATE,
				SOURCE.OPERT_INV_PRPSAL_VAL,
				SOURCE.OPERT_INV_VAL,
				SOURCE.ROP_DMND_RATE,
				SOURCE.ROP_RIGHT_RATE_TARGET,
				SOURCE.ROP_PRPSAL_VAL,
				SOURCE.ROP_VAL,
				SOURCE.EOQ_DMND_RATE,
				SOURCE.EOQ_RIGHT_RATE_TARGET,
				SOURCE.EOQ_PRPSAL_VAL,
				SOURCE.EOQ_VAL,
				SOURCE.TARGET_INV_PRPSAL_VAL,
				SOURCE.TARGET_INV_VAL,
				@P_USER_ID,
				GETDATE()
				);

	/***************************************************************************************************************************************************************************
	11. TB_CM_SITE_ITEM : 재고배치전략이 전방배치인 경우 즉시 출하 컬럼 적용
	***************************************************************************************************************************************************************************/
	UPDATE	TB_CM_SITE_ITEM 
	SET		IMMEDIATE_SHIPMENT_YN = 'Y'
	WHERE	ID IN	(
					SELECT	A.LOCAT_ITEM_ID
					FROM	TB_IM_INV_POLICY_ITEM A
							INNER JOIN TB_AD_COMN_CODE B
							ON B.ID = A.INV_PLACE_STRTGY_ID
					WHERE	ISNULL(A.FIXED_YN, 'N') = 'N'
					AND		B.COMN_CD = 'FRONT_DEPLOY'
					)

	DROP TABLE #TEMP_WAREHOUSE_STOCK
	DROP TABLE #TEMP_INTRANSIT_STOCK
	DROP TABLE #TEMP_DAY_AVG_ACTUAL_SHIPMENT
	DROP TABLE #TEMP_BOH
	DROP TABLE #TEMP_EOH
	DROP TABLE #TEMP_STOCK_INFO
	DROP TABLE #TEMP_PO_CYCL_VAL
	DROP TABLE #TEMP_OPERT_TARGET
	DROP TABLE #TEMP_DMND_CAL_METHOD_MAP
	DROP TABLE #TEMP_DMND_RATE_ACTUAL_ALL
	DROP TABLE #TEMP_DMND_RATE_ACTUAL_YOY
	DROP TABLE #TEMP_DMND_RATE_FORECAST_ALL
	DROP TABLE #TEMP_DMND_RATE_FORECAST_TARGET
	DROP TABLE #TEMP_DMND_RATE
	DROP TABLE #TEMP_PERIOD_DMND_RATE
	DROP TABLE #TEMP_INV_ANLY_PRIOD
	DROP TABLE #TEMP_LAST_SHIPMENT_ANLY
	DROP TABLE #TEMP_ACTUAL_YOY_ANLY
	DROP TABLE #TEMP_DMND_PLAN_ANLY
	DROP TABLE #TEMP_DMND_VARAN_ANLYS
	DROP TABLE #TEMP_SFST
	DROP TABLE #TEMP_PERIOD_SFST
	DROP TABLE #TEMP_OPERT_INV
	DROP TABLE #TEMP_PERIOD_OPERT_INV
	DROP TABLE #TEMP_EOQ
	DROP TABLE #TEMP_PERIOD_EOQ
	DROP TABLE #TEMP_STD_ROP
	DROP TABLE #TEMP_PERIOD_STD_ROP
	DROP TABLE #TEMP_AVG_INV
	DROP TABLE #TEMP_ROP
	DROP TABLE #TEMP_PERIOD_ROP
	DROP TABLE #TEMP_TARGET_INV
	DROP TABLE #TEMP_PERIOD_TARGET_INV

	SET @P_RT_ROLLBACK_FLAG = 'true'
	SET @P_RT_MSG = 'MSG_0003'

END TRY

BEGIN CATCH
	IF(ERROR_MESSAGE() LIKE 'MSG_%')
		BEGIN
			SET @P_ERR_MSG = ERROR_MESSAGE()
			SET @P_RT_ROLLBACK_FLAG = 'false'
			SET @P_RT_MSG = @P_ERR_MSG
		END
	ELSE
		THROW;
END CATCH;
go

