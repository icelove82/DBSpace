CREATE PROCEDURE [dbo].[SP_UI_BF_16_FC_INPUT_FAC]
(	 @P_ENGINE_TP_CD			NVARCHAR(30)
	,@P_INPUT_FROM_DATE			DATE			
	,@P_INPUT_TO_DATE			DATE
	,@P_INPUT_BUKT_CD			NVARCHAR(30)
	,@P_INPUT_HORIZ				INT				
	,@P_SALES_LV_CD				NVARCHAR(100)
	,@P_ITEM_LV_CD				NVARCHAR(100)
	,@P_STD_WEEK				NVARCHAR(30)		
	,@P_LEAF_ITEM_LV_CD			NVARCHAR(100)	-- LEAF LEVEL
	,@P_LEAF_ITEM_CD			NVARCHAR(100)	-- LEAF ITEM
	,@P_LEAF_SALES_LV_CD		NVARCHAR(100)    
	,@P_LEAF_ACCT_CD			NVARCHAR(100)
	,@P_RT_ROLLBACK_FLAG		NVARCHAR(10)   = 'true'			OUTPUT
	,@P_RT_MSG					NVARCHAR(4000) = ''				OUTPUT		
) AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
	DECLARE @P_ERR_STATUS INT = 0
		   ,@P_ERR_MSG NVARCHAR(4000)=''
CREATE TABLE #TB_TMP_FC 
(  ITEMID0			NVARCHAR(100)  COLLATE DATABASE_DEFAULT
 , ITEMID1			NVARCHAR(100)  COLLATE DATABASE_DEFAULT
 , VARIABLE			NVARCHAR(30)
 , HIST_YEAR	   INT
 , HIST_PERIOD	   INT
 , HIST_VALUE	   FLOAT
		)
;
BEGIN TRY
/*************************************************************************************************************
	-- 1. Validation
*************************************************************************************************************/
IF NOT EXISTS (	SELECT *
			  FROM TB_BF_FC_REG_INPUT
		  )
BEGIN
	SET @P_ERR_MSG = 'Regression Input Data is none'
	RAISERROR (@P_ERR_MSG,12, 1);
END
;
/*************************************************************************************************************
	-- 2. Get Master Data
*************************************************************************************************************/
TRUNCATE TABLE TB_BF_FC_FACTOR_INPUT
;
WITH
CALENDAR
AS (
SELECT YYYY
	 , [WEEK]	AS HIST_PERIOD
	 , STRT_DATE
	 , END_DATE 
	 , (SELECT MAX(DP_WK) FROM TB_CM_CALENDAR WHERE YYYY = A.YYYY) AS PP
  FROM (
		SELECT YYYY
			 , DP_WK			    AS [WEEK]
			 , MIN(DAT)				AS STRT_DATE
			 , MAX(DAT)				AS END_DATE
		  FROM TB_CM_CALENDAR
	     WHERE DAT BETWEEN @P_INPUT_FROM_DATE AND @P_INPUT_TO_DATE
	    GROUP BY YYYY, DP_WK
	 ) A 

--	SELECT DAT		AS STRT_DATE
--		, ISNULL ((LEAD(DAT,1)  OVER ( ORDER BY YYYYMMDD)) -1,@P_INPUT_TO_DATE) AS END_DATE
--		, YYYY
----		, ISO_WK AS [WEEK]
----		, [MM]		
----		, YYYYMMDD
--		, CASE @P_INPUT_BUKT_CD 
--			WHEN 'W' THEN DATEPART(WEEK, DAT) --ISO_WK
--			WHEN 'M' THEN MM
--			WHEN 'D' THEN YYYYMMDD
--		  END 								AS HIST_PERIOD		   
--		, CASE @P_INPUT_BUKT_CD
--		 			WHEN 'W' THEN (SELECT MAX(DATEPART(WEEK,DAT)) FROM TB_CM_CALENDAR WHERE YYYY = M.YYYY) -- 52
--		 			WHEN 'M' THEN 12
--		 			WHEN 'D' THEN 365
--		  END								AS PP
--	  FROM TB_CM_CALENDAR M
--     WHERE DAT BETWEEN @P_INPUT_FROM_DATE AND @P_INPUT_TO_DATE
--	   AND CASE WHEN @P_INPUT_BUKT_CD = 'M' THEN DD ELSE 1 END = 1 
--	   AND CASE WHEN @P_INPUT_BUKT_CD = 'W' THEN DOW_NM ELSE @P_STD_WEEK END = @P_STD_WEEK 	 	
   ),IAF
AS (
	 SELECT  ITEM_CD, ACCOUNT_CD, MFM.COL_NM FACTOR_CD 
			,CAL.STRT_DATE
			,CAL.END_DATE
			,CAL.PP
			,CAL.HIST_PERIOD
			,CAL.YYYY 
	   FROM TB_BF_ITEM_ACCOUNT_MODEL_MAP IAM
			INNER JOIN 
			TB_BF_FACTOR_MGMT MFM
		on MFM.ACTV_YN='Y' and MFM.EXTEND_YN='N'
		 --ON IAM.MODEL_CD = MFM.MODEL_CD
		--ON IAM.ENGINE_TP_CD = @P_ENGINE_TP_CD -- 'REGRESSION_FP'
		--
		-- 
	    --AND IAM.ACTV_YN = 'Y'
			CROSS JOIN
			CALENDAR CAL		 			
), DATE_FAC 
AS (
	SELECT --DATEADD(YYYY, -17, BASE_DATE) 
		   BASE_DATE, FACTOR_CD, VAL
	 from TB_BF_TMP_DATA
		  UNPIVOT ( VAL FOR FACTOR_CD IN ( 
										   trend_yy
										 , trend_yymm
										 , trend_yywk
										 , yyyy
										 , mm
										 , dp_wk
										 , dow
										 , mon_10
										 , mon_5
										 , mon_3
										 , pr_holid
										 , nx_holid
										 , holiday2
										 , qty_mm
										 , qty_wk
										 , qty_wd
										 , qty_md10
										 , qty_m10
										 , qty_md05
										 , qty_m05
										 , qty_md03
										 , qty_m03
										 , day_of_month
										 , day_of_week
										 , month
										 , season
										 )) AS FAC	 
--	SELECT --DATEADD(YYYY, -17, BASE_DATE) 
--		   BASE_DATE, FACTOR_CD, VAL
--	 from TB_BF_TMP_DATA
--	 FROM TB_BF_DATE_FACTOR 
--		  UNPIVOT ( VAL FOR FACTOR_CD IN ( FACTOR1
--										 , FACTOR2
--										 , FACTOR3
--										 , FACTOR4
--										 , FACTOR5
--										 , FACTOR6
--										 , FACTOR7
--										 , FACTOR8
--										 , FACTOR9
--										 , FACTOR10
--										 , FACTOR11
--										 , FACTOR12
--										 , FACTOR13
--										 , FACTOR14
--										 , FACTOR15
--										 , FACTOR16
--										 , FACTOR17
--										 , FACTOR18
--										 , FACTOR19
--										 , FACTOR20
--										 )) AS FAC
),SALES_FAC
AS (	
	SELECT 'ITEM_CD' ITEM_CD, 'ACCT_CD' ACCOUNT_CD, BASE_DATE, FACTOR_CD, VAL
	 from TB_BF_TMP_DATA
		  UNPIVOT ( VAL FOR FACTOR_CD IN ( qty_factor1
										 , qty_factor2
										 , qty_factor3
										 , qty_factor4
										 , qty_factor5
										 , qty_factor6
										 , qty_factor7
										 , qty_sales_factor1
										 , factor1
										 , factor2
										 , factor3
										 , factor4
										 , factor5
										 , factor6
										 , factor7
										 , sales_factor1_avg
										 , sales_factor1_sum
										  )) AS FAC

--	SELECT ITEM_CD, ACCOUNT_CD, 
--			BASE_DATE, FACTOR_CD, VAL	 
--	 FROM TB_BF_SALES_FACTOR
--		  UNPIVOT ( VAL FOR FACTOR_CD IN ( SALES_FACTOR1
--										 , SALES_FACTOR2
--										 , SALES_FACTOR3
--										 , SALES_FACTOR4
--										 , SALES_FACTOR5
--										 , SALES_FACTOR6
--										 , SALES_FACTOR7
--										 , SALES_FACTOR8
--										 , SALES_FACTOR9
--										 , SALES_FACTOR10
--										 , SALES_FACTOR11
--										 , SALES_FACTOR12
--										 , SALES_FACTOR13
--										 , SALES_FACTOR14
--										 , SALES_FACTOR15
--										 , SALES_FACTOR16
--										 , SALES_FACTOR17
--										 , SALES_FACTOR18
--										 , SALES_FACTOR19
--										 , SALES_FACTOR20
--										 )) AS FAC

), TB_PR_ITEM_LEVEL_MGMT 
  ( ID
  , PATH_CD
  , PATH_ID
  , LV_CD
  , LEAF_ITEM_LV_ID
  , LEAF_ITEM_LV_CD
  ) 
AS(
		SELECT SL.ID
			 , CONVERT(NVARCHAR(4000), SL.ITEM_LV_CD) PATH_CD
			 , CONVERT(NVARCHAR(4000), SL.ID) [PATH_ID]
			 , LM.LV_CD
			 , SL.ID	AS LEAF_ITEM_LV_ID
			 , SL.ITEM_LV_CD AS LEAF_ITEM_LV_CD
		  FROM TB_CM_ITEM_LEVEL_MGMT SL
			   INNER JOIN
			   TB_CM_LEVEL_MGMT LM
			ON SL.LV_MGMT_ID = LM.ID
		 WHERE LV_CD = @P_ITEM_LV_CD
		UNION ALL	
		SELECT SL.ID
			 , CONVERT(NVARCHAR(4000), PATH_CD+'/'+SL.ITEM_LV_CD) AS PATH_CD		
			 , CONVERT(NVARCHAR(4000), [PATH_ID]+'/'+SL.ID) AS [PATH_ID]		
			 , LM.LV_CD
			 , SL.ID	AS LEAF_ITEM_LV_ID
			 , SL.ITEM_LV_CD AS LEAF_ITEM_LV_CD
		  FROM TB_CM_ITEM_LEVEL_MGMT SL
			   INNER JOIN
			   TB_PR_ITEM_LEVEL_MGMT PL
			ON SL.PARENT_ITEM_LV_ID = PL.ID
			   INNER JOIN
			   TB_CM_LEVEL_MGMT LM
			ON SL.LV_MGMT_ID = LM.ID
		 WHERE ISNULL(LM.DEL_YN,'N') = 'N'
		   AND ISNULL(SL.DEL_YN,'N') = 'N'
		   AND ISNULL(LM.SALES_LV_YN  ,'N') = 'N'
		   AND LM.ACTV_YN = 'Y'
		   AND SL.ACTV_YN = 'Y'
), TB_PR_SALES_LEVEL_MGMT 
 ( ID
 , PATH_CD
 , PATH_ID
 , LV_CD
 , LEAF_SALES_LV_ID
 , LEAF_SALES_LV_CD
 ) 
AS(
		SELECT SL.ID
			 , CONVERT(NVARCHAR(4000), SL.SALES_LV_CD) PATH_CD
			 , CONVERT(NVARCHAR(4000), SL.ID) [PATH_ID]
			 , LM.LV_CD
			 , SL.ID	AS LEAF_SALES_LV_ID
			 , SL.SALES_LV_CD AS LEAF_SALES_LV_CD
		  FROM TB_DP_SALES_LEVEL_MGMT SL
			   INNER JOIN
			   TB_CM_LEVEL_MGMT LM
			ON SL.LV_MGMT_ID = LM.ID
		 WHERE LV_CD = @P_SALES_LV_CD
		UNION ALL	
		SELECT SL.ID
			 , CONVERT(NVARCHAR(4000), PATH_CD+'/'+SL.SALES_LV_CD) AS PATH_CD		
			 , CONVERT(NVARCHAR(4000), [PATH_ID]+'/'+SL.ID) AS [PATH_ID]		
			 , LM.LV_CD
			 , SL.ID	AS LEAF_SALES_LV_ID
			 , SL.SALES_LV_CD AS LEAF_SALES_LV_CD
		  FROM TB_DP_SALES_LEVEL_MGMT SL
			   INNER JOIN
			   TB_PR_SALES_LEVEL_MGMT PL
			ON SL.PARENT_SALES_LV_ID = PL.ID
			   INNER JOIN
			   TB_CM_LEVEL_MGMT LM
			ON SL.LV_MGMT_ID = LM.ID
		 WHERE ISNULL(LM.DEL_YN,'N') = 'N'
		   AND ISNULL(SL.DEL_YN,'N') = 'N'
		   AND ISNULL(LM.SALES_LV_YN  ,'N') = 'Y'
		   AND LM.ACTV_YN = 'Y'
		   AND SL.ACTV_YN = 'Y'
), ITEM
AS (
		 SELECT I.ITEM_CD
			  , I.ID			AS ITEM_ID
			  , PATH_CD
			  , CASE WHEN @P_ITEM_LV_CD = @P_LEAF_ITEM_LV_CD THEN LEAF_ITEM_LV_CD ELSE LEFT(M.[PATH_CD], CHARINDEX('/', M.[PATH_CD])-1)  END AS TOP_ITEM_LV
  		   FROM TB_CM_ITEM_MST I
				LEFT OUTER JOIN
				( SELECT M.LEAF_ITEM_LV_ID
						,M.LEAF_ITEM_LV_CD
  						,M.PATH_CD	AS PATH_CD
				    FROM TB_PR_ITEM_LEVEL_MGMT M
   				   WHERE M.LV_CD =@P_LEAF_ITEM_LV_CD
				) M
			ON  LEAF_ITEM_LV_ID = I.PARENT_ITEM_LV_ID
		  WHERE ISNULL(I.DEL_YN,'N') = 'N'
		    AND I.PARENT_ITEM_LV_ID IS NOT NULL
), ACCT
AS (
		 SELECT A.ACCOUNT_CD	AS ACCT_CD
			  , A.ID			AS ACCT_ID
			  , PATH_CD
			  , CASE WHEN @P_SALES_LV_CD = @P_LEAF_SALES_LV_CD THEN LEAF_SALES_LV_CD ELSE LEFT(M.[PATH_CD], CHARINDEX('/', M.[PATH_CD])-1)  END AS TOP_SALES_LV
  		   FROM TB_DP_ACCOUNT_MST A
				LEFT OUTER JOIN
				( SELECT M.LEAF_SALES_LV_ID
						,M.LEAF_SALES_LV_CD
  						,M.PATH_CD	AS PATH_CD
				    FROM TB_PR_SALES_LEVEL_MGMT M
   				   WHERE M.LV_CD =@P_LEAF_SALES_LV_CD
				) M
			ON  LEAF_SALES_LV_ID = A.PARENT_SALES_LV_ID
		  WHERE ISNULL(A.DEL_YN,'N') = 'N'
		    AND A.PARENT_SALES_LV_ID IS NOT NULL
)
/*************************************************************************************************************
	-- 3. Main Procedure (Make Factor Data)
*************************************************************************************************************/
INSERT INTO #TB_TMP_FC -- TB_BF_FC_FACTOR_INPUT 
		(  ITEMID0
		 , ITEMID1
		 , VARIABLE
		 , HIST_YEAR
		 , HIST_PERIOD
		 , HIST_VALUE	
		)
	SELECT CASE WHEN @P_ITEM_LV_CD = @P_LEAF_ITEM_CD 
				THEN I.ITEM_CD 
				ELSE I.TOP_ITEM_LV 
			END											AS ITEMID0
		 , CASE WHEN @P_SALES_LV_CD = @P_LEAF_ACCT_CD 
				THEN A.ACCT_CD 
				ELSE A.TOP_SALES_LV 
			END											AS ITEMID1
		 , IAF.FACTOR_CD								AS VARIABLE
		 , YYYY											AS HIST_YEAR
		 , IAF.HIST_PERIOD
		 , AVG(SF.VAL)									AS VAL 
     FROM IAF
 	      INNER JOIN
 	      ITEM I	   
	   ON IAF.ITEM_CD = I.ITEM_CD 
 	      INNER JOIN
 	      ACCT A	   
	   ON IAF.ACCOUNT_CD = A.ACCT_CD
	  	  INNER JOIN
		  ( SELECT SF.ITEM_CD, SF.ACCOUNT_CD, SF.FACTOR_CD, AVG(SF.VAL) AS VAL , CA.HIST_PERIOD
		     FROM SALES_FAC SF
		  	      INNER JOIN
		  		  CALENDAR CA
		      ON SF.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
	    GROUP BY SF.ITEM_CD, SF.ACCOUNT_CD, SF.FACTOR_CD, CA.HIST_PERIOD
		  ) SF
	   ON SF.ITEM_CD = IAF.ITEM_CD
	  AND SF.ACCOUNT_CD = IAF.ACCOUNT_CD
	  AND SF.FACTOR_CD = IAF.FACTOR_CD
	  AND SF.HIST_PERIOD = IAF.HIST_PERIOD
 GROUP BY CASE WHEN @P_ITEM_LV_CD = @P_LEAF_ITEM_CD 
				THEN I.ITEM_CD 
				ELSE I.TOP_ITEM_LV 
			END											 
		 , CASE WHEN @P_SALES_LV_CD = @P_LEAF_ACCT_CD 
				THEN A.ACCT_CD 
				ELSE A.TOP_SALES_LV 
			END											 
		 , IAF.FACTOR_CD		
		 , YYYY										 
		 , IAF.HIST_PERIOD
UNION
	SELECT CASE WHEN @P_ITEM_LV_CD = @P_LEAF_ITEM_CD 
				THEN I.ITEM_CD 
				ELSE I.TOP_ITEM_LV 
			END											AS ITEMID0
		 , CASE WHEN @P_SALES_LV_CD = @P_LEAF_ACCT_CD 
				THEN A.ACCT_CD 
				ELSE A.TOP_SALES_LV 
			END											AS ITEMID1
		 , IAF.FACTOR_CD								AS VARIABLE
		 , YYYY											AS HIST_YEAR
		 , IAF.HIST_PERIOD
		 , AVG(DF.VAL)									AS VAL 
     FROM IAF
 	      INNER JOIN
 	      ITEM I	   
	   ON IAF.ITEM_CD = I.ITEM_CD 
 	      INNER JOIN
 	      ACCT A	   
	   ON IAF.ACCOUNT_CD = A.ACCT_CD
		  INNER JOIN
	  	 ( SELECT DF.FACTOR_CD, AVG(DF.VAL) AS VAL, CA.HIST_PERIOD
		     FROM DATE_FAC DF
			      INNER JOIN
				  CALENDAR CA
			  ON  DF.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
	    GROUP BY DF.FACTOR_CD, CA.HIST_PERIOD
		  )  DF
	   ON DF.FACTOR_CD = IAF.FACTOR_CD
	  AND DF.HIST_PERIOD = IAF.HIST_PERIOD
 GROUP BY CASE WHEN @P_ITEM_LV_CD = @P_LEAF_ITEM_CD 
				THEN I.ITEM_CD 
				ELSE I.TOP_ITEM_LV 
			END											 
		 , CASE WHEN @P_SALES_LV_CD = @P_LEAF_ACCT_CD 
				THEN A.ACCT_CD 
				ELSE A.TOP_SALES_LV 
			END											 
		 , IAF.FACTOR_CD		
		 , YYYY										 
		 , IAF.HIST_PERIOD
;
/*************************************************************************************************************
	-- 4. Extract Correct Data
*************************************************************************************************************/
INSERT INTO TB_BF_FC_FACTOR_INPUT
		(  ITEMID0
		 , ITEMID1
		 , VARIABLE
		 , HIST_YEAR
		 , HIST_PERIOD
		 , HIST_VALUE	
		)
SELECT   F.ITEMID0
	   , F.ITEMID1
	   , F.VARIABLE
	   , F.HIST_YEAR
	   , F.HIST_PERIOD
	   , F.HIST_VALUE	
  FROM #TB_TMP_FC F
	   INNER JOIN
	   TB_BF_FC_REG_INPUT R
	ON F.ITEMID0 = R.ITEMID0
   AND F.ITEMID1 = R.ITEMID1
   AND F.HIST_PERIOD = R.HIST_PERIOD
   AND F.HIST_YEAR = R.HIST_YEAR

	    SET @P_RT_MSG = 'MSG_0001'
	    SET @P_RT_ROLLBACK_FLAG = 'true'
END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END
	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR
END CATCH



go

