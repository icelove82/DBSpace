/*************************
Title : SP_DP_15_Q1
최초 작성자 : 민경훈
최초 생성일 : 2018.12.13
History (수정일자 / 수정자 / 수정내용)
- 2019.09.26 / 김소희 / UOM_NM 추가
- 2020.03.12 / 김소희 / EMP_NO => USER_ID 
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER
**************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_37_Q1] (@p_EMP_CD         NVARCHAR(50) = ''
									  , @p_AUTH_TP_ID	  NVARCHAR(50) = ''
                                      , @p_ITEM_CD        NVARCHAR(4000) = ''
                                      , @p_ITEM_NM        NVARCHAR(4000) = ''
									  , @p_ACCT_CD        NVARCHAR(4000) = ''
									  , @p_ACCT_NM        NVARCHAR(4000) = ''
								   ) AS 

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN


		SELECT  IA.ID
			  , IA.AUTH_TP_ID
			  , LM.LV_CD AS AUTH_TP_CD
			  , LM.LV_NM AS AUTH_TP_NM
			  , IA.ACCOUNT_ID
			  , AM.ACCOUNT_CD
			  , AM.ACCOUNT_NM 
			  , IA.ITEM_MST_ID
			  , IM.ITEM_CD
			  , IM.ITEM_NM 
			  , C.UOM_CD as UOM_CD --C.UOM_CD
			  , C.UOM_NM
			  , IA.EMP_ID
			  , DE.USERNAME as USER_ID
			  , DE.USERNAME as EMP_NO
			  , DE.DISPLAY_NAME as EMP_NM 
			  , IA.CREATE_BY
			  , CONVERT(DATETIME,IA.CREATE_DTTM) as CREATE_DTTM
			  , IA.MODIFY_BY
			  , IA.MODIFY_DTTM
		  FROM   TB_DP_USER_ITEM_ACCOUNT_EXCLUD IA
			   , TB_DP_ACCOUNT_MST AM 
			   , TB_CM_ITEM_MST IM 
			   , TB_CM_UOM C
			   , TB_CM_LEVEL_MGMT LM
			   , TB_AD_USER  DE
		WHERE IA.AUTH_TP_ID = LM.ID
		  AND IA.ACCOUNT_ID = AM.ID
		  AND IA.ITEM_MST_ID = IM.ID
		  AND IM.UOM_ID = C.ID		
		  AND C.ACTV_YN = 'Y'
		  AND IA.EMP_ID = DE.ID
		  AND DE.USERNAME = @p_EMP_CD --'admin'
		  -- AUTH_TP_ID
		  AND IA.AUTH_TP_ID LIKE  '%'+ @p_AUTH_TP_ID + '%'
		  -- ITEM_CD
		  AND (  ( '' <> @P_ITEM_CD AND IM.ITEM_CD IN (SELECT Value VAL
													FROM SplitTableNVARCHAR(ISNULL(@p_ITEM_CD,''),'|')) 
				 ) OR
				 ( ''  =  @p_ITEM_CD AND ISNULL(IM.ITEM_CD,'')  LIKE  '%'  )	                                        
			  )        
		  -- ITEM_NM
		  AND (  ( '' <> @P_ITEM_NM AND IM.ITEM_NM IN (SELECT Value VAL
													FROM SplitTableNVARCHAR(ISNULL(@p_ITEM_NM,''),'|')) 
				 ) OR
				 ( ''  =  @p_ITEM_NM AND ISNULL(IM.ITEM_NM,'')  LIKE  '%'  )	                                        
			  )        

		  -- ACCOUNT_CD 
          AND (  ( '' <> @p_ACCT_CD AND AM.ACCOUNT_CD IN (SELECT Value VAL
                                                        FROM SplitTableNVARCHAR(ISNULL(@p_ACCT_CD,''),'|'))
                ) OR
                ( ''  =  @p_ACCT_CD AND ISNULL(AM.ACCOUNT_CD,'')  LIKE  '%'  )                                              
                )       
		  -- ACCOUNT_NM 
          AND (  ( '' <> @p_ACCT_NM AND AM.ACCOUNT_NM IN (SELECT Value VAL
                                                        FROM SplitTableNVARCHAR(ISNULL(@p_ACCT_NM,''),'|'))
                ) OR
                ( ''  =  @p_ACCT_NM AND ISNULL(AM.ACCOUNT_NM,'')  LIKE  '%'  )                                              
                )       

         ORDER BY AM.ACCOUNT_CD, IM.ITEM_CD
;





END


		   





go

