/*****************************************************************************
Title : SP_UI_MP_06_POP_Q4
최초 작성자 : 조아람
최초 생성일 : 2017.08.16
 
설명 
 - MP Simultaneous Resource 팝업 (UI_MP_06_08) - Resource 조회 프로시저
 
History (수정일자 / 수정자 / 수정내용)
- 2017.08.16 / 조아람 / 최초 작성
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_MP_06_POP_Q4] (
	@P_TYPE					NVARCHAR(10) = '',
	@P_LOC_MGMT_ID			CHAR(32) = '',
	@P_ITEM_MST_ID			CHAR(32) = '',
	@P_SIMLT_RES_ID			CHAR(32) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @V_NEW_GRP_ID CHAR(32) 

BEGIN
	
	SET @V_NEW_GRP_ID = REPLACE(NEWID(), '-','')
	
	IF @P_TYPE = 'N'
		BEGIN
            SELECT
                @V_NEW_GRP_ID      AS SIMLT_RES_GRP_ID,
                NULL               AS SIMLT_RES_ID,
                RMD.ID             AS RES_DTL_ID,
                RMD.RES_CD         AS RES_CD,
                RMD.RES_DESCRIP    AS RES_DESCRIP,
                'N'                AS SELECT_YN
            FROM
                TB_CM_LOC_MGMT LMG
                INNER JOIN TB_CM_SITE_ITEM SIT ON LMG.ID = SIT.LOCAT_MGMT_ID
                INNER JOIN TB_MP_RES_MGMT_MST RMM ON LMG.ID = RMM.LOCAT_MGMT_ID
                INNER JOIN TB_MP_RES_MGMT_DTL RMD ON RMM.ID = RMD.RES_MGMT_MST_ID
            WHERE
                LMG.ID = @P_LOC_MGMT_ID
            AND SIT.ITEM_MST_ID = @P_ITEM_MST_ID
            AND SIT.BOM_ITEM_TP_ID = (SELECT ID FROM TB_AD_COMN_CODE WHERE COMN_CD = 'FINAL_PRODUCT_GR_ITEM')
		END

	IF @P_TYPE = 'U'
		BEGIN
			SELECT DISTINCT
				   CASE WHEN SMG.ID IS NOT NULL THEN SMG.ID
						ELSE @V_NEW_GRP_ID
					END								AS SIMLT_RES_GRP_ID
				 , SML.ID							AS SIMLT_RES_ID
				 , RMD.ID							AS RES_DTL_ID
				 , RMD.RES_CD						AS RES_CD
				 , RMD.RES_DESCRIP					AS RES_DESCRIP
				 , CASE WHEN SML.ID IS NOT NULL THEN SML.ACTV_YN
						ELSE 'N'
				   END								AS SELECT_YN
				 , RTN.ROUTE_CD                     AS ROUTE_CD
				 , RTN.ROUTE_DESCRIP                AS ROUTE_DESCRIP
			FROM
                TB_CM_LOC_MGMT LMG
                INNER JOIN TB_CM_SITE_ITEM SIT ON ( LMG.ID = SIT.LOCAT_MGMT_ID )
                INNER JOIN TB_MP_RES_MGMT_MST RMM ON ( LMG.ID = RMM.LOCAT_MGMT_ID )
                INNER JOIN TB_MP_RES_MGMT_DTL RMD ON ( RMM.ID = RMD.RES_MGMT_MST_ID )
                LEFT OUTER JOIN TB_MP_SIMLT_GRP SMG ON ( SIT.ID = SMG.LOCAT_ITEM_ID )
                LEFT OUTER JOIN TB_MP_SIMLT_RES SML ON ( SMG.ID = SML.SIMLT_PRDUCT_GRP_ID AND RMD.ID = SML.RES_ID )
                LEFT OUTER JOIN TB_MP_ROUTE RTN ON (RTN.ID = SMG.ROUTE_ID)
            WHERE
                LMG.ID = @P_LOC_MGMT_ID
                AND SIT.ITEM_MST_ID = @P_ITEM_MST_ID
                AND 1 = CASE
                            WHEN @P_SIMLT_RES_ID = ''     THEN 1
                            WHEN SMG.ID = @P_SIMLT_RES_ID THEN 1
                        END;
		END
END

go

