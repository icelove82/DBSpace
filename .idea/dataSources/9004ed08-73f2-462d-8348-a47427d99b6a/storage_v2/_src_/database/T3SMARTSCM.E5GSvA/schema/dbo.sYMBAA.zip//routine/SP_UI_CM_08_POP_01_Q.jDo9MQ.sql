CREATE PROCEDURE [dbo].[SP_UI_CM_08_POP_01_Q] (
    @P_CONF_KEY              AS NVARCHAR(100) = '',
    @P_SHPP_LEADTIME_DTL_ID  AS NVARCHAR(100) = ''
)
AS SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
BEGIN

    IF @P_CONF_KEY = 'DAILY' /* SCHEDULE - DAILY */
        BEGIN 
            SELECT A.MON_YN
                 , A.TUE_YN
                 , A.WED_YN
                 , A.THU_YN
                 , A.FRI_YN
                 , A.SAT_YN
                 , A.SUN_YN
                 , A.ACTV_YN
              FROM TB_CM_SHIP_LT_DAILY_SCH A 
             WHERE A.SHPP_LEADTIME_DTL_ID = @P_SHPP_LEADTIME_DTL_ID
        END
    
    ELSE IF @P_CONF_KEY = 'MONTHLY' /* SCHEDULE - MONTHLY */
        BEGIN
			WITH DAY_OF_MONTH AS (
				SELECT 1 AS DD 
				UNION ALL 
				SELECT DD + 1 
				FROM   DAY_OF_MONTH 
				WHERE  DD <= 30
			)
			SELECT CASE WHEN B.DD IS NULL THEN A.DD ELSE B.DD END AS DD,
				   CASE WHEN B.ACTV_YN IS NULL THEN A.ACTV_YN ELSE B.ACTV_YN END AS ACTV_YN
			  FROM (
				   SELECT DD AS DD
						, 'N' AS ACTV_YN
					 FROM DAY_OF_MONTH
				   ) A
				   LEFT OUTER JOIN 
				   (
					SELECT RTRIM(A.DD) AS DD
						 , ACTV_YN
					  FROM TB_CM_SHIP_LT_MONTHLY_SCH A
					 WHERE A.SHPP_LEADTIME_DTL_ID = @P_SHPP_LEADTIME_DTL_ID
				   ) B
				   ON A.DD = B.DD
        END
    
    ELSE IF @P_CONF_KEY = 'EXCEPT_DAILY' /* EXCEPTION - DAILY */
        BEGIN 
            SELECT A.ID
                 , A.STRT_DATE
                 , A.END_DATE
                 , A.MON_YN
                 , A.TUE_YN
                 , A.WED_YN
                 , A.THU_YN
                 , A.FRI_YN
                 , A.SAT_YN
                 , A.SUN_YN
                 , A.ACTV_YN
              FROM TB_CM_SHIP_LT_EXCEPTION_SCH A 
             WHERE A.SHPP_LEADTIME_DTL_ID = @P_SHPP_LEADTIME_DTL_ID
               AND A.TRANSFER_DD IS NULL
        END
    
    ELSE IF @P_CONF_KEY = 'EXCEPT_MONTHLY' /* EXCEPTION - MONTHLY */
        BEGIN 
            SELECT A.ID
                 , A.STRT_DATE
                 , A.END_DATE
                 , A.TRANSFER_DD
                 , A.ACTV_YN
              FROM TB_CM_SHIP_LT_EXCEPTION_SCH A
             WHERE A.SHPP_LEADTIME_DTL_ID = @P_SHPP_LEADTIME_DTL_ID
               AND A.TRANSFER_DD IS NOT NULL
        END
    
    ELSE IF @P_CONF_KEY = 'HOLIDAY' /* HOLIDAY */
        BEGIN
            SELECT A.ID 
                 , A.SHPP_LEADTIME_DTL_ID
                 , A.CALENDAR_ID
                 , A.CALENDAR_DESCRIP       AS CALENDAR_DESC
                 , A.STRT_DATE
                 , A.END_DATE
                 , A.CYCL_TP_ID             AS CYCLE_TYPE
                 , A.ACTV_YN
              FROM TB_CM_HOLIDAY A
             WHERE A.SHPP_LEADTIME_DTL_ID = @P_SHPP_LEADTIME_DTL_ID
        END

END

go

