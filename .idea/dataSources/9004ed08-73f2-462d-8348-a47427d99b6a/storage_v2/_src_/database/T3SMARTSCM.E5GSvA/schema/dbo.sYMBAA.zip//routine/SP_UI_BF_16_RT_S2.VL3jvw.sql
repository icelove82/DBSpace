CREATE PROCEDURE [dbo].[SP_UI_BF_16_RT_S2] 
(	 @P_VER_CD					NVARCHAR(50)
	,@P_USER_ID					NVARCHAR(100)
	,@P_SELECT_CRITERIA			NVARCHAR(30)
	,@P_PROCESS_NO				INT
	,@P_RT_ROLLBACK_FLAG		NVARCHAR(10)   = 'true'			OUTPUT
	,@P_RT_MSG					NVARCHAR(4000) = ''				OUTPUT		
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
/*************************************************************************************************************
	-- Calculating Accuracy & Select Best Value
	-- 
	-- History (Date / Writer / Comment)
	-- 2020.01.03 / kim sohee / draft
	-- 2020.01.08 / kim sohee / select_yn => select_seq
	-- 2020.01.08 / kim sohee / select best value
	-- 2020.01.23 / kim sohee / when accuracy is empty, select a best value based on cofiguration of default engine type.
	-- 2020.02.28 / kim sohee / change week rule : DP_WK (53 week per a year) 
	-- 2020.06.25 / kim sohee / mape_W => wape (only config code for setting right value about distribution rule)
	-- 2020.08.26 / kim sohee / add a zionex percentage calculated previous period based on attribute 03 of Group Code = "BF_BEST_SELECTION" in Configuration Table
	--						  / 이전 SELECT_SEQ를 참고하여 ZIO_P를 계산해주는 방식 (X)
	--						  / Zionex Percentage를 BEST_SELECTION의 SEQ로 계산하는게 아니라
								, 각 Version별 error 값을 갖고 sequenece 를 다시 매겨서 1인 값들을 추출하여 가져와야 함 
	-- 2020.11.23 / Kim sohee / wape 변경된 계산식 반영
*************************************************************************************************************/
DECLARE @P_ERR_STATUS INT = 0
	   ,@P_ERR_MSG NVARCHAR(4000)=''

 DECLARE @P_TARGET_BUKT_CD		NVARCHAR(50) = 'W'
		,@P_TARGET_TO_DATE		DATE 		     
		,@P_TARGET_FROM_DATE	DATE		  
--		,@P_VER_CD				NVARCHAR(50)
		,@P_ACCURACY_WK			INT			   = 4
		,@P_VER_CNT			    INT
		,@P_ZIO_SELECTION_CRI	NVARCHAR(250)
	;	 	
BEGIN TRY


--IF EXISTS ( SELECT *
--			  FROM TB_BF_CONTROL_BOARD_VER_DTL
--			 WHERE VER_CD = @P_VER_CD
--			   AND PROCESS_NO < @P_PROCESS_NO
--			   AND [STATUS] = 'Ready'
--		 )
--	BEGIN
--	   SET @P_ERR_MSG = 'Please complete the previous process first.'
--	   RAISERROR (@P_ERR_MSG,12, 1);  		
--	END
--IF EXISTS ( SELECT *
--			  FROM TB_BF_CONTROL_BOARD_VER_DTL
--			 WHERE VER_CD = @P_VER_CD
--			   AND PROCESS_NO = 1000
--			   AND [STATUS] = 'Completed'
--		 )
--	BEGIN
--	   SET @P_ERR_MSG = 'This version is aleady closed.'
--	   RAISERROR (@P_ERR_MSG,12, 1);  		
--	END
/*************************************************************************************************************
	-- Change Version Data
*************************************************************************************************************/
	UPDATE TB_BF_CONTROL_BOARD_VER_DTL
	   SET RUN_STRT_DATE = GETDATE()
	 WHERE VER_CD = @P_VER_CD
	   AND PROCESS_NO = @P_PROCESS_NO 
/*************************************************************************************************************
	-- Get Config Data
*************************************************************************************************************/
--	SELECT TOP 1 @P_VER_CD = VER_CD 
--	  FROM TB_BF_CONTROL_BOARD_VER_DTL 
--  ORDER BY CREATE_DTTM DESC

	SELECT @P_ACCURACY_WK = ISNULL(ATTR_01,4)
		 , @P_VER_CNT = ISNULL(ATTR_03, 8)
		 , @P_ZIO_SELECTION_CRI = ISNULL(ATTR_02, 'WAPE')
	  FROM TB_CM_COMM_CONFIG 
	 WHERE CONF_CD = @P_SELECT_CRITERIA
	   AND CONF_GRP_CD = 'BF_SELECT_CRITERIA'
	   AND ACTV_YN = 'Y'

 
	SELECT DISTINCT @P_TARGET_BUKT_CD   = TARGET_BUKT_CD
				  , @P_TARGET_TO_DATE   = INPUT_TO_DATE
				  , @P_TARGET_FROM_DATE = (SELECT TOP 1 LEAD(MIN(DAT),@P_ACCURACY_WK) OVER(ORDER BY  CASE WHEN TARGET_BUKT_CD='M' THEN YYYYMM ELSE DP_WK END  DESC) -- DP_WK DESC) 
										   FROM TB_CM_CALENDAR 
										  --WHERE DAT BETWEEN DATEADD(WEEK, @P_ACCURACY_WK*-1, DATEADD(DAY,+1,INPUT_TO_DATE)) 
										  WHERE DAT BETWEEN CASE WHEN TARGET_BUKT_CD='M' THEN DATEADD(MONTH, @P_ACCURACY_WK*-1, DATEADD(DAY,+1,INPUT_TO_DATE)) ELSE DATEADD(WEEK, @P_ACCURACY_WK*-1, DATEADD(DAY,+1,INPUT_TO_DATE)) END
											AND DATEADD(DAY,+1,INPUT_TO_DATE)
									   GROUP BY  CASE WHEN TARGET_BUKT_CD='M' THEN YYYYMM ELSE DP_WK END 
					 )
	 FROM TB_BF_CONTROL_BOARD_VER_DTL
    WHERE VER_CD = @P_VER_CD
	  AND ENGINE_TP_CD IS NOT NULL

--	   SELECT   @P_TARGET_BUKT_CD   
--			  , @P_TARGET_TO_DATE   
--			  , @P_TARGET_FROM_DATE 

/***************************************************************************************************************
	-- Get Previous Version 
***************************************************************************************************************/
 

/****************************************************************************************************************/
--	IF EXISTS (	SELECT TOP 100 BASE_DATE 
--				  FROM TB_BF_RT_HISTORY H
--				 WHERE DATEPART(DW, BASE_DATE) = 1
--				ORDER BY CREATE_DTTM DESC 
--			 )
--		BEGIN
--		   SET @P_ERR_MSG = 'configuration of start week is different with start week of recent Result data'
--		   RAISERROR (@P_ERR_MSG,12, 1);  		
--		END

 
/*************************************************************************************************************
	-- Delete same version Data
*************************************************************************************************************/
DELETE FROM TB_BF_RT_ACCRCY
  WHERE VER_CD = @P_VER_CD
  ;
/*************************************************************************************************************
	-- Get Forecast & Sales
*************************************************************************************************************/
WITH IA
AS (
--	SELECT ITEM_CD, ACCOUNT_CD, ENGINE_TP_CD 
--	  FROM TB_BF_RT
--	 WHERE VER_CD = @P_VER_CD
--  GROUP BY ITEM_CD, ACCOUNT_CD, ENGINE_TP_CD
	SELECT ITEM_CD, ACCOUNT_CD
		 , case when ENGINE_TP_CD like 'ZAUTO%' then 'ZAUTO' else ENGINE_TP_CD end ENGINE_TP_CD
	  FROM TB_BF_RT
	 WHERE VER_CD = @P_VER_CD
  GROUP BY ITEM_CD, ACCOUNT_CD, case when ENGINE_TP_CD like 'ZAUTO%' then 'ZAUTO' else ENGINE_TP_CD end
)
, IA_ONLY
AS (
	SELECT ITEM_CD, ACCOUNT_CD
	FROM IA
	GROUP BY ITEM_CD, ACCOUNT_CD
)
, TARGET_IA 
AS (
	SELECT IH.DESCENDANT_ID	AS ITEM_ID
		 , IH.DESCENDANT_CD	AS ITEM_CD
		 , IH.ANCESTER_CD	AS P_ITEM_CD
		 , SH.DESCENDANT_ID	AS ACCT_ID
		 , SH.DESCENDANT_CD	AS ACCT_CD
		 , SH.ANCESTER_CD	AS P_ACCT_CD 		
	 FROM TB_BF_ITEM_ACCOUNT_MODEL_MAP S 
		   INNER JOIN 
		   TB_DPD_ITEM_HIER_CLOSURE IH
		ON S.ITEM_CD = IH.DESCENDANT_CD
	   AND IH.LEAF_YN = 'Y' 
	   AND IH.LV_TP_CD = 'I'
	       INNER JOIN 
		   TB_DPD_SALES_HIER_CLOSURE SH
		ON S.ACCOUNT_CD = SH.DESCENDANT_CD
	   AND SH.LEAF_YN = 'Y' 
	   AND SH.LV_TP_CD = 'S'
	   	   INNER JOIN 
	   	   IA_ONLY IA
	   	ON IA.ITEM_CD = IH.ANCESTER_CD 
	   AND IA.ACCOUNT_CD = SH.ANCESTER_CD 
	WHERE ACTV_YN = 'Y' 
)
, RT
AS (
	 SELECT ITEM_CD
	 	  , ACCOUNT_CD
	 	  , BASE_DATE
	 	  , case when ENGINE_TP_CD like 'ZAUTO%' then 'ZAUTO' else ENGINE_TP_CD end ENGINE_TP_CD
	 	  , QTY
	 	  , VER_CD
	   FROM TB_BF_RT_HISTORY 
	  WHERE BASE_DATE BETWEEN @P_TARGET_FROM_DATE AND @P_TARGET_TO_DATE
)
, CALENDAR
AS (
	SELECT DAT 
         , YYYY
         , YYYYMM
		 , CASE @P_TARGET_BUKT_CD
			WHEN 'W' THEN DATEPART(ISO_WEEK, DAT)
			WHEN 'PW'THEN DATEPART(ISO_WEEK, DAT)
			WHEN 'M' THEN YYYYMM
		   END AS BUKT	
	  FROM TB_CM_CALENDAR
	 WHERE DAT BETWEEN @P_TARGET_FROM_DATE AND @P_TARGET_TO_DATE
​
), CAL
AS (
	SELECT MIN(DAT)	AS STRT_DATE
		,  MAX(DAT) AS END_DATE 
		--,  BUKT
         , CASE @P_TARGET_BUKT_CD
            WHEN 'W' THEN CONVERT(VARCHAR(4), MIN(YYYY)) + ' w' +REPLICATE('0', 2-LEN(BUKT)) + CONVERT(NVARCHAR(2), BUKT)
            WHEN 'PW' THEN CONVERT(VARCHAR(6), MIN(YYYYMM)) + ' w' +REPLICATE('0', 2-LEN(BUKT)) + CONVERT(NVARCHAR(2), BUKT)
            WHEN 'M' THEN CONVERT(VARCHAR(6), MIN(YYYYMM))
            END AS BUKT
	  FROM CALENDAR 
  GROUP BY BUKT
 ), ACT_SALES
 AS (
	SELECT ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, QTY, AMT, QTY_CORRECTION, AMT_CORRECTION, CORRECTION_YN
	  FROM TB_CM_ACTUAL_SALES
    WHERE BASE_DATE BETWEEN @P_TARGET_FROM_DATE AND @P_TARGET_TO_DATE         
 ), SA_IA
 AS (
	SELECT P_ITEM_CD 		 
		 , P_ACCT_CD
		 , S.BASE_DATE
    	 , SUM(ISNULL(CASE CORRECTION_YN WHEN 'Y' THEN QTY_CORRECTION ELSE QTY END,0 ))		AS QTY
    	 , SUM(ISNULL(CASE CORRECTION_YN WHEN 'Y' THEN AMT_CORRECTION ELSE AMT END,0 ))		AS AMT 
	 FROM  ACT_SALES S 
		   INNER JOIN 
		   TARGET_IA M
		ON S.ITEM_MST_ID = M.ITEM_ID 
	   AND S.ACCOUNT_ID = M.ACCT_ID
	GROUP BY P_ITEM_CD 		 
		 , P_ACCT_CD
		 , S.BASE_DATE
 )
 , SA
AS (
	SELECT M.P_ITEM_CD		AS ITEM_CD  
		 , M.P_ACCT_CD  	AS ACCOUNT_CD  
    	 , CAL.STRT_DATE   
    	 , CAL.END_DATE     
    	 , SUM(COALESCE(QTY,0)) AS QTY
    	 , SUM(COALESCE(AMT,0)) AS AMT  
      FROM CAL 
		   CROSS JOIN 
		   TARGET_IA M			   
           LEFT OUTER JOIN
 		   SA_IA S WITH(NOLOCK)
 		ON S.BASE_DATE BETWEEN CAL.STRT_DATE AND CAL.END_DATE 
	   AND M.P_ITEM_CD = S.P_ITEM_CD
	   AND M.P_ACCT_CD = S.P_ACCT_CD
     GROUP BY M.P_ITEM_CD
     		, M.P_ACCT_CD
            , CAL.STRT_DATE
            , CAL.END_DATE     
)
,SA_SUM
AS (
	SELECT  ITEM_CD
		  , ACCOUNT_CD
		  , SUM(QTY)		AS QTY
	  FROM SA 
  GROUP BY ITEM_CD, ACCOUNT_CD
),SA_AVG
AS (
	SELECT  ITEM_CD
		  , ACCOUNT_CD
		  , AVG(QTY)		AS QTY
	  FROM SA 
  GROUP BY ITEM_CD, ACCOUNT_CD
)
/*************************************************************************************************************
	-- Calculating Accuracy
*************************************************************************************************************/
INSERT INTO TB_BF_RT_ACCRCY
	(	 ID				 
		,ENGINE_TP_CD	 
		,VER_CD			 
		,ITEM_CD		 
		,ACCOUNT_CD		 
		,MAPE			 
		,MAE			 
		,MAE_P			 
		,RMSE			 
		,RMSE_P			 
		,WAPE 			 
		,SELECT_SEQ	 
		,CREATE_BY		 
		,CREATE_DTTM	 
		,MODIFY_BY		 
		,MODIFY_DTTM	 
	)
SELECT   REPLACE(NEWID(),'-','')									AS ID
	   , IA.ENGINE_TP_CD 											
	   , @P_VER_CD
	   , IA.ITEM_CD
 	   , IA.ACCOUNT_CD
	   , MAPE	
	   , MAE	
	   , MAE_P
	   , RMSE	
	   , RMSE_P
	   , WAPE
	   , ROW_NUMBER() OVER (PARTITION BY IA.ITEM_CD, IA.ACCOUNT_CD 
								ORDER BY CASE WHEN 
											CASE @P_SELECT_CRITERIA
											WHEN 'MAPE'		THEN MAPE
											WHEN 'WAPE'		THEN WAPE
--											WHEN 'MAPE_W'   THEN MAPE_W 
											WHEN 'MAE'		THEN MAE
											WHEN 'MAE_P'	THEN MAE_P
											WHEN 'RMSE'		THEN RMSE
											WHEN 'RMSE_P'	THEN RMSE_P
										 END IS NULL THEN 1 ELSE 0 END ASC, 
										 	CASE @P_SELECT_CRITERIA
											WHEN 'MAPE'		THEN MAPE
											WHEN 'WAPE'		THEN WAPE
--											WHEN 'MAPE_W'   THEN MAPE_W 
											WHEN 'MAE'		THEN MAE
											WHEN 'MAE_P'	THEN MAE_P
											WHEN 'RMSE'		THEN RMSE
											WHEN 'RMSE_P'	THEN RMSE_P END ASC, C.DEFAT_VAL DESC)					AS SELECT_SEQ
	   , @P_USER_ID	
	   , GETDATE()
	   , NULL
	   , NULL
  FROM IA
	   LEFT OUTER JOIN	 
	   (
		 SELECT  A.ENGINE_TP_CD 	   
			   , A.ITEM_CD
		 	   , A.ACCOUNT_CD
		 	   , CASE WHEN AVG(ERR/SALES 	)*100 > 100 THEN 100 
		 	   		  ELSE AVG(ERR/SALES 	)*100 END						AS MAPE		-- SUM(ABS(예측-실적)/실적)/n
		 	   , AVG(ERR)													AS MAE		-- SUM(ABS(예측-실적)/n
		 	   , AVG(ERR)/AVG(SALES)*100									AS MAE_P	-- SUM(ABS(예측-실적)/n / SUM(실적)/n
		 	   , SQRT(AVG(ERR*ERR))											AS RMSE		-- SUM(ABS(예측-실적)제곱)/n의 루트
		 	   , SQRT(AVG(ERR*ERR))/AVG(SALES)*100							AS RMSE_P	 			
--			   , SUM(ABS(SALES-FCS))/SUM(SALES) * 100						AS WAPE
			   , CASE 
				  WHEN SUM(ERR) = 0 THEN 0 
				  ELSE (CASE WHEN SUM(ERR)/SUM(SALES)<=1 THEN SUM(ERR)/SUM(SALES) ELSE 1 END)  * 100
				 END														AS WAPE		
				 -- 2021.04.27 https://github.com/zionex/cautious-enigma/blob/master/python/zionexar/bf_util.py#L466
			     -- Weighted MAPE은 MAPE의 0처리를 위한 것
			     -- Sales가 0일경우 0나누기 오류가 발생해서, Sales의 합계로 나눔.
			     -- 링크(https://en.wikipedia.org/wiki/Demand_forecasting)의 수식을 보고 실적/실적합으로 계산하여 곱해줬는데, 
				 -- https://towardsdatascience.com/forecast-kpi-rmse-mae-mape-bias-cdc5703d242d
		  FROM (
					SELECT RT.ITEM_CD
						,  RT.ACCOUNT_CD
						,  RT.BASE_DATE
						,  RT.ENGINE_TP_CD
						,  RT.VER_CD
						,  ABS(SA.QTY - RT.QTY)						AS ERR	 -- ABS(예측-실적)
						, RT.QTY+0.00001									AS FCS
						,  convert(FLOAT,SA.QTY) + 0.00001			AS SALES -- For Calculating % 
						,  convert(FLOAT,SA.QTY) 					AS ORG_SALES
						,  SA_AVG.QTY	+ 0.00001					AS SA_AVG
--						,  CASE SA_SUM.QTY WHEN 0 THEN 0 ELSE SA.QTY/SA_SUM.QTY END	AS W
					  FROM RT 
						   INNER JOIN
						   SA    
						ON RT.ITEM_CD = SA.ITEM_CD
					  AND RT.ACCOUNT_CD = SA.ACCOUNT_CD
					   AND RT.BASE_DATE BETWEEN SA.STRT_DATE AND SA.END_DATE
--						   INNER JOIN
--						   SA_SUM
--						ON RT.ITEM_CD = SA_SUM.ITEM_CD
--					   AND RT.ACCOUNT_CD = SA_SUM.ACCOUNT_CD
						   INNER JOIN
						   SA_AVG
						ON RT.ITEM_CD = SA_AVG.ITEM_CD
					   AND RT.ACCOUNT_CD = SA_AVG.ACCOUNT_CD

				) A
		GROUP BY A.ITEM_CD
			  ,  A.ACCOUNT_CD 
			  ,  A.ENGINE_TP_CD 
	 ) A
  ON IA.ITEM_CD = A.ITEM_CD
 AND IA.ACCOUNT_CD = A.ACCOUNT_CD
 AND IA.ENGINE_TP_CD = A.ENGINE_TP_CD
	 INNER JOIN
	 TB_CM_COMM_CONFIG C WITH(NOLOCK)
   ON IA.ENGINE_TP_CD = C.CONF_CD 
  AND C.CONF_GRP_CD = 'BF_ENGINE_TP'
	 ;
/***************************************************************************************************************
	-- Calculate Zionex Percent
***************************************************************************************************************/
--IF (@P_SELECT_CRITERIA = 'ZIO_P')
--	BEGIN
--		DECLARE @TB_PREV_VERSION TABLE (VER_cD NVARCHAR(50))
--			   ;
--		INSERT INTO @TB_PREV_VERSION (VER_cD)
--		SELECT  VER_CD 
--		  FROM (
--			SELECT VER_CD
--				 , ROW_NUMBER() OVER (ORDER BY VER_CD DESC)  AS RW
--			 FROM TB_BF_CONTROL_BOARD_VER_DTL
--			WHERE (PROCESS_NO = 990 OR PROCESS_NO = 990000) 
--			  AND STATUS = 'Completed'
--		--	  AND VER_cD != @P_VER_CD
--			   ) A
--		  WHERE RW <= @P_VER_CNT	-- -1
--		  ;
----		select *
----		  FROM @TB_PREV_VERSION
----		  ;
--		WITH ERROR
--		AS (
--			SELECT VER_CD, ENGINE_TP_CD, ITEM_CD, ACCOUNT_CD
--				 , ROW_NUMBER() OVER (PARTITION BY RT.VER_CD, RT.ITEM_CD, RT.ACCOUNT_CD  
--									   ORDER BY CASE @P_ZIO_SELECTION_CRI 
--													WHEN 'MAPE'		THEN MAPE
--													WHEN 'WAPE'		THEN WAPE
--													WHEN 'MAE'		THEN MAE
--													WHEN 'MAE_P'	THEN MAE_P
--													WHEN 'RMSE'		THEN RMSE
--													WHEN 'RMSE_P'	THEN RMSE_P
--												END ASC
--											  , C.DEFAT_VAL DESC) AS SELECT_SEQ 
--			  FROM TB_BF_RT_ACCRCY RT
--			 LEFT OUTER JOIN
--			 TB_CM_COMM_CONFIG C
--		   ON RT.ENGINE_TP_CD = C.CONF_CD 
--		  AND C.CONF_GRP_CD = 'BF_ENGINE_TP'
--			 WHERE VER_CD IN (SELECT VER_CD FROM @TB_PREV_VERSION)
--		),BEST_SELECTION
--		  AS (  
--				SELECT ENGINE_TP_CD, ITEM_CD, ACCOUNT_CD 
--					 , SUM(SELECT_SEQ) AS SEQ_SUM
--				 FROM ERROR
--				 WHERE 1=1
--		--		   AND VER_cD IN (SELECT VER_CD FROM @TB_PREV_VERSION)
--				   AND SELECT_SEQ = 1 
--		GROUP BY ENGINE_TP_CD, ITEM_CD, ACCOUNT_CD
--		), VER
--		AS (
--			SELECT ITEM_CD, ACCOUNT_CD, ENGINE_TP_CD, SELECT_SEQ 
--			 FROM ERROR
--			WHERE VER_CD = @P_VER_CD 
--		), M
--		AS ( 
--			SELECT VE.ENGINE_TP_CD, VE.ITEM_CD, VE.ACCOUNT_CD --, MM.SEQ_SUM, VE.SELECT_SEQ, SUM(SEQ_SUM) OVER (PARTITION BY VE.ITEM_CD, VE.ACCOUNT_CD) AS SEQ_SUM 
--				 , CONVERT( FLOAT, ISNULL(MM.SEQ_SUM,0)) /  SUM(SEQ_SUM) OVER (PARTITION BY VE.ITEM_CD, VE.ACCOUNT_CD)*100 AS RT   
--				 , ROW_NUMBER() OVER (PARTITION BY VE.ITEM_CD, VE.ACCOUNT_CD ORDER BY CONVERT( FLOAT, ISNULL(MM.SEQ_SUM,0)) DESC, VE.SELECT_SEQ ASC) AS SEQ
--			  FROM VER VE 
--				   LEFT OUTER JOIN 
--				   BEST_SELECTION MM  
--				ON VE.ITEM_CD = MM.ITEM_CD
--			   AND VE.ACCOUNT_CD = MM.ACCOUNT_CD
--			   AND VE.ENGINE_TP_CD = MM.ENGINE_TP_CD	
--		--ORDER BY ITEM_CD, ACCOUNT_CD,  ENGINE_TP_CD 
--			)
--				UPDATE TB_BF_RT_ACCRCY
--				  SET ZIO_P = RT
--					 ,SELECT_SEQ = SEQ
--				 FROM M
--				WHERE TB_BF_RT_ACCRCY.ITEM_CD		= M.ITEM_CD 
--				  AND TB_BF_RT_ACCRCY.ACCOUNT_CD	= M.ACCOUNT_CD	
--				  AND TB_BF_RT_ACCRCY.ENGINE_TP_CD	= M.ENGINE_TP_CD
--				  AND TB_BF_RT_ACCRCY.VER_CD = @P_VER_CD 
--				;
--
--	END


/*************************************************************************************************************
	-- Change Version Data
*************************************************************************************************************/
	UPDATE TB_BF_CONTROL_BOARD_VER_DTL
	   SET RULE_01 = @P_SELECT_CRITERIA
		 , [STATUS] = 'Completed'
		 , RUN_END_DATE = GETDATE()
	 WHERE VER_CD = @P_VER_CD
	   AND PROCESS_NO = @P_PROCESS_NO 
/*************************************************************************************************************
	-- Result Message
*************************************************************************************************************/
	    SET @P_RT_MSG = 'MSG_0001'
	    SET @P_RT_ROLLBACK_FLAG = 'true'
END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END
	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR
END CATCH

 

go

