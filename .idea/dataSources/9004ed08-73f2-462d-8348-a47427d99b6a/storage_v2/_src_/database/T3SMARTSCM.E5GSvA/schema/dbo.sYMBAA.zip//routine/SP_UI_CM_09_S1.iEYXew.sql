/*****************************************************************************
Title : SP_UI_CM_09_S1
최초 작성자 : 곽명근
최초 생성일 : 2017.12.20
 
설명 
 - Site Packing Master 의 그리드상에서 수정 및 삭제 쿼리임. 
 
History (수정일자 / 수정자 / 수정내용)
- 2017.12.20 / 곽명근 / 최초 작성
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_CM_09_S1] 
(
	 @P_WRK_TYPE								AS NVARCHAR(10)
	,@P_ID										AS NVARCHAR(32)	= null
	,@P_PACKING_TP_ID							AS NVARCHAR(32)	= null
	,@P_PALLET_TP_ID							AS NVARCHAR(32)	= null
	,@P_UOM_PER_PACKING							AS NVARCHAR(50)	= null
	,@P_PACKING_PER_PALLET						AS NVARCHAR(50)	= null
	,@P_UNIT_WEIGHT	 							AS NVARCHAR(50)	= null
	,@P_WEIGHT_UOM_ID							AS NVARCHAR(32)	= null
	,@P_SITE_WAREHOUSE_MGMT_ID					AS NVARCHAR(32)	= null
	,@P_PALLET_LAYER							AS NVARCHAR(50)	= null	-- CHAGNE
	,@P_PACKING_CELLL						AS NVARCHAR(50)	= null		-- CHANGE
	,@P_FIXED_YN								AS CHAR(1) = 'Y'
	,@P_ACTV_YN									AS CHAR(1) = 'Y'
	,@P_USER_ID									AS NVARCHAR(50)	= null
	,@P_RT_ROLLBACK_FLAG						   NVARCHAR(10)   = 'true'  OUTPUT
	,@P_RT_MSG									   NVARCHAR(4000) = ''		OUTPUT
	
)
AS 

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''

	


BEGIN TRY

	IF @P_WRK_TYPE = 'SAVE'
		BEGIN
		
			UPDATE TB_CM_SITE_PACKING
			   SET
			       SITE_WAREHOUSE_MGMT_ID   =  @P_SITE_WAREHOUSE_MGMT_ID		
			     , PACKING_TP_CD_ID			=  @P_PACKING_TP_ID			
			     , PALLET_TP_ID				=  @P_PALLET_TP_ID			
			     , UOM_PER_PACKING			=  CAST(IIF(RTRIM(@P_UOM_PER_PACKING)='',null,@P_UOM_PER_PACKING) AS DECIMAL(20,3))	
			     , PACKING_PER_PALLET		=  CAST(IIF(RTRIM(@P_PACKING_PER_PALLET)='',null,@P_PACKING_PER_PALLET) AS DECIMAL(20,3))
			     , WEIGHT_UOM_ID			=  @P_WEIGHT_UOM_ID
			     , UNIT_WEIGHT				=  CAST(IIF(RTRIM(@P_UNIT_WEIGHT)='',null,@P_UNIT_WEIGHT) AS DECIMAL(20,3))
			     , PALLET_LAYER				=  CAST(IIF(RTRIM(@P_PALLET_LAYER)='',null,@P_PALLET_LAYER) AS DECIMAL(20,3))		
			     , PACKING_CELL				=  CAST(IIF(RTRIM(@P_PACKING_CELLL)='',null,@P_PACKING_CELLL) AS DECIMAL(20,3))	
			     , FIXED_YN					=  @P_FIXED_YN				
			     , ACTV_YN					=  @P_ACTV_YN		
				 , MODIFY_BY				=  @P_USER_ID
				 , MODIFY_DTTM				=  GETDATE()
		  WHERE ID = @P_ID

	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.
	
		END
	ELSE IF @P_WRK_TYPE = 'DELETE'
		BEGIN

			DELETE FROM TB_CM_SITE_PACKING
			WHERE ID = @P_ID 

	   SET @P_RT_MSG = 'MSG_0002'  --삭제 되었습니다.

		END
				              
	   SET @P_RT_ROLLBACK_FLAG = 'true'


END TRY

BEGIN CATCH
		IF(ERROR_MESSAGE() LIKE 'MSG_%')
			BEGIN
				SET @P_ERR_MSG = ERROR_MESSAGE()
				SET @P_RT_ROLLBACK_FLAG = 'false'
				SET @P_RT_MSG = @P_ERR_MSG
			END
		ELSE
			THROW;

END CATCH




go

