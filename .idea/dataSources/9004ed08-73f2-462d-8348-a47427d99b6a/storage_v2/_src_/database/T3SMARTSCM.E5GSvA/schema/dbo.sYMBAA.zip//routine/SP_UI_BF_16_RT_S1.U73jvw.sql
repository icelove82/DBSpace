CREATE PROCEDURE [dbo].[SP_UI_BF_16_RT_S1] 
(	 @P_ENGINE_TP_CD		NVARCHAR(30) = 'HISTORIC_FP'
	,@P_VER_CD				NVARCHAR(50)
	,@P_USER_ID				NVARCHAR(50)
	,@P_RT_ROLLBACK_FLAG		NVARCHAR(10)   = 'true'			OUTPUT
	,@P_RT_MSG					NVARCHAR(4000) = ''				OUTPUT		
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
/*************************************************************************************************************
	-- Create BF Input Data by Actual Sales (시계열 & 회귀)
	TARGET BUCKET은 INPUT BUCKET이랑 동일
	TARGET 시작일은 INPUT 끝나는날 다음..
	TARGET 구간은 Forecast Pro에서 설정해줘야 함. (선택사항 > 예측 구간)

	[분배 대상]
	- Item & Account Level
	- date (추후 결정) : Result table에서는 item, account level 분배만
	-- History (Date / Writer / comment)
	- 2019.12.18 / Kimsohee / draft
	- 2020.01.08 / Kimsohee / version Code를 UI에서 가져와 조회하게 수정
	- 2020.02.28 / kimsohee / change week rule : DP_WK (53 week per a year) 
	- 2020.06.22 / Kimsohee / change a rule about bucket
*************************************************************************************************************/
-- DECLARE  @P_ENGINE_TP_CD		NVARCHAR(30) = 'STATISTIC_FP'
		-- 1. For Setting Version Data
DECLARE @P_ERR_STATUS INT = 0
	   ,@P_ERR_MSG NVARCHAR(4000)=''

DECLARE  @P_INPUT_FROM_DATE		DATE			
		,@P_INPUT_TO_DATE		DATE
		,@P_INPUT_BUKT_CD		NVARCHAR(30)
		,@P_INPUT_HORIZ			INT				
		,@P_SALES_LV_CD			NVARCHAR(100)
		,@P_ITEM_LV_CD			NVARCHAR(100)
		,@P_TARGET_FROM_DATE	DATE			
		,@P_TARGET_TO_DATE		DATE
		,@P_TARGET_BUKT_CD		NVARCHAR(30)
		,@P_TARGET_HORIZ		INT				
		,@P_RULE_01		NVARCHAR(30)	-- EV/ AS
		,@P_LEAF_ITEM_CD		NVARCHAR(100)	-- LEAF ITEM
		,@P_LEAF_ACCT_CD		NVARCHAR(100)
		,@P_STD_WK				NVARCHAR(30)
		;	
BEGIN TRY
--IF EXISTS ( SELECT *
--			  FROM TB_BF_CONTROL_BOARD_VER_DTL
--			 WHERE VER_CD = @P_VER_CD
--			   AND PROCESS_NO = 1000
--			   AND [STATUS] = 'Completed'
--		 )
--	BEGIN
--	   SET @P_ERR_MSG = 'This version is aleady closed.'
--	   RAISERROR (@P_ERR_MSG,12, 1);  		
--	END
/*************************************************************************************************************
	-- 1. Setting Version Data
*************************************************************************************************************/
	  SELECT @P_INPUT_FROM_DATE	 = INPUT_FROM_DATE
			,@P_INPUT_TO_DATE	 = INPUT_TO_DATE
			,@P_INPUT_BUKT_CD	 = INPUT_BUKT_CD
			,@P_INPUT_HORIZ		 = INPUT_HORIZ
			,@P_SALES_LV_CD		 = SALES_LV_CD
			,@P_ITEM_LV_CD		 = ITEM_LV_CD
			,@P_TARGET_FROM_DATE = TARGET_FROM_DATE 
			,@P_TARGET_TO_DATE	 = TARGET_TO_DATE	 
			,@P_TARGET_BUKT_CD	 = TARGET_BUKT_CD	 
			,@P_TARGET_HORIZ	 = TARGET_HORIZ	 		
			,@P_RULE_01			 = RULE_01	
	  FROM TB_BF_CONTROL_BOARD_VER_DTL
	 WHERE ENGINE_TP_CD = @P_ENGINE_TP_CD 
	   AND VER_CD = @P_VER_CD
	; 
	  SELECT @P_LEAF_ITEM_CD = LV_CD 
		FROM TB_CM_LEVEL_MGMT 
	  WHERE ISNULL(SALES_LV_YN  ,'N') = 'N'
		AND ISNULL(ACCOUNT_LV_YN,'N') = 'N'
		AND LEAF_YN = 'Y' 
		AND ISNULL(DEL_YN,'N') = 'N' 
		AND ACTV_YN = 'Y'

	  SELECT @P_LEAF_ACCT_CD = LV_CD 
		FROM TB_CM_LEVEL_MGMT 
	  WHERE ISNULL(ACCOUNT_LV_YN,'N') = 'Y'
		AND LEAF_YN = 'Y' 
		AND ISNULL(DEL_YN,'N') = 'N' 
		AND ACTV_YN = 'Y'
		;
	 SELECT @P_STD_WK = UPPER(CONF_CD)
	  FROM TB_CM_COMM_CONFIG
	 WHERE CONF_GRP_CD = 'DP_STD_WEEK'
	   AND ACTV_YN = 'Y'
	   AND USE_YN = 'Y'
--	SET @P_STD_WK = 'MON'
/*************************************************************************************************************
	-- 2. Remove previous result data
*************************************************************************************************************/
	DELETE 
	  FROM TB_BF_RT
	 WHERE VER_CD = @P_VER_CD
	   AND ENGINE_TP_CD = @P_ENGINE_TP_CD
	;
/*************************************************************************************************************
	-- 3. Making Result data
*************************************************************************************************************/
WITH BF_OUTPUT
AS (
	SELECT  RTRIM(ItemId0) AS ITEM_CD
		  , RTRIM(ItemId1) AS ACCT_CD
		  , Description
		  , FC_Year		   AS YYYY
		  , FC_Period	   AS BUKT
		  , FC_Value	   AS QTY
	  FROM TB_BF_FC_BYPRDT_OUTPUT
	 WHERE @P_ENGINE_TP_CD = 'STATISTIC_FP'
	UNION
	SELECT  RTRIM(ItemId0) AS ITEM_CD
		  , RTRIM(ItemId1) AS ACCT_CD
		  , Description
		  , FC_Year
		  , FC_Period
		  , FC_Value
	  FROM TB_BF_FC_REG_OUTPUT
	 WHERE @P_ENGINE_TP_CD = 'REGRESSION_FP'
), MAIN_CAL
AS (
	SELECT DAT
		 , YYYY 
		 , CASE @P_INPUT_BUKT_CD
			WHEN 'W' THEN YYYY+CONVERT(NVARCHAR(2),DP_WK)
			WHEN 'PW'THEN YYYYMM+CONVERT(NVARCHAR(2),DP_WK) 
			WHEN 'M' THEN MM
			WHEN 'D' THEN YYYYMMDD 
		   END AS INPUT_BUKT	
		 , CASE @P_TARGET_BUKT_CD
			WHEN 'W' THEN YYYY+CONVERT(NVARCHAR(2),DP_WK)
			WHEN 'PW'THEN MM+CONVERT(NVARCHAR(2),DP_WK) 
			WHEN 'M' THEN MM
			WHEN 'D' THEN YYYYMMDD 
		   END AS TARGET_BUKT	
	  FROM TB_CM_CALENDAR
	 WHERE DAT BETWEEN @P_INPUT_FROM_DATE AND @P_TARGET_TO_DATE
), INPUT_CAL
AS (
	SELECT YYYY 
		 , MIN(DAT)					AS STRT_DATE
		 , MAX(DAT)					AS END_DATE
		 , INPUT_BUKT	
	  FROM MAIN_CAL
	 WHERE DAT BETWEEN @P_INPUT_FROM_DATE AND @P_INPUT_TO_DATE
 GROUP BY YYYY
		, INPUT_BUKT
), TARGET_CAL 
AS (
	SELECT YYYY
		 , MIN(DAT)					AS STRT_DATE
		 , MAX(DAT)					AS END_DATE
		 , TARGET_BUKT
	  FROM MAIN_CAL
	 WHERE DAT BETWEEN @P_TARGET_FROM_DATE AND @P_TARGET_TO_DATE
  GROUP BY YYYY
		 , TARGET_BUKT 
), ITEM_HIER 
AS (
	SELECT IH.ANCESTER_CD
		 , IH.DESCENDANT_CD
	  FROM TB_CM_LEVEL_MGMT LV
		   INNER JOIN
		   TB_CM_ITEM_LEVEL_MGMT IL
		ON IL.LV_MGMT_ID = LV.ID
       AND LV.LV_CD = @P_ITEM_LV_CD
		   INNER JOIN
		   TB_DPD_ITEM_HIER_CLOSURE  IH 
		ON IH.ANCESTER_CD = IL.ITEM_LV_CD
	 WHERE IH.LEAF_YN = 'Y' 	
), ACCT_HIER
AS (
	SELECT SH.ANCESTER_CD
		 , SH.DESCENDANT_CD
	  FROM TB_CM_LEVEL_MGMT LV
		   INNER JOIN
		   TB_DP_SALES_LEVEL_MGMT SL
		ON SL.LV_MGMT_ID = LV.ID
       AND LV.LV_CD = @P_ITEM_LV_CD
		   INNER JOIN
		   TB_DPD_ITEM_HIER_CLOSURE  SH 
		ON SH.ANCESTER_CD = SL.SALES_LV_CD 
	 WHERE SH.LEAF_YN = 'Y' 
)
INSERT INTO TB_BF_RT
		  ( ID
		  , ENGINE_TP_CD
		  , VER_CD
		  , ITEM_CD
		  , ACCOUNT_CD
		  , BASE_DATE
		  , QTY
		  , CREATE_BY
		  , CREATE_DTTM
		  , MODIFY_BY
		  , MODIFY_DTTM
		  )
	SELECT REPLACE(NEWID(), '-', '') AS ID
		  ,@P_ENGINE_TP_CD
		  ,@P_VER_CD		  
		  ,IH.DESCENDANT_CD
		  ,AH.DESCENDANT_CD
--		  ,TC.TARGET_BUKT
		  ,TC.STRT_DATE
		  ,SUM(BO.QTY)
		  ,@P_USER_ID
		  ,GETDATE()		  
		  ,NULL
		  ,NULL
	  FROM BF_OUTPUT BO
		   INNER JOIN 
		   ITEM_HIER IH 
		ON BO.ITEM_CD = IH.ANCESTER_CD
		   INNER JOIN
		   ACCT_HIER AH
	    ON BO.ACCT_CD = AH.ANCESTER_CD 
		   INNER JOIN 
		   INPUT_CAL IC
		ON BO.YYYY = IC.YYYY
	   AND BO.BUKT = IC.INPUT_BUKT	-- W
		   INNER JOIN
		   MAIN_CAL MC
		ON IC.INPUT_BUKT = MC.INPUT_BUKT
	   AND IC.YYYY = MC.YYYY 
		   INNER JOIN
		   TARGET_CAL TC 
		ON TC.YYYY = MC.YYYY
	   AND TC.TARGET_BUKT = MC.TARGET_BUKT
  GROUP BY IH.DESCENDANT_CD
  		  ,AH.DESCENDANT_CD
  --	  ,TC.TARGET_BUKT
  		  ,TC.STRT_DATE
  		 ;
/*
WITH 
FC_OUTPUT
AS (
	SELECT  RTRIM(ItemId0) AS ItemId0
		  , RTRIM(ItemId1) AS ItemId1
		  , Description
		  , UnitsDesc
		  , FC_Year	
		  , FC_Period		
		  , FC_Value
	  FROM TB_BF_FC_BYPRDT_OUTPUT
	 WHERE @P_ENGINE_TP_CD = 'STATISTIC_FP'
	UNION
	SELECT  RTRIM(ItemId0) AS ItemId0
		  , RTRIM(ItemId1) AS ItemId1
		  , Description
		  , UnitsDesc
		  , FC_Year
		  , FC_Period
		  , FC_Value
	  FROM TB_BF_FC_REG_OUTPUT
	 WHERE @P_ENGINE_TP_CD = 'REGRESSION_FP'
), CAL
AS (
	  SELECT MIN(DAT)		AS STRT_DATE
			,CASE @P_TARGET_BUKT_CD 
  	  			WHEN 'W' 	THEN DP_WK	-- STD_WK가 반영 안됨
  	  			WHEN 'M'	THEN MM
  	  			WHEN 'D'	THEN YYYYMMDD
  			 ELSE YYYYMMDD END	AS TG_PERIOD
		    ,YYYY
		FROM TB_CM_CALENDAR
	   WHERE DAT BETWEEN @P_TARGET_FROM_DATE AND @P_TARGET_TO_DATE
	     AND CASE @P_TARGET_BUKT_CD WHEN 'W' THEN DOW_NM ELSE @P_STD_WK END = @p_STD_WK
	GROUP BY CASE @P_TARGET_BUKT_CD 
  	  			WHEN 'W' 	THEN DP_WK--ISO_WK	
  	  			WHEN 'M'	THEN MM
  	  			WHEN 'D'	THEN YYYYMMDD
  			 ELSE YYYYMMDD END	 
		    ,YYYY
 ), TB_PR_ITEM_LEVEL_MGMT 
  ( ID
  , PATH_CD
  , PATH_ID
  , LV_CD
  , LEAF_ITEM_LV_ID
  , LEAF_ITEM_LV_CD
  ) 
AS(
		SELECT SL.ID
			 , CONVERT(NVARCHAR(4000), SL.ITEM_LV_CD) PATH_CD
			 , CONVERT(NVARCHAR(4000), SL.ID) [PATH_ID]
			 , LM.LV_CD
			 , SL.ID	AS LEAF_ITEM_LV_ID
			 , SL.ITEM_LV_CD AS LEAF_ITEM_LV_CD
		  FROM TB_CM_ITEM_LEVEL_MGMT SL
			   INNER JOIN
			   TB_CM_LEVEL_MGMT LM
			ON SL.LV_MGMT_ID = LM.ID
		 WHERE LV_CD = @P_ITEM_LV_CD
		UNION ALL	
		SELECT SL.ID
			 , CONVERT(NVARCHAR(4000), PATH_CD+'/'+SL.ITEM_LV_CD) AS PATH_CD		
			 , CONVERT(NVARCHAR(4000), [PATH_ID]+'/'+SL.ID) AS [PATH_ID]		
			 , LM.LV_CD
			 , SL.ID	AS LEAF_ITEM_LV_ID
			 , SL.ITEM_LV_CD AS LEAF_ITEM_LV_CD
		  FROM TB_CM_ITEM_LEVEL_MGMT SL
			   INNER JOIN
			   TB_PR_ITEM_LEVEL_MGMT PL
			ON SL.PARENT_ITEM_LV_ID = PL.ID
			   INNER JOIN
			   TB_CM_LEVEL_MGMT LM
			ON SL.LV_MGMT_ID = LM.ID
		 WHERE ISNULL(LM.DEL_YN,'N') = 'N'
		   AND ISNULL(SL.DEL_YN,'N') = 'N'
		   AND ISNULL(LM.SALES_LV_YN  ,'N') = 'N'
		   AND LM.ACTV_YN = 'Y'
		   AND SL.ACTV_YN = 'Y'
), TB_PR_SALES_LEVEL_MGMT 
 ( ID
 , PATH_CD
 , PATH_ID
 , LV_CD
 , LEAF_SALES_LV_ID
 , LEAF_SALES_LV_CD
 ) 
AS(
		SELECT SL.ID
			 , CONVERT(NVARCHAR(4000), SL.SALES_LV_CD) PATH_CD
			 , CONVERT(NVARCHAR(4000), SL.ID) [PATH_ID]
			 , LM.LV_CD
			 , SL.ID	AS LEAF_SALES_LV_ID
			 , SL.SALES_LV_CD AS LEAF_SALES_LV_CD
		  FROM TB_DP_SALES_LEVEL_MGMT SL
			   INNER JOIN
			   TB_CM_LEVEL_MGMT LM
			ON SL.LV_MGMT_ID = LM.ID
		 WHERE LV_CD = @P_SALES_LV_CD
		UNION ALL	
		SELECT SL.ID
			 , CONVERT(NVARCHAR(4000), PATH_CD+'/'+SL.SALES_LV_CD) AS PATH_CD		
			 , CONVERT(NVARCHAR(4000), [PATH_ID]+'/'+SL.ID) AS [PATH_ID]		
			 , LM.LV_CD
			 , SL.ID	AS LEAF_SALES_LV_ID
			 , SL.SALES_LV_CD AS LEAF_SALES_LV_CD
		  FROM TB_DP_SALES_LEVEL_MGMT SL
			   INNER JOIN
			   TB_PR_SALES_LEVEL_MGMT PL
			ON SL.PARENT_SALES_LV_ID = PL.ID
			   INNER JOIN
			   TB_CM_LEVEL_MGMT LM
			ON SL.LV_MGMT_ID = LM.ID
		 WHERE ISNULL(LM.DEL_YN,'N') = 'N'
		   AND ISNULL(SL.DEL_YN,'N') = 'N'
		   AND ISNULL(LM.SALES_LV_YN  ,'N') = 'Y'
		   AND LM.ACTV_YN = 'Y'
		   AND SL.ACTV_YN = 'Y'
)
INSERT INTO TB_BF_RT
		  ( ID
		  , ENGINE_TP_CD
		  , VER_CD
		  , ITEM_CD
		  , ACCOUNT_CD
		  , BASE_DATE
		  , QTY
		  , CREATE_BY
		  , CREATE_DTTM
		  , MODIFY_BY
		  , MODIFY_DTTM
		  )
SELECT  REPLACE(NEWID(), '-', '')																AS ID
	  , @P_ENGINE_TP_CD																			AS ENGINE_TP_CD	  
	  , @P_VER_CD																				AS VER_cD
	  , CASE @P_LEAF_ITEM_CD WHEN @P_ITEM_LV_CD  THEN BO.ITEMID0 ELSE IT.ITEM_CD		END 	AS ITEM_CD
	  , CASE @p_LEAF_ACCT_CD WHEN @P_SALES_LV_CD THEN BO.ITEMID1 ELSE AC.ACCOUNT_CD  END		AS ACCT_CD 
	  , CA.STRT_DATE																			AS BASE_DATE
	  , CASE @P_RULE_01 
			WHEN 'EV' THEN AVG(BO.FC_VALUE)			-- MAX(BO.FC_VALUE)	/ COUNT(BO.FC_VALUE)
			WHEN 'AS' THEN NULL						-- by Actual Sales
		ELSE AVG(BO.FC_VALUE) END																AS QTY -- 1/N Distribution	  
	  , @P_USER_ID
	  , GETDATE()
	  , NULL
	  , NULL 
  FROM FC_OUTPUT BO
	   INNER JOIN 
	   CAL CA
	ON BO.FC_YEAR = CA.YYYY
   AND BO.FC_PERIOD = CA.TG_PERIOD	
       -- FOR ITEM LEVEL
	   LEFT OUTER JOIN
	   TB_PR_ITEM_LEVEL_MGMT IL
	ON IL.PATH_CD LIKE BO.ItemId0+'%'
	   LEFT OUTER JOIN
	   TB_CM_ITEM_MST IT 
	ON IT.PARENT_ITEM_LV_ID = IL.LEAF_ITEM_LV_ID	 
	   -- FOR SALES LEVEL 
	   LEFT OUTER JOIN
	   TB_PR_SALES_LEVEL_MGMT SL
	ON SL.PATH_CD LIKE BO.ItemId1+'%'
	   LEFT OUTER JOIN
	   TB_DP_ACCOUNT_MST AC 
	ON AC.PARENT_SALES_LV_ID = SL.LEAF_SALES_LV_ID
GROUP BY CASE @P_LEAF_ITEM_CD WHEN @P_ITEM_LV_CD  THEN BO.ITEMID0 ELSE IT.ITEM_CD		END  
	    ,CASE @p_LEAF_ACCT_CD WHEN @P_SALES_LV_CD THEN BO.ITEMID1 ELSE AC.ACCOUNT_CD	END	
	    ,CA.STRT_DATE
-- ORDER BY 	   CASE @P_LEAF_ITEM_CD WHEN @P_ITEM_LV_CD  THEN BO.ITEMID0 ELSE IT.ITEM_CD		END 	 
-- 	  , CASE @p_LEAF_ACCT_CD WHEN @P_SALES_LV_CD THEN BO.ITEMID1 ELSE AC.ACCOUNT_CD  END		 
-- 	  ,  STRT_DATE 
*/	 
/*************************************************************************************************************
	-- 4. Making Result History data
*************************************************************************************************************/
MERGE TB_BF_RT_HISTORY TGT
USING ( SELECT ID
			  ,ENGINE_TP_CD
			  ,ITEM_CD
			  ,ACCOUNT_CD
			  ,BASE_DATE
			  ,QTY
			  ,VER_CD
			 , @P_USER_ID		AS [USER_ID]
			 , GETDATE()		AS DTTM
		  FROM TB_BF_RT 
		 WHERE ENGINE_TP_CD = @P_ENGINE_TP_CD
		   AND VER_cD = @P_VER_CD
	  ) SRC
  ON TGT.ITEM_CD = SRC.ITEM_CD
 AND TGT.ACCOUNT_CD = SRC.ACCOUNT_CD
 AND TGT.BASE_DATE = SRC.BASE_DATE
 AND TGT.ENGINE_TP_CD = SRC.ENGINE_TP_CD
WHEN MATCHED THEN
	UPDATE -- UPDATE의 SELECT_YN은 유지해야하나? N으로 바꿔야 하나? 데이터도 바꼈기 때문에 N?=>뭔지 몰라서 지움 2020.02.13
	   SET TGT.QTY = SRC.QTY
		 , TGT.VER_CD = SRC.VER_CD
		 , TGT.MODIFY_BY = SRC.[USER_ID]
		 , TGT.MODIFY_DTTM = SRC.DTTM
WHEN NOT MATCHED THEN
	INSERT ( ID
			,ENGINE_TP_CD
			,VER_CD
			,ITEM_CD
			,ACCOUNT_CD
			,BASE_DATE
			,QTY
			,CREATE_BY
			,CREATE_DTTM			
		   )
	 VALUES (SRC.ID
			,SRC.ENGINE_TP_CD
			,SRC.VER_CD
			,SRC.ITEM_CD
			,SRC.ACCOUNT_CD
			,SRC.BASE_DATE
			,SRC.QTY
			,SRC.[USER_ID]
			,SRC.DTTM
			)
		;
/*************************************************************************************************************
	-- 4. Making Result History data
*************************************************************************************************************/
	UPDATE TB_BF_CONTROL_BOARD_VER_DTL
	   SET [STATUS] = 'Completed'
		,  RUN_END_DATE = GETDATE()
	 WHERE VER_CD = @P_VER_CD
	   AND ENGINE_TP_CD = @P_ENGINE_TP_CD
	;
/*************************************************************************************************************/
	    SET @P_RT_MSG = 'MSG_0001'
	    SET @P_RT_ROLLBACK_FLAG = 'true'
END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END
	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR
END CATCH



go

