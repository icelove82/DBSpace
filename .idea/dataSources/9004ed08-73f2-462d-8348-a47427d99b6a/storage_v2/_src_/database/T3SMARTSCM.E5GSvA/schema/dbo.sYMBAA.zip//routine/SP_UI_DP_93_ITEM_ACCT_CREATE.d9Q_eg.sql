/*
	[ Title ] SP_UI_DP_93_ITEM_ACCT_CREATE
		- Setting new item & account & value into entry 

	[ Description ]
		1. Item Master
		- @P_ITEM_MST_ID	X
		- @P_ITEM_LV_ID		O
		- @P_ACCOUNT_ID		X
		- @P_ACCT_LV_ID		X
		- @P_USER_ID		X
		- @P_AUTH_TP_ID		X
		(1) item ID가 user_item_map, user_account_map에 있는 값인지 확인
		(2) 있다면, 해당 user ID를 임시테이블에 넣고, user account map 에서 해당하는 account ID 모두 찾기.
		(3) user item account exclude 테이블에서 item, account 조합 빼기

		2. Account Master
		(1) account ID가 user_account_map, user_account_map에 있는 값인지 확인
		(2) 있다면, 해당 user ID를 임시테이블에 넣고, user item map 에서 해당하는 item ID 모두 찾기.
		(3) user item account exclude 테이블에서 item, account 조합 빼기
		- @P_ITEM_MST_ID	X
		- @P_ITEM_LV_ID		X
		- @P_ACCOUNT_ID		O
		- @P_ACCT_LV_ID		X
		- @P_USER_ID		X
		- @P_AUTH_TP_ID		X

		3. User Item map
		(1) item level ID라면 최하단 item ID를 찾아주기
		(2) user account map 테이블에서 해당 user의 account ID 모두 찾기
		(3) user item account exclude 테이블에서 item, account 조합 빼기
		- @P_ITEM_MST_ID	O X
		- @P_ITEM_LV_ID		X O
		- @P_ACCOUNT_ID		X
		- @P_ACCT_LV_ID		X
		- @P_USER_ID		O
		- @P_AUTH_TP_ID		O

		4. User account map
		(1) sales level ID라면 최하단 account ID 찾아주기
		(2) user item map 테이블에서 해당 user의 item ID 모두 찾기
		(3) user item account exclude 테이블에서 item, account 조합 빼기
		- @P_ITEM_MST_ID	X
		- @P_ITEM_LV_ID		X
		- @P_ACCOUNT_ID		O X
		- @P_ACCT_LV_ID		X O
		- @P_USER_ID		O
		- @P_AUTH_TP_ID		O

		5. User item account map
		(1) user의 item,account를 바로 넣어주기	
		- @P_ITEM_MST_ID	O
		- @P_ITEM_LV_ID		X
		- @P_ACCOUNT_ID		O
		- @P_ACCT_LV_ID		X
		- @P_USER_ID		O
		- @P_AUTH_TP_ID		O

	[ History ( Date / Writer / Comment ) ]
		- 2020.12.02 / kim sohee / draft
		- 2020.12.04 / kim sohee / insert => merge 
		- 2021.02.15 / kim sohee / case : init qty value is none, bug fix
		- 2021.07.29 / kim sohee / add a case : bucket	
		- 2021.11.__ / kim sohee / add USE_YN

	[!] 프로시저를 실행하기 전에, Item & Account 조합으로 Entry에 동일 데이터가 존재하는지 체크할 것
	그 조합을 반드시 한명의 사용자가 관리하지는 않는다.
*/
CREATE PROCEDURE [dbo].[SP_UI_DP_93_ITEM_ACCT_CREATE]  (
	 @P_ITEM_MST_ID		CHAR(32)	-- Item Account User Map / Item Master 
	,@P_ITEM_LV_ID		CHAR(32)	
	,@P_ACCOUNT_ID		CHAR(32)	-- Item Account User Map / Account Master 
	,@P_ACCT_LV_ID		CHAR(32)
	,@P_USER_ID			CHAR(32)	-- Mapping data
	,@P_AUTH_TP_ID		CHAR(32)
	,@P_VER_ID			CHAR(32) 
)
AS
BEGIN
	/***********************************************************************************************************************************
		-- 1. Get a new map of Item & account
	***********************************************************************************************************************************/
	DECLARE @TB_USER	  TABLE ( EMP_ID CHAR(32) COLLATE  DATABASE_DEFAULT , AUTH_TP_ID CHAR(32) COLLATE DATABASE_DEFAULT )
	DECLARE @TB_ITEM	  TABLE ( ITEM_ID CHAR(32) COLLATE DATABASE_DEFAULT , EMP_ID CHAR(32) COLLATE DATABASE_DEFAULT , AUTH_TP_ID CHAR(32) COLLATE DATABASE_DEFAULT )
	DECLARE @TB_ACCT	  TABLE ( ACCT_ID CHAR(32) COLLATE DATABASE_DEFAULT , EMP_ID CHAR(32) COLLATE DATABASE_DEFAULT , AUTH_TP_ID CHAR(32) COLLATE DATABASE_DEFAULT )

	CREATE TABLE #IAC
	(
	  ITEM_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
	 ,ACCT_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
	 ,ROLE_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
	 ,EMP_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
	 ,BASE_DATE		DATE 
	)
	;
	/***********************************************************************************************************************************
		-- (1) USER		
	************************************************************************************************************************************/
	IF (@P_USER_ID IS NULL AND @P_ITEM_MST_ID IS NULL)	-- Account
		BEGIN
			INSERT INTO @TB_USER (EMP_ID, AUTH_TP_ID) 
			SELECT DISTINCT EMP_ID, AUTH_TP_ID  
			  FROM TB_DP_USER_ACCOUNT_MAP UA
				   INNER JOIN
				   TB_DPD_SALES_HIER_CLOSURE SH
				ON UA.SALES_LV_ID = SH.ANCESTER_ID AND SH.USE_YN='Y' and UA.ACTV_YN='Y'
			 WHERE SH.DESCENDANT_ID = @P_ACCOUNT_ID
			UNION
			SELECT DISTINCT EMP_ID, AUTH_TP_ID 
			  FROM TB_DP_USER_ACCOUNT_MAP
			 WHERE ACCOUNT_ID = @P_ACCOUNT_ID and ACTV_YN='Y'
			UNION
			SELECT DISTINCT EMP_ID, AUTH_TP_ID 
			  FROM TB_DP_USER_ITEM_ACCOUNT_MAP
			 WHERE ACCOUNT_ID = @P_ACCOUNT_ID and ACTV_YN='Y'
		END
	ELSE IF (@P_USER_ID IS NULL AND @p_ACCOUNT_ID IS NULL) -- Item
		BEGIN
			INSERT INTO @TB_USER
			SELECT DISTINCT EMP_ID, AUTH_TP_ID   
			  FROM TB_DP_USER_ITEM_MAP UA
				   INNER JOIN
				   TB_DPD_ITEM_HIER_CLOSURE SH
				ON UA.ITEM_LV_ID = SH.ANCESTER_ID and UA.ACTV_YN = 'Y' and SH.USE_YN='Y' 
			 WHERE SH.DESCENDANT_ID = @P_ITEM_MST_ID 
			UNION
			SELECT DISTINCT EMP_ID, AUTH_TP_ID   
			  FROM TB_DP_USER_ITEM_MAP
			 WHERE ITEM_MST_ID = @P_ITEM_MST_ID
			UNION
			SELECT DISTINCT EMP_ID, AUTH_TP_ID  
			  FROM TB_DP_USER_ITEM_ACCOUNT_MAP
			 WHERE ITEM_MST_ID = @P_ITEM_MST_ID		
		END
	ELSE -- @P_USER_ID IS NOT NULL	-- Mapping
		BEGIN
			INSERT INTO @TB_USER (EMP_ID, AUTH_TP_ID) 
			SELECT @P_USER_ID, @P_AUTH_TP_ID 
		END 

--		SELECT * FROM @TB_USER; 
	/***********************************************************************************************************************************
		-- (2) Item		
	************************************************************************************************************************************/
	-- Item Master ID or Account ID가 Null이면, DPD 테이블에서 item level ID와 Account Level ID데이터로 DESC ID 찾아주기.
	IF (@P_ITEM_MST_ID IS NULL AND @P_ITEM_LV_ID IS NULL)
		BEGIN
			-- Account mapping by user
			WITH ITEM
			  AS (
					SELECT CASE LV.LEAF_YN WHEN 'Y' THEN ITEM_MST_ID ELSE ITEM_LV_ID END AS ITEM_ID 
						  ,US.EMP_ID
						  ,US.AUTH_TP_ID
					  FROM TB_DP_USER_ITEM_MAP IM   
						   INNER JOIN 
						   @TB_USER US
						ON IM.AUTH_TP_ID = US.AUTH_TP_ID and IM.ACTV_YN ='Y'
					   AND IM.EMP_ID = US.EMP_ID
						   INNER JOIN 
						   TB_CM_LEVEL_MGMT LV 					   		   
						ON IM.LV_MGMT_ID = LV.ID
			     )
					INSERT INTO @TB_ITEM (ITEM_ID, EMP_ID, AUTH_TP_ID)
					SELECT IH.DESCENDANT_ID
						  ,IT.EMP_ID
						  ,IT.AUTH_TP_ID
					  FROM ITEM IT
					       INNER JOIN 
						   TB_DPD_ITEM_HIER_CLOSURE IH
						ON IT.ITEM_ID = IH.ANCESTER_ID
					   AND IH.LEAF_YN = 'Y'  and IH.USE_YN ='Y'
		END
	ELSE IF (@P_ITEM_MST_ID IS NULL AND @P_ITEM_LV_ID IS NOT NULL)	-- Item Level mapping by user
		BEGIN
			-- Insert leaf Item ID temp table
			INSERT INTO @TB_ITEM (ITEM_ID, EMP_ID, AUTH_TP_ID)
			SELECT DESCENDANT_ID
				 , @P_USER_ID
				 , @P_AUTH_TP_ID
			  FROM TB_DPD_ITEM_HIER_CLOSURE
			 WHERE ANCESTER_ID = @P_ITEM_LV_ID
			   AND LEAF_YN = 'Y'  and USE_YN = 'Y'
		END
	ELSE IF (@P_ITEM_MST_ID IS NOT NULL AND @P_ITEM_LV_ID IS NULL)
		BEGIN
			-- item master or item mapping by user 
			INSERT INTO @TB_ITEM (ITEM_ID, EMP_ID, AUTH_TP_ID)
 			SELECT @P_ITEM_MST_ID 			  		
				  ,EMP_ID
				  ,AUTH_TP_ID 
			  FROM @TB_USER
		END
--		SELECT * FROM @TB_ITEM;
	/***********************************************************************************************************************************
	-- (3) Account		
	************************************************************************************************************************************/
	IF (@P_ACCOUNT_ID IS NULL AND @P_ACCT_LV_ID IS NULL)
		BEGIN
			-- When User Item map, find account info by user ID
			WITH ACCT
			  AS (
					SELECT CASE LV.LEAF_YN WHEN 'Y' THEN ACCOUNT_ID ELSE SALES_LV_ID END AS ACCOUNT_ID 
						 , US.EMP_ID
						 , US.AUTH_TP_ID
					  FROM TB_DP_USER_ACCOUNT_MAP AM 
						   INNER JOIN
						   @TB_USER US
						ON AM.AUTH_TP_ID = US.AUTH_TP_ID
					   AND AM.EMP_ID = US.EMP_ID
						   INNER JOIN 
						   TB_CM_LEVEL_MGMT LV 					   		   
						ON AM.LV_MGMT_ID = LV.ID
			  )
			   INSERT INTO @TB_ACCT (ACCT_ID, EMP_ID, AUTH_TP_ID) 
				SELECT SH.DESCENDANT_ID
					 , AC.EMP_ID
					 , AC.AUTH_TP_ID
				  FROM ACCT AC
					   INNER JOIN
					   TB_DPD_SALES_HIER_CLOSURE SH
					ON AC.ACCOUNT_ID = SH.ANCESTER_ID
				   AND SH.LEAF_YN = 'Y'			
		END
	ELSE IF (@p_ACCOUNT_ID IS NULL AND @P_ACCT_LV_ID IS NOT NULL)
		BEGIN
			-- Insert leaf Account ID temp table
			INSERT INTO @TB_ACCT (ACCT_ID, EMP_ID, AUTH_TP_ID) 
			SELECT DESCENDANT_ID
				  ,@P_USER_ID
				  ,@P_AUTH_TP_ID
			  FROM TB_DPD_SALES_HIER_CLOSURE
			 WHERE ANCESTER_ID = @P_ACCT_LV_ID
			   AND LEAF_YN = 'Y' 
		END
	ELSE IF (@P_ACCOUNT_ID IS NOT NULL AND @P_ACCT_LV_ID IS NULL)
		BEGIN
			INSERT INTO @TB_ACCT (ACCT_ID, EMP_ID, AUTH_TP_ID) 
			SELECT @P_ACCOUNT_ID
				  ,EMP_ID
				  ,AUTH_TP_ID 
			  FROM @TB_USER

		END
--		SELECT * FROM @TB_ACCT ;
	/***********************************************************************************************************************************
	-- (4) Item & Account	
	************************************************************************************************************************************/
	DECLARE @P_FROM_DATE	DATE 
		   ,@P_TO_DATE		DATE 
		   ,@P_SM_DATE		DATE 
		   ,@P_BUKT			NVARCHAR(100)
		   ,@P_PLAN_TP_ID	CHAR(32)
	;
	 SELECT   @P_FROM_DATE	= FROM_DATE	
			, @P_TO_DATE	= TO_DATE	
			, @P_BUKT		= BUKT 	
			, @P_PLAN_TP_ID = PLAN_TP_ID 
	   FROM TB_DP_CONTROL_BOARD_VER_MST 
	 WHERE ID = @P_VER_ID
	   ;

  WITH CAL
	AS (
		SELECT MIN(DAT)	AS STRT_DT
			 , MAX(DAT) AS END_DT
		  FROM TB_CM_CALENDAR CAL
		WHERE DAT BETWEEN @P_FROM_DATE AND @P_TO_DATE  
	  GROUP BY CASE @P_BUKT
						WHEN 'Y' THEN YYYY
						WHEN 'Q' THEN YYYY+'-'+CONVERT(CHAR(1), QTR)
						WHEN 'M' THEN YYYYMM
						WHEN 'PW' THEN MM+'-'+DP_WK
						WHEN 'W' THEN DP_WK
					ELSE YYYYMMDD END   	
		), IA
	AS (
		SELECT IT.ITEM_ID
			  ,AC.ACCT_ID 
			  ,IT.EMP_ID
		  FROM @TB_ITEM IT 
			   INNER JOIN
			   @TB_ACCT AC
			ON IT.EMP_ID = AC.EMP_ID
		   AND IT.AUTH_TP_ID = AC.AUTH_TP_ID
		EXCEPT 
		SELECT ITEM_MST_ID
			 , ACCOUNT_ID
			  ,EX.EMP_ID
		  FROM TB_DP_USER_ITEM_ACCOUNT_EXCLUD EX
			   INNER JOIN
			   @TB_USER US
			ON EX.EMP_ID = US.EMP_ID
		   AND EX.AUTH_TP_ID = US.AUTH_TP_ID	  
	), SALES_LV
AS (
	SELECT DISTINCT LV_MGMT_ID
	  FROM TB_DP_CONTROL_BOARD_VER_DTL
	 WHERE CONBD_VER_MST_ID = @p_VER_ID 
	   AND LV_MGMT_ID IS NOT NULL 
   )
	INSERT INTO #IAC 
		  (ITEM_ID
		 , ACCT_ID
		 , ROLE_ID
		 , EMP_ID
		 , BASE_DATE
		 ) 
	SELECT ITEM_ID
		  ,ACCT_ID
		  ,LV_MGMT_ID
		  ,EMP_ID
		  ,STRT_DT 
	  FROM IA 	
		   CROSS JOIN
		   CAL 
		   CROSS JOIN
		   SALES_LV 
		   ;
/************************************************************************************************************
	-- 2. Get Version Config
************************************************************************************************************/
	--------------- 1. Get Versison Detail Info (Initial value type by authority type)
	CREATE TABLE #VER_INFO_DTL 
	(	 ID				CHAR(32)		COLLATE DATABASE_DEFAULT
		,DTL_ID			CHAR(32)		COLLATE DATABASE_DEFAULT
		,AUTH_TP_CD		NVARCHAR(100)	COLLATE DATABASE_DEFAULT
		,AUTH_TP_ID		CHAR(32)		COLLATE DATABASE_DEFAULT
		,INIT_TP_CD		NVARCHAR(50)	COLLATE DATABASE_DEFAULT
		,INIT_VAL_CD	NVARCHAR(50)	COLLATE DATABASE_DEFAULT
		,INIT_VAL_ID	CHAR(32)		COLLATE DATABASE_DEFAULT
		,PRICE_TP_ID	CHAR(32)		COLLATE DATABASE_DEFAULT
	)
	;
	DECLARE @P_PREV_VER_ID CHAR(32)
    SELECT TOP 1 @P_PREV_VER_ID = CONBD_VER_MST_ID  
	  FROM TB_DP_CONTROL_BOARD_VER_DTL D  
	 WHERE CONBD_VER_MST_ID != @P_VER_ID 
	   AND PLAN_TP_ID = @P_PLAN_TP_ID 
	   AND D.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_cD = 'DP_WK_TP' AND CONF_CD = 'CL')
	   AND D.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
  ORDER BY CREATE_DTTM DESC
  ;
		INSERT INTO #VER_INFO_DTL
		( ID	
	     ,DTL_ID 			
		 ,AUTH_TP_CD		
		 ,AUTH_TP_ID		
		 ,INIT_TP_CD		
		 ,INIT_VAL_CD	
		 ,INIT_VAL_ID	
		 ,PRICE_TP_ID 
		)
		SELECT VI.ID
		 , VE.ID 
		 , LV.LV_CD						 AS AUTH_TP_CD
		 , VE.LV_MGMT_ID				 AS AUTH_TP_ID
		 , IV.CONF_CD					 AS INIT_TP_CD
		 , CASE IV.CONF_CD 
			WHEN 'PR' THEN IL.LV_CD
			WHEN 'MS' THEN MS.MEASURE_CD
		   END							 AS INIT_VAL_CD
		 , CASE IV.CONF_CD 
			WHEN 'PR' THEN IL.ID
			WHEN 'MS' THEN MS.ID
		   END							 AS INIT_VAL_ID
		 , PRICE_TP_ID 
	  FROM TB_DP_CONTROL_BOARD_VER_MST VI 
		   INNER JOIN 
		   TB_DP_CONTROL_BOARD_VER_DTL VE
		ON VI.ID = @P_VER_ID 
	   AND VE.CONBD_VER_MST_ID = @P_VER_ID 	   
		   INNER JOIN
		   TB_CM_LEVEL_MGMT LV
		ON VE.LV_MGMT_ID = LV.ID
	   AND ISNULL(LV.DEL_YN, 'N') = 'N'
	   AND LV.ACTV_YN = 'Y'   
		   INNER JOIN
		   TB_CM_COMM_CONFIG IV
		ON VE.INIT_VAL_TP_ID = IV.ID 
	   AND IV.ACTV_YN = 'Y'   
		   LEFT OUTER JOIN
		   TB_CM_LEVEL_MGMT IL
		ON VE.INIT_FIXED_LV_MGMT_ID = IL.ID
	   AND ISNULL(IL.DEL_YN, 'N') = 'N'
	   AND IL.ACTV_YN = 'Y'   
		   LEFT OUTER JOIN
		   TB_DP_MEASURE_MST MS
		ON VE.INIT_MEASURE_ID = MS.ID
		;
	CREATE TABLE #VER_INFO_INIT 
	(	DTL_ID					CHAR(32)			COLLATE DATABASE_DEFAULT
	   ,AUTH_TP_ID				CHAR(32) 			COLLATE DATABASE_DEFAULT
	   ,INIT_MS_VAL_TP_CD		NVARCHAR(100)		COLLATE DATABASE_DEFAULT
	   ,INIT_VAL_TP_ID			CHAR(32)			COLLATE DATABASE_DEFAULT
	   ,INIT_VAL_TP_CD			NVARCHAR(100)		COLLATE DATABASE_DEFAULT
	   ,INIT_MEASURE_ID			CHAR(32)			COLLATE DATABASE_DEFAULT
	   ,INIT_MEASURE_CD			NVARCHAR(100)		COLLATE DATABASE_DEFAULT
	   ,INIT_FIXED_LV_MGMT_ID	CHAR(32)			COLLATE DATABASE_DEFAULT
	   ,INIT_FIXED_LV_MGMT_CD	NVARCHAR(100)		COLLATE DATABASE_DEFAULT
	    ,IDX						INT -- FOR COUNT OF COLUMN 
	)
	INSERT INTO #VER_INFO_INIT
	(	DTL_ID					
	   ,AUTH_TP_ID 
	   ,INIT_MS_VAL_TP_CD		
	   ,INIT_VAL_TP_ID			
	   ,INIT_VAL_TP_CD			
	   ,INIT_MEASURE_ID			
	   ,INIT_MEASURE_CD			
	   ,INIT_FIXED_LV_MGMT_ID	
	   ,INIT_FIXED_LV_MGMT_CD	
	    ,IDX 		
	)
		SELECT VI.CONBD_VER_DTL_ID
			 , VD.AUTH_TP_ID 
			 , VI.MS_VAL_TP_CD			AS INIT_MS_VAL_TP_CD
			 , VI.INIT_VAL_TP_ID		AS INIT_VAL_TP_ID
			 , VT.CONF_CD				AS INIT_VAL_TP_CD
			 , VI.INIT_MEASURE_ID		
			 , MS.MEASURE_CD			AS INIT_MEASURE
			 , VI.INIT_FIXED_LV_MGMT_ID	
			 , LV.LV_CD					AS INIT_LV 
			 , DENSE_RANK() OVER (PARTITION BY VT.CONF_CD ORDER BY VI.MS_VAL_TP_CD ASC )
		  FROM TB_DP_CONTROL_BOARD_VER_INIT VI
			   INNER JOIN 
			   #VER_INFO_DTL VD
			ON VI.CONBD_VER_DTL_ID = VD.DTL_ID 
			   INNER JOIN 
			   TB_CM_COMM_CONFIG VT
		    ON VI.INIT_VAL_TP_ID = VT.ID 
		       LEFT OUTER JOIN
			   TB_DP_MEASURE_MST MS
			ON VI.INIT_MEASURE_ID = MS.ID 
		       LEFT OUTER JOIN
			   TB_CM_LEVEL_MGMT LV
			ON LV.ID = VI.INIT_FIXED_LV_MGMT_ID
		 ;
/************************************************************************************************************
	-- 3. Get Initial Value
************************************************************************************************************/
--	SELECT *
--	  FROM #VER_INFO_DTL
	--------------- 2. Create and Insert Result Temporary Table
	CREATE TABLE #RT
			(	 ITEM_MST_ID	CHAR(32)		COLLATE DATABASE_DEFAULT
				,ACCOUNT_ID		CHAR(32)		COLLATE DATABASE_DEFAULT
				,BASE_DATE		DATE
				,QTY			DECIMAL(20,3)
				,AUTH_TP_ID		CHAR(32)		COLLATE DATABASE_DEFAULT
				,QTY_1			DECIMAL(20,3)
				,QTY_2			DECIMAL(20,3)
				,QTY_3			DECIMAL(20,3)
			)
		;
 
	BEGIN 
		DECLARE @P_STR	NVARCHAR(MAX)
			  , @P_VAL_CNT  INT = (	SELECT DISTINCT COUNT(INIT_VAL_TP_CD) 
									  FROM #VER_INFO_INIT  WHERE INIT_VAL_TP_CD = 'PR' )
--			  , @P_LOOP_IDX	INT = 1
		
		IF EXISTS ( SELECT 1 FROM #VER_INFO_DTL WHERE INIT_TP_CD = 'PR') OR EXISTS ( SELECT 1 FROM #VER_INFO_INIT WHERE INIT_VAL_TP_CD = 'PR')
			BEGIN	
				CREATE TABLE #PR
				( ITEM_MST_ID	CHAR(32)	COLLATE DATABASE_DEFAULT
				 ,ACCOUNT_ID	CHAR(32)	COLLATE DATABASE_DEFAULT
				 ,BASE_DATE		DATE
				 ,AUTH_TP_ID	CHAR(32)	COLLATE DATABASE_DEFAULT
				 ,QTY			DECIMAL(20,3)
				 ,QTY_1			DECIMAL(20,3)
				 ,QTY_2			DECIMAL(20,3)
				 ,QTY_3			DECIMAL(20,3)	
				)
				INSERT INTO #PR
				SELECT ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, AUTH_TP_ID, QTY, QTY_1, QTY_2, QTY_3
				  FROM TB_DP_ENTRY
				 WHERE VER_ID = @P_PREV_VER_ID 
				 ;
				
				SET @P_STR =
				'WITH INI_PR '
				+  'AS ( '
				+	'SELECT DTL_ID '
				+		 ', INIT_FIXED_LV_MGMT_ID '
				+		 ', INIT_MS_VAL_TP_CD '
				+	  'FROM #VER_INFO_INIT '
				+	 'WHERE INIT_VAL_TP_CD = ''PR'' '
				+  ')' 
				+ 'INSERT INTO #RT  ( ITEM_MST_ID,ACCOUNT_ID,BASE_DATE,QTY,AUTH_TP_ID'	-- bug fix
					+(		SELECT ISNULL(','+STRING_AGG(INIT_MS_VAL_TP_CD,',') WITHIN GROUP(ORDER BY INIT_MS_VAL_TP_CD)  ,'')
							  FROM ( SELECT DISTINCT INIT_MS_VAL_TP_CD 
						  		    FROM #VER_INFO_INIT		
								   WHERE INIT_VAL_TP_CD = 'PR' 	
							      ) A			
					)
				+')'
				+'SELECT M.ITEM_ID '
				+	  ', M.ACCT_ID'
				+	  ', M.BASE_DATE  '
				+	CASE WHEN EXISTS ( SELECT 1 FROM #VER_INFO_DTL WHERE INIT_TP_CD = 'PR') THEN  ', DE.QTY ' ELSE ', 0' END
				+	  ', VE.AUTH_TP_ID '+
				(		SELECT ISNULL(', '+STRING_AGG('DE'+CONVERT(CHAR(1),  IDX)+'.'+INIT_MS_VAL_TP_CD,',')  WITHIN GROUP(ORDER BY INIT_MS_VAL_TP_CD) ,'')
						  FROM ( SELECT DISTINCT INIT_MS_VAL_TP_CD, IDX 
						  		    FROM #VER_INFO_INIT		
								   WHERE INIT_VAL_TP_CD = 'PR' 	
							      ) A		
				)
				+ ' FROM #IAC M '
				+' INNER JOIN'
				+' #VER_INFO_DTL VE ON M.ROLE_ID = VE.AUTH_TP_ID '
				IF EXISTS ( SELECT 1 FROM #VER_INFO_DTL WHERE INIT_TP_CD = 'PR')
					BEGIN
						SET @P_STR = @P_STR 
									+     ' LEFT OUTER JOIN '
									+	   '#VER_INFO_DTL VD'
									+ ' ON VE.DTL_ID = VD.DTL_ID AND VD.INIT_TP_CD = ''PR'''		
									+	   'LEFT OUTER JOIN '
									+	   '#PR DE '
									+ ' ON VD.INIT_VAL_ID = DE.AUTH_TP_ID '
									+' AND M.ITEM_ID = DE.ITEM_MST_ID'
									+' AND M.ACCT_ID = DE.ACCOUNT_ID'
									+' AND M.BASE_DATE = DE.BASE_DATE '
					END
				IF (@P_VAL_CNT > 0)
					BEGIN
						SET @P_STR = @P_STR 
						+	   'INNER JOIN '		  
						+	   'INI_PR '
						+' PIVOT (MAX(INIT_FIXED_LV_MGMT_ID) FOR INIT_MS_VAL_TP_CD IN ('+
						(		SELECT ISNULL(STRING_AGG(INIT_MS_VAL_TP_CD,',') WITHIN GROUP(ORDER BY INIT_MS_VAL_TP_CD)  ,'')
								  FROM ( SELECT DISTINCT INIT_MS_VAL_TP_CD
						  		    FROM #VER_INFO_INIT		
								   WHERE INIT_VAL_TP_CD = 'PR' 	
							      ) A			
						)
						+')) AS PVT ' 
						+' ON VE.DTL_ID = PVT.DTL_ID '				
					SELECT  @P_STR = @P_STR
					+    ' LEFT OUTER JOIN '
					+    ' #PR DE'+CONVERT(CHAR(1),  IDX)
					+ ' ON PVT.'+INIT_MS_VAL_TP_CD+' = DE'+CONVERT(CHAR(1),  IDX)+'.AUTH_TP_ID '
					+ ' AND M.ITEM_ID = DE'+CONVERT(CHAR(1),  IDX) +'.ITEM_MST_ID '
					+ ' AND M.ACCT_ID = DE'+CONVERT(CHAR(1),  IDX) +'.ACCOUNT_ID '
					+ ' AND M.BASE_DATE	= DE'+CONVERT(CHAR(1),  IDX) +'.BASE_DATE '
				  FROM #VER_INFO_INIT
				 WHERE INIT_VAL_TP_CD = 'PR' 
				GROUP BY INIT_MS_VAL_TP_CD, IDX 
				;
				 END
 
			 SET @P_STR = @P_STR+';'
				EXECUTE (@P_STR)
				;
				DROP TABLE #PR;
			END

	END
		;
		IF EXISTS ( SELECT 1 FROM #VER_INFO_DTL WHERE INIT_TP_CD = 'MS') OR EXISTS ( SELECT 1 FROM #VER_INFO_INIT WHERE INIT_VAL_TP_CD = 'MS')
			BEGIN	
				SET @P_STR = '';		 
				WITH INI
				  AS (
					SELECT DTL_ID 
						 , AUTH_TP_ID 
						 , INIT_VAL_CD+ ' AS QTY' AS COL
						 , 'QTY' as VAL_COL
						 , 'SRC.QTY'  as IST_COL
						 , 'TGT.QTY = SRC.QTY' as UPT_COL

					 FROM #VER_INFO_DTL 
					WHERE INIT_TP_CD = 'MS'
					UNION
					SELECT DTL_ID
						 , AUTH_TP_ID 
						 , STRING_AGG(INIT_MEASURE_CD+' AS '+INIT_MS_VAL_TP_CD, ',')   AS COL
--						 ,STRING_AGG(INIT_MEASURE_CD, ',') AS MS_COL
						 , STRING_AGG(INIT_MS_VAL_TP_CD, ',') as VAL_COL
						 , STRING_AGG('SRC.'+INIT_MS_VAL_TP_CD, ',') as IST_COL
						 , STRING_AGG('TGT.'+INIT_MS_VAL_TP_CD+'='+'SRC.'+INIT_MS_VAL_TP_CD, ',') as UPT_COL
					  FROM #VER_INFO_INIT 
					 WHERE INIT_VAL_TP_CD = 'MS' 
					 GROUP BY DTL_ID, AUTH_TP_ID
				  ) 
				SELECT @P_STR = @P_STR+
					   ' MERGE INTO #RT TGT'
					 + ' USING (			  '
					 + 'SELECT ITEM_MST_ID, ACCOUNT_ID, BASE_DATE '
--					 +  INIT_VAL_CD
				     + ','''+AUTH_TP_ID+''' AS AUTH_TP_ID '
				     + ','''+DTL_ID+''' AS DTL_ID '
					 +  ','+ISNULL(COL,'')
					 + ' FROM TB_DP_MEASURE_DATA'
					 + ' WHERE BASE_DATE BETWEEN CONVERT(DATE, '''+CONVERT(NVARCHAR(10),@P_FROM_DATE,112)+''') AND CONVERT(DATE, '''+CONVERT(NVARCHAR(10), @P_TO_DATE, 112)+''') '
					 + ' ) SRC '
					 + ' ON SRC.ITEM_MST_ID = TGT.ITEM_MST_ID '
					 + ' AND SRC.ACCOUNT_ID = TGT.ACCOUNT_ID  '
					 + ' AND SRC.BASE_DATE = TGT.BASE_DATE	  '
					 + ' AND SRC.AUTH_TP_ID = TGT.AUTH_TP_ID  '
					 + ' WHEN MATCHED THEN '
					 + ' UPDATE SET '+UPT_COL
					 + ' WHEN NOT MATCHED THEN '
					 + ' INSERT  ( '
					 + ' ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, AUTH_TP_ID ,'
					 +  VAL_COL
					 + ' ) VALUES '
					 + ' (SRC.ITEM_MST_ID, SRC.ACCOUNT_ID, SRC.BASE_DATE, SRC.AUTH_TP_ID ,'
					 + IST_COL
					 + ' );'
				 FROM INI 
				;	
				EXECUTE (@P_STR);	
			END 
			;

/************************************************************************************************************
	-- 3. Make Entry Data
************************************************************************************************************/
	WITH ENTRY_HIS
	AS (    SELECT  SUM(QTY)		AS QTY
				 , SUM(AMT)			AS AMT
				 , ITEM_MST_ID
				 , ACCOUNT_ID
			  FROM TB_DP_ENTRY_HISTORY 
			 WHERE BASE_dATE BETWEEN @P_SM_DATE AND DATEADD(DAY,-1,@P_FROM_DATE)
		GROUP BY ITEM_MST_ID, ACCOUNT_ID
	)	
	 MERGE TB_DP_ENTRY TGT
	  USING (
			 SELECT @P_VER_ID				AS VER_ID 
				  , MN.ROLE_ID 
				  , MN.ITEM_ID	
				  , MN.ACCT_ID	
				  , MN.BASE_DATE
				  , MN.EMP_ID 
				  , ISNULL(RT.QTY , 0)		AS QTY 
				  , RT.QTY_1 -- ISNULL(RT.QTY_1,0)
				  , RT.QTY_2 -- ISNULL(RT.QTY_2,0)
				  , RT.QTY_3 -- ISNULL(RT.QTY_3,0)
				  , EH.QTY			AS QTY_A
				  , EH.AMT 			AS AMT_A 
			   FROM #IAC MN
				    LEFT OUTER JOIN 
					#RT		RT 
			     ON MN.ITEM_ID = RT.ITEM_MST_ID 
				AND MN.ACCT_ID = RT.ACCOUNT_ID 
				AND RT.BASE_DATE = MN.BASE_DATE  
				AND RT.AUTH_TP_ID = MN.ROLE_ID  
					LEFT OUTER JOIN
					ENTRY_HIS EH 
				ON  MN.ITEM_ID = EH.ITEM_MST_ID
			   AND  MN.ACCT_ID = EH.ACCOUNT_ID
			   ) SRC
			ON TGT.VER_ID = SRC.VER_ID 
		   AND TGT.AUTH_TP_ID = SRC.ROLE_ID
		   AND TGT.ITEM_MST_ID = SRC.ITEM_ID
		   AND TGT.ACCOUNT_ID = SRC.ACCT_ID
		   AND TGT.BASE_DATE = SRC.BASE_dATE
		WHEN NOT MATCHED THEN
		INSERT 
	 (    ID
		, VER_ID
		, AUTH_TP_ID
		, EMP_ID
		, ITEM_MST_ID
		, ACCOUNT_ID
--		, SALES_LV_ID
		, BASE_DATE
		, QTY
		, AMT
		, CREATE_BY
		, CREATE_DTTM
		, PLAN_TP_ID
		, QTY_1
		, AMT_1
		, QTY_2
		, AMT_2
		, QTY_3
		, AMT_3		 
	    , QTY_A
		, AMT_A 
	 ) VALUES
	 (	REPLACE(NEWID(),'-','') 
	  , VER_ID
	  , ROLE_ID
	  , EMP_ID
	  , ITEM_ID
	  , ACCT_ID
	  , BASE_DATE
	  , QTY
	  , NULL 
	  , @p_user_ID
	  , GETDATE()
	  , @P_PLAN_TP_ID 	 
	  , QTY_1
	  , NULL
	  , QTY_2
	  , NULL
	  , QTY_3
	  , NULL
	  , QTY_A 
	  , AMT_A  
	 )
	   ;

/************************************************************************************************************
	-- 3. Drop Temporary table
************************************************************************************************************/
	DROP TABLE #VER_INFO_DTL
	DROP TABLE #VER_INFO_INIT
	DROP TABLE #RT
	DROP TABLE #IAC 
END

go

