/*****************************************************************************
Title : SP_UI_DP_07_S1
최초 작성자 : 민희영
최초 생성일 : 2017.06.13
 
설명 
  - Exchange Rate
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.13 / 민희영 / 최초 작성
 
*****************************************************************************/


CREATE PROCEDURE [dbo].[SP_UI_DP_07_S1]  (     
									   @p_FROM_CURCY_CD       NVARCHAR(32)      = ''         
									  ,@p_TO_CURCY_CD         NVARCHAR(32)      = ''      
									  ,@p_BASE_DATE           DATETIME          = NULL
									  ,@p_EXCHANGE_RATE       DECIMAL(20,5)     = 0
									  ,@p_UNIT_UOM_VAL        DECIMAL(20,3)     = 0
									  ,@p_CURCY_TP_CD         NVARCHAR(50)      = ''
									  ,@p_USER_ID             NVARCHAR(100)     = ''
									  ,@P_RT_ROLLBACK_FLAG    NVARCHAR(10)      = 'true'  OUTPUT
									  ,@P_RT_MSG              NVARCHAR(4000)    = ''	  OUTPUT									        
	  								   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE 
        @P_ERR_MSG NVARCHAR(4000)=''
	   ,@p_FROM_CURCY_CD_ID NVARCHAR(4000)=''
	   ,@p_TO_CURCY_CD_ID NVARCHAR(4000)=''

	   ,@V_FROM_CURCY_CD	NVARCHAR(32)	= ''
	   ,@V_TO_CURCY_CD  	NVARCHAR(32)	= ''
	   ,@V_BASE_DATE    	DATETIME		= NULL
	   ,@V_EXCHANGE_RATE	DECIMAL(20,5)	= 0
	   ,@V_UNIT_UOM_VAL 	DECIMAL(20,3)	= 0
	   ,@V_CURCY_TP_ID  	NVARCHAR(32)	= ''
	   ,@V_USER_ID      	NVARCHAR(100)	= ''

SET @V_FROM_CURCY_CD	= @p_FROM_CURCY_CD
SET @V_TO_CURCY_CD  	= @p_TO_CURCY_CD  
SET @V_BASE_DATE    	= @p_BASE_DATE    
SET @V_EXCHANGE_RATE	= @p_EXCHANGE_RATE
SET @V_UNIT_UOM_VAL 	= @p_UNIT_UOM_VAL 
SET @V_CURCY_TP_ID  	= (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_CD = @p_CURCY_TP_CD AND CONF_GRP_CD = 'DP_CURRENCY_TYPE' )
SET @V_USER_ID      	= @p_USER_ID      

BEGIN TRY
---------- ID 추출 ----------
	BEGIN TRY
		SELECT @p_FROM_CURCY_CD_ID = ID FROM TB_AD_COMN_CODE WHERE COMN_CD = @V_FROM_CURCY_CD;
		SELECT @p_TO_CURCY_CD_ID = ID FROM TB_AD_COMN_CODE WHERE COMN_CD = @V_TO_CURCY_CD;
	END TRY
	BEGIN CATCH
		IF(@p_FROM_CURCY_CD_ID IS NULL OR @p_TO_CURCY_CD_ID IS NULL)
			BEGIN
				SET @P_ERR_MSG = 'MSG_0006'
			END
	END CATCH;

---------- VALIDATION ------------------

    IF (@p_FROM_CURCY_CD_ID IS NULL)
	   BEGIN
			SET @P_ERR_MSG = 'MSG_0006'
			RAISERROR (@P_ERR_MSG,12, 1);
	   END
    IF (@p_TO_CURCY_CD_ID IS NULL)
	   BEGIN
			SET @P_ERR_MSG = 'MSG_0006'
			RAISERROR (@P_ERR_MSG,12, 1);
	   END
    IF (@V_BASE_DATE IS NULL)
	   BEGIN
			SET @P_ERR_MSG = 'MSG_0006'
			RAISERROR (@P_ERR_MSG,12, 1);
	   END
    IF (@V_EXCHANGE_RATE IS NULL)
	   BEGIN
			SET @P_ERR_MSG = 'MSG_0006'
			RAISERROR (@P_ERR_MSG,12, 1);
	   END
    IF (@V_CURCY_TP_ID IS NULL)
	   BEGIN
			SET @P_ERR_MSG = 'MSG_0006'
			RAISERROR (@P_ERR_MSG,12, 1);
	   END
    IF (@p_FROM_CURCY_CD_ID = @p_TO_CURCY_CD_ID)
	   BEGIN
			SET @P_ERR_MSG = 'MSG_5100'
			RAISERROR (@P_ERR_MSG,12, 1);
	   END

	  -- 프로시저 시작 

				MERGE TB_DP_EXCHANGE_RATE TGT
				USING ( 
						SELECT   @p_FROM_CURCY_CD_ID       AS  FROM_CURCY_CD_ID     
								,@p_TO_CURCY_CD_ID         AS  TO_CURCY_CD_ID       
								,@V_BASE_DATE              AS  BASE_DATE            
								,@V_EXCHANGE_RATE          AS  EXCHANGE_RATE        
								,@V_UNIT_UOM_VAL           AS  UNIT_UOM_VAL         
								,@V_CURCY_TP_ID			   AS  CURCY_TP_ID
								,@V_USER_ID                AS  USER_ID
					  ) SRC
				ON (  TGT.FROM_CURCY_CD_ID = SRC.FROM_CURCY_CD_ID 
				  AND TGT.TO_CURCY_CD_ID   = SRC.TO_CURCY_CD_ID 
				  AND TGT.BASE_DATE        = SRC.BASE_DATE
				  AND TGT.CURCY_TP_ID      = SRC.CURCY_TP_ID )
				WHEN MATCHED THEN
					 UPDATE 
					   SET         
							 TGT.EXCHANGE_RATE       	= SRC.EXCHANGE_RATE   
							,TGT.UNIT_UOM_VAL    		= SRC.UNIT_UOM_VAL    
							,TGT.MODIFY_BY              = SRC.USER_ID       
							,TGT.MODIFY_DTTM            = GETDATE()       
				WHEN NOT MATCHED THEN 
					 INSERT (
							 ID               
							,FROM_CURCY_CD_ID
							,TO_CURCY_CD_ID  
							,BASE_DATE       
							,EXCHANGE_RATE   
							,UNIT_UOM_VAL
							,CURCY_TP_ID    
							,CREATE_BY
							,CREATE_DTTM
							) 
					 VALUES (
							 REPLACE(NEWID(),'-','') 
							,SRC.FROM_CURCY_CD_ID   
							,SRC.TO_CURCY_CD_ID     
							,SRC.BASE_DATE          
							,SRC.EXCHANGE_RATE      
							,SRC.UNIT_UOM_VAL 
							,SRC.CURCY_TP_ID      
							,SRC.USER_ID 
							,GETDATE()            
 							) 
							;    

	
	   SET @P_RT_ROLLBACK_FLAG = 'true'

	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;



go

