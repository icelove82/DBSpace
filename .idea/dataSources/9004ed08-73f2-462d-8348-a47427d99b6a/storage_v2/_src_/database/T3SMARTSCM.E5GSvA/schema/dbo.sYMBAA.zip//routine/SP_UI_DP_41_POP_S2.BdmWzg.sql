CREATE PROCEDURE [dbo].[SP_UI_DP_41_POP_S2] (
     @P_MEASURE_CD		NVARCHAR(20)
	,@P_BASE_DATE		DATE
   , @P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'    OUTPUT
   , @P_RT_MSG            NVARCHAR(4000) = ''		 OUTPUT
) AS
/****************************************T*********************************************************************
	[SP_UI_DP_41_POP_S2]
	Calculate YTD Value 

	History (Date / Writer / Comment)
		-- 2020.03.19 / Kimsohee / draft
		-- 2020.12.21 / kim sohee/ relocate code to set mm bukt 
		-- 2022.05.10 / kim sohee / YTD measure, change calculation rule by fiscal year (config code : SM)

		YTD : 시작일 ~ 시작일+1년
		YOY : 시작일 ~ TB_DP_MEASURE_DATA의 MAX(BASE_DATE) => 1년전 데이터를
		ACT_SALES : 시작일 ~ (마감일은 X)

		==> 이번달 1일을 기본 시작일로 하고, 
		이번달 1일부터 일년치를 만들게 변경 (실적은 있는 날짜까지)

		- 2023.02.10 / Kim sohee / YOY 계산방식 변경 & MEASURE 별 날짜 범위 지정 코드 정리 
*************************************************************************************************************/
--	SET @P_MEASURE_CD = 'TEST';

IF @P_BASE_DATE IS NULL
	BEGIN
		SET @P_BASE_DATE = GETDATE();
	END
DECLARE @P_STRT_DATE	 DATE = @P_BASE_DATE
	 ,  @P_END_DATE		 DATE = DATEADD(DAY,-1,DATEADD(YEAR,1,@P_BASE_DATE))
	 ,  @P_SM			 NVARCHAR(2)

-- For ANNUAL_DP 
DECLARE @P_MM_BUKT		 NVARCHAR(2)
	   ,@P_YY_BUKT		 NVARCHAR(2)
	   ,@P_YY_VER_ID	 CHAR(32)
	   ,@P_CL_LV_MGMT_ID CHAR(32)
	   ;

DECLARE  @P_ERR_STATUS INT = 0
        ,@P_ERR_MSG NVARCHAR(4000)=''

BEGIN TRY
/**********************************************************************************************************************
	-- Config Setting
**********************************************************************************************************************/
		SELECT @P_MM_BUKT = POLICY_VAL
		  FROM TB_DP_PLAN_POLICY PP
			   INNER JOIN
			   TB_CM_COMM_CONFIG CF
			ON PP.POLICY_ID = CF.ID
		   AND CF.CONF_CD = 'B'
			   INNER JOIN
			   TB_CM_COMM_CONFIG PT
			ON PP.PLAN_TP_ID = PT.ID
		   AND PT.ATTR_01 = 'M'
		   ;
IF (@P_MEASURE_CD LIKE 'YTD%')
	BEGIN
		SELECT @P_SM = POLICY_VAL 
		  FROM TB_DP_PLAN_POLICY PP
			   INNER JOIN
			   TB_CM_COMM_CONFIG CF
			ON PP.POLICY_ID = CF.ID
		   AND CF.CONF_CD = 'SM'
			   INNER JOIN
			   TB_CM_COMM_CONFIG PT
			ON PP.PLAN_TP_ID = PT.ID
		   AND PT.ATTR_01 = 'M'
		   ;

--		SELECT @P_STRT_DATE = CONVERT(DATE, CONVERT(CHAR(4), DATEPART(YEAR, ISNULL(@P_BASE_DATE, GETDATE())))+'-'+POLICY_VAL+'-1')
--			 , @P_SM = POLICY_VAL 
--		  FROM TB_DP_PLAN_POLICY PP
--			   INNER JOIN
--			   TB_CM_COMM_CONFIG CF
--			ON PP.POLICY_ID = CF.ID
--		   AND CF.CONF_CD = 'SM'
--			   INNER JOIN
--			   TB_CM_COMM_CONFIG PT
--			ON PP.PLAN_TP_ID = PT.ID
--		   AND PT.ATTR_01 = 'M'
--		   ;
--		SELECT @P_END_DATE = DATEADD(DAY,-1,DATEADD(YEAR, 1, @P_STRT_DATE))
--		;

	END 
ELSE IF (@P_MEASURE_CD = 'YOY')
	BEGIN
	     SET @P_STRT_DATE = DATEADD(YEAR, -1, @P_STRT_DATE)
		 SET @P_END_DATE  = DATEADD(YEAR, -1, @P_END_DATE)
	END
--ELSE IF (@P_MEASURE_CD = 'ACT_SALES' AND @P_BASE_DATE IS NULL)
--	BEGIN
--			SELECT TOP 1 @P_STRT_DATE = ISNULL(@P_BASE_DATE, FROM_DATE)
--			  FROM TB_DP_CONTROL_BOARD_VER_MST
--		  ORDER BY CREATE_DTTM DESC 			   
--	END

/**********************************************************************************************************************
    -- Get Version Data
**********************************************************************************************************************/    
	CREATE TABLE  #TEMP_DP_ITEM_ACCOUNT_DATE 
    (  ITEM_MST_ID	CHAR(32)	COLLATE DATABASE_DEFAULT
     , ACCOUNT_ID	CHAR(32)	COLLATE DATABASE_DEFAULT
     , BASE_DATE	DATE
     , STRT_DATE	DATE
     , END_DATE		DATE
	 );

	WITH USER_ACCT_MAP
     AS (
        SELECT AUTH_TP_ID, EMP_ID, SH.DESCENDANT_ID AS ACCOUNT_ID
          FROM TB_DP_USER_ACCOUNT_MAP M
               INNER JOIN 
               TB_CM_LEVEL_MGMT L
            ON M.LV_MGMT_ID = L.ID    
               INNER JOIN 
               TB_DPD_SALES_HIER_CLOSURE SH
            ON SH.LEAF_YN = 'Y' 
		   AND SH.LV_TP_CD = 'S'
           AND CASE WHEN L.LEAF_YN = 'Y' THEN ACCOUNT_ID ELSE SALES_LV_ID END = SH.ANCESTER_ID 
    GROUP BY  AUTH_TP_ID, EMP_ID, SH.DESCENDANT_ID 
     ), USER_ITEM_MAP
     AS (
        SELECT AUTH_TP_ID, EMP_ID, IH.DESCENDANT_ID AS ITEM_ID
          FROM TB_DP_USER_ITEM_MAP M
               INNER JOIN 
               TB_CM_LEVEL_MGMT L
            ON M.LV_MGMT_ID = L.ID    
               INNER JOIN 
               TB_DPD_ITEM_HIER_CLOSURE IH
            ON IH.LEAF_YN = 'Y' 
		   AND IH.LV_TP_CD = 'I'
           AND CASE WHEN L.LEAF_YN = 'Y' THEN ITEM_MST_ID ELSE ITEM_LV_ID END = IH.ANCESTER_ID 
    GROUP BY  AUTH_TP_ID, EMP_ID, IH.DESCENDANT_ID 
     
     ), ITEM_ACCT 
    AS (
        SELECT A.ACCOUNT_ID 
              ,I.ITEM_ID 
          FROM USER_ACCT_MAP A
               INNER JOIN 
               USER_ITEM_MAP I
            ON A.AUTH_TP_ID = I.AUTH_TP_ID
           AND A.EMP_ID = I.EMP_ID
        GROUP BY A.ACCOUNT_ID, I.ITEM_ID 
        UNION 
		SELECT UA.ACCOUNT_ID
			 , UA.ITEM_MST_ID    AS ITEM_ID
		  FROM TB_DP_USER_ITEM_ACCOUNT_MAP UA
			   INNER JOIN
			   TB_DP_ACCOUNT_MST AM
			ON UA.ACCOUNT_ID = AM.ID
           AND AM.ACTV_YN = 'Y'
           AND COALESCE(AM.DEL_YN,'N') != 'Y' 
			   INNER JOIN
			   TB_CM_ITEM_MST IM
			ON UA.ITEM_MST_ID = IM.ID 
           AND IM.DP_PLAN_YN = 'Y'
           AND COALESCE(IM.DEL_YN,'N') != 'Y'
		WHERE UA.ACTV_YN = 'Y'
		GROUP BY UA.ACCOUNT_ID
			 , UA.ITEM_MST_ID 
		)
	,CAL
	AS (
			SELECT  MIN(DAT)	AS STRT_DATE
				  , MAX(DAT)	AS END_DATE
				  , MIN(DAT)	AS BASE_DATE 
			  FROM TB_CM_CALENDAR
			 WHERE DAT BETWEEN @p_STRT_DATE AND @P_END_DATE 		
		  GROUP BY CASE WHEN @P_MM_BUKT = 'M'  THEN YYYYMM	
						WHEN @P_MM_BUKT = 'PW' THEN MM+'-'+DP_WK
						WHEN @P_MM_BUKT = 'W'  THEN DP_WK 
						WHEN @P_MM_BUKT = 'D' THEN YYYYMMDD 
					ELSE YYYY 
					END   	 
		)        
    INSERT INTO #TEMP_DP_ITEM_ACCOUNT_DATE 
    (  ITEM_MST_ID
     , ACCOUNT_ID
     , BASE_DATE
     , STRT_DATE
     , END_DATE )
    SELECT ITEM_ID  
         , ACCOUNT_ID 
         , BASE_DATE 
         , STRT_DATE
         , END_DATE
      FROM CAL 
           CROSS JOIN
           ITEM_ACCT 		                                                                                          
    ;
/**********************************************************************************************************************
	-- Main Proceure
**********************************************************************************************************************/
IF NOT EXISTS ( SELECT COLUMN_NAME
				  FROM INFORMATION_SCHEMA.COLUMNS
				 WHERE TABLE_NAME = 'TB_DP_MEASURE_DATA' 
				   AND COLUMN_NAME = 'ANNUAL_QTY'
				   AND TABLE_CATALOG =  DB_NAME()					
			 ) AND @P_MEASURE_CD = 'YTD_ANNUAL'	
	BEGIN
			SET @P_ERR_MSG = 'Please, Create Annual column first.'
			RAISERROR (@P_ERR_MSG,12, 1);
	END
	;
/**********************************************************************************************************************
	-- YTD
**********************************************************************************************************************/
	IF (@P_MEASURE_CD = 'YTD') 
			BEGIN					
				WITH SA
				AS (
					SELECT MM.ITEM_MST_ID
						 , MM.ACCOUNT_ID
						 , MM.BASE_DATE 
						 , ISNULL(SUM(SA.QTY),0)		AS QTY 
						 , ISNULL(SUM(SA.AMT),0)		AS AMT
					  FROM #TEMP_DP_ITEM_ACCOUNT_DATE MM
						   LEFT OUTER JOIN
						   (SELECT ITEM_MST_ID
								 , ACCOUNT_ID
								 , BASE_DATE 
								 , QTY
								 , AMT
							  FROM TB_CM_ACTUAL_SALES WHERE BASE_DATE BETWEEN @P_STRT_DATE AND @P_END_DATE
							) SA
						ON SA.BASE_DATE BETWEEN MM.STRT_DATE AND MM.END_DATE				
					   AND MM.ITEM_MST_ID = SA.ITEM_MST_ID
					   AND MM.ACCOUNT_ID = SA.ACCOUNT_ID   				
					GROUP BY MM.ITEM_MST_ID
							,MM.ACCOUNT_ID 
							,MM.BASE_DATE
				)     MERGE TB_DP_MEASURE_DATA SRC
					  USING (   SELECT ITEM_MST_ID
									 , ACCOUNT_ID
									 , BASE_DATE
									 -- SO_STATUS_ID
									 , SUM(QTY) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID
																 , CASE WHEN DATEPART(MONTH, BASE_DATE) >= @P_SM	THEN DATEPART(YEAR,BASE_DATE) 
																			ELSE DATEPART(YEAR,BASE_DATE)-1 
																   END ORDER BY BASE_DATE) AS QTY -- , DATEPART(YEAR, BASE_DATE)
									 , SUM(AMT) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID
																 , CASE WHEN DATEPART(MONTH, BASE_DATE) >= @P_SM	THEN DATEPART(YEAR,BASE_DATE) 
																		 ELSE DATEPART(YEAR,BASE_DATE)-1 
																   END ORDER BY BASE_DATE) AS AMT -- , DATEPART(YEAR, BASE_DATE)
								  FROM SA					  
						    ) TGT
						ON SRC.ITEM_MST_ID = TGT.ITEM_MST_ID 
					   AND SRC.ACCOUNT_ID  = TGT.ACCOUNT_ID  
					   AND SRC.BASE_DATE   = TGT.BASE_DATE   
					   WHEN MATCHED THEN
					   UPDATE SET YTD_QTY = TGT.QTY
								, YTD_AMT = TGT.AMT
								, CREATE_BY = 'system'
								, MODIFY_DTTM = GETDATE()
					   WHEN NOT MATCHED THEN
					   INSERT  
					   ( ID
						,ITEM_MST_ID
					    ,ACCOUNT_ID
						,BASE_DATE
						,YTD_QTY
						,YTD_AMT
						,CREATE_BY
						,CREATE_DTTM
					   ) VALUES
					   ( REPLACE(NEWID(),'-','')
					    ,TGT.ITEM_MST_ID
						,TGT.ACCOUNT_ID
						,TGT.BASE_DATE
						,TGT.QTY
					   	,TGT.AMT
						,'system'
						,GETDATE()
					   );

				  				 
		END
/**********************************************************************************************************************
	-- YTD Annual
**********************************************************************************************************************/
	ELSE IF (@P_MEASURE_CD = 'YTD_ANNUAL') 
		BEGIN	  
				MERGE TB_DP_MEASURE_DATA SRC
				USING(	SELECT MM.ITEM_MST_ID
							 , MM.ACCOUNT_ID
							 , MM.BASE_DATE			AS BASE_DATE
							 , SUM(ANNUAL_QTY) OVER 
							 (PARTITION BY MM.ITEM_MST_ID, MM.ACCOUNT_ID
										,  CASE WHEN DATEPART(MONTH, MM.BASE_DATE) >= @P_SM	THEN DATEPART(YEAR,MM.BASE_DATE) 
											 ELSE DATEPART(YEAR,MM.BASE_DATE)-1 
										END  ORDER BY MM.BASE_DATE
							  ) AS QTY -- , DATEPART(YEAR, MM.BASE_DATE)
							 , SUM(ANNUAL_AMT) OVER 
							 (PARTITION BY MM.ITEM_MST_ID, MM.ACCOUNT_ID
										,  CASE WHEN DATEPART(MONTH, MM.BASE_DATE) >= @P_SM	THEN DATEPART(YEAR,MM.BASE_DATE) 
											 ELSE DATEPART(YEAR,MM.BASE_DATE)-1 
										END  ORDER BY MM.BASE_DATE
							  ) AS AMT -- , DATEPART(YEAR, MM.BASE_DATE)
						  FROM #TEMP_DP_ITEM_ACCOUNT_DATE MM
							   LEFT OUTER JOIN
							   (SELECT ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, ANNUAL_QTY, ANNUAL_AMT
							      FROM TB_DP_MEASURE_DATA
								 WHERE BASE_DATE BETWEEN  @P_STRT_DATE AND @P_END_DATE
							   ) MD
							ON MM.ITEM_MST_ID = MD.ITEM_MST_ID
						   AND MM.ACCOUNT_ID = MD.ACCOUNT_ID
						   AND MM.BASE_DATE = MD.BASE_DATE
					) TGT
				 ON SRC.ITEM_MST_ID  = TGT.ITEM_MST_ID
				AND SRC.ACCOUNT_ID   = TGT.ACCOUNT_ID
				AND SRC.BASE_DATE    = TGT.BASE_DATE 
				WHEN MATCHED THEN
				 UPDATE  SET SRC.YTD_ANNUAL_QTY = TGT.QTY
							,SRC.YTD_ANNUAL_AMT = TGT.AMT
							,SRC.CREATE_BY = 'system'
							,SRC.MODIFY_DTTM = GETDATE()
				WHEN NOT MATCHED THEN
				INSERT (  ID
					    , ITEM_MST_ID
					    , ACCOUNT_ID
					    , BASE_DATE
					    , YTD_ANNUAL_QTY
					    , YTD_ANNUAL_AMT
					    , CREATE_BY
					    , CREATE_DTTM
					   ) 
				VALUES ( REPLACE(NEWID(),'-','')
						,TGT.ITEM_MST_ID
						,TGT.ACCOUNT_ID
						,TGT.BASE_DATE
						,TGT.QTY
					   	,TGT.AMT
						,'system'
						,GETDATE()
					   );						  				 								
		END
/**********************************************************************************************************************
	-- YOY
**********************************************************************************************************************/
	ELSE IF (@P_MEASURE_CD = 'YOY')
		BEGIN
                  WITH SA
                    AS (
                        SELECT ITEM_MST_ID
                             , ACCOUNT_ID
                             , BASE_DATE 
                             , QTY
                             , AMT 
                         FROM TB_CM_ACTUAL_SALES
                        WHERE BASE_DATE BETWEEN @p_STRT_DATE AND @p_END_DATE
                    )

		 MERGE TB_DP_MEASURE_DATA TGT
		 USING (  SELECT SA.ITEM_MST_ID
                         , SA.ACCOUNT_ID
                         , DATEADD(YEAR, 1, MM.BASE_DATE)	AS BASE_DATE
                         , SUM(QTY)		AS QTY 
                         , SUM(AMT)		AS AMT 
                      FROM SA SA
                           INNER JOIN 
                           #TEMP_DP_ITEM_ACCOUNT_DATE MM
                        ON SA.ITEM_MST_ID = MM.ITEM_MST_ID
                       AND SA.ACCOUNT_ID = MM.ACCOUNT_ID
                       AND SA.BASE_DATE BETWEEN MM.STRT_DATE AND MM.END_DATE 
                 GROUP BY SA.ITEM_MST_ID
                        , SA.ACCOUNT_ID
                        , MM.BASE_DATE	
					 ) SRC
				  ON TGT.ITEM_MST_ID = SRC.ITEM_MST_ID
				 AND TGT.ACCOUNT_ID = SRC.ACCOUNT_ID
				 AND TGT.BASE_DATE = SRC.BASE_DATE			
			   WHEN MATCHED THEN 
			   UPDATE 
			     SET YOY_QTY = SRC.QTY
					,YOY_AMT = SRC.AMT 
			   WHEN NOT MATCHED THEN
			   INSERT ( ID
					  , ITEM_MST_ID
			   		  , ACCOUNT_ID
					  , BASE_DATE
					  , YOY_QTY
					  , YOY_AMT 
					  )
			   VALUES (	REPLACE(NEWID(),'-','')
					  , SRC.ITEM_MST_ID
					  , SRC.ACCOUNT_ID
					  , SRC.BASE_DATE
					  , SRC.QTY
			   		  , SRC.AMT 
			  		  )
					  ;
			   			
		END
/**********************************************************************************************************************
	-- Actual Sales
**********************************************************************************************************************/
ELSE IF (@P_MEASURE_CD = 'ACT_SALES')
	BEGIN
                  WITH SA
                    AS (
                        SELECT ITEM_MST_ID
                             , ACCOUNT_ID
                             , BASE_DATE 
                             , QTY
                             , AMT 
                         FROM TB_CM_ACTUAL_SALES
                        WHERE BASE_DATE BETWEEN @p_STRT_DATE AND @p_END_DATE
                    )

		 MERGE TB_DP_MEASURE_DATA TGT
		 USING (  SELECT SA.ITEM_MST_ID
                         , SA.ACCOUNT_ID
                         , MM.BASE_DATE
                         , SUM(QTY)		AS QTY 
                         , SUM(AMT)		AS AMT 
                      FROM SA SA
                           INNER JOIN 
                           #TEMP_DP_ITEM_ACCOUNT_DATE MM
                        ON SA.ITEM_MST_ID = MM.ITEM_MST_ID
                       AND SA.ACCOUNT_ID = MM.ACCOUNT_ID
                       AND SA.BASE_DATE BETWEEN MM.STRT_DATE AND MM.END_DATE 
                 GROUP BY SA.ITEM_MST_ID
                        , SA.ACCOUNT_ID
                        , MM.BASE_DATE			
			 ) SRC
			ON TGT.ITEM_MST_ID = SRC.ITEM_MST_ID
		   AND TGT.ACCOUNT_ID = SRC.ACCOUNT_ID
		   AND TGT.BASE_DATE = SRC.BASE_DATE
		  WHEN MATCHED THEN
			UPDATE SET TGT.ACT_SALES_QTY = SRC.QTY
					 , TGT.ACT_SALES_AMT = SRC.AMT
					 , TGT.MODIFY_BY     = 'system'
					 , TGT.MODIFY_DTTM   = GETDATE()
		  WHEN NOT MATCHED THEN 
			INSERT
			(ID
			,ITEM_MST_ID
			,ACCOUNT_ID
			,BASE_DATE
			,ACT_SALES_QTY
			,ACT_SALES_AMT
			,CREATE_BY
			,CREATE_DTTM
			)
			VALUES
			(REPLACE(NEWID(),'-','')
			,SRC.ITEM_MST_ID
			,SRC.ACCOUNT_ID
			,SRC.BASE_DATE
			,SRC.QTY
			,SRC.AMT
			,'system'
			,GETDATE()			
			);

	END

	DELETE FROM #TEMP_DP_ITEM_ACCOUNT_DATE;

	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0003'  --저장 되었습니다.
	   
END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE()= @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH

go

