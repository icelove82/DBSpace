
CREATE PROCEDURE [dbo].[SP_UI_CM_06_Q3] (
	 @P_BOD_TYPE					NVARCHAR(32) = '' 
	,@P_CONSUME_LOCAT_TP_NM			NVARCHAR(32) = '' 
	,@P_CONSUME_LOCAT_LV			NVARCHAR(32) = '' 
	,@P_CONSUME_LOCAT_CD			NVARCHAR(32) = '' 
	,@P_CONSUME_LOCAT_NM			NVARCHAR(32) = '' 
	,@P_SUPPLY_LOCAT_TP_NM			NVARCHAR(32) = '' 
	,@P_SUPPLY_LOCAT_LV				NVARCHAR(32) = '' 
	,@P_SUPPLY_LOCAT_CD				NVARCHAR(32) = '' 
	,@P_SUPPLY_LOCAT_NM				NVARCHAR(32) = '' 
) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN
	  
    SELECT M.COMN_CD_NM			AS BOD_TYPE
             , N.COMN_CD_NM		AS SUPPLY_LOCAT_TP
             , B.LOCAT_LV		AS SUPPLY_LOCAT_LV
             , C.LOCAT_CD		AS SUPPLY_LOCAT_CD
             , C.LOCAT_NM		AS SUPPLY_LOCAT_NM
             , O.COMN_CD_NM		AS CONSUME_LOCAT_TP
             , E.LOCAT_LV		AS CONSUME_LOCAT_LV
             , F.LOCAT_CD		AS CONSUME_LOCAT_CD
             , F.LOCAT_NM		AS CONSUME_LOCAT_NM
             , P.VEHICL_TP	
             , P.LT             AS BOD_LEADTIME
             , P.UOM_NM	
             , A.CREATE_BY
             , A.CREATE_DTTM
             , A.MODIFY_BY
             , A.MODIFY_DTTM
    FROM	TB_CM_LOC_BOD_MAP A   
           INNER JOIN TB_CM_LOC_MGMT D   
               ON (D.ID = A.SUPPLY_LOCAT_ID )
           INNER JOIN TB_CM_LOC_DTL C   
               ON (C.ID = D.LOCAT_ID )
           INNER JOIN TB_CM_LOC_MST B   
               ON (B.ID = C.LOCAT_MST_ID )
           INNER JOIN TB_CM_LOC_MGMT G   
               ON ( G.ID = A.CONSUME_LOCAT_ID )
           INNER JOIN TB_CM_LOC_DTL F   
               ON ( F.ID = G.LOCAT_ID )
           INNER JOIN TB_CM_LOC_MST E  
               ON ( E.ID = F.LOCAT_MST_ID )
           LEFT OUTER JOIN TB_AD_COMN_CODE M  
               ON (  A.BOD_TP_ID = M.ID    )
           LEFT OUTER JOIN TB_AD_COMN_CODE N  
               ON (  B.LOCAT_TP_ID = N.ID)
           LEFT OUTER JOIN TB_AD_COMN_CODE O  
               ON ( E.LOCAT_TP_ID = O.ID)
           LEFT OUTER JOIN
           (
                SELECT  A.CONSUME_LOCAT_ID, A.SUPPLY_LOCAT_ID, A.VEHICL_TP, A.LT, A.UOM_NM
                FROM    (
                        SELECT  A.SHIP_LT_MST_ID, 
                                A.CONSUME_LOCAT_ID, A.SUPPLY_LOCAT_ID, A.VEHICL_TP_ID, A.VEHICL_TP, A.LT, A.UOM_NM,
                                ROW_NUMBER() OVER (PARTITION BY A.CONSUME_LOCAT_ID, A.SUPPLY_LOCAT_ID ORDER BY A.A_PRIO, A.B_PRIO, A.VEHICL_TP) AS ROW_SEQ
                        FROM    (
                                SELECT  A.ID AS SHIP_LT_MST_ID, A.VEHICL_TP_ID, 
                                        A.CONSUME_LOCAT_ID, A.SUPPLY_LOCAT_ID,
                                        B.VEHICL_TP, ISNULL(A.PRIORT, 0) A_PRIO, ISNULL(B.PRIORT, 0) B_PRIO, C.LT, D.UOM_NM
                                FROM    TB_CM_SHIP_LT_MST A  ,
                                        TB_CM_VEHICLE B  ,
                                        (
                                        SELECT  SHPP_LEADTIME_MST_ID, SUM(LEADTIME) LT, MIN(UOM_ID) UOM_ID
                                        FROM    TB_CM_SHIP_LT_DTL  
                                        GROUP   BY SHPP_LEADTIME_MST_ID
                                        ) C
                                        LEFT OUTER JOIN TB_CM_UOM D  
										ON D.ID = C.UOM_ID
                                WHERE   B.ID = A.VEHICL_TP_ID
                                AND     A.ID = C.SHPP_LEADTIME_MST_ID
                            	AND     ISNULL(A.ACTV_YN, 'N') = 'Y'
                                ) A
                        ) A
                WHERE   A.ROW_SEQ = 1
           ) p
           ON G.ID = P.CONSUME_LOCAT_ID
           AND D.ID = P.SUPPLY_LOCAT_ID
    WHERE 1=1
	   -------------------
    	  AND M.ID = CASE WHEN @P_BOD_TYPE = 'ALL' OR @P_BOD_TYPE = ''
                     THEN M.ID
                     ELSE @P_BOD_TYPE
                     END
		  AND UPPER(O.COMN_CD_NM) LIKE '%'+UPPER(@P_CONSUME_LOCAT_TP_NM)+'%'
          AND E.LOCAT_LV		  LIKE '%'+@P_CONSUME_LOCAT_LV+'%'
		  AND UPPER(F.LOCAT_CD)  LIKE '%'+UPPER(@P_CONSUME_LOCAT_CD)+'%'
		  AND UPPER(F.LOCAT_NM)  LIKE '%'+UPPER(@P_CONSUME_LOCAT_NM)+'%'
		  AND UPPER(N.COMN_CD_NM) LIKE '%'+UPPER(@P_SUPPLY_LOCAT_TP_NM)+'%'
		  AND B.LOCAT_LV		LIKE '%'+@P_SUPPLY_LOCAT_LV+'%'
		  AND UPPER(C.LOCAT_CD) LIKE '%'+UPPER(@P_SUPPLY_LOCAT_CD)+'%'
		  AND UPPER(C.LOCAT_NM) LIKE '%'+UPPER(@P_SUPPLY_LOCAT_NM)+'%'
    ORDER BY
       M.COMN_CD_NM 
     , N.SEQ
     , B.LOCAT_LV
     , C.LOCAT_CD
     , C.LOCAT_NM

END

go

