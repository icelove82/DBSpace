/*****************************************************************************
Title : SP_DP_12_S2
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP Sales Authority Management
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2019.05.14 / 김소희 / Start, End Authority Date 필수값 validation 뻄 
- 2020.03.12 / KSH / EMP_NO => USER_ID 
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER
- 2021.03.10 / kim sohee / call a procedure to create User Group
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_12_S2]  (
                                       @p_ID                  NVARCHAR(32)     = NULL     
									  ,@p_SALES_LV_ID         NVARCHAR(32)     = NULL     
									  ,@p_SEL_SALES_LV_ID     NVARCHAR(32)     = NULL         
									  ,@p_STRT_DATE_AUTH      DATETIME         = NULL
									  ,@p_END_DATE_AUTH       DATETIME         = NULL
									  ,@p_EMP_NO              NVARCHAR(50)     = ''	--EMP_NO 로 변경돼서, 로직 변경해줘야함     
									  ,@p_USER_ID             NVARCHAR(50)    = ''    
									  ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true' OUTPUT
									  ,@P_RT_MSG            NVARCHAR(4000) = ''		OUTPUT									    
				                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''

	   ,@V_ID              NVARCHAR(32)     = NULL
	   ,@V_SALES_LV_ID     NVARCHAR(32)     = NULL
	   ,@V_SEL_SALES_LV_ID NVARCHAR(32)     = NULL
	   ,@V_STRT_DATE_AUTH  DATETIME         = NULL
	   ,@V_END_DATE_AUTH   DATETIME         = NULL
	   ,@V_EMP_NO          NVARCHAR(50)     = ''	
	   ,@V_USER_ID         NVARCHAR(50)    = ''   

SET @V_ID              = @p_ID             
SET @V_SALES_LV_ID     = @p_SALES_LV_ID    
SET @V_SEL_SALES_LV_ID = @p_SEL_SALES_LV_ID
SET @V_STRT_DATE_AUTH  = @p_STRT_DATE_AUTH 
SET @V_END_DATE_AUTH   = @p_END_DATE_AUTH  
SET @V_EMP_NO          = @p_EMP_NO         
SET @V_USER_ID         = @p_USER_ID        

BEGIN TRY
/** VALIDATION **************************************************************************************************************************************************************************/
IF (@V_SALES_LV_ID IS NULL OR @V_SALES_LV_ID = ''
	OR @V_SEL_SALES_LV_ID IS NULL OR @V_SEL_SALES_LV_ID = ''
	)
	BEGIN
	   SET @P_ERR_MSG = 'MSG_5036' 
	   RAISERROR (@P_ERR_MSG,12, 1);	
	END
IF (@V_EMP_NO IS NULL OR @V_EMP_NO = '')
	BEGIN
	   SET @P_ERR_MSG = 'MSG_0014' 
	   RAISERROR (@P_ERR_MSG,12, 1);			
	END
 DECLARE @v_EMP_ID CHAR(32) = ''
 SELECT @v_EMP_ID = ID  
 FROM TB_AD_USER
 WHERE USERNAME = @V_EMP_NO; 
IF (@v_EMP_ID IS NULL)
	BEGIN
	   SET @P_ERR_MSG = 'MSG_0014' 
	   RAISERROR (@P_ERR_MSG,12, 1);			
	END
-- IF (@V_STRT_DATE_AUTH IS NULL OR @V_STRT_DATE_AUTH = ''
-- 	OR @V_END_DATE_AUTH IS NULL OR @V_END_DATE_AUTH = ''
-- 	)
-- 	BEGIN
-- 	   SET @P_ERR_MSG = 'MSG_0016' 
-- 	   RAISERROR (@P_ERR_MSG,12, 1);			
-- 	END
IF (@V_STRT_DATE_AUTH>@V_END_DATE_AUTH)
	BEGIN
	   SET @P_ERR_MSG = 'MSG_0007' 
	   RAISERROR (@P_ERR_MSG,12, 1);			
	END



--SELECT * FROM [TB_DP_SALES_AUTH_MAP]  WHERE ID = '8F6CAA745ACD48AFA556AF7091E3C34C'
 
--UPDATE [TB_DP_SALES_AUTH_MAP] 
-- SET MODIFY_DTTM = '9999-12-31'
-- WHERE ID = '8F6CAA745ACD48AFA556AF7091E3C34C'

    
	

	  -- 프로시저 시작 
	  
				MERGE [TB_DP_SALES_AUTH_MAP] TGT
				USING ( 
						SELECT    @V_ID                 AS   ID 
						         ,CASE WHEN LEN(@V_SALES_LV_ID)  > 0 THEN @V_SALES_LV_ID ELSE @V_SEL_SALES_LV_ID END AS SALES_LV_ID      
								 ,CASE WHEN CONVERT(VARCHAR(8),CONVERT(datetime, @V_STRT_DATE_AUTH),112) = '19010101' THEN 	CONVERT(datetime, '9999-12-31') ELSE @V_STRT_DATE_AUTH END AS STRT_DATE_AUTH	
								 ,CASE WHEN CONVERT(VARCHAR(8),CONVERT(datetime, @V_END_DATE_AUTH),112) = '19010101' THEN 	CONVERT(datetime, '9999-12-31') ELSE @V_END_DATE_AUTH END	AS 	 END_DATE_AUTH 	
								 ,@v_EMP_ID        		AS 	 EMP_ID        	
								 ,@V_USER_ID           	AS 	 USER_ID           	
					  ) SRC
				ON   TGT.ID = SRC.ID
 				WHEN MATCHED THEN
					 UPDATE 
					   SET   
					         TGT.STRT_DATE_AUTH	       = SRC.STRT_DATE_AUTH
							,TGT.END_DATE_AUTH 	       = SRC.END_DATE_AUTH        
							,TGT.EMP_ID        	       = SRC.EMP_ID        
							,TGT.MODIFY_BY             = SRC.USER_ID       
							,TGT.MODIFY_DTTM           = GETDATE()        
				WHEN NOT MATCHED THEN 
					 INSERT ( 
					            ID
					          , SALES_LV_ID   
						      , STRT_DATE_AUTH
						      , END_DATE_AUTH 
						      , EMP_ID        
							  , CREATE_BY
							  , CREATE_DTTM
							) 
					 VALUES (
					            SRC.ID --(SELECT REPLACE(NEWID(),'-','') )
                              , SRC.SALES_LV_ID
						      , SRC.STRT_DATE_AUTH
						      , SRC.END_DATE_AUTH 
						      , SRC.EMP_ID        
							  , SRC.USER_ID 
							  , GETDATE()            
 							) 
							;    	
     
							
	  -- 프로시저 종료 

		DECLARE @V_LV_MGMT_ID	CHAR(32);
		SELECT @V_LV_MGMT_ID = LV_MGMT_ID 
		  FROM TB_DP_SALES_LEVEL_MGMT
		WHERE ID = @p_SALES_LV_ID
		;
		EXEC SP_UI_DP_00_MAKE_USER_GROUP @P_USER_ID = @V_EMP_ID, @P_USER_NAME = @P_EMP_NO, @P_AUTH_TP_ID = @V_LV_MGMT_ID ;

	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;

go

