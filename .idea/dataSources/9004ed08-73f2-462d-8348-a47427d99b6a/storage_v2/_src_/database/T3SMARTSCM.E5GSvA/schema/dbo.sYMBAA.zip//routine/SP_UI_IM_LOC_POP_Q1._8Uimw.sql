
CREATE PROCEDURE [dbo].[SP_UI_IM_LOC_POP_Q1]
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

	WITH T_LOC_INFO AS(
		SELECT  B.ID                                         AS LOCAT_MST_ID  
				,B.LOCAT_TP_ID                               AS LOCAT_TP_ID 
				,X.COMN_CD_NM									 AS LOCAT_TP_NM
				,B.LOCAT_LV									 AS LOCAT_LV
				,C.ID 										 AS LOCAT_ID
				,C.LOCAT_CD									 AS LOCAT_CD
				,C.LOCAT_NM									 AS LOCAT_NM
				,D.ID                                        AS LOCAT_MGMT_ID
			FROM  TB_CM_CONFIGURATION A
				,TB_CM_LOC_MST        B
				,TB_CM_LOC_DTL        C
				,TB_CM_LOC_MGMT       D
				,TB_AD_COMN_CODE	  X
			WHERE 1=1
			AND A.ID = B.CONF_ID
			AND B.ID = C.LOCAT_MST_ID
			AND C.ID = D.LOCAT_ID
			AND B.LOCAT_TP_ID = X.ID
			AND B.ACTV_YN = 'Y'
			AND C.ACTV_YN = 'Y'
			AND D.ACTV_YN = 'Y'
			AND X.COMN_CD IN ('LOC_CDC', 'LOC_RDC')
	)
	SELECT LOCAT_MST_ID
			,LOCAT_TP_ID 
			,LOCAT_TP_NM	
			,LOCAT_LV	
			,LOCAT_ID	
			,LOCAT_CD	
			,LOCAT_NM
			,LOCAT_MGMT_ID
		FROM T_LOC_INFO;

END

go

