/*****************************************************************************
Title : [SP_UI_DP_00_USER_ITEM_LV_Q1]
최초 작성자 : 김소희
최초 생성일 : 2019.05.25
 
설명 
 - DP 콤보(LEVEL Management) 조회 프로시저 
  
History (수정일자 / 수정자 / 수정내용)
- 2019.05.25 / 김소희 / 최초 작성
- 2020.03.12 / KSH / EMP_NO => USER_ID 
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_00_USER_ITEM_LV_Q1] ( 
													  @p_EMP_NO	    NVARCHAR(240) = NULL
													, @p_AUTH_TP_ID CHAR(32)	  = NULL
												    , @p_LEAF_YN    CHAR(1)    = NULL
                                                    , @p_TYPE		NVARCHAR(30)      = NULL
								                 ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
	DECLARE @P_EMP_ID	CHAR(32);
BEGIN
	SELECT @P_EMP_ID = ID 
	  FROM TB_AD_USER 
	 WHERE USERNAME = @p_EMP_NO
IF NOT EXISTS (
							SELECT EMP_ID 
						     FROM TB_DP_USER_ITEM_MAP
							WHERE EMP_ID = @p_EMP_ID
							  AND AUTH_TP_ID = @p_AUTH_TP_ID
							  AND ACTV_YN = 'Y'
							UNION
						    SELECT EMP_ID
						      FROM TB_DP_USER_ITEM_ACCOUNT_MAP
						     WHERE EMP_ID = @p_EMP_ID
							   AND AUTH_TP_ID = @p_AUTH_TP_ID
							   AND ACTV_YN = 'Y'
				)
	BEGIN
		SET @P_EMP_ID = NULL;
	END
IF (@P_EMP_ID IS NULL OR @p_AUTH_TP_ID IS NULL)
	BEGIN
		SELECT * 
		FROM ( 
				SELECT  '' AS ID 
					  , UPPER(@P_TYPE)  AS CD
					  , UPPER(@P_TYPE)  AS CD_NM
					  , 0 AS LV_SEQ
					  , 0 AS SEQ
				WHERE UPPER(@P_TYPE) = 'ALL'
				UNION ALL 
				SELECT IL.ID
					  ,IL.ITEM_LV_CD AS CD 
					  ,IL.ITEM_LV_NM AS CD_NM 
					  ,LM.SEQ AS LV_SEQ
					  ,IL.SEQ
				  FROM TB_CM_CONFIGURATION A
					 , TB_CM_COMM_CONFIG B
					 , TB_CM_LEVEL_MGMT  LM
					 , TB_CM_ITEM_LEVEL_MGMT  IL
				  WHERE A.MODULE_CD = 'DP'
					AND A.ID = B.CONF_ID
					AND B.CONF_GRP_CD = 'DP_LV_TP'
					AND B.CONF_CD = 'I'
					AND B.ID = LM.LV_TP_ID  -- S/C/I
					AND ISNULL(LM.DEL_YN,'N') = 'N'
					AND LM.ACTV_YN = 'Y'
					AND LM.ID = IL.LV_MGMT_ID 
					AND LM.LV_LEAF_YN  LIKE '%' + ISNULL(@p_LEAF_YN,'') +'%'	
					AND ISNULL(IL.DEL_YN,'N') = 'N'
					AND IL.ACTV_YN = 'Y'
		     )  A
		ORDER BY A.LV_SEQ, A.SEQ
		 ;
	END
ELSE
	BEGIN
		SELECT NULL				AS ID
	      ,  'ALL'			AS CD_NM
		    ,  'ALL'			AS CD
		WHERE @P_TYPE = 'ALL'
		UNION
		SELECT IL.ID
			 , IL.ITEM_LV_NM	AS CD_NM
			 , IL.ITEM_LV_CD	AS CD
	    FROM FN_DP_TEMP_FIND_ITEM(@P_EMP_ID,@P_AUTH_TP_ID, NULL) FI
			   INNER JOIN
			   TB_CM_ITEM_LEVEL_MGMT IL
	  	ON IL.ID = FI.PARENT_ITEM_LV_ID
	GROUP BY IL.ID, ITEM_LV_CD, ITEM_LV_NM
	END
	
	
	
	
	
	
	
	
	
	
	
	
	

END






go

