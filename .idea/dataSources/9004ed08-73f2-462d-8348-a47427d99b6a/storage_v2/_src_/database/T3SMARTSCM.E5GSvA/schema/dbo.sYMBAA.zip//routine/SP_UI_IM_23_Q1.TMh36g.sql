
CREATE PROCEDURE [dbo].[SP_UI_IM_23_Q1] (
	 @P_MAIN_VER_ID				NVARCHAR(100) = '',
	 @P_LOCAT_TP				NVARCHAR(100) = '',
	 @P_LOCAT_LV				NVARCHAR(100) = '',
	 @P_LOCAT_CD				NVARCHAR(100) = '',
	 @P_LOCAT_NM				NVARCHAR(100) = ''
) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN
	WITH LOC_INFO AS (
        SELECT   A.COMN_CD_NM    AS LOCAT_TP_NM
                ,B.LOCAT_LV
                ,C.LOCAT_CD
                ,C.LOCAT_NM
                ,E.ID AS LOCAT_ITEM_ID
        FROM    TB_AD_COMN_CODE A
                INNER JOIN
                TB_CM_LOC_MST B
                ON (A.ID = B.LOCAT_TP_ID)
                INNER JOIN
                TB_CM_LOC_DTL C
                ON (B.ID = C.LOCAT_MST_ID)
                INNER JOIN
                TB_CM_LOC_MGMT D
                ON (C.ID = D.LOCAT_ID)
                INNER JOIN
                TB_CM_SITE_ITEM E
                ON (D.ID = E.LOCAT_MGMT_ID)
    )
    SELECT
            F.LOCAT_TP_NM
        ,F.LOCAT_LV
        ,F.LOCAT_CD
        ,F.LOCAT_NM
        ,D.VAL_01
        ,D.VAL_02
        ,D.VAL_03
        ,D.VAL_04
        ,D.VAL_05
        ,D.VAL_06
        ,D.VAL_07
        ,D.VAL_08
        ,D.VAL_09
        ,D.VAL_10
		,D.VAL_11
        ,D.VAL_12
        ,D.VAL_13
        ,D.VAL_14
        ,D.VAL_15
        ,D.VAL_16
        ,D.VAL_17
        ,D.VAL_18
        ,D.VAL_19
        ,D.VAL_20
        ,B.SIMUL_VER_ID
		,DBO.SUBSTRING_SPLIT_INDEX(B.SIMUL_VER_ID, '-', 4) AS SIMUL_VER_SEQ
        ,E.CONBD_MAIN_VER_DTL_ID
        ,G.COMN_CD_NM               AS STOCK_MGMT_SYSTEM_TP
        ,H.COMN_CD_NM               AS STOCK_PLACE_STRTGY
        ,COUNT(*)                   AS ITEM_CNT
        ,SUM(C.DMND_QTY)            AS DMND_QTY
        ,SUM(C.ON_TIME_QTY)         AS ON_TIME_QTY
        ,AVG(C.AVG_INV_QTY)         AS AVG_INV_QTY
        ,AVG(C.AVG_INV_AMT)         AS AVG_INV_AMT
        ,AVG(C.FILL_RATE)           AS FILL_RATE
        ,SUM(C.BACK_ORD)            AS BACK_ORD
        ,AVG(C.PDT_LV)              AS PREDICT_LV
        ,SUM(C.KEEPING_COST)        AS KEEPING_COST
        ,SUM(C.ORDER_COST)          AS ORDER_COST
        ,SUM(C.TRANSP_COST)         AS TRANSP_COST
        ,SUM(C.TOTAL_COST)          AS TOTAL_COST
        ,MIN(E.FIXED_YN)            AS CONFRM_YN
    FROM
        TB_CM_CONBD_MAIN_VER_MST A
        INNER JOIN
        TB_CM_CONBD_MAIN_VER_DTL B
        ON (B.CONBD_MAIN_VER_MST_ID = A.ID)
        INNER JOIN
        TB_RT_OPT_SCNRI_COMBT_MAIN C
        ON (C.CONBD_MAIN_VER_DTL_ID = B.ID)
        INNER JOIN
        TB_RT_SITE_ITEM_SEG_SUMM D
        ON (D.CONBD_MAIN_VER_DTL_ID = B.ID AND D.LOCAT_ITEM_ID = C.LOCAT_ITEM_ID)
        INNER JOIN
        TB_RT_INV_POLICY_ITEM E
        ON (E.CONBD_MAIN_VER_DTL_ID = B.ID AND E.LOCAT_ITEM_ID = D.LOCAT_ITEM_ID)
        INNER JOIN
        LOC_INFO F
        ON (F.LOCAT_ITEM_ID = E.LOCAT_ITEM_ID)
        LEFT OUTER JOIN
        TB_AD_COMN_CODE G
        ON (E.INV_MGMT_SYSTEM_TP_ID = G.ID)
        LEFT OUTER JOIN
        TB_AD_COMN_CODE H
        ON (E.INV_PLACE_STRTGY_ID = H.ID)
    WHERE
        1 = 1
        AND UPPER(ISNULL(A.MAIN_VER_ID,'')) LIKE '%' + @P_MAIN_VER_ID + '%'
        AND UPPER(F.LOCAT_TP_NM) LIKE '%'+UPPER(@P_LOCAT_TP)+'%'
        AND F.LOCAT_LV LIKE '%'+@P_LOCAT_LV+'%'
        AND UPPER(F.LOCAT_CD) LIKE '%'+UPPER(@P_LOCAT_CD)+'%'
        AND UPPER(F.LOCAT_NM) LIKE '%'+UPPER(@P_LOCAT_NM)+'%'
    GROUP BY
        F.LOCAT_TP_NM, F.LOCAT_LV, F.LOCAT_CD, F.LOCAT_NM, 
        D.VAL_01, D.VAL_02, D.VAL_03, D.VAL_04, D.VAL_05, D.VAL_06, D.VAL_07, D.VAL_08, D.VAL_09, D.VAL_10,
		D.VAL_11, D.VAL_12, D.VAL_13, D.VAL_14, D.VAL_15, D.VAL_16, D.VAL_17, D.VAL_18, D.VAL_19, D.VAL_20, 
        B.SIMUL_VER_ID, E.CONBD_MAIN_VER_DTL_ID, G.COMN_CD_NM, H.COMN_CD_NM, E.FIXED_YN;
END

go

