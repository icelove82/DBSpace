CREATE PROCEDURE [dbo].[SP_UI_BF_50_CHART_Q1]
	 @P_VER_CD	  NVARCHAR(100)
	,@P_ITEM	  NVARCHAR(100) = null
	,@P_SALES	  NVARCHAR(100) = null
	,@P_FROM_DATE DATE = null
	,@P_TO_DATE   DATE = null
AS 
/*
	BF Accuracy Analysis Load Procedure
	작성자 : 김소희
	작성일 : 2019.04.30
	History (Date / User / Comment)
	- 2019.04.30 / 김소희 / 초안 작성 (우선은 DATE가 주차로 같을 것이라고 가정)
	- 2019.05.08 / 김소희 / BF_PLAN_POLICY의 Bucket 활용
						  / parameter 추가 : Item, Sales
						 / 개인화 정보 값 반영하여 계산
	- 2019.05.10 / 김소희 / Item level or Code 둘 중 하나 값만 들어오기 떄문에 level 데이터 join걸어줘야 함.
	- 2020.01.** / 민경훈 / 로직 변경
	- 2020.01.20 / 김소희 / 로직 변경
	-- 2020.02.28 / kim sohee / change week rule : DP_WK (53 week per a year) 
	- 2020.06.22 / 김소희 / 주차 외에 다른 버킷 단위로 조회 가능하게
*/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON;
	DECLARE @P_TARGET_FROM_DATE DATE
		  , @V_BUKT				NVARCHAR(2)
	SELECT @P_TARGET_FROM_DATE = MAX(TARGET_FROM_DATE)
		 , @V_BUKT			   = MAX(TARGET_BUKT_CD)
	  FROM TB_BF_CONTROL_BOARD_VER_DTL
	 WHERE VER_CD = @P_VER_CD
	   AND ENGINE_TP_CD IS NOT NULL
	;
/*************************************************************************************************************
	-- 주차 시작 요일 바꼈을 경우 대비해서 버전 날짜 범위 변경 처리
************************************************************************************************************/

IF (@V_BUKT = 'W')
BEGIN
	SELECT --@P_FROM_dATE    = MIN(STRT_DATE),
		   @P_TO_DATE	   = MAX(END_DATE)
	  FROM (
			SELECT YYYY
				 , DP_WK
				 , MIN(DAT) AS STRT_DATE
				 , MAX(DAT) AS END_DATE
			  FROM TB_CM_CALENDAR C
			 WHERE DAT BETWEEN @P_FROM_DATE AND @P_TO_DATE
		  GROUP BY YYYY, DP_WK
		  HAVING COUNT(DP_WK) >= 7
		  ) A
END
; 

BEGIN
 
WITH RT
AS (
	SELECT ITEM_CD
		 , ACCOUNT_CD
		 , BASE_DATE 
		 , ENGINE_TP_CD
		 , isnull(QTY,0)	AS QTY
	  FROM TB_BF_RT RF
	 WHERE BASE_DATE BETWEEN @P_FROM_DATE and @P_TO_DATE
	   AND VER_CD = @P_VER_CD
	   AND ACCOUNT_CD = @P_SALES
	   AND ITEM_CD = @P_ITEM
), CALENDAR
AS (
	SELECT DAT 
         , YEAR(DATEADD(day, 26 - DATEPART(isoww, dat), dat)) iso_year
         , DATEPART(isoww, dat) iso_week
         , YYYY
         , YYYYMM
         , DP_WK	
	  FROM TB_CM_CALENDAR CA
	 WHERE DAT between @P_FROM_DATE and @P_TO_DATE     
)
, CA
AS (
	SELECT MIN(DAT)	 STRT_DATE
		 , MAX(DAT)	 END_DATE
		 , CASE @V_BUKT
			WHEN 'W' THEN CONVERT(NVARCHAR(4), iso_year) +' w' + CONVERT(NVARCHAR(2), iso_week)
			WHEN 'PW'THEN YYYYMM+' w' + SUBSTRING(DP_WK, 5, 2)
			WHEN 'M' THEN YYYYMM
		   END AS BUKT	
	  FROM CALENDAR CA
	 WHERE DAT between @P_FROM_DATE and @P_TO_DATE 
   GROUP BY CASE @V_BUKT
			WHEN 'W' THEN CONVERT(NVARCHAR(4), iso_year) +' w' + CONVERT(NVARCHAR(2), iso_week)
			WHEN 'PW'THEN YYYYMM+' w' + SUBSTRING(DP_WK, 5, 2)
			WHEN 'M' THEN YYYYMM
		   END 
), SA
AS (
	SELECT  ITEM_CD
		  , ACCOUNT_CD
		  , CA.STRT_DATE
		  , CA.BUKT 
		  , SUM(QTY)	QTY 
	  FROM TB_CM_ACTUAL_SALES S
--		   INNER JOIN CALENDAR MCA
--		ON S.BASE_DATE = MCA.DAT 
	       INNER JOIN
		   CA
--		ON MCA.BUKT = CA.BUKT 
        ON S.BASE_DATE BETWEEN CA.STRT_DATE AND CA.END_DATE
		   INNER JOIN 
		   TB_CM_ITEM_MST IM 
		ON S.ITEM_MST_ID = IM.ID
	   AND ISNULL(IM.DEL_YN,'N') = 'N'
		   INNER JOIN 
		   TB_DP_ACCOUNT_MST AM
		ON S.ACCOUNT_ID = AM.ID
	   AND ISNULL(AM.DEL_YN,'N') = 'N'
	   AND AM.ACTV_YN = 'Y'
	 WHERE 1=1
	   AND ACCOUNT_CD = @P_SALES
	   AND ITEM_CD = @P_ITEM
  GROUP BY ITEM_CD, ACCOUNT_CD
		  , CA.BUKT
		  , CA.STRT_DATE
), N
AS (
	SELECT RT.ITEM_CD					AS ITEM_CD
	     , RT.ACCOUNT_CD				AS ACCOUNT_CD
		 , CA.BUKT
		 , RT.ENGINE_TP_CD
		 , SUM(RT.QTY)					AS QTY 			 
	  FROM RT 
--		   INNER JOIN
--		   CALENDAR MCA
--	    ON RT.BASE_DATE = MCA.DAT
		   INNER JOIN 
		   CA 
--		ON MCA.BUKT = CA.BUKT 
        ON RT.BASE_DATE BETWEEN CA.STRT_DATE AND END_DATE
GROUP BY ITEM_CD, ACCOUNT_CD, CA.BUKT, ENGINE_TP_CD 
	 UNION
	SELECT SA.ITEM_CD
		 , SA.ACCOUNT_CD
		 , BUKT
		 , 'Z_ACT_SALES'						AS ENGINE_TP_CD
		 , SA.QTY 
	  FROM SA
), M
AS (
	SELECT ITEM_CD
		  ,ACCOUNT_CD 
		  ,ENGINE_TP_CD
		  ,STRT_DATE
		  ,END_DATE
		  ,BUKT
		  ,CASE WHEN ENGINE_TP_CD ='Z_ACT_SALES' AND STRT_DATE >= @P_TARGET_FROM_DATE THEN 'ORANGE' 
				WHEN ENGINE_TP_CD ='Z_ACT_SALES' AND STRT_DATE < @P_TARGET_FROM_DATE THEN 'GREY'
				ELSE NULL 
		   END AS COLOR
	  FROM CA 
		   CROSS JOIN
		   ( SELECT ITEM_CD
				   ,ACCOUNT_CD 
				   ,ENGINE_TP_CD
			   FROM N  
		   GROUP BY ITEM_CD
		 		   ,ACCOUNT_CD 
		 		   ,ENGINE_TP_CD
		   ) RT
)
SELECT M.ITEM_CD
	 , M.ACCOUNT_CD
	 , M.ENGINE_TP_CD
	 , M.BUKT	
--	 , M.STRT_DATE
--	 , M.END_DATE 
	 , N.QTY	 
	 , M.COLOR 
  FROM M
	   LEFT OUTER JOIN
	   N ON M.ITEM_CD = N.ITEM_CD
		  AND M.ACCOUNT_CD = N.ACCOUNT_CD
		  AND M.BUKT = N.BUKT
		  AND M.ENGINE_TP_CD = N.ENGINE_TP_CD
  ORDER BY M.ENGINE_TP_CD, M.STRT_DATE

END 

go

