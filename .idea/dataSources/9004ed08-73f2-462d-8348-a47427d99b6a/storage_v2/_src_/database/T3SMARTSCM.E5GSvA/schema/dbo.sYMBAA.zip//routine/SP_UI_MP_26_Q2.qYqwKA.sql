CREATE PROCEDURE [dbo].[SP_UI_MP_26_Q2]
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN
    SELECT A.MAIN_VER_ID
            ,B.COMN_CD            AS MODULE_VAL
            ,A.DESCRIP            AS MAIN_VER_DESCRIP
            ,D.STEP               AS PROCESS_STEP
            ,D.PROCESS_DESCRIP    AS PROCESS_DESCRIP
    FROM TB_CM_CONBD_MAIN_VER_MST A,
            TB_AD_COMN_CODE B,
            TB_CM_PLAN_SNRIO_MGMT_MST C,
            TB_CM_PLAN_SNRIO_MGMT_DTL D
    WHERE 1=1
    AND A.MODULE_ID = B.ID
    AND A.PLAN_SNRIO_MGMT_MST_ID = C.ID
    AND C.ID = D.PLAN_SNRIO_MGMT_MST_ID
    AND D.STEP=1
    AND A.MAIN_VER_ID = (
                            SELECT MAX(MAIN_VER_ID)
                            FROM TB_CM_CONBD_MAIN_VER_MST A
                                ,TB_AD_COMN_CODE B
                            WHERE 1=1
                            AND A.MODULE_ID = B.ID
                            AND B.COMN_CD LIKE '%MP%'
                            );

END

go

