CREATE PROCEDURE [dbo].[SP_UI_IM_13_Q4] (
	@P_INTRANSIT_INV_MST_ID char(32)
)
AS
/*****************************************************************************
Title : SP_UI_IM_13_Q4
최초 작성자 : 한영석
최초 생성일 : 2017.09.15
 
설명 
 -  Customer Pegging 팝업 쿼리
 - SP_UI_IM_12_Q3과 동일한 로직
History (수정일자 / 수정자 / 수정내용)
- 2017.07.24 / 한영석 / 최초 작성
 
*****************************************************************************/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	SELECT A.ID, A.ACCOUNT_CD, A.ACCOUNT_NM
	, (		
		SELECT 1
		FROM TB_DP_ACCOUNT_MST B
		WHERE 1=1
		AND B.ID = A.ID
		AND A.ID 	=	(
				SELECT ACCOUNT_ID
				FROM TB_CM_INTRANSIT_STOCK_MST A
				WHERE A.ID = @P_INTRANSIT_INV_MST_ID
				)
		)  AS ACTV_YN
	FROM TB_DP_ACCOUNT_MST A

go

