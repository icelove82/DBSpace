/*****************************************************************************
Title : SP_UI_CM_08_POP_04_S
최초 작성자 : 이정섭
최초 생성일 : 2018.07.09
 
설명 
 - Shpping Holiday 등록 및 삭제
 
History (수정일자 / 수정자 / 수정내용)
- 2018.07.09 / 이정섭 / 최초 작성
 
*****************************************************************************/
CREATE PROCEDURE [dbo].[SP_UI_CM_08_POP_04_S] (
     @P_WRK_TYPE				AS NVARCHAR(100) = ''
	,@P_SHPP_LEADTIME_DTL_ID 	AS NVARCHAR(100) = ''
	,@P_CALENDAR_ID	    		AS NVARCHAR(100) = ''
	,@P_CALENDAR_DESC			AS NVARCHAR(100) = ''
	,@P_STRT_DATE				AS DATETIME = ''
	,@P_END_DATE				AS DATETIME = ''
	,@P_CYCLE_TYPE				AS NVARCHAR(100) = ''
	,@P_ACTV_YN					AS NVARCHAR(100) = ''
	,@P_USER_ID					AS NVARCHAR(100) = ''
    ,@P_RT_ROLLBACK_FLAG     	NVARCHAR(10)   = 'true'  OUTPUT
	,@P_RT_MSG               	NVARCHAR(4000) = ''		 OUTPUT
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
		,@P_ERR_MSG NVARCHAR(4000) = ''
		,@V_CALENDAR_SEQ INT = 0

BEGIN TRY

    SELECT @V_CALENDAR_SEQ = COUNT(*) 
      FROM TB_CM_HOLIDAY

    IF @P_WRK_TYPE = 'SAVE'
    	BEGIN
	    	
	        MERGE INTO TB_CM_HOLIDAY B 
			USING (SELECT @P_SHPP_LEADTIME_DTL_ID AS ID,
	                      @P_CALENDAR_ID AS CALENDAR_ID
	               ) A
	           ON (B.SHPP_LEADTIME_DTL_ID = A.ID
	           AND B.CALENDAR_ID = A.CALENDAR_ID)
			WHEN MATCHED THEN
				UPDATE 
				   SET CALENDAR_DESCRIP		= @P_CALENDAR_DESC
					 , STRT_DATE			= @P_STRT_DATE
					 , END_DATE				= @P_END_DATE
					 , CYCL_TP_ID			= @P_CYCLE_TYPE
				     , ACTV_YN				= @P_ACTV_YN
					 , MODIFY_BY			= @P_USER_ID
					 , MODIFY_DTTM			= GETDATE()
	
			WHEN NOT MATCHED THEN
				INSERT (
					ID
					,SHPP_LEADTIME_DTL_ID
					,CALENDAR_ID
					,CALENDAR_DESCRIP
					,STRT_DATE
					,END_DATE
					,CYCL_TP_ID
					,ACTV_YN
	                ,CREATE_BY
	                ,CREATE_DTTM
					)
				VALUES 
			  	    (
					REPLACE(NEWID(),'-','')
					,@P_SHPP_LEADTIME_DTL_ID
					,CONCAT('Calendar-', CAST(@V_CALENDAR_SEQ + 1 AS VARCHAR))
					,@P_CALENDAR_DESC
					,@P_STRT_DATE
					,@P_END_DATE
					,@P_CYCLE_TYPE
					,@P_ACTV_YN
	                ,@P_USER_ID
	                ,GETDATE()
				);
	
	        SET @P_RT_ROLLBACK_FLAG = 'true'
	        SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.	    	
	    	
    	END 

    ELSE IF @P_WRK_TYPE = 'DELETE'
    	BEGIN
	    	
	        DELETE
	          FROM TB_CM_HOLIDAY
	         WHERE SHPP_LEADTIME_DTL_ID = @P_SHPP_LEADTIME_DTL_ID
	           AND CALENDAR_ID = @P_CALENDAR_ID
	
	        SET @P_RT_ROLLBACK_FLAG = 'true'
	        SET @P_RT_MSG = 'MSG_0002'	
	    	
    	END 
    
END TRY

BEGIN CATCH

	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
	       BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
		       SET @P_RT_MSG = @P_ERR_MSG
		   END
	   ELSE
	       THROW

END CATCH

go

