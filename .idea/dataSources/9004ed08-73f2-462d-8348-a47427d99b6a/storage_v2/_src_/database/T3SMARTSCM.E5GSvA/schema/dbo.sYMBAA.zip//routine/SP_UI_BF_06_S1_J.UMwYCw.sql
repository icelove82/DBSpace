
CREATE PROCEDURE [dbo].[SP_UI_BF_06_S1_J]  (
									  @P_JSON				NVARCHAR(MAX)
									, @P_USER_ID			NVARCHAR(50)
									, @P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'  OUTPUT
									, @P_RT_MSG            NVARCHAR(4000) = ''		OUTPUT
				                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''

BEGIN TRY
	  BEGIN
    	  
    	        --IF EXISTS (SELECT BASE_DATE FROM TB_BF_DATE_FACTOR WHERE BASE_DATE = (SELECT BASE_DATE FROM OpenJson(@P_JSON) WITH (BASE_DATE DATE '$.BASE_DATE')))
    	        --    BEGIN
        	    --        SET @P_ERR_MSG = 'Factors for desired date already exist.'
        	    --        RAISERROR (@P_ERR_MSG, 12, 1);
    	        --    END
	  
				MERGE TB_BF_DATE_FACTOR TAR
				USING ( 
						SELECT  ID			
							  , BASE_DATE	
							  , FACTOR1	
							  , FACTOR2	
							  , FACTOR3	
							  , FACTOR4	
							  , FACTOR5	
							  , FACTOR6
							  , FACTOR7
							  , FACTOR8
							  , FACTOR9
							  , FACTOR10
							  , FACTOR11
							  , FACTOR12
							  , FACTOR13
							  , FACTOR14
							  , FACTOR15
							  , FACTOR16
							  , FACTOR17
							  , FACTOR18
							  , FACTOR19
							  , FACTOR20
							  , FACTOR21
							  , FACTOR22
							  , FACTOR23
							  , FACTOR24
							  , FACTOR25
							  , FACTOR26
							  , FACTOR27
							  , FACTOR28	
							  , FACTOR29
							  , FACTOR30
							  , FACTOR31	
							  , FACTOR32
							  , FACTOR33
							  , FACTOR34
							  , FACTOR35
							  , FACTOR36
							  , FACTOR37	
							  , FACTOR38
							  , FACTOR39
							  , FACTOR40
							  , FACTOR41
							  , FACTOR42	
							  , FACTOR43	
							  , FACTOR44	
							  , FACTOR45	
							  , FACTOR46	
							  , FACTOR47	
							  , FACTOR48	
							  , FACTOR49	
							  , FACTOR50
							  , @P_USER_ID		AS USER_ID
						FROM OpenJson(@P_JSON)
						WITH
							(
							  ID				CHAR(32)	'$.ID'
							, BASE_DATE			DATE		'$.BASE_DATE'
							, FACTOR1			FLOAT		'$.FACTOR1'
							, FACTOR2			FLOAT		'$.FACTOR2'
							, FACTOR3			FLOAT		'$.FACTOR3'
							, FACTOR4			FLOAT		'$.FACTOR4'
							, FACTOR5			FLOAT		'$.FACTOR5'
							, FACTOR6			FLOAT		'$.FACTOR6'
							, FACTOR7			FLOAT		'$.FACTOR7'
							, FACTOR8			FLOAT		'$.FACTOR8'
							, FACTOR9			FLOAT		'$.FACTOR9'
							, FACTOR10			FLOAT		'$.FACTOR10'
							, FACTOR11			FLOAT		'$.FACTOR11'
							, FACTOR12			FLOAT		'$.FACTOR12'
							, FACTOR13			FLOAT		'$.FACTOR13'
							, FACTOR14			FLOAT		'$.FACTOR14'
							, FACTOR15			FLOAT		'$.FACTOR15'
							, FACTOR16			FLOAT		'$.FACTOR16'
							, FACTOR17			FLOAT		'$.FACTOR17'
							, FACTOR18			FLOAT		'$.FACTOR18'
							, FACTOR19			FLOAT		'$.FACTOR19'
							, FACTOR20			FLOAT		'$.FACTOR20'
							, FACTOR21			FLOAT		'$.FACTOR21'
							, FACTOR22			FLOAT		'$.FACTOR22'
							, FACTOR23			FLOAT		'$.FACTOR23'
							, FACTOR24			FLOAT		'$.FACTOR24'
							, FACTOR25			FLOAT		'$.FACTOR25'
							, FACTOR26			FLOAT		'$.FACTOR26'
							, FACTOR27			FLOAT		'$.FACTOR27'
							, FACTOR28			FLOAT		'$.FACTOR28'
							, FACTOR29			FLOAT		'$.FACTOR29'
							, FACTOR30			FLOAT		'$.FACTOR30'
							, FACTOR31			FLOAT		'$.FACTOR31'
							, FACTOR32			FLOAT		'$.FACTOR32'
							, FACTOR33			FLOAT		'$.FACTOR33'
							, FACTOR34			FLOAT		'$.FACTOR34'
							, FACTOR35			FLOAT		'$.FACTOR35'
							, FACTOR36			FLOAT		'$.FACTOR36'
							, FACTOR37			FLOAT		'$.FACTOR37'
							, FACTOR38			FLOAT		'$.FACTOR38'
							, FACTOR39			FLOAT		'$.FACTOR39'
							, FACTOR40			FLOAT		'$.FACTOR40'
							, FACTOR41			FLOAT		'$.FACTOR41'
							, FACTOR42			FLOAT		'$.FACTOR42'
							, FACTOR43			FLOAT		'$.FACTOR43'
							, FACTOR44			FLOAT		'$.FACTOR44'
							, FACTOR45			FLOAT		'$.FACTOR45'
							, FACTOR46			FLOAT		'$.FACTOR46'
							, FACTOR47			FLOAT		'$.FACTOR47'
							, FACTOR48			FLOAT		'$.FACTOR48'
							, FACTOR49			FLOAT		'$.FACTOR49'
							, FACTOR50			FLOAT		'$.FACTOR50'
							)
					  ) SRC
				ON	  TAR.BASE_DATE     = SRC.BASE_DATE
				WHEN MATCHED THEN
					 UPDATE 
					   SET   		
--							 TAR.BASE_DATE		= SRC.BASE_DATE
							 TAR.FACTOR1		= SRC.FACTOR1	
							,TAR.FACTOR2		= SRC.FACTOR2	
							,TAR.FACTOR3		= SRC.FACTOR3	
							,TAR.FACTOR4		= SRC.FACTOR4	
							,TAR.FACTOR5		= SRC.FACTOR5	
							,TAR.FACTOR6		= SRC.FACTOR6	
							,TAR.FACTOR7		= SRC.FACTOR7	
							,TAR.FACTOR8		= SRC.FACTOR8	
							,TAR.FACTOR9		= SRC.FACTOR9	
							,TAR.FACTOR10		= SRC.FACTOR10	
							,TAR.FACTOR11		= SRC.FACTOR11	
							,TAR.FACTOR12		= SRC.FACTOR12	
							,TAR.FACTOR13		= SRC.FACTOR13	
							,TAR.FACTOR14		= SRC.FACTOR14	
							,TAR.FACTOR15		= SRC.FACTOR15	
							,TAR.FACTOR16		= SRC.FACTOR16	
							,TAR.FACTOR17		= SRC.FACTOR17	
							,TAR.FACTOR18		= SRC.FACTOR18	
							,TAR.FACTOR19		= SRC.FACTOR19	
							,TAR.FACTOR20		= SRC.FACTOR20	
							,TAR.FACTOR21		= SRC.FACTOR21	
							,TAR.FACTOR22		= SRC.FACTOR22	
							,TAR.FACTOR23		= SRC.FACTOR23	
							,TAR.FACTOR24		= SRC.FACTOR24	
							,TAR.FACTOR25		= SRC.FACTOR25	
							,TAR.FACTOR26		= SRC.FACTOR26	
							,TAR.FACTOR27		= SRC.FACTOR27	
							,TAR.FACTOR28		= SRC.FACTOR28	
							,TAR.FACTOR29		= SRC.FACTOR29	
							,TAR.FACTOR30		= SRC.FACTOR30	
							,TAR.FACTOR31		= SRC.FACTOR31	
							,TAR.FACTOR32		= SRC.FACTOR32	
							,TAR.FACTOR33		= SRC.FACTOR33	
							,TAR.FACTOR34		= SRC.FACTOR34	
							,TAR.FACTOR35		= SRC.FACTOR35	
							,TAR.FACTOR36		= SRC.FACTOR36	
							,TAR.FACTOR37		= SRC.FACTOR37	
							,TAR.FACTOR38		= SRC.FACTOR38	
							,TAR.FACTOR39		= SRC.FACTOR39	
							,TAR.FACTOR40		= SRC.FACTOR40	
							,TAR.FACTOR41		= SRC.FACTOR41	
							,TAR.FACTOR42		= SRC.FACTOR42	
							,TAR.FACTOR43		= SRC.FACTOR43	
							,TAR.FACTOR44		= SRC.FACTOR44	
							,TAR.FACTOR45		= SRC.FACTOR45	
							,TAR.FACTOR46		= SRC.FACTOR46	
							,TAR.FACTOR47		= SRC.FACTOR47	
							,TAR.FACTOR48		= SRC.FACTOR48	
							,TAR.FACTOR49		= SRC.FACTOR49	
							,TAR.FACTOR50		= SRC.FACTOR50	
							,TAR.MODIFY_BY		= SRC.USER_ID
							,TAR.MODIFY_DTTM	= GETDATE()
				WHEN NOT MATCHED THEN 
					 INSERT (
							  ID			
							, BASE_DATE	
							, FACTOR1	
							, FACTOR2	
							, FACTOR3	
							, FACTOR4	
							, FACTOR5	
							, FACTOR6	
							, FACTOR7	
							, FACTOR8	
							, FACTOR9	
							, FACTOR10	
							, FACTOR11	
							, FACTOR12	
							, FACTOR13	
							, FACTOR14	
							, FACTOR15	
							, FACTOR16	
							, FACTOR17	
							, FACTOR18	
							, FACTOR19	
							, FACTOR20	
							, FACTOR21	
							, FACTOR22	
							, FACTOR23	
							, FACTOR24	
							, FACTOR25	
							, FACTOR26	
							, FACTOR27	
							, FACTOR28	
							, FACTOR29	
							, FACTOR30	
							, FACTOR31	
							, FACTOR32	
							, FACTOR33	
							, FACTOR34	
							, FACTOR35	
							, FACTOR36	
							, FACTOR37	
							, FACTOR38	
							, FACTOR39	
							, FACTOR40	
							, FACTOR41	
							, FACTOR42	
							, FACTOR43	
							, FACTOR44	
							, FACTOR45	
							, FACTOR46	
							, FACTOR47	
							, FACTOR48	
							, FACTOR49	
							, FACTOR50	
							, CREATE_BY	
							, CREATE_DTTM
							) 
					 VALUES (
							 (SELECT REPLACE(NEWID(),'-','') )
							,SRC.BASE_DATE
							,SRC.FACTOR1
							,SRC.FACTOR2
							,SRC.FACTOR3
							,SRC.FACTOR4
							,SRC.FACTOR5
							,SRC.FACTOR6
							,SRC.FACTOR7
							,SRC.FACTOR8
							,SRC.FACTOR9
							,SRC.FACTOR10
							,SRC.FACTOR11
							,SRC.FACTOR12
							,SRC.FACTOR13
							,SRC.FACTOR14
							,SRC.FACTOR15
							,SRC.FACTOR16
							,SRC.FACTOR17
							,SRC.FACTOR18
							,SRC.FACTOR19
							,SRC.FACTOR20
							,SRC.FACTOR21
							,SRC.FACTOR22
							,SRC.FACTOR23
							,SRC.FACTOR24
							,SRC.FACTOR25
							,SRC.FACTOR26
							,SRC.FACTOR27
							,SRC.FACTOR28
							,SRC.FACTOR29
							,SRC.FACTOR30
							,SRC.FACTOR31
							,SRC.FACTOR32
							,SRC.FACTOR33
							,SRC.FACTOR34
							,SRC.FACTOR35
							,SRC.FACTOR36
							,SRC.FACTOR37
							,SRC.FACTOR38
							,SRC.FACTOR39
							,SRC.FACTOR40
							,SRC.FACTOR41
							,SRC.FACTOR42
							,SRC.FACTOR43
							,SRC.FACTOR44
							,SRC.FACTOR45
							,SRC.FACTOR46
							,SRC.FACTOR47
							,SRC.FACTOR48
							,SRC.FACTOR49
							,SRC.FACTOR50
							,SRC.USER_ID
							,GETDATE()
 							) 
							
							;    

         
	  END
			


	   SET @P_RT_ROLLBACK_FLAG = 'true'

	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;

go

