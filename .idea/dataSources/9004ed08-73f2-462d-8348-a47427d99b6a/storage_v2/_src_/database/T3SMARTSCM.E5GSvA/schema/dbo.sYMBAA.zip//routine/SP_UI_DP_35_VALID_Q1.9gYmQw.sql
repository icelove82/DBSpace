/*****************************************************************************
Title : [SP_UI_DP_35_VALIDATION_Q1] 
최초 작성자 : 이고은
최초 생성일 : 2017.08.30
 
설명 
 - DP VALIDATION ( All/ User)
 
History (수정일자 / 수정자 / 수정내용)
-  2017.08.30 / 이고은 / 최초 작성
- 2019.04.25 / 김소희 / DEL_YN Null처리 
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_35_VALID_Q1] 
(	
	 @p_OPERATOR_ID		NVARCHAR(100) = ''
	,@p_AUTH_TP_ID		NVARCHAR(50) = ''
) 
AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

DECLARE @v_VALID_FLAG	NVARCHAR(10) -- 전체/ 개인별 VALID 화면에서 보는 항목 조회 FLAG
	  , @V_OPERATOR_ID  NVARCHAR(100) = ''
	  , @V_AUTH_TP_ID	NVARCHAR(50) = ''

SET @V_OPERATOR_ID = @p_OPERATOR_ID	
SET @V_AUTH_TP_ID  = @p_AUTH_TP_ID	

IF	(@V_OPERATOR_ID = '' OR @V_OPERATOR_ID IS NULL)
BEGIN 
	SET @v_VALID_FLAG = 'ALL' --전체 
END 
ELSE 
BEGIN
	SET @v_VALID_FLAG = 'PSNZ' -- 개인 
END	



SELECT	A.CHECK_CD, A.CHECK_DESC, A.CNT
FROM	(
		-- 전체 #################################################################################
		SELECT	A.CHECK_CD, A.CHECK_DESC, A.CNT
		FROM	(
				SELECT 'ITEM_CD_P_LEVEL'					AS CHECK_CD	
						,'Item Master의 상위 Level 미지정'	AS CHECK_DESC
						,CONVERT(NVARCHAR,COUNT(ID))		AS CNT
				FROM	TB_CM_ITEM_MST 
				WHERE	ISNULL(DEL_YN,'N') = 'N' AND DP_PLAN_YN = 'Y'
				AND		ISNULL(PARENT_ITEM_LV_ID, '') NOT IN (SELECT ID FROM TB_CM_ITEM_LEVEL_MGMT )
				UNION ALL
				SELECT	'ITEM_LV_CD_P_LEVEL'										AS CHECK_CD
						,'Item Level Management의 상위 Lecel 미지정(seq = 1제외)'	AS CHECK_DESC
						,CONVERT(NVARCHAR,COUNT(A.ID))								AS CNT
				FROM	TB_CM_ITEM_LEVEL_MGMT A 
						INNER JOIN TB_CM_LEVEL_MGMT B  ON A.LV_MGMT_ID = B.ID AND B.ACTV_YN = 'Y'
				WHERE	A.ACTV_YN = 'Y'
				AND		A.SEQ NOT IN (
									SELECT MIN(X.SEQ) FROM  TB_CM_ITEM_LEVEL_MGMT X 
															INNER JOIN TB_CM_LEVEL_MGMT Y   ON A.LV_MGMT_ID = B.ID AND Y.ACTV_YN = 'Y'
									)
				AND		A.LV_MGMT_ID IN ( SELECT ID FROM TB_CM_LEVEL_MGMT  WHERE ACTV_YN = 'Y')
				AND		ISNULL(A.PARENT_ITEM_LV_ID, '') NOT IN	(
																SELECT ID FROM TB_CM_ITEM_LEVEL_MGMT 
																)
				UNION ALL
				SELECT	'ACCOUNT_CD_P_LEVEL'					AS CHECK_CD
						,'Account Master의 상위 Level 미지정'	AS CHECK_DESC
						,CONVERT(NVARCHAR,COUNT(ID))			AS CNT
				FROM	TB_DP_ACCOUNT_MST 
				WHERE	ISNULL(DEL_YN,'N') = 'N' AND ACTV_YN = 'Y'
				AND		ISNULL(PARENT_SALES_LV_ID, '') NOT IN	(
																SELECT ID FROM TB_DP_SALES_LEVEL_MGMT 
																)
				UNION ALL 
				SELECT	'SALES_LV_CD_P_LEVEL'										AS CHECK_CD
						,'Sales Level Management의 상위 Level 미지정 (seq = 1제외)' AS CHECK_DESC
						,CONVERT(NVARCHAR,COUNT(A.ID))								AS CNT
				FROM	TB_DP_SALES_LEVEL_MGMT A 
						INNER JOIN TB_CM_LEVEL_MGMT B  ON A.LV_MGMT_ID = B.ID AND B.ACTV_YN = 'Y'
				WHERE	A.ACTV_YN = 'Y'
				AND		A.SEQ NOT IN (
									SELECT	MIN(X.SEQ) 
									FROM	TB_DP_SALES_LEVEL_MGMT X 
											INNER JOIN TB_CM_LEVEL_MGMT Y  ON A.LV_MGMT_ID = B.ID AND Y.ACTV_YN = 'Y'
									)
				AND		A.LV_MGMT_ID IN ( SELECT ID FROM TB_CM_LEVEL_MGMT  WHERE ACTV_YN = 'Y') 
				AND		ISNULL(A.PARENT_SALES_LV_ID, '') NOT IN	(
																SELECT ID FROM TB_DP_SALES_LEVEL_MGMT 
																)
				UNION ALL 
				SELECT	'U_AUTHORITY'											AS CHECK_CD
						,'상위 Sales Level 의 승인 권한자 미지정(Virtual 제외)' AS CHECK_DESC
						,CONVERT(NVARCHAR,COUNT(A.ID))							AS CNT
				FROM	TB_DP_SALES_LEVEL_MGMT A 
						INNER JOIN TB_CM_LEVEL_MGMT B  ON A.LV_MGMT_ID = B.ID AND B.ACTV_YN = 'Y'
				WHERE	A.ACTV_YN = 'Y' AND A.VIRTUAL_YN = 'N'
				AND		A.LV_MGMT_ID IN ( SELECT ID FROM TB_CM_LEVEL_MGMT  WHERE ACTV_YN = 'Y') 
				AND		ISNULL(A.PARENT_SALES_LV_ID, '') IN	(
															SELECT ID 
															FROM TB_DP_SALES_LEVEL_MGMT 
															WHERE ACTV_YN = 'Y'
															)
				AND		NOT EXISTS	(
									SELECT 'X'
									FROM TB_DP_SALES_AUTH_MAP X 
									WHERE A.ID = X.SALES_LV_ID
									)
				) A WHERE 1=1 AND 'ALL' = @v_VALID_FLAG
		UNION ALL
		-- 전체/개인 공용 #################################################################################
		SELECT	'U_I_A_ITEM_CD'													 AS CHECK_CD
				,'User별 Item & Account 맵핑에서 Item Code가 Master에 없는 경우' AS CHECK_DESC
				,CONVERT(NVARCHAR,COUNT(A.ITEM_MST_ID))							 AS CNT
		FROM	TB_DP_USER_ITEM_ACCOUNT_MAP A 
				INNER JOIN TB_AD_USER B  ON A.EMP_ID = B.ID
		WHERE	NOT EXISTS	(
							SELECT 'X'
							FROM TB_CM_ITEM_MST X 
							WHERE A.ITEM_MST_ID = X.ID
							AND ISNULL(X.DEL_YN,'N') = 'N' AND X.DP_PLAN_YN = 'Y'
							)
		AND		A.AUTH_TP_ID LIKE '%' + @V_AUTH_TP_ID +'%'
		AND		B.USERNAME LIKE '%' + @V_OPERATOR_ID + '%'
		AND		A.ACTV_YN='Y'
		UNION ALL
		SELECT	'U_I_A_ACCOUNT_CD'													AS CHECK_CD
				,'User별 Item & Account 맵핑에서 Account Code가 Master에 없는 경우' AS CHECK_DESC
				,CONVERT(NVARCHAR,COUNT(A.ACCOUNT_ID))								AS CNT
		FROM TB_DP_USER_ITEM_ACCOUNT_MAP A 
		INNER JOIN TB_AD_USER B  ON A.EMP_ID = B.ID
		WHERE NOT EXISTS	(
								SELECT 'X'
								FROM TB_DP_ACCOUNT_MST X 
								WHERE A.ACCOUNT_ID= X.ID
								AND X.ACTV_YN = 'Y'
							)
		AND		A.AUTH_TP_ID LIKE '%' + @V_AUTH_TP_ID +'%'
		AND		B.USERNAME LIKE '%' + @V_OPERATOR_ID + '%'
		AND		A.ACTV_YN='Y'
		UNION ALL
		SELECT	'U_I_ITEM_CD'																AS CHECK_CD
				,'User별 Item 매핑에서 등록된 값이 Item Code일때 그값이 Master에 없는 경우' AS CHECK_DESC
				,CONVERT(NVARCHAR,COUNT(A.ITEM_MST_ID))										AS CNT
		FROM	TB_DP_USER_ITEM_MAP A 
				INNER JOIN TB_AD_USER B  ON A.EMP_ID = B.ID
		WHERE	A.LV_MGMT_ID IN	(
								SELECT A.ID FROM TB_CM_LEVEL_MGMT A 
								INNER JOIN  TB_CM_COMM_CONFIG B  ON A.LV_TP_ID = B.ID AND B.CONF_GRP_CD = 'DP_LV_TP' AND B.CONF_CD = 'I'
								WHERE A.ACTV_YN = 'Y' AND A.LEAF_YN = 'Y'
								)
		AND		NOT EXISTS		(
								SELECT 'X'
								FROM TB_CM_ITEM_MST X 
								WHERE A.ITEM_MST_ID = X.ID
								AND ISNULL(X.DEL_YN,'N') = 'N' AND X.DP_PLAN_YN = 'Y'
								)
		AND		A.AUTH_TP_ID LIKE '%' + @V_AUTH_TP_ID +'%'
		AND		B.USERNAME LIKE '%' + @V_OPERATOR_ID + '%'
		AND		A.ACTV_YN='Y'
		UNION ALL 
		SELECT	'U_ITEM_LV_CD'																 AS CHECK_CD
				,'User별 Item 매핑에서 등록된 값이 Item Level일때 그값이 Master에 없는 경우' AS CHECK_DESC
				,CONVERT(NVARCHAR,COUNT(A.ITEM_LV_ID))										AS CNT
		FROM	TB_DP_USER_ITEM_MAP A 
				INNER JOIN TB_AD_USER B  ON A.EMP_ID = B.ID
		WHERE	A.LV_MGMT_ID IN	(
								SELECT A.ID FROM TB_CM_LEVEL_MGMT A 
								INNER JOIN  TB_CM_COMM_CONFIG B  ON A.LV_TP_ID = B.ID AND B.CONF_GRP_CD = 'DP_LV_TP' AND B.CONF_CD = 'I'
								WHERE A.ACTV_YN = 'Y' 
								AND A.LEAF_YN = 'N'
								)
		AND		NOT EXISTS		(
								SELECT 'X'
								FROM TB_CM_ITEM_LEVEL_MGMT X 
								WHERE A.ITEM_LV_ID = X.ID
								AND X.ACTV_YN = 'Y'
								)
		AND		A.AUTH_TP_ID LIKE '%' + @V_AUTH_TP_ID +'%'
		AND		B.USERNAME LIKE '%' + @V_OPERATOR_ID + '%'
		AND		A.ACTV_YN='Y'
		UNION ALL 
		SELECT	'U_A_ACCOUNT_CD'																	AS CHECK_CD
				,'User별 Account 매핑에서 등록된 값이 Account Code 일때 그 값이 Master에 없는 경우' AS CHECK_DESC
				,CONVERT(NVARCHAR,COUNT(A.ACCOUNT_ID))												AS CNT
		FROM	TB_DP_USER_ACCOUNT_MAP A 
				INNER JOIN TB_AD_USER B  ON A.EMP_ID = B.ID
		WHERE	A.LV_MGMT_ID IN	(
								SELECT A.ID FROM TB_CM_LEVEL_MGMT A 
								INNER JOIN  TB_CM_COMM_CONFIG B  ON A.LV_TP_ID = B.ID AND B.CONF_GRP_CD = 'DP_LV_TP' AND B.CONF_CD = 'S'
								WHERE A.ACTV_YN = 'Y' AND A.LEAF_YN = 'Y' AND A.ACCOUNT_LV_YN = 'Y'
								)
		AND		NOT EXISTS		(	
								SELECT 'X'
								FROM TB_DP_ACCOUNT_MST X 
								WHERE A.ACCOUNT_ID = X.ID
								AND ISNULL(X.DEL_YN,'N') = 'N' 
								)
		AND		A.AUTH_TP_ID LIKE '%' + @V_AUTH_TP_ID +'%'
		AND		B.USERNAME LIKE '%' + @V_OPERATOR_ID + '%'
		AND		A.ACTV_YN='Y'
		UNION ALL 
		SELECT	'U_A_SALES_LV_CD'																	AS CHECK_CD
				,'User별 Account매핑에서 등록된 값이 Sales Levle 일때 그 값이 Master에 없는 경우'	AS CHECK_DESC
				,CONVERT(NVARCHAR,COUNT(A.SALES_LV_ID))												AS CNT
		FROM	TB_DP_USER_ACCOUNT_MAP A 
				INNER JOIN TB_AD_USER B  ON A.EMP_ID = B.ID
		WHERE	A.LV_MGMT_ID IN		(
									SELECT A.ID FROM TB_CM_LEVEL_MGMT A 
									INNER JOIN  TB_CM_COMM_CONFIG B  ON A.LV_TP_ID = B.ID AND B.CONF_GRP_CD = 'DP_LV_TP' AND B.CONF_CD = 'S'
									WHERE A.ACTV_YN = 'Y' AND A.LEAF_YN = 'N'  
									)
		AND		NOT EXISTS		(
								SELECT 'X'
								FROM TB_DP_SALES_LEVEL_MGMT X 
								WHERE A.SALES_LV_ID = X.ID
								AND ISNULL(X.DEL_YN,'N') = 'N' 
								)
		AND		A.AUTH_TP_ID LIKE '%' + @V_AUTH_TP_ID +'%'
		AND		B.USERNAME LIKE '%' + @V_OPERATOR_ID + '%'
		AND		A.ACTV_YN='Y'
		UNION ALL
		-- 개인 #################################################################################
		SELECT	A.CHECK_CD, A.CHECK_DESC, A.CNT
		FROM	(
				SELECT	'U_M_EXCEPTION'												AS CHECK_CD
						,'User Mapping Exception. 맵핑구조상 관리대상이 없는 경우'	AS CHECK_DESC
						,CASE WHEN COUNT(*) = 0 THEN
									 'DP 대상 없음'
								ELSE 
									'NONE'
								END													AS CNT
				FROM	(
							SELECT	DISTINCT B.USERNAME as EMP_NO, B.DISPLAY_NAME as EMP_NM, A.AUTH_TP_ID, B.USERNAME as USER_ID
							FROM	TB_DP_USER_ITEM_MAP		A 
									INNER JOIN TB_AD_USER	B  ON A.EMP_ID = B.ID AND		A.ACTV_YN='Y'

							UNION ALL
							SELECT	DISTINCT B.USERNAME as EMP_NO, B.DISPLAY_NAME as EMP_NM, A.AUTH_TP_ID, B.USERNAME as USER_ID
							FROM	TB_DP_USER_ACCOUNT_MAP		A 
									INNER JOIN TB_AD_USER	B  ON A.EMP_ID = B.ID AND		A.ACTV_YN='Y'

							UNION ALL
							SELECT	DISTINCT B.USERNAME as EMP_NO, B.DISPLAY_NAME as EMP_NM, A.AUTH_TP_ID, B.USERNAME as USER_ID
							FROM	TB_DP_USER_ITEM_ACCOUNT_MAP	A 
									INNER JOIN TB_AD_USER		B ON A.EMP_ID = B.ID AND		A.ACTV_YN='Y'
						) A
				WHERE	1=1
				AND		A.AUTH_TP_ID = @V_AUTH_TP_ID 
				AND		A.USER_ID = @V_OPERATOR_ID 
				) A
		WHERE	1=1 AND 'PSNZ' = @v_VALID_FLAG
		
		) A


END








go

