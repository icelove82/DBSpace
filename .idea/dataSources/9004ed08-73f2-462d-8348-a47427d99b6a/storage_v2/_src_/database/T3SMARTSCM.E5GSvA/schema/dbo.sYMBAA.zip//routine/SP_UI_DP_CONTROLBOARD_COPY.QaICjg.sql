/*****************************************************************************

[SP_UI_DP_CONTROLBOARD_COPY]

설명 
 - DP VERSION Copy
 
History (수정일자 / 수정자 / 수정내용)
- 2023.02.14 / kim sohee / Draft
- 2023.02.28 / kim sohee / separate data version ID and copied version ID to share process status of main version 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_CONTROLBOARD_COPY]  (
											   @p_VER_ID				CHAR(32)	    
											  ,@P_ORG_DATA_VER_ID		CHAR(32)	    
											  ,@P_COPIED_APPV_VER_ID	CHAR(32)	    
											  ,@p_VER_DESCRIP			NVARCHAR(MAX)	    
											  ,@p_USER_ID				NVARCHAR(100)      
                                              ,@P_RT_ROLLBACK_FLAG		NVARCHAR(10)	='true' OUTPUT
                                        	  ,@P_RT_MSG           	 	NVARCHAR(3000)	 OUTPUT										   
	  										   ) 
AS

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)
	   ,@V_VER_MST_ID NVARCHAR(32)= REPLACE(NEWID(),'-','')

BEGIN TRY
/*
	ALTER TABLE [TB_DP_CONTROL_BOARD_VER_MST] ADD COPIED_VER_ID CHAR(32) 
*/	

	--버전 DATA 저장
INSERT INTO [TB_DP_CONTROL_BOARD_VER_MST]
           ([ID]
           ,[VER_ID]
		   ,[MODULE_ID]
           ,[BUKT]
           ,[HORIZ]
           ,[FROM_DATE]
           ,[TO_DATE]
           ,[DTF]
           ,[DTF_DATE]
           ,[DESCRIP]
           ,[CREATE_BY]
           ,[CREATE_DTTM]
           ,[VER_S_BUCKET]
           ,[VER_S_HORIZON]
           ,[VER_S_HORIZON_DATE]
           ,[VER_S_BUCKET2]
           ,[VER_S_HORIZON2]
           ,[VER_S_HORIZON_DATE2]
		   ,[PLAN_TP_ID]
		   ,[PRICE_TP_ID]
		   ,[CURCY_TP_ID]	
		   ,COPIED_VER_ID
		   )
	SELECT @V_VER_MST_ID
		 , @P_VER_ID 
		 , [MODULE_ID]
         , [BUKT]
         , [HORIZ]
         , [FROM_DATE]
         , [TO_DATE]
         , [DTF]
         , [DTF_DATE]
         , @p_VER_DESCRIP
         , @P_USER_ID 
         , GETDATE() 
         , [VER_S_BUCKET]
         , [VER_S_HORIZON]
         , [VER_S_HORIZON_DATE]
         , [VER_S_BUCKET2]
         , [VER_S_HORIZON2]
         , [VER_S_HORIZON_DATE2]
		 , [PLAN_TP_ID]
		 , [PRICE_TP_ID]
		 , [CURCY_TP_ID]	
		 , @P_COPIED_APPV_VER_ID
	 FROM TB_DP_CONTROL_BOARD_VER_MST
	WHERE ID = @P_ORG_DATA_VER_ID

		-- DTL
		INSERT INTO TB_DP_CONTROL_BOARD_VER_DTL
		(     ID
			, CONBD_VER_MST_ID		
			, MODULE_ID				
			, WORK_CD				
			, WORK_NM				
			, SEQ					
			, DESCRIP				
			, WORK_TP_ID			
			, LINK					
			, LV_MGMT_ID			
			, INIT_VAL_TP_ID		
			, INIT_FIXED_LV_MGMT_ID	
			, INPUT_TP_ID			
			, CONST_INPUT_YN		
			, CONST_INPUT_DATE		
			, APPV_CONST_ID			
			, APPV_EVENT_ID			
			, AUTO_APPV_YN			
			, AUTO_APPV_DATE		
			, CANC_CONST_ID			
			, CANC_EVENT_ID			
			, CL_TP_ID				
			, CL_LV_MGMT_ID			
			, CL_STATUS_ID			
			, CREATE_BY				
			, CREATE_DTTM			
			, MODIFY_BY				
			, MODIFY_DTTM			
			, PLAN_TP_ID			
			, INIT_MEASURE_ID		
		) 									 
		SELECT REPLACE(NEWID(),'-','')				
			 , @V_VER_MST_ID		
			 , MODULE_ID				
			 , WORK_CD				
			 , WORK_NM				
			 , SEQ					
			 , DESCRIP				
			 , WORK_TP_ID			
			 , LINK					
			 , LV_MGMT_ID			
			 , INIT_VAL_TP_ID		
			 , INIT_FIXED_LV_MGMT_ID	
			 , INPUT_TP_ID			
			 , CONST_INPUT_YN		
			 , CONST_INPUT_DATE		
			 , APPV_CONST_ID			
			 , APPV_EVENT_ID			
			 , AUTO_APPV_YN			
			 , AUTO_APPV_DATE		
			 , CANC_CONST_ID			
			 , CANC_EVENT_ID			
			 , CL_TP_ID				
			 , CL_LV_MGMT_ID			
			 , CL_STATUS_ID			
			 , @P_USER_ID 				
			 , GETDATE() 			
			 , NULL				
			 , NULL			
			 , PLAN_TP_ID			
			 , INIT_MEASURE_ID	
		 FROM TB_DP_CONTROL_BOARD_VER_DTL 
		WHERE CONBD_VER_MST_ID = @P_ORG_DATA_VER_ID 
		 
		  ;
		  WITH VER_DTL
		  AS (
		  SELECT D.ID AS NEW_DTL_ID 
			    ,C.ID  AS DTL_ID  
		    FROM TB_DP_CONTROL_BOARD_VER_DTL D 
				 INNER JOIN 
				 TB_DP_CONTROL_BOARD_VER_MST M 
		      ON D.CONBD_VER_MST_ID = M.ID 
			 AND M.ID = @V_VER_MST_ID
				 INNER JOIN 
				 TB_DP_CONTROL_BOARD_VER_DTL C
			  ON M.COPIED_VER_ID = C.CONBD_VER_MST_ID
			 AND D.WORK_CD = C.WORK_CD 	 
		  )
		   INSERT INTO TB_DP_CONTROL_BOARD_VER_INIT					
			( ID
			 ,CONBD_VER_DTL_ID
			 ,MS_VAL_TP_CD
			 ,INIT_VAL_TP_ID
			 ,INIT_FIXED_LV_MGMT_ID	
			 ,INIT_MEASURE_ID		
			 ,CREATE_BY 
			 ,CREATE_DTTM 
			)
			SELECT REPLACE(NEWID(),'-','')
			 ,NEW_DTL_ID
			 ,MS_VAL_TP_CD
			 ,INIT_VAL_TP_ID
			 ,INIT_FIXED_LV_MGMT_ID	
			 ,INIT_MEASURE_ID				
			 , @p_USER_ID
			 , GETDATE()
			  FROM TB_DP_CONTROL_BOARD_VER_INIT I
				   INNER JOIN 
				   VER_DTL D
				ON I.CONBD_VER_DTL_ID = D.DTL_ID 
			 WHERE CONBD_VER_DTL_ID IN (SELECT ID FROM TB_DP_CONTROL_BOARD_VER_DTL WHERE CONBD_VER_MST_ID = @P_ORG_DATA_VER_ID)

			 INSERT INTO TB_DP_ENTRY 
			 (  ID
			  , VER_ID
			  , AUTH_TP_ID
			  , ACCOUNT_ID
			  , SALES_LV_ID
			  , BASE_DATE
			  , ITEM_MST_ID
			  , EMP_ID
			  , QTY
			  , AMT
			  , CREATE_BY
			  , CREATE_DTTM
			  , MODIFY_BY
			  , MODIFY_DTTM
			  , PLAN_TP_ID
			  , QTY_1
			  , AMT_1
			  , QTY_2
			  , AMT_2
			  , QTY_3
			  , AMT_3
			  , QTY_A
			  , AMT_A
			  , comment
			  , QTY_I
			  , QTY_R
			 )
			 SELECT REPLACE(NEWID(),'-','')			
				  , @V_VER_MST_ID
				  , AUTH_TP_ID
				  , ACCOUNT_ID
				  , SALES_LV_ID
				  , BASE_DATE
				  , ITEM_MST_ID
				  , EMP_ID
				  , QTY
				  , AMT
				  , @p_USER_ID
				  , GETDATE()
				  , NULL
				  , NULL
				  , PLAN_TP_ID
				  , QTY_1
				  , AMT_1
				  , QTY_2
				  , AMT_2
				  , QTY_3
				  , AMT_3
				  , QTY_A
				  , AMT_A
				  , comment
				  , QTY_I
				  , QTY_R
			   FROM TB_DP_ENTRY 
			  WHERE VER_ID = @P_ORG_DATA_VER_ID


	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;




go

