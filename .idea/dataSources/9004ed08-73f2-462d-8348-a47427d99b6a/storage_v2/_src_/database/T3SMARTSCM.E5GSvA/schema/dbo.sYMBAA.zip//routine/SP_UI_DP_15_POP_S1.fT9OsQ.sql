/*****************************************************************************
Title : SP_DP_15_POP_S1
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP User Mapping(Item&Account)
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2019.06.04 / 김소희 / Validation 용도로 정리 
- 2019.11.15 / 김소희 / User item account exclude 화면에서도 사용
*****************************************************************************/


CREATE PROCEDURE [dbo].[SP_UI_DP_15_POP_S1]  (
									  -- 저장 로직시 사용 변수 
									   @P_EMP_NO              NVARCHAR(50)  = NULL      
									  ,@P_AUTH_TP_ID          CHAR(32)      = NULL   
									  ,@p_ACCOUNT_ID          CHAR(32)      = NULL 
									  ,@p_ITEM_MST_ID         CHAR(32)      = NULL     
									  ,@P_UI_ID				  NVARCHAR(10)		= 'UI_DP_15'
									  ,@P_RT_MSG            NVARCHAR(4000) = ''		 OUTPUT
									  
									  --,@P_OUTPUT_MSG          NVARCHAR(4000) OUTPUT    
				                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
BEGIN 
    SET @P_RT_MSG = 'MSG_0003'  --완료 되었습니다.


IF (@P_EMP_NO IS NULL OR @P_EMP_NO = '')
	BEGIN
	   SET @P_RT_MSG = 'MSG_0014' 
 		
	END
IF (@P_AUTH_TP_ID IS NULL OR @P_AUTH_TP_ID = '')
	BEGIN
	   SET @P_RT_MSG = 'Authority Type is necessary' 
 		
	END
IF (@p_ACCOUNT_ID IS NULL OR @p_ACCOUNT_ID = '')
	BEGIN
	   SET @P_RT_MSG = 'MSG_0015' 
 	END
IF (@p_ITEM_MST_ID IS NULL OR @p_ITEM_MST_ID = '')
	BEGIN
	   SET @P_RT_MSG = 'MSG_0017' 
 	END

-- Account + Item 의 1개의 값은 1명의 User만 담당할 수 있다. 중복된 데이터가 있는 경우 msg
IF EXISTS(SELECT 1 
	        FROM TB_DP_USER_ITEM_ACCOUNT_MAP UI 
		   WHERE UI.ACCOUNT_ID = @P_ACCOUNT_ID 
		     AND UI.ITEM_MST_ID = @P_ITEM_MST_ID 
			 AND UI.AUTH_TP_ID = @P_AUTH_TP_ID 	
		  ) AND @p_UI_ID like 'UI_DP_15%'
	BEGIN
		   SET @P_RT_MSG = 'MSG_0013' 
 
	END
ELSE IF EXISTS(SELECT 1 
	        FROM TB_DP_USER_ITEM_ACCOUNT_EXCLUD UI 
		   WHERE UI.ACCOUNT_ID = @P_ACCOUNT_ID 
		     AND UI.ITEM_MST_ID = @P_ITEM_MST_ID 
			 AND UI.AUTH_TP_ID = @P_AUTH_TP_ID 	
		  ) AND @p_UI_ID like 'UI_DP_37%'
	BEGIN
		   SET @P_RT_MSG = 'MSG_0013' 
 
	END	
	           
	
 
END 

go

