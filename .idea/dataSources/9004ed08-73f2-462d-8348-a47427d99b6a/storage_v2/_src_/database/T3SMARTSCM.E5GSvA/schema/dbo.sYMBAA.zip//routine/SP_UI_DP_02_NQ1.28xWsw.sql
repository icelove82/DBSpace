/*****************************************************************************
Title : SP_DP_02_NQ1
 
설명 
 - DP Level Management
 
History (수정일자 / 수정자 / 수정내용)
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_02_NQ1] ( @LV_TP NVARCHAR(30) = ''
								   ) AS 

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN


/****** SSMS의 SelectTopNRows 명령 스크립트 ******/
	SELECT LM.ID
		  ,LM.LV_TP_ID 
		  --,B.CONF_CD   AS  LV_TP
		  --,B.CONF_NM   AS  LV_NM
		  ,LM.LV_CD
		  ,LM.LV_NM
		  ,LM.SEQ
		  ,LM.LV_LEAF_YN
		  ,LM.SALES_LV_YN
		  ,LM.ACCOUNT_LV_YN
		  ,LM.SRP_LV_YN
		  ,LM.LEAF_YN
		  ,LM.ACTV_YN
		  ,LM.DEL_YN
		  ,LM.CREATE_BY
		  ,LM.CREATE_DTTM
		  ,LM.MODIFY_BY
		  ,LM.MODIFY_DTTM
      FROM TB_CM_CONFIGURATION A
		 , TB_CM_COMM_CONFIG B
         , TB_CM_LEVEL_MGMT LM
	 where A.ID = B.CONF_ID
	   AND B.CONF_GRP_CD =  'DP_LV_TP'
	   AND B.CONF_CD  LIKE LTRIM(RTRIM(@LV_TP)) +'%'	
	   AND B.ACTV_YN = 'Y'
	   AND LM.ACTV_YN = 'Y'
	   AND LM.DEL_YN = 'N'
	   AND B.ID = LM.LV_TP_ID
    ORDER BY B.PRIORT ASC, LM.SEQ ASC
 ;

   
END
 





go

