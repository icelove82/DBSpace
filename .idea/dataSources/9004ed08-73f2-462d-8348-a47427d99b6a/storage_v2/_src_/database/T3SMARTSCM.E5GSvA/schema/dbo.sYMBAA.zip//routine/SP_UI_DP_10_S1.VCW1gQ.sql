/*****************************************************************************
Title : SP_DP_10_S1
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP Sales Hierarchy Management
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
 	- 2020.11.10 / Kim sohee / data type of CODE NVARCHAR(100)
*****************************************************************************/


CREATE PROCEDURE [dbo].[SP_UI_DP_10_S1]  (
                                       @p_ID                    NVARCHAR(32)     = NULL         
									  ,@p_SALES_LV_CD           NVARCHAR(100)     = NULL         
									  ,@p_SALES_LV_NM		    NVARCHAR(240)    = NULL         
									  ,@p_LV_MGMT_ID            NVARCHAR(32)     = NULL      
									  ,@p_PARENT_SALES_LV_ID    NVARCHAR(32)     = NULL   
									  ,@p_SEQ				    INT			     = NULL 
									  ,@p_VIRTUAL_YN			CHAR(1)          = NULL          
									  ,@p_CURCY_CD_ID	        NVARCHAR(32)     = NULL 
									  ,@p_SRP_YN				CHAR(1)			 = NULL
									  ,@p_ACTV_YN 			    CHAR(1)          = NULL          
									  ,@p_DEL_YN 			    CHAR(1)          = NULL          
									  ,@p_USER_ID               NVARCHAR(50)           
								      ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'  OUTPUT
								      ,@P_RT_MSG            NVARCHAR(4000) = ''		 OUTPUT
				                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
	   ,@P_ERR_STATUS_02 INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''

	   ,@V_ID					NVARCHAR(32)     = NULL
	   ,@V_SALES_LV_CD       	NVARCHAR(100)     = NULL
	   ,@V_SALES_LV_NM			NVARCHAR(240)    = NULL
	   ,@V_LV_MGMT_ID        	NVARCHAR(32)     = NULL
	   ,@V_PARENT_SALES_LV_ID	NVARCHAR(32)     = NULL
	   ,@V_SEQ					INT			     = NULL
	   ,@V_VIRTUAL_YN			CHAR(1)          = NULL
	   ,@V_CURCY_CD_ID	    	NVARCHAR(32)     = NULL
	   ,@V_SRP_YN				CHAR(1)			 = NULL
	   ,@V_ACTV_YN 				CHAR(1)          = NULL
	   ,@V_DEL_YN 				CHAR(1)          = NULL
	   ,@V_USER_ID           	NVARCHAR(50)           

	   SET @V_ID					= @p_ID                
	   SET @V_SALES_LV_CD       	= @p_SALES_LV_CD       
	   SET @V_SALES_LV_NM			= @p_SALES_LV_NM		
	   SET @V_LV_MGMT_ID        	= @p_LV_MGMT_ID        
	   SET @V_PARENT_SALES_LV_ID	= @p_PARENT_SALES_LV_ID
	   SET @V_SEQ					= @p_SEQ				
	   SET @V_VIRTUAL_YN			= @p_VIRTUAL_YN		
	   SET @V_CURCY_CD_ID	    	= @p_CURCY_CD_ID	    
	   SET @V_SRP_YN				= @p_SRP_YN			
	   SET @V_ACTV_YN 				= @p_ACTV_YN 			
	   SET @V_DEL_YN 				= @p_DEL_YN 			
	   SET @V_USER_ID           	= @p_USER_ID           
/*****************************************************************************************************************************************************************************************/
BEGIN TRY
IF(@V_SALES_LV_CD IS NULL OR @V_SALES_LV_CD = '')
	BEGIN
		   SET @P_ERR_MSG = 'MSG_5034' 
		   RAISERROR (@P_ERR_MSG,12, 1);
	END
IF(@V_LV_MGMT_ID IS NULL OR @V_LV_MGMT_ID = '')
	BEGIN
		   SET @P_ERR_MSG = 'MSG_5035' 
		   RAISERROR (@P_ERR_MSG,12, 1);
	END
IF EXISTS(SELECT *
            FROM TB_DP_SALES_LEVEL_MGMT
            WHERE 1=1
             AND SALES_LV_CD = @V_SALES_LV_CD
             AND ID != @V_ID)
			 BEGIN
  		     SET @P_ERR_MSG = 'MSG_0013' 
  		     RAISERROR (@P_ERR_MSG,12, 1);
			 END
IF(@V_PARENT_SALES_LV_ID = @V_ID)
BEGIN
		SET @P_ERR_MSG = 'MSG_5040' 
  		RAISERROR (@P_ERR_MSG,12, 1);
END	


       SELECT @P_ERR_STATUS = SEQ  
         FROM TB_CM_LEVEL_MGMT 
        WHERE 1=1
          AND ID = @V_LV_MGMT_ID
		  ;
   SELECT @P_ERR_STATUS_02 = MIN(SEQ) 
     FROM TB_CM_LEVEL_MGMT
    WHERE 1=1
      AND ACTV_YN = 'Y'
      AND ISNULL(DEL_YN,'N') = 'N'
      AND SALES_LV_YN = 'Y'
--      AND ACCOUNT_LV_YN = 'N'
	  ;
/* 가장 최상위의 ITEM LEVEL이면 상위품목레벨코드 = NULL */
IF (@P_ERR_STATUS = @P_ERR_STATUS_02 AND ISNULL(@V_PARENT_SALES_LV_ID, '') != '')
    BEGIN
	   SET @P_ERR_MSG = 'MSG_5154' 
	   RAISERROR (@P_ERR_MSG,12, 1);

	 


	END
/* 가장 최상위의 ITEM LEVEL이 아니면 상위품목레벨코드 != NULL */
IF (@P_ERR_STATUS != @P_ERR_STATUS_02 AND ISNULL(@V_PARENT_SALES_LV_ID,'') ='')
    BEGIN
	   SET @P_ERR_MSG = 'MSG_5051' 
	   RAISERROR (@P_ERR_MSG,12, 1);
	END

IF(LTRIM(RTRIM(@V_SALES_LV_CD)) = '')		 SET @V_SALES_LV_CD = NULL
IF(LTRIM(RTRIM(@V_SALES_LV_NM)) = '')		 SET @V_SALES_LV_NM = NULL
IF(LTRIM(RTRIM(@V_LV_MGMT_ID)) = '')		 SET @V_LV_MGMT_ID = NULL
IF(LTRIM(RTRIM(@V_PARENT_SALES_LV_ID)) = '') SET @V_PARENT_SALES_LV_ID = NULL
IF(LTRIM(RTRIM(@V_CURCY_CD_ID)) = '')		 SET @V_CURCY_CD_ID = NULL


	  -- 프로시저 시작 
	  
	  
				MERGE TB_DP_SALES_LEVEL_MGMT TGT
				USING ( 
						SELECT    @V_ID                   AS ID                
								, @V_SALES_LV_CD          AS SALES_LV_CD       
								, @V_SALES_LV_NM		  AS SALES_LV_NM		
								, @V_LV_MGMT_ID           AS LV_MGMT_ID        
								, @V_PARENT_SALES_LV_ID   AS PARENT_SALES_LV_ID
								, @V_SEQ  				  AS SEQ 
								, @V_VIRTUAL_YN			  AS VIRTUAL_YN		
								, @V_CURCY_CD_ID	      AS CURCY_CD_ID
								, ISNULL(@V_SRP_YN,'N')	  AS SRP_YN	    
								, ISNULL(@V_ACTV_YN,'N')  AS ACTV_YN 
								, ISNULL(@V_DEL_YN,'N')   AS DEL_YN			
							    , @V_USER_ID              AS USER_ID						
					  ) SRC
				ON     TGT.ID = SRC.ID
				WHEN MATCHED THEN
					 UPDATE 
					   SET   TGT.SALES_LV_CD            = SRC.SALES_LV_CD              
							,TGT.SALES_LV_NM		    = SRC.SALES_LV_NM		
							,TGT.LV_MGMT_ID             = SRC.LV_MGMT_ID        
							,TGT.PARENT_SALES_LV_ID     = SRC.PARENT_SALES_LV_ID
							,TGT.SEQ                    = SRC.SEQ 
							,TGT.VIRTUAL_YN		        = SRC.VIRTUAL_YN		
							,TGT.CURCY_CD_ID	        = SRC.CURCY_CD_ID	    
							,TGT.SRP_YN					= SRC.SRP_YN		
							,TGT.ACTV_YN 			    = SRC.ACTV_YN 			
							,TGT.DEL_YN 			    = SRC.DEL_YN 	
							,TGT.MODIFY_BY              = SRC.USER_ID       
							,TGT.MODIFY_DTTM            = GETDATE()       
				WHEN NOT MATCHED THEN 
					 INSERT (
					            ID                
							  , SALES_LV_CD       
							  , SALES_LV_NM		
							  , LV_MGMT_ID        
							  , PARENT_SALES_LV_ID
							  , SEQ 
							  , VIRTUAL_YN		
							  , CURCY_CD_ID	    
							  , SRP_YN
							  , ACTV_YN
							  , DEL_YN 			
							  , CREATE_BY
							  , CREATE_DTTM
							) 
					 VALUES (
					            ID --(SELECT REPLACE(NEWID(),'-','') )
							  , SALES_LV_CD       
							  , SALES_LV_NM		
							  , LV_MGMT_ID        
							  , PARENT_SALES_LV_ID
							  , SEQ 
							  , VIRTUAL_YN		
							  , CURCY_CD_ID	  
							  , SRP_YN  
							  , ACTV_YN 
							  , 'N'			
							  , SRC.USER_ID 
							  , GETDATE()            
 							) 
							;    	
							

     
							
	  -- 프로시저 종료 

		              
	   SET @P_RT_ROLLBACK_FLAG = 'true'

	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.
END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;

go

