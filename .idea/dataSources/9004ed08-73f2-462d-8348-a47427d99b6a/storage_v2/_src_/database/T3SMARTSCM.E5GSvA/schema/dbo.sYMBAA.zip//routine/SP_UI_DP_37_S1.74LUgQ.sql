/*****************************************************************************
Title : SP_UI_DP_37_S1
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - 
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2020.03.12 / 김소희 / EMP_NO => USER_ID 
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER
- 2020.11.10 / Kim sohee / data type of ITEM_CD NVARCHAR(100)
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_37_S1]  (
									   @p_ID                  NVARCHAR(32)      = ''      
									  ,@p_EMP_NO			  NVARCHAR(25)      = ''      
									  ,@p_AUTH_TP_ID          NVARCHAR(32)      = ''      
                                      ,@p_ACCOUNT_ID          NVARCHAR(32)      = ''         
                                      ,@p_ACCOUNT_CD			  NVARCHAR(100)      = ''         
                                      ,@p_ITEM_MST_ID         NVARCHAR(32)      = ''         
                                      ,@p_ITEM_CD			  NVARCHAR(100)      = ''         
									  ,@p_USER_ID             NVARCHAR(50)      = ''  
									  ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'  OUTPUT
									  ,@P_RT_MSG            NVARCHAR(4000) = ''		 OUTPUT
									  --,@P_OUTPUT_MSG          NVARCHAR(4000) OUTPUT    
				                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE   @V_ERR_TYPE                 NVARCHAR(32)      = NULL    
		, @P_EMP_ID                   NVARCHAR(32)      = NULL    
DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''
BEGIN TRY

-- EMPLOYEE 가 선택되지 않은 경우
IF (@p_EMP_NO IS NULL OR @p_EMP_NO = '' OR NOT EXISTS(SELECT USERNAME FROM TB_AD_USER WHERE USERNAME = @p_EMP_NO))
	BEGIN
	   SET @P_ERR_MSG = 'MSG_0014' 
	   RAISERROR (@P_ERR_MSG,12, 1);	
	END
IF(@p_ACCOUNT_ID IS NULL)
BEGIN
	SELECT @P_ACCOUNT_ID = ID FROM TB_DP_ACCOUNT_MST WHERE ACCOUNT_CD = @p_ACCOUNT_CD
END
IF(@P_ITEM_MST_ID IS NULL)
BEGIN
	SELECT @P_ITEM_MST_ID = ID FROM TB_cM_ITEM_MST WHERE ITEM_CD = @p_ITEM_CD
END
-- Account + Item 의 1개의 값은 1명의 User만 담당할 수 있다. 중복된 데이터가 있는 경우 msg
IF EXISTS(SELECT 1 
	        FROM TB_DP_USER_ITEM_ACCOUNT_MAP UI 
		   WHERE UI.ACCOUNT_ID = @p_ACCOUNT_ID 
		    AND UI.ITEM_MST_ID = @p_ITEM_MST_ID
			AND UI.AUTH_TP_ID = @p_AUTH_TP_ID 
			AND ID != @P_ID) 
BEGIN
	   SET @P_ERR_MSG = 'MSG_0013' 
	   RAISERROR (@P_ERR_MSG,12, 1);
END
-- Account 체크
IF (@p_ACCOUNT_ID IS NULL OR @p_ACCOUNT_ID = '')
BEGIN
	   SET @P_ERR_MSG = 'MSG_0015' 
	   RAISERROR (@P_ERR_MSG,12, 1);	
END
-- item 체크
IF (@p_ITEM_MST_ID IS NULL OR @p_ITEM_MST_ID = '')
BEGIN
	   SET @P_ERR_MSG = 'MSG_0017' 
	   RAISERROR (@P_ERR_MSG,12, 1);	
END

      -- 프로시저 시작 


	   BEGIN 



                -- EMP_ID Setting 
 				SELECT @P_EMP_ID = ID 
				  FROM TB_AD_USER
				WHERE USERNAME = @P_EMP_NO
				;

				MERGE TB_DP_USER_ITEM_ACCOUNT_EXCLUD  TGT   
				USING ( 
						SELECT  @p_ID             AS ID 
						       ,@p_AUTH_TP_ID     AS  AUTH_TP_ID
							   ,@p_ACCOUNT_ID     AS  ACCOUNT_ID
							   ,@p_ITEM_MST_ID    AS  ITEM_MST_ID
							   ,@p_EMP_ID   AS  EMP_ID
							   ,@p_USER_ID   AS  USER_ID
					  ) SRC
				ON      TGT.ID = SRC.ID
				WHEN MATCHED THEN
					 UPDATE 
					   SET   TGT.MODIFY_BY   = SRC.USER_ID
					        ,TGT.ACCOUNT_ID  = SRC.ACCOUNT_ID
							,TGT.ITEM_MST_ID = SRC.ITEM_MST_ID 
							,TGT.MODIFY_DTTM = GETDATE()       
				WHEN NOT MATCHED THEN 
					 INSERT (
					            ID 
							  , AUTH_TP_ID
							  , ACCOUNT_ID
							  , ITEM_MST_ID
							  , EMP_ID
							  , CREATE_BY
							  , CREATE_DTTM
							) 
					 VALUES (
					            REPLACE(NEWID(),'-','') --(SELECT REPLACE(NEWID(),'-','') )
							  , SRC.AUTH_TP_ID
							  , SRC.ACCOUNT_ID
							  , SRC.ITEM_MST_ID
							  , SRC.EMP_ID
							  , SRC.USER_ID 
							  , GETDATE()            
 							) 
							;    	

	   END 



	           
      

	   SET @P_RT_ROLLBACK_FLAG = 'true'

	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;

go

