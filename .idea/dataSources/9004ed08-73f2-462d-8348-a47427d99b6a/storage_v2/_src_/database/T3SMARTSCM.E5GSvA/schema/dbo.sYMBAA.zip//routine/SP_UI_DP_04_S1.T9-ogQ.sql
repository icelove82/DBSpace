/*****************************************************************************
Title : SP_DP_04_S1
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP Customer
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2018.03.08 / 김소희 / TB_CM_CUSTOMER로 테이블 변경에 따라 프로시저 변경 및 Validation 작업
 	- 2020.11.10 / Kim sohee / data type of CODE NVARCHAR(100)
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_04_S1]  (
									   @P_ID				   NVARCHAR(32)      = NULL
                                      ,@p_CUST_CD              NVARCHAR(100)      = NULL         
									  ,@p_CUST_NM              NVARCHAR(240)     = NULL         
									  ,@p_COUNTRY_CD           NVARCHAR(32)      = NULL      
									  ,@p_ADDR                 NVARCHAR(1000)    = NULL   -- cast(@p_SEQ AS int)   AS  SEQ
									  ,@p_USER_ID              NVARCHAR(100)         
									  ,@P_RT_ROLLBACK_FLAG     NVARCHAR(10)   = 'true'  OUTPUT
									  ,@P_RT_MSG               NVARCHAR(4000) = ''		OUTPUT									    
					                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''
	   ,@P_COUNTRY_ID NVARCHAR(32)

	   ,@V_ID		  NVARCHAR(32) = NULL
	   ,@V_CUST_CD    NVARCHAR(100) = NULL
	   ,@V_CUST_NM    NVARCHAR(240) = NULL
	   ,@V_COUNTRY_CD NVARCHAR(32) = NULL
	   ,@V_ADDR       NVARCHAR(1000) = NULL
	   ,@V_USER_ID    NVARCHAR(100) 

SET @V_ID			= @P_ID		
SET @V_CUST_CD   	= @P_CUST_CD   
SET @V_CUST_NM   	= @P_CUST_NM   
SET @V_COUNTRY_CD	= @P_COUNTRY_CD
SET @V_ADDR      	= @P_ADDR      
SET @V_USER_ID   	= @P_USER_ID   

BEGIN TRY

/**** 빈 값 VALIDATION *********************************************************************************************************************************************************************/
IF( ISNULL(@V_CUST_CD	 ,'')	= ''
AND ISNULL(@V_CUST_NM    ,'')	= ''
AND ISNULL(@V_COUNTRY_CD ,'')	= ''
AND ISNULL(@V_ADDR       ,'')	= '')
BEGIN
   SET @P_ERR_MSG = 'MSG_0006' 
   RAISERROR (@P_ERR_MSG,12, 1);  
END

IF(ISNULL(@V_CUST_CD, '') = '')
BEGIN
   SET @P_ERR_MSG = 'MSG_5027' 
   RAISERROR (@P_ERR_MSG,12, 1);   	
END

/*** CUSTOMER CODE 중복 검사 *****************************************************************************************************************************************************************/
--SELECT @P_ERR_STATUS = COUNT(*) FROM TB_CM_CUSTOMER WHERE ID = @V_ID
--IF(@P_ERR_STATUS=0)
--	BEGIN
		SELECT @P_ERR_STATUS = COUNT(CUST_CD)
		FROM TB_CM_CUSTOMER
		WHERE 1=1
		AND CUST_CD = @V_CUST_CD
		AND ID!=@V_ID;

		IF(@P_ERR_STATUS >=1)
			BEGIN
				SET @P_ERR_MSG = 'MSG_5028' 
				RAISERROR (@P_ERR_MSG,12, 1);   	
			END
--	END
/*** COUNTRY CODE TO ID *****************************************************************************************************************************************************************/
IF(ISNULL(@V_COUNTRY_CD, '') != '')
	BEGIN
		  SELECT @P_COUNTRY_ID = A.ID
			FROM TB_CM_COMM_CONFIG A
			WHERE 1=1
		      AND conf_grp_cd = 'CM_COUNTRY'
		      AND A.CONF_CD = @V_COUNTRY_CD

	END
ELSE
	SET @P_COUNTRY_ID = NULL

	  -- 프로시저 시작 

				MERGE TB_CM_CUSTOMER TGT
				USING ( 
						SELECT
						 @V_CUST_CD          AS CUST_CD    
						,@V_CUST_NM     	 AS CUST_NM    
						,@P_COUNTRY_ID  	 AS COUNTRY_ID
						,@V_ADDR        	 AS ADDR       
						,@V_USER_ID     	 AS USER_ID    
					  ) SRC
				ON     TGT.CUST_CD = SRC.CUST_CD
				WHEN MATCHED THEN
					 UPDATE 
					   SET   TGT.CUST_NM      = SRC.CUST_NM   
							,TGT.COUNTRY_ID   = SRC.COUNTRY_ID
							,TGT.ADDR         = SRC.ADDR       
							,TGT.MODIFY_BY    = SRC.USER_ID       
							,TGT.MODIFY_DTTM  = GETDATE()       
				WHEN NOT MATCHED THEN 
					 INSERT ( ID
					        , CUST_CD    
							, CUST_NM    
							, COUNTRY_ID 
							, ADDR       
							, CREATE_BY
							, CREATE_DTTM
							) 
					 VALUES (
							  REPLACE(NEWID(),'-','')
					        , SRC.CUST_CD    
							, SRC.CUST_NM    
							, SRC.COUNTRY_ID
							, SRC.ADDR       
							, SRC.USER_ID 
							, GETDATE()            
 							) 
							;    	
	


	   SET @P_RT_ROLLBACK_FLAG = 'true'

	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY

BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;

go

