CREATE PROCEDURE [dbo].[SP_UI_IM_08_Q3] (
	@P_LOCAT_CD	NVARCHAR(100) = ''
)
AS
/*****************************************************************************
 * System Name : T3Enterprise IM
 * Business Name : SABC Analysis
 * Program Name(ID) :SP_UI_IM_08_Q3
 * Program Description : Search for the SABC grade
 *
 * Create Date : HYS
 * Author : 2017/07/24
 *
 * Modifier    Modified Date    Revision History
 * --------    -------------    ----------------------------------------------
 * RSK         2019/03/12       Ref. Config. Inventory Grade Mgmt. Base 
 *                              Added Comments
 *
 *****************************************************************************/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

SELECT 
	 D.ID
	,D.INV_CLSS_TP	AS SABC_VAL
	,D.SVC_LV		AS PRPSAL_SVC_LV
FROM 
	TB_IM_SABC_CAL_BASE A
	INNER JOIN TB_CM_LOC_DTL B ON A.LOCAT_ID=B.ID
	INNER JOIN TB_AD_COMN_CODE C ON A.SABC_CAL_BASE_ID=C.ID
	INNER JOIN TB_IM_STOCK_CLASS_MGMT D ON A.LOCAT_ID=D.LOCAT_ID 
										AND C.COMN_CD=D.CATAGY_VAL
WHERE 
	B.LOCAT_CD=@P_LOCAT_CD
	AND D.ACTV_YN='Y'
	ORDER BY D.SVC_LV DESC;
	
END

go

