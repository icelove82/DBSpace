CREATE PROCEDURE [dbo].[SP_UI_IM_26_Q4] (
	@P_LOCAT_CD		NVARCHAR(100) = ''
   ,@P_USER_ID		NVARCHAR(100) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN
	SELECT
         E.ID
        ,E.CALENDAR_ID
        ,E.DESCRIP
        ,E.INV_MGMT_SYSTEM_TP_ID    AS INV_MGMT_SYSTEM_TP
        ,F.COMN_CD_NM               AS INV_MGMT_SYSTEM_TP_NM
        ,E.OPERT_BASE_TP_ID         AS OPERT_BASE_TP
        ,I.COMN_CD_NM               AS OPERT_BASE_TP_NM
        ,E.PO_CYCL_TP_ID            AS PO_CYCL_TP
        ,G.COMN_CD                  AS PO_CYCL_TP_CD
        ,G.COMN_CD_NM               AS PO_CYCL_TP_NM
        FROM TB_AD_COMN_CODE A
            INNER JOIN
            TB_CM_LOC_MST B
        ON (A.ID = B.LOCAT_TP_ID)
            INNER JOIN
            TB_CM_LOC_DTL C
        ON (B.ID = C.LOCAT_MST_ID)
            INNER JOIN
            TB_CM_LOC_MGMT D
        ON (C.ID = D.LOCAT_ID)
            INNER JOIN
            TB_IM_PO_CALENDAR E
        ON (D.ID = E.LOCAT_MGMT_ID)
            LEFT OUTER JOIN
            TB_AD_COMN_CODE F
        ON (E.INV_MGMT_SYSTEM_TP_ID = F.ID)
            LEFT OUTER JOIN
            TB_AD_COMN_CODE G
        ON (E.PO_CYCL_TP_ID = G.ID)
            LEFT OUTER JOIN
            TB_AD_COMN_CODE I
        ON (E.OPERT_BASE_TP_ID = I.ID)
    WHERE
        1 = 1
        AND C.LOCAT_CD LIKE '%'+@P_LOCAT_CD+'%'
    ORDER BY E.CALENDAR_ID;
END

go

