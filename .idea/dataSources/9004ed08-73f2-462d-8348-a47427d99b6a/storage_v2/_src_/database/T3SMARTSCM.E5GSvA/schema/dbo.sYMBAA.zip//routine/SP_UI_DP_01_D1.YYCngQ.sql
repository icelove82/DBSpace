/*****************************************************************************
Title : SP_DP_01_S1
최초 작성자 : 민희영
최초 생성일 : 2017.06.20
 
설명 
 - DP Configuration
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 민희영 / 최초 작성
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_01_D1]  (
									   @p_ID				NVARCHAR(32)
									  ,@P_USER_ID			NVARCHAR(100)
									  ,@P_GRP_CONF_NM		NVARCHAR(50)
									  ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'  OUTPUT
									  ,@P_RT_MSG            NVARCHAR(4000) = ''		 OUTPUT									  									
									   )
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE 
		 @P_ERR_STATUS INT = 0
        ,@P_ERR_MSG NVARCHAR(4000)=''

		,@V_ID			NVARCHAR(32)
		,@V_USER_ID		NVARCHAR(100)
		,@V_GRP_CONF_NM NVARCHAR(50)
		;

SET @V_ID			= @p_ID
SET @V_USER_ID		= @P_USER_ID
SET @V_GRP_CONF_NM	= @P_GRP_CONF_NM

BEGIN TRY


	  -- 프로시저 시작 
		DECLARE @v_CONF_GRP_CD NVARCHAR(50)
		SELECT @v_CONF_GRP_CD = CONF_NM
		FROM TB_CM_CONFIGURATION
		WHERE ID = @V_ID
		;
		-- LANG_PACK 데이터 삭제
        DELETE 
        FROM TB_AD_LANG_PACK 
        WHERE 1=1
          AND LANG_CD = 'en'
          AND LANG_KEY = UPPER(@v_CONF_GRP_CD)+'_DESCRIP'
          ;
		DELETE
		FROM TB_AD_LANG_PACK
		WHERE 1=1
		AND LANG_CD = 'en'
		AND LANG_KEY LIKE 'CF_'+@v_CONF_GRP_CD+'%'

	   -- CONFIGURATION ROW 삭제
		DELETE 
		FROM TB_CM_CONFIGURATION
		WHERE ID = @V_ID
		-- 하위 값들 삭제		
		DELETE
		FROM TB_CM_COMM_CONFIG
		WHERE CONF_ID = @V_ID


	  -- 프로시저 종료 

		              
	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0002'  --저장 되었습니다.

END TRY

BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;



go

