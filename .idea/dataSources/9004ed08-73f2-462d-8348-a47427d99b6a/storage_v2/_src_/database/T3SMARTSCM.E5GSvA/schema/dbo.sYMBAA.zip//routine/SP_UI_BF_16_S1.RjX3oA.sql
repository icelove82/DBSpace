
CREATE PROCEDURE [dbo].[SP_UI_BF_16_S1] 
(
		 @P_BF_VER				NVARCHAR(30)
		,@P_ENGINE_TP_CD		NVARCHAR(30)				
		,@P_DESCRIP				NVARCHAR(200)
		,@P_SEQ					INT
		,@P_INPUT_HORIZ			NVARCHAR(100)
		,@P_INPUT_BUKT_CD		NVARCHAR(30)
		,@P_TARGET_HORIZ		NVARCHAR(100)
		,@P_TARGET_BUKT_CD		NVARCHAR(30)
		,@P_SALES_LV_CD			NVARCHAR(100)
		,@P_ITEM_LV_CD			NVARCHAR(100)
		,@P_RULE_01		NVARCHAR(30)
		,@P_INPUT_FROM_DATE		DATETIME
		,@P_INPUT_TO_DATE		DATETIME
		,@P_TARGET_FROM_DATE	DATETIME
		,@P_TARGET_TO_DATE		DATETIME
		,@P_VAL_TP				NVARCHAR(100)
		,@P_ATTR_01				NVARCHAR(100)
		,@P_ATTR_02				NVARCHAR(100)
		,@P_ATTR_03				NVARCHAR(100)
		,@P_ATTR_04				NVARCHAR(100)
		,@P_ATTR_05				NVARCHAR(100)
		,@P_ATTR_06				NVARCHAR(100)
		,@P_ATTR_07				NVARCHAR(100)
		,@P_ATTR_08				NVARCHAR(100)
		,@P_ATTR_09				NVARCHAR(100)
		,@P_ATTR_10				NVARCHAR(100)
		,@P_USER_ID				NVARCHAR(100)
		,@P_RT_ROLLBACK_FLAG		NVARCHAR(10)   = 'true'     OUTPUT
		,@P_RT_MSG				NVARCHAR(4000) = ''				OUTPUT		
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	DECLARE @P_ERR_STATUS INT = 0
		   ,@P_ERR_MSG NVARCHAR(4000)=''
	DECLARE @P_READY_CD			NVARCHAR(30) = 'Ready'
		   ,@P_COMP_CD			NVARCHAR(30) = 'Completed'
BEGIN TRY
IF NOT EXISTS (
				SELECT LV_CD
				  FROM TB_CM_LEVEL_MGMT
				WHERE 1=1
				  AND ACTV_YN = 'Y'
				  AND ISNULL(DEL_YN,'N') = 'N'
				  AND ACCOUNT_LV_YN = 'Y'
				  AND LV_CD = @P_SALES_LV_CD
			  )
			BEGIN
					SET @P_ERR_MSG = 'Sales Level Code is not valid'
					RAISERROR (@P_ERR_MSG,12, 1);
			END
IF NOT EXISTS (
				SELECT LV_CD
				  FROM TB_CM_LEVEL_MGMT
				WHERE ACTV_YN = 'Y'
				  AND ISNULL(DEL_YN,'N') = 'N'
				  AND ACCOUNT_LV_YN = 'N'
				  AND SALES_LV_YN = 'N'
				  AND LV_CD = @P_ITEM_LV_CD
			  )
			BEGIN
					SET @P_ERR_MSG = 'Item Level Code is not valid'
					RAISERROR (@P_ERR_MSG,12, 1);
			END
IF(@P_seq				IS NULL) BEGIN	SET @P_ERR_MSG = 'Sequence is empty'		 RAISERROR (@P_ERR_MSG,12, 1); END
IF(@P_INPUT_HORIZ		IS NULL) BEGIN	SET @P_ERR_MSG = 'Input Horizon is empty'		 RAISERROR (@P_ERR_MSG,12, 1); END
IF(@P_INPUT_BUKT_CD		IS NULL) BEGIN	SET @P_ERR_MSG = 'Input Bucket is empty'		 RAISERROR (@P_ERR_MSG,12, 1); END
IF(@P_TARGET_HORIZ		IS NULL) BEGIN	SET @P_ERR_MSG = 'Target Horizon is empty'		 RAISERROR (@P_ERR_MSG,12, 1); END
IF(@P_TARGET_BUKT_CD	IS NULL) BEGIN	SET @P_ERR_MSG = 'Target Bucket is empty'		 RAISERROR (@P_ERR_MSG,12, 1); END
--IF(@P_RULE_01	IS NULL) BEGIN	SET @P_ERR_MSG = 'Disaggregate Rule is empty' RAISERROR (@P_ERR_MSG,12, 1); 		END

/****************************************************************************************
	-- 1. Version Create & Close status 생성
*****************************************************************************************/
	IF NOT EXISTS ( SELECT *
					  FROM TB_BF_CONTROL_BOARD_VER_DTL
					WHERE VER_CD = @P_BF_VER
				  )
	BEGIN
		WITH M
		AS (
			SELECT 'Version Create' AS [PROCESS]
				,   @P_COMP_CD		AS STAT
				,   1				AS PROCESS_NO
				,   GETDATE()		AS RUN_DT
				,   NULL			AS RULE_01
				,   NULL			AS TARGET_BUKT_CD
			UNION
			SELECT 'Close'			AS [PROCESS]
				,   @P_READY_CD		AS STAT
				,   1000000		    AS PROCESS_NO
				,   NULL			AS RUN_DT
				,   NULL			AS RULE_01
			    , (SELECT POLICY_VAL
				     FROM TB_DP_PLAN_POLICY 
				    WHERE PLAN_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND DEFAT_VAL = 'Y' AND ACTV_YN = 'Y')		
				      AND POLICY_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_POLICY' AND CONF_CD = 'B' AND ACTV_YN = 'Y')		
				   )				AS TARGET_BUKT_CD
		    UNION
			SELECT 'Select Best Value' AS [PROCESS]
				,  	@P_READY_CD		AS STAT
				,   990000				AS PROCESS_NO
				,   NULL			AS RUN_DT 
				,   (SELECT CONF_CD 
					   FROM TB_CM_COMM_CONFIG
					  WHERE CONF_GRP_CD = 'BF_SELECT_CRITERIA' 
					    AND DEFAT_VAL='Y')			AS RULE_01
				,   NULL			AS TARGET_BUKT_CD
		  ) INSERT INTO TB_BF_CONTROL_BOARD_VER_DTL
					( ID
					 ,VER_CD
					 ,PROCESS_NO
					 ,ENGINE_TP_CD
					 ,[STATUS]
					 ,RUN_STRT_DATE
					 ,RUN_END_DATE
					 ,DESCRIP
					 ,RULE_01
--					 ,INPUT_BUKT_CD
					 ,TARGET_BUKT_CD
					 ,CREATE_BY
					 ,CREATE_DTTM
					)
				SELECT REPLACE(NEWID(),'-','') AS ID
					,  @P_BF_VER			   AS VER_CD
					,  M.PROCESS_NO			   AS PROCESS_NO
					,  NULL					   AS ENGINE_TP_CD
					,  M.STAT				   AS [STATUS]
					,  M.RUN_DT				   AS RUN_STRT_DATE
					,  M.RUN_DT				   AS RUN_END_DATE
					,  M.PROCESS			   AS DESCRIP
					,  M.RULE_01	   		   AS RULE_01
					,  M.TARGET_BUKT_CD		   AS TARGET_BUKT_CD
					,  @P_USER_ID			   AS CREATE_BY
					,  GETDATE()			   AS CREATE_DTTM
				  FROM M 
		;
	END
	;
/****************************************************************************************
	-- 2. Model별 process 생성 (grid changes 파라미터에 의해 Engine Type별로 프로시저 실행)
*****************************************************************************************/
	WITH MST
	AS (
			SELECT  @P_BF_VER				    AS VER_CD
				   ,@P_SEQ						AS SEQ
				   ,@P_ENGINE_TP_CD				AS ENGINE_TP_CD
				   ,@P_DESCRIP					AS DESCRIP
				   ,@P_INPUT_HORIZ				AS INPUT_HORIZ			
				   ,@P_INPUT_BUKT_CD			AS INPUT_BUKT_CD		
				   ,@P_TARGET_HORIZ				AS TARGET_HORIZ		
				   ,@P_TARGET_BUKT_CD			AS TARGET_BUKT_CD		
				   ,@P_SALES_LV_CD				AS SALES_LV_CD			
				   ,@P_ITEM_LV_CD				AS ITEM_LV_CD		
				   ,NULL						AS RULE_01
--				   ,@P_RULE_01			AS RULE_01		-- 지금은 안씀
				   ,@P_INPUT_FROM_DATE			AS INPUT_FROM_DATE		
				   ,@P_INPUT_TO_DATE			AS INPUT_TO_DATE		
				   ,@P_TARGET_FROM_DATE			AS TARGET_FROM_DATE	
				   ,@P_TARGET_TO_DATE			AS TARGET_TO_DATE
				   ,@P_VAL_TP					AS VAL_TP
				   ,@P_ATTR_01					AS ATTR_01				
				   ,@P_ATTR_02					AS ATTR_02				
				   ,@P_ATTR_03					AS ATTR_03				
				   ,@P_ATTR_04					AS ATTR_04				
				   ,@P_ATTR_05					AS ATTR_05				
				   ,@P_ATTR_06					AS ATTR_06				
				   ,@P_ATTR_07					AS ATTR_07				
				   ,@P_ATTR_08					AS ATTR_08				
				   ,@P_ATTR_09					AS ATTR_09				
				   ,@P_ATTR_10					AS ATTR_10				
				   ,@P_USER_ID					AS USER_ID				
	 ), PROCESS
	 AS (	
--		   SELECT ' Learning'		AS TP
--				 ,0					AS SEQ	
--				 ,NULL				AS STRT_DATE
--				 ,NULL 		  		AS END_DATE 
--		    WHERE @P_ENGINE_TP_CD = 'TF'
--			  AND NOT EXISTS (  SELECT 1
--								  FROM TB_BF_CONTROL_BOARD_VER_DTL
--								 WHERE ENGINE_TP_CD = 'TF'
--								   AND DESCRIP LIKE '%Learning%'
--								   AND STATUS = @P_COMP_CD
--							 )
--			UNION
--			SELECT TOP 1
--				  ' Learning'			AS TP
--				 , 0					AS SEQ 
--				 , RUN_STRT_DATE		AS STRT_DATE
--				 , RUN_END_DATE			AS END_DATE 
--			  FROM TB_BF_CONTROL_BOARD_VER_DTL
--			 WHERE ENGINE_TP_CD = 'TF'
--			   AND @P_ENGINE_TP_CD = 'TF'
--			   AND DESCRIP LIKE '%Learning%'
--			   AND STATUS = @P_COMP_CD
--			ORDER BY RUN_END_DATE DESC 
--		    UNION
--		   SELECT ' Predict'		AS TP
--				, 1					AS SEQ
--				,NULL				AS STRT_DATE
--				,NULL 		  		AS END_DATE 
--		    WHERE @P_ENGINE_TP_CD = 'TF'
--		    UNION
		   SELECT ''				AS TP
		   		, 0					AS SEQ
				,NULL				AS STRT_DATE
				,NULL 		  		AS END_DATE 
		    --WHERE @P_ENGINE_TP_CD != 'TF'
	 )
 INSERT INTO TB_BF_CONTROL_BOARD_VER_DTL
	 (    ID
		, VER_CD
		, PROCESS_NO				
		, ENGINE_TP_CD
		, [STATUS]
		, RUN_STRT_DATE
		, RUN_END_DATE
		, DESCRIP
		, RULE_01		
		, INPUT_HORIZ			
		, INPUT_BUKT_CD		
		, TARGET_HORIZ		
		, TARGET_BUKT_CD		
		, INPUT_FROM_DATE		
		, INPUT_TO_DATE		
		, TARGET_FROM_DATE	
		, TARGET_TO_DATE		
		, SALES_LV_CD			
		, ITEM_LV_CD	
		, VAL_TP
		, ATTR_01				
		, ATTR_02				
		, ATTR_03				
		, ATTR_04				
		, ATTR_05				
		, ATTR_06				
		, ATTR_07				
		, ATTR_08				
		, ATTR_09				
		, ATTR_10				
		, CREATE_BY
		, CREATE_DTTM
		, MODIFY_BY
		, MODIFY_DTTM
        , SHARD_NO
	 )
	 SELECT	  REPLACE(NEWID(),'-','')		AS ID
			, M.VER_CD						AS VER_CD
			, M.SEQ*10000+P.SEQ				AS PROCESS_NO				
			, M.ENGINE_TP_CD				AS ENGINE_TP_CD
			, CASE WHEN P.END_DATE	 IS NULL THEN @P_READY_CD ELSE @P_COMP_CD END AS [STATUS]
			, P.STRT_DATE						AS RUN_STRT_DATE
			, P.END_DATE						AS RUN_END_DATE
			, M.DESCRIP+P.TP				AS DESCRIP
			, M.RULE_01				AS RULE_01		
			, M.INPUT_HORIZ					AS INPUT_HORIZ			
			, M.INPUT_BUKT_CD				AS INPUT_BUKT_CD		
			, M.TARGET_HORIZ				AS TARGET_HORIZ		
			, M.TARGET_BUKT_CD				AS TARGET_BUKT_CD		
			, M.INPUT_FROM_DATE				AS INPUT_FROM_DATE		
			, M.INPUT_TO_DATE				AS INPUT_TO_DATE		
			, M.TARGET_FROM_DATE			AS TARGET_FROM_DATE	
			, M.TARGET_TO_DATE				AS TARGET_TO_DATE		
			, M.SALES_LV_CD					AS SALES_LV_CD			
			, M.ITEM_LV_CD					AS ITEM_LV_CD
			, M.VAL_TP						AS VAL_TP
			, M.ATTR_01						AS ATTR_01				
			, M.ATTR_02						AS ATTR_02				
			, M.ATTR_03						AS ATTR_03				
			, M.ATTR_04						AS ATTR_04				
			, M.ATTR_05						AS ATTR_05				
			, M.ATTR_06						AS ATTR_06				
			, M.ATTR_07						AS ATTR_07				
			, M.ATTR_08						AS ATTR_08				
			, M.ATTR_09						AS ATTR_09				
			, M.ATTR_10						AS ATTR_10				
			, M.USER_ID						AS CREATE_BY
			, GETDATE()						AS CREATE_DTTM
			, NULL							AS MODIFY_BY
			, NULL							AS MODIFY_DTTM
            , 0                             AS SHARD_NO
	   FROM MST M
		    CROSS JOIN
			PROCESS P
		;
/****************************************************************************************
	-- Master 데이터 변경
*****************************************************************************************/

    UPDATE TB_BF_CONTROL_BOARD_MST 
	   SET INPUT_HORIZ		= @P_INPUT_HORIZ
	     , INPUT_BUKT_CD	= @P_INPUT_BUKT_CD
		 , TARGET_HORIZ		= @P_TARGET_HORIZ
		 , TARGET_BUKT_CD	= @P_TARGET_BUKT_CD
		 , SALES_LV_CD		= @P_SALES_LV_CD
		 , ITEM_LV_CD		= @P_ITEM_LV_CD
		 , BF_DIST_RULE_CD  = @P_RULE_01
		 , VAL_TP			= @P_VAL_TP
		 , ATTR_01			= @P_ATTR_01
		 , ATTR_02			= @P_ATTR_02
		 , ATTR_03			= @P_ATTR_03
		 , ATTR_04			= @P_ATTR_04
		 , ATTR_05			= @P_ATTR_05
		 , ATTR_06			= @P_ATTR_06
		 , ATTR_07			= @P_ATTR_07
		 , ATTR_08			= @P_ATTR_08
		 , ATTR_09			= @P_ATTR_09
		 , ATTR_10			= @P_ATTR_10
	WHERE ENGINE_TP_CD = @P_ENGINE_TP_CD


 
  
	 
	BEGIN
	    SET @P_RT_MSG = 'MSG_0001'
	END
	    SET @P_RT_ROLLBACK_FLAG = 'true'
END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END
	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR
END CATCH



go

