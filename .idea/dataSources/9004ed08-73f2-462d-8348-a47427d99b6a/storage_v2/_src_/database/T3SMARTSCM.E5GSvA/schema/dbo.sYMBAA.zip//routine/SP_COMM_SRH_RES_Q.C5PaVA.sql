/*****************************************************************************
Title : SP_COMM_SRH_RES_Q
최초 작성자 : 조아람
최초 생성일 : 2017.11.08
 
설명 
 - 검색조건 : Resource 정보 조회
 
History (수정일자 / 수정자 / 수정내용)
- 2017.11.08 / 조아람 / 최초 작성
 
*****************************************************************************/
CREATE PROCEDURE [dbo].[SP_COMM_SRH_RES_Q] (
	@P_LOCAT_TP			NVARCHAR(100) = '',
	@P_LOCAT_CD			NVARCHAR(100) = '',
	@P_LOCAT_NM			NVARCHAR(100) = '',
	@P_RES_CD			NVARCHAR(100) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

	 SELECT  A.COMN_CD_NM	AS LOCAT_TP_NM
			,B.LOCAT_LV
			,C.LOCAT_CD
			,C.LOCAT_NM
			,E.ROUTE_GRP
			,E.WC
			,F.ID			AS RES_DTL_ID
			,F.RES_CD
			,F.RES_DESCRIP      
		FROM TB_AD_COMN_CODE A
			INNER JOIN 
			TB_CM_LOC_MST B
		ON (A.ID = B.LOCAT_TP_ID)
			INNER JOIN 
			TB_CM_LOC_DTL C
		ON (B.ID = C.LOCAT_MST_ID)
			INNER JOIN 
			TB_CM_LOC_MGMT D
		ON (C.ID = D.LOCAT_ID)
			INNER JOIN 
			TB_MP_RES_MGMT_MST E
		ON (D.ID = E.LOCAT_MGMT_ID)
			INNER JOIN 
			TB_MP_RES_MGMT_DTL F
		ON (E.ID = F.RES_MGMT_MST_ID)
	 ------------------------------------------
	 -- 조회 조건
	 ------------------------------------------
	  WHERE UPPER(A.COMN_CD_NM) LIKE '%' + @P_LOCAT_TP + '%'
	    AND C.LOCAT_CD LIKE '%' + @P_LOCAT_CD + '%'
		AND C.LOCAT_NM LIKE '%' + @P_LOCAT_NM + '%'
		AND F.RES_CD LIKE '%' + @P_RES_CD + '%'
      ORDER BY A.SEQ, B.LOCAT_LV, C.LOCAT_CD, F.RES_CD
	
END

go

