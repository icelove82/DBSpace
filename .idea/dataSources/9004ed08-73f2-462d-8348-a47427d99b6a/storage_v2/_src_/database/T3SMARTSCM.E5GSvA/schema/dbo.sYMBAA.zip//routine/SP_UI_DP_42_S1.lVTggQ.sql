CREATE PROCEDURE [dbo].[SP_UI_DP_42_S1] (
	 @P_ITEM_CD				NVARCHAR(100)
	,@P_ACCT_CD				NVARCHAR(100)
	,@P_BASE_DATE			DATE
	,@P_QTY					decimal(20,3)
	,@P_AMT					decimal(20,3)
	,@P_SO_STATUS_CD	    NVARCHAR(200)
--	,@P_SO_STATUS_ID	    CHAR(32)
	,@P_USER_ID				NVARCHAR(25)
	,@P_RT_ROLLBACK_FLAG		NVARCHAR(10)   = 'true'     OUTPUT
	,@P_RT_MSG				NVARCHAR(4000) = ''				OUTPUT		
)
AS
/***************************************************************************************
	[SP_UI_CM_20_S1]

	History (date / wirter /comment)
	- ****.**.** / kim sohee / draft
	- 2022.01.12 / kim sohee / SO_STATUS_ID => SO_STATUS_CD (for excel import)
****************************************************************************************/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	DECLARE @P_ERR_STATUS INT = 0
		   ,@P_ERR_MSG NVARCHAR(4000)=''
	DECLARE  @P_ITEM_MST_ID	 CHAR(32)
			,@P_ACCOUNT_ID   CHAR(32)
			,@P_SO_STATUS_ID CHAR(32);
BEGIN TRY
	-- Find ID
	SELECT @P_ITEM_MST_ID = ID FROM TB_CM_ITEM_MST WHERE ITEM_CD =@P_ITEM_CD
	SELECT @P_ACCOUNT_ID = ID FROM TB_DP_ACCOUNT_MST WHERE ACCOUNT_CD = @P_ACCT_CD
	SELECT @P_SO_STATUS_ID = ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_SO_STATUS' AND CONF_CD = @P_SO_STATUS_CD
	-- VALIDATION ABOUT ID 
	IF(@P_ITEM_MST_ID IS NULL)
	BEGIN 
		SET @P_ERR_MSG = 'Item Code is not valid'
		RAISERROR (@P_ERR_MSG,12, 1);
	END
	IF(@P_ACCOUNT_ID IS NULL)
	BEGIN 
		SET @P_ERR_MSG = 'Account Code is not valid'
		RAISERROR (@P_ERR_MSG,12, 1);
	END
--	IF(@P_SO_STATUS_ID IS NULL)
--	BEGIN 
--		SET @P_ERR_MSG = 'SO Status is not valid'
--		RAISERROR (@P_ERR_MSG,12, 1);
--	END

	MERGE INTO TB_CM_ACTUAL_SALES TGT
		 USING ( SELECT
				 @P_ITEM_MST_ID		AS ITEM_MST_ID	
				,@P_ACCOUNT_ID		AS ACCOUNT_ID	
				,@P_BASE_DATE		AS BASE_DATE	
				,@P_QTY				AS QTY			
				,@P_AMT				AS AMT			
				,@P_SO_STATUS_ID	AS SO_STATUS_ID
				,@P_USER_ID			AS [USER_ID]		
				,GETDATE()			AS [DTTM]		
		 	   ) SRC
			ON SRC.ITEM_MST_ID = TGT.ITEM_MST_ID
		   AND SRC.ACCOUNT_ID = TGT.ACCOUNT_ID
		   AND SRC.BASE_DATE = TGT.BASE_DATE
		   AND SRC.SO_STATUS_ID = TGT.SO_STATUS_ID
	WHEN MATCHED THEN 
		 UPDATE SET QTY		    = SRC.QTY
			       ,AMT		    = SRC.AMT
				   ,MODIFY_BY   = SRC.[USER_ID]
				   ,MODIFY_DTTM = SRC.[DTTM]
	WHEN NOT MATCHED THEN
		   INSERT  ( ID
				    ,ITEM_MST_ID
				    ,ACCOUNT_ID
				    ,BASE_DATE
				    ,SO_STATUS_ID
				    ,QTY
				    ,AMT
				    ,CREATE_BY
				    ,CREATE_DTTM
				   ) VALUES
				  ( REPLACE(NEWID(),'-','')
				   ,SRC.ITEM_MST_ID
				   ,SRC.ACCOUNT_ID
				   ,SRC.BASE_DATE
				   ,SRC.SO_STATUS_ID
				   ,SRC.QTY
				   ,SRC.AMT
				   ,SRC.[USER_ID]
				   ,SRC.DTTM				 				   
				  );
				   
	    SET @P_RT_MSG = 'MSG_0001'

	    SET @P_RT_ROLLBACK_FLAG = 'true'
END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END
	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR
END CATCH

go

