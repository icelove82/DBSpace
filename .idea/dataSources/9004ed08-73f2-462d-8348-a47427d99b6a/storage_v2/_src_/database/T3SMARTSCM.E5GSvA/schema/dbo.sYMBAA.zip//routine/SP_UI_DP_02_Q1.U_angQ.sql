/*****************************************************************************
Title : SP_DP_02_Q1
최초 작성자 : 민희영
최초 생성일 : 2017.06.20
 
설명 
 - DP Level Management
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 민희영 / 최초 작성
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_02_Q1] ( @p_LV_TP NVARCHAR(30) = ''
										,@p_DEL_YN CHAR(1) = 'N'
								   ) AS 

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

/****** Script for SelectTopNRows command from SSMS  ******/
/*
SELECT LM.LV_TP
      ,LM.LV_CD
      ,LM.LV_NM
      ,LM.SEQ
      ,LM.LEAF_YN
      ,LM.LV_LEAF_YN
      ,LM.SRP_LV_YN
	  ,LM.USE_YN
      ,LM.CREATE_BY
      ,LM.CREATE_DTTM
      ,LM.MODIFY_BY
      ,LM.MODIFY_DTTM
  FROM TB_DP_LEVEL_MANAGEMENT  LM
 WHERE LM.LV_TP  LIKE '%' + @p_LV_TP +'%'				 
 ORDER BY LM.LV_TP ASC, LM.SEQ ASC
   ;
*/

/****** SSMS의 SelectTopNRows 명령 스크립트 ******/
	SELECT LM.ID
		  ,LM.LV_TP_ID 
		  --,B.CONF_CD   AS  LV_TP
		  --,B.CONF_NM   AS  LV_NM
		  ,LM.LV_CD
		  ,LM.LV_NM
		  ,LM.SEQ
		  ,LM.LV_LEAF_YN
		  ,LM.SALES_LV_YN
		  ,LM.ACCOUNT_LV_YN
		  ,LM.SRP_LV_YN
		  ,LM.LEAF_YN
		  ,LM.ACTV_YN
		  ,LM.DEL_YN
		  ,LM.CREATE_BY
		  ,LM.CREATE_DTTM
		  ,LM.MODIFY_BY
		  ,LM.MODIFY_DTTM
      FROM TB_CM_CONFIGURATION A
		 , TB_CM_COMM_CONFIG B
         , TB_CM_LEVEL_MGMT LM
	 where A.MODULE_CD = 'DP'
	   AND A.ID = B.CONF_ID
	   AND B.CONF_GRP_CD =  'DP_LV_TP'
	   AND B.ACTV_YN = 'Y'
	   AND B.ID = LM.LV_TP_ID
	   --AND (ISNULL(LM.DEL_YN, 'N') = @P_DEL_YN OR ISNULL(@P_DEL_YN,'') = '')
	   AND (LM.DEL_YN = @p_DEL_YN OR ISNULL(RTRIM(LTRIM(@p_DEL_YN)),'')='')
       AND LM.LV_TP_ID  LIKE '%' + LTRIM(RTRIM(@p_LV_TP)) +'%'		
    ORDER BY B.PRIORT ASC, LM.SEQ ASC
 ;

   
END
 





go

