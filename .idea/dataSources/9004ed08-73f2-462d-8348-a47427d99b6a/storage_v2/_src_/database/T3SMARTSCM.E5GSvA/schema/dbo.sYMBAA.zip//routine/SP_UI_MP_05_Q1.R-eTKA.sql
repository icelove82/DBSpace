/*****************************************************************************
Title : SP_UI_MP_05_Q1
최초 작성자 : 조아람
최초 생성일 : 2017.08.02
 
설명 
 - MP Material Constraint(UI_MP_05) 조회 프로시저
 
History (수정일자 / 수정자 / 수정내용)
- 2017.08.02 / 조아람 / 최초 작성
- 2018.04.25 / 김명식 / UOM_NM 컬럼 쿼리 수정
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_MP_05_Q1] (
	 @P_LOCAT_TP		NVARCHAR(100) = '',
	 @P_LOCAT_LV		NVARCHAR(100) = '',
	 @P_LOCAT_CD		NVARCHAR(100) = '',
	 @P_LOCAT_NM		NVARCHAR(100) = '',
	 @P_ITEM_CD			NVARCHAR(100) = '',
	 @P_ITEM_NM			NVARCHAR(100) = '',
	 @P_MAT_TP			NVARCHAR(100) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

	IF @P_MAT_TP = '' SET @P_MAT_TP = 'A'

	SELECT  F.ID						AS ID
		   ,A.COMN_CD_NM				AS LOCAT_TP_NM
		   ,B.LOCAT_LV
		   ,C.LOCAT_CD
		   ,C.LOCAT_NM
		   ,G.ITEM_CD
		   ,G.ITEM_NM 
		   ,G.DESCRIP					AS ITEM_DESCRIP
		   ,H.CONVN_NM					AS ITEM_TP 
		   ,F.KEY_MAT_YN				AS KEY_MAT_YN
		   ,F.LGDY_MAT_YN				AS LGDY_MAT_YN
		   ,F.MAT_CONST_TP_ID			AS MAT_CONST_TP_ID
		   ,F.MAT_CONST_TP_ID			AS MAT_CONST_TP
		   ,F.CONST_TP_CHNG_PERIOD		AS CONST_TP_CHNG_PERIOD
		   ,(SELECT UOM.ID FROM TB_CM_UOM UOM WHERE UOM.ID = F.UOM_ID AND UOM.TIME_UOM_YN='Y') AS UOM_NM
		   ,F.ACTV_YN
		   ,A.CREATE_BY
		   ,A.CREATE_DTTM
		   ,A.MODIFY_BY
		   ,A.MODIFY_DTTM
		 , G.ATTR_01					AS ATTR_01
		 , G.ATTR_02					AS ATTR_02
		 , G.ATTR_03					AS ATTR_03
		 , G.ATTR_04					AS ATTR_04
		 , G.ATTR_05					AS ATTR_05
		 , G.ATTR_06					AS ATTR_06
		 , G.ATTR_07					AS ATTR_07
		 , G.ATTR_08					AS ATTR_08
		 , G.ATTR_09					AS ATTR_09
		 , G.ATTR_10					AS ATTR_10
		 , G.ATTR_11					AS ATTR_11
		 , G.ATTR_12					AS ATTR_12
		 , G.ATTR_13					AS ATTR_13
		 , G.ATTR_14					AS ATTR_14
		 , G.ATTR_15					AS ATTR_15
		 , G.ATTR_16					AS ATTR_16
		 , G.ATTR_17					AS ATTR_17
		 , G.ATTR_18					AS ATTR_18
		 , G.ATTR_19					AS ATTR_19
		 , G.ATTR_20					AS ATTR_20
		 ---------------------------------------------
	  FROM TB_AD_COMN_CODE A
		   INNER JOIN
		   TB_CM_LOC_MST B
		ON (A.ID = B.LOCAT_TP_ID)
		   INNER JOIN 
		   TB_CM_LOC_DTL C
		ON (B.ID = C.LOCAT_MST_ID)
		   INNER JOIN 
		   TB_CM_LOC_MGMT D
		ON (C.ID = D.LOCAT_ID)
		   INNER JOIN 
		   TB_CM_SITE_ITEM F
		ON (D.ID = F.LOCAT_MGMT_ID)
		   INNER JOIN 
		   TB_CM_ITEM_MST G
		ON (F.ITEM_MST_ID = G.ID)
		   INNER JOIN 
		   TB_CM_ITEM_TYPE H
		ON (G.ITEM_TP_ID = H.ID)
		   INNER JOIN 
		   TB_AD_COMN_CODE K
		ON (H.ITEM_TP_CD_ID = K.ID)
	 WHERE 1=1
	   AND K.COMN_CD = 'RM'

	   AND UPPER(A.COMN_CD_NM) LIKE '%'+UPPER(@P_LOCAT_TP)+'%'
	   AND B.LOCAT_LV LIKE '%'+@P_LOCAT_LV+'%'
	   AND UPPER(C.LOCAT_CD) LIKE '%'+UPPER(@P_LOCAT_CD)+'%'
	   AND UPPER(C.LOCAT_NM) LIKE '%'+UPPER(@P_LOCAT_NM)+'%'
	   AND UPPER(G.ITEM_CD) LIKE '%'+UPPER(@P_ITEM_CD)+'%'
	   AND UPPER(G.ITEM_NM) LIKE '%'+UPPER(@P_ITEM_NM)+'%'
	   AND 1= CASE WHEN @P_MAT_TP = 'A' THEN 1
				   WHEN @P_MAT_TP = 'K' THEN CASE WHEN F.KEY_MAT_YN = 'Y'  THEN 1 END
				   WHEN @P_MAT_TP = 'L' THEN CASE WHEN F.LGDY_MAT_YN = 'Y' THEN 1 END
			   END

END
go

