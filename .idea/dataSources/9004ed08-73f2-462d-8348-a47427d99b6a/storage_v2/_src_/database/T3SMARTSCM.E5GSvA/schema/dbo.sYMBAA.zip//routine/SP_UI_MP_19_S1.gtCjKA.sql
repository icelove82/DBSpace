
CREATE PROCEDURE [dbo].[SP_UI_MP_19_S1] (
     @P_ID                        CHAR(32)
    ,@P_ACTV_YN                   CHAR(1) = NULL
    ,@P_DMND_TP_ID                CHAR(32) = NULL
    ,@P_DMND_CLASS_ID             CHAR(32) = NULL
    ,@P_URGENT_ORDER_TP           CHAR(32) = NULL
    ,@P_DMND_QTY                  DECIMAL(20,3) = NULL
    ,@P_SALES_UNIT_PRIC           DECIMAL(20,3) = NULL
    ,@P_PRIORT                    INT = NULL
    ,@P_PRDUCT_DELIVY_DATE        DATETIME = NULL
    ,@P_DELIVY_PLAN_POLICY_CD_ID  CHAR(32) = NULL
    ,@P_MAT_CONST_CD_ID           CHAR(32) = NULL
    ,@P_PARTIAL_PLAN_YN           CHAR(1) = NULL
    ,@P_HEURISTIC_YN              CHAR(1) = NULL
    ,@P_COST_OPTIMIZ_YN           CHAR(1) = NULL
    ,@P_DUE_DATE                  DATETIME = NULL
    ,@P_PST                       DATETIME = NULL
    ,@P_DUE_DATE_FNC              DATETIME = NULL
    ,@P_STRATEGY_METHD_ID         CHAR(32) = NULL
    ,@P_DISPLAY_COLOR             NVARCHAR (100) = NULL
    ,@P_USER_ID                   NVARCHAR (100) = NULL
    ,@P_RT_ROLLBACK_FLAG          NVARCHAR(10) = 'true' OUTPUT
    ,@P_RT_MSG                    NVARCHAR(4000) = '' OUTPUT
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
        ,@P_ERR_MSG NVARCHAR(4000)=''

BEGIN TRY
    UPDATE A
    SET  A.DMND_TP_ID                = @P_DMND_TP_ID
        ,A.DMND_CLASS_ID             = @P_DMND_CLASS_ID
        ,A.URGENT_ORDER_TP_ID        = @P_URGENT_ORDER_TP
        ,A.DMND_QTY                  = @P_DMND_QTY
        ,A.SALES_UNIT_PRIC           = @P_SALES_UNIT_PRIC
        ,A.PRIORT                    = @P_PRIORT
        ,A.PRDUCT_DELIVY_DATE        = @P_PRDUCT_DELIVY_DATE
        ,A.DELIVY_PLAN_POLICY_CD_ID  = @P_DELIVY_PLAN_POLICY_CD_ID
        ,A.MAT_CONST_CD_ID           = @P_MAT_CONST_CD_ID
        ,A.PARTIAL_PLAN_YN           = @P_PARTIAL_PLAN_YN
        ,A.HEURISTIC_YN              = @P_HEURISTIC_YN
        ,A.COST_OPTIMIZ_YN           = @P_COST_OPTIMIZ_YN
        ,A.DUE_DATE                  = @P_DUE_DATE
        ,A.PST                       = @P_PST
        ,A.DUE_DATE_FNC              = @P_DUE_DATE_FNC
        ,A.STRATEGY_METHD_ID         = @P_STRATEGY_METHD_ID
        ,A.DISPLAY_COLOR             = @P_DISPLAY_COLOR
        ,A.ACTV_YN                   = @P_ACTV_YN
        ,A.MODIFY_BY                 = @P_USER_ID
        ,A.MODIFY_DTTM               = GETDATE()
        FROM TB_CM_DEMAND_OVERVIEW A
        WHERE 1=1
            AND A.ID = @P_ID

    SET @P_RT_ROLLBACK_FLAG = 'true'
    SET @P_RT_MSG = 'MSG_0001'

END TRY
BEGIN CATCH
    IF(ERROR_MESSAGE() LIKE 'MSG_%')
        BEGIN
            SET @P_ERR_MSG = ERROR_MESSAGE()
            SET @P_RT_ROLLBACK_FLAG = 'false'
            SET @P_RT_MSG = @P_ERR_MSG
        END
    ELSE
        THROW
END CATCH

go

