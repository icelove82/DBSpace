CREATE PROCEDURE [dbo].[SP_UI_IM_25_Q2] (
	@P_LOCAT_TP		 NVARCHAR(100) = ''
   ,@P_LOCAT_LV		 NVARCHAR(100) = ''
   ,@P_LOCAT_CD		 NVARCHAR(100) = ''
   ,@P_LOCAT_NM		 NVARCHAR(100) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

    SELECT  A.ID,
            D.COMN_CD_NM AS LOCAT_TP_NM,
            C.LOCAT_LV,
            B.LOCAT_CD,
            B.LOCAT_NM,
            A.VAL_01,
			H.DESCRIP AS QUADRANT_DESCRIP,
            A.VAL_02,
            A.VAL_03,
            A.VAL_04,
            A.VAL_05,
            A.VAL_06,
            A.VAL_07,
            A.VAL_08,
            A.VAL_09,
            A.VAL_10,
            A.VAL_11,
            A.VAL_12,
            A.VAL_13,
            A.VAL_14,
            A.VAL_15,
            A.VAL_16,
            A.VAL_17,
            A.VAL_18,
            A.VAL_19,
            A.VAL_20,
            A.ITEM_CNT,
            A.INV_MGMT_SYSTEM_TP_ID,
            A.PO_CYCL_CD_ID,
			A.PO_CYCL_CALENDAR_ID,
            G.CALENDAR_ID AS PO_CYCL_CALENDAR,
            A.INV_PLACE_STRTGY_ID,
            A.SUPPLY_LEADTIME_YN,
			A.PO_CYCL_YN,
            A.OPERT_LV_VAL,
            A.PRPSAL_SVC_LV,
            A.SFST_SVC_LV,
			A.SFST_DEMDVAR_CONSID_YN,
			A.SFST_SUPYVAR_CONSID_YN,
			A.ROP_CAL_TP_ID,
            A.ROP_SFST_CONSID_YN,
            A.ROP_OPERT_INV_CONSID_YN,
			A.ROP_RIGHT_RATE_YN,
            A.EOQ_CAL_TP_ID,
			A.EOQ_RIGHT_RATE_YN,
			A.EOQ_MULTIPLE,
            A.TARGET_INV_SFST_CONSID_YN,
            A.TARGET_INV_OPERT_INV_CONSID_YN,
            A.FIXED_YN,
            A.ACTV_YN,
            A.CREATE_BY,
            A.CREATE_DTTM,
            A.MODIFY_BY,
            A.MODIFY_DTTM
    FROM    TB_IM_INV_POLICY_MST A
            INNER JOIN TB_CM_LOC_DTL B
            ON B.ID = A.LOCAT_ID
            INNER JOIN TB_CM_LOC_MST C
            ON C.ID = B.LOCAT_MST_ID
            INNER JOIN TB_AD_COMN_CODE D
            ON D.ID = C.LOCAT_TP_ID
            LEFT OUTER JOIN
            (
            SELECT  B.MGMT_NM, B.SEQ
            FROM    TB_IM_SEGMT_DIM_MST A,
                    TB_IM_SEGMT_DIM_DTL B
            WHERE   A.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
            AND     A.SEGMT_DIM_CD = 'VAL_01'
            ) E
            ON E.MGMT_NM = A.VAL_01
            LEFT OUTER JOIN
            (
            SELECT  B.MGMT_NM, B.SEQ
            FROM    TB_IM_SEGMT_DIM_MST A,
                    TB_IM_SEGMT_DIM_DTL B
            WHERE   A.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
            AND     A.SEGMT_DIM_CD = 'VAL_02'
            ) F
            ON F.MGMT_NM = A.VAL_02
            LEFT OUTER JOIN TB_IM_PO_CALENDAR G
			ON (A.PO_CYCL_CALENDAR_ID = G.ID)
			LEFT OUTER JOIN TB_AD_COMN_CODE H
			ON (H.COMN_CD = A.VAL_01)
    WHERE   1=1
    AND     UPPER(D.COMN_CD_NM) LIKE '%'+UPPER(@P_LOCAT_TP)+'%'
    AND     C.LOCAT_LV LIKE '%'+UPPER(@P_LOCAT_LV)+'%'
    AND     RTRIM(B.LOCAT_CD) LIKE '%'+UPPER(@P_LOCAT_CD)+'%'
    AND     UPPER(B.LOCAT_NM) LIKE '%'+UPPER(@P_LOCAT_NM)+'%' 
    ORDER   BY D.SEQ, C.LOCAT_LV, B.LOCAT_CD, A.LOCAT_ID, E.SEQ, F.SEQ

END

go

