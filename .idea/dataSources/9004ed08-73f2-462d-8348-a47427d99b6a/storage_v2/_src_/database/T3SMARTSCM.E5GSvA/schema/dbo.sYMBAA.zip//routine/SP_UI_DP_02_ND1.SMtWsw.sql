
CREATE PROCEDURE [dbo].[SP_UI_DP_02_ND1]  (
                                       @ID                CHAR(32)          = ''         
									  ,@USER_ID           NVARCHAR(100)     = ''    
									  ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)      = 'true'   OUTPUT
									  ,@P_RT_MSG            NVARCHAR(4000)    = ''		 OUTPUT											    
					                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
/*
	[SP_UI_DP_02_ND1]

	History (Date / Writer / Comment)
	- 2023.01.18 / kim sohee / validation
	- 2023.01.25 / kim sohee / Leaf Level update 
*/
DECLARE  
		 @P_ERR_STATUS INT = 0
        ,@P_ERR_MSG NVARCHAR(4000)=''
BEGIN TRY
		-- CAN NOT REMOVE ITEM, SALESMANM ACCOUNT
/**********************************************************************************************
-- LEAF_YN, LV_LEAF_YN UPDATE
-- Config에서 레벨 타입이 새로 생기면, LEAF로 최하위 레벨을 만들어줘야 한다.
-- LEAF LEVEL이 삭제되면 다른 레벨을 LEAF LEVEL로 만들어줘야 한다
**********************************************************************************************/
DECLARE @P_LV_LEAF_YN		CHAR(1)
	   ,@P_ACCOUNT_LV_YN	CHAR(1)
	   ,@P_LV_TP_ID			CHAR(32)
	   ;

SELECT @P_LV_LEAF_YN = LV_LEAF_YN, @P_ACCOUNT_LV_YN = ACCOUNT_LV_YN, @P_LV_TP_ID = LV_TP_ID 
 FROM TB_CM_LEVEL_MGMT
WHERE ID = @ID 
;
IF (@P_LV_LEAF_YN = 'Y')
	BEGIN
		WITH ALL_LEVEL
		  AS (
		SELECT LV.ID, LV.LV_CD, SEQ, ROW_NUMBER() OVER (ORDER BY LV.SEQ DESC) AS SEQ_NUM 
		 FROM TB_CM_LEVEL_MGMT LV
		 WHERE COALESCE(LV.DEL_YN,'N') = 'N'
		   AND COALESCE(LV.ACTV_YN, 'N') = 'Y'
		   AND COALESCE(ACCOUNT_LV_YN, 'N') = @P_ACCOUNT_LV_YN
		   AND COALESCE(LEAF_YN,'N') = 'N'	
		   AND LV_TP_ID = @P_LV_TP_ID
		   AND LV.ID != @ID 
		   ) 
		   UPDATE TB_CM_LEVEL_MGMT 
		     SET LV_LEAF_YN = 'Y' 		
			WHERE ID = (SELECT ID FROM ALL_LEVEL WHERE SEQ_NUM = 1)
			 ;
	 END	


/***********************************************************************************************
	-- Main 
 **********************************************************************************************/
	 
	SELECT @P_ERR_STATUS = COUNT(1)
	  FROM TB_CM_LEVEL_MGMT 
	 WHERE LEAF_YN = 'Y' 
	   AND ID = @ID
	   ;
	IF (@P_ERR_STATUS > 0 )
	BEGIN
		SET @P_ERR_MSG = 'MSG_5052'	-- The lowest level cannot be deleted.
		RAISERROR (@P_ERR_MSG,11, 1);	 		
	END

        DELETE FROM TB_CM_LEVEL_MGMT WHERE ID = @ID
        
        
--		DELETE FROM TB_AD_GROUP
--		 WHERE GRP_CD = (SELECT LV_CD FROM TB_CM_LEVEL_MGMT WHERE ID = @P_ID) 
--		 ;
					
	  -- 프로시저 종료   
   ;
		              
	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0002'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;
go

