CREATE PROCEDURE [dbo].[SP_UI_IM_26_S1_J] (
	 @P_JSON				  NVARCHAR(MAX)
    ,@P_USER_ID               NVARCHAR(100) = ''
	,@P_RT_ROLLBACK_FLAG	  NVARCHAR(10) ='true' OUT
    ,@P_RT_MSG                NVARCHAR(4000) = ''  OUT
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE
	@V_TIME_BUCKET			VARCHAR(30),
	@V_DATA_CNT				INT = 0,
	@P_ERR_STATUS			INT = 0,
	@P_ERR_MSG				NVARCHAR(4000) = ''

BEGIN TRY

	SELECT  @V_TIME_BUCKET = B.UOM_CD
	FROM    TB_CM_HORIZON_TIME_BUCKET A
			INNER JOIN TB_CM_UOM B
			ON B.ID = A.TIME_UOM_ID
			INNER JOIN TB_CM_PLAN_SNRIO_MGMT_MST C
			ON C.ID = A.PLAN_SNRIO_MGMT_MST_ID
			INNER JOIN TB_AD_COMN_CODE D
			ON D.ID = C.MODULE_ID
	WHERE   1=1
	AND		D.COMN_CD = 'IM'

	/***************************************************************************************************************************************************************************
	0. JSON 데이터 생성
	***************************************************************************************************************************************************************************/
    CREATE TABLE #TEMP_IM_INV_POLICY_ITEM
    (
        ID CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
        LOCAT_ITEM_ID CHAR(32) COLLATE DATABASE_DEFAULT,
        INV_MGMT_SYSTEM_TP_ID CHAR(32) COLLATE DATABASE_DEFAULT,
        PO_CYCL_CD_ID CHAR(32) COLLATE DATABASE_DEFAULT,
		PO_CYCL_YN CHAR COLLATE DATABASE_DEFAULT,
        PO_CYCL_CALENDAR_ID CHAR(32) COLLATE DATABASE_DEFAULT,
        OPERT_BASE_TP_ID CHAR(32) COLLATE DATABASE_DEFAULT,
        INV_PLACE_STRTGY_ID CHAR(32) COLLATE DATABASE_DEFAULT,
        SUPPLY_LEADTIME_YN CHAR COLLATE DATABASE_DEFAULT,
        OPERT_LV_VAL DECIMAL(20,3),
        SFST_SVC_LV DECIMAL(20,3),
        SFST_VAL DECIMAL(20,3),
		OPERT_INV_VAL DECIMAL(20,3),
        ROP_SFST_CONSID_YN CHAR COLLATE DATABASE_DEFAULT,
        ROP_OPERT_INV_CONSID_YN CHAR COLLATE DATABASE_DEFAULT,
        ROP_VAL DECIMAL(20,3),
		EOQ_MULTIPLE DECIMAL(20,3),
        EOQ_VAL DECIMAL(20,3),
        TARGET_INV_SFST_CONSID_YN CHAR COLLATE DATABASE_DEFAULT,
        TARGET_INV_OPERT_INV_CONSID_YN CHAR COLLATE DATABASE_DEFAULT,
        TARGET_INV_VAL DECIMAL(20,3),
        MOQ DECIMAL(20,3),
        MULTIPLIER DECIMAL(20,3),
        FIXED_YN CHAR COLLATE DATABASE_DEFAULT,
        ACTV_YN CHAR COLLATE DATABASE_DEFAULT,
		UPDATE_TYPE NVARCHAR(30)
    )

	INSERT INTO #TEMP_IM_INV_POLICY_ITEM
	(
		 ID
		,LOCAT_ITEM_ID
		,INV_MGMT_SYSTEM_TP_ID
		,PO_CYCL_CD_ID
		,PO_CYCL_YN
		,PO_CYCL_CALENDAR_ID
		,OPERT_BASE_TP_ID
		,INV_PLACE_STRTGY_ID
		,SUPPLY_LEADTIME_YN
		,OPERT_LV_VAL
		,SFST_SVC_LV
		,SFST_VAL
		,OPERT_INV_VAL
		,ROP_SFST_CONSID_YN
		,ROP_OPERT_INV_CONSID_YN
		,ROP_VAL
		,EOQ_MULTIPLE
		,EOQ_VAL
		,TARGET_INV_SFST_CONSID_YN
		,TARGET_INV_OPERT_INV_CONSID_YN
		,TARGET_INV_VAL
		,MOQ
		,MULTIPLIER
		,FIXED_YN
		,ACTV_YN
	)
	SELECT  A.ID															AS ID,
			ISNULL(A.LOCAT_ITEM_ID, B.LOCAT_ITEM_ID)						AS LOCAT_ITEM_ID,
			C.ID															AS INV_MGMT_SYSTEM_TP_ID,
			D.ID															AS PO_CYCL_CD_ID,
			CASE WHEN C.COMN_CD = 'TARGET_INVENTORY_MGMT_SYSTEM' OR C.COMN_CD ='MIN_MAX_MGMT_SYSTEM' THEN 'Y' ELSE 'N' END AS PO_CYCL_YN,
			E.ID															AS PO_CYCL_CALENDAR_ID,
			F.ID															AS OPERT_BASE_TP_ID,
			G.ID															AS INV_PLACE_STRTGY_ID,
			CASE WHEN UPPER(A.SUPPLY_LEADTIME_YN) = 'T' THEN 'Y'
			     WHEN UPPER(A.SUPPLY_LEADTIME_YN) = 'F' THEN 'N'
				 ELSE ISNULL(A.SUPPLY_LEADTIME_YN, 'N')
			END																AS SUPPLY_LEADTIME_YN,
			A.OPERT_LV_VAL													AS OPERT_LV_VAL,
			A.SFST_SVC_LV													AS SFST_SVC_LV,
			A.SFST_VAL														AS SFST_VAL,
			A.OPERT_INV_VAL													AS OPERT_INV_VAL,
			CASE WHEN UPPER(A.ROP_SFST_CONSID_YN) = 'T' THEN 'Y'
			     WHEN UPPER(A.ROP_SFST_CONSID_YN) = 'F' THEN 'N'
				 ELSE ISNULL(A.ROP_SFST_CONSID_YN, 'N')
			END																AS ROP_SFST_CONSID_YN,
			CASE WHEN UPPER(A.ROP_OPERT_INV_CONSID_YN) = 'T' THEN 'Y'
			     WHEN UPPER(A.ROP_OPERT_INV_CONSID_YN) = 'F' THEN 'N'
				 ELSE ISNULL(A.ROP_OPERT_INV_CONSID_YN, 'N')
			END																AS ROP_OPERT_INV_CONSID_YN,
			A.ROP_VAL														AS ROP_VAL,
			A.EOQ_MULTIPLE													AS EOQ_MULTIPLE,
			A.EOQ_VAL														AS EOQ_VAL,
			CASE WHEN UPPER(A.TARGET_INV_SFST_CONSID_YN) = 'T' THEN 'Y'
			     WHEN UPPER(A.TARGET_INV_SFST_CONSID_YN) = 'F' THEN 'N'
				 ELSE ISNULL(A.TARGET_INV_SFST_CONSID_YN, 'N')
			END																AS TARGET_INV_SFST_CONSID_YN,
			CASE WHEN UPPER(A.TARGET_INV_OPERT_INV_CONSID_YN) = 'T' THEN 'Y'
			     WHEN UPPER(A.TARGET_INV_OPERT_INV_CONSID_YN) = 'F' THEN 'N'
				 ELSE ISNULL(A.TARGET_INV_OPERT_INV_CONSID_YN, 'N')
			END																AS TARGET_INV_OPERT_INV_CONSID_YN,
			A.TARGET_INV_VAL												AS TARGET_INV_VAL,
			A.MOQ															AS MOQ,
			A.MULTIPLIER													AS MULTIPLIER,
			CASE WHEN UPPER(A.FIXED_YN) = 'T' THEN 'Y'
			     WHEN UPPER(A.FIXED_YN) = 'F' THEN 'N'
				 ELSE ISNULL(A.FIXED_YN, 'N')
			END																AS FIXED_YN,
			CASE WHEN UPPER(A.ACTV_YN) = 'T' THEN 'Y'
			     WHEN UPPER(A.ACTV_YN) = 'F' THEN 'N'
				 ELSE ISNULL(A.ACTV_YN, 'N')
			END																AS ACTV_YN
	FROM    OPENJSON(@P_JSON) WITH
			(	ID								CHAR(32),
				LOCAT_ITEM_ID					CHAR(32),
				LOCAT_CD						NVARCHAR(100),
				ITEM_CD							NVARCHAR(100),
				INV_MGMT_SYSTEM_TP_ID			NVARCHAR(100),
				PO_CYCL_CD						NVARCHAR(100),
				PO_CYCL_CALENDAR				NVARCHAR(100),
				OPERT_BASE_TP					NVARCHAR(100),
				INV_PLACE_STRTGY_ID				NVARCHAR(100),
				SUPPLY_LEADTIME_YN				CHAR,
				OPERT_LV_VAL					DECIMAL(20,3),
				SFST_SVC_LV						DECIMAL(20,3),
				SFST_VAL						DECIMAL(20,3),
				OPERT_INV_VAL					DECIMAL(20,3),
				ROP_SFST_CONSID_YN				CHAR,
				ROP_OPERT_INV_CONSID_YN			CHAR,
				ROP_VAL							DECIMAL(20,3),
				EOQ_MULTIPLE					DECIMAL(20,3),
				EOQ_VAL							DECIMAL(20,3),
				TARGET_INV_SFST_CONSID_YN		CHAR,
				TARGET_INV_OPERT_INV_CONSID_YN	CHAR,
				TARGET_INV_VAL					DECIMAL(20,3),
				MOQ								DECIMAL(20,3),
				MULTIPLIER						DECIMAL(20,3),
				FIXED_YN						CHAR,
				ACTV_YN							CHAR
			) A
			INNER JOIN VW_LOCAT_ITEM_INFO B
			ON B.LOCAT_CD = A.LOCAT_CD
			AND B.ITEM_CD = A.ITEM_CD
			INNER JOIN TB_AD_COMN_CODE C
			ON C.COMN_CD_NM = A.INV_MGMT_SYSTEM_TP_ID
			LEFT OUTER JOIN TB_AD_COMN_CODE D
			ON D.COMN_CD_NM = A.PO_CYCL_CD
			LEFT OUTER JOIN TB_IM_PO_CALENDAR E
			ON E.CALENDAR_ID = A.PO_CYCL_CALENDAR
			LEFT OUTER JOIN TB_AD_COMN_CODE F
			ON F.COMN_CD_NM = A.OPERT_BASE_TP
			LEFT OUTER JOIN TB_AD_COMN_CODE G
			ON G.COMN_CD_NM = A.INV_PLACE_STRTGY_ID

	/***************************************************************************************************************************************************************************
	1-1. UDPATE TYPE 추가
	      - NOTHING : 변경된 값이 없는 데이터
		  - SIMPLE  : 재계산이 필요 하지 않은 데이터
		  - CALCULATE : 재계산이 필요한 데이터
	***************************************************************************************************************************************************************************/
	UPDATE	A
	SET		A.UPDATE_TYPE = CASE WHEN	A.INV_MGMT_SYSTEM_TP_ID = O.INV_MGMT_SYSTEM_TP_ID
									AND A.PO_CYCL_CD_ID = O.PO_CYCL_CD_ID
									AND A.PO_CYCL_CALENDAR_ID = O.PO_CYCL_CALENDAR_ID
									AND A.OPERT_BASE_TP_ID = O.OPERT_BASE_TP_ID
									AND A.INV_PLACE_STRTGY_ID = O.INV_PLACE_STRTGY_ID
									AND A.SUPPLY_LEADTIME_YN = O.SUPPLY_LEADTIME_YN
									AND ISNULL(A.OPERT_LV_VAL, 0) = ISNULL(O.OPERT_LV_VAL, 0)
									AND ISNULL(A.SFST_SVC_LV, 0) = ISNULL(O.SFST_SVC_LV, 0)
									AND A.ROP_SFST_CONSID_YN = O.ROP_SFST_CONSID_YN
									AND A.ROP_OPERT_INV_CONSID_YN = O.ROP_OPERT_INV_CONSID_YN
									AND ISNULL(A.EOQ_MULTIPLE, 0) = ISNULL(O.EOQ_MULTIPLE, 0)
									AND A.TARGET_INV_SFST_CONSID_YN = O.TARGET_INV_SFST_CONSID_YN
									AND A.TARGET_INV_OPERT_INV_CONSID_YN = O.TARGET_INV_OPERT_INV_CONSID_YN
									AND ISNULL(A.SFST_VAL, 0) = ISNULL(O.SFST_VAL, 0)
									AND ISNULL(A.OPERT_INV_VAL, 0) = ISNULL(O.OPERT_INV_VAL, 0)
									AND ISNULL(A.ROP_VAL, 0) = ISNULL(O.ROP_VAL, 0)
									AND ISNULL(A.EOQ_VAL, 0) = ISNULL(O.EOQ_VAL, 0)
									AND ISNULL(A.TARGET_INV_VAL, 0) = ISNULL(O.TARGET_INV_VAL, 0)
									AND ISNULL(A.MOQ, 0) = ISNULL(O.MOQ, 0)
									AND ISNULL(A.MULTIPLIER, 0) = ISNULL(O.MULTIPLIER, 0)
									AND A.FIXED_YN = O.FIXED_YN
									AND A.ACTV_YN = O.ACTV_YN
								THEN 'NOTHING'
								WHEN    A.INV_MGMT_SYSTEM_TP_ID = O.INV_MGMT_SYSTEM_TP_ID
									AND A.PO_CYCL_CD_ID = O.PO_CYCL_CD_ID
									AND A.PO_CYCL_CALENDAR_ID = O.PO_CYCL_CALENDAR_ID
									AND A.OPERT_BASE_TP_ID = O.OPERT_BASE_TP_ID
									AND A.INV_PLACE_STRTGY_ID = O.INV_PLACE_STRTGY_ID
									AND A.SUPPLY_LEADTIME_YN = O.SUPPLY_LEADTIME_YN
									AND ISNULL(A.OPERT_LV_VAL, 0) = ISNULL(O.OPERT_LV_VAL, 0)
									AND ISNULL(A.SFST_SVC_LV, 0) = ISNULL(O.SFST_SVC_LV, 0)
									AND A.ROP_SFST_CONSID_YN = O.ROP_SFST_CONSID_YN
									AND A.ROP_OPERT_INV_CONSID_YN = O.ROP_OPERT_INV_CONSID_YN
									AND ISNULL(A.EOQ_MULTIPLE, 0) = ISNULL(O.EOQ_MULTIPLE, 0)
									AND A.TARGET_INV_SFST_CONSID_YN = O.TARGET_INV_SFST_CONSID_YN
									AND A.TARGET_INV_OPERT_INV_CONSID_YN = O.TARGET_INV_OPERT_INV_CONSID_YN
									AND (ISNULL(A.SFST_VAL, 0) != ISNULL(O.SFST_VAL, 0)
									OR  ISNULL(A.OPERT_INV_VAL, 0) != ISNULL(O.OPERT_INV_VAL, 0)
									OR  ISNULL(A.ROP_VAL, 0) != ISNULL(O.ROP_VAL, 0)
									OR  ISNULL(A.EOQ_VAL, 0) != ISNULL(O.EOQ_VAL, 0)
									OR  ISNULL(A.TARGET_INV_VAL, 0) != ISNULL(O.TARGET_INV_VAL, 0)
									OR  ISNULL(A.MOQ, 0) != ISNULL(O.MOQ, 0)
									OR  ISNULL(A.MULTIPLIER, 0) != ISNULL(O.MULTIPLIER, 0)
									OR  A.FIXED_YN != O.FIXED_YN
									OR  A.ACTV_YN != O.ACTV_YN)
								THEN 'SIMPLE'
								WHEN    (A.INV_MGMT_SYSTEM_TP_ID != O.INV_MGMT_SYSTEM_TP_ID
									OR  A.PO_CYCL_CD_ID != O.PO_CYCL_CD_ID
									OR  A.PO_CYCL_CALENDAR_ID != O.PO_CYCL_CALENDAR_ID
									OR  A.OPERT_BASE_TP_ID != O.OPERT_BASE_TP_ID
									OR  A.INV_PLACE_STRTGY_ID != O.INV_PLACE_STRTGY_ID
									OR  A.SUPPLY_LEADTIME_YN != O.SUPPLY_LEADTIME_YN
									OR  ISNULL(A.OPERT_LV_VAL, 0) != ISNULL(O.OPERT_LV_VAL, 0)
									OR  ISNULL(A.SFST_SVC_LV, 0) != ISNULL(O.SFST_SVC_LV, 0)
									OR  A.ROP_SFST_CONSID_YN != O.ROP_SFST_CONSID_YN
									OR  A.ROP_OPERT_INV_CONSID_YN != O.ROP_OPERT_INV_CONSID_YN
									OR  A.EOQ_MULTIPLE != O.EOQ_MULTIPLE
									OR  A.TARGET_INV_SFST_CONSID_YN != O.TARGET_INV_SFST_CONSID_YN
									OR  A.TARGET_INV_OPERT_INV_CONSID_YN != O.TARGET_INV_OPERT_INV_CONSID_YN)
								THEN 'CALCULATE'
							END
	FROM	#TEMP_IM_INV_POLICY_ITEM A
			INNER JOIN TB_IM_INV_POLICY_ITEM O
			ON O.ID = A.ID

	/***************************************************************************************************************************************************************************
	1-2. 단순 변경 데이터 수정 후 삭제
	***************************************************************************************************************************************************************************/
	UPDATE	A
	SET		A.SFST_VAL = B.SFST_VAL,
			A.OPERT_INV_VAL = B.OPERT_INV_VAL,
			A.ROP_VAL = B.ROP_VAL,
			A.EOQ_VAL = B.EOQ_VAL,
			A.TARGET_INV_VAL = B.TARGET_INV_VAL,
			A.MOQ = B.MOQ,
			A.MULTIPLIER = B.MULTIPLIER,
			A.FIXED_YN = B.FIXED_YN,
			A.ACTV_YN = B.ACTV_YN,
			A.MODIFY_BY = @P_USER_ID,
			A.MODIFY_DTTM = GETDATE()
	FROM	TB_IM_INV_POLICY_ITEM A
			INNER JOIN #TEMP_IM_INV_POLICY_ITEM B
			ON B.ID = A.ID
	WHERE	B.UPDATE_TYPE = 'SIMPLE'

	/***************************************************************************************************************************************************************************
	1-3. 변경 없는 데이터 삭제
	***************************************************************************************************************************************************************************/
	DELETE FROM #TEMP_IM_INV_POLICY_ITEM
	WHERE UPDATE_TYPE IN ('NOTHING', 'SIMPLE')

	SELECT * FROM #TEMP_IM_INV_POLICY_ITEM
	SELECT ID,LOCAT_ITEM_ID,INV_MGMT_SYSTEM_TP_ID,PO_CYCL_CD_ID,PO_CYCL_YN,PO_CYCL_CALENDAR_ID,OPERT_BASE_TP_ID,INV_PLACE_STRTGY_ID,SUPPLY_LEADTIME_YN,OPERT_LV_VAL,SFST_SVC_LV
		,SFST_VAL,OPERT_INV_VAL,ROP_SFST_CONSID_YN,ROP_OPERT_INV_CONSID_YN,ROP_VAL,EOQ_MULTIPLE,EOQ_VAL,TARGET_INV_SFST_CONSID_YN,TARGET_INV_OPERT_INV_CONSID_YN,TARGET_INV_VAL
		,MOQ,MULTIPLIER,FIXED_YN,ACTV_YN 
	FROM TB_IM_INV_POLICY_ITEM
	WHERE ID IN (select ID from #TEMP_IM_INV_POLICY_ITEM)

	/***************************************************************************************************************************************************************************
	1-4. 재고정책 재계산
	***************************************************************************************************************************************************************************/
	SELECT	@V_DATA_CNT = COUNT(1)
	FROM	#TEMP_IM_INV_POLICY_ITEM
	WHERE	UPDATE_TYPE = 'CALCULATE'

	IF @V_DATA_CNT > 0
	BEGIN
		/***************************************************************************************************************************************************************************
		2. 운영목표
		 - 보충리드타임 : (체크된 경우) 공급리드타임 + (체크된 경우) 발주주기
		   * 공급리드타임 : 공급변동성 분석 데이터 참조
		   * 발주주기     : 발주주기 Daily Calendar : 7 / 체크된 요일 개수
							발주주기 Monthly Calendar : 31 / 체크된 일자 개수
		 - 운영목표 : 보충 리드타임 + 운영수준
		***************************************************************************************************************************************************************************/
		CREATE TABLE #TEMP_PO_CYCL_VAL (
			LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
			PO_CYCL_VAL					DECIMAL(20,3)
		)

		CREATE TABLE #TEMP_OPERT_TARGET (
			LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
			REPLSH_LEADTIME				DECIMAL(20,3),
			OPERT_TARGET_VAL			DECIMAL(20,3)
		)

		INSERT INTO #TEMP_PO_CYCL_VAL
		(
			LOCAT_ITEM_ID,
			PO_CYCL_VAL
		)
		SELECT	A.LOCAT_ITEM_ID,
				CASE WHEN SUM(CASE WHEN ISNULL(G.ACTV_YN,'N') = 'Y' THEN 1 ELSE 0 END) = 0 THEN 0
					 ELSE CAST(COUNT(*) AS DECIMAL(20,3)) / SUM(CASE WHEN ISNULL(G.ACTV_YN,'N') = 'Y' THEN 1 ELSE 0 END)
				END	 PO_CYCL_VAL
		FROM	#TEMP_IM_INV_POLICY_ITEM A
				INNER JOIN TB_IM_PO_CALENDAR E
				ON E.ID = A.PO_CYCL_CALENDAR_ID
				INNER JOIN TB_AD_COMN_CODE F
				ON F.ID = E.PO_CYCL_TP_ID
				LEFT OUTER JOIN TB_IM_PO_MONTHLY_SCH G
				ON E.ID = G.PO_CYCL_CALENDAR_ID
		WHERE	F.COMN_CD = 'MONTHLY'
		GROUP   BY A.LOCAT_ITEM_ID
		UNION ALL
		SELECT	A.LOCAT_ITEM_ID,
				CASE WHEN SUM(CASE WHEN ISNULL(G.CHECK_YN,'N') = 'Y' THEN 1 ELSE 0 END) = 0 THEN 0
					 ELSE CAST(COUNT(*) AS DECIMAL(20,3)) / SUM(CASE WHEN ISNULL(G.CHECK_YN,'N') = 'Y' THEN 1 ELSE 0 END)
				END  PO_CYCL_VAL
		FROM	#TEMP_IM_INV_POLICY_ITEM A
				INNER JOIN TB_IM_PO_CALENDAR E
				ON E.ID = A.PO_CYCL_CALENDAR_ID
				INNER JOIN TB_AD_COMN_CODE F
				ON F.ID = E.PO_CYCL_TP_ID
				LEFT OUTER JOIN
				(
				SELECT	A.PO_CYCL_CALENDAR_ID,
						A.WK_CD,
						A.CHECK_YN
				FROM	TB_IM_PO_DAILY_SCH A
						UNPIVOT (CHECK_YN FOR WK_CD IN (MON_YN, 
														TUE_YN, 
														WED_YN, 
														THU_YN, 
														FRI_YN, 
														SAT_YN, 
														SUN_YN)
        						) A
				) G
				ON E.ID = G.PO_CYCL_CALENDAR_ID
		WHERE	F.COMN_CD = 'DAILY'
		GROUP	BY A.LOCAT_ITEM_ID

		INSERT INTO #TEMP_OPERT_TARGET
		(
			LOCAT_ITEM_ID,
			REPLSH_LEADTIME,
			OPERT_TARGET_VAL
		)
		SELECT	A.LOCAT_ITEM_ID,
				IIF(A.REPLSH_LEADTIME = 0, 1, A.REPLSH_LEADTIME) AS REPLSH_LEADTIME,
				IIF(A.REPLSH_LEADTIME = 0, 1, A.REPLSH_LEADTIME) + ISNULL(A.OPERT_LV_VAL, 0) AS OPERT_TARGET_VAL
		FROM	(
				SELECT	A.LOCAT_ITEM_ID,
						E.SUPPLY_LEADTIME_AVG,
						F.PO_CYCL_VAL,
						A.OPERT_LV_VAL,
						(CASE WHEN A.SUPPLY_LEADTIME_YN = 'Y' THEN ISNULL(E.SUPPLY_LEADTIME_AVG, 0) ELSE 0 END) + (CASE WHEN A.PO_CYCL_YN = 'Y' THEN ISNULL(F.PO_CYCL_VAL, 0) ELSE 0 END) AS REPLSH_LEADTIME
				FROM	#TEMP_IM_INV_POLICY_ITEM A
						LEFT OUTER JOIN TB_IM_SPPLY_VARAN_ANLYS_MST E
						ON E.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
						LEFT OUTER JOIN #TEMP_PO_CYCL_VAL F
						ON F.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
				WHERE	1=1
				) A
			
		/***************************************************************************************************************************************************************************
		3. 수요율 계산
		***************************************************************************************************************************************************************************/
		CREATE TABLE #TEMP_DMND_RATE_ACTUAL_ALL (
			LOCAT_ITEM_ID			CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
			QTY						DECIMAL(20,3),
			MIN_QTY					DECIMAL(20,3),
			MAX_QTY					DECIMAL(20,3)
		)

		INSERT INTO #TEMP_DMND_RATE_ACTUAL_ALL
		(
			LOCAT_ITEM_ID,
			QTY,
			MIN_QTY,
			MAX_QTY
		)
		SELECT	A.SUPPLY_LOCAT_ITEM_ID,
				SUM(A.QTY) / MIN(A.BUCKET_CNT) AS QTY,
				MIN(A.MIN_QTY) AS MIN_QTY,
				MAX(A.MAX_QTY) AS MAX_QTY
		FROM	(
				SELECT	A.SUPPLY_LOCAT_ITEM_ID,
						A.ATD,
						D.BUCKET_CNT,
						SUM(A.SHPP_QTY) AS QTY,
						MIN(A.SHPP_QTY) AS MIN_QTY,
						MAX(A.SHPP_QTY) AS MAX_QTY
				FROM	TB_CM_ACTUAL_SHIPMENT A
						INNER JOIN TB_CM_SITE_ITEM B
						ON B.ID = A.SUPPLY_LOCAT_ITEM_ID
						INNER JOIN #TEMP_IM_INV_POLICY_ITEM X
						ON B.ID = X.LOCAT_ITEM_ID
						INNER JOIN TB_CM_LOC_MGMT C
						ON C.ID = B.LOCAT_MGMT_ID
						LEFT OUTER JOIN 
						(
						SELECT	LOCAT_ID, START_DATE, END_DATE,
								(SELECT VAL FROM DBO.FN_G_BUCKET_CNT(@V_TIME_BUCKET, A.START_DATE, A.END_DATE)) AS BUCKET_CNT
						FROM	(
								SELECT	LOCAT_ID, 
										(SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.ACTUAL_PERIOD, 'START', B.UOM_CD)) AS START_DATE,
										(SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.ACTUAL_PERIOD, 'END', B.UOM_CD)) AS END_DATE
								FROM	TB_IM_VARIABILITY_ACT_PRIOD A
										INNER JOIN TB_CM_UOM B
										ON B.ID = A.UOM_ID
								WHERE	CATAGY_VAL = 'DEMAND_RATE'
								) A
						) D
						ON D.LOCAT_ID = C.LOCAT_ID
				WHERE	1=1
				AND		ISNULL(B.ACTV_YN, 'N') = 'Y'
				AND		ISNULL(C.ACTV_YN, 'N') = 'Y'
				AND		A.ATD BETWEEN D.START_DATE AND D.END_DATE
				GROUP	BY A.SUPPLY_LOCAT_ITEM_ID, D.BUCKET_CNT, A.ATD
				) A
		GROUP	BY A.SUPPLY_LOCAT_ITEM_ID

		/***************************************************************************************************************************************************************************
		5. 안전재고
		 - 제안SL(%) : Configuration 목표 서비스 수준 산출 기준 으로 계산
		 - 목표 서비스 수준 산출 기준 : TB_IM_TARGET_SVC_CAL_BASE 테이블의 각 거점 별 목표 서비스 산출 기준에 따라 선택됨
			.COV 일 경우 수요 변동성 분석에서 서비스 수준 제안 값 (TB_IM_DMND_VARAN_ANLYS_MST.PRPSAL_SVC_LV_VAL)
			.SABC 일 경우 SABC 분석에서 서비스 수준 제안 값 (TB_IM_SABC_ANALYSIS_MST.PRPSAL_SVC_LV)

		 - 목표 SL(%) : 제안 SL 값과 동일값으로 등록 이후 사용자 변경 가능
		 - 수요변동 표준편차 : 수요변동성 분석의 표준편차 값 (TB_IM_DMND_VARAN_ANLYS_MST.DEVIT)
		 - 공급변동 표준편차 : 공급변동성 분석의 표준편차 값 (TB_IM_SPPLY_VARAN_ANLYS_MST.SUPPLY_LEADTIME_DEVIT)

		 - 수요율 : 거점 별로 선택된 수요율 산출 계산 방식에 따른 수요율 값
					Actual (All), Actual (YoY), Forecast (All), Forecast (Target)

		 - 제안 안전재고 : 수요변동성 고려 및 공급변동성 고려 체크 여부에 따라 안전재고 공식 기준으로 계산
		   [수요변동성만 고려 시]
			=> 안전계수 * SQRT(보충리드타임) * 수요변동성 표준편차
			   안전계수 : 목표 SL에 대해서 Configuration 안전재고 목표 서비스 수준 / 안전계수 기준 참조
			   보충리드타임 : 목표재고 시스템(정기) : 공급리드타임 + 발주주기
							  주문점 시스템(비정기) : 공급리드타임
							  Min/Max 시스템(정기) : 공급리드타임 + 발주주기
							  Rule Based 시스템(비정기) : 공급리드타임

		   [공급변동성 고려 시]
			=> 안전계수 * SQRT(보충리드타임 * POWER(수요변동성 표준편차,2) + POWER(수요율,2) * POWER(공급리드타임 표준편차,2))

		 - 안전재고 : 제안 SL 값과 동일값으로 등록 이후 사용자 변경 가능
		***************************************************************************************************************************************************************************/
		CREATE TABLE #TEMP_SFST
		(
			LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
			PRPSAL_SVC_LV				DECIMAL(20,3),
			SFST_SVC_LV					DECIMAL(20,3),
			SFST_PRPSAL_VAL				DECIMAL(20,3)
		)

		INSERT INTO #TEMP_SFST
		(
			LOCAT_ITEM_ID,
			PRPSAL_SVC_LV,
			SFST_SVC_LV,
			SFST_PRPSAL_VAL
		)
		SELECT	A.LOCAT_ITEM_ID,
				A.PRPSAL_SVC_LV,
				A.SFST_SVC_LV,
				CASE WHEN A.SFST_SUPYVAR_CONSID_YN = 'N' THEN A.SFST_PRPSAL_VAL_01 ELSE A.SFST_PRPSAL_VAL_02 END AS SFST_PRPSAL_VAL
		FROM	(
				SELECT	A.LOCAT_ITEM_ID,
						B.PRPSAL_SVC_LV,
						A.SFST_SVC_LV,
						B.SFST_DEMDVAR_CONSID_YN,
						B.SFST_DEMDVAR_STDDEV,
						B.SFST_SUPYVAR_CONSID_YN,
						B.SFST_DMND_RATE_CAL_TP_ID,
						B.SFST_DMND_RATE,
						B.SUPYVAR_STDDEV,
						A.SAFTFCT * SQRT(F.REPLSH_LEADTIME) * ISNULL(B.SFST_DEMDVAR_STDDEV, 0) AS SFST_PRPSAL_VAL_01,
						A.SAFTFCT * SQRT(F.REPLSH_LEADTIME * POWER(ISNULL(B.SFST_DEMDVAR_STDDEV, 0), 2) + POWER(B.SFST_DMND_RATE, 2) * POWER(ISNULL(B.SUPYVAR_STDDEV,0), 2)) AS SFST_PRPSAL_VAL_02
				FROM	(
						SELECT	A.*,
								(SELECT ISNULL(MAX(SAFTFCT),0) FROM TB_IM_SVC_SAFTFCT_BASE B WHERE B.SVC_LV <= A.SFST_SVC_LV) AS SAFTFCT
						FROM	#TEMP_IM_INV_POLICY_ITEM A
						) A
						INNER JOIN TB_IM_INV_POLICY_ITEM B
						ON B.ID = A.ID
						LEFT OUTER JOIN #TEMP_OPERT_TARGET F
						ON F.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
				WHERE	1=1
				) A

		/***************************************************************************************************************************************************************************
		6. 운영재고
		 - 제안 운영재고 : 운영목표 * 수요율
		 - 운영재고 : 제안 운영재고 값과 동일값으로 등록 이후 사용자 변경 가능
		***************************************************************************************************************************************************************************/
		CREATE TABLE #TEMP_OPERT_INV 
		(
			LOCAT_ITEM_ID						CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
			--OPERT_INV_DMND_RATE_CAL_MTD_ID		CHAR(32),
			--OPERT_INV_DMND_RATE					DECIMAL(20,3),
			OPERT_INV_PRPSAL_VAL				DECIMAL(20,3)
		)

		INSERT INTO #TEMP_OPERT_INV
		(
			LOCAT_ITEM_ID,
			--OPERT_INV_DMND_RATE_CAL_MTD_ID,
			--OPERT_INV_DMND_RATE,
			OPERT_INV_PRPSAL_VAL
		)
		SELECT	A.LOCAT_ITEM_ID,
				--B.OPERT_INV_DMND_RATE_CAL_MTD_ID,
				--B.OPERT_INV_DMND_RATE,
				A.OPERT_TARGET_VAL * B.OPERT_INV_DMND_RATE AS OPERT_INV_PRPSAL_VAL
		FROM	#TEMP_OPERT_TARGET A
				INNER JOIN TB_IM_INV_POLICY_ITEM B
				ON B.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID

		/***************************************************************************************************************************************************************************
		7. EOQ 
		 - EOQ 계산 방식
		   EOQDR01	EOQ (경제적 주문량)
		   EOQDR02	평균 발주량

		 - EOQ
		  .제안 EOQ : EOQ 계산 공식에 의해 계산
			   - SQRT(2 * 연간소요량 * 1회 발주비) / (제품 단가*재고유지비율) or SQRT(2 * 연간소요량 * 주문비용) / 재고보관비용
			   - 연간 소요량은 FORECAST ALL 값으로 함
		   .EOQ : 제안 EOQ 값과 동일값으로 등록 이후 사용자 변경 가능
  
		 - 평균 발주량
		   .제안 EOQ : Actual (ALL) 과거 실적 기준으로 1회 평균 발주량 제시 (전체 실적의 총 평균)

		 - 정률이 체크된 경우
		  .제안 EOQ : 수요율 * 정률 Target
		   - 정률 Target : EOQ / (Time Bucket이 Day이면 일평균 출하실적, Time Bucket이 Week이면 주평균 출하실적, Time Bucket이 Month이면 월평균 출하실적)
		  .EOQ : 제안 EOQ 값과 동일값으로 등록 이후 사용자 변경 가능
		***************************************************************************************************************************************************************************/
		CREATE TABLE #TEMP_EOQ
		(
			LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
			EOQ_PRPSAL_VAL				DECIMAL(20,3)
		)

		INSERT INTO #TEMP_EOQ
		(
			LOCAT_ITEM_ID,
			EOQ_PRPSAL_VAL
		)
		SELECT	A.LOCAT_ITEM_ID,
				CASE WHEN A.EOQ_CAL_TP_CD = 'EOQDR01' AND A.EOQ_RIGHT_RATE_YN = 'N' THEN A.EOQ * EOQ_MULTIPLE
					 WHEN A.EOQ_CAL_TP_CD = 'EOQDR01' AND A.EOQ_RIGHT_RATE_YN = 'Y' THEN ISNULL(A.DMND_RATE, 0) * ISNULL(A.EOQ_RIGHT_RATE_TARGET, 0)
					 WHEN A.EOQ_CAL_TP_CD = 'EOQDR02' AND A.EOQ_RIGHT_RATE_YN = 'N' THEN A.AVG_PO_QTY * EOQ_MULTIPLE
					 WHEN A.EOQ_CAL_TP_CD = 'EOQDR02' AND A.EOQ_RIGHT_RATE_YN = 'Y' THEN ISNULL(A.DMND_RATE, 0) * ISNULL(A.AVG_PO_RIGHT_RATE_TARGET, 0)
					 ELSE NULL
				END AS EOQ_PRPSAL_VAL
		FROM	(
				SELECT	A.LOCAT_ITEM_ID,
						D.EOQ_CAL_TP_ID,
						E.COMN_CD AS EOQ_CAL_TP_CD,
						D.EOQ_DMND_RATE AS DMND_RATE,
						F.EOQ AS EOQ,
						G.QTY AS AVG_PO_QTY,
						CASE WHEN ISNULL(H.QTY, 0) = 0 THEN 0 ELSE ROUND((ISNULL(F.EOQ, 0) * ISNULL(D.EOQ_MULTIPLE, 1)) / H.QTY, 3) END AS EOQ_RIGHT_RATE_TARGET,
						CASE WHEN ISNULL(H.QTY, 0) = 0 THEN 0 ELSE ROUND((ISNULL(G.QTY, 0) * ISNULL(D.EOQ_MULTIPLE, 1)) / H.QTY, 3) END AS AVG_PO_RIGHT_RATE_TARGET,
						D.EOQ_RIGHT_RATE_YN,
						ISNULL(D.EOQ_MULTIPLE, 1) AS EOQ_MULTIPLE
				FROM	#TEMP_IM_INV_POLICY_ITEM A
						INNER JOIN TB_CM_SITE_ITEM B
						ON B.ID = A.LOCAT_ITEM_ID
						INNER JOIN TB_CM_LOC_MGMT C
						ON C.ID = B.LOCAT_MGMT_ID
						INNER JOIN TB_IM_INV_POLICY_ITEM D
						ON D.ID = A.ID
						LEFT OUTER JOIN TB_AD_COMN_CODE E
						ON E.ID = D.EOQ_CAL_TP_ID
						LEFT OUTER JOIN 
						(
						SELECT	A.LOCAT_ITEM_ID,
								CASE WHEN ISNULL(A.INV_KEEPING_VAL ,0) = 0 THEN 0
									 ELSE SQRT((2 * ISNULL(B.QTY, 0) * ISNULL(A.ORDER_COST_VAL, 0)) / ISNULL(A.INV_KEEPING_VAL, 0))
								END AS EOQ
						FROM	TB_IM_INV_COST A
								LEFT OUTER JOIN #TEMP_DMND_RATE_ACTUAL_ALL B
								ON B.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
						) F
						ON F.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
						LEFT OUTER JOIN #TEMP_DMND_RATE_ACTUAL_ALL G
						ON G.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
						LEFT OUTER JOIN #TEMP_DMND_RATE_ACTUAL_ALL H
						ON H.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
				WHERE	1=1
				) A

		/***************************************************************************************************************************************************************************
		8. ROP
		 - ROP 계산 방식
		   ROPDR01	정규성
		   ROPDR02	평균 출하
		   ROPDR03	최대 출하
		   ROPDR04	최소 출하
		   ROPDR05	평균 재고

		 - 정규성
		  .제안ROP : (체크된) 안전재고 + (체크된) 운영재고
		  .ROP : 제안 ROP 값과 동일값으로 등록 이후 사용자 변경 가능

		 - 평균재고
		  .제안ROP : (Warehouse Stock + In-Transit Stock) - 발주량 / 2
		  .ROP : 제안 ROP 값과 동일값으로 등록 이후 사용자 변경 가능
  
		 - 평균/최대/최소 출하
		  .제안ROP : 과거 실적 구간에서 평균, 최대, 최소 출하 량으로 단순 계산함
		  .ROP : 제안 ROP 값과 동일값으로 등록 이후 사용자 변경 가능

		 - 정률이 체크된 경우
		  .제안 ROP : 수요율 * 정률 Target
		   - 정률 Target : ROP / (Time Bucket이 Day이면 일평균 출하실적, Time Bucket이 Week이면 주평균 출하실적, Time Bucket이 Month이면 월평균 출하실적)
		  .ROP : 제안 ROP 값과 동일값으로 등록 이후 사용자 변경 가능
		***************************************************************************************************************************************************************************/
		CREATE TABLE #TEMP_STD_ROP
		(
			LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
			STD_ROP						DECIMAL(20,3)
		)

		CREATE TABLE #TEMP_ROP
		(
			LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
			ROP_PRPSAL_VAL				DECIMAL(20,3)
		)

		INSERT INTO #TEMP_STD_ROP
		(
			LOCAT_ITEM_ID,
			STD_ROP
		)
		SELECT	A.LOCAT_ITEM_ID,
				CASE WHEN A.ROP_OPERT_INV_CONSID_YN = 'Y' AND A.ROP_SFST_CONSID_YN = 'Y'  THEN E.OPERT_INV_PRPSAL_VAL + F.SFST_PRPSAL_VAL
					 WHEN A.ROP_OPERT_INV_CONSID_YN = 'Y' AND A.ROP_SFST_CONSID_YN = 'N'  THEN E.OPERT_INV_PRPSAL_VAL
					 WHEN A.ROP_OPERT_INV_CONSID_YN = 'N' AND A.ROP_SFST_CONSID_YN = 'Y'  THEN F.SFST_PRPSAL_VAL
				ELSE NULL
				END STD_ROP
		FROM	#TEMP_IM_INV_POLICY_ITEM A
				LEFT OUTER JOIN #TEMP_OPERT_INV E
				ON E.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
				LEFT OUTER JOIN #TEMP_SFST F
				ON F.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
		WHERE	1=1
		
		INSERT INTO #TEMP_ROP
		(
			LOCAT_ITEM_ID,
			ROP_PRPSAL_VAL
		)
		SELECT	A.LOCAT_ITEM_ID,
				CASE WHEN E.COMN_CD = 'ROPDR01' AND D.ROP_RIGHT_RATE_YN = 'N' THEN F.STD_ROP
					 WHEN E.COMN_CD = 'ROPDR01' AND D.ROP_RIGHT_RATE_YN = 'Y' THEN D.ROP_DMND_RATE * (IIF(H.QTY = 0, 0, ISNULL(F.STD_ROP, 0) / H.QTY))
					 ELSE D.ROP_PRPSAL_VAL
				END AS ROP_PRPSAL_VAL
		FROM	#TEMP_IM_INV_POLICY_ITEM A
				LEFT OUTER JOIN TB_IM_INV_POLICY_ITEM D
				ON D.ID = A.ID
				LEFT OUTER JOIN TB_AD_COMN_CODE E
				ON E.ID = D.ROP_CAL_TP_ID
				LEFT OUTER JOIN #TEMP_STD_ROP F
				ON F.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
				LEFT OUTER JOIN #TEMP_DMND_RATE_ACTUAL_ALL H
				ON H.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
		WHERE	1=1

		/***************************************************************************************************************************************************************************
		9. 목표재고
		 - 제안 목표재고 : (체크된) 안전재고 + (체크된) 운영재고
		 - 목표재고 : 제안 목표재고값과 동일값으로 등록 이후 사용자 변경 가능
		***************************************************************************************************************************************************************************/
		CREATE TABLE #TEMP_TARGET_INV
		(
			LOCAT_ITEM_ID						CHAR(32) COLLATE DATABASE_DEFAULT PRIMARY KEY,
			TARGET_INV_PRPSAL_VAL				DECIMAL(20,3)
		)

		INSERT INTO #TEMP_TARGET_INV
		(
			LOCAT_ITEM_ID,
			TARGET_INV_PRPSAL_VAL
		)
		SELECT	A.LOCAT_ITEM_ID,
				CASE WHEN A.TARGET_INV_SFST_CONSID_YN = 'Y' AND A.TARGET_INV_OPERT_INV_CONSID_YN = 'N' THEN F.SFST_PRPSAL_VAL
					 WHEN A.TARGET_INV_SFST_CONSID_YN = 'N' AND A.TARGET_INV_OPERT_INV_CONSID_YN = 'Y' THEN E.OPERT_INV_PRPSAL_VAL
					 WHEN A.TARGET_INV_SFST_CONSID_YN = 'Y' AND A.TARGET_INV_OPERT_INV_CONSID_YN = 'Y' THEN E.OPERT_INV_PRPSAL_VAL + F.SFST_PRPSAL_VAL
					 ELSE NULL
				END AS TARGET_INV_PRPSAL_VAL
		FROM	#TEMP_IM_INV_POLICY_ITEM A
				LEFT OUTER JOIN #TEMP_OPERT_INV E
				ON E.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
				LEFT OUTER JOIN #TEMP_SFST F
				ON F.LOCAT_ITEM_ID = A.LOCAT_ITEM_ID
		WHERE	1=1

		/***************************************************************************************************************************************************************************
		10. 재고정책상세 데이터 업데이트
		  - 확정 데이터(FIXED_YN = 'Y')는 제안값만 수정
		  - 나머지 데이터는 제안값, 실제값 모두 수정
		  - 단, 실제값은 사용자가 변경한 경우 그대로 사용
		***************************************************************************************************************************************************************************/
		MERGE INTO TB_IM_INV_POLICY_ITEM TARGET
		USING 
		(
			SELECT	A.LOCAT_ITEM_ID,
					A.INV_MGMT_SYSTEM_TP_ID				AS PRPSAL_INV_MGMT_SYSTEM_TP_ID,
					A.INV_MGMT_SYSTEM_TP_ID,
					A.PO_CYCL_CD_ID,
					A.PO_CYCL_CALENDAR_ID				AS PO_CYCL_CALENDAR_ID,
					A.OPERT_BASE_TP_ID,
					A.INV_PLACE_STRTGY_ID,
					A.SUPPLY_LEADTIME_YN,
					A.PO_CYCL_YN,
					I.REPLSH_LEADTIME,
					G.OPERT_LV_VAL,
					I.OPERT_TARGET_VAL,
					J.PRPSAL_SVC_LV,
					J.SFST_SVC_LV,
					CEILING(J.SFST_PRPSAL_VAL)			AS SFST_PRPSAL_VAL,
					CASE WHEN G.SFST_VAL != A.SFST_VAL THEN A.SFST_VAL
					     WHEN A.FIXED_YN = 'Y' THEN G.SFST_VAL
						 ELSE CEILING(J.SFST_PRPSAL_VAL)
					END									AS SFST_VAL,
					A.ROP_SFST_CONSID_YN,
					A.ROP_OPERT_INV_CONSID_YN,
					CEILING(L.ROP_PRPSAL_VAL)			AS ROP_PRPSAL_VAL,
					CASE WHEN G.ROP_VAL != A.ROP_VAL THEN A.ROP_VAL
					     WHEN A.FIXED_YN = 'Y' THEN G.ROP_VAL
						 ELSE CEILING(L.ROP_PRPSAL_VAL)
					END									AS ROP_VAL,
					G.EOQ_MULTIPLE,
					CEILING(M.EOQ_PRPSAL_VAL)			AS EOQ_PRPSAL_VAL,
					CASE WHEN G.EOQ_VAL != A.EOQ_VAL THEN A.EOQ_VAL
					     WHEN A.FIXED_YN = 'Y' THEN G.EOQ_VAL
						 ELSE CEILING(M.EOQ_PRPSAL_VAL)
					END									AS EOQ_VAL,
					CEILING(K.OPERT_INV_PRPSAL_VAL)		AS OPERT_INV_PRPSAL_VAL,
					CASE WHEN G.OPERT_INV_VAL != A.OPERT_INV_VAL THEN A.OPERT_INV_VAL
					     WHEN A.FIXED_YN = 'Y' THEN G.OPERT_INV_VAL
						 ELSE CEILING(K.OPERT_INV_PRPSAL_VAL)
					END									AS OPERT_INV_VAL,
					A.TARGET_INV_SFST_CONSID_YN,
					A.TARGET_INV_OPERT_INV_CONSID_YN,
					CEILING(N.TARGET_INV_PRPSAL_VAL)	AS TARGET_INV_PRPSAL_VAL,
					CASE WHEN G.TARGET_INV_VAL != A.TARGET_INV_VAL THEN A.TARGET_INV_VAL
					     WHEN A.FIXED_YN = 'Y' THEN G.TARGET_INV_VAL
						 ELSE CEILING(N.TARGET_INV_PRPSAL_VAL)
					END									AS TARGET_INV_VAL,
					A.MOQ,
					A.MULTIPLIER,
					A.FIXED_YN,
					A.ACTV_YN
			FROM	#TEMP_IM_INV_POLICY_ITEM A
					LEFT OUTER JOIN TB_IM_INV_POLICY_ITEM G
					ON A.ID = G.ID
					LEFT OUTER JOIN #TEMP_OPERT_TARGET I
					ON A.LOCAT_ITEM_ID = I.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_SFST J
					ON A.LOCAT_ITEM_ID = J.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_OPERT_INV K
					ON A.LOCAT_ITEM_ID = K.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_ROP L
					ON A.LOCAT_ITEM_ID = L.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_EOQ M
					ON A.LOCAT_ITEM_ID = M.LOCAT_ITEM_ID
					LEFT OUTER JOIN #TEMP_TARGET_INV N
					ON A.LOCAT_ITEM_ID = N.LOCAT_ITEM_ID
			WHERE	1=1

		) SOURCE 
		ON ( TARGET.LOCAT_ITEM_ID = SOURCE.LOCAT_ITEM_ID )
		WHEN MATCHED THEN
			UPDATE 
				SET   
					TARGET.PRPSAL_INV_MGMT_SYSTEM_TP_ID		= SOURCE.PRPSAL_INV_MGMT_SYSTEM_TP_ID,
					TARGET.INV_MGMT_SYSTEM_TP_ID			= SOURCE.INV_MGMT_SYSTEM_TP_ID,
					TARGET.PO_CYCL_CD_ID					= SOURCE.PO_CYCL_CD_ID,
					TARGET.PO_CYCL_CALENDAR_ID				= SOURCE.PO_CYCL_CALENDAR_ID,
					TARGET.OPERT_BASE_TP_ID					= SOURCE.OPERT_BASE_TP_ID,
					TARGET.INV_PLACE_STRTGY_ID				= SOURCE.INV_PLACE_STRTGY_ID,
					TARGET.SUPPLY_LEADTIME_YN				= SOURCE.SUPPLY_LEADTIME_YN,
					TARGET.PO_CYCL_YN						= SOURCE.PO_CYCL_YN,
					TARGET.REPLSH_LEADTIME					= SOURCE.REPLSH_LEADTIME,
					TARGET.OPERT_LV_VAL						= SOURCE.OPERT_LV_VAL,
					TARGET.OPERT_TARGET_VAL					= SOURCE.OPERT_TARGET_VAL,
					TARGET.PRPSAL_SVC_LV					= SOURCE.PRPSAL_SVC_LV,
					TARGET.SFST_SVC_LV						= SOURCE.SFST_SVC_LV,
					TARGET.SFST_PRPSAL_VAL					= SOURCE.SFST_PRPSAL_VAL,
					TARGET.SFST_VAL							= SOURCE.SFST_VAL,
					TARGET.ROP_SFST_CONSID_YN				= SOURCE.ROP_SFST_CONSID_YN,
					TARGET.ROP_OPERT_INV_CONSID_YN			= SOURCE.ROP_OPERT_INV_CONSID_YN,
					TARGET.ROP_PRPSAL_VAL					= SOURCE.ROP_PRPSAL_VAL,
					TARGET.ROP_VAL							= SOURCE.ROP_VAL,
					TARGET.EOQ_MULTIPLE						= SOURCE.EOQ_MULTIPLE,
					TARGET.EOQ_PRPSAL_VAL					= SOURCE.EOQ_PRPSAL_VAL,
					TARGET.EOQ_VAL							= SOURCE.EOQ_VAL,
					TARGET.OPERT_INV_PRPSAL_VAL				= SOURCE.OPERT_INV_PRPSAL_VAL,
					TARGET.OPERT_INV_VAL					= SOURCE.OPERT_INV_VAL,
					TARGET.TARGET_INV_SFST_CONSID_YN		= SOURCE.TARGET_INV_SFST_CONSID_YN,
					TARGET.TARGET_INV_OPERT_INV_CONSID_YN	= SOURCE.TARGET_INV_OPERT_INV_CONSID_YN,
					TARGET.TARGET_INV_PRPSAL_VAL			= SOURCE.TARGET_INV_PRPSAL_VAL,
					TARGET.TARGET_INV_VAL					= SOURCE.TARGET_INV_VAL,
					TARGET.MOQ								= SOURCE.MOQ,
					TARGET.MULTIPLIER                       = SOURCE.MULTIPLIER,
					TARGET.FIXED_YN							= SOURCE.FIXED_YN,
					TARGET.ACTV_YN							= SOURCE.ACTV_YN,
					TARGET.MODIFY_BY						= @P_USER_ID,
					TARGET.MODIFY_DTTM 						= GETDATE();

	END

	DROP TABLE #TEMP_IM_INV_POLICY_ITEM
	IF @V_DATA_CNT > 0
	BEGIN
		DROP TABLE #TEMP_PO_CYCL_VAL
		DROP TABLE #TEMP_OPERT_TARGET
		DROP TABLE #TEMP_DMND_RATE_ACTUAL_ALL
		DROP TABLE #TEMP_SFST
		DROP TABLE #TEMP_OPERT_INV
		DROP TABLE #TEMP_EOQ
		DROP TABLE #TEMP_STD_ROP
		DROP TABLE #TEMP_ROP
		DROP TABLE #TEMP_TARGET_INV
	END

	SET @P_RT_ROLLBACK_FLAG = 'true'
	SET @P_RT_MSG = 'MSG_0001'

END TRY

BEGIN CATCH
	IF(ERROR_MESSAGE() LIKE 'MSG_%')
		BEGIN
			SET @P_ERR_MSG = ERROR_MESSAGE()
			SET @P_RT_ROLLBACK_FLAG = 'false'
			SET @P_RT_MSG = @P_ERR_MSG
		END
	ELSE
		THROW
END CATCH
go

