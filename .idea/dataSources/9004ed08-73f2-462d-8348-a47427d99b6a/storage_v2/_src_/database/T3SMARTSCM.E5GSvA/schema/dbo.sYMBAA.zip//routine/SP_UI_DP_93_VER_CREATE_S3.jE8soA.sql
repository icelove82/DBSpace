/************************************************************************************************************
Title : [SP_UI_DP_93_VER_CREATE_S3]
최초 작성자 : Kim Sohee
최초 생성일 : 2020.05.07
 
Description
 - Make DP Entry Init Data
 
History (수정일자 / 수정자 / 수정내용)
- 2020.05.07 / Kim Sohee / Draft 
	-- 2020.05.13 / ksh / left outer join => inner join 
	-- 2020.05.28 / ksh / bug fix about User hierarchy Info
	-- 2020.05.29 / ksh / dynamically make init data of entry based measure
	-- 2020.06.02 / ksh / amt에 utpic 넣어두기 (test)
	-- 2020.06.1* / ksh / input entry history initial data into entry 
	-- 2020.07.07 / ksh / Entry 관리하고자 하는 버전 개수만 설정대로 유지
	-- 2020.11.10 / Kim sohee / data type of CODE NVARCHAR(100)
	-- 2020.11.26 / Kim sohee / set initial data by value type (케이스 테스트 더 해봐야 함)
	- 2021.02.15 / kim sohee / case : init qty value is none, bug fix
	- 2021.06.21 /hanguls/ emp_id mapping max 로 초기값 설정
	- 2021.07.29 / kim sohee / add a case : bucket	
	- 2022.03.02 / Kim sohee / virtual level also make demand & value
	- 2022.05.02 / kim sohee / yearly plan, bug (get initial data) fix
	- 2022.05.31 / kim sohee / QTY_A 
	- 2022.12.23 / kim sohee / add QTY_I
************************************************************************************************************/
CREATE PROCEDURE [dbo].[SP_UI_DP_93_VER_CREATE_S3]  (
			@P_VER_CD					NVARCHAR(50) --	= (SELECT TOP 1 ver_ID FROM TB_DP_CONTROL_BOARD_VER_MST ORDER BY CREATE_DTTM DESC)
		  , @P_PLAN_TP_ID				CHAR(32)	 --   = (SELECT TOP 1 PLAN_TP_ID FROM TB_DP_CONTROL_BOARD_VER_MST ORDER BY CREATE_DTTM DESC)	
)
AS 
SET NOCOUNT ON 
BEGIN 
	DECLARE @P_VER_ID		CHAR(32)
		   ,@P_FROM_DATE	DATE 
		   ,@P_TO_DATE		DATE 
		   ,@P_SM_DATE		DATE 
		   ,@P_PLAN_ATTR	NVARCHAR(50) 
	;

/************************************************************************************************************
	-- Get Version Config
************************************************************************************************************/
	 SELECT   @P_VER_ID		= ID 
			, @P_FROM_DATE	= FROM_DATE	
			, @P_TO_DATE	= TO_DATE		
	   FROM TB_DP_CONTROL_BOARD_VER_MST WHERE VER_ID = @P_VER_CD 
	   ;
	SELECT @P_PLAN_ATTR = ATTR_01 
	  FROM TB_CM_COMM_CONFIG
	WHERE ID = @P_PLAN_TP_ID
	;
	--------------- 1. Get Versison Detail Info (Initial value type by authority type)
	CREATE TABLE #VER_INFO_DTL 
	 	(	 ID				CHAR(32)		COLLATE DATABASE_DEFAULT
			,DTL_ID			CHAR(32) 		COLLATE DATABASE_DEFAULT
	 		,AUTH_TP_CD		NVARCHAR(100)	COLLATE DATABASE_DEFAULT
	 		,AUTH_TP_ID		CHAR(32)		COLLATE DATABASE_DEFAULT
	 		,INIT_TP_CD		NVARCHAR(50)	COLLATE DATABASE_DEFAULT
	 		,INIT_VAL_CD	NVARCHAR(50)	COLLATE DATABASE_DEFAULT
	 		,INIT_VAL_ID	CHAR(32)		COLLATE DATABASE_DEFAULT
			,PRICE_TP_ID	CHAR(32)		COLLATE DATABASE_DEFAULT
	 	)
		;
	DECLARE @P_PREV_VER_ID CHAR(32)
    SELECT TOP 1 @P_PREV_VER_ID = CONBD_VER_MST_ID  
	  FROM TB_DP_CONTROL_BOARD_VER_DTL D  
	 WHERE CONBD_VER_MST_ID != @P_VER_ID 
	   AND PLAN_TP_ID = @P_PLAN_TP_ID 
	   AND D.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_cD = 'DP_WK_TP' AND CONF_CD = 'CL')
	   AND D.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
  ORDER BY CREATE_DTTM DESC
  ;
		INSERT INTO #VER_INFO_DTL
		( ID	
	     ,DTL_ID 			
		 ,AUTH_TP_CD		
		 ,AUTH_TP_ID		
		 ,INIT_TP_CD		
		 ,INIT_VAL_CD	
		 ,INIT_VAL_ID	
		 ,PRICE_TP_ID 
		)
		SELECT VI.ID
			 , VE.ID 
			 , LV.LV_CD						 AS AUTH_TP_CD
			 , VE.LV_MGMT_ID				 AS AUTH_TP_ID
			 , IV.CONF_CD					 AS INIT_TP_CD
			 , CASE IV.CONF_CD 
				WHEN 'PR' THEN IL.LV_CD
				WHEN 'MS' THEN MS.MEASURE_CD
			   END							 AS INIT_VAL_CD
			 , CASE IV.CONF_CD 
				WHEN 'PR' THEN IL.ID
				WHEN 'MS' THEN MS.ID
			   END							 AS INIT_VAL_ID
			 , PRICE_TP_ID 
	  FROM TB_DP_CONTROL_BOARD_VER_MST VI 
		   INNER JOIN 
		   TB_DP_CONTROL_BOARD_VER_DTL VE
		ON VI.ID = @P_VER_ID 
	   AND VE.CONBD_VER_MST_ID = @P_VER_ID 	   
		   INNER JOIN
		   TB_CM_LEVEL_MGMT LV
		ON VE.LV_MGMT_ID = LV.ID
	   AND ISNULL(LV.DEL_YN, 'N') = 'N'
	   AND LV.ACTV_YN = 'Y'   
		   INNER JOIN
		   TB_CM_COMM_CONFIG IV
		ON VE.INIT_VAL_TP_ID = IV.ID 
	   AND IV.ACTV_YN = 'Y'   
		   LEFT OUTER JOIN
		   TB_CM_LEVEL_MGMT IL
		ON VE.INIT_FIXED_LV_MGMT_ID = IL.ID
	   AND ISNULL(IL.DEL_YN, 'N') = 'N'
	   AND IL.ACTV_YN = 'Y'   
		   LEFT OUTER JOIN
		   TB_DP_MEASURE_MST MS
		ON VE.INIT_MEASURE_ID = MS.ID
		;
	CREATE TABLE #VER_INFO_INIT 
	(	DTL_ID					CHAR(32)		COLLATE DATABASE_DEFAULT
	   ,AUTH_TP_ID				CHAR(32) 		COLLATE DATABASE_DEFAULT
	   ,INIT_MS_VAL_TP_CD		NVARCHAR(100)	COLLATE DATABASE_DEFAULT
	   ,INIT_VAL_TP_ID			CHAR(32)		COLLATE DATABASE_DEFAULT
	   ,INIT_VAL_TP_CD			NVARCHAR(100)	COLLATE DATABASE_DEFAULT
	   ,INIT_MEASURE_ID			CHAR(32)		COLLATE DATABASE_DEFAULT
	   ,INIT_MEASURE_CD			NVARCHAR(100)	COLLATE DATABASE_DEFAULT
	   ,INIT_FIXED_LV_MGMT_ID	CHAR(32)		COLLATE DATABASE_DEFAULT
	   ,INIT_FIXED_LV_MGMT_CD	NVARCHAR(100)	COLLATE DATABASE_DEFAULT
	    ,IDX						INT -- FOR COUNT OF COLUMN 
	)
	INSERT INTO #VER_INFO_INIT
	(	DTL_ID					
	   ,AUTH_TP_ID 
	   ,INIT_MS_VAL_TP_CD		
	   ,INIT_VAL_TP_ID			
	   ,INIT_VAL_TP_CD			
	   ,INIT_MEASURE_ID			
	   ,INIT_MEASURE_CD			
	   ,INIT_FIXED_LV_MGMT_ID	
	   ,INIT_FIXED_LV_MGMT_CD	
	    ,IDX 		
	)
		SELECT VI.CONBD_VER_DTL_ID
			 , VD.AUTH_TP_ID 
			 , VI.MS_VAL_TP_CD			AS INIT_MS_VAL_TP_CD
			 , VI.INIT_VAL_TP_ID		AS INIT_VAL_TP_ID
			 , VT.CONF_CD				AS INIT_VAL_TP_CD
			 , VI.INIT_MEASURE_ID		
			 , MS.MEASURE_CD			AS INIT_MEASURE
			 , VI.INIT_FIXED_LV_MGMT_ID	
			 , LV.LV_CD					AS INIT_LV 
			 , DENSE_RANK() OVER (PARTITION BY VT.CONF_CD ORDER BY VI.MS_VAL_TP_CD ASC )
		  FROM TB_DP_CONTROL_BOARD_VER_INIT VI
			   INNER JOIN 
			   #VER_INFO_DTL VD
			ON VI.CONBD_VER_DTL_ID = VD.DTL_ID 
			   INNER JOIN 
			   TB_CM_COMM_CONFIG VT
		    ON VI.INIT_VAL_TP_ID = VT.ID 
		       LEFT OUTER JOIN
			   TB_DP_MEASURE_MST MS
			ON VI.INIT_MEASURE_ID = MS.ID 
		       LEFT OUTER JOIN
			   TB_CM_LEVEL_MGMT LV
			ON LV.ID = VI.INIT_FIXED_LV_MGMT_ID
		 ;
/**************************************************************************************************************************************
	-- Close 하지 않은 이전 버전 정리
*************************************************************************************************************************************/
/*	DECLARE @NOT_CLOSE_VER_INFO TABLE ( ID		CHAR(32) )
	INSERT INTO @NOT_CLOSE_VER_INFO		
	SELECT CONBD_VER_MST_ID
	  FROM TB_DP_CONTROL_BOARD_VER_DTL D
	 WHERE D.WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_cD = 'DP_WK_TP' AND CONF_CD = 'CL')
	  AND D.CL_STATUS_ID != (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
	  AND PLAN_TP_ID = @P_PLAN_TP_ID
	  AND CONBD_VER_MST_ID != @P_VER_ID
	DELETE FROM TB_DP_ENTRY
	WHERE VER_ID IN (SELECT ID FROM @NOT_CLOSE_VER_INFO)
	; 
	DELETE FROM TB_DP_CONTROL_BOARD_VER_DTL
	WHERE CONBD_VER_MST_ID IN (SELECT ID FROM @NOT_CLOSE_VER_INFO)
	;
	DELETE FROM TB_DP_CONTROL_BOARD_VER_MST
	WHERE ID IN (SELECT ID FROM @NOT_CLOSE_VER_INFO)
	;
*/
/************************************************************************************************************
	-- Find Item account mapping data
*************************************************************************************************************/
CREATE TABLE #IAC
(
  ITEM_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
 ,ACCT_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
 ,ROLE_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
 ,EMP_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
 ,BASE_DATE		DATE 
)
;
CREATE TABLE #CALENDAR
(  STRT_DATE	DATE 
 , END_DATE		DATE 
 , BASE_DATE	DATE 
)
;

WITH VER_INFO
AS (SELECT	 ID
			,FROM_DATE 
			,TO_DATE
			,BUKT	
			,PRICE_TP_ID				 
	 FROM TB_DP_CONTROL_BOARD_VER_MST 
    WHERE ID = @P_VER_ID 
	)
	INSERT INTO #CALENDAR (STRT_DATE, END_DATE, BASE_DATE) 
		SELECT MIN(DAT)	
			 , MAX(DAT) 
			 , MIN(DAT) 
		  FROM TB_CM_CALENDAR CAL
			   INNER JOIN
			   VER_INFO VER
			ON CAL.DAT BETWEEN VER.FROM_DATE AND VER.TO_DATE 
	  GROUP BY CASE VER.BUKT
				WHEN 'Y' THEN YYYY
				WHEN 'Q' THEN YYYY+'-'+CONVERT(CHAR(1), QTR)
				WHEN 'M' THEN YYYYMM
				WHEN 'PW' THEN MM+'-'+DP_WK
				WHEN 'W' THEN DP_WK
			  ELSE YYYYMMDD END  	
			 ;

WITH ITEM_HIER
	AS (
		SELECT ANCESTER_ID, ANCESTER_CD, DESCENDANT_ID, DESCENDANT_CD FROM TB_DPD_ITEM_HIER_CLOSURE IH WHERE IH.LEAF_YN = 'Y' and IH.USE_YN='Y'
	), SALES_HIER
	AS (
		SELECT ANCESTER_ID, ANCESTER_CD, DESCENDANT_ID, DESCENDANT_CD FROM TB_DPD_SALES_HIER_CLOSURE SH WHERE SH.LEAF_YN = 'Y' and SH.USE_YN='Y'
	), ITEM
	AS (  SELECT CASE WHEN CL.LEAF_YN = 'Y' THEN IM.ITEM_MST_ID ELSE IM.ITEM_LV_ID END	AS ID
						 , CL.LEAF_YN
						 , IM.AUTH_TP_ID 
						 , IM.EMP_ID
				FROM TB_DP_USER_ITEM_MAP IM 
					  INNER JOIN 
					  TB_CM_LEVEL_MGMT CL ON (IM.LV_MGMT_ID = CL.ID 
							  			 AND CL.ACTV_YN = 'Y'
							  			 AND CL.DEL_YN = 'N')
			   WHERE IM.ACTV_YN = 'Y'   
	), ACCT
	AS (-- 내 매핑 ACCT 찾기
			SELECT CASE WHEN CL.LEAF_YN = 'Y' THEN AM.ACCOUNT_ID ELSE AM.SALES_LV_ID END	AS ID
				 , AM.AUTH_TP_ID 
				 , AM.EMP_ID
				 , CL.LEAF_YN
			  FROM TB_DP_USER_ACCOUNT_MAP AM 
				   INNER JOIN
				   TB_CM_LEVEL_MGMT CL
				ON AM.LV_MGMT_ID = CL.ID 
			   AND CL.ACTV_YN = 'Y'
			   AND ISNULL(CL.DEL_YN, 'N') = 'N'
			 WHERE AM.ACTV_YN = 'Y'	 
	), IA_LEAF
	AS (	
		    SELECT ACCT.AUTH_TP_ID
				 , ACCT.EMP_ID 
				 , CASE WHEN ITEM.LEAF_YN = 'Y' THEN ITEM.ID ELSE IH.DESCENDANT_ID END		AS ITEM_ID
				 , CASE WHEN ACCT.LEAF_YN = 'Y' THEN ACCT.ID ELSE SH.DESCENDANT_ID END		AS ACCT_ID
			  FROM ACCT		-- ACCT_SH
				   INNER JOIN
				   ITEM		-- ITEM_SH 
				ON ACCT.AUTH_TP_ID = ITEM.AUTH_TP_ID
			   AND ACCT.EMP_ID  = ITEM.EMP_ID
				   INNER JOIN 
				   ITEM_HIER IH ON ( ITEM.ID = IH.ANCESTER_ID )
				   INNER JOIN
				   SALES_HIER SH
				ON ACCT.ID = SH.ANCESTER_ID
	), SALES_LEVEL
	AS (
		SELECT ID, LV_CD, ROW_NUMBER() OVER (ORDER BY LEAF_YN) AS SEQ 
		  FROM TB_CM_LEVEL_MGMT WHERE SALES_LV_YN = 'Y'
	), IA
	AS (    SELECT DISTINCT 
				   ACCT_ID			AS ACCOUNT_ID
				 , ITEM_ID			AS ITEM_MST_ID
				 , MIN(EMP_ID) OVER (PARTITION BY ACCT_ID, ITEM_ID ORDER BY SL.SEQ)	AS EMP_ID	-- AUTH TYPE이 MARKETING인 것부터 EMP_ID를 찾아주고 .. 없으면 다음 .. SORT..
			  FROM IA_LEAF UIAM		
				   INNER JOIN 
				   SALES_LEVEL SL
				ON UIAM.AUTH_TP_ID = SL.ID 				
--		GROUP BY ACCT_ID, ITEM_ID
				 UNION
			SELECT DISTINCT 
				   ACCOUNT_ID
				 , ITEM_MST_ID
				 , MIN(EMP_ID) OVER (PARTITION BY ACCOUNT_ID, ITEM_MST_ID ORDER BY SL.SEQ)	AS EMP_ID
			  FROM TB_DP_USER_ITEM_ACCOUNT_MAP UIAM	-- item, account 각각의 매핑 정보가 있으면, 이 매핑 정보는 안본다.		
				   INNER JOIN 
				   SALES_LEVEL SL
				ON UIAM.AUTH_TP_ID = SL.ID 				  
--		 GROUP BY ACCOUNT_ID, ITEM_MST_ID
	), CONBD_VER
	AS (
	SELECT LV_MGMT_ID FROM TB_DP_CONTROL_BOARD_VER_DTL WHERE CONBD_VER_MST_ID = @P_VER_ID AND LV_MGMT_ID IS NOT NULL 
	)
	INSERT INTO #IAC (ITEM_ID, ACCT_ID, ROLE_ID, EMP_ID, BASE_DATE) 
	SELECT ITEM_MST_ID
		  ,ACCOUNT_ID
		  ,LV_MGMT_ID	-- Mapping이 있는 상용자 ID랑 SALES_ORG의 하위 사용자 ID가 같다면.. 그 상위 사용자 ID로. 같지 않으면 
		  ,EMP_ID	-- 이건 어떻게 바꿔줄가..
		  ,STRT_DATE 
	  FROM IA	
		   CROSS JOIN
		   #CALENDAR CAL  
		   CROSS JOIN 
		   CONBD_VER -- Mapping 기준으로 Control board에 등록된 단계의 레벨을 다 생성해줌
		   ;
-- UPDATE		
/*
WITH SALES_USER
	AS (
		  SELECT ANCS_ID
			   , ANCS_CD
			   , ANCS_ROLE_ID
			   , DESC_ID
			   , DESC_CD 
		    FROM TB_DPD_USER_HIER_CLOSURE
		   WHERE ANCS_ROLE_CD = 'SALES_ORG'
		     AND DEPTH_NUM > 0	
	)
*/	

/************************************************************************************************************
	-- Initial Value
************************************************************************************************************/
--	SELECT *
--	  FROM #VER_INFO_DTL
	--------------- 2. Create and Insert Result Temporary Table
	CREATE TABLE #RT
			(	 ITEM_MST_ID	CHAR(32)			COLLATE DATABASE_DEFAULT
				,ACCOUNT_ID		CHAR(32)			COLLATE DATABASE_DEFAULT
				,BASE_DATE		DATE
				,QTY			DECIMAL(20,3)
				,AUTH_TP_ID		CHAR(32)			COLLATE DATABASE_DEFAULT
				,QTY_1			DECIMAL(20,3)
				,QTY_2			DECIMAL(20,3)
				,QTY_3			DECIMAL(20,3)
			)
			;
 
	BEGIN 
		DECLARE @P_STR	NVARCHAR(MAX)
			  , @P_VAL_CNT  INT = (	SELECT DISTINCT COUNT(INIT_VAL_TP_CD) 
									  FROM #VER_INFO_INIT  WHERE INIT_VAL_TP_CD = 'PR' )
--			  , @P_LOOP_IDX	INT = 1
		
		IF EXISTS ( SELECT 1 FROM #VER_INFO_DTL WHERE INIT_TP_CD = 'PR') OR EXISTS ( SELECT 1 FROM #VER_INFO_INIT WHERE INIT_VAL_TP_CD = 'PR')
			BEGIN	
				CREATE TABLE #PR
				( ITEM_MST_ID	CHAR(32)		COLLATE DATABASE_DEFAULT
				 ,ACCOUNT_ID	CHAR(32)		COLLATE DATABASE_DEFAULT
				 ,BASE_DATE		DATE
				 ,AUTH_TP_ID	CHAR(32)		COLLATE DATABASE_DEFAULT
				 ,QTY			DECIMAL(20,3)
				 ,QTY_1			DECIMAL(20,3)
				 ,QTY_2			DECIMAL(20,3)
				 ,QTY_3			DECIMAL(20,3)	
				)
				INSERT INTO #PR
				SELECT ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, AUTH_TP_ID, QTY, QTY_1, QTY_2, QTY_3
				  FROM TB_DP_ENTRY
				 WHERE VER_ID = @P_PREV_VER_ID 
				 ;
				
				SET @P_STR =
				'WITH INI_PR '
				+  'AS ( '
				+	'SELECT DTL_ID '
				+		 ', INIT_FIXED_LV_MGMT_ID '
				+		 ', INIT_MS_VAL_TP_CD '
				+	  'FROM #VER_INFO_INIT '
				+	 'WHERE INIT_VAL_TP_CD = ''PR'' '
				+  ')' 
				+ 'INSERT INTO #RT  ( ITEM_MST_ID,ACCOUNT_ID,BASE_DATE,QTY,AUTH_TP_ID'	-- bug fix
					+(		SELECT ISNULL(',' + STRING_AGG(INIT_MS_VAL_TP_CD,',') WITHIN GROUP(ORDER BY INIT_MS_VAL_TP_CD)  ,'')
							  FROM ( SELECT DISTINCT INIT_MS_VAL_TP_CD 
						  		    FROM #VER_INFO_INIT		
								   WHERE INIT_VAL_TP_CD = 'PR' 	
							      ) A			
					)
				+')'
				+'SELECT M.ITEM_ID '
				+	  ', M.ACCT_ID'
				+	  ', M.BASE_DATE  '
				+	CASE WHEN EXISTS ( SELECT 1 FROM #VER_INFO_DTL WHERE INIT_TP_CD = 'PR') THEN  ', DE.QTY ' ELSE ', 0' END
				+	  ', VE.AUTH_TP_ID '+
				(		SELECT ISNULL(', '+STRING_AGG('DE'+CONVERT(CHAR(1),  IDX)+'.'+INIT_MS_VAL_TP_CD,',')  WITHIN GROUP(ORDER BY INIT_MS_VAL_TP_CD) ,'')
						  FROM ( SELECT DISTINCT INIT_MS_VAL_TP_CD, IDX 
						  		    FROM #VER_INFO_INIT		
								   WHERE INIT_VAL_TP_CD = 'PR' 	
							      ) A		
				)
				+ ' FROM #IAC M '
				+' INNER JOIN'
				+' #VER_INFO_DTL VE ON M.ROLE_ID = VE.AUTH_TP_ID '
				IF EXISTS ( SELECT 1 FROM #VER_INFO_DTL WHERE INIT_TP_CD = 'PR')
					BEGIN
						SET @P_STR = @P_STR 
									+     ' LEFT OUTER JOIN '
									+	   '#VER_INFO_DTL VD'
									+ ' ON VE.DTL_ID = VD.DTL_ID AND VD.INIT_TP_CD = ''PR'''		
									+	   'LEFT OUTER JOIN '
									+	   '#PR DE '
									+ ' ON VD.INIT_VAL_ID = DE.AUTH_TP_ID '
									+' AND M.ITEM_ID = DE.ITEM_MST_ID'
									+' AND M.ACCT_ID = DE.ACCOUNT_ID'
									+' AND M.BASE_DATE = DE.BASE_DATE '
					END
				IF (@P_VAL_CNT > 0)
					BEGIN
						SET @P_STR = @P_STR 
						+	   'INNER JOIN '		  
						+	   'INI_PR '
						+' PIVOT (MAX(INIT_FIXED_LV_MGMT_ID) FOR INIT_MS_VAL_TP_CD IN ('+
						(		SELECT ISNULL(STRING_AGG(INIT_MS_VAL_TP_CD,',') WITHIN GROUP(ORDER BY INIT_MS_VAL_TP_CD)  ,'')
								  FROM ( SELECT DISTINCT INIT_MS_VAL_TP_CD
						  		    FROM #VER_INFO_INIT		
								   WHERE INIT_VAL_TP_CD = 'PR' 	
							      ) A			
						)
						+')) AS PVT ' 
						+' ON VE.DTL_ID = PVT.DTL_ID '
					
--				WHILE (@P_LOOP_IDX <= @P_VAL_CNT)
--					BEGIN
					SELECT  @P_STR = @P_STR
					+    ' LEFT OUTER JOIN '
					+    ' #PR DE'+CONVERT(CHAR(1),  IDX)
					+ ' ON PVT.'+INIT_MS_VAL_TP_CD+' = DE'+CONVERT(CHAR(1),  IDX)+'.AUTH_TP_ID '
					+ ' AND M.ITEM_ID = DE'+CONVERT(CHAR(1),  IDX) +'.ITEM_MST_ID '
					+ ' AND M.ACCT_ID = DE'+CONVERT(CHAR(1),  IDX) +'.ACCOUNT_ID '
					+ ' AND M.BASE_DATE	= DE'+CONVERT(CHAR(1),  IDX) +'.BASE_DATE '
				  FROM #VER_INFO_INIT
				 WHERE INIT_VAL_TP_CD = 'PR' 
				GROUP BY INIT_MS_VAL_TP_CD, IDX 
				;
				 END
--					END 
					;

--				INSERT INTO #RT
--					(	 ITEM_MST_ID	 
--						,ACCOUNT_ID		 
--						,BASE_DATE		 
--						,QTY			 
--						,AUTH_TP_ID		 
--						,QTY_1
--						,QTY_2
--						,QTY_3 
--					)		
			 SET @P_STR = @P_STR+';'
				EXECUTE (@P_STR)
				;
				DROP TABLE #PR;
			END

	END
		;
		IF EXISTS ( SELECT 1 FROM #VER_INFO_DTL WHERE INIT_TP_CD = 'MS') OR EXISTS ( SELECT 1 FROM #VER_INFO_INIT WHERE INIT_VAL_TP_CD = 'MS')
			BEGIN	
				SET @P_STR = '';		 
				WITH INI
				  AS (
					SELECT DTL_ID 
						 , AUTH_TP_ID 
						 , CASE WHEN @P_PLAN_ATTR = 'Y' THEN 'SUM('+INIT_VAL_CD+') AS QTY' ELSE INIT_VAL_CD+ ' AS QTY' END AS COL
						 , 'QTY' as VAL_COL
						 , 'SRC.QTY'  as IST_COL
						 , 'TGT.QTY = SRC.QTY' as UPT_COL

					 FROM #VER_INFO_DTL 
					WHERE INIT_TP_CD = 'MS'
					UNION
					SELECT DTL_ID
						 , AUTH_TP_ID 
						 , STRING_AGG(CASE WHEN @P_PLAN_ATTR = 'Y' THEN 'SUM('+INIT_MEASURE_CD+') AS '+INIT_MS_VAL_TP_CD ELSE INIT_MEASURE_CD+' AS '+INIT_MS_VAL_TP_CD END , ',')   AS COL
--						 ,STRING_AGG(INIT_MEASURE_CD, ',') AS MS_COL
						 , STRING_AGG(INIT_MS_VAL_TP_CD, ',') as VAL_COL
						 , STRING_AGG('SRC.'+INIT_MS_VAL_TP_CD, ',') as IST_COL
						 , STRING_AGG('TGT.'+INIT_MS_VAL_TP_CD+'='+'SRC.'+INIT_MS_VAL_TP_CD, ',') as UPT_COL
					  FROM #VER_INFO_INIT 
					 WHERE INIT_VAL_TP_CD = 'MS' 
					 GROUP BY DTL_ID, AUTH_TP_ID
				  ) 
				SELECT @P_STR = @P_STR
					 + ' MERGE INTO #RT TGT'
					 + ' USING (			  '
					 + 'SELECT M.ITEM_MST_ID, M.ACCOUNT_ID'
					 + ', @@CAL_DATE '
--					 +  INIT_VAL_CD
				     + ','''+AUTH_TP_ID+''' AS AUTH_TP_ID '
				     + ','''+DTL_ID+''' AS DTL_ID '					 
					 +  ','+ISNULL(COL,'')
					 + ' FROM TB_DP_MEASURE_DATA M '
					 + '@@JOIN_CALENDAR'
					 + ' WHERE M.BASE_DATE BETWEEN CONVERT(DATE, '''+CONVERT(NVARCHAR(10),@P_FROM_DATE,112)+''') AND CONVERT(DATE, '''+CONVERT(NVARCHAR(10), @P_TO_DATE, 112)+''') '
					 + '@@GROUPBY'
					 + ' ) SRC '
					 + ' ON SRC.ITEM_MST_ID = TGT.ITEM_MST_ID '
					 + ' AND SRC.ACCOUNT_ID = TGT.ACCOUNT_ID  '
					 + ' AND SRC.BASE_DATE = TGT.BASE_DATE	  '
					 + ' AND SRC.AUTH_TP_ID = TGT.AUTH_TP_ID  '
					 + ' WHEN MATCHED THEN '
					 + ' UPDATE SET '+UPT_COL
					 + ' WHEN NOT MATCHED THEN '
					 + ' INSERT  ( '
					 + ' ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, AUTH_TP_ID ,'
					 +  VAL_COL
					 + ' ) VALUES '
					 + ' (SRC.ITEM_MST_ID, SRC.ACCOUNT_ID, SRC.BASE_DATE, SRC.AUTH_TP_ID ,'
					 + IST_COL
					 + ' );'					 
				 FROM INI 
				;	

				 -- PLAN TYPE 
				IF (@P_PLAN_ATTR = 'Y')
					BEGIN
						SET @P_STR = REPLACE(@P_STR, '@@JOIN_CALENDAR', 'INNER JOIN #CALENDAR C ON M.BASE_DATE BETWEEN C.STRT_DATE AND C.END_DATE');
						SET @P_STR = REPLACE(@P_STR, '@@CAL_DATE', 'C.BASE_DATE');
						SET @P_STR = REPLACE(@P_STR, '@@GROUPBY', 'GROUP BY M.ITEM_MST_ID, M.ACCOUNT_ID, C.BASE_DATE');
					END
				ELSE 
					BEGIN
						SET @P_STR = REPLACE(@P_STR, '@@JOIN_CALENDAR','')
						SET @P_STR = REPLACE(@P_STR, '@@CAL_DATE', 'M.BASE_DATE');
						SET @P_STR = REPLACE(@P_STR, '@@GROUPBY', '');
					END
					;
				EXECUTE (@P_STR);	
			END 
	 SELECT @P_SM_DATE = CONVERT(DATE,CASE WHEN DATEPART(MONTH, @P_FROM_DATE)>=PP.POLICY_VAL 
									  		THEN CONVERT(CHAR(4), DATEPART(YEAR, GETDATE()))
									  		ELSE CONVERT(CHAR(4), DATEPART(YEAR, GETDATE())-1) 
									  END +'-'+PP.POLICY_VAL+'-01')
	   FROM TB_DP_PLAN_POLICY  PP
		    INNER JOIN 
			TB_CM_COMM_CONFIG CC
		 ON PP.POLICY_ID = CC.ID 
	  WHERE PLAN_TP_ID = @P_PLAN_TP_ID
	    AND CC.CONF_CD = 'SM'
		;
--	SELECT *
--	  FROM #RT
--	  ;
/************************************************************************************************************
	-- Result
************************************************************************************************************/
	WITH UNIT_PRICE
	AS (SELECT  ITEM_MST_ID
			   ,ACCOUNT_ID
			   ,BASE_DATE	AS STRT_DATE 
			   ,ISNULL(DATEADD(DAY,-1,LEAD(BASE_DATE) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID ORDER BY  BASE_DATE )), @P_TO_DATE)	AS END_DATE  
			   ,UTPIC
		  FROM TB_DP_UNIT_PRICE UP
			   INNER JOIN
			   #VER_INFO_DTL VD
			ON UP.PRICE_TP_ID = VD.PRICE_TP_ID 
		   AND UP.BASE_DATE <= @P_TO_DATE  
	), ENTRY_HIS
	AS (   SELECT  SUM(QTY)			AS QTY
				 , SUM(AMT)			AS AMT
				 , ITEM_MST_ID
				 , ACCOUNT_ID
			  FROM TB_DP_ENTRY_HISTORY 
			 WHERE BASE_dATE BETWEEN @P_SM_DATE AND DATEADD(DAY,-1,@P_FROM_DATE)
		GROUP BY ITEM_MST_ID, ACCOUNT_ID
	)
		INSERT INTO TB_DP_ENTRY
		 (    ID
			, VER_ID
			, AUTH_TP_ID
			, EMP_ID
			, ITEM_MST_ID
			, ACCOUNT_ID
--			, SALES_LV_ID
			, BASE_DATE
			, QTY
			, QTY_I 
			, AMT
			, CREATE_BY
			, CREATE_DTTM
			, PLAN_TP_ID
			, QTY_1
			, AMT_1
			, QTY_2
			, AMT_2
			, QTY_3
			, AMT_3		 
		    , QTY_A
			, AMT_A 
		 )
		 SELECT REPLACE(NEWID(),'-','')							AS ID
			  , @P_VER_ID										AS VER_ID 
			  , MN.ROLE_ID 
			  , MN.EMP_ID
			  , MN.ITEM_ID	
			  , MN.ACCT_ID	
			  , MN.BASE_DATE 
			  , ISNULL(RT.QTY , 0)								AS QTY 
			  , ISNULL(RT.QTY , 0)					-- QTY_I 
			  , NULL 										AS AMT
			  , 'system'
			  ,  GETDATE()
			  , @P_PLAN_TP_ID 
			  , RT.QTY_1-- ISNULL(RT.QTY_1,0)
			  , NULL  
			  , RT.QTY_2 -- ISNULL(RT.QTY_2,0)
			  , NULL 
			  , RT.QTY_3-- ISNULL(RT.QTY_3,0)
			  , NULL 
			  , EH.QTY
			  , EH.AMT 
		   FROM #IAC MN
--				INNER JOIN
--				UNIT_PRICE UP
--			 ON IA.ITEM_ID = UP.ITEM_MST_ID 
--			AND IA.ACCT_ID = UP.ACCOUNT_ID
--			AND CAL.STRT_DT BETWEEN UP.STRT_DATE AND UP.END_DATE
			    LEFT OUTER JOIN 
				#RT		RT 
		     ON MN.ITEM_ID = RT.ITEM_MST_ID 
			AND MN.ACCT_ID = RT.ACCOUNT_ID 
			AND RT.BASE_DATE = MN.BASE_DATE  
			AND RT.AUTH_TP_ID = MN.ROLE_ID  
				LEFT OUTER JOIN
				ENTRY_HIS EH 
			ON  MN.ITEM_ID = EH.ITEM_MST_ID
		   AND  MN.ACCT_ID = EH.ACCOUNT_ID
		   AND MN.BASE_DATE < DATEADD(YEAR,1,@P_SM_DATE)
							
	DROP TABLE #RT;
	DROP TABLE #IAC;
	DROP TABLE #VER_INFO_INIT;
	DROP TABLE #VER_INFO_DTL;
-- WITH VER_CNT
--   AS ( SELECT CONBD_VER_MST_ID, ROW_NUMBER() OVER (ORDER BY CREATE_DTTM DESC) AS RW  
-- 		 FROM TB_DP_CONTROL_BOARD_VER_DTL 			 
-- 		WHERE 1=1
-- 		  AND PLAN_TP_ID = @P_PLAN_TP_ID	
-- 		  AND WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')		
-- 		  AND CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')    
-- 	 )
-- 	DELETE FROM TB_DP_ENTRY
-- 	  WHERE VER_ID IN (SELECT CONBD_VER_MST_ID
-- 						 FROM VER_CNT 
-- 						WHERE RW > (SELECT ATTR_02 
-- 									  FROM TB_CM_COMM_CONFIG
-- 									WHERE ID = @P_PLAN_TP_ID
-- 								   )
-- 					   ) 
-- 
 
END

go

