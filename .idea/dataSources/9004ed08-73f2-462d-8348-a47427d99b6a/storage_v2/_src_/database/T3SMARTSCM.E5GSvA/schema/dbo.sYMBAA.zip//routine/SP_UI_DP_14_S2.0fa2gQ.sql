/*****************************************************************************
Title : SP_DP_14_S2
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP User Mapping (Account)
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2018.03.09 / 김소희 / Validation 작업 
- 2019.04.25 / 김소희 / DEL_YN Null처리
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER
- 2020.12.02 / 김소희 / Make Initial Data into Entry
- 2020.12.07 / kim sohee / execute making dynamic user data procedure 
- 2021.03.10 / kim sohee / call a procedure to create User Group
*****************************************************************************/
CREATE PROCEDURE [dbo].[SP_UI_DP_14_S2]  (
										  @P_EMP_NO            NVARCHAR(32)    = '' 
										 ,@p_AUTH_TP_ID        NVARCHAR(32)    = ''		-- 하단 그리드 COLUMN
										 ,@P_LV_CD			   NVARCHAR(200)
										 ,@p_ACCOUNT_CD        NVARCHAR(200)   = '' 		-- 수정 시 필요한 값     
										 ,@p_ACTV_YN           CHAR(1)         = '' 
										 ,@p_USER_ID           NVARCHAR(50)    = '' 
										 ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)	   = 'true'   OUTPUT
									     ,@P_RT_MSG            NVARCHAR(4000)  = ''		  OUTPUT	
				                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE  @P_ERR_STATUS			INT = 0
        ,@P_ERR_MSG				NVARCHAR(4000)=''		 
		,@V_EMP_ID				CHAR(32)
		,@V_ACCT_YN				CHAR(1)
		,@V_ACCT_LV_ID			CHAR(32) 
		,@V_LV_MGMT_ID			CHAR(32)
		,@V_ACCOUNT_ID			CHAR(32)


BEGIN TRY
	if(ISNULL(@p_ACTV_YN,'') = '')
	BEGIN
		SET @p_ACTV_YN = 'Y' -- None of personal data
	END
	-- EMP_NO => EMP_ID
	SELECT @V_EMP_ID = ID
	  FROM TB_AD_USER
	 WHERE USERNAME = @p_EMP_NO
	-- LV_CD => LV_MGMT_ID
	SELECT @v_LV_MGMT_ID = m.ID
		,  @V_ACCT_YN = LEAF_YN
	  FROM TB_CM_LEVEL_MGMT m
	  inner join TB_CM_COMM_CONFIG c on c.id = m.LV_TP_ID and c.CONF_CD = 'S'
	 WHERE LV_CD = @p_LV_CD
	IF(@V_ACCT_YN = 'Y')
	BEGIN
		SELECT @V_ACCOUNT_ID = ID
		  FROM TB_DP_ACCOUNT_MST
		 WHERE ACCOUNT_CD = @P_ACCOUNT_CD
	END
	ELSE
	BEGIN
		SELECT @V_ACCOUNT_ID = ID
			 , @V_ACCT_LV_ID = ID 
		  FROM TB_DP_SALES_LEVEL_MGMT
		 WHERE SALES_LV_CD = @P_ACCOUNT_CD
		   AND LV_MGMT_ID = @V_LV_MGMT_ID
	END

	-- Validation 
	-- key ID == null?
	IF ( @v_LV_MGMT_ID IS NULL)
	BEGIN
		SET @P_RT_ROLLBACK_FLAG = 'false'
		SET @P_ERR_MSG = 'MSG_5029'
		RAISERROR(@P_ERR_MSG,12,1)
	END
	IF ( @V_ACCOUNT_ID IS NULL)
	BEGIN
		SET @P_RT_ROLLBACK_FLAG = 'false'
		SET @P_ERR_MSG = 'MSG_0017'
		RAISERROR(@P_ERR_MSG,12,1)
	END
	IF ( @p_AUTH_TP_ID IS NULL)
	BEGIN
		SET @P_RT_ROLLBACK_FLAG = 'false'
		SET @P_ERR_MSG = 'MSG_5044'
		RAISERROR(@P_ERR_MSG,12,1)
	END
				
	-- 중복													
	SELECT @P_ERR_STATUS = COUNT(*)
	  FROM TB_DP_USER_ACCOUNT_MAP
	 WHERE 1=1
	   AND CASE  @V_ACCT_YN WHEN 'Y' THEN ACCOUNT_ID ELSE SALES_LV_ID END = @V_ACCOUNT_ID
	   AND EMP_ID = @V_EMP_ID
	   AND ACTV_YN = @p_ACTV_YN -- 유일 수정 값인 활성화 여부로 INSERT와 UPDATE 구분
	IF ( @P_ERR_STATUS != 0 )
	BEGIN
		SET @P_RT_ROLLBACK_FLAG = 'false'
		SET @P_ERR_MSG = 'MSG_0013'
		RAISERROR(@P_ERR_MSG,12,1)
	END

				MERGE [TB_DP_USER_ACCOUNT_MAP]  TGT
				USING ( 
						SELECT  REPLACE(NEWID(),'-','')									AS ID 
							   ,@V_EMP_ID												AS  EMP_ID
						       ,@P_AUTH_TP_ID											AS  AUTH_TP_ID
							   ,@V_LV_MGMT_ID											AS  LV_MGMT_ID
							   ,CASE @V_ACCT_YN WHEN 'N' THEN @V_ACCOUNT_ID   END       AS  SALES_LV_ID
							   ,CASE @V_ACCT_YN WHEN 'Y' THEN @V_ACCOUNT_ID   END       AS  ACCOUNT_ID
							   ,@P_ACTV_YN												AS  ACTV_YN
							   ,@P_USER_ID												AS  USER_ID
					  ) SRC
				ON   (SRC.EMP_ID = TGT.EMP_ID
			   AND    SRC.AUTH_TP_ID = TGT.AUTH_TP_ID
			   AND    SRC.LV_MGMT_ID = TGT.LV_MGMT_ID
			   AND    ISNULL(SRC.SALES_LV_ID,'') = ISNULL(TGT.SALES_LV_ID,'')
			   AND    ISNULL(SRC.ACCOUNT_ID ,'') = ISNULL(TGT.ACCOUNT_ID ,'')  				
					 )
				WHEN MATCHED THEN
					 UPDATE 
					 SET   TGT.ACTV_YN     = SRC.ACTV_YN 
							,TGT.MODIFY_BY   = SRC.USER_ID       
							,TGT.MODIFY_DTTM = GETDATE()       
				WHEN NOT MATCHED THEN 
					 INSERT (
					            ID
							  , EMP_ID
							  , AUTH_TP_ID
							  , LV_MGMT_ID
							  , SALES_LV_ID
							  , ACCOUNT_ID
							  , ACTV_YN
							  , CREATE_BY
							  , CREATE_DTTM
							) 
					 VALUES (
					            SRC.ID 
							  , SRC.EMP_ID
							  , SRC.AUTH_TP_ID
							  , SRC.LV_MGMT_ID
							  , SRC.SALES_LV_ID
							  , SRC.ACCOUNT_ID
							  , SRC.ACTV_YN  
							  , SRC.USER_ID 
							  , GETDATE()            
 							) 
							;    	
							
	/********************************************************************************************************************************************
		-- Make Entry data
	********************************************************************************************************************************************/
	 

	DECLARE @TB_VERSION TABLE ( ID CHAR(32)) 
	DECLARE @CUR_VER_ID NVARCHAR(100)
	INSERT INTO @TB_VERSION (ID) 
	SELECT VER_ID
	  FROM ( 
			SELECT M.ID AS VER_ID 
				 , DENSE_RANK () OVER (PARTITION BY M.PLAN_TP_ID ORDER BY M.CREATE_DTTM DESC) AS RW 
			  FROM TB_DP_CONTROL_BOARD_VER_MST M
				   INNER JOIN 
				   TB_DP_CONTROL_bOARD_VER_DTL D
				ON M.ID = D.CONBD_VER_MST_ID 
				   INNER JOIN 
				   TB_CM_COMM_CONFIG W
				ON W.ID = D.WORK_TP_ID
			   AND W.CONF_CD = 'CL'
				   INNER JOIN 
				   TB_CM_COMM_CONFIG C
				ON D.CL_STATUS_ID = C.ID
			   AND C.CONF_CD != 'CLOSE' 
			 WHERE EXISTS (SELECT DISTINCT VER_ID FROM TB_DP_ENTRY WHERE VER_ID = M.ID) 
		    ) A
	WHERE RW = 1  
	DECLARE USER_ACCT_CUR CURSOR FAST_FORWARD LOCAL
	FOR SELECT ID FROM @TB_VERSION
	READONLY
	;
	OPEN USER_ACCT_CUR
    FETCH NEXT FROM USER_ACCT_CUR INTO @CUR_VER_ID 
	;
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			-- Cursor로 나온 Version ID의 새로운 데이터 중복 여부 판별
--			 IF NOT EXISTS
--			 (  SELECT 1 
--				 FROM TB_DP_ENTRY 
--				WHERE VER_ID = @CUR_VER_ID
--				  AND ACCOUNT_ID IN (SELECT DESCENDANT_ID FROM TB_DPD_SALES_HIER_CLOSURE WHERE ANCESTER_ID = @V_ACCOUNT_ID AND LEAF_YN = 'Y')
--			 )
--			 BEGIN
				   IF (@V_ACCT_YN = 'N')
					BEGIN
						SET @V_ACCOUNT_ID = NULL ;
					END
				   EXECUTE dbo.SP_UI_DP_93_ITEM_ACCT_CREATE 
							 @P_ITEM_MST_ID		= null		-- Item Account User Map / Item Master 
							,@P_ITEM_LV_ID		= null		
							,@P_ACCOUNT_ID		= @V_ACCOUNT_ID   -- Item Account User Map / Account Master 
							,@P_ACCT_LV_ID		= @V_ACCT_LV_ID   	
							,@P_USER_ID			= @P_USER_ID			-- Mapping data
							,@P_AUTH_TP_ID		= @P_AUTH_TP_ID	
							,@P_VER_ID			= @CUR_VER_ID 	
							;   
--			  END 	
--			  ;
			  FETCH NEXT FROM USER_ACCT_CUR INTO @CUR_VER_ID
		END 
	   ;

		CLOSE USER_ACCT_CUR
		DEALLOCATE USER_ACCT_CUR 
		;
		EXEC SP_UI_DP_00_MAKE_USER_GROUP @P_USER_ID = @V_EMP_ID, @P_USER_NAME = @P_EMP_NO, @P_AUTH_TP_ID = @P_AUTH_TP_ID ;
		EXEC SP_UI_DPD_MAKE_HIER_USER;	

	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;

go

