CREATE PROCEDURE [dbo].[SP_UI_IM_09_Q3] (
	@P_LOCAT_ID		AS NVARCHAR(32)	= null
)
AS
/*****************************************************************************
Title : [SP_UI_IM_09_Q3]
Create By : 한영석
Create Date : 2017.07.24
 
Description 
- 수요변동성 분석 사분면 선택 프로시저

History
- 2017.07.24 / 한영석 / 최초 작성
- 2019.09.09 / SK. Roh / COV 사분면 Service Level Configuration 참조
 
*****************************************************************************/	
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE 
	@V_SVC_LV_01 NUMERIC(10,5) = 0,
	@V_SVC_LV_02 NUMERIC(10,5) = 0,
	@V_SVC_LV_03 NUMERIC(10,5) = 0,
	@V_SVC_LV_04 NUMERIC(10,5) = 0
BEGIN
	SELECT	@V_SVC_LV_01 = ISNULL(MAX(A.SVC_LV_01), 97),
			@V_SVC_LV_02 = ISNULL(MAX(A.SVC_LV_02), 90),
			@V_SVC_LV_03 = ISNULL(MAX(A.SVC_LV_03), 85),
			@V_SVC_LV_04 = ISNULL(MAX(A.SVC_LV_04), 95)
	FROM TB_IM_DMND_VARIABILITY_BASE A 
	WHERE A.ACTV_YN = 'Y' 
	AND A.LOCAT_ID = @P_LOCAT_ID

	SELECT	 B.ID
			,B.COMN_CD_NM	 AS QUADRANT_NM
			,B.DESCRIP		 AS QUADRANT_DESCRIP
			,A.GRP_CD AS [GROUP]
			,CASE	WHEN B.COMN_CD_NM = '1/4' THEN @V_SVC_LV_01
					WHEN B.COMN_CD_NM = '2/4' THEN @V_SVC_LV_02	
					WHEN B.COMN_CD_NM = '3/4' THEN @V_SVC_LV_03
					WHEN B.COMN_CD_NM = '4/4' THEN @V_SVC_LV_04
					END AS  PRPSAL_SVC_LV_VAL
	FROM 
		TB_AD_COMN_GRP A 
		INNER JOIN TB_AD_COMN_CODE B ON A.ID = B.SRC_ID
	WHERE 
		A.GRP_CD = 'QUADRANT'
	ORDER BY B.COMN_CD_NM

END

go

