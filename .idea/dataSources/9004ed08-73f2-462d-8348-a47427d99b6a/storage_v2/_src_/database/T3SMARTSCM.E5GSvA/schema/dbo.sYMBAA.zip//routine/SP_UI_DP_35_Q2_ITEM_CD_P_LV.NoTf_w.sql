/*****************************************************************************
Title : [SP_UI_DP_35_VALID_ITEM_CD_P_LV_Q1] 
최초 작성자 : 이고은
최초 생성일 : 2017.08.30
 
설명 
 - DP VALIDATION (ITEM_CD_P_LEVEL)-- ALL
 
History (수정일자 / 수정자 / 수정내용)
-  2017.08.30 / 이고은 / 최초 작성
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_35_Q2_ITEM_CD_P_LV] 
--(	
--	 @p_EMP_ID		NVARCHAR(100) = ''
--	,@p_AUTH_TP_ID	NVARCHAR(50) = ''
--) 
AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN


	SELECT	ID, ITEM_CD, ITEM_NM
	FROM	TB_CM_ITEM_MST 
	WHERE	ISNULL(DEL_YN, 'N') = 'N' AND DP_PLAN_YN = 'Y'
	AND		ISNULL(PARENT_ITEM_LV_ID, '') NOT IN(
												SELECT ID FROM TB_CM_ITEM_LEVEL_MGMT 
												)


END








go

