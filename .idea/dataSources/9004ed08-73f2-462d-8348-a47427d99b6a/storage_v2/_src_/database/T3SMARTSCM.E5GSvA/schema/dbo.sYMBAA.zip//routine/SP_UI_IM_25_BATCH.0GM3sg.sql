CREATE PROCEDURE [dbo].[SP_UI_IM_25_BATCH] (
	 @P_APPLY_POINT_CD		NVARCHAR(100)
	,@P_APPLY_TARGET		NVARCHAR(100)
	,@P_OVERWRITE_DATA_YN	CHAR(1)
	,@P_USER_ID				NVARCHAR (100)
	,@P_RT_ROLLBACK_FLAG	NVARCHAR(10) = 'true' OUTPUT
	,@P_RT_MSG				NVARCHAR(4000) = ''   OUTPUT
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_MSG NVARCHAR(4000)='',
		@V_ROP_CAL_TP_ID CHAR(32),
		@V_EOQ_CAL_TP_ID CHAR(32)
	
BEGIN TRY

	SELECT	@V_ROP_CAL_TP_ID = A.ID 
	FROM	TB_AD_COMN_CODE A,
			TB_AD_COMN_GRP B 
	WHERE	B.ID = A.SRC_ID 
	AND		B.GRP_CD = 'ROP_DECISION_RULE' 
	AND		A.COMN_CD = 'ROPDR01'
	
	SELECT	@V_EOQ_CAL_TP_ID = A.ID 
	FROM	TB_AD_COMN_CODE A,
			TB_AD_COMN_GRP B 
	WHERE	B.ID = A.SRC_ID 
	AND		B.GRP_CD = 'EOQ_DECISION_RULE' 
	AND		A.COMN_CD = 'EOQDR02'

	/***************************************************************************************************************************************************************************
	1. 재고수준
	 - 출하실적 구간 : Configuration 생산 입고품 재고일수 계산 출하실적 산출 구간 참조
	 - 일 평균 출하 실적 : 출하실적 데이터의 공급거점 관점에서 출하실적 구간 만큼의 출하수량에 대한 일 평균을 구함
	 - 평균재고 : (기초재고 + 기말재고) / 2
	 - 재고일수 : 평균재고 / 일 평균 출하 실적
	***************************************************************************************************************************************************************************/
	CREATE TABLE #TEMP_DAY_AVG_ACTUAL_SHIPMENT (
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT,
		QTY							DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_BOH (
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT,
		QTY							DECIMAL(20,3)
	)

	CREATE TABLE #TEMP_EOH (
		LOCAT_ITEM_ID				CHAR(32) COLLATE DATABASE_DEFAULT,
		QTY							DECIMAL(20,3)
	)

	INSERT INTO #TEMP_DAY_AVG_ACTUAL_SHIPMENT
	(
		LOCAT_ITEM_ID,
		QTY
	)
	SELECT	A.SUPPLY_LOCAT_ITEM_ID, 
			SUM(A.QTY) / MIN(A.DAY_CNT) AS QTY
	FROM	(
			SELECT	A.SUPPLY_LOCAT_ITEM_ID,
					D.SHPP_ACTUAL_PERIOD,
					D.DAY_CNT,
					A.ATD,
					SUM(SHPP_QTY) AS QTY
			FROM	TB_CM_ACTUAL_SHIPMENT A
					INNER JOIN TB_CM_SITE_ITEM B
					ON B.ID = A.SUPPLY_LOCAT_ITEM_ID
					INNER JOIN TB_CM_LOC_MGMT C
					ON C.ID = B.LOCAT_MGMT_ID
					LEFT OUTER JOIN 
					(
					SELECT	LOCAT_ID, START_DATE, END_DATE,
							ABS(A.ACTUAL_PERIOD) AS SHPP_ACTUAL_PERIOD,
							(SELECT VAL FROM DBO.FN_G_BUCKET_CNT('DAY', A.START_DATE, A.END_DATE)) AS DAY_CNT
					FROM	(
							SELECT	LOCAT_ID, A.ACTUAL_PERIOD, B.UOM_NM,
									(SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.ACTUAL_PERIOD, 'START', B.UOM_CD)) AS START_DATE,
									(SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.ACTUAL_PERIOD, 'END', B.UOM_CD)) AS END_DATE
							FROM	TB_IM_VARIABILITY_ACT_PRIOD A
									INNER JOIN TB_CM_UOM B
									ON B.ID = A.UOM_ID
							WHERE	CATAGY_VAL = 'FINAL_PRODUCT_GR_ITEM_INVTURN'
							AND		ISNULL(A.ACTV_YN, 'N') = 'Y'
							) A
					) D
					ON D.LOCAT_ID = C.LOCAT_ID
			WHERE	1=1
			AND		ISNULL(B.ACTV_YN, 'N') = 'Y'
			AND		ISNULL(C.ACTV_YN, 'N') = 'Y'
			AND		A.ATD BETWEEN D.START_DATE AND D.END_DATE
			GROUP	BY A.SUPPLY_LOCAT_ITEM_ID, D.SHPP_ACTUAL_PERIOD, D.DAY_CNT, A.ATD
			) A
	GROUP	BY A.SUPPLY_LOCAT_ITEM_ID

	INSERT INTO #TEMP_BOH
	(
		LOCAT_ITEM_ID,
		QTY
	)
	SELECT	A.LOCAT_ITEM_ID, 
			SUM(A.QTY) AS QTY
	FROM	(
			SELECT	B.LOCAT_ITEM_ID, 
					E.LOCAT_ID,
					B.CUTOFF_DATE,
					SUM(ISNULL(C.QTY, 0)) AS QTY
			FROM	TB_CM_SITE_ITEM A
					INNER JOIN TB_CM_WAREHOUSE_STOCK_MST B
					ON A.ID = B.LOCAT_ITEM_ID
					INNER JOIN TB_CM_WAREHOUSE_STOCK_QTY C
					ON B.ID = C.WAREHOUSE_INV_MST_ID
					INNER JOIN TB_IM_STOCK_QTY_TYPE D
					ON D.ID = C.INV_QTY_TP_ID
					INNER JOIN TB_CM_LOC_MGMT E
					ON E.ID = A.LOCAT_MGMT_ID
			WHERE	1=1
			AND		ISNULL(D.ACTV_YN, 'N') = 'Y'
			AND		ISNULL(D.PLAN_YN, 'N') = 'Y'
			GROUP	BY B.LOCAT_ITEM_ID, E.LOCAT_ID, B.CUTOFF_DATE
			) A,
			(
			SELECT	B.LOCAT_ID, MIN(A.CUTOFF_DATE) AS CUTOFF_DATE
			FROM	TB_CM_WAREHOUSE_STOCK_MST A,
					(
					SELECT	A.LOCAT_ID, 
							--CONVERT(DATETIME, '20180910', 120) AS START_DATE
							(SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.ACTUAL_PERIOD, 'START', B.UOM_CD)) AS START_DATE
					FROM	TB_IM_VARIABILITY_ACT_PRIOD A
							INNER JOIN TB_CM_UOM B
							ON B.ID = A.UOM_ID
					WHERE	CATAGY_VAL = 'FINAL_PRODUCT_GR_ITEM_INVTURN'
					) B
			WHERE	A.CUTOFF_DATE = B.START_DATE
			GROUP	BY B.LOCAT_ID
			) B
	WHERE	1=1
	AND		A.LOCAT_ID = B.LOCAT_ID
	AND		A.CUTOFF_DATE = B.CUTOFF_DATE
	GROUP	BY A.LOCAT_ITEM_ID

	INSERT INTO #TEMP_EOH
	(
		LOCAT_ITEM_ID,
		QTY
	)
	SELECT	A.LOCAT_ITEM_ID, 
			SUM(A.QTY) AS QTY
	FROM	(
			SELECT	B.LOCAT_ITEM_ID, 
					E.LOCAT_ID,
					B.CUTOFF_DATE,
					SUM(ISNULL(C.QTY, 0)) AS QTY
			FROM	TB_CM_SITE_ITEM A
					INNER JOIN TB_CM_WAREHOUSE_STOCK_MST B
					ON A.ID = B.LOCAT_ITEM_ID
					INNER JOIN TB_CM_WAREHOUSE_STOCK_QTY C
					ON B.ID = C.WAREHOUSE_INV_MST_ID
					INNER JOIN TB_IM_STOCK_QTY_TYPE D
					ON D.ID = C.INV_QTY_TP_ID
					INNER JOIN TB_CM_LOC_MGMT E
					ON E.ID = A.LOCAT_MGMT_ID
			WHERE	1=1
			AND		ISNULL(D.ACTV_YN, 'N') = 'Y'
			AND		ISNULL(D.PLAN_YN, 'N') = 'Y'
			GROUP	BY B.LOCAT_ITEM_ID, E.LOCAT_ID, B.CUTOFF_DATE
			) A,
			(
			SELECT	B.LOCAT_ID, MIN(A.CUTOFF_DATE) AS CUTOFF_DATE
			FROM	TB_CM_WAREHOUSE_STOCK_MST A,
					(
					SELECT	A.LOCAT_ID, 
							--DATEADD(DD, 1, CONVERT(DATETIME, '20180909', 120)) AS END_DATE
							DATEADD(DD, 1, (SELECT VAL FROM DBO.FN_G_TARGET_DAT(A.ACTUAL_PERIOD, 'END', B.UOM_CD))) AS END_DATE
					FROM	TB_IM_VARIABILITY_ACT_PRIOD A
							INNER JOIN TB_CM_UOM B
							ON B.ID = A.UOM_ID
					WHERE	CATAGY_VAL = 'FINAL_PRODUCT_GR_ITEM_INVTURN'
					) B
			WHERE	A.CUTOFF_DATE = B.END_DATE
			GROUP	BY B.LOCAT_ID
			) B
	WHERE	1=1
	AND		A.LOCAT_ID = B.LOCAT_ID
	AND		A.CUTOFF_DATE = B.CUTOFF_DATE
	GROUP	BY A.LOCAT_ITEM_ID

	/***************************************************************************************************************************************************************************
	2. SITE ITEM 별 세그먼트 정보 추출
	 - VAL_01 : COV (QUADRANT)
	 - VAL_02 : 재고등급(SABC)
	 - VAL_03 : ITEM_TYPE
	 - VAL_04 : 차별화전략
	 - VAL_05 : 재고일수
	 - VAL_06 : 수요예측정확도 (구현안됨)
	 - VAL_07 : 공급변동성
	 - VAL_08 : 단종시점
	 - VAL_09 : 모품목 단종시점
	 - VAL_10 : 수요빈도
	 - VAL_11 : 표준단가
	 - VAL_12 ~ VAL_20 : 구현안됨
	***************************************************************************************************************************************************************************/
	CREATE TABLE #TEMP_SITE_ITEM_SEGMT (
		ID							CHAR(32),
		INV_MGMT_SEGMT_DIM_DTL_ID	CHAR(32) COLLATE DATABASE_DEFAULT
	)

	INSERT INTO #TEMP_SITE_ITEM_SEGMT
	(
		ID,
		INV_MGMT_SEGMT_DIM_DTL_ID
	)
	SELECT	A.LOCAT_ITEM_ID, 
			B.INV_MGMT_SEGMT_DIM_DTL_ID
	FROM	VW_LOCAT_ITEM_INFO A
			LEFT OUTER JOIN
			(
			-- COV (QUADRANT)
			SELECT  A.ID
				   ,B.ID AS INV_MGMT_SEGMT_DIM_DTL_ID
			  FROM  TB_CM_SITE_ITEM A
				   ,TB_IM_SEGMT_DIM_DTL B
				   ,TB_IM_SEGMT_DIM_MST C
				   ,TB_IM_DMND_VARAN_ANLYS_MST D
				   ,TB_AD_COMN_CODE E
			 WHERE 1=1
			   AND C.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
			   AND A.ID = D.LOCAT_ITEM_ID
			   AND E.ID = D.QUADRANT_ID
			   AND B.VAL = E.COMN_CD
			   AND C.SEGMT_DIM_CD = 'VAL_01'
			   AND ISNULL(B.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(C.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(D.ACTV_YN, 'N') = 'Y'
			 UNION ALL
			 -- SABC
			SELECT  A.ID
				   ,B.ID AS INV_MGMT_SEGMT_DIM_DTL_ID
			  FROM  TB_CM_SITE_ITEM A
				   ,TB_IM_SEGMT_DIM_DTL B
				   ,TB_IM_SEGMT_DIM_MST C
				   ,TB_IM_SABC_ANALYSIS_MST D
			 WHERE 1=1
			   AND C.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
			   AND A.ID = D.LOCAT_ITEM_ID
			   AND B.VAL = ISNULL(D.SABC_VAL, D.SABC_PRPSAL_VAL)
			   AND C.SEGMT_DIM_CD = 'VAL_02'
			   AND ISNULL(B.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(C.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(D.ACTV_YN, 'N') = 'Y'
			UNION ALL
			-- ITEM_TYPE
			SELECT  A.ID
				   ,B.ID AS INV_MGMT_SEGMT_DIM_DTL_ID
			  FROM  TB_CM_SITE_ITEM A
				   ,TB_IM_SEGMT_DIM_DTL B
				   ,TB_IM_SEGMT_DIM_MST C
				   ,TB_CM_ITEM_MST D
				   ,TB_CM_ITEM_TYPE E
			 WHERE 1=1
			   AND C.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
			   AND D.ID = A.ITEM_MST_ID
			   AND E.ID = D.ITEM_TP_ID
			   AND B.VAL = E.ITEM_TP
			   AND C.SEGMT_DIM_CD = 'VAL_03'
			   AND ISNULL(B.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(C.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(D.DEL_YN,  'Y') = 'N'
			 UNION ALL
			-- DIFFTD_CLASS
			SELECT  A.ID
				   ,B.ID AS INV_MGMT_SEGMT_DIM_DTL_ID
			  FROM  TB_CM_SITE_ITEM A
				   ,TB_IM_SEGMT_DIM_DTL B
				   ,TB_IM_SEGMT_DIM_MST C
				   ,TB_CM_COMM_CONFIG D
			 WHERE 1=1
			   AND C.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
			   AND D.ID = A.DIFFTD_CLSS_ID
			   AND C.SEGMT_DIM_CD = 'VAL_04'
			   AND ISNULL(B.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(C.ACTV_YN, 'N') = 'Y'
			 UNION ALL
			-- STOCK_DAYS
			SELECT  A.ID
				   ,B.ID AS INV_MGMT_SEGMT_DIM_DTL_ID
			  FROM  (
					SELECT	A.LOCAT_ITEM_ID AS ID, 
							CASE WHEN ISNULL(A.QTY, 0) = 0 THEN 0
								 ELSE ROUND(((ISNULL(B.QTY, 0) + ISNULL(C.QTY, 0)) / 2) / ISNULL(A.QTY, 0), 3) 
							END AS INVTURN
					FROM	#TEMP_DAY_AVG_ACTUAL_SHIPMENT A
							LEFT OUTER JOIN #TEMP_BOH B
							ON A.LOCAT_ITEM_ID = B.LOCAT_ITEM_ID
							LEFT OUTER JOIN #TEMP_EOH C
							ON A.LOCAT_ITEM_ID = C.LOCAT_ITEM_ID
					) A
				   ,TB_IM_SEGMT_DIM_DTL B
				   ,TB_IM_SEGMT_DIM_MST C
			 WHERE 1=1
			   AND C.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
			   AND A.INVTURN BETWEEN B.FROM_VAL AND B.TO_VAL
			   AND C.SEGMT_DIM_CD = 'VAL_05'
			   AND ISNULL(B.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(C.ACTV_YN, 'N') = 'Y'
			 UNION ALL
			-- FORECAST_ACCURACY
			SELECT  A.ID
				   ,B.ID AS INV_MGMT_SEGMT_DIM_DTL_ID
			  FROM  TB_CM_SITE_ITEM A
				   ,TB_IM_SEGMT_DIM_DTL B
				   ,TB_IM_SEGMT_DIM_MST C
			 WHERE 1=2
			   AND C.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
			   AND C.SEGMT_DIM_CD = 'VAL_06'
			   AND ISNULL(B.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(C.ACTV_YN, 'N') = 'Y'
			 UNION ALL
			-- SUPPLY_VARIABILITY
			SELECT  A.ID
				   ,B.ID AS INV_MGMT_SEGMT_DIM_DTL_ID
			  FROM  TB_CM_SITE_ITEM A
				   ,TB_IM_SEGMT_DIM_DTL B
				   ,TB_IM_SEGMT_DIM_MST C
				   ,TB_IM_SPPLY_VARAN_ANLYS_MST D
			 WHERE 1=1
			   AND C.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
			   AND A.ID = D.LOCAT_ITEM_ID
			   AND D.SUPPLY_LEADTIME_VARAN BETWEEN B.FROM_VAL AND B.TO_VAL
			   AND C.SEGMT_DIM_CD = 'VAL_07'
			   AND ISNULL(B.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(C.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(D.ACTV_YN, 'N') = 'Y'
			 UNION ALL
			-- EOL
			SELECT  A.ID
				   ,B.ID AS INV_MGMT_SEGMT_DIM_DTL_ID
			  FROM  TB_CM_SITE_ITEM A
				   ,TB_IM_SEGMT_DIM_DTL B
				   ,TB_IM_SEGMT_DIM_MST C
			 WHERE 1=1
			   AND C.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
			   AND ISNULL(DATEDIFF(DD, GETDATE(), A.EOS), 0) BETWEEN B.FROM_VAL AND B.TO_VAL
			   AND A.EOS IS NOT NULL
			   AND C.SEGMT_DIM_CD = 'VAL_08'
			   AND ISNULL(B.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(C.ACTV_YN, 'N') = 'Y'
			 UNION ALL
			-- PARENT_EOL
			SELECT  A.ID
				   ,B.ID AS INV_MGMT_SEGMT_DIM_DTL_ID
			  FROM  TB_CM_SITE_ITEM A
				   ,TB_IM_SEGMT_DIM_DTL B
				   ,TB_IM_SEGMT_DIM_MST C
			 WHERE 1=1
			   AND C.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
			   AND ISNULL(DATEDIFF(DD, GETDATE(), A.PARENT_ITEM_EOL), 0) BETWEEN B.FROM_VAL AND B.TO_VAL
			   AND A.PARENT_ITEM_EOL IS NOT NULL
			   AND C.SEGMT_DIM_CD = 'VAL_09'
			   AND ISNULL(B.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(C.ACTV_YN, 'N') = 'Y'
			 UNION ALL
			-- DEMAND_FREQUENCY
			SELECT  A.ID
				   ,B.ID AS INV_MGMT_SEGMT_DIM_DTL_ID
			  FROM  TB_CM_SITE_ITEM A
				   ,TB_IM_SEGMT_DIM_DTL B
				   ,TB_IM_SEGMT_DIM_MST C
				   ,TB_IM_DMND_VARAN_ANLYS_MST D
			 WHERE 1=1
			   AND C.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
			   AND A.ID = D.LOCAT_ITEM_ID
			   AND D.AVG_SALES_TIMES BETWEEN B.FROM_VAL AND B.TO_VAL
			   AND C.SEGMT_DIM_CD = 'VAL_10'
			   AND ISNULL(B.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(C.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(D.ACTV_YN, 'N') = 'Y'
			 UNION ALL
			-- STD_UTPIC
			SELECT  A.ID
				   ,B.ID AS INV_MGMT_SEGMT_DIM_DTL_ID
			  FROM  TB_CM_SITE_ITEM A
				   ,TB_IM_SEGMT_DIM_DTL B
				   ,TB_IM_SEGMT_DIM_MST C
			 WHERE 1=1
			   AND C.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
			   AND A.STD_UTPIC BETWEEN B.FROM_VAL AND B.TO_VAL
			   AND ISNULL(A.STD_UTPIC, 0) >= 0
			   AND C.SEGMT_DIM_CD = 'VAL_11'
			   AND ISNULL(B.ACTV_YN, 'N') = 'Y'
			   AND ISNULL(C.ACTV_YN, 'N') = 'Y'
			) B
			ON B.ID = A.LOCAT_ITEM_ID
            LEFT OUTER JOIN TB_CM_LOC_MST C
			ON C.ID = A.LOCAT_MST_ID
	WHERE	1=1
	AND		A.BOM_ITEM_TP_CD = 'FINAL_PRODUCT_GR_ITEM'
	AND		A.ITEM_TP IN ('FG','MD')
	AND     A.INV_POLICY_TARGET_YN = 'Y'

	/***************************************************************************************************************************************************************************
	3. SITE ITEM 별 세그먼트 생성
	***************************************************************************************************************************************************************************/
    DELETE FROM TB_IM_SITE_ITEM_SEG_SUMM

    INSERT INTO TB_IM_SITE_ITEM_SEG_SUMM
    (
        ID
       ,LOCAT_ITEM_ID
       ,VAL_01
       ,VAL_02
       ,VAL_03
       ,VAL_04
       ,VAL_05
       ,VAL_06
       ,VAL_07
       ,VAL_08
       ,VAL_09
       ,VAL_10
       ,VAL_11
       ,VAL_12
       ,VAL_13
       ,VAL_14
       ,VAL_15
       ,VAL_16
       ,VAL_17
       ,VAL_18
       ,VAL_19
       ,VAL_20
       ,CREATE_BY
       ,CREATE_DTTM
    )
    SELECT  REPLACE(NEWID(),'-','')
           ,B.ID
           ,VAL_01
           ,VAL_02
           ,VAL_03
           ,VAL_04
           ,VAL_05
           ,VAL_06
           ,VAL_07
           ,VAL_08
           ,VAL_09
           ,VAL_10
           ,VAL_11
           ,VAL_12
           ,VAL_13
           ,VAL_14
           ,VAL_15
           ,VAL_16
           ,VAL_17
           ,VAL_18
           ,VAL_19
           ,VAL_20
           ,@P_USER_ID
           ,GETDATE()
      FROM  (
            SELECT  C.ID
                   ,A.SEGMT_DIM_CD
                   ,B.MGMT_NM
              FROM  TB_IM_SEGMT_DIM_MST A
                   ,TB_IM_SEGMT_DIM_DTL B
                   ,#TEMP_SITE_ITEM_SEGMT C
             WHERE  A.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
               AND  B.ID = C.INV_MGMT_SEGMT_DIM_DTL_ID
            ) A
      PIVOT (
            MAX(MGMT_NM) FOR SEGMT_DIM_CD IN ( VAL_01,
                                               VAL_02,
                                               VAL_03,
                                               VAL_04,
                                               VAL_05,
                                               VAL_06,
                                               VAL_07,
                                               VAL_08,
                                               VAL_09,
                                               VAL_10,
                                               VAL_11,
                                               VAL_12,
                                               VAL_13,
                                               VAL_14,
                                               VAL_15,
                                               VAL_16,
                                               VAL_17,
                                               VAL_18,
                                               VAL_19,
                                               VAL_20 )
            ) B;

	/***************************************************************************************************************************************************************************
	4. 재고정책 마스터 생성 대상 SEGMENT 추출
	 - Configuration(재고관리 세그먼트 설정) 에서 선택된 Primary, Secondary 기준 대상 추출
	***************************************************************************************************************************************************************************/
	CREATE TABLE #TEMP_SEGMT_TARGET (
		SEG_KEY		NVARCHAR(100),
		PRIM_ID		CHAR(32) COLLATE DATABASE_DEFAULT,
		SECOND_ID	CHAR(32) COLLATE DATABASE_DEFAULT
	)

	CREATE TABLE #TEMP_SEGMT_MGMT (
		SEG_KEY						NVARCHAR(100),
		INV_MGMT_SEGMT_DIM_DTL_ID	CHAR(32) COLLATE DATABASE_DEFAULT
	)

	INSERT INTO #TEMP_SEGMT_TARGET
	(
		SEG_KEY,
		PRIM_ID,
		SECOND_ID
	)
    SELECT  IIF(B.VAL IS NULL, A.VAL, A.VAL + B.VAL) AS SEG_KEY,
			A.ID		AS PRIM_ID, 
			B.ID		AS SECOND_ID
    FROM    (
            SELECT  A.SEGMT_DIM_CD, B.ID, B.VAL
            FROM    TB_IM_SEGMT_DIM_MST A,
                    TB_IM_SEGMT_DIM_DTL B
            WHERE   1=1
            AND     A.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
            AND     A.PRIM_YN = 'Y'
            AND     ISNULL(A.ACTV_YN, 'N') = 'Y'
            AND     ISNULL(B.ACTV_YN, 'N') = 'Y'
            ) A
			LEFT OUTER JOIN
            (
            SELECT  A.SEGMT_DIM_CD, B.ID, B.VAL
            FROM    TB_IM_SEGMT_DIM_MST A,
                    TB_IM_SEGMT_DIM_DTL B
            WHERE   1=1
            AND     A.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
            AND     A.SECOND_YN = 'Y'
            AND     ISNULL(A.ACTV_YN, 'N') = 'Y'
            AND     ISNULL(B.ACTV_YN, 'N') = 'Y'
            ) B
			ON 1=1

	INSERT INTO #TEMP_SEGMT_MGMT
	(
		SEG_KEY,
		INV_MGMT_SEGMT_DIM_DTL_ID
	)
    SELECT  A.SEG_KEY, B.ID AS INV_MGMT_SEGMT_DIM_DTL_ID
    FROM    #TEMP_SEGMT_TARGET A,
            TB_IM_SEGMT_DIM_DTL B
    WHERE   B.ID = A.PRIM_ID
    UNION   ALL
    SELECT  A.SEG_KEY, B.ID AS INV_MGMT_SEGMT_DIM_DTL_ID
    FROM    #TEMP_SEGMT_TARGET A,
            TB_IM_SEGMT_DIM_DTL B
    WHERE   B.ID = A.SECOND_ID

	/***************************************************************************************************************************************************************************
	5. 재고정책 마스터 데이터 생성
	 - APPLY_TARGET = 'GRADE'
	  : 등급별로 재고정책 데이터를 생성함
	 - APPLY_TARGET = 'LOCAT_SEGMT'
	  : 거점별로 재고정책 세그먼트 대상의 조합으로 데이터를 생성함

	6. 발주 캘린더 정보 업데이트
	 - 재고정책 마스터와 매핑되는 발주 캘린더 정보 존재 시 설정
	***************************************************************************************************************************************************************************/
	IF @P_APPLY_POINT_CD = 'ALL'
	BEGIN
		IF @P_APPLY_TARGET = 'GRADE'
			BEGIN
				DELETE FROM TB_IM_INV_POLICY_GRADE_MST
			END
		ELSE
			BEGIN
				DELETE FROM TB_IM_INV_POLICY_MST
			END
	END
    
	IF @P_APPLY_TARGET = 'GRADE'
		BEGIN
			MERGE INTO TB_IM_INV_POLICY_GRADE_MST TARGET
			USING (
					SELECT  A.LOCAT_MST_ID,
							A.GRADE,
							A.ITEM_CNT,
							A.INV_MGMT_SYSTEM_TP_ID,
							A.PO_CYCL_CD_ID,
							A.PO_CYCL_CALENDAR_ID,
							A.INV_PLACE_STRTGY_ID,
							A.SUPPLY_LEADTIME_YN,
							A.PO_CYCL_YN,
							A.OPERT_LV_VAL,
							A.PRPSAL_SVC_LV,
							A.SFST_SVC_LV,
							A.SFST_DEMDVAR_CONSID_YN,
							A.SFST_SUPYVAR_CONSID_YN,
							A.ROP_CAL_TP_ID,
							A.ROP_SFST_CONSID_YN,
							A.ROP_OPERT_INV_CONSID_YN,
							A.ROP_RIGHT_RATE_YN,
							A.EOQ_CAL_TP_ID,
							A.EOQ_RIGHT_RATE_YN,
							A.EOQ_MULTIPLE,
							A.TARGET_INV_SFST_CONSID_YN,
							A.TARGET_INV_OPERT_INV_CONSID_YN
					FROM    (
							SELECT  A.LOCAT_MST_ID, A.VAL_02 AS GRADE, 
									CASE WHEN MAX(B.LOCAT_MST_ID) IS NULL THEN NULL ELSE MAX(B.CNT) END AS ITEM_CNT,
									MAX(C.DEFAT_INV_MGMT_SYSTEM_TP_ID) AS INV_MGMT_SYSTEM_TP_ID,
									MAX(C.DEFAT_PO_CYCL_CD_ID) AS PO_CYCL_CD_ID,
									NULL AS PO_CYCL_CALENDAR_ID,
									MAX(C.DEFAT_INV_PLACE_STRTGY_ID) AS INV_PLACE_STRTGY_ID,
									CASE WHEN MAX(B.SUPPLY_LEADTIME_YN) IS NULL THEN 'Y' ELSE MAX(B.SUPPLY_LEADTIME_YN) END AS SUPPLY_LEADTIME_YN,
									MAX(C.PO_CYCL_YN) AS PO_CYCL_YN,
									CASE WHEN MAX(B.OPERT_LV_VAL) IS NULL THEN NULL ELSE MAX(B.OPERT_LV_VAL) END AS OPERT_LV_VAL,
									MAX(D.SVC_LV) AS PRPSAL_SVC_LV,
									MAX(D.SVC_LV) AS SFST_SVC_LV,
									CASE WHEN MAX(B.SFST_DEMDVAR_CONSID_YN) IS NULL THEN 'Y' ELSE MAX(B.SFST_DEMDVAR_CONSID_YN) END AS SFST_DEMDVAR_CONSID_YN,
									CASE WHEN MAX(B.SFST_SUPYVAR_CONSID_YN) IS NULL THEN 'N' ELSE MAX(B.SFST_SUPYVAR_CONSID_YN) END AS SFST_SUPYVAR_CONSID_YN,
									CASE WHEN MAX(B.ROP_CAL_TP_ID) IS NULL THEN @V_ROP_CAL_TP_ID ELSE MAX(B.ROP_CAL_TP_ID) END AS ROP_CAL_TP_ID,
									CASE WHEN MAX(B.ROP_SFST_CONSID_YN) IS NULL THEN 'Y' ELSE MAX(B.ROP_SFST_CONSID_YN) END AS ROP_SFST_CONSID_YN,
									CASE WHEN MAX(B.ROP_OPERT_INV_CONSID_YN) IS NULL THEN 'N' ELSE MAX(B.ROP_OPERT_INV_CONSID_YN) END AS ROP_OPERT_INV_CONSID_YN,
									CASE WHEN MAX(B.ROP_RIGHT_RATE_YN) IS NULL THEN 'N'  ELSE MAX(B.ROP_RIGHT_RATE_YN) END AS ROP_RIGHT_RATE_YN,
									CASE WHEN MAX(B.EOQ_CAL_TP_ID) IS NULL THEN @V_EOQ_CAL_TP_ID ELSE MAX(B.EOQ_CAL_TP_ID) END AS EOQ_CAL_TP_ID,
									CASE WHEN MAX(B.EOQ_RIGHT_RATE_YN) IS NULL THEN 'N'  ELSE MAX(B.EOQ_RIGHT_RATE_YN) END AS EOQ_RIGHT_RATE_YN,
									CASE WHEN MAX(B.EOQ_MULTIPLE) IS NULL THEN NULL ELSE MAX(B.EOQ_MULTIPLE) END AS EOQ_MULTIPLE,
									CASE WHEN MAX(B.TARGET_INV_SFST_CONSID_YN) IS NULL THEN 'Y' ELSE MAX(B.TARGET_INV_SFST_CONSID_YN) END AS TARGET_INV_SFST_CONSID_YN,
									CASE WHEN MAX(B.TARGET_INV_OPERT_INV_CONSID_YN) IS NULL THEN 'N' ELSE MAX(B.TARGET_INV_OPERT_INV_CONSID_YN) END AS TARGET_INV_OPERT_INV_CONSID_YN
							FROM    
									(
									SELECT	A.LOCAT_MST_ID, B.MGMT_NM AS VAL_02
									FROM	(
											SELECT  DISTINCT
													A.LOCAT_MST_ID
											FROM    VW_LOCAT_ITEM_INFO A
											WHERE   A.BOM_ITEM_TP_CD = 'FINAL_PRODUCT_GR_ITEM'
											AND		A.ITEM_TP IN ('FG','MD')
											AND     A.INV_POLICY_TARGET_YN = 'Y'
											) A
											CROSS JOIN
											( 
											SELECT	B.MGMT_NM
											FROM	TB_IM_SEGMT_DIM_MST A,
													TB_IM_SEGMT_DIM_DTL B
											WHERE	A.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
											AND		A.SEGMT_DIM_CD = 'VAL_02'
											) B
									) A
									LEFT OUTER JOIN
									(
									SELECT  D.LOCAT_MST_ID, 
											B.VAL_02,
											E.CNT,
											C.ID AS INV_POLICY_ID,
											C.INV_MGMT_SYSTEM_TP_ID,
											C.PO_CYCL_CD_ID,
											C.PO_CYCL_CALENDAR_ID,
											C.INV_PLACE_STRTGY_ID,
											C.SUPPLY_LEADTIME_YN,
											C.PO_CYCL_YN,
											C.OPERT_LV_VAL,
											C.PRPSAL_SVC_LV,
											C.SFST_SVC_LV,
											C.SFST_DEMDVAR_CONSID_YN,
											C.SFST_SUPYVAR_CONSID_YN,
											C.ROP_CAL_TP_ID,
											C.ROP_SFST_CONSID_YN,
											C.ROP_OPERT_INV_CONSID_YN,
											C.ROP_RIGHT_RATE_YN,
											C.EOQ_CAL_TP_ID,
											C.EOQ_RIGHT_RATE_YN,
											C.EOQ_MULTIPLE,
											C.TARGET_INV_SFST_CONSID_YN,
											C.TARGET_INV_OPERT_INV_CONSID_YN
									FROM    TB_CM_SITE_ITEM A
											INNER JOIN TB_IM_SITE_ITEM_SEG_SUMM B
											ON A.ID = B.LOCAT_ITEM_ID
											LEFT OUTER JOIN TB_IM_INV_POLICY_ITEM C
											ON A.ID = C.LOCAT_ITEM_ID
											INNER JOIN VW_LOCAT_ITEM_INFO D
											ON A.ID = D.LOCAT_ITEM_ID
											INNER JOIN 
											(
											SELECT	LOCAT_MST_ID, VAL_02, COUNT(*) CNT
											FROM	(
													SELECT	D.LOCAT_MST_ID, VAL_02, A.ITEM_MST_ID
													FROM	TB_CM_SITE_ITEM A
															INNER JOIN TB_IM_SITE_ITEM_SEG_SUMM B
															ON A.ID = B.LOCAT_ITEM_ID
															LEFT OUTER JOIN TB_IM_INV_POLICY_ITEM C
															ON B.LOCAT_ITEM_ID = C.LOCAT_ITEM_ID
															INNER JOIN VW_LOCAT_ITEM_INFO D
															ON A.ID = D.LOCAT_ITEM_ID
													) A
											GROUP	BY LOCAT_MST_ID, VAL_02
											) E
											ON D.LOCAT_MST_ID = E.LOCAT_MST_ID
											AND B.VAL_02 = E.VAL_02
									WHERE	D.INV_POLICY_TARGET_YN = 'Y'
									) B
									ON  A.LOCAT_MST_ID = B.LOCAT_MST_ID
									AND A.VAL_02 = B.VAL_02
									LEFT OUTER JOIN
									(
									SELECT  A.SEGMT_DIM_CD, A.MGMT_NM AS VAL_02, 
											B.ID AS DEFAT_INV_MGMT_SYSTEM_TP_ID,
											C.ID AS DEFAT_PO_CYCL_CD_ID,
											D.ID AS DEFAT_INV_PLACE_STRTGY_ID,
											CASE WHEN PO_CYCL_CD = 'PERIODIC' THEN 'Y' ELSE 'N' END AS PO_CYCL_YN
									FROM
											(
											SELECT  A.SEGMT_DIM_CD, B.MGMT_NM,
													CASE WHEN B.MGMT_NM = 'S' OR B.MGMT_NM = 'A' THEN 'TARGET_INVENTORY_MGMT_SYSTEM' ELSE 'REORDER_POINT_MGMT_SYSTEM' END AS INV_MGMT_SYSTEM_TP_CD,
													CASE WHEN B.MGMT_NM = 'S' OR B.MGMT_NM = 'A' THEN 'PERIODIC' ELSE 'NON-PERIODIC' END AS PO_CYCL_CD,
													CASE WHEN B.MGMT_NM = 'S' OR B.MGMT_NM = 'A' THEN 'FRONT_DEPLOY' ELSE 'REAR_DEPLOY' END AS INV_PLACE_STRTGY_CD
											FROM    TB_IM_SEGMT_DIM_MST A,
													TB_IM_SEGMT_DIM_DTL B
											WHERE   1=1
											AND     A.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
											AND     A.SEGMT_DIM_NM = 'SABC'
											) A
											LEFT OUTER JOIN TB_AD_COMN_CODE B
											ON B.COMN_CD = A.INV_MGMT_SYSTEM_TP_CD
											LEFT OUTER JOIN TB_AD_COMN_CODE C
											ON C.COMN_CD = A.PO_CYCL_CD
											LEFT OUTER JOIN TB_AD_COMN_CODE D
											ON D.COMN_CD = A.INV_PLACE_STRTGY_CD
									) C
									ON A.VAL_02 = C.VAL_02
									LEFT OUTER JOIN
									(
									SELECT  E.ID, C.INV_CLSS_TP, MAX(C.SVC_LV) AS SVC_LV
									FROM    TB_IM_SABC_CAL_BASE A,
											TB_AD_COMN_CODE B,
											TB_IM_STOCK_CLASS_MGMT C,
											TB_CM_LOC_DTL D,
											TB_CM_LOC_MST E
									WHERE   B.ID = A.SABC_CAL_BASE_ID
									AND     A.LOCAT_ID = C.LOCAT_ID
									AND     B.COMN_CD = C.CATAGY_VAL
									AND		D.ID = C.LOCAT_ID
									AND		E.ID = D.LOCAT_MST_ID
									AND     ISNULL(A.ACTV_YN, 'N') = 'Y'
									AND     ISNULL(C.ACTV_YN, 'N') = 'Y'
									GROUP	BY E.ID, C.INV_CLSS_TP
									) D
									ON A.LOCAT_MST_ID = D.ID
									AND A.VAL_02 = D.INV_CLSS_TP
							WHERE   1=1
							GROUP   BY A.LOCAT_MST_ID, A.VAL_02
							) A
				) SOURCE 
				ON (
						TARGET.LOCAT_MST_ID = SOURCE.LOCAT_MST_ID 
				AND		TARGET.GRADE = SOURCE.GRADE
				   )
				WHEN NOT MATCHED THEN
					INSERT  (
							ID,
							LOCAT_MST_ID,
							GRADE,
							ITEM_CNT,
							INV_MGMT_SYSTEM_TP_ID,
							PO_CYCL_CD_ID,
							PO_CYCL_CALENDAR_ID,
							INV_PLACE_STRTGY_ID,
							SUPPLY_LEADTIME_YN,
							PO_CYCL_YN,
							OPERT_LV_VAL,
							PRPSAL_SVC_LV,
							SFST_SVC_LV,
							SFST_DEMDVAR_CONSID_YN,
							SFST_SUPYVAR_CONSID_YN,
							ROP_CAL_TP_ID,
							ROP_SFST_CONSID_YN,
							ROP_OPERT_INV_CONSID_YN,
							ROP_RIGHT_RATE_YN,
							EOQ_CAL_TP_ID,
							EOQ_RIGHT_RATE_YN,
							EOQ_MULTIPLE,
							TARGET_INV_SFST_CONSID_YN,
							TARGET_INV_OPERT_INV_CONSID_YN,
							FIXED_YN,
							ACTV_YN,
							CREATE_BY,
							CREATE_DTTM
							)
					VALUES  (
							REPLACE(NEWID(),'-',''),
							SOURCE.LOCAT_MST_ID,
							SOURCE.GRADE,
							SOURCE.ITEM_CNT,
							SOURCE.INV_MGMT_SYSTEM_TP_ID,
							SOURCE.PO_CYCL_CD_ID,
							SOURCE.PO_CYCL_CALENDAR_ID,
							SOURCE.INV_PLACE_STRTGY_ID,
							SOURCE.SUPPLY_LEADTIME_YN,
							SOURCE.PO_CYCL_YN,
							SOURCE.OPERT_LV_VAL,
							SOURCE.PRPSAL_SVC_LV,
							SOURCE.SFST_SVC_LV,
							SOURCE.SFST_DEMDVAR_CONSID_YN,
							SOURCE.SFST_SUPYVAR_CONSID_YN,
							SOURCE.ROP_CAL_TP_ID,
							SOURCE.ROP_SFST_CONSID_YN,
							SOURCE.ROP_OPERT_INV_CONSID_YN,
							SOURCE.ROP_RIGHT_RATE_YN,
							SOURCE.EOQ_CAL_TP_ID,
							SOURCE.EOQ_RIGHT_RATE_YN,
							SOURCE.EOQ_MULTIPLE,
							SOURCE.TARGET_INV_SFST_CONSID_YN,
							SOURCE.TARGET_INV_OPERT_INV_CONSID_YN,
							'N', 
							'Y',
							@P_USER_ID, 
							GETDATE()
							);

		END
	ELSE
		BEGIN
			MERGE INTO TB_IM_INV_POLICY_MST TARGET
			USING (
					SELECT  A.LOCAT_ID,
							A.VAL_01,
							A.VAL_02,
							A.VAL_03,
							A.VAL_04,
							A.VAL_05,
							A.VAL_06,
							A.VAL_07,
							A.VAL_08,
							A.VAL_09,
							A.VAL_10,
							A.VAL_11,
							A.VAL_12,
							A.VAL_13,
							A.VAL_14,
							A.VAL_15,
							A.VAL_16,
							A.VAL_17,
							A.VAL_18,
							A.VAL_19,
							A.VAL_20,
							A.ITEM_CNT,
							A.INV_MGMT_SYSTEM_TP_ID,
							A.PO_CYCL_CD_ID,
							A.PO_CYCL_CALENDAR_ID,
							A.INV_PLACE_STRTGY_ID,
							A.SUPPLY_LEADTIME_YN,
							A.PO_CYCL_YN,
							A.OPERT_LV_VAL,
							A.PRPSAL_SVC_LV,
							A.SFST_SVC_LV,
							A.SFST_DEMDVAR_CONSID_YN,
							A.SFST_SUPYVAR_CONSID_YN,
							A.ROP_CAL_TP_ID,
							A.ROP_SFST_CONSID_YN,
							A.ROP_OPERT_INV_CONSID_YN,
							A.ROP_RIGHT_RATE_YN,
							A.EOQ_CAL_TP_ID,
							A.EOQ_RIGHT_RATE_YN,
							A.EOQ_MULTIPLE,
							A.TARGET_INV_SFST_CONSID_YN,
							A.TARGET_INV_OPERT_INV_CONSID_YN
					FROM    (
							SELECT  A.LOCAT_ID,
									A.VAL_01, A.VAL_02, A.VAL_03, A.VAL_04, A.VAL_05, A.VAL_06, A.VAL_07, A.VAL_08, A.VAL_09, A.VAL_10,
									A.VAL_11, A.VAL_12, A.VAL_13, A.VAL_14, A.VAL_15, A.VAL_16, A.VAL_17, A.VAL_18, A.VAL_19, A.VAL_20,
									CASE WHEN MAX(B.ID) IS NULL THEN NULL ELSE COUNT(*) END AS ITEM_CNT,
									CASE WHEN MAX(B.INV_MGMT_SYSTEM_TP_ID) IS NULL THEN MAX(C.DEFAT_INV_MGMT_SYSTEM_TP_ID) ELSE MAX(B.INV_MGMT_SYSTEM_TP_ID) END AS INV_MGMT_SYSTEM_TP_ID,
									CASE WHEN MAX(B.PO_CYCL_CD_ID) IS NULL THEN MAX(C.DEFAT_PO_CYCL_CD_ID) ELSE MAX(B.PO_CYCL_CD_ID) END AS PO_CYCL_CD_ID,
									CASE WHEN MAX(B.PO_CYCL_CALENDAR_ID) IS NULL THEN NULL ELSE MAX(B.PO_CYCL_CALENDAR_ID) END AS PO_CYCL_CALENDAR_ID,
									CASE WHEN MAX(B.INV_PLACE_STRTGY_ID) IS NULL THEN MAX(C.DEFAT_INV_PLACE_STRTGY_ID) ELSE MAX(B.INV_PLACE_STRTGY_ID) END AS INV_PLACE_STRTGY_ID,
									CASE WHEN MAX(B.SUPPLY_LEADTIME_YN) IS NULL THEN 'Y' ELSE MAX(B.SUPPLY_LEADTIME_YN) END AS SUPPLY_LEADTIME_YN,
									CASE WHEN MAX(B.PO_CYCL_YN) IS NULL THEN MAX(C.PO_CYCL_YN) ELSE MAX(B.PO_CYCL_YN) END AS PO_CYCL_YN,
									CASE WHEN MAX(B.OPERT_LV_VAL) IS NULL THEN NULL ELSE MAX(B.OPERT_LV_VAL) END AS OPERT_LV_VAL,
									CASE WHEN MAX(ISNULL(B.PRPSAL_SVC_LV, 0)) > 0 THEN MAX(B.PRPSAL_SVC_LV)
										 WHEN MAX(D.TARGET_SVC_CAL_BASE) = 'COV' THEN MAX(E.SVC_LV)
										 ELSE MAX(F.SVC_LV) END AS PRPSAL_SVC_LV,
									CASE WHEN MAX(ISNULL(B.SFST_SVC_LV, 0)) > 0 THEN MAX(B.SFST_SVC_LV)
										 WHEN MAX(D.TARGET_SVC_CAL_BASE) = 'COV' THEN MAX(E.SVC_LV)
										 ELSE MAX(F.SVC_LV) END AS SFST_SVC_LV,
									CASE WHEN MAX(B.SFST_DEMDVAR_CONSID_YN) IS NULL THEN 'Y' ELSE MAX(B.SFST_DEMDVAR_CONSID_YN) END AS SFST_DEMDVAR_CONSID_YN,
									CASE WHEN MAX(B.SFST_SUPYVAR_CONSID_YN) IS NULL THEN 'N' ELSE MAX(B.SFST_SUPYVAR_CONSID_YN) END AS SFST_SUPYVAR_CONSID_YN,
									CASE WHEN MAX(B.ROP_CAL_TP_ID) IS NULL THEN @V_ROP_CAL_TP_ID ELSE MAX(B.ROP_CAL_TP_ID) END AS ROP_CAL_TP_ID,
									CASE WHEN MAX(B.ROP_SFST_CONSID_YN) IS NULL THEN 'Y' ELSE MAX(B.ROP_SFST_CONSID_YN) END AS ROP_SFST_CONSID_YN,
									CASE WHEN MAX(B.ROP_OPERT_INV_CONSID_YN) IS NULL THEN 'N' ELSE MAX(B.ROP_OPERT_INV_CONSID_YN) END AS ROP_OPERT_INV_CONSID_YN,
									CASE WHEN MAX(B.ROP_RIGHT_RATE_YN) IS NULL THEN 'N'  ELSE MAX(B.ROP_RIGHT_RATE_YN) END AS ROP_RIGHT_RATE_YN,
									CASE WHEN MAX(B.EOQ_CAL_TP_ID) IS NULL THEN @V_EOQ_CAL_TP_ID ELSE MAX(B.EOQ_CAL_TP_ID) END AS EOQ_CAL_TP_ID,
									CASE WHEN MAX(B.EOQ_RIGHT_RATE_YN) IS NULL THEN 'N'  ELSE MAX(B.EOQ_RIGHT_RATE_YN) END AS EOQ_RIGHT_RATE_YN,
									CASE WHEN MAX(B.EOQ_MULTIPLE) IS NULL THEN NULL ELSE MAX(B.EOQ_MULTIPLE) END AS EOQ_MULTIPLE,
									CASE WHEN MAX(B.TARGET_INV_SFST_CONSID_YN) IS NULL THEN 'Y' ELSE MAX(B.TARGET_INV_SFST_CONSID_YN) END AS TARGET_INV_SFST_CONSID_YN,
									CASE WHEN MAX(B.TARGET_INV_OPERT_INV_CONSID_YN) IS NULL THEN 'N' ELSE MAX(B.TARGET_INV_OPERT_INV_CONSID_YN) END AS TARGET_INV_OPERT_INV_CONSID_YN
							FROM    
									(
									SELECT  B.ID, B.LOCAT_ID, B.LOCAT_CD, 
											A.VAL_01, A.VAL_02, A.VAL_03, A.VAL_04, A.VAL_05, A.VAL_06, A.VAL_07, A.VAL_08, A.VAL_09, A.VAL_10,
											A.VAL_11, A.VAL_12, A.VAL_13, A.VAL_14, A.VAL_15, A.VAL_16, A.VAL_17, A.VAL_18, A.VAL_19, A.VAL_20
									FROM    
											(
											SELECT  A.SEG_KEY
												   ,A.VAL_01
												   ,A.VAL_02
												   ,A.VAL_03
												   ,A.VAL_04
												   ,A.VAL_05
												   ,A.VAL_06
												   ,A.VAL_07
												   ,A.VAL_08
												   ,A.VAL_09
												   ,A.VAL_10
												   ,A.VAL_11
												   ,A.VAL_12
												   ,A.VAL_13
												   ,A.VAL_14
												   ,A.VAL_15
												   ,A.VAL_16
												   ,A.VAL_17
												   ,A.VAL_18
												   ,A.VAL_19
												   ,A.VAL_20
											  FROM (
													SELECT  C.SEG_KEY
														   ,A.SEGMT_DIM_CD
														   ,B.MGMT_NM
													  FROM TB_IM_SEGMT_DIM_MST A
														   LEFT OUTER JOIN 
														   TB_IM_SEGMT_DIM_DTL B
														ON A.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
														   LEFT OUTER JOIN
														   #TEMP_SEGMT_MGMT C
														ON  B.ID = C.INV_MGMT_SEGMT_DIM_DTL_ID
												   ) A 
												   PIVOT (
														MAX(MGMT_NM) FOR SEGMT_DIM_CD IN ( VAL_01,
																							VAL_02,
																							VAL_03,
																							VAL_04,
																							VAL_05,
																							VAL_06,
																							VAL_07,
																							VAL_08,
																							VAL_09,
																							VAL_10,
																							VAL_11,
																							VAL_12,
																							VAL_13,
																							VAL_14,
																							VAL_15,
																							VAL_16,
																							VAL_17,
																							VAL_18,
																							VAL_19,
																							VAL_20 )
														 ) A
											WHERE A.SEG_KEY IS NOT NULL
											) A,
											(
											SELECT  DISTINCT
													A.LOCAT_MGMT_ID AS ID,
													A.LOCAT_ID,
													A.LOCAT_CD
											FROM    VW_LOCAT_ITEM_INFO A
											WHERE   A.BOM_ITEM_TP_CD = 'FINAL_PRODUCT_GR_ITEM'
											AND		A.ITEM_TP IN ('FG','MD')
											AND     A.INV_POLICY_TARGET_YN = 'Y'
											) B
									) A
									LEFT OUTER JOIN
									(
									SELECT  A.LOCAT_MGMT_ID, B.ID,
											B.VAL_01, B.VAL_02, B.VAL_03, B.VAL_04, B.VAL_05, B.VAL_06, B.VAL_07, B.VAL_08, B.VAL_09, B.VAL_10,
											B.VAL_11, B.VAL_12, B.VAL_13, B.VAL_14, B.VAL_15, B.VAL_16, B.VAL_17, B.VAL_18, B.VAL_19, B.VAL_20,
											C.ID AS INV_POLICY_ID,
											C.INV_MGMT_SYSTEM_TP_ID,
											C.PO_CYCL_CD_ID,
											C.PO_CYCL_CALENDAR_ID,
											C.INV_PLACE_STRTGY_ID,
											C.SUPPLY_LEADTIME_YN,
											C.PO_CYCL_YN,
											C.OPERT_LV_VAL,
											C.PRPSAL_SVC_LV,
											C.SFST_SVC_LV,
											C.SFST_DEMDVAR_CONSID_YN,
											C.SFST_SUPYVAR_CONSID_YN,
											C.ROP_CAL_TP_ID,
											C.ROP_SFST_CONSID_YN,
											C.ROP_OPERT_INV_CONSID_YN,
											C.ROP_RIGHT_RATE_YN,
											C.EOQ_CAL_TP_ID,
											C.EOQ_RIGHT_RATE_YN,
											C.EOQ_MULTIPLE,
											C.TARGET_INV_SFST_CONSID_YN,
											C.TARGET_INV_OPERT_INV_CONSID_YN
									FROM    TB_CM_SITE_ITEM A
											INNER JOIN TB_IM_SITE_ITEM_SEG_SUMM B
											ON A.ID = B.LOCAT_ITEM_ID
											LEFT OUTER JOIN TB_IM_INV_POLICY_ITEM C
											ON B.LOCAT_ITEM_ID = C.LOCAT_ITEM_ID
									) B
									ON  A.ID = B.LOCAT_MGMT_ID
									AND ISNULL(A.VAL_01, '*') = CASE WHEN A.VAL_01 IS NULL THEN '*' ELSE ISNULL(B.VAL_01, '*') END
									AND ISNULL(A.VAL_02, '*') = CASE WHEN A.VAL_02 IS NULL THEN '*' ELSE ISNULL(B.VAL_02, '*') END
									AND ISNULL(A.VAL_03, '*') = CASE WHEN A.VAL_03 IS NULL THEN '*' ELSE ISNULL(B.VAL_03, '*') END
									AND ISNULL(A.VAL_04, '*') = CASE WHEN A.VAL_04 IS NULL THEN '*' ELSE ISNULL(B.VAL_04, '*') END
									AND ISNULL(A.VAL_05, '*') = CASE WHEN A.VAL_05 IS NULL THEN '*' ELSE ISNULL(B.VAL_05, '*') END
									AND ISNULL(A.VAL_06, '*') = CASE WHEN A.VAL_06 IS NULL THEN '*' ELSE ISNULL(B.VAL_06, '*') END
									AND ISNULL(A.VAL_07, '*') = CASE WHEN A.VAL_07 IS NULL THEN '*' ELSE ISNULL(B.VAL_07, '*') END
									AND ISNULL(A.VAL_08, '*') = CASE WHEN A.VAL_08 IS NULL THEN '*' ELSE ISNULL(B.VAL_08, '*') END
									AND ISNULL(A.VAL_09, '*') = CASE WHEN A.VAL_09 IS NULL THEN '*' ELSE ISNULL(B.VAL_09, '*') END
									AND ISNULL(A.VAL_10, '*') = CASE WHEN A.VAL_10 IS NULL THEN '*' ELSE ISNULL(B.VAL_10, '*') END
									AND ISNULL(A.VAL_11, '*') = CASE WHEN A.VAL_11 IS NULL THEN '*' ELSE ISNULL(B.VAL_11, '*') END
									AND ISNULL(A.VAL_12, '*') = CASE WHEN A.VAL_12 IS NULL THEN '*' ELSE ISNULL(B.VAL_12, '*') END
									AND ISNULL(A.VAL_13, '*') = CASE WHEN A.VAL_13 IS NULL THEN '*' ELSE ISNULL(B.VAL_13, '*') END
									AND ISNULL(A.VAL_14, '*') = CASE WHEN A.VAL_14 IS NULL THEN '*' ELSE ISNULL(B.VAL_14, '*') END
									AND ISNULL(A.VAL_15, '*') = CASE WHEN A.VAL_15 IS NULL THEN '*' ELSE ISNULL(B.VAL_15, '*') END
									AND ISNULL(A.VAL_16, '*') = CASE WHEN A.VAL_16 IS NULL THEN '*' ELSE ISNULL(B.VAL_16, '*') END
									AND ISNULL(A.VAL_17, '*') = CASE WHEN A.VAL_17 IS NULL THEN '*' ELSE ISNULL(B.VAL_17, '*') END
									AND ISNULL(A.VAL_18, '*') = CASE WHEN A.VAL_18 IS NULL THEN '*' ELSE ISNULL(B.VAL_18, '*') END
									AND ISNULL(A.VAL_19, '*') = CASE WHEN A.VAL_19 IS NULL THEN '*' ELSE ISNULL(B.VAL_19, '*') END
									AND ISNULL(A.VAL_20, '*') = CASE WHEN A.VAL_20 IS NULL THEN '*' ELSE ISNULL(B.VAL_20, '*') END
									LEFT OUTER JOIN
									(
									SELECT  A.SEGMT_DIM_CD, A.MGMT_NM AS VAL_02, 
											B.ID AS DEFAT_INV_MGMT_SYSTEM_TP_ID,
											C.ID AS DEFAT_PO_CYCL_CD_ID,
											D.ID AS DEFAT_INV_PLACE_STRTGY_ID,
											CASE WHEN PO_CYCL_CD = 'PERIODIC' THEN 'Y' ELSE 'N' END AS PO_CYCL_YN
									FROM
											(
											SELECT  A.SEGMT_DIM_CD, B.MGMT_NM,
													CASE WHEN B.MGMT_NM = 'S' OR B.MGMT_NM = 'A' THEN 'TARGET_INVENTORY_MGMT_SYSTEM' ELSE 'REORDER_POINT_MGMT_SYSTEM' END AS INV_MGMT_SYSTEM_TP_CD,
													CASE WHEN B.MGMT_NM = 'S' OR B.MGMT_NM = 'A' THEN 'PERIODIC' ELSE 'NON-PERIODIC' END AS PO_CYCL_CD,
													CASE WHEN B.MGMT_NM = 'S' OR B.MGMT_NM = 'A' THEN 'FRONT_DEPLOY' ELSE 'REAR_DEPLOY' END AS INV_PLACE_STRTGY_CD
											FROM    TB_IM_SEGMT_DIM_MST A,
													TB_IM_SEGMT_DIM_DTL B
											WHERE   1=1
											AND     A.ID = B.INV_MGMT_SEGMT_DIM_MST_ID
											AND     A.SEGMT_DIM_NM = 'SABC'
											) A
											LEFT OUTER JOIN TB_AD_COMN_CODE B
											ON B.COMN_CD = A.INV_MGMT_SYSTEM_TP_CD
											LEFT OUTER JOIN TB_AD_COMN_CODE C
											ON C.COMN_CD = A.PO_CYCL_CD
											LEFT OUTER JOIN TB_AD_COMN_CODE D
											ON D.COMN_CD = A.INV_PLACE_STRTGY_CD
									) C
									ON A.VAL_02 = C.VAL_02
									LEFT OUTER JOIN
									(
									SELECT  A.LOCAT_ID, B.COMN_CD AS TARGET_SVC_CAL_BASE
									FROM    TB_IM_TARGET_SVC_CAL_BASE A,
											TB_AD_COMN_CODE B
									WHERE   B.ID = A.TARGET_SVC_CAL_BASE_ID
									AND     ISNULL(A.ACTV_YN, 'N') = 'Y'
									) D
									ON A.LOCAT_ID = D.LOCAT_ID
									LEFT OUTER JOIN
									(
									SELECT  A.LOCAT_ID, 
											B.COMN_CD AS COV,
											CASE WHEN B.SEQ = 1 THEN A.SVC_LV_01
												 WHEN B.SEQ = 2 THEN A.SVC_LV_02
												 WHEN B.SEQ = 3 THEN A.SVC_LV_03
												 ELSE A.SVC_LV_04 END AS SVC_LV
									FROM    TB_IM_DMND_VARIABILITY_BASE A,
											(
											SELECT  ROW_NUMBER() OVER (ORDER BY B.COMN_CD) AS SEQ, B.COMN_CD
											FROM    TB_AD_COMN_GRP A,
													TB_AD_COMN_CODE B
											WHERE   A.ID = B.SRC_ID
											AND     A.GRP_CD = 'QUADRANT'
											) B
									WHERE   ISNULL(A.ACTV_YN, 'N') = 'Y'
									) E
									ON A.LOCAT_ID = E.LOCAT_ID
									AND A.VAL_01 = E.COV
									LEFT OUTER JOIN
									(
									SELECT  A.LOCAT_ID, C.INV_CLSS_TP, C.SVC_LV
									FROM    TB_IM_SABC_CAL_BASE A,
											TB_AD_COMN_CODE B,
											TB_IM_STOCK_CLASS_MGMT C
									WHERE   B.ID = A.SABC_CAL_BASE_ID
									AND     A.LOCAT_ID = C.LOCAT_ID
									AND     B.COMN_CD = C.CATAGY_VAL
									AND     ISNULL(A.ACTV_YN, 'N') = 'Y'
									AND     ISNULL(C.ACTV_YN, 'N') = 'Y'
									) F
									ON A.LOCAT_ID = F.LOCAT_ID
									AND A.VAL_02 = F.INV_CLSS_TP
							WHERE   1=1
							GROUP   BY A.LOCAT_ID,
									A.VAL_01, A.VAL_02, A.VAL_03, A.VAL_04, A.VAL_05, A.VAL_06, A.VAL_07, A.VAL_08, A.VAL_09, A.VAL_10,
									A.VAL_11, A.VAL_12, A.VAL_13, A.VAL_14, A.VAL_15, A.VAL_16, A.VAL_17, A.VAL_18, A.VAL_19, A.VAL_20
							) A
				) SOURCE 
				ON (
						TARGET.LOCAT_ID = SOURCE.LOCAT_ID 
				AND		ISNULL(TARGET.VAL_01, '') = IIF(SOURCE.VAL_01 IS NULL, ISNULL(TARGET.VAL_01, ''), ISNULL(SOURCE.VAL_01, ''))
				AND		ISNULL(TARGET.VAL_02, '') = IIF(SOURCE.VAL_02 IS NULL, ISNULL(TARGET.VAL_02, ''), ISNULL(SOURCE.VAL_02, ''))
				   )
				WHEN NOT MATCHED THEN
					INSERT  (
							ID,
							LOCAT_ID,
							VAL_01,
							VAL_02,
							VAL_03,
							VAL_04,
							VAL_05,
							VAL_06,
							VAL_07,
							VAL_08,
							VAL_09,
							VAL_10,
							VAL_11,
							VAL_12,
							VAL_13,
							VAL_14,
							VAL_15,
							VAL_16,
							VAL_17,
							VAL_18,
							VAL_19,
							VAL_20,
							ITEM_CNT,
							INV_MGMT_SYSTEM_TP_ID,
							PO_CYCL_CD_ID,
							PO_CYCL_CALENDAR_ID,
							INV_PLACE_STRTGY_ID,
							SUPPLY_LEADTIME_YN,
							PO_CYCL_YN,
							OPERT_LV_VAL,
							PRPSAL_SVC_LV,
							SFST_SVC_LV,
							SFST_DEMDVAR_CONSID_YN,
							SFST_SUPYVAR_CONSID_YN,
							ROP_CAL_TP_ID,
							ROP_SFST_CONSID_YN,
							ROP_OPERT_INV_CONSID_YN,
							ROP_RIGHT_RATE_YN,
							EOQ_CAL_TP_ID,
							EOQ_RIGHT_RATE_YN,
							EOQ_MULTIPLE,
							TARGET_INV_SFST_CONSID_YN,
							TARGET_INV_OPERT_INV_CONSID_YN,
							FIXED_YN,
							ACTV_YN,
							CREATE_BY,
							CREATE_DTTM
							)
					VALUES  (
							REPLACE(NEWID(),'-',''),
							SOURCE.LOCAT_ID,
							SOURCE.VAL_01,
							SOURCE.VAL_02,
							SOURCE.VAL_03,
							SOURCE.VAL_04,
							SOURCE.VAL_05,
							SOURCE.VAL_06,
							SOURCE.VAL_07,
							SOURCE.VAL_08,
							SOURCE.VAL_09,
							SOURCE.VAL_10,
							SOURCE.VAL_11,
							SOURCE.VAL_12,
							SOURCE.VAL_13,
							SOURCE.VAL_14,
							SOURCE.VAL_15,
							SOURCE.VAL_16,
							SOURCE.VAL_17,
							SOURCE.VAL_18,
							SOURCE.VAL_19,
							SOURCE.VAL_20,
							SOURCE.ITEM_CNT,
							SOURCE.INV_MGMT_SYSTEM_TP_ID,
							SOURCE.PO_CYCL_CD_ID,
							SOURCE.PO_CYCL_CALENDAR_ID,
							SOURCE.INV_PLACE_STRTGY_ID,
							SOURCE.SUPPLY_LEADTIME_YN,
							SOURCE.PO_CYCL_YN,
							SOURCE.OPERT_LV_VAL,
							SOURCE.PRPSAL_SVC_LV,
							SOURCE.SFST_SVC_LV,
							SOURCE.SFST_DEMDVAR_CONSID_YN,
							SOURCE.SFST_SUPYVAR_CONSID_YN,
							SOURCE.ROP_CAL_TP_ID,
							SOURCE.ROP_SFST_CONSID_YN,
							SOURCE.ROP_OPERT_INV_CONSID_YN,
							SOURCE.ROP_RIGHT_RATE_YN,
							SOURCE.EOQ_CAL_TP_ID,
							SOURCE.EOQ_RIGHT_RATE_YN,
							SOURCE.EOQ_MULTIPLE,
							SOURCE.TARGET_INV_SFST_CONSID_YN,
							SOURCE.TARGET_INV_OPERT_INV_CONSID_YN,
							'N', 
							'Y',
							@P_USER_ID, 
							GETDATE()
							);

			UPDATE	A
			SET		A.PO_CYCL_CALENDAR_ID = B.PO_CYCL_CALENDAR_ID
			FROM	TB_IM_INV_POLICY_MST A
					INNER JOIN 
					(
					SELECT	B.LOCAT_ID, A.INV_MGMT_SYSTEM_TP_ID, 
							A.ID AS PO_CYCL_CALENDAR_ID
					FROM	TB_IM_PO_CALENDAR A
							INNER JOIN TB_CM_LOC_MGMT B
							ON B.ID = A.LOCAT_MGMT_ID
					) B
					ON A.LOCAT_ID = B.LOCAT_ID
					AND A.INV_MGMT_SYSTEM_TP_ID = B.INV_MGMT_SYSTEM_TP_ID
			WHERE	A.PO_CYCL_CALENDAR_ID IS NULL
		END
	
	DROP TABLE #TEMP_DAY_AVG_ACTUAL_SHIPMENT;
	DROP TABLE #TEMP_BOH;
	DROP TABLE #TEMP_EOH;
	DROP TABLE #TEMP_SITE_ITEM_SEGMT;
	DROP TABLE #TEMP_SEGMT_TARGET;
	DROP TABLE #TEMP_SEGMT_MGMT;

	SET @P_RT_ROLLBACK_FLAG = 'true'
	SET @P_RT_MSG = 'MSG_0003'

END TRY

BEGIN CATCH
	IF(ERROR_MESSAGE() LIKE 'MSG_%')
		BEGIN
			SET @P_ERR_MSG = ERROR_MESSAGE()
			SET @P_RT_ROLLBACK_FLAG = 'false'
			SET @P_RT_MSG = @P_ERR_MSG
		END
	ELSE
		THROW;
END CATCH;

go

