/*****************************************************************************
Title : [SP_UI_DP_35_VALID_Q10_U_I_ITEM_LV_CD] 
최초 작성자 : 이고은
최초 생성일 : 2017.08.30
 
설명 
 - DP VALIDATION (U_I_ITEM_LV_CD)-- ALL/ USER
 
History (수정일자 / 수정자 / 수정내용)
-  2017.08.30 / 이고은 / 최초 작성
- 2020.03.12 / KSH / + USER_ID  
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_35_Q10_I_ITEM_LV_CD] 
(	
	 @p_OPERATOR_ID		NVARCHAR(100) = ''
	,@p_AUTH_TP_ID	NVARCHAR(50) = ''
) 
AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

	SELECT	B.USERNAME as USER_ID,B.USERNAME as EMP_NO,B.DISPLAY_NAME as EMP_NM, A.AUTH_TP_ID, L.LV_NM AS AUTH_TP_NM, A.ITEM_LV_ID, C.ITEM_LV_NM, 
	           CASE WHEN ISNULL(C.DEL_YN, 'N') = 'Y' THEN 'MASTER DATA 삭제' 
				   WHEN C.ACTV_YN = 'N' THEN 'MASTER DATA 비활성화'
				  ELSE '그외(I/F 문제등)' END ERR_DESC
	FROM	TB_DP_USER_ITEM_MAP					A 
			INNER JOIN TB_AD_USER				B  ON A.EMP_ID = B.ID
			LEFT OUTER JOIN TB_CM_ITEM_LEVEL_MGMT	C  ON A.ITEM_LV_ID = C.ID
            LEFT OUTER JOIN TB_CM_LEVEL_MGMT L
            ON A.AUTH_TP_ID = L.ID            
	WHERE	A.LV_MGMT_ID IN	(
							SELECT A.ID FROM TB_CM_LEVEL_MGMT	A 
							INNER JOIN  TB_CM_COMM_CONFIG		B  ON A.LV_TP_ID = B.ID AND B.CONF_GRP_CD = 'DP_LV_TP' AND B.CONF_CD = 'I'
							WHERE A.ACTV_YN = 'Y' 
							AND A.LEAF_YN = 'N'
							)
	AND		NOT EXISTS	(
						SELECT 'X'
						FROM TB_CM_ITEM_LEVEL_MGMT X 
						WHERE A.ITEM_LV_ID = X.ID
						AND X.ACTV_YN = 'Y'
						)
	AND		A.AUTH_TP_ID	LIKE '%' + @p_AUTH_TP_ID + '%'
	AND		B.USERNAME		LIKE '%' + @p_OPERATOR_ID	 + '%'
	AND A.ACTV_YN = 'Y'

END


go

