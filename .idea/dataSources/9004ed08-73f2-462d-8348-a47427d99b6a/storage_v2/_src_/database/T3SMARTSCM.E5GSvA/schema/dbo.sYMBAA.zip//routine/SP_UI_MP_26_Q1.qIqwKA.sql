
CREATE PROCEDURE [dbo].[SP_UI_MP_26_Q1] (
	 @P_MAIN_VER_ID NVARCHAR(100) = ''
	,@P_SIMUL_STEP  INT = ''
	,@P_COMP_NUM	INT = 100
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE
	@V_NUM_CNT DECIMAL(20,3) = 100;

BEGIN
	IF @P_COMP_NUM IS NOT NULL
		SET @V_NUM_CNT = @P_COMP_NUM;

	SELECT        
        A.MAIN_VER_ID
        ,A.DESCRIP                   AS MAIN_VER_DESCRIP
        ,B.SIMUL_VER_ID
        ,B.SIMUL_VER_DESCRIP
        ,'Y'                         AS ENGINE_EXE
        ,ISNULL(B.END_DTTM,B.STRT_DTTM) AS ENGINE_EXE_DTTM
        ,D.VER_ID                    AS PLAN_POLICY_VER_ID
        ,E.PLAN_POLICY_VAL_01        AS PLAN_POLICY_DESCRIP
        ,G.PDT_REVENUE               AS PREDICT_REVENUE
		,G.PDT_COST					 AS PREDICT_COST
        ,G.PDT_PROFIT                AS PREDICT_PROFIT
        ,G.AVG_EOH
        ,G.PDT_MOS                   AS PREDICT_MOS
        ,G.AVG_INV_AMT               AS AVG_STOCK_AMT
        ,G.UTILIZATION
        ,G.DMND_QTY
        ,G.ON_TIME_QTY
        ,G.LATE_QTY
        ,G.SHRT_QTY                  AS SHORTAGE_QTY
        ,G.ON_TIME_RATIO
        ,G.DELIVY_RATIO
        ,B.CONFRM_YN
        ,B.CONFRM_DTTM
        ,B.CONFRM_EMP_ID
		,(RIGHT(B.SIMUL_VER_ID , 3)) AS	SIMUL_VER_SEQ
    FROM  TB_CM_CONBD_MAIN_VER_MST A
        INNER JOIN TB_CM_CONBD_MAIN_VER_DTL B
        ON A.ID = B.CONBD_MAIN_VER_MST_ID
        INNER JOIN TB_CM_PLAN_SNRIO_MGMT_DTL C
        ON B.PLAN_SNRIO_MGMT_DTL_ID = C.ID
        INNER JOIN TB_CM_PLAN_POLICY_MGMT D
        ON C.PLAN_POLICY_MGMT_ID = D.ID
        INNER JOIN TB_CM_PLAN_POLICY_VALUE E
        ON  D.ID = E.PLAN_POLICY_MGMT_ID
        INNER JOIN TB_CM_PLAN_POLICY_MST F
        ON  E.PLAN_POLICY_MST_ID = F.ID
        AND  F.PLAN_POLICY_ITEM_ID = 'M00020000'
        INNER JOIN TB_RT_MP_COMPARE_ANALYSIS G
        ON B.ID = G.CONBD_MAIN_VER_DTL_ID
    WHERE 1=1
    AND B.SIMUL_VER_ID IN (
                            SELECT A.VERSION_ID 
                            FROM (
                                    SELECT B.SIMUL_VER_ID AS VERSION_ID
                                        ,ROW_NUMBER() OVER(ORDER BY B.CREATE_DTTM DESC) AS ROW_SEQ
                                    FROM TB_CM_CONBD_MAIN_VER_MST A
                                        ,TB_CM_CONBD_MAIN_VER_DTL B
                                        ,TB_CM_PLAN_SNRIO_MGMT_DTL C
                                    WHERE A.ID = B.CONBD_MAIN_VER_MST_ID
                                    AND B.PLAN_SNRIO_MGMT_DTL_ID = C.ID 
                                    AND C.STEP = @P_SIMUL_STEP
                                    AND A.MAIN_VER_ID = @P_MAIN_VER_ID
                                ) A
                            WHERE A.ROW_SEQ <= @V_NUM_CNT
                            )
    ORDER BY G.CREATE_DTTM DESC;
END
go

