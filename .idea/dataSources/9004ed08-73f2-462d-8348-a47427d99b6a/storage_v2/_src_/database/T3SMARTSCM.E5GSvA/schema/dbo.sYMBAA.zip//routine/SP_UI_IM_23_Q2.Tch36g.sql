
CREATE PROCEDURE [dbo].[SP_UI_IM_23_Q2] (
	 @P_TYPE					NVARCHAR(10)  = '', 
	 @P_MAIN_VER_ID				NVARCHAR(100) = '',
	 @P_LOCAT_TP				NVARCHAR(100) = '',
	 @P_LOCAT_LV				NVARCHAR(100) = '',
	 @P_LOCAT_CD				NVARCHAR(100) = '',
	 @P_VAL_01					NVARCHAR(100) = '',
	 @P_VAL_02					NVARCHAR(100) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN
	
	/* 총 비용 분석 */
	IF @P_TYPE = 'COST'
		BEGIN
			SELECT
                     B.SIMUL_VER_ID
					,DBO.SUBSTRING_SPLIT_INDEX(B.SIMUL_VER_ID, '-', 4) AS SIMUL_VER_SEQ
                    ,SUM(SCM.KEEPING_COST)  AS KEEPING_COST
                    ,SUM(SCM.ORDER_COST)    AS ORDER_COST
                    ,SUM(SCM.TRANSP_COST)   AS TRANSP_COST
                    ,SUM(SCM.TOTAL_COST)    AS TOTAL_COST
                FROM
                    TB_RT_OPT_SCNRI_COMBT_MAIN SCM
                    INNER JOIN
                    TB_CM_SITE_ITEM SIT
                    ON (SCM.LOCAT_ITEM_ID = SIT.ID)
                    INNER JOIN
                    (
                        SELECT
                             A.COMN_CD_NM       AS LOCAT_TP_NM
                            ,B.LOCAT_LV
                            ,C.LOCAT_CD
                            ,C.LOCAT_NM
                            ,D.ID               AS LOCAT_MGMT_ID
                            ,D.ACTV_YN
                            ,A.SEQ
                            ,E.COMN_CD          AS PLAN_RES_TP
                        FROM
                            TB_AD_COMN_CODE A
                            INNER JOIN
                            TB_CM_LOC_MST B
                            ON (A.ID = B.LOCAT_TP_ID)
                            INNER JOIN
                            TB_CM_LOC_DTL C
                            ON (B.ID = C.LOCAT_MST_ID)
                            INNER JOIN
                            TB_CM_LOC_MGMT D
                            ON (C.ID = D.LOCAT_ID)
                            LEFT OUTER JOIN
                            TB_AD_COMN_CODE E
                            ON (D.PLAN_RES_TP_ID = E.ID)
                        WHERE
                            1=1
                            AND B.ACTV_YN = 'Y'
                            AND C.ACTV_YN = 'Y'
                            AND D.ACTV_YN = 'Y'
                    ) E
                    ON SIT.LOCAT_MGMT_ID = E.LOCAT_MGMT_ID
                    INNER JOIN
                    TB_CM_CONBD_MAIN_VER_DTL B
                    ON (SCM.CONBD_MAIN_VER_DTL_ID = B.ID)
                    INNER JOIN
                    TB_CM_CONBD_MAIN_VER_MST A
                    ON (B.CONBD_MAIN_VER_MST_ID = A.ID)
                    INNER JOIN
                    TB_RT_SITE_ITEM_SEG_SUMM ISS
                    ON (ISS.CONBD_MAIN_VER_DTL_ID = B.ID
					AND ISS.LOCAT_ITEM_ID = SIT.ID)
                 WHERE
                    1=1
                    AND UPPER(ISNULL(A.MAIN_VER_ID,'')) LIKE '%' + @P_MAIN_VER_ID + '%'
                    AND UPPER(E.LOCAT_TP_NM) LIKE '%'+ UPPER(@P_LOCAT_TP) + '%'
                    AND E.LOCAT_LV LIKE '%' + @P_LOCAT_LV + '%'
                    AND UPPER(E.LOCAT_CD) LIKE '%' + UPPER(@P_LOCAT_CD) + '%'
					AND UPPER(ISS.VAL_01) LIKE '%' + UPPER(@P_VAL_01) + '%'
					AND UPPER(ISS.VAL_02) LIKE '%' + UPPER(@P_VAL_02) + '%'
                GROUP BY B.SIMUL_VER_ID;

		END

	/* Fill Rate(%) */
	IF @P_TYPE = 'FILL_RATE'
		BEGIN
			SELECT
                     B.SIMUL_VER_ID
					,DBO.SUBSTRING_SPLIT_INDEX(B.SIMUL_VER_ID, '-', 4) AS SIMUL_VER_SEQ
                    ,AVG(SCM.FILL_RATE) AS FILL_RATE
                FROM
                    TB_RT_OPT_SCNRI_COMBT_MAIN SCM
                    INNER JOIN
                    TB_CM_SITE_ITEM SIT
                    ON (SCM.LOCAT_ITEM_ID = SIT.ID)
                    INNER JOIN
                    (
                        SELECT
                             A.COMN_CD_NM   AS LOCAT_TP_NM
                            ,B.LOCAT_LV
                            ,C.LOCAT_CD
                            ,C.LOCAT_NM
                            ,D.ID           AS LOCAT_MGMT_ID
                            ,D.ACTV_YN
                            ,A.SEQ
                            ,E.COMN_CD      AS PLAN_RES_TP
                        FROM
                            TB_AD_COMN_CODE A
                            INNER JOIN
                            TB_CM_LOC_MST B
                            ON (A.ID = B.LOCAT_TP_ID)
                            INNER JOIN
                            TB_CM_LOC_DTL C
                            ON (B.ID = C.LOCAT_MST_ID)
                            INNER JOIN
                            TB_CM_LOC_MGMT D
                            ON (C.ID = D.LOCAT_ID)
                             LEFT OUTER JOIN
                             TB_AD_COMN_CODE E
                            ON (D.PLAN_RES_TP_ID = E.ID)
                        WHERE 1=1
                            AND B.ACTV_YN = 'Y'
                            AND C.ACTV_YN = 'Y'
                            AND D.ACTV_YN = 'Y'
                    ) E
                    ON SIT.LOCAT_MGMT_ID = E.LOCAT_MGMT_ID
                    INNER JOIN
                    TB_CM_CONBD_MAIN_VER_DTL B
                    ON (SCM.CONBD_MAIN_VER_DTL_ID = B.ID)
                    INNER JOIN
                    TB_CM_CONBD_MAIN_VER_MST A
                    ON (B.CONBD_MAIN_VER_MST_ID = A.ID)
                    INNER JOIN
                    TB_RT_SITE_ITEM_SEG_SUMM ISS
                    ON (ISS.CONBD_MAIN_VER_DTL_ID = B.ID
					AND ISS.LOCAT_ITEM_ID = SIT.ID)
                 WHERE
                    1=1
                    AND UPPER(ISNULL(A.MAIN_VER_ID,'')) LIKE '%' + @P_MAIN_VER_ID + '%'
                    AND UPPER(E.LOCAT_TP_NM) LIKE '%'+ UPPER(@P_LOCAT_TP) + '%'
                    AND E.LOCAT_LV LIKE '%' + @P_LOCAT_LV + '%'
                    AND UPPER(E.LOCAT_CD) LIKE '%' + UPPER(@P_LOCAT_CD) + '%'
					AND UPPER(ISS.VAL_01) LIKE '%' + UPPER(@P_VAL_01) + '%'
					AND UPPER(ISS.VAL_02) LIKE '%' + UPPER(@P_VAL_02) + '%'
                 GROUP BY B.SIMUL_VER_ID;
			
		END

	/* 평균재고량/평균재고금액*/
	IF @P_TYPE = 'AVG_STOCK'
		BEGIN
			SELECT
                     B.SIMUL_VER_ID
					,DBO.SUBSTRING_SPLIT_INDEX(B.SIMUL_VER_ID, '-', 4) AS SIMUL_VER_SEQ
                    ,AVG(SCM.AVG_INV_QTY)   AS AVG_INV_QTY
                    ,AVG(SCM.AVG_INV_AMT)   AS AVG_INV_AMT
                FROM
                    TB_RT_OPT_SCNRI_COMBT_MAIN SCM
                    INNER JOIN
                    TB_CM_SITE_ITEM SIT
                    ON (SCM.LOCAT_ITEM_ID = SIT.ID)
                    INNER JOIN
                    (
                        SELECT
                             A.COMN_CD_NM   AS LOCAT_TP_NM
                            ,B.LOCAT_LV
                            ,C.LOCAT_CD
                            ,C.LOCAT_NM
                            ,D.ID           AS LOCAT_MGMT_ID
                            ,D.ACTV_YN
                            ,A.SEQ
                            ,E.COMN_CD      AS PLAN_RES_TP
                        FROM
                            TB_AD_COMN_CODE A
                            INNER JOIN
                            TB_CM_LOC_MST B
                            ON (A.ID = B.LOCAT_TP_ID)
                            INNER JOIN
                            TB_CM_LOC_DTL C
                            ON (B.ID = C.LOCAT_MST_ID)
                            INNER JOIN
                            TB_CM_LOC_MGMT D
                            ON (C.ID = D.LOCAT_ID)
                            LEFT OUTER JOIN
                            TB_AD_COMN_CODE E
                            ON (D.PLAN_RES_TP_ID = E.ID)
                        WHERE
                            1=1
                            AND B.ACTV_YN = 'Y'
                            AND C.ACTV_YN = 'Y'
                            AND D.ACTV_YN = 'Y'
                    ) E
                    ON SIT.LOCAT_MGMT_ID = E.LOCAT_MGMT_ID
                    INNER JOIN
                    TB_CM_CONBD_MAIN_VER_DTL B
                    ON (SCM.CONBD_MAIN_VER_DTL_ID = B.ID)
                    INNER JOIN
                    TB_CM_CONBD_MAIN_VER_MST A
                    ON (B.CONBD_MAIN_VER_MST_ID = A.ID)
                    INNER JOIN
                    TB_RT_SITE_ITEM_SEG_SUMM ISS
                    ON (ISS.CONBD_MAIN_VER_DTL_ID = B.ID
					AND ISS.LOCAT_ITEM_ID = SIT.ID)
             WHERE
                1=1
                AND UPPER(ISNULL(A.MAIN_VER_ID,'')) LIKE '%' + @P_MAIN_VER_ID + '%'
                AND UPPER(E.LOCAT_TP_NM) LIKE '%'+ UPPER(@P_LOCAT_TP) + '%'
                AND E.LOCAT_LV LIKE '%' + @P_LOCAT_LV + '%'
                AND UPPER(E.LOCAT_CD) LIKE '%' + UPPER(@P_LOCAT_CD) + '%'
				AND UPPER(ISS.VAL_01) LIKE '%' + UPPER(@P_VAL_01) + '%'
				AND UPPER(ISS.VAL_02) LIKE '%' + UPPER(@P_VAL_02) + '%'
             GROUP BY B.SIMUL_VER_ID;
		END

	/* 예상수준 */
	IF @P_TYPE = 'PREDICT_LV'
		BEGIN
			SELECT
                     B.SIMUL_VER_ID
					,DBO.SUBSTRING_SPLIT_INDEX(B.SIMUL_VER_ID, '-', 4) AS SIMUL_VER_SEQ
                    ,AVG(SCM.PDT_LV)    AS PREDICT_LV
                FROM
                    TB_RT_OPT_SCNRI_COMBT_MAIN SCM
                    INNER JOIN
                    TB_CM_SITE_ITEM SIT
                    ON (SCM.LOCAT_ITEM_ID = SIT.ID)
                    INNER JOIN
                    (
                        SELECT
                             A.COMN_CD_NM   AS LOCAT_TP_NM
                            ,B.LOCAT_LV
                            ,C.LOCAT_CD
                            ,C.LOCAT_NM
                            ,D.ID           AS LOCAT_MGMT_ID
                            ,D.ACTV_YN
                            ,A.SEQ
                            ,E.COMN_CD      AS PLAN_RES_TP
                        FROM
                            TB_AD_COMN_CODE A
                            INNER JOIN
                            TB_CM_LOC_MST B
                            ON (A.ID = B.LOCAT_TP_ID)
                            INNER JOIN
                            TB_CM_LOC_DTL C
                            ON (B.ID = C.LOCAT_MST_ID)
                            INNER JOIN
                            TB_CM_LOC_MGMT D
                            ON (C.ID = D.LOCAT_ID)
                            LEFT OUTER JOIN
                            TB_AD_COMN_CODE E
                            ON (D.PLAN_RES_TP_ID = E.ID)
                        WHERE
                            1=1
                            AND B.ACTV_YN = 'Y'
                            AND C.ACTV_YN = 'Y'
                            AND D.ACTV_YN = 'Y'
                    ) E
                    ON SIT.LOCAT_MGMT_ID = E.LOCAT_MGMT_ID
                    INNER JOIN
                    TB_CM_CONBD_MAIN_VER_DTL B
                    ON (SCM.CONBD_MAIN_VER_DTL_ID = B.ID)
                    INNER JOIN
                    TB_CM_CONBD_MAIN_VER_MST A
                    ON (B.CONBD_MAIN_VER_MST_ID = A.ID)
                    INNER JOIN
                    TB_RT_SITE_ITEM_SEG_SUMM ISS
                    ON (ISS.CONBD_MAIN_VER_DTL_ID = B.ID
					AND ISS.LOCAT_ITEM_ID = SIT.ID)
             WHERE
                1=1
                AND UPPER(ISNULL(A.MAIN_VER_ID,'')) LIKE '%' + @P_MAIN_VER_ID + '%'
                AND UPPER(E.LOCAT_TP_NM) LIKE '%'+ UPPER(@P_LOCAT_TP) + '%'
                AND E.LOCAT_LV LIKE '%' + @P_LOCAT_LV + '%'
                AND UPPER(E.LOCAT_CD) LIKE '%' + UPPER(@P_LOCAT_CD) + '%'
				AND UPPER(ISS.VAL_01) LIKE '%' + UPPER(@P_VAL_01) + '%'
				AND UPPER(ISS.VAL_02) LIKE '%' + UPPER(@P_VAL_02) + '%'
             GROUP BY B.SIMUL_VER_ID;
		END

END

go

