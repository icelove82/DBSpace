/*****************************************************************************
Title : SP_DP_15_S1
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP User Mapping(Item&Account)
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2019.06.03 / 김소희 / 코드 정리 및 Multi Popup 저장기능과 공통화 
- 2020.03.12 / KSH / EMP_NO => USER_ID 
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER
- 2020.11.10 / Kim sohee / data type of ITEM_CD NVARCHAR(100)
- 2020.12.02 / 김소희 / Make Initial Data into Entry
- 2020.12.07 / kim sohee / execute making dynamic user data procedure 
- 2021.03.10 / kim sohee / call a procedure to create User Group
- 2023.01.19 / kim sohee / item & account & user key validation
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_15_S1]  (
									   @p_ID                  CHAR(32)			= ''      
									  ,@p_EMP_NO			  NVARCHAR(25)		= ''      
									  ,@p_AUTH_TP_ID          CHAR(32)			= ''      
                                      ,@p_ACCOUNT_ID          CHAR(32)			= ''         
                                      ,@p_ACCOUNT_CD          NVARCHAR(100)		= ''         
                                      ,@p_ITEM_MST_ID         CHAR(32)			= ''         
                                      ,@p_ITEM_CD			  NVARCHAR(100)		= ''     
									  ,@p_USER_ID             NVARCHAR(50)      = ''  
									  ,@p_ACTV_YN           CHAR(1)         = '' 
									  ,@P_RT_ROLLBACK_FLAG    NVARCHAR(10)		= 'true'	 OUTPUT
									  ,@P_RT_MSG              NVARCHAR(4000)	= ''		 OUTPUT
									  --,@P_OUTPUT_MSG          NVARCHAR(4000) OUTPUT    
				                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE   @P_ERR_TYPE                 NVARCHAR(32)      = NULL    
		, @P_EMP_ID                   NVARCHAR(32)      = NULL 

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''

  
BEGIN TRY

-- EMPLOYEE 가 선택되지 않은 경우
IF (@P_EMP_NO IS NULL OR @P_EMP_NO = '')
	BEGIN
	   SET @P_ERR_MSG = 'MSG_0014' 
	   RAISERROR (@P_ERR_MSG,12, 1);	
	END
IF(@p_ACCOUNT_ID IS NULL)
BEGIN
	SELECT @P_ACCOUNT_ID = ID FROM TB_DP_ACCOUNT_MST WHERE ACCOUNT_CD = @p_ACCOUNT_CD
END
IF(@P_ITEM_MST_ID IS NULL)
BEGIN
	SELECT @P_ITEM_MST_ID = ID FROM TB_cM_ITEM_MST WHERE ITEM_CD = @p_ITEM_CD
END
IF(@p_ACTV_YN IS NULL)
BEGIN
	SET @p_ACTV_YN = 'Y'
END

-- Account 체크
IF (@P_ACCOUNT_ID IS NULL OR @P_ACCOUNT_ID = '')
	BEGIN
		   SET @P_ERR_MSG = 'MSG_0015' 
		   RAISERROR (@P_ERR_MSG,12, 1);	
	END
-- item 체크
IF (@P_ITEM_MST_ID IS NULL OR @P_ITEM_MST_ID = '')
	BEGIN
		   SET @P_ERR_MSG = 'MSG_0017' 
		   RAISERROR (@P_ERR_MSG,12, 1);	
	END

-- Account + Item 의 1개의 값은 1명의 User만 담당할 수 있다. 중복된 데이터가 있는 경우 msg
IF EXISTS(SELECT 1 
		    FROM TB_DP_USER_ITEM_ACCOUNT_MAP UI 
		   WHERE UI.ACCOUNT_ID = @P_ACCOUNT_ID 
		     AND UI.ITEM_MST_ID = @P_ITEM_MST_ID 
			 AND UI.AUTH_TP_ID = @P_AUTH_TP_ID 
			 AND UI.EMP_ID = @P_EMP_ID 
			 AND ID != @P_ID) 
	BEGIN
		   SET @P_ERR_MSG = 'MSG_0013' 
		   RAISERROR (@P_ERR_MSG,12, 1);
	END


      -- 프로시저 시작 
		BEGIN 

                -- EMP_ID Setting 
 				SELECT @P_EMP_ID = ID 
				  FROM TB_AD_USER
				WHERE USERNAME = @P_EMP_NO
				;

				MERGE TB_DP_USER_ITEM_ACCOUNT_MAP  TGT   
				USING ( 
						SELECT  @P_ID               AS ID 
						       ,@P_AUTH_TP_ID       AS  AUTH_TP_ID
							   ,@P_ACCOUNT_ID		AS  ACCOUNT_ID
							   ,@P_ITEM_MST_ID		AS  ITEM_MST_ID
							   ,@P_EMP_ID			AS  EMP_ID
							   ,@P_USER_ID			AS  USER_ID
							   ,@p_ACTV_YN			AS  ACTV_YN
					  ) SRC
				ON      TGT.ID = SRC.ID
				WHEN MATCHED THEN
					 UPDATE 
					   SET   TGT.MODIFY_BY   = SRC.USER_ID
					        ,TGT.ACCOUNT_ID  = SRC.ACCOUNT_ID
							,TGT.ITEM_MST_ID = SRC.ITEM_MST_ID 
							,TGT.ACTV_YN     = SRC.ACTV_YN 
							,TGT.MODIFY_DTTM = GETDATE()       
				WHEN NOT MATCHED THEN 
					 INSERT (
					            ID 
							  , AUTH_TP_ID
							  , ACCOUNT_ID
							  , ITEM_MST_ID
							  , EMP_ID
							  , ACTV_YN
							  , CREATE_BY
							  , CREATE_DTTM
							) 
					 VALUES (
					            REPLACE(NEWID(),'-','')
							  , SRC.AUTH_TP_ID
							  , SRC.ACCOUNT_ID
							  , SRC.ITEM_MST_ID
							  , SRC.EMP_ID
							  , SRC.ACTV_YN
							  , SRC.USER_ID 
							  , GETDATE()            
 							) 
							;    	

	   END 


	  /****************************************************************************************************************************
		-- Add new Demand into Entry 
	  ***************************************************************************************************************************/	   
	/************************************************************************************************************************************
		1. close 되지 않은 버전 이면서 TB_DP_ENTRY에 data가 존재하는 버전 : 엔진을 사용한다면 entry에 데이타가 없으므로

		2. TB_DP_ENTRY 에 이미 해당 item-account가 있는 경우 무시 
		     - 삭제되었다가 다시 추가되는 상황인 경우 이럴 수 있음
		3. Plan type별로 version이 있을수 있음 : 여러개일 가능성 있음 
				SELECT  CONBD_VER_MST_ID as VER_ID, max(create_dttm) OVER (PARTITION BY PLAN_TP_ID ORDER BY create_dttm DESC)  
				FROM TB_DP_CONTROL_BOARD_VER_DTL 
				WHERE WORK_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_WK_TP' AND CONF_CD = 'CL')
						AND CL_STATUS_ID IN (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD != 'CLOSE')

		4. plan type 별로 해당 version의 auth type을 구함
				select  LV_MGMT_ID from TB_DP_CONTROL_BOARD_VER_DTL where CONBD_VER_MST_ID  = 'F4F716D3FBDD4252BDDC28B9575BD690' and LV_MGMT_ID is not null
		5. 각 auth type별로 초기값 반영은 2차로 진행해도 될듯... 일단 value가 0인 상태로 demand만 추가 되도록 필요
	************************************************************************************************************************************/
	/********************************************************************************************************************************************
		-- Make Entry data
	********************************************************************************************************************************************/
		 

	DECLARE @TB_VERSION TABLE ( ID CHAR(32)) 
	DECLARE @CUR_VER_ID NVARCHAR(100)
	INSERT INTO @TB_VERSION (ID) 
	SELECT VER_ID
	  FROM ( 
			SELECT M.ID AS VER_ID 
				 , DENSE_RANK () OVER (PARTITION BY M.PLAN_TP_ID ORDER BY M.CREATE_DTTM DESC) AS RW 
			  FROM TB_DP_CONTROL_BOARD_VER_MST M
				   INNER JOIN 
				   TB_DP_CONTROL_bOARD_VER_DTL D
				ON M.ID = D.CONBD_VER_MST_ID 
				   INNER JOIN 
				   TB_CM_COMM_CONFIG W
				ON W.ID = D.WORK_TP_ID
			   AND W.CONF_CD = 'CL'
				   INNER JOIN 
				   TB_CM_COMM_CONFIG C
				ON D.CL_STATUS_ID = C.ID
			   AND C.CONF_CD != 'CLOSE' 
			 WHERE EXISTS (SELECT DISTINCT VER_ID FROM TB_DP_ENTRY WHERE VER_ID = M.ID) 
		    ) A
	WHERE RW = 1  
	DECLARE ITEM_ACCT_CUR CURSOR FAST_FORWARD LOCAL
	FOR SELECT ID FROM @TB_VERSION
	READONLY
	;

	OPEN ITEM_ACCT_CUR
    FETCH NEXT FROM ITEM_ACCT_CUR INTO @CUR_VER_ID 
	;
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			 IF NOT EXISTS
			 (  SELECT 1 
				 FROM TB_DP_ENTRY 
				WHERE VER_ID = @CUR_VER_ID
				  AND ITEM_MST_ID = @P_ITEM_MST_ID
				  AND ACCOUNT_ID = @P_ACCOUNT_ID
			 )
			 BEGIN
			   EXECUTE dbo.SP_UI_DP_93_ITEM_ACCT_CREATE 
						 @P_ITEM_MST_ID		= @P_ITEM_MST_ID   		-- Item Account User Map / Item Master 
						,@P_ITEM_LV_ID		= NULL		
						,@P_ACCOUNT_ID		= @P_ACCOUNT_ID			-- Item Account User Map / Account Master 
						,@P_ACCT_LV_ID		= NULL    	
						,@P_USER_ID			= @P_USER_ID			-- Mapping data
						,@P_AUTH_TP_ID		= @P_AUTH_TP_ID		
						,@P_VER_ID			= @CUR_VER_ID 	
						;   
			END
			  FETCH NEXT FROM ITEM_ACCT_CUR INTO @CUR_VER_ID
		END 
	   ;

		CLOSE ITEM_ACCT_CUR
		DEALLOCATE ITEM_ACCT_CUR 
		;

		EXEC SP_UI_DP_00_MAKE_USER_GROUP @P_USER_ID = @p_EMP_ID, @P_USER_NAME = @P_EMP_NO, @P_AUTH_TP_ID = @P_AUTH_TP_ID ;
		EXEC SP_UI_DPD_MAKE_HIER_USER;	

	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN			   
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR
END CATCH;

go

