
CREATE PROCEDURE [dbo].[SP_UI_DP_MAKE_HISTORY](
			@P_VER_ID			NVARCHAR(100)  = NULL
		   ,@P_AUTH_TP_ID		CHAR(32)	   = NULL
)

AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
/******************************************************************************************
	-- Make Entry History
	-- for report
	-- History ( date / writer / comment)
	-- 2019.11.08 / draft
	-- 2020.03.20 / Make Annual DP (소수 반올림 처리함)
******************************************************************************************/
DECLARE  @V_VER_ID			 CHAR(32)	   = NULL
	   , @P_MM_BUKT			 NVARCHAR(2)
	   , @P_STRT_DATE		 DATE 
	   , @P_END_DATE		 DATE 
	   , @P_PLAN_TP_ATTR	 CHAR(1)
	   ;

SET @V_VER_ID		= @P_VER_ID	
SET @P_AUTH_TP_ID = @P_AUTH_TP_ID

BEGIN
	SELECT TOP 1 @P_STRT_DATE	 = FROM_DATE
				,@P_END_DATE	 = TO_DATE
				,@P_PLAN_TP_ATTR = C.ATTR_01
				,@V_VER_ID = V.ID
	 FROM TB_DP_CONTROL_BOARD_VER_MST V
		  INNER JOIN
		  TB_CM_COMM_CONFIG C
	   ON C.ID = V.PLAN_TP_ID
	WHERE VER_ID = @P_VER_ID
	;
/***********************************************************************************************************************************
	-- make Entry History
************************************************************************************************************************************/
	merge TB_DP_ENTRY_HISTORY as tar
	using (select e.PLAN_TP_ID
				, ITEM_MST_ID
				, ACCOUNT_ID
				, BASE_DATE 
				, EMP_ID
				, QTY
				, AMT 
	       from TB_DP_ENTRY e
		  where auth_tp_id = @P_AUTH_TP_ID
		    and ver_id = @V_VER_ID
		   ) as src
	   on src.PLAN_TP_ID  = tar.PLAN_TP_ID 
	  and src.ITEM_MST_ID = tar.ITEM_MST_ID 
	  and src.ACCOUNT_ID  = tar.ACCOUNT_ID 
	  and src.BASE_DATE   = tar.BASE_DATE
	WHEN MATCHED THEN 
		UPDATE SET QTY = src.QTY
				 , AMT = src.AMT
				 , MODIFY_DTTM = getDate()
	WHEN NOT MATCHED THEN  
			INSERT (Id
				  , PLAN_TP_ID
				  , ITEM_MST_ID
				  , ACCOUNT_ID
				  , BASE_DATE
				  , EMP_ID
				  , QTY
				  , AMT
				  , CREATE_DTTM
				  )
			VALUES (REPLACE(NEWID(),'-','')
				  , src.PLAN_TP_ID
				  , src.ITEM_MST_ID
				  , src.ACCOUNT_ID
				  , src.BASE_DATE
				  , src.EMP_ID
				  , src.QTY
				  , src.AMT
				  , getDate()
				  );

/***********************************************************************************************************************************
	-- make Annual DP when attribute of plan type is "Y"
************************************************************************************************************************************/

	SELECT TOP 1 @P_MM_BUKT  = BUKT
	 FROM TB_DP_CONTROL_BOARD_VER_MST
	WHERE PLAN_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01 = 'M' AND ACTV_YN = 'Y')
	ORDER BY CREATE_DTTM DESC
	;	
IF(@P_PLAN_TP_ATTR = 'Y') 
	BEGIN
		WITH CA
		AS (
			SELECT MIN(DAT)				AS STRT_DATE
				 , MAX(DAT)				AS END_DATE
				 , MIN(YYYYMM)			AS YYYYMM
				 , COUNT(DAT)			AS DAT_CNT
				 , MIN(MM)				AS MM
			  FROM TB_CM_CALENDAR	
			 WHERE DAT BETWEEN @P_STRT_DATE AND @P_END_DATE 
		  GROUP BY YYYY
				 , CASE WHEN @P_MM_BUKT IN ('M', 'PW') THEN MM    ELSE 1 END
				 , CASE WHEN @P_MM_BUKT IN ('PW', 'W') THEN DP_WK ELSE 1 END 
		), YY
		AS (
			SELECT ITEM_MST_ID
				 , ACCOUNT_ID
				 , BASE_DATE		AS STRT_DATE
				 , ISNULL(DATEADD(DAY, -1, LEAD(BASE_DATE, 1) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID ORDER BY BASE_DATE ASC)), @P_END_DATE) AS END_DATE
				 , QTY
				 , AMT		
			  FROM TB_DP_ENTRY
			 WHERE VER_ID = @V_VER_ID
			   AND AUTH_TP_ID = @P_AUTH_TP_ID
		)	MERGE TB_DP_MEASURE_DATA SRC
			USING ( SELECT YY.ITEM_MST_ID
						  ,YY.ACCOUNT_ID
						  ,CA.STRT_DATE							AS BASE_DATE
						  ,ROUND(YY.QTY * CA.DAT_CNT  / SUM(CA.DAT_CNT) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID, MM),0)	AS QTY
						  ,ROUND(YY.AMT * CA.DAT_CNT  / SUM(CA.DAT_CNT) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID, MM),0)	AS AMT
					  FROM CA 
						   INNER JOIN
						   YY 	
						ON CA.STRT_DATE BETWEEN YY.STRT_DATE AND YY.END_DATE	-- 연간 Bucket 단위가 월간 Bucket 단위보다 무조건 커야 함
				  ) TGT
			 ON SRC.ITEM_MST_ID = TGT.ITEM_MST_ID
			AND SRC.ACCOUNT_ID  = TGT.ACCOUNT_ID
			AND SRC.BASE_DATE   = TGT.BASE_DATE	
			WHEN MATCHED THEN 
			UPDATE 
			  SET ANNUAL_QTY =   TGT.QTY
				, ANNUAL_AMT = 	 TGT.AMT
			WHEN NOT MATCHED THEN
			INSERT 
			(  ITEM_MST_ID
			 , ACCOUNT_ID
			 , BASE_DATE
			 , ANNUAL_QTY
			 , ANNUAL_AMT
			 , CREATE_BY
			 , CREATE_DTTM
			) VALUES
			(  TGT.ITEM_MST_ID
			 , TGT.ACCOUNT_ID
			 , TGT.BASE_DATE
			 , TGT.QTY
			 , TGT.AMT
			 , 'System'
			 , GETDATE()
			)
			;
	END

END

go

