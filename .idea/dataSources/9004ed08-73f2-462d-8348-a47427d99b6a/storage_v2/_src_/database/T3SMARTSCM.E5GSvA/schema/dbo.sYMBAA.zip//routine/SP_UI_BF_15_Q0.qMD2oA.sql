CREATE PROCEDURE [dbo].[SP_UI_BF_15_Q0]

AS 
/********************************************************
	-- ML Defualt Value
	-- BUKT
	-- BUCKET
*********************************************************/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN
	WITH LV
	AS (
		SELECT LV_CD
			 , ACCOUNT_LV_YN
		  FROM TB_CM_LEVEL_MGMT
		 WHERE LEAF_YN = 'Y'
		   AND ACTV_YN ='Y'
		   AND ISNULL(DEL_YN,'N') = 'N'
		   AND SALES_LV_YN = 'N'
	), BUKT 
	AS (
		SELECT CONF_CD, PRIORT
		  FROM TB_CM_COMM_CONFIG
		 WHERE CONF_GRP_CD = 'BF_BUKT_TP'
		   AND ACTV_YN = 'Y'
		   AND USE_YN = 'Y'
	), DIST
	AS (
		SELECT CONF_CD
		  FROM TB_CM_COMM_CONFIG
		 WHERE CONF_GRP_CD = 'BF_DIST_RULE_VALUE'
		   AND ACTV_YN = 'Y'
		   AND USE_YN = 'Y'	
		   AND CONF_CD = 'NN'
	)
	SELECT A.LV_CD	AS SALES
		 , I.LV_CD	AS ITEM
		 , B.BUKT	AS BUKT
		 , 'TF'		AS ENGINE_TP_CD
		 , D.CONF_CD AS DIST_RULE_CD
	  FROM LV A
		   INNER JOIN
		   LV I
		ON A.ACCOUNT_LV_YN = 'Y'
	   AND ISNULL(I.ACCOUNT_LV_YN,'N') = 'N'
		   CROSS JOIN
		   (
			SELECT CONF_CD	AS BUKT
			  FROM BUKT
			 WHERE PRIORT = (SELECT MAX(PRIORT) 
							  FROM BUKT 
							 )
			) B
		   CROSS JOIN
		   DIST D

END

go

