/*****************************************************************************
Title : [SP_UI_DP_35_VALID_Q7_U_I_A_ITEM_CD] 
최초 작성자 : 이고은
최초 생성일 : 2017.08.30
 
설명 
 - DP VALIDATION (U_I_A_ITEM_CD)-- ALL/ USER
 
History (수정일자 / 수정자 / 수정내용)
-  2017.08.30 / 이고은 / 최초 작성
- 2019.04.25 / 김소희 / DEL_YN Null처리 
- 2020.03.12 / KSH / + USER_ID  
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER

*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_35_Q7_I_A_ITEM_CD] 
(	
	 @p_OPERATOR_ID		NVARCHAR(100) = ''
	,@p_AUTH_TP_ID		NVARCHAR(50) = ''
) 
AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

	SELECT	B.USERNAME as USER_ID, B.USERNAME as EMP_NO,B.DISPLAY_NAME as EMP_NM, A.AUTH_TP_ID, L.LV_NM AS AUTH_TP_NM, A.ITEM_MST_ID, C.ITEM_NM, CASE WHEN ISNULL(C.DEL_YN,'N') = 'Y' THEN 'MASTER DATA 삭제' ELSE '그외(I/F문제등)' END ERR_DESC
	FROM	TB_DP_USER_ITEM_ACCOUNT_MAP	A 
			INNER JOIN TB_AD_USER		B  ON A.EMP_ID = B.ID
			LEFT OUTER JOIN TB_CM_ITEM_MST C  ON A.ITEM_MST_ID = C.ID AND C.DP_PLAN_YN = 'Y'
            LEFT OUTER JOIN TB_CM_LEVEL_MGMT L
            ON A.AUTH_TP_ID = L.ID            
	WHERE	NOT EXISTS	(
						SELECT 'X'
						FROM TB_CM_ITEM_MST X 
						WHERE A.ITEM_MST_ID = X.ID
						AND ISNULL(X.DEL_YN,'N') = 'N' AND X.DP_PLAN_YN = 'Y'
						)
	AND A.ACTV_YN='Y'
	AND		A.AUTH_TP_ID	LIKE '%' + @p_AUTH_TP_ID + '%'
	AND		B.USERNAME		LIKE '%' + @p_OPERATOR_ID	 + '%'
END








go

