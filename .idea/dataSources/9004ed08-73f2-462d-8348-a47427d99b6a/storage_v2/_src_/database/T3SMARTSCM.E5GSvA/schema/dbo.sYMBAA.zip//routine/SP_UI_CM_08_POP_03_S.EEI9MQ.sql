CREATE PROCEDURE [dbo].[SP_UI_CM_08_POP_03_S] (
     @P_WRK_TYPE				AS NVARCHAR(100) = ''
	,@P_ID						AS CHAR(32) = ''
	,@P_SHPP_LEADTIME_DTL_ID	AS NVARCHAR(100) =  ''
	,@P_STRT_DATE				AS DATETIME = ''
	,@P_END_DATE				AS DATETIME = ''
	,@P_TRANSFER_DD				AS CHAR(32) = ''
    ,@P_ACTV_YN                 AS CHAR(32) = ''
	,@P_USER_ID					AS NVARCHAR(100) = ''
    ,@P_RT_ROLLBACK_FLAG     	NVARCHAR(10) = 'true'  OUTPUT
	,@P_RT_MSG               	NVARCHAR(4000) = ''	   OUTPUT
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
		,@P_ERR_MSG NVARCHAR(4000) = ''
    
BEGIN TRY
	
    IF @P_WRK_TYPE = 'SAVE'
		BEGIN
			MERGE INTO TB_CM_SHIP_LT_EXCEPTION_SCH B 
			USING (SELECT @P_ID AS ID) A
	           ON (B.ID = A.ID)
			WHEN MATCHED THEN
				UPDATE 
				   SET STRT_DATE    = @P_STRT_DATE
					 , END_DATE     = @P_END_DATE
					 , TRANSFER_DD	= @P_TRANSFER_DD
	                 , ACTV_YN      = @P_ACTV_YN
				     , MODIFY_BY	= @P_USER_ID
					 , MODIFY_DTTM	= GETDATE()
			WHEN NOT MATCHED THEN
				INSERT (
					ID
					,SHPP_LEADTIME_DTL_ID
					,STRT_DATE
					,END_DATE
					,TRANSFER_DD			
					,ACTV_YN
	                ,CREATE_BY
	                ,CREATE_DTTM
					)
				VALUES 
			  	    (
					REPLACE(NEWID(),'-','')
					,@P_SHPP_LEADTIME_DTL_ID
					,@P_STRT_DATE	
					,@P_END_DATE	
					,@P_TRANSFER_DD
					,@P_ACTV_YN
	                ,@P_USER_ID
	                ,GETDATE()
				);
				
	        SET @P_RT_MSG = 'MSG_0001'
		END 

	ELSE IF @P_WRK_TYPE = 'DELETE'
    	BEGIN
	        DELETE 
	          FROM TB_CM_SHIP_LT_EXCEPTION_SCH
	         WHERE ID = @P_ID
	        
			SET @P_RT_MSG = 'MSG_0002'
    	END 

	SET @P_RT_ROLLBACK_FLAG = 'true'

END TRY
BEGIN CATCH
	IF (ERROR_MESSAGE() LIKE 'MSG_%')
	    BEGIN
			SET @P_ERR_MSG = ERROR_MESSAGE()
			SET @P_RT_ROLLBACK_FLAG = 'false'
		    SET @P_RT_MSG = @P_ERR_MSG
		END
	ELSE
	    THROW
END CATCH

go

