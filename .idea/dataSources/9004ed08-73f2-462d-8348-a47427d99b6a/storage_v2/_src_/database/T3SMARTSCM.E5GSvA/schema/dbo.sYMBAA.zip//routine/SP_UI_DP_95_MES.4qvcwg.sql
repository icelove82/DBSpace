-- =============================================
-- Author:		eunha

-- History ( Date / writer / comment )
-- 2022.09.29 / kim sohee / remove join TB_AD_USER_GROUP because of admin permission 
-- =============================================
CREATE PROCEDURE [dbo].[SP_UI_DP_95_MES](
                 @USER_ID   NVARCHAR(50) = ''
                ,@AUTH_TP   NVARCHAR(50) = ''
                ,@UI_ID     NVARCHAR(30) = ''
				,@GRID_ID	NVARCHAR(30) = ''
)As
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
BEGIN
	SET @GRID_ID = REPLACE(@GRID_ID, @UI_ID+'-', '');

	SELECT	 				
	A.FLD_CD AS DISPLAY					
	, A.FLD_APPLY_CD AS MEASURE_CD    					
	,L.LV_CD AS LEVEL_CD					
	,C.CONF_CD AS VAL_TYPE					
	,C2.CONF_CD AS VER_APPLY
	,B.INPUT_YN AS INPUT_YN		
	,L.ID AS AUTH_TP_ID		
	,C.ATTR_01 AS DECIMAL_PLACES
	FROM	TB_AD_USER_PREF_DTL A 
	inner join TB_AD_USER_PREF_MST m on m.id = A.USER_PREF_MST_ID and m.VIEW_CD = @UI_ID and m.GRID_CD = @GRID_ID
	inner join TB_AD_GROUP g on g.ID = A.GRP_ID and GRP_CD = @AUTH_TP
	inner join TB_AD_USER u on u.USERNAME = @USER_ID
--	inner join TB_AD_USER_GROUP ug on ug.GRP_ID = a.GRP_ID and u.id = ug.USER_ID		
	INNER JOIN TB_DP_MEASURE_SETTING B ON A.REFER_VALUE = B.ID					
	INNER JOIN TB_CM_COMM_CONFIG C ON b.MEASURE_VAL_TP_ID = C.ID					
	LEFT OUTER JOIN TB_CM_COMM_CONFIG C2 ON b.VER_APPY_BASE_ID = C2.ID					
	LEFT OUTER JOIN TB_DP_MEASURE_MST T ON B.MEASURE_MST_ID = T.ID					
	LEFT OUTER JOIN TB_CM_LEVEL_MGMT L ON B.LV_MGMT_ID = L.ID 					 
	LEFT OUTER JOIN TB_AD_USER_PREF up 
				ON	m.id = up.USER_PREF_MST_ID AND A.GRP_ID = up.GRP_ID	AND	A.FLD_CD = up.FLD_CD	AND up.USER_ID = u.ID					
	WHERE	A.DIM_MEASURE_TP = 'MEASURE'			
	AND		ISNULL(up.FLD_ACTIVE_YN,ISNULL(A.FLD_ACTIVE_YN,'N')) = 'Y'		
      ;
END;

go

