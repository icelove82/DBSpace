/*****************************************************************************
Title : SP_UI_MP_05_S1
최초 작성자 : 조아람
최초 생성일 : 2017.08.02
 
설명 
 - Material Constraints 변경사항 저장
 
History (수정일자 / 수정자 / 수정내용)
- 2017.08.02 / 조아람 / 최초 작성
- 2018.04.23 / 김명식 / @P_UOM_ID 추가 작성-
 
*****************************************************************************/
CREATE PROCEDURE [dbo].[SP_UI_MP_05_S1] (
	 @P_WRK_TYPE						AS NVARCHAR(10)
	,@P_ID								AS NVARCHAR(32)	= null
	,@P_KEY_MAT_YN						AS CHAR(1)
	,@P_LGDY_MAT_YN						AS CHAR(1)
	,@P_MAT_CONST_TP					AS NVARCHAR(32)	= null
	,@P_CONST_TP_CHNG_PERIOD			AS NVARCHAR(100) = null
	,@P_UOM_ID							AS CHAR(32) = NULL
	,@P_ACTV_YN							AS CHAR(1)
	,@P_USER_ID							AS NVARCHAR(20)
	,@P_RT_ROLLBACK_FLAG				NVARCHAR(10)   = 'true'   OUTPUT
	,@P_RT_MSG							NVARCHAR(4000) = '	'	  OUTPUT
)
AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON;

IF @P_CONST_TP_CHNG_PERIOD = '' OR @P_CONST_TP_CHNG_PERIOD = ' '  SET @P_CONST_TP_CHNG_PERIOD = NULL

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''

BEGIN TRY
	IF @P_WRK_TYPE = 'SAVE'
	BEGIN
		UPDATE TB_CM_SITE_ITEM
		   SET KEY_MAT_YN = @P_KEY_MAT_YN
		     , LGDY_MAT_YN = @P_LGDY_MAT_YN
			 , MAT_CONST_TP_ID = @P_MAT_CONST_TP
			 , CONST_TP_CHNG_PERIOD = @P_CONST_TP_CHNG_PERIOD
			 , UOM_ID = @P_UOM_ID
			 , ACTV_YN = @P_ACTV_YN
			 , MODIFY_BY = @P_USER_ID
			 , MODIFY_DTTM = GETDATE()	
		 WHERE ID = @P_ID
	END

	SET @P_RT_ROLLBACK_FLAG = 'true'
	SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY

BEGIN CATCH
	IF(ERROR_MESSAGE() LIKE 'MSG_%')
		BEGIN
			SET @P_ERR_MSG = ERROR_MESSAGE()
			SET @P_RT_ROLLBACK_FLAG = 'false'
			SET @P_RT_MSG = @P_ERR_MSG
		END
	ELSE
		THROW
END CATCH

go

