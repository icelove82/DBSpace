/****************************************************************************************************************
		System Error Message
		2018.06.20
****************************************************************************************************************/
CREATE PROCEDURE [dbo].[SP_COMM_RAISE_ERR] 
AS
	DECLARE @P_ERR_MSG NVARCHAR(4000)
BEGIN
				SET @P_ERR_MSG = '[MESSAGE : '+ERROR_MESSAGE()+'  LINE : '+ CAST(ERROR_LINE() AS NVARCHAR(100))+']' -- 16
				RAISERROR(@P_ERR_MSG,16,1)		
END;

go

