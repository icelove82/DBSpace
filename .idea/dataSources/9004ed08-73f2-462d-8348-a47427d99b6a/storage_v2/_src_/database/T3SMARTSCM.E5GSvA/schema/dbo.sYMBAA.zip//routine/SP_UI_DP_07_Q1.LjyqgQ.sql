/*****************************************************************************
Title : SP_UI_DP_07_Q1
최초 작성자 : 민희영
최초 생성일 : 2017.06.13
 
설명 
 - Exchange Rate
 - 프로그램 시작을 기록하는 부분임
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.13 / 민희영 / 최초 작성
- 2018.12.27 / 김소희 / 가장 최신 값 가져올 수 있게 고침 
- 2021.01.20 / 김소희 / currency name 추가
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_07_Q1] (@p_GB                   NVARCHAR(50) = ''
									   ,@p_VER_ID               NVARCHAR(100) = ''
									   ,@p_FROM_DATE            DATETIME         = NULL
									   ,@p_TO_DATE              DATETIME         = NULL
                                       ,@P_FROM_CURCY_CD_ID     NVARCHAR(32) = '' 
									   ,@P_TO_CURCY_CD_ID       NVARCHAR(32) = '' 
									   ,@P_CURCY_TP_ID			NVARCHAR(32) = ''
									   ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE   @V_GB               	NVARCHAR(50) = ''
		, @V_VER_ID				NVARCHAR(100) = ''
		, @V_FROM_DATE        	DATETIME
		, @V_TO_DATE			DATETIME
		, @V_FROM_CURCY_CD_ID	NVARCHAR(32) = ''
		, @V_TO_CURCY_CD_ID   	NVARCHAR(32) = ''
		, @V_CURCY_TP_ID		NVARCHAR(32) = ''

SET @V_GB               = @p_GB               
SET @V_VER_ID			= @p_VER_ID           
SET @V_FROM_DATE        = @p_FROM_DATE        
SET @V_TO_DATE			= @p_TO_DATE          
SET @V_FROM_CURCY_CD_ID	= @P_FROM_CURCY_CD_ID 
SET @V_TO_CURCY_CD_ID   = @P_TO_CURCY_CD_ID   
SET @V_CURCY_TP_ID		= @P_CURCY_TP_ID		

BEGIN

		

      --,CONVERT(DATETIME, SA.STRT_DATE_AUTH,112)  AS STRT_DATE_AUTH
		IF (@V_GB = 'DATE'  )
		BEGIN 
   
			SELECT TOP 1 A.VER_ID, A.FROM_DATE, A.TO_DATE, A.SEQ
			FROM 
			     ( 
				    -- VERSION 없을때 Default 값 
					SELECT TOP 1 '' AS VER_ID 
						  , CONVERT(DATETIME,DATEADD(MM, DATEDIFF(M, 0, GETDATE()) , 0),112) AS FROM_DATE  --월초 
						  , CONVERT(DATETIME,DATEADD(DAY,-1,DATEADD(MM, DATEDIFF(M, 0, GETDATE())+1 , 0)),112)  AS TO_DATE       --월말  
						  , 0 AS SEQ 
					UNION ALL 
					SELECT  TOP 1  VER_ID 
						   , CONVERT(DATETIME, FROM_DATE,112)  AS FROM_DATE
						   , CONVERT(DATETIME, TO_DATE,112)  AS TO_DATE 
						   , 1 AS SEQ 
					FROM TB_DP_CONTROL_BOARD_VER_MST 
					
					ORDER BY VER_ID DESC 
			       ) A
            ORDER BY SEQ DESC



		END 
		ELSE 
		BEGIN 


				  /*
				  	DECLARE @V_FROM_DATE            DATETIME         = NULL
					       ,@V_TO_DATE              DATETIME         = NULL;


				  SELECT  @V_FROM_DATE = CONVERT(DATETIME,DATEADD(MM, DATEDIFF(M, 0, GETDATE()) , 0),112)
				     , @V_TO_DATE  = CONVERT(DATETIME,DATEADD(DAY,-1,DATEADD(MM, DATEDIFF(M, 0, GETDATE())+5 , 0)),112) 
					 ;
                  */

                SELECT ER.ID
					  ,ER.FROM_CURCY_CD_ID
					  ,CD.COMN_CD AS FROM_CURCY_CD
					  ,CD.COMN_CD_NM AS FROM_CURCY_NM
					  ,ER.TO_CURCY_CD_ID
					  ,ER.CURCY_TP_ID
					  ,CTP.CONF_CD AS CURCY_TP_CD 
--					  ,CTP.CONF_NM AS CURCY_TP_CD
					  ,CD2.COMN_CD AS TO_CURCY_CD
					  ,CD2.COMN_CD_NM AS TO_CURCY_NM
					  ,CONVERT(DATETIME, ER.BASE_DATE,112)  AS BASE_DATE
					  ,ER.EXCHANGE_RATE
					  ,ER.UNIT_UOM_VAL
--					  , '1' AS GUBUN  --Before range
					 , @V_FROM_DATE AS FROM_DATE 
					 , @V_TO_DATE AS TO_DATE
				  FROM TB_AD_COMN_GRP CM
					 , TB_AD_COMN_CODE CD 
					 , TB_AD_COMN_GRP CM2
					 , TB_AD_COMN_CODE CD2 
					 , TB_CM_COMM_CONFIG CTP
  				     , TB_DP_EXCHANGE_RATE ER 
				  WHERE  CM.ID = CD.SRC_ID 
				    AND  CM.GRP_CD = 'CURRENCY'  
				    AND  CD.ID = ER.FROM_CURCY_CD_ID
                    AND  CM2.ID = CD2.SRC_ID 
				    AND  CM2.GRP_CD = 'CURRENCY'  
				    AND  CD2.ID = ER.TO_CURCY_CD_ID
					AND CTP.ID = ER.CURCY_TP_ID
					AND @p_FROM_DATE > BASE_DATE
--					AND  ER.BASE_DATE BETWEEN @V_FROM_DATE AND @V_TO_DATE 
                    AND  EXISTS 
					    ( -- 조회 시작일을포함한 이전값중 가장 최근의 값 
						 SELECT ID 
						  FROM ( 
							  SELECT ID, ROW_NUMBER () OVER(PARTITION BY ER.FROM_CURCY_CD_ID, ER.TO_CURCY_CD_ID, ER.CURCY_TP_ID ORDER BY BASE_DATE DESC) ROW_NUM
								FROM TB_DP_EXCHANGE_RATE ER 
							  WHERE ER.BASE_DATE <=  @V_FROM_DATE         
								AND  ER.FROM_CURCY_CD_ID LIKE '%'+ LTRIM(RTRIM(@V_FROM_CURCY_CD_ID)) +'%'
								AND  ER.TO_CURCY_CD_ID LIKE '%'+ LTRIM(RTRIM(@V_TO_CURCY_CD_ID)) +'%'   
								AND  ER.CURCY_TP_ID LIKE '%'+ LTRIM(RTRIM(@V_CURCY_TP_ID)) +'%'
								) A
						 WHERE 1=1
						   AND ROW_NUM = 1 
						   AND ID = ER.ID 
						 ) 				 
			    UNION
				SELECT ER.ID
					  ,ER.FROM_CURCY_CD_ID
					  ,CD.COMN_CD AS FROM_CURCY_CD
					  ,CD.COMN_CD_NM AS FROM_CURCY_NM
					  ,ER.TO_CURCY_CD_ID
					  ,ER.CURCY_TP_ID
					  ,CTP.CONF_CD AS CURCY_TP_CD 
--					  ,CTP.CONF_NM AS CURCY_TP_CD
					  ,CD2.COMN_CD AS TO_CURCY_CD
					  ,CD2.COMN_CD_NM AS TO_CURCY_NM
					  ,CONVERT(DATETIME, ER.BASE_DATE,112)  AS BASE_DATE
					  ,ER.EXCHANGE_RATE
					  ,ER.UNIT_UOM_VAL
--					  , '2' AS GUBUN --In range
					 , @V_FROM_DATE AS FROM_DATE 
					 , @V_TO_DATE AS TO_DATE
				  FROM TB_AD_COMN_GRP CM
					 , TB_AD_COMN_CODE CD 
					 , TB_AD_COMN_GRP CM2
					 , TB_AD_COMN_CODE CD2 
					 , TB_CM_COMM_CONFIG CTP
  				     , TB_DP_EXCHANGE_RATE ER 
			WHERE  CM.ID = CD.SRC_ID 
				    AND  CM.GRP_CD = 'CURRENCY'  
				    AND  CD.ID = ER.FROM_CURCY_CD_ID
                    AND  CM2.ID = CD2.SRC_ID 
				    AND  CM2.GRP_CD = 'CURRENCY'  
				    AND  CD2.ID = ER.TO_CURCY_CD_ID
					AND CTP.ID = ER.CURCY_TP_ID
				    --AND  ER.BASE_DATE > @V_FROM_DATE 
				    --AND  ER.BASE_DATE <= @V_TO_DATE
					AND  ER.BASE_DATE BETWEEN @V_FROM_DATE AND @V_TO_DATE 
					AND ER.FROM_CURCY_CD_ID LIKE '%' + LTRIM(RTRIM(@V_FROM_CURCY_CD_ID))+'%'
					AND ER.TO_CURCY_CD_ID LIKE '%' + LTRIM(RTRIM(@V_TO_CURCY_CD_ID)) + '%'
					AND ER.CURCY_TP_ID LIKE '%' + LTRIM(RTRIM(@V_CURCY_TP_ID)) + '%'
					AND @V_FROM_DATE != @V_TO_DATE
		END 

END

go

