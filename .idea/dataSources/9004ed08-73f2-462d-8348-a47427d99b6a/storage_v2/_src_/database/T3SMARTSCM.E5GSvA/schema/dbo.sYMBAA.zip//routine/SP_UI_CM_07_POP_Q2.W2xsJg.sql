
CREATE PROCEDURE [dbo].[SP_UI_CM_07_POP_Q2] (
	 @P_JOB_TYPE					NVARCHAR(50) = '',
	 @P_BOD_TP_ID					CHAR(32) = '',
	 @P_CONSUME_LOC_MGMT_ID			CHAR(32) = '',
	 @P_ACCOUNT_ID					CHAR(32) = '',
	 @P_SUPPLY_LOC_MGMT_ID			CHAR(32) = ''
) 
AS SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @vBOD_TP	NVARCHAR(100)

    SELECT @vBOD_TP = COMN_CD
      FROM TB_AD_COMN_CODE 
     WHERE ID = @P_BOD_TP_ID

BEGIN

	IF @P_JOB_TYPE = 'N'
		BEGIN
			IF @vBOD_TP IS NOT NULL AND @vBOD_TP = 'SALES_BOD'
				BEGIN
                   SELECT 		   
                           NULL						    AS SHPP_LEADTIME_MST_ID
                         , @P_BOD_TP_ID                 AS BOD_TP_ID
                         , NULL                         AS CONSUME_LOCAT_MGMT_ID
                         , ACC.ID                       AS ACCOUNT_ID
                         , LMG.ID                       AS SUPPLY_LOCAT_MGMT_ID
                         , 'Y'					        AS ACTV_YN
                         , VHC.ID						AS VEHICL_TP_ID
                         , VHC.VEHICL_TP				AS VEHICL_TP
                         , BLT.ID						AS BOD_LEADTIME_ID
                         , BLT.BOD_LEADTIME_PERIOD		AS BOD_LEADTIME_PERIOD
                         , ACD.COMN_CD_NM				AS LEADTIME_TP
                         , BLT.BOD_LEADTIME_SEQ			AS BOD_LEADTIME_SEQ
                         , NULL		        			AS BOD_LEAD_TIME
                         , NULL                         AS UOM_ID
                      FROM TB_CM_BOD_LT BLT
                           LEFT OUTER JOIN TB_AD_COMN_CODE ACD  
                           ON ACD.ID = BLT.LEADTIME_TP_ID,
						   TB_DP_ACCOUNT_MST ACC,
						   (
						   SELECT	A.ID
						   FROM	    TB_CM_LOC_MST A
								    INNER JOIN TB_AD_COMN_CODE B
									ON B.ID = A.LOCAT_TP_ID
						   WHERE	B.COMN_CD = 'LOC_ACCOUNT'
						   ) CUS,
                           TB_CM_LOC_MST LMS,
                           TB_CM_LOC_DTL LDT,
                           TB_CM_LOC_MGMT LMG,
                           TB_CM_VEHICLE VHC  
                     WHERE CUS.ID = BLT.TO_LOCAT_MST_ID
					   AND LMS.ID = BLT.FROM_LOCAT_MST_ID
                       AND LMS.ID = LDT.LOCAT_MST_ID
                       AND LDT.ID = LMG.LOCAT_ID
                       AND VHC.ID = BLT.VEHICL_TP_ID
					   AND ACC.ID = @P_ACCOUNT_ID
                       AND LMG.ID = @P_SUPPLY_LOC_MGMT_ID
					   AND ISNULL(BLT.ACTV_YN, 'N') = 'Y'
                     ORDER BY VHC.VEHICL_TP, BLT.BOD_LEADTIME_SEQ
				END
			ELSE
				BEGIN
                   SELECT 		   
                           NULL						    AS SHPP_LEADTIME_MST_ID
                         , @P_BOD_TP_ID                 AS BOD_TP_ID
                         , LMG.ID                       AS CONSUME_LOCAT_MGMT_ID
                         , NULL                         AS ACCOUNT_ID
                         , LMG2.ID                      AS SUPPLY_LOCAT_MGMT_ID
                         , 'Y'					        AS ACTV_YN
                         , VHC.ID						AS VEHICL_TP_ID
                         , VHC.VEHICL_TP				AS VEHICL_TP
                         , BLT.ID						AS BOD_LEADTIME_ID
                         , BLT.BOD_LEADTIME_PERIOD		AS BOD_LEADTIME_PERIOD
                         , ACD.COMN_CD_NM				AS LEADTIME_TP
                         , BLT.BOD_LEADTIME_SEQ			AS BOD_LEADTIME_SEQ
                         , NULL		        			AS BOD_LEAD_TIME
                         , NULL                         AS UOM_ID
                      FROM TB_CM_BOD_LT BLT  
                           LEFT OUTER JOIN TB_AD_COMN_CODE ACD  
                           ON ACD.ID = BLT.LEADTIME_TP_ID,
                           TB_CM_LOC_MST LMS  ,
                           TB_CM_LOC_DTL LDT  ,
                           TB_CM_LOC_MGMT LMG  ,
                           TB_CM_LOC_MST LMS2  ,
                           TB_CM_LOC_DTL LDT2  ,
    TB_CM_LOC_MGMT LMG2  ,
                           TB_CM_VEHICLE VHC  
                     WHERE BLT.TO_LOCAT_MST_ID = LMS.ID 
                       AND LMS.ID = LDT.LOCAT_MST_ID
                       AND LDT.ID = LMG.LOCAT_ID
                       AND LMS2.ID = BLT.FROM_LOCAT_MST_ID
                       AND LMS2.ID = LDT2.LOCAT_MST_ID
                       AND LDT2.ID = LMG2.LOCAT_ID
                       AND VHC.ID = BLT.VEHICL_TP_ID
                       AND LMG.ID = @P_CONSUME_LOC_MGMT_ID
                       AND LMG2.ID = @P_SUPPLY_LOC_MGMT_ID
					   AND ISNULL(BLT.ACTV_YN, 'N') = 'Y'
                     ORDER BY VHC.VEHICL_TP, BLT.BOD_LEADTIME_SEQ
				END
		END

	IF @P_JOB_TYPE = 'U'
		BEGIN
			SELECT  
				   SLM.ID						AS SHPP_LEADTIME_MST_ID
                 , SLM.BOD_TP_ID                AS BOD_TP_ID
                 , SLM.CONSUME_LOCAT_ID         AS CONSUME_LOCAT_MGMT_ID
                 , SLM.ACCOUNT_ID               AS ACCOUNT_ID
                 , SLM.SUPPLY_LOCAT_ID          AS SUPPLY_LOCAT_MGMT_ID
				 , SLD.ACTV_YN					AS ACTV_YN
				 , VHC.ID						AS VEHICL_TP_ID
				 , VHC.VEHICL_TP				AS VEHICL_TP
				 , BLT.ID						AS BOD_LEADTIME_ID
				 , BLT.BOD_LEADTIME_PERIOD		AS BOD_LEADTIME_PERIOD
				 , ACD.COMN_CD_NM				AS LEADTIME_TP
				 , BLT.BOD_LEADTIME_SEQ			AS BOD_LEADTIME_SEQ
				 , SLD.LEADTIME					AS BOD_LEAD_TIME
                 , SLD.UOM_ID                   AS UOM_ID
			 FROM TB_CM_SHIP_LT_MST SLM  ,
				  TB_CM_SHIP_LT_DTL SLD  ,
                  TB_CM_BOD_LT BLT  
				  LEFT OUTER JOIN TB_AD_COMN_CODE ACD  
				  ON BLT.LEADTIME_TP_ID = ACD.ID,
                  TB_CM_VEHICLE VHC  
			 WHERE 1=1
			   AND SLM.ID = SLD.SHPP_LEADTIME_MST_ID
			   AND  SLD.BOD_LEADTIME_ID = BLT.ID
			   AND VHC.ID = BLT.VEHICL_TP_ID
			   AND (SLM.CONSUME_LOCAT_ID = @P_CONSUME_LOC_MGMT_ID
                 OR SLM.ACCOUNT_ID = @P_ACCOUNT_ID)
			   AND SLM.SUPPLY_LOCAT_ID = @P_SUPPLY_LOC_MGMT_ID
		     ORDER BY VHC.VEHICL_TP, BLT.BOD_LEADTIME_SEQ
		END
		   
END

go

