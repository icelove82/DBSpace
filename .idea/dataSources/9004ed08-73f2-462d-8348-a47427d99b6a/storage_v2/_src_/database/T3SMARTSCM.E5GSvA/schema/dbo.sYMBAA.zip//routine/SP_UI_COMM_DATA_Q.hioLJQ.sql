CREATE PROCEDURE [dbo].[SP_UI_COMM_DATA_Q] (
	 @P_DATA_DIV nvarchar(50)
	,@P_PARAM1   nvarchar(100) = null
	,@P_PARAM2   nvarchar(100) = null
	,@P_PARAM3   nvarchar(100) = null
)
/*****************************************************************************
Author      : <ZIONEX>
ALTER date  : <2016-09-01 10:25:00>
Description : 공통 데이터를 조회한다.
*****************************************************************************/
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN
	
	IF @P_DATA_DIV = 'UOM'
	    BEGIN
			SELECT B.UOM_CD		AS CD
				 , B.UOM_NM		AS CD_NM
				 , B.ID			AS UOM_ID
			  FROM TB_CM_CONFIGURATION A
				 , TB_CM_UOM B
			 WHERE A.ID = B.CONF_ID
	    END
	
	ELSE IF @P_DATA_DIV = 'CUST'
	    BEGIN
			SELECT B.CONF_CD		AS CD
				 , B.CONF_NM		AS CD_NM
			  FROM TB_CM_CORPORATION A
				 , TB_CM_COMM_CONFIG B
			 WHERE A.ID = B.CONF_ID
	    END
	
	ELSE IF @P_DATA_DIV = 'TEST_DATA'
	    BEGIN
			SELECT 'TEST_KEY'		AS CD
				 , 'TEST_VALUE'		AS CD_NM
	    END
	
	ELSE IF @P_DATA_DIV = 'LOC_TP'
		BEGIN
			SELECT A.LOCAT_LV
				 , B.COMN_CD AS LOC_TP
				 , A.LOC_MST_ID
			  FROM	(
					SELECT B.LOCAT_TP_ID
						 , B.LOCAT_LV
						 , B.ID	AS LOC_MST_ID
					  FROM TB_CM_CONFIGURATION A
						 , TB_CM_LOC_MST  B
					 WHERE A.ID = B.CONF_ID
					) A
					LEFT OUTER JOIN TB_AD_COMN_CODE B
					ON A.LOCAT_TP_ID = B.ID
		END
	
	ELSE IF @P_DATA_DIV = 'LOC_CD'
		BEGIN
			SELECT A.LOCAT_CD	AS LOC_CD
				 , A.LOCAT_NM	AS LOC_NM
			  FROM TB_CM_LOC_DTL A
			 WHERE A.LOCAT_MST_ID = @P_PARAM1
		END
	
	ELSE IF @P_DATA_DIV = 'REGION'
		BEGIN
	        SELECT Y.CONF_NM AS CD_NM
	        	  ,Y.CONF_CD AS CD
	          FROM TB_CM_CONFIGURATION X  
				  ,TB_CM_COMM_CONFIG Y  
	         WHERE X.ID = Y.CONF_ID
	           AND Y.CONF_GRP_CD='CM_REGION'
			   AND Y.ACTV_YN = 'Y'	
		END
	
	ELSE IF @P_DATA_DIV = 'COUNTRY'
		BEGIN	    
			SELECT B.CONF_CD		AS CODE  
			  	  ,B.CONF_NM		AS CODE_TEXT
			  FROM TB_CM_CONFIGURATION A   
			       INNER JOIN TB_CM_COMM_CONFIG B   
			       ON A.ID = B.CONF_ID
			 WHERE B.CONF_GRP_CD = 'CM_COUNTRY'
			   AND B.ACTV_YN ='Y'
			   AND B.USE_YN ='Y' 
			 ORDER BY B.CONF_CD
		END
	
	ELSE IF @P_DATA_DIV = 'PLN_RES_TP'
		BEGIN
			SELECT Y.COMN_CD_NM AS CD_NM
				 , Y.COMN_CD AS CD
	          FROM TB_AD_COMN_GRP X 
	             , TB_AD_COMN_CODE Y 
	         WHERE 1=1
	           AND X.GRP_CD = 'PLN_RES_TP'
	           AND X.ID = Y.SRC_ID
	           AND Y.USE_YN ='Y'   
		END			
	
	ELSE IF @P_DATA_DIV = 'DEFAT_INCOTERMS_CD'
		BEGIN
			SELECT B.INCOTERMS AS CD  
				 , B.INCOTERMS AS CD_NM
	          FROM TB_CM_CONFIGURATION A  
	             , TB_CM_INCOTERMS B  
			 WHERE 1=1
			   AND A.ID = B.CONF_ID
		END	
	
	ELSE IF @P_DATA_DIV = 'DEFAT_SHIPPING_TRANSP_TP'
		BEGIN
		    SELECT Y.VEHICL_TP AS CD
		     	 , Y.VEHICL_TP AS CD_NM			 
		      FROM TB_CM_CONFIGURATION X  
		           ,TB_CM_VEHICLE Y  
	         WHERE 1=1
		       AND X.ID = Y.CONF_ID
		       AND Y.ACTV_YN = 'Y'
		END
	
	ELSE IF @P_DATA_DIV = 'DEFAT_SHIPPING_TRANSP_TP'
		BEGIN
		    SELECT Y.VEHICL_TP AS CD
		     	 , Y.VEHICL_TP AS CD_NM			 
		      FROM TB_CM_CONFIGURATION X  
		           ,TB_CM_VEHICLE Y  
	         WHERE 1=1
		       AND X.ID = Y.CONF_ID
		       AND Y.ACTV_YN = 'Y'
		END
	
	ELSE IF @P_DATA_DIV = 'STOCK_LOCATION_MGMT_TP'
		BEGIN
			SELECT Y.COMN_CD_NM AS CD_NM
			     , Y.COMN_CD AS CD
	          FROM TB_AD_COMN_GRP X 
	              ,TB_AD_COMN_CODE Y 
	         WHERE 1=1
	           AND X.GRP_CD = 'STOCK_LOCATION_MGMT_TP'
	           AND X.ID = Y.SRC_ID
	           AND Y.USE_YN ='Y'
		END
	
	ELSE IF @P_DATA_DIV = 'FIXED_PLN_TP'
		BEGIN
			SELECT Y.COMN_CD_NM AS CD_NM
			     , Y.COMN_CD AS CD
	          FROM TB_AD_COMN_GRP X 
	              ,TB_AD_COMN_CODE Y 
	         WHERE 1=1
	           AND X.GRP_CD = 'FIXED_PLN_TP'
	           AND X.ID = Y.SRC_ID
	      AND Y.USE_YN ='Y'   
		END
		 
	ELSE IF @P_DATA_DIV = 'CORPORATION1'
		BEGIN
			SELECT CORPOR_ID
			  FROM TB_CM_CORPORATION
		END
	  
	ELSE IF @P_DATA_DIV = 'CORPORATION2'
		BEGIN
			SELECT CORPOR_NM
			  FROM TB_CM_CORPORATION
		END

	ELSE IF @P_DATA_DIV = 'GET_BOM_VER'
		BEGIN
			
			SELECT A.BOM_VER_ID			 AS CD
			     , A.BOM_VER_ID  AS CD_NM
				 , 'BOM_VER'	 AS BOM_VER
			  FROM TB_CM_GLOBAL_BOM_DTL A 
			 WHERE A.PRDUCT_BOM_MST_ID = @P_PARAM1
		END

	ELSE IF @P_DATA_DIV ='GET_VEHICL_TP'
	    BEGIN
            SELECT DISTINCT
                   A.ID          AS CD,
                   A.VEHICL_TP   AS CD_NM
	          FROM TB_CM_VEHICLE A
	               INNER JOIN TB_CM_BOD_LT B
	               ON A.ID = B.VEHICL_TP_ID
                   AND ISNULL(B.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_MST C
	               ON C.ID = B.FROM_LOCAT_MST_ID
                   AND ISNULL(C.ACTV_YN, 'N') = 'Y'
   	               INNER JOIN TB_CM_LOC_MST D
	               ON D.ID = B.TO_LOCAT_MST_ID
                   AND ISNULL(D.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_DTL E
	               ON E.LOCAT_MST_ID = C.ID
                   AND ISNULL(E.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_DTL F
	               ON F.LOCAT_MST_ID = D.ID
                   AND ISNULL(F.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_MGMT G
	               ON G.LOCAT_ID = E.ID
                   AND ISNULL(G.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_MGMT H
	               ON H.LOCAT_ID = F.ID
                   AND ISNULL(B.ACTV_YN, 'N') = 'Y'
	         WHERE ISNULL(A.ACTV_YN, 'N') = 'Y'
               AND G.ID = @P_PARAM1
	           AND H.ID = @P_PARAM2
		END
	            
	ELSE IF @P_DATA_DIV ='GET_ITEM_CODE'
	    BEGIN
	        SELECT DISTINCT
	               IMS.ID		AS ITEM_MST_ID
	             , IMS.ITEM_CD	AS ITEM_CD
                 , IMS.ITEM_NM  AS ITEM_NM
                 , CIT.CONVN_NM AS ITEM_TP
	          FROM TB_CM_ITEM_MST IMS 
	               INNER JOIN TB_CM_ITEM_TYPE CIT 
	               ON IMS.ITEM_TP_ID = CIT.ID
	               AND ITEM_TP <> 'ROH'
	               AND ISNULL(CIT.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_SITE_ITEM SIT 
	               ON IMS.ID = SIT.ITEM_MST_ID
	               AND ISNULL(SIT.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_MGMT LMG
	               ON SIT.LOCAT_MGMT_ID =  LMG.ID
	               AND ISNULL(LMG.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_DTL LDT 
	               ON LMG.LOCAT_ID = LDT.ID
	               AND ISNULL(LDT.ACTV_YN, 'N') = 'Y'
                WHERE 1=1
				AND ISNULL(IMS.DEL_YN, 'N') = 'N'
                AND IMS.ITEM_CD LIKE '%'+@P_PARAM1+'%'
                AND ISNULL(IMS.ITEM_NM, ' ') LIKE '%'+@P_PARAM2+'%'
                AND IMS.ITEM_TP_ID = CASE WHEN @P_PARAM3='ALL' THEN IMS.ITEM_TP_ID
                                          WHEN  LTRIM(RTRIM(@P_PARAM3)) = '' THEN IMS.ITEM_TP_ID
                                          WHEN LTRIM(RTRIM(@P_PARAM3)) IS NOT NULL THEN @P_PARAM3 END
             ORDER BY IMS.ITEM_CD;
		END
	            
	ELSE IF @P_DATA_DIV ='GET_DP_ITEM'
	    BEGIN
	        SELECT DISTINCT
	               IMS.ID		AS ITEM_MST_ID
	             , IMS.ITEM_CD	AS ITEM_CD
                 , IMS.ITEM_NM  AS ITEM_NM
                 , CIT.CONVN_NM AS ITEM_TP
				 , IMS.UOM_ID	AS UOM_ID
	          FROM TB_CM_ITEM_MST IMS 
	               INNER JOIN TB_CM_ITEM_TYPE CIT 
	               ON IMS.ITEM_TP_ID = CIT.ID
	               AND ITEM_TP <> 'ROH'
	               AND ISNULL(CIT.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_SITE_ITEM SIT 
	               ON IMS.ID = SIT.ITEM_MST_ID
	               AND ISNULL(SIT.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_MGMT LMG
	               ON SIT.LOCAT_MGMT_ID =  LMG.ID
	               AND ISNULL(LMG.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_DTL LDT 
	               ON LMG.LOCAT_ID = LDT.ID
	               AND ISNULL(LDT.ACTV_YN, 'N') = 'Y'
                WHERE 1=1
				AND ISNULL(IMS.DEL_YN, 'N') = 'N'
				AND ISNULL(IMS.DP_PLAN_YN, 'N') = 'Y'
                AND IMS.ITEM_CD LIKE '%'+@P_PARAM1+'%'
                AND ISNULL(IMS.ITEM_NM, ' ') LIKE '%'+@P_PARAM2+'%'
                AND IMS.ITEM_TP_ID = CASE WHEN @P_PARAM3='ALL' THEN IMS.ITEM_TP_ID
                                          WHEN  LTRIM(RTRIM(@P_PARAM3)) = '' THEN IMS.ITEM_TP_ID
                                          WHEN LTRIM(RTRIM(@P_PARAM3)) IS NOT NULL THEN @P_PARAM3 END
             ORDER BY IMS.ITEM_CD;
		END

	ELSE IF @P_DATA_DIV = 'GET_ITEM_CODE_LIST'
		BEGIN
			SELECT DISTINCT
	               IMS.ID		AS CD
	             , IMS.ITEM_CD	AS CD_NM
	          FROM TB_CM_ITEM_MST IMS 
	               INNER JOIN TB_CM_ITEM_TYPE CIT 
	               ON IMS.ITEM_TP_ID = CIT.ID
	               AND ITEM_TP <> 'ROH'
	               AND ISNULL(CIT.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_SITE_ITEM SIT 
	               ON IMS.ID = SIT.ITEM_MST_ID
	               AND ISNULL(SIT.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_MGMT LMG
	               ON SIT.LOCAT_MGMT_ID =  LMG.ID
	               AND ISNULL(LMG.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_DTL LDT 
	               ON LMG.LOCAT_ID = LDT.ID
	               AND ISNULL(LDT.ACTV_YN, 'N') = 'Y'
                WHERE 1= CASE WHEN @P_PARAM1 IS NULL OR @P_PARAM1 = '' THEN 1
	                        WHEN LDT.ID = @P_PARAM1 THEN 1
	                   END;
		END
	            
	ELSE IF @P_DATA_DIV ='GET_ITEM_CODE_ALL'
	    BEGIN
	        SELECT DISTINCT
	               IMS.ID			AS CD
	             , IMS.ITEM_CD		AS CD_NM
	          FROM TB_CM_ITEM_MST IMS 
	               INNER JOIN TB_CM_SITE_ITEM SIT 
	               ON IMS.ID = SIT.ITEM_MST_ID
	               AND ISNULL(SIT.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_MGMT LMG
	               ON SIT.LOCAT_MGMT_ID =  LMG.ID
	               AND ISNULL(LMG.ACTV_YN, 'N') = 'Y'
	               INNER JOIN TB_CM_LOC_DTL LDT 
	               ON LMG.LOCAT_ID = LDT.ID
	               AND ISNULL(LDT.ACTV_YN, 'N') = 'Y'
	         WHERE 1 = CASE WHEN @P_PARAM1 IS NULL OR @P_PARAM1 = '' THEN 1
	                        WHEN LDT.ID = @P_PARAM1 THEN 1
	                   END
             ORDER BY IMS.ITEM_CD
		END
             
	ELSE IF @P_DATA_DIV ='GET_LOCAT_ITEM'
	    BEGIN
		    SELECT SIT.ID			AS CD
				 , IMS.ITEM_CD		AS CD_NM
		      FROM TB_CM_LOC_DTL LDT 
		           INNER JOIN TB_CM_LOC_MGMT LMG 
		           ON LDT.ID = LMG.LOCAT_ID
	               AND ISNULL(LMG.ACTV_YN, 'N') = 'Y'
		           INNER JOIN TB_CM_SITE_ITEM SIT
		           ON LMG.ID = SIT.LOCAT_MGMT_ID
	               AND ISNULL(SIT.ACTV_YN, 'N') = 'Y'
				   INNER JOIN TB_CM_ITEM_MST IMS 
		           ON SIT.ITEM_MST_ID = IMS.ID
		     WHERE ISNULL(LDT.ACTV_YN, 'N') = 'Y'
		       AND 1 = CASE WHEN @P_PARAM1 IS NULL OR @P_PARAM1 = '' THEN 1
		                    WHEN LDT.ID = @P_PARAM1 THEN 1
		               END
		     ORDER BY IMS.ITEM_CD
		END
             
	ELSE IF @P_DATA_DIV ='GET_ITEM_LOCAT'
	    BEGIN
        	SELECT DISTINCT 
		   		   LDT.ID				AS CD
		 		 , LDT.LOCAT_CD			AS CD_NM
	  		  FROM TB_CM_LOC_DTL LDT 
	    		   INNER JOIN TB_CM_LOC_MGMT LMG 
          		   ON LDT.ID = LMG.LOCAT_ID
	               AND ISNULL(LMG.ACTV_YN, 'N') = 'Y'
        		   INNER JOIN TB_CM_SITE_ITEM SIT	
          		   ON LMG.ID = SIT.LOCAT_MGMT_ID
	               AND ISNULL(SIT.ACTV_YN, 'N') = 'Y'
        		   INNER JOIN TB_CM_ITEM_MST IMS
          		   ON SIT.ITEM_MST_ID = IMS.ID
	 		 WHERE ISNULL(LDT.ACTV_YN, 'N') = 'Y'
         	   AND 1 = CASE WHEN @P_PARAM1 IS NULL OR @P_PARAM1 = '' THEN 1
                            WHEN IMS.ID = @P_PARAM1  THEN 1
             		   END
			 ORDER BY LDT.LOCAT_CD
		END
	
	ELSE IF @P_DATA_DIV = 'GET_ITEM_RES_PREF'
		BEGIN
			SELECT RMD.ID			AS CD
	             , RMD.RES_CD		AS CD_NM
	          FROM TB_MP_RES_MGMT_DTL RMD  
	               INNER JOIN TB_MP_ITEM_RES_PREFER_MST RPM  
	               ON RMD.ID = RPM.RES_ID
	               INNER JOIN TB_CM_SITE_ITEM SIT  
	               ON RPM.LOCAT_ITEM_ID = SIT.ID
	               INNER JOIN TB_CM_ITEM_MST IMS  
	               ON SIT.ITEM_MST_ID = IMS.ID
	               INNER JOIN TB_CM_ITEM_TYPE CIT  
	               ON IMS.ITEM_TP_ID = CIT.ID
	               AND ITEM_TP <> 'ROH'
	               INNER JOIN TB_CM_LOC_MGMT LMG  
	               ON SIT.LOCAT_MGMT_ID =  LMG.ID
	               INNER JOIN TB_CM_LOC_DTL LDT  
	               ON LMG.LOCAT_ID = LDT.ID
	         WHERE 1 = 1
	           AND 1 = CASE WHEN @P_PARAM1 IS NULL OR @P_PARAM1 = '' THEN 1
	                       WHEN LDT.ID = @P_PARAM1 THEN 1
	                   END
	           AND 1 = CASE WHEN @P_PARAM2 IS NULL OR @P_PARAM2 = '' THEN 1
	                       WHEN SIT.ID = @P_PARAM2 THEN 1
	                   END;
		END

	ELSE IF @P_DATA_DIV = 'GET_LOCAT_RES'
		BEGIN
			SELECT RMD.ID			AS CD
	             , RMD.RES_CD		AS CD_NM
	          FROM TB_MP_RES_MGMT_DTL RMD  
	               INNER JOIN TB_MP_RES_MGMT_MST RMM  
	               ON RMD.RES_MGMT_MST_ID = RMM.ID 
	               INNER JOIN TB_CM_LOC_MGMT LMG
	               ON RMM.LOCAT_MGMT_ID = LMG.ID
	               INNER JOIN TB_CM_LOC_DTL LDT
	               ON LMG.LOCAT_ID = LDT.ID
	         WHERE 1=1
	           AND 1 = CASE WHEN @P_PARAM1 = NULL OR @P_PARAM1 = '' THEN 1
	                       WHEN LDT.ID = @P_PARAM1 THEN 1
					END
		END

	ELSE IF @P_DATA_DIV = 'GET_LOCAT_INFO'
		BEGIN
			SELECT DISTINCT 
			 	   DTL.ID
				 , ACM.COMN_CD_NM		AS LOCAT_TP
				 , MST.LOCAT_LV			AS LOCAT_LV
				 , DTL.LOCAT_CD			AS LOCAT_CD
				 , DTL.LOCAT_NM			AS LOCAT_NM
				 , MGT.PLAN_RES_TP_ID	AS PLAN_RES_TP_ID
				 , ACD1.COMN_CD_NM		AS PLAN_RES_TP
				 , RMG.ROUTE_GRP		AS ROUTE_GRP
				 , RGP.RES_GRP_CD		AS RES_GRP_CD
				 , RGP.DESCRIP			AS RES_DESCRIP
				 , ACD2.COMN_CD_NM		AS RES_GRP_TP
				 , RMG.WC				AS WC
				 , RMG.ACTV_YN			AS ACTV_YN
			  FROM TB_CM_LOC_DTL DTL 
				   LEFT OUTER JOIN TB_CM_LOC_MST MST 
				   ON MST.ID = DTL.LOCAT_MST_ID
				   LEFT OUTER JOIN TB_AD_COMN_CODE	ACM
				   ON MST.LOCAT_TP_ID = ACM.ID
				   LEFT OUTER JOIN TB_CM_LOC_MGMT MGT
				   ON DTL.ID = MGT.LOCAT_ID
				   LEFT OUTER JOIN TB_AD_COMN_CODE ACD1
				   ON MGT.PLAN_RES_TP_ID = ACD1.ID
				   LEFT OUTER JOIN TB_MP_RES_MGMT_MST RMG 
				   ON MGT.ID = RMG.LOCAT_MGMT_ID
				   LEFT OUTER JOIN TB_CM_RES_GROUP RGP
				   ON RMG.RES_GRP_ID = RGP.ID
				   LEFT OUTER JOIN TB_AD_COMN_CODE ACD2 
				   ON RGP.RES_GRP_TP_ID = ACD2.ID
			 WHERE DTL.ID = @P_PARAM1;
		END

	ELSE IF @P_DATA_DIV = 'GET_ITEM_CLASS'
		BEGIN
			SELECT A.ID 
			     , B.ITEM_SCOPE_NM AS ITEM_LV_NM
			     , A.ITEM_CLASS_VAL
			     , A.DESCRIP
			     , A.CONTINU_PRDUCT_YN
			     , A.PROD_MIX_YN
			     , A.ACTV_YN
		      FROM TB_CM_ITEM_CLASS_MST A
			       INNER JOIN TB_CM_ITEM_SCOPE_MST B 
	               ON A.ITEM_SCOPE_MST_ID = B.ID;
		END

	ELSE IF @P_DATA_DIV = 'GET_MAIN_CAL'
		BEGIN
			SELECT ACD1.COMN_CD_NM			AS LOCAT_TP
			     , LMS.LOCAT_LV				AS LOCAT_LV
			     , LDT.LOCAT_CD				AS LOCAT_CD
			     , LDT.LOCAT_NM				AS LOCAT_NM
			     , RMD.RES_CD				AS RES_CD
			     , RMD.RES_DESCRIP			AS RES_DESCRIP
		    	 , RHL.CALENDAR_ID			AS CALENDAR_ID
			     , RHL.CALENDAR_DESCRIP		AS CALENDAR_DESCRIP
		    	 , ACD3.COMN_CD_NM			AS CYCL_TP
		      FROM TB_MP_RES_HOLIDAY RHL
				   INNER JOIN TB_AD_COMN_CODE ACD3
				   ON RHL.CYCL_TP_ID = ACD3.ID
	               INNER JOIN TB_MP_RES_MGMT_DTL RMD
	               ON RHL.RES_ID = RMD.ID
	               INNER JOIN TB_MP_RES_MGMT_MST RMM
	               ON RMD.RES_MGMT_MST_ID =  RMM.ID 
	               INNER JOIN TB_CM_LOC_MGMT LMG
	               ON RMM.LOCAT_MGMT_ID = LMG.ID
			       LEFT OUTER JOIN TB_AD_COMN_CODE ACD2
				   ON LMG.PLAN_RES_TP_ID = ACD2.ID
	               INNER JOIN TB_CM_LOC_DTL LDT
	               ON LMG.LOCAT_ID = LDT.ID
	               INNER JOIN TB_CM_LOC_MST LMS
	               ON LDT.LOCAT_MST_ID = LMS.ID
				   INNER JOIN TB_AD_COMN_CODE ACD1
				   ON LMS.LOCAT_TP_ID = ACD1.ID
		     WHERE UPPER(LDT.LOCAT_CD) LIKE '%'+UPPER(@P_PARAM1)+'%'
		     ORDER BY ACD1.COMN_CD_NM, LDT.LOCAT_CD, RMD.RES_CD;
		END

	ELSE IF @P_DATA_DIV = 'GET_ITEM_LV'
		BEGIN
			SELECT A.ID				AS ITEM_LV_ID
				 , A.ITEM_LV_CD
				 , A.ITEM_LV_NM
				 , B.ITEM_LV_CD		AS PARENT_ITEM_LV_CD
				 , B.ITEM_LV_NM		AS PARENT_ITEM_LV_NM
			  FROM TB_CM_ITEM_LEVEL_MGMT A
				INNER JOIN TB_CM_LEVEL_MGMT LV on A.LV_MGMT_ID = LV.ID
				INNER JOIN TB_CM_COMM_CONFIG C on LV.LV_TP_ID = C.ID and C.CONF_CD = 'I'			  
			    LEFT OUTER JOIN TB_CM_ITEM_LEVEL_MGMT B   ON B.ID = A.PARENT_ITEM_LV_ID
			 WHERE A.ACTV_YN = 'Y'
		END

	ELSE IF @P_DATA_DIV = 'GET_SALES_LV'
		BEGIN
			SELECT A.ID				AS SALES_LV_ID
				 , A.SALES_LV_CD
				 , A.SALES_LV_NM
				 , B.SALES_LV_CD	AS PARENT_SALES_LV_CD
				 , B.SALES_LV_NM	AS PARENT_SALES_LV_NM
				 , A.VIRTUAL_YN
			  FROM TB_DP_SALES_LEVEL_MGMT A
				INNER JOIN TB_CM_LEVEL_MGMT LV on A.LV_MGMT_ID = LV.ID
				INNER JOIN TB_CM_COMM_CONFIG C on LV.LV_TP_ID = C.ID and C.CONF_CD = 'S'			  
				LEFT OUTER JOIN TB_DP_SALES_LEVEL_MGMT B   ON B.ID = A.PARENT_SALES_LV_ID
			 WHERE A.ACTV_YN = 'Y'
		END

END

go

