/*****************************************************************************
Title : SP_DP_15_S3
 
설명 
 - DP User Mapping(Item&Account)
 
History (수정일자 / 수정자 / 수정내용)
- 2022.11.22 /hanguls / create
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_15_S3]  (
									   @p_FROM_EMP_NO			  NVARCHAR(25)		= ''      
									  ,@p_TO_EMP_NO			  NVARCHAR(25)		= ''      
									  ,@p_AUTH_TP_ID          CHAR(32)			= ''      
									  ,@p_TRANFER_TYPE             NVARCHAR(50)      = 'COPY'  
									  ,@p_USER_ID             NVARCHAR(50)      = ''  
									  ,@P_RT_ROLLBACK_FLAG    NVARCHAR(10)		= 'true'	 OUTPUT
									  ,@P_RT_MSG              NVARCHAR(4000)	= ''		 OUTPUT
				                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE   @P_ERR_TYPE                 NVARCHAR(32)      = NULL    
		, @P_FROM_EMP_ID                   NVARCHAR(32)      = NULL 
		, @P_TO_EMP_ID                   NVARCHAR(32)      = NULL 

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''

  
BEGIN TRY

-- EMPLOYEE 가 선택되지 않은 경우
IF (@p_FROM_EMP_NO IS NULL OR @p_FROM_EMP_NO = '' or @p_TO_EMP_NO IS NULL OR @p_TO_EMP_NO = '')
	BEGIN
	   SET @P_ERR_MSG = 'MSG_0014' 
	   RAISERROR (@P_ERR_MSG,12, 1);	
	END


  -- 프로시저 시작 
BEGIN 
    -- EMP_ID Setting 
	SELECT @P_FROM_EMP_ID = ID 
	  FROM TB_AD_USER
	WHERE USERNAME = @p_FROM_EMP_NO
	;
	SELECT @P_TO_EMP_ID = ID 
	  FROM TB_AD_USER
	WHERE USERNAME = @p_TO_EMP_NO
	;

	IF(@p_TRANFER_TYPE = 'MOVE')
		BEGIN
		UPDATE TB_DP_USER_ITEM_ACCOUNT_MAP SET EMP_ID = @P_TO_EMP_ID WHERE AUTH_TP_ID = @P_AUTH_TP_ID and EMP_ID = @P_FROM_EMP_ID
		END
	ELSE 
		BEGIN 
		MERGE TB_DP_USER_ITEM_ACCOUNT_MAP  TGT   
		USING ( 							   
				 select distinct @P_TO_EMP_ID as EMP_ID , AUTH_TP_ID,  ACCOUNT_ID,  ITEM_MST_ID, @P_USER_ID AS USER_ID, ACTV_YN
				 from TB_DP_USER_ITEM_ACCOUNT_MAP tduiam 
				 where AUTH_TP_ID = @P_AUTH_TP_ID
				 and EMP_ID = @P_FROM_EMP_ID							   
			  ) SRC
		ON      TGT.ACCOUNT_ID = SRC.ACCOUNT_ID and TGT.ITEM_MST_ID = src.ITEM_MST_ID and TGT.AUTH_TP_ID = SRC.AUTH_TP_ID and TGT.EMP_ID = SRC.EMP_ID
		WHEN MATCHED THEN
			 UPDATE 
			   SET   TGT.MODIFY_BY   = SRC.USER_ID
					,TGT.ACTV_YN     = SRC.ACTV_YN 
					,TGT.MODIFY_DTTM = GETDATE()       
		WHEN NOT MATCHED THEN 
			 INSERT (
			            ID 
					  , AUTH_TP_ID
					  , ACCOUNT_ID
					  , ITEM_MST_ID
					  , EMP_ID
					  , ACTV_YN
					  , CREATE_BY
					  , CREATE_DTTM
					) 
			 VALUES (
			            REPLACE(NEWID(),'-','')
						  , SRC.AUTH_TP_ID
						  , SRC.ACCOUNT_ID
						  , SRC.ITEM_MST_ID
						  , SRC.EMP_ID
						  , SRC.ACTV_YN
						  , SRC.USER_ID 
						  , GETDATE()            
						) 
						;    	

		END			
		
   END 


	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN			   
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR
END CATCH;

go

