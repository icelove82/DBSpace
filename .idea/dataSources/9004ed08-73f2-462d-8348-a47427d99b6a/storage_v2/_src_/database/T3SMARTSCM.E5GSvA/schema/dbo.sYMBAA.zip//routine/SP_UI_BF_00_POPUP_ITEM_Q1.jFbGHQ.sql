CREATE PROCEDURE [dbo].[SP_UI_BF_00_POPUP_ITEM_Q1] (
	  @P_LV_MGMT_ID CHAR(32)
	, @P_ITEM_CD		NVARCHAR(100)  
	, @P_ITEM_NM		NVARCHAR(240)
	, @P_ACCT_CD	NVARCHAR(100)
) AS 
BEGIN	
/******************************************************************************************
	Item & Item level

	history ( date / writer / comment)
	- 2020.09.01 / ksh / draft 
******************************************************************************************/
IF EXISTS (
	SELECT 1
	  FROM TB_CM_LEVEL_MGMT
	 WHERE (ID = @P_LV_MGMT_ID AND LEAF_YN  ='Y')
	 	OR @P_LV_MGMT_ID = ''
)
	BEGIN
		SELECT DISTINCT 
			   IM.ID
			 , IM.ITEM_CD  
			 , IM.ITEM_NM 
		  FROM TB_CM_ITEM_MST IM
--		  			    INNER JOIN TB_BF_ITEM_ACCOUNT_MODEL_MAP IAM
--			  		ON IAM.ITEM_CD = IM.ITEM_CD
--			  	   AND IAM.ACTV_YN = 'Y'
--				   AND 'Y' = CASE WHEN @P_ACCT_CD = '' THEN 'Y'
--				   				  ELSE (CASE WHEN @P_ACCT_CD = IAM.ACCOUNT_CD THEN 'Y' ELSE 'N' END)
--								   END
		 WHERE DEL_YN = 'N'
		   AND DP_PLAN_YN = 'Y'	
		   AND PARENT_ITEM_LV_ID IS NOT NULL
		    AND  ('Y' = CASE WHEN @P_ITEM_CD = '' THEN 'Y'
							ELSE ( case when UPPER(IM.ITEM_CD)  LIKE '%' + UPPER(RTRIM(ISNULL(@P_ITEM_CD,''))) + '%'	then 'Y' else 'N' end) 
						    END)
 		    AND ('Y' = CASE WHEN @P_ITEM_NM = '' THEN 'Y'
							ELSE ( case when UPPER(IM.ITEM_NM)  LIKE '%' + UPPER(RTRIM(ISNULL(@P_ITEM_NM,''))) + '%'	then 'Y' else 'N' end) 
						    END)
	END
ELSE 
	BEGIN
		SELECT ID
			  ,ITEM_LV_CD	AS ITEM_CD  
			  ,ITEM_LV_NM 	AS ITEM_NM 
		  FROM TB_CM_ITEM_LEVEL_MGMT IL
		 WHERE LV_MGMT_ID = @P_LV_MGMT_ID 
		   AND ACTV_YN = 'Y'
		   AND DEL_YN = 'N'
		   AND ('Y' = CASE WHEN @P_ITEM_CD = '' THEN 'Y'
						   ELSE ( case when UPPER(ITEM_LV_CD)  LIKE '%' + UPPER(RTRIM(ISNULL(@P_ITEM_CD,''))) + '%'	then 'Y' else 'N' end) 
						   END)
		   AND ('Y' = CASE WHEN @P_ITEM_NM = '' THEN 'Y'
						   ELSE ( case when UPPER(ITEM_LV_NM)  LIKE '%' + UPPER(RTRIM(ISNULL(@P_ITEM_NM,''))) + '%'	then 'Y' else 'N' end) 
						   END)
	END
END
go

