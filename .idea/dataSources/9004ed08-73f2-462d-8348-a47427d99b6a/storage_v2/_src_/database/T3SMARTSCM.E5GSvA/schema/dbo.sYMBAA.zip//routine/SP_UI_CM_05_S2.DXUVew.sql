CREATE PROCEDURE [dbo].[SP_UI_CM_05_S2] (
	 @P_ID						AS NVARCHAR(32)	= null
	,@P_GLOBAL_BOM_MST_ID		AS NVARCHAR(32) = null
	,@P_BOM_VER					AS NVARCHAR(32) = null
	,@P_VER_ACTV_YN				AS CHAR(1)		= null
	,@P_BASE_BOM_YN				AS CHAR(1)		= null
	,@P_LOCAT_ITEM_ID			AS NVARCHAR(32) = null
	,@P_BASE_BOM_RATE			AS DECIMAL(20,3)= null
	,@P_ALT_GRP_ID				AS NVARCHAR(32)	= null
	,@P_ALT_POLICY_ID			AS NVARCHAR(32)	= null
	,@P_PRIORT					AS INT			= null
	,@P_PRDUCT_YN				AS CHAR(1)		= null
	,@P_ACTV_YN					AS CHAR(1)		= null
	,@P_BOM_LV					AS DECIMAL(20,3)= null
	,@P_USER_ID					AS NVARCHAR(50) = null
	,@P_RT_ROLLBACK_FLAG		AS NVARCHAR(10)   = 'true'   OUTPUT
	,@P_RT_MSG					AS NVARCHAR(4000) = ''		 OUTPUT
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON;

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''
	   ,@P_PARENT_BASE_QTY INT = 0
	   ,@V_CHECK_ID CHAR(32) = NULL
		
BEGIN TRY
	IF ISNULL(@P_BASE_BOM_RATE, -1) < 0
	SET @P_BASE_BOM_RATE = 0;

	SET @P_PARENT_BASE_QTY = ( SELECT A.BASE_QTY FROM TB_CM_GLOBAL_BOM_MST A WHERE A.ID = @P_GLOBAL_BOM_MST_ID )

	SET @P_ERR_MSG = 'MSG_0006'
	IF (@P_BOM_VER IS NULL OR @P_BOM_VER = '')
	RAISERROR (@P_ERR_MSG,12, 1);

	SET @P_ERR_MSG = 'MSG_0008'
	IF (@P_BASE_BOM_RATE < 0)
	RAISERROR (@P_ERR_MSG,12, 1);

	SET @P_ERR_MSG = 'MSG_0013'
	SET @V_CHECK_ID = ( SELECT ID FROM TB_CM_GLOBAL_BOM_DTL WHERE PRDUCT_BOM_MST_ID = @P_GLOBAL_BOM_MST_ID AND LOCAT_ITEM_ID = @P_LOCAT_ITEM_ID )
	IF((@P_ID IS NULL OR @P_ID = '') AND @V_CHECK_ID IS NOT NULL)
	RAISERROR (@P_ERR_MSG,12, 1);

	 MERGE INTO TB_CM_GLOBAL_BOM_DTL A
        USING (SELECT @P_ID AS ID) B
        ON (A.ID = B.ID)
        WHEN MATCHED THEN
            UPDATE
            SET A.VER_ACTV_YN = @P_VER_ACTV_YN
			   ,A.BASE_BOM_YN = @P_BASE_BOM_YN
               ,A.BASE_BOM_RATE = @P_BASE_BOM_RATE
               ,A.CONSUME_QTY = (@P_PARENT_BASE_QTY * @P_BASE_BOM_RATE)
               ,A.ALT_GRP_ID = @P_ALT_GRP_ID
               ,A.ALT_POLICY_ID = @P_ALT_POLICY_ID
               ,A.PRIORT = @P_PRIORT
               ,A.PRDUCT_YN = @P_PRDUCT_YN
			   ,A.ACTV_YN = @P_ACTV_YN
               ,A.MODIFY_BY = @P_USER_ID
               ,A.MODIFY_DTTM = GETDATE()
        WHEN NOT MATCHED THEN
            INSERT (
                ID, CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM
               ,PRDUCT_BOM_MST_ID
               ,BOM_VER_ID
               ,VER_ACTV_YN
               ,BASE_BOM_YN
               ,LOCAT_ITEM_ID
			   ,STRT_DATE
			   ,END_DATE
               ,CONSUME_QTY
               ,BASE_BOM_RATE
               ,ALT_GRP_ID
               ,ALT_POLICY_ID
               ,PRIORT
               ,PRDUCT_YN
               ,ACTV_YN
               ,BOM_LV
            )
            VALUES (
                REPLACE(NEWID(), '-' , ''), @P_USER_ID, GETDATE(), NULL, NULL
               ,@P_GLOBAL_BOM_MST_ID
               ,@P_BOM_VER
               ,@P_VER_ACTV_YN
               ,@P_BASE_BOM_YN
               ,@P_LOCAT_ITEM_ID
			   ,CONVERT(DATETIME, '19990101', 120)
			   ,CONVERT(DATETIME, '99991231', 120)
               ,(@P_PARENT_BASE_QTY * @P_BASE_BOM_RATE)
               ,@P_BASE_BOM_RATE
               ,@P_ALT_GRP_ID
               ,@P_ALT_POLICY_ID
               ,@P_PRIORT
               ,@P_PRDUCT_YN
               ,@P_ACTV_YN
               ,@P_BOM_LV
            );

	SET @P_RT_MSG = 'MSG_0001'
	SET @P_RT_ROLLBACK_FLAG = 'true'

END TRY
BEGIN CATCH
	IF (ERROR_MESSAGE() LIKE 'MSG_%')
		BEGIN
				SET @P_ERR_MSG = ERROR_MESSAGE()
				SET @P_RT_ROLLBACK_FLAG = 'false'
				SET @P_RT_MSG = @P_ERR_MSG
		END
	ELSE
		THROW;
END CATCH

go

