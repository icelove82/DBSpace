/*****************************************************************************
Title : [SP_UI_MP_07_POP_S2]
최초 작성자 : 조아람
최초 생성일 : 2017.09.06
 
설명 
 - MP Resource Preference Analysis - 일괄 업데이트 팝업 저장 프로시저
 
History (수정일자 / 수정자 / 수정내용)
- 2017.09.06 / 조아람 / 최초 작성
 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_MP_07_POP_S2] (
	 @P_WRK_TYPE			NVARCHAR(10) = '' 
	,@P_APPLY_RANGE			CHAR(1) = ''		-- 전체거점 : A, 특정거점:L
	,@P_LOC_DTL_ID			CHAR(32) = ''
	,@P_PRIORT_YN			CHAR(1) = ''
	,@P_PRIORT_BASE			CHAR(1) = ''		-- Based on Production Quantity : Q, Based on Production Times : T
	,@P_PROPTN_YN			CHAR(1) = ''
	,@P_PROPTN_BASE			CHAR(1) = ''		-- Based on Production Quantity : Q, Based on Production Times : T
	,@P_OVERRIDE_YN			CHAR(1) = ''		
	,@p_USER_ID				NVARCHAR (100)
	,@P_RT_ROLLBACK_FLAG	NVARCHAR(10)   = 'true'  OUTPUT
	,@P_RT_MSG				NVARCHAR(4000) = ''	     OUTPUT
) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''

BEGIN TRY

		IF @P_APPLY_RANGE = 'A' 
			BEGIN

				UPDATE RPM
				   SET RPM.BASE_ALLOC_PRIORT = CASE WHEN @P_PRIORT_YN = 'Y'
												   THEN CASE WHEN @P_PRIORT_BASE = 'Q'	THEN RPA.PRDUCT_QTY_PRIORT_PRPSAL_VAL
															 WHEN @P_PRIORT_BASE = 'T' THEN RPA.PRDUCT_TIMES_PRIORT_PRPSAL_VAL
														 END
												   ELSE RPM.BASE_ALLOC_PRIORT
											   END
					 , RPM.BASE_ALLOC_PROPTN = CASE WHEN @P_PROPTN_YN = 'Y'
												   THEN CASE WHEN @P_PROPTN_BASE = 'Q'	THEN RPA.PRDUCT_QTY_PROPTN_PRPSAL_VAL
															 WHEN @P_PROPTN_BASE = 'T'  THEN RPA.PRDUCT_TIMES_PROPTN_PRPSAL_VAL
														 END
												   ELSE RPM.BASE_ALLOC_PROPTN
											   END
					 , RPM.MODIFY_BY = @p_USER_ID
					 , RPM.MODIFY_DTTM = GETDATE()
				  FROM TB_MP_ITEM_RES_PREFER_MST RPM
					 , TB_MP_RES_PREFER_ANLYS RPA
				 WHERE RPM.LOCAT_ITEM_ID = RPA.LOCAT_ITEM_ID
				   AND RPM.RES_ID = RPA.RES_ID
				   AND 1 = CASE WHEN @P_OVERRIDE_YN = 'N'
								THEN CASE WHEN RPM.FIXED_YN='N' THEN 1 END
								ELSE 1
						    END
					

				--EXEC SP_UI_MP_07_POP_S2_SUB @P_WRK_TYPE, '', @p_USER_ID

			END
		
		ELSE IF @P_APPLY_RANGE = 'L'
			BEGIN
				
				UPDATE RPM
				   SET RPM.BASE_ALLOC_PRIORT = CASE WHEN @P_PRIORT_YN = 'Y'
												   THEN CASE WHEN @P_PRIORT_BASE = 'Q' THEN RPA.PRDUCT_QTY_PRIORT_PRPSAL_VAL
															 WHEN @P_PRIORT_BASE = 'T' THEN RPA.PRDUCT_TIMES_PRIORT_PRPSAL_VAL
														 END
												   ELSE RPM.BASE_ALLOC_PRIORT
											   END
					 , RPM.BASE_ALLOC_PROPTN = CASE WHEN @P_PROPTN_YN = 'Y'
												   THEN CASE WHEN @P_PROPTN_BASE = 'Q' THEN RPA.PRDUCT_QTY_PROPTN_PRPSAL_VAL
															 WHEN @P_PROPTN_BASE = 'T' THEN RPA.PRDUCT_TIMES_PROPTN_PRPSAL_VAL
														 END
												   ELSE RPM.BASE_ALLOC_PROPTN
											   END
					 , RPM.MODIFY_BY = @p_USER_ID
					 , RPM.MODIFY_DTTM = GETDATE()
				  FROM TB_CM_LOC_DTL LDT
				     , TB_CM_LOC_MGMT LMG
						INNER JOIN TB_CM_SITE_ITEM SIT
							ON LMG.ID = SIT.LOCAT_MGMT_ID
						INNER JOIN TB_MP_RES_MGMT_MST RMM
							ON LMG.ID = RMM.LOCAT_MGMT_ID
						INNER JOIN TB_MP_RES_MGMT_DTL RMD
							ON RMM.ID = RMD.RES_MGMT_MST_ID
					 , TB_MP_ITEM_RES_PREFER_MST RPM
					 , TB_MP_RES_PREFER_ANLYS RPA
				 WHERE LDT.ID = LMG.LOCAT_ID
				   AND SIT.ID = RPM.LOCAT_ITEM_ID
				   AND RMD.ID = RPM.RES_ID
				   AND RPM.LOCAT_ITEM_ID = RPA.LOCAT_ITEM_ID
				   AND RPM.RES_ID = RPA.RES_ID
				   AND LDT.ID = @P_LOC_DTL_ID
				   AND 1 = CASE WHEN @P_OVERRIDE_YN = 'N'
								THEN CASE WHEN RPM.FIXED_YN='N' THEN 1 END
								ELSE 1
						    END

				--EXEC SP_UI_MP_07_POP_S2_SUB @P_WRK_TYPE, @P_LOC_DTL_ID, @p_USER_ID

			END
     
	SET @P_RT_ROLLBACK_FLAG = 'true'
	SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY

BEGIN CATCH
	IF(ERROR_MESSAGE() LIKE 'MSG_%')
		BEGIN
			SET @P_ERR_MSG = ERROR_MESSAGE()
			SET @P_RT_ROLLBACK_FLAG = 'false'
			SET @P_RT_MSG = @P_ERR_MSG
		END
	ELSE
		THROW
END CATCH

go

