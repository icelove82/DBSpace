/******************************************************************************************
	Check a User's Task Status

	Description
	- CNT : a number of approval
	- If CNT is 0, Status is true.
	- 최종 Close를 해도, close를 한번 더 못하지만, 다른 처리는 가능한 상태

	History (Date / Writer / Comment)
	- 2020.05.04 / Kimsohee / Draft
	- 2020.06.05 / hanguls / USER_ID => USERNAME
	- 2020.07.03 / Kimsohee / 최종 close에 대한 활성화 처리 추가 
	- 2020.09.22 /hanguls TB_DP_EMPLOYEE => TB_AD_USER
	- 2020.12.04 / kim sohee / confirm Control board version detail
	- 2020.12.07 / kim sohee / bug fix
******************************************************************************************/
CREATE PROCEDURE [dbo].[SP_UI_DP_00_CHECK_USER_TASK] 
(
	    @P_TASK_CATEGORY	NVARCHAR(10)	 -- = 'ALL' 'CLOSE'
	  , @P_EMP_NO			NVARCHAR(50) -- = 'GOC'
	  , @P_AUTH_TP			NVARCHAR(50) -- = 'GOC'
	  , @P_VER_CD			NVARCHAR(50) -- = 'DPM-20200427-003-00'	  
) 
AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
BEGIN
DECLARE @P_CL_STATUS_CNT	INT 
	  , @P_FINAL_CLOSE_CNT	INT = 0
	  , @P_VER_ID			CHAR(32) 
	  ;
			 SELECT @P_VER_ID	= ID 
			  FROM TB_DP_CONTROL_BOARD_VER_MST
			WHERE VER_ID = @P_VER_CD 
			;
			-- (2) 최종 Close를 했는지 안했는지 : 이 경우, 다른 Status도 diable 상태로 변경
			SELECT @P_FINAL_CLOSE_CNT = COUNT(1)				  
			  FROM TB_DP_CONTROL_BOARD_VER_DTL CD				 
			 WHERE CD.CL_STATUS_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_CL_STATUS' AND CONF_CD = 'CLOSE')
			   AND CD.CONBD_VER_MST_ID = @P_VER_ID 		
			 ;
			-- Close 가능한 상태인지 아닌지 판단
			-- (1) 최상위 관리자의 가장 최근 처리 상태가 승인인지 아닌지
			WITH GOC
			AS (
				SELECT TOP 1 WITH TIES CL.SEQ
						,EP.[USERNAME]	AS [USER_ID]
						,CL.LV_CD		AS AUTH_TP
				  FROM TB_DP_SALES_AUTH_MAP SA
					   INNER JOIN
					   TB_DP_SALES_LEVEL_MGMT SL
					ON SA.SALES_LV_ID = SL.ID
				   AND SL.ACTV_YN = 'Y'
				   AND COALESCE(SL.DEL_YN,'N') = 'N'
					   INNER JOIN
					   TB_CM_LEVEL_MGMT CL
					ON SL.LV_MGMT_ID = CL.ID
				   AND CL.ACTV_YN = 'Y'
				   AND COALESCE(CL.DEL_YN,'N') = 'N'
					   INNER JOIN 
					   TB_DP_CONTROL_BOARD_VER_DTL VD
					ON VD.CONBD_VER_MST_ID = @P_VER_ID
				   AND CL.ID = VD.LV_MGMT_ID
					   INNER JOIN
					   TB_AD_USER EP
					ON EP.ID = SA.EMP_ID
				ORDER BY CL.SEQ ASC
				)
			SELECT @P_CL_STATUS_CNT = COUNT([STATUS]) 
			  FROM (
					SELECT ISNULL(ST.[STATUS], 'READY') AS [STATUS], ROW_NUMBER() OVER (PARTITION BY GC.[USER_ID] ORDER BY ST.STATUS_DATE DESC) AS RW
					  FROM GOC  GC
						   LEFT OUTER JOIN 
						   TB_DP_PROCESS_STATUS_LOG ST
						ON ST.OPERATOR_ID = GC.[USER_ID]
					   AND ST.AUTH_TYPE = GC.AUTH_TP 
					   AND VER_CD = @P_VER_CD
					) A
			 WHERE A.RW = 1
			   AND  [STATUS] != 'APPROVAL'
			  ;

 
--			SELECT @P_FINAL_CLOSE_CNT, @P_CL_STATUS_CNT;

			WITH STA_CONF
			AS (SELECT AC.CONF_CD						AS APPROVAL
					 , IT.CONF_CD	 					AS INPUT	
					 , ISNULL(CC.CONF_CD, AC.CONF_CD)	AS CANCEL
				  FROM TB_DP_CONTROL_BOARD_VER_MST CB
					   INNER JOIN
					   TB_DP_CONTROL_BOARD_VER_DTL CD
					ON CB.ID = CD.CONBD_VER_MST_ID
				   AND CB.VER_ID = @P_VER_CD 
					   INNER JOIN
					   TB_CM_LEVEL_MGMT LV
					ON CD.LV_MGMT_ID = LV.ID 
				   AND LV.LV_CD = @P_AUTH_TP
					   LEFT OUTER JOIN
					   TB_CM_COMM_CONFIG AC
					ON CD.APPV_CONST_ID = AC.ID
					   LEFT OUTER JOIN
					   TB_CM_COMM_CONFIG IT
					ON CD.INPUT_TP_ID = IT.ID 
					   LEFT OUTER JOIN
					   TB_CM_COMM_CONFIG CC
					ON CD.CANC_CONST_ID = CC.ID
--				 WHERE CB.PLAN_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_PLAN_TYPE' AND ATTR_01 = 'M') 
			), EMP_INFO
			AS (SELECT DESC_ROLE_CD		AS AUTH_TP
					 , DESC_CD			AS EMP_NO
					,  'D'				AS LV
				FROM TB_DPD_USER_HIER_CLOSURE
					   INNER JOIN 
					   TB_DP_CONTROL_BOARD_VER_DTL VD
					ON VD.CONBD_VER_MST_ID = @P_VER_ID
				   AND DESC_ROLE_ID = VD.LV_MGMT_ID
				WHERE ANCS_CD = @P_EMP_NO
				  AND ANCS_ROLE_CD = @P_AUTH_TP 
				  AND ANCS_CD != DESC_CD
				UNION
				SELECT ANCS_ROLE_CD		AS AUTH_TP
					 , ANCS_CD			AS EMP_NO
					 , 'A'				AS LV
				FROM TB_DPD_USER_HIER_CLOSURE
					   INNER JOIN 
					   TB_DP_CONTROL_BOARD_VER_DTL VD
					ON VD.CONBD_VER_MST_ID = @P_VER_ID
				   AND ANCS_ROLE_ID = VD.LV_MGMT_ID
				WHERE DESC_CD = @P_EMP_NO
				  AND DESC_ROLE_CD = @P_AUTH_TP 
				  AND DESC_CD != ANCS_CD
				UNION
				SELECT @P_AUTH_TP
					 , @P_EMP_NO
					 , 'S'
			), M
			AS (SELECT AUTH_TP
					 , EMP_NO
					 , [STATUS]
					 , [STATUS_DATE]
					 , LV 
					 , CASE WHEN LV  = 'A'  AND [STATUS]  = 'APPROVAL'	  THEN 'N'							-- PR	-- NT
							WHEN LV  = 'D'  AND [STATUS] != 'APPROVAL'	  THEN 'N' 							-- PR
							WHEN LV  = 'S'  AND [STATUS]  = 'APPROVAL'    THEN 'N'							-- PR	-- NT
							WHEN [STATUS] = 'CLOSE'						  THEN 'N'
							ELSE 'Y' END	AS APPV_YN
					 , CASE WHEN LV  = 'A'  AND [STATUS]  IN ('PROCESS', 'APPROVAL') THEN 'N'				-- PR
							WHEN LV  = 'D'  AND [STATUS] != 'APPROVAL'	  THEN 'N'							-- PR
							WHEN LV  = 'S'  AND [STATUS]  = 'APPROVAL'    THEN 'N'							-- PR		
							WHEN [STATUS] = 'CLOSE'						  THEN 'N'
							ELSE 'Y' END	AS INPT_YN
					 , CASE WHEN LV  = 'A'  AND [STATUS]  = 'APPROVAL'	  THEN 'N'							-- NT
							WHEN LV  = 'S'  AND [STATUS] != 'APPROVAL'    THEN 'N'							-- NT
							WHEN [STATUS] = 'CLOSE'						  THEN 'N'
							ELSE 'Y' END	AS CANC_YN	
				 FROM (SELECT EP.AUTH_TP
							 , EP.EMP_NO
							 , ISNULL(PS.[STATUS], 'READY') AS [STATUS]
							 , ROW_NUMBER () OVER (PARTITION BY EP.EMP_NO, EP.AUTH_TP ORDER BY PS.STATUS_DATE DESC) AS RW
							 , PS.STATUS_DATE
							 , EP.LV
						  FROM EMP_INFO  EP
			  				   LEFT OUTER JOIN
			  				   TB_DP_PROCESS_STATUS_LOG PS
		   					ON PS.AUTH_TYPE = EP.AUTH_TP
						   AND PS.OPERATOR_ID = EP.EMP_NO
						   AND VER_CD = @P_VER_CD
					  ) A  
				WHERE RW = 1
				)  
				 SELECT TASK, @P_FINAL_CLOSE_CNT+COUNT(M.[STATUS])		AS CNT
				   FROM M
						RIGHT OUTER JOIN
						STA_CONF C
						UNPIVOT (CONF_CD FOR TASK IN (APPROVAL
													  ,INPUT	
			 			 							  ,CANCEL
												   )) AS UP
				  ON CASE UP.CONF_CD  
							WHEN 'PR'	THEN 'A,D,S'
							WHEN 'NT'	THEN 'A,S'
							-- WHEN NM  THEN NULL
 						END LIKE '%'+LV+'%'
					AND CASE TASK 
							WHEN 'APPROVAL' THEN APPV_YN
							WHEN 'INPUT'	 THEN INPT_YN
							WHEN 'CANCEL' THEN CANC_YN
						 END = 'N'	  
				  WHERE (TASK = @P_TASK_CATEGORY OR @P_TASK_CATEGORY = 'ALL')
				GROUP BY TASK 
				UNION
				SELECT 'CLOSE'
					 , @P_FINAL_CLOSE_CNT+@P_CL_STATUS_CNT
				 WHERE ('CLOSE' = @P_TASK_CATEGORY OR @P_TASK_CATEGORY = 'ALL')	-- 얘는 따로 써줘도 되긴 하겠네
	 

END

go

