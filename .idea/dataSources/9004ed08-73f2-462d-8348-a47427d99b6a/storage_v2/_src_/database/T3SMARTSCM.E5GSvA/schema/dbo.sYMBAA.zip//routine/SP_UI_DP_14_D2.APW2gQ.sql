/*****************************************************************************
Title : SP_DP_13_D2
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP User Mapping (Item)
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2018.03.09 / 김소희 / validation 작업 
- 2020.12.08 / kim sohee / execute making dynamic user data procedure  
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_14_D2]  (
                                       @p_ID                   NVARCHAR(32)     = ''         
									  ,@p_USER_ID              NVARCHAR(30)     = ''     
									  ,@P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'  OUTPUT
									  ,@P_RT_MSG            NVARCHAR(4000) = ''		 OUTPUT									   
					                   ) 
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''
BEGIN TRY

	  -- 프로시저 시작 


	     DELETE FROM [TB_DP_USER_ACCOUNT_MAP]
		 WHERE ID = @p_ID
         ; 

		  EXEC SP_UI_DPD_MAKE_HIER_USER;	-- for MAPPING_SELF_YN
					
	  -- 프로시저 종료 

	   SET @P_RT_ROLLBACK_FLAG = 'true'

	   SET @P_RT_MSG = 'MSG_0002'  -- 삭제 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;



go

