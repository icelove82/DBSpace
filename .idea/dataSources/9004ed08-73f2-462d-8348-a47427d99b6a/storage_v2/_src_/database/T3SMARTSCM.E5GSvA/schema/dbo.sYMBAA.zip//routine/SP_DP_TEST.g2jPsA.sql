-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_DP_TEST] 
AS
BEGIN
	SET NOCOUNT ON;

    WAITFOR DELAY '1:12:0'
	SELECT * from TB_DP_ACCOUNT_MST
END

go

