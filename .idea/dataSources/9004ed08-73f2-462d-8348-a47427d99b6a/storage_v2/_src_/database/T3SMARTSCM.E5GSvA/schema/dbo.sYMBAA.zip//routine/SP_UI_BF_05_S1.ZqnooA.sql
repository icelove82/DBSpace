
CREATE PROCEDURE [dbo].[SP_UI_BF_05_S1]  (
									  @P_ID					CHAR(32)
									, @P_ACCOUNT_CD			NVARCHAR(100)
									, @P_ITEM_CD			NVARCHAR(100)
									, @P_BASE_DATE			DATETIME
									, @P_STATUS				NVARCHAR(50)
									, @P_QTY				decimal(20, 3)
									, @P_QTY_CORRECTION		decimal(20, 3)
									, @P_CORRECTION_COMMENT NVARCHAR(50) --CHAR(32)
									, @P_USER_ID			NVARCHAR(50)
									, @P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'  OUTPUT
									, @P_RT_MSG            NVARCHAR(4000) = ''		OUTPUT
				                   ) 
AS
/*
	History (date / writer / comment)
	-- 2020.02.03 / kim sohee / change data type of correction comment : char(32) => nvarchar(50) for excel import 
*/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @P_ERR_STATUS INT = 0
       ,@P_ERR_MSG NVARCHAR(4000)=''
	   ,@V_ACCOUNT_ID CHAR(32)
	   ,@V_ITEM_MST_ID CHAR(32)
	   ,@V_SO_STATUS_ID CHAR(32)

SELECT @V_ACCOUNT_ID = ID
  FROM TB_DP_ACCOUNT_MST
 WHERE ACCOUNT_CD = @P_ACCOUNT_CD

SELECT @V_ITEM_MST_ID = ID
  FROM TB_CM_ITEM_MST
 WHERE ITEM_CD = @P_ITEM_CD

SELECT @V_SO_STATUS_ID = ID
  FROM TB_CM_COMM_CONFIG 
 WHERE CONF_GRP_CD='DP_SO_STATUS'
   AND CONF_CD = @P_STATUS

BEGIN TRY
-- Excel import
IF(@P_ID IS NULL)
BEGIN
	SELECT @P_ID = ID 
	  FROM TB_CM_ACTUAL_SALES
	 WHERE ITEM_MST_ID = @V_ITEM_MST_ID
	   AND ACCOUNT_ID = @v_ACCOUNT_ID
	   AND BASE_DATE = @P_BASE_DATE
	   AND SO_STATUS_ID = @V_SO_STATUS_ID
END
-- IF(LEN(RTRIM(@P_CORRECTION_COMMENT)) = 0)
-- BEGIN
-- 	SET @P_CORRECTION_COMMENT = NULL
-- END
IF (@P_CORRECTION_COMMENT != 'NN')
BEGIN
	SELECT @P_CORRECTION_COMMENT = ID
	  FROM TB_CM_COMM_CONFIG
	 WHERE CONF_CD = @P_CORRECTION_COMMENT
	   AND CONF_GRP_cD = 'BF_SO_MODIFY_REASON'
END
ELSE 
BEGIN
	SET @P_CORRECTION_COMMENT = NULL
END

IF  (@P_CORRECTION_COMMENT IS NOT NULL AND @P_QTY_CORRECTION IS NULL)  
BEGIN
   SET @P_ERR_MSG = 'Calibration QTY is required' 
   RAISERROR (@P_ERR_MSG,12, 1);  			
END
				UPDATE TB_CM_ACTUAL_SALES
				    SET QTY_CORRECTION			= CASE WHEN ID = @P_ID THEN @P_QTY_CORRECTION ELSE NULL END
					  , CORRECTION_COMMENT_ID 	= @P_CORRECTION_COMMENT
					  , CORRECTION_YN		   	= CASE WHEN @P_QTY_CORRECTION IS NOT NULL THEN 'Y' ELSE 'N' END
					  , MODIFY_BY			   	= @P_USER_ID
					  , MODIFY_DTTM		   		= GETDATE()
				  WHERE 1=1
                    AND ITEM_MST_ID = @V_ITEM_MST_ID
                    AND ACCOUNT_ID = @V_ACCOUNT_ID
                    AND BASE_DATE = @P_BASE_DATE

--				MERGE TB_CM_ACTUAL_SALES TAR
--				USING ( 
--						SELECT
--						  @P_ID						AS 	ID					
--						, @V_ACCOUNT_ID				AS 	ACCOUNT_ID
--						, @V_ITEM_MST_ID			AS 	ITEM_MST_ID
--						, @P_BASE_DATE				AS 	BASE_DATE			
--						, @V_SO_STATUS_ID			AS 	SO_STATUS_ID
--						, @P_QTY				    AS 	QTY			
--						, @P_QTY_CORRECTION		 	AS 	QTY_CORRECTION
--						, @P_CORRECTION_COMMENT     AS 	CORRECTION_COMMENT_ID
--						, @P_USER_ID				AS  USER_ID
--					  ) SRC
--				ON	  (TAR.ID			= SRC.ID	
--					  )
--				WHEN MATCHED THEN
--					 UPDATE 
--					   SET   TAR.QTY_CORRECTION		   = SRC.QTY_CORRECTION
--							,TAR.CORRECTION_COMMENT_ID = SRC.CORRECTION_COMMENT_ID
--							,TAR.CORRECTION_YN		   = 'Y'
--							,TAR.MODIFY_BY			   = SRC.USER_ID
--							,TAR.MODIFY_DTTM		   = GETDATE()    
--				WHEN NOT MATCHED THEN 
--					 INSERT (
--							  ID					
--							, ACCOUNT_ID	
--							, ITEM_MST_ID		
--							, BASE_DATE			
--							, SO_STATUS_ID		
--							, QTY				
--							, QTY_CORRECTION		
--							, CORRECTION_COMMENT_ID
--							, CREATE_BY			
--							, CREATE_DTTM
--							) 
--					 VALUES (
--							 (SELECT REPLACE(NEWID(),'-','') )
--							,SRC.ACCOUNT_ID	
--							,SRC.ITEM_MST_ID		
--							,SRC.BASE_DATE			
--							,SRC.SO_STATUS_ID		
--							,SRC.QTY				
--							,SRC.QTY_CORRECTION	
--							,SRC.CORRECTION_COMMENT_ID
--							,SRC.USER_ID			
--							,GETDATE()		  
-- 							) 
--							
--						;    

         
 	


	   SET @P_RT_ROLLBACK_FLAG = 'true'

	   SET @P_RT_MSG = 'MSG_0001'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR

END CATCH;

go

