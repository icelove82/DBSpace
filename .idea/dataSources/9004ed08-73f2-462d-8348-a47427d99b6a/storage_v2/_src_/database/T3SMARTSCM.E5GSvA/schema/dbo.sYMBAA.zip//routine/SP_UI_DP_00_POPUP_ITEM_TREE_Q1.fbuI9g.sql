/*****************************************************************************
Title : [SP_UI_DP_00_POPUP_ITEM_TREE_Q1]
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP ITEM TREE POPUP의 그리드 조회 프로시저 
  
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2019.07.25 / 김소희 / DPD 테이블 없이 조회하게 수정 
- 2019.07.26 / 김소희 / 사용자에 매핑된 item만 조회하는 기능도 추가
- 2020.03.12 / 김소희 / EMP_NO => USER_ID 
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 / hanguls / TB_DP_EMPLOYEE => TB_AD_USER
- 2020.11.10 / Kim sohee / data type of ITEM_CD NVARCHAR(100)
- 2021.12.13 / Kim sohee / DPD 테이블로 데이터 찾는 방식으로 변경 (속도 개선)
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_00_POPUP_ITEM_TREE_Q1]  (
											   @p_EMP_NO	   NVARCHAR(100) = NULL
											  ,@p_AUTH_TP_ID   CHAR(32)		 = NULL
											  ,@p_ITEM_CD      NVARCHAR(100)  = NULL
                                              ,@p_ITEM_NM      NVARCHAR(240) = NULL
											  ,@p_ITEM_LV	   NVARCHAR(300) = NULL
                                              ,@p_LV_TP_CD       NVARCHAR(50)	= NULL
            								  ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON 

	DECLARE @P_EMP_ID	CHAR(32) = NULL;
BEGIN
		SELECT @P_EMP_ID = ID 
		  FROM TB_AD_USER 
		 WHERE USERNAME = @p_EMP_NO
		 ;

-- Top of Item level, @P_ITEM_LV converts to NULL
SET @p_ITEM_LV = NULLIF(@p_ITEM_LV, '');
SET @P_ITEM_CD = ISNULL(@p_ITEM_CD, '');
SET @P_ITEM_NM = ISNULL(@p_ITEM_NM, '');
SET @p_LV_TP_CD = COALESCE(@p_LV_TP_CD, 'I');

IF  EXISTS (
			SELECT ITEM_LV_CD 
			  FROM TB_CM_ITEM_LEVEL_MGMT IL
				   INNER JOIN 
				   TB_CM_LEVEL_MGMT LV 
				ON IL.LV_MGMT_ID = LV.ID 
				   INNER JOIN
				   TB_CM_COMM_CONFIG CC
				ON LV.LV_TP_ID = CC.ID
			   AND CC.CONF_CD = 'I'
			 WHERE IL.PARENT_ITEM_LV_ID IS NULL		
			   AND ITEM_LV_CD = @p_ITEM_LV
		)
BEGIN
	SET @P_ITEM_LV = NULL;
END

IF NOT EXISTS  (	
--				SELECT *
--				  FROM TB_CM_LEVEL_MGMT
--				 WHERE 1=1
--				   AND ID = @P_AUTH_TP_ID 
--				   AND LEAF_YN = 'Y'
--				   AND COALESCE(DEL_YN,'N') = 'N'
--				   AND ACTV_YN = 'Y'
					SELECT COUNT(EMP_ID) 
				     FROM TB_DP_USER_ITEM_MAP
					WHERE EMP_ID = @p_EMP_ID
					  AND AUTH_TP_ID = @p_AUTH_TP_ID
					  AND ACTV_YN = 'Y'
					  HAVING COUNT(1) != 0
					UNION
				    SELECT COUNT(EMP_ID)
				      FROM TB_DP_USER_ITEM_ACCOUNT_MAP
				     WHERE EMP_ID = @p_EMP_ID
					   AND AUTH_TP_ID = @p_AUTH_TP_ID
					   AND ACTV_YN = 'Y'
					   HAVING COUNT(1) != 0
				) 
	BEGIN
		SET @P_EMP_ID = NULL;
	END
IF(@P_EMP_ID IS NULL OR @p_AUTH_TP_ID IS NULL)
	BEGIN	
	-- Case : mapping data is none, get all master data
		WITH ITEM_HIER
		  AS (  SELECT DESCENDANT_ID AS ID 
				  FROM TB_DPD_ITEM_HIER_CLOSURE IH	WITH (NOLOCK)
				 WHERE LEAF_YN = 'Y'
				   AND ANCESTER_CD = @p_ITEM_LV
				   AND USE_YN = 'Y'
				   AND LV_TP_CD = @p_LV_TP_CD
				UNION
				SELECT ''
				 WHERE @p_ITEM_LV IS NULL 
			 )
			SELECT A.ID
				 , A.ITEM_CD
				 , A.ITEM_NM
				 , A.EOS AS END_DATE_SALES
				 , A.RTS AS STRT_DATE_SALES
				 , C.UOM_CD
				 , C.UOM_NM
				 , A.DESCRIP
				 , A.PARENT_ITEM_LV_ID
				 , IL.ITEM_LV_CD AS PARENT_ITEM_LV_CD
				 , IL.ITEM_LV_NM AS PARENT_ITEM_LV_NM
			  FROM TB_CM_ITEM_MST A	WITH (NOLOCK)		  
				   INNER JOIN 
				   ITEM_HIER IH
				ON CASE WHEN IH.ID = '' THEN '' ELSE A.ID END = IH.ID 
				   INNER JOIN
				   TB_CM_ITEM_LEVEL_MGMT IL
				ON A.PARENT_ITEM_LV_ID = IL.ID 
				   LEFT OUTER JOIN 
				   TB_CM_UOM C 
				ON A.UOM_ID = C.ID AND C.ACTV_YN = 'Y'
			 WHERE 1=1	    
				AND COALESCE(A.DEL_YN,'N')='N'
				AND A.DP_PLAN_YN = 'Y'
								AND  ('Y' = CASE WHEN @P_ITEM_CD = '' THEN 'Y'
								ELSE ( CASE WHEN UPPER(A.ITEM_CD)  LIKE '%' + UPPER(RTRIM(@P_ITEM_CD)) + '%'	THEN 'Y' ELSE 'N' END) 
							END)
 				AND ('Y' = CASE WHEN @P_ITEM_NM = '' THEN 'Y'
								ELSE ( CASE WHEN UPPER(A.ITEM_NM)  LIKE '%' + UPPER(RTRIM(@P_ITEM_NM)) + '%'	THEN 'Y' ELSE 'N' END) 
							END)
			  ORDER BY IL.SEQ, IL.ITEM_LV_CD, A.ITEM_CD
			  ;
	END
ELSE 
	BEGIN			
			WITH DP_LEVEL 
			  AS (
					SELECT LV.ID 
						 , LV.LEAF_YN
					  FROM TB_CM_LEVEL_MGMT LV
					       INNER JOIN 
						   TB_CM_COMM_CONFIG CC
						ON LV.LV_TP_ID = CC.ID
					 WHERE CC.CONF_CD = 'I'
					   AND COALESCE(LV.ACCOUNT_LV_YN,'N') = 'N'
					   AND COALESCE(LV.SALES_LV_YN  ,'N')= 'N'
					   AND LV.ACTV_YN = 'Y'
					   AND COALESCE(LV.DEL_YN,'N') = 'N'
				 ),USER_MAP_ITEM_LV
			  AS (  SELECT DISTINCT ITEM_LV_ID AS ID
					  FROM TB_DP_USER_ITEM_MAP M	    
						   INNER JOIN 
						   DP_LEVEL L
						ON M.LV_MGMT_ID = L.ID 
					   AND L.LEAF_YN = 'N'
					 WHERE 1=1 
					   AND AUTH_TP_ID = @P_AUTH_TP_ID
					   AND EMP_ID = @P_EMP_ID
					   AND ACTV_YN = 'Y'		 
			), USER_MAP_ITEM
			AS (
				SELECT DISTINCT ITEM_MST_ID AS ITEM_ID 
				  FROM TB_DP_USER_ITEM_MAP M
				       INNER JOIN 
					   DP_LEVEL L
					ON M.LV_MGMT_ID = L.ID 
				   AND L.LEAF_YN = 'Y'
				 WHERE EMP_ID = @P_EMP_ID
				   AND M.AUTH_TP_ID = @P_AUTH_TP_ID
				   AND M.ACTV_YN = 'Y'
				UNION
				SELECT DISTINCT ITEM_MST_ID
				  FROM TB_DP_USER_ITEM_ACCOUNT_MAP 
				 WHERE EMP_ID = @P_EMP_ID
				   AND AUTH_TP_ID = @P_AUTH_TP_ID 
				   AND ACTV_YN = 'Y'
				UNION
				SELECT IH.DESCENDANT_ID
				  FROM USER_MAP_ITEM_LV IM
					   INNER JOIN 
					   TB_DPD_ITEM_HIER_CLOSURE IH 	WITH (NOLOCK)
					ON IM.ID = IH.ANCESTER_ID
				   AND USE_YN = 'Y' 
				   AND IH.LEAF_YN = 'Y'
			), ITEM_HIER
			  AS (  SELECT DESCENDANT_ID AS ID 
					  FROM TB_DPD_ITEM_HIER_CLOSURE IH	WITH (NOLOCK)
					 WHERE LEAF_YN = 'Y'
					   AND ANCESTER_CD = @p_ITEM_LV
					   AND USE_YN = 'Y'
					   AND LV_TP_CD = @p_LV_TP_CD
					UNION
					SELECT ''
					 WHERE @p_ITEM_LV IS NULL 
				 )
	 				SELECT IM.ID
						 , IM.ITEM_CD
						 , IM.ITEM_NM
						 , IM.EOS	 AS END_DATE_SALES
						 , IM.RTS	 AS STRT_DATE_SALES
						 , UM.UOM_CD
						 , UM.UOM_NM
						 , IM.DESCRIP
						 , IM.PARENT_ITEM_LV_ID
						 , IL.ITEM_LV_CD AS PARENT_ITEM_LV_CD
						 , IL.ITEM_LV_NM AS PARENT_ITEM_LV_NM
					  FROM USER_MAP_ITEM FI
						   INNER JOIN
						    ITEM_HIER IH
					    ON CASE WHEN IH.ID = '' THEN '' ELSE FI.ITEM_ID END = IH.ID 
						   INNER JOIN
						   TB_CM_ITEM_MST IM WITH (NOLOCK)
						ON IM.ID = FI.ITEM_ID
						   INNER JOIN
						   TB_CM_ITEM_LEVEL_MGMT IL
						ON IL.ID = IM.PARENT_ITEM_LV_ID
						   LEFT OUTER JOIN
						   TB_CM_UOM UM
						ON IM.UOM_ID = UM.ID
					 WHERE ('Y' = CASE WHEN @P_ITEM_CD = '' THEN 'Y'
										ELSE ( CASE WHEN UPPER(IM.ITEM_CD)  LIKE '%' + UPPER(RTRIM(@P_ITEM_CD)) + '%'	THEN 'Y' ELSE 'N' END) 
									END)
	 					AND ('Y' = CASE WHEN @P_ITEM_NM = '' THEN 'Y'
										ELSE ( CASE WHEN UPPER(IM.ITEM_NM)  LIKE '%' + UPPER(RTRIM(@P_ITEM_NM)) + '%'	THEN 'Y' ELSE 'N' END) 
									END)
				 ORDER BY IL.SEQ, IL.ITEM_LV_CD, IM.ITEM_CD		
			
	END
END






go

