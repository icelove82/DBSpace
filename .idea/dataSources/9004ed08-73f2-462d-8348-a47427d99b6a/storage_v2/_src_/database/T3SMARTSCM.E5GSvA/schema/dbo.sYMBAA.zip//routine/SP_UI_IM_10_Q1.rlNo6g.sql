CREATE PROCEDURE [dbo].[SP_UI_IM_10_Q1] (
	@P_LOCAT_TP		NVARCHAR(100) = '',
	@P_LOCAT_LV		NVARCHAR(100) = '',
	@P_LOCAT_CD		NVARCHAR(100) = '',
	@P_LOCAT_NM		NVARCHAR(100) = '',
	@P_ITEM_CD		NVARCHAR(100) = '',
	@P_ITEM_NM		NVARCHAR(100) = '',
	@P_ITEM_TP		NVARCHAR(100) = ''
)
AS
/*****************************************************************************
Title : SP_UI_IM_10_Q1
최초 작성자 : 한영석
최초 생성일 : 2017.07.24
 
설명 
 -  
History (수정일자 / 수정자 / 수정내용)
- 2017.07.24 / 한영석 / 최초 작성
 
*****************************************************************************/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

SELECT A.COMN_CD_NM				AS LOCAT_TP_NM 
       ,LOCAT_LV 
       ,Rtrim(C.LOCAT_CD)		AS LOCAT_CD 
       ,C.LOCAT_NM 
       ,G.ITEM_CD
	   ,G.ITEM_NM
       ,G.DESCRIP
       ,H.CONVN_NM				AS ITEM_TP
	   ,I.UOM_NM 
       ,J.COMN_CD_NM  CURCY_NM
	   ,F.ID					AS ID 
	   ,F.SUPPLY_LEADTIME_AVG 
	   ,F.SUPPLY_LEADTIME_DEVIT 
	   ,F.SUPPLY_LEADTIME_VARAN 
	   ,F.ACTV_YN 
	   ,F.CREATE_BY 
	   ,F.CREATE_DTTM 
	   ,F.MODIFY_BY 
	   ,F.MODIFY_DTTM 
  FROM TB_AD_COMN_CODE A
       INNER JOIN 
       TB_CM_LOC_MST B
	ON (A.ID = B.LOCAT_TP_ID)
       INNER JOIN 	   
	   TB_CM_LOC_DTL C
	ON (B.ID = C.LOCAT_MST_ID)
       INNER JOIN 
	   TB_CM_LOC_MGMT D
	ON (C.ID = D.LOCAT_ID)
       INNER JOIN 
	   TB_CM_SITE_ITEM E
	ON (D.ID = E.LOCAT_MGMT_ID)
       INNER JOIN 
	   TB_IM_SPPLY_VARAN_ANLYS_MST F
	ON (E.ID = F.LOCAT_ITEM_ID)
	   INNER JOIN 
	   TB_CM_ITEM_MST G
	ON (E.ITEM_MST_ID = G.ID)
	   INNER JOIN 
	   TB_CM_ITEM_TYPE H
	ON (G.ITEM_TP_ID = H.ID)
	   LEFT OUTER JOIN 
	   TB_CM_UOM I
	ON (E.UOM_ID = I.ID)
	   LEFT OUTER JOIN 
	   TB_AD_COMN_CODE J
	ON (E.CURCY_CD_ID = J.ID)
WHERE 1=1
   AND UPPER(A.COMN_CD_NM) LIKE '%'+UPPER(@P_LOCAT_TP)+'%'
   AND B.LOCAT_LV LIKE '%'+@P_LOCAT_LV+'%'
   AND UPPER(C.LOCAT_CD) LIKE '%'+UPPER(@P_LOCAT_CD)+'%'
   AND UPPER(C.LOCAT_NM) LIKE '%'+UPPER(@P_LOCAT_NM)+'%'
   AND UPPER(G.ITEM_CD) LIKE '%'+UPPER(@P_ITEM_CD)+'%'
   AND UPPER(G.ITEM_NM) LIKE '%'+UPPER(@P_ITEM_NM)+'%'
   AND UPPER(H.CONVN_NM) LIKE '%'+UPPER(@P_ITEM_TP)+'%'

go

