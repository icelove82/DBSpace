CREATE PROCEDURE [dbo].[SP_UI_IM_26_Q3] (
 	 @P_ID		NVARCHAR (32)
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN
	SELECT 
            ID, 
            ITEM_INV_POLICY_ID, 
            END_DTTM, 
            STRT_DTTM, 
            SFST_DMND_RATE, 
            SFST_PRPSAL_VAL, 
            SFST_VAL, 
            OPERT_INV_DMND_RATE, 
            OPERT_INV_PRPSAL_VAL, 
            OPERT_INV_VAL, 
            ROP_DMND_RATE, 
            ROP_RIGHT_RATE_TARGET, 
            ROP_PRPSAL_VAL, 
            ROP_VAL, 
            EOQ_DMND_RATE, 
            EOQ_RIGHT_RATE_TARGET, 
            EOQ_PRPSAL_VAL, 
            EOQ_VAL, 
            TARGET_INV_PRPSAL_VAL, 
            TARGET_INV_VAL, 
            CREATE_BY, 
            CREATE_DTTM, 
            MODIFY_BY, 
            MODIFY_DTTM 
	FROM   TB_IM_INV_POLICY_PRIOD_INFO A
	WHERE  A.ITEM_INV_POLICY_ID = @P_ID
END

go

