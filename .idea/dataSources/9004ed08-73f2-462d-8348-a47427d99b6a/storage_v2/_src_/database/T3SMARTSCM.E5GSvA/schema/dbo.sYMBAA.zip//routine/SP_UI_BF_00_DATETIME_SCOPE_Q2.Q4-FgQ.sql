
CREATE PROCEDURE [dbo].[SP_UI_BF_00_DATETIME_SCOPE_Q2]
(
	@P_VER_ID NVARCHAR(50) = NULL
)
AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
/*
	Load a Scope of date by version 

	Description 
	-- 주로 보고서 화면에서 사용할 의도
	사용중인 화면 ID / 이름
	-- UI_BF_50 / BF Result

	HISTORY (date / writer / comment)
	-- 2020.02.03 / kimsohee / Base Table : TB_BF_RT => TB_BF_CONTROL_BOARD_VER_DTL
	-- 2020.02.28 / kim sohee / add a comment to change week rule : DP_WK (53 week per a year) 
*/
BEGIN
	DECLARE @P_FROM_DATE	DATE 
		  , @P_END_DATE		DATE 
		  , @V_BUKT			NVARCHAR(2)
	
	SELECT		@P_FROM_DATE= MIN(BASE_DATE) ,
				@P_END_DATE	= MAX(BASE_DATE)   
--				@V_BUKT     = MAX(TARGET_BUKT_CD)
	  FROM		TB_BF_RT
	 WHERE		VER_CD = @P_VER_ID
--	   AND		ENGINE_TP_CD IS NOT NULL
	;
-- IF (@V_BUKT = 'W')
-- BEGIN
-- 	SELECT --@P_FROM_dATE    = MIN(STRT_DATE),
-- 		   @P_END_DATE	   = MAX(END_DATE)
-- 	  FROM (
-- 			SELECT YYYY
-- 				 , DP_WK
-- 				 , MIN(DAT) AS STRT_DATE
-- 				 , MAX(DAT) AS END_DATE
-- 			  FROM TB_CM_CALENDAR C
-- 			 WHERE DAT BETWEEN @P_FROM_DATE AND @P_END_DATE
-- 		  GROUP BY YYYY, DP_WK
-- 		  HAVING COUNT(DP_WK) >= 7
-- 		  ) A
-- END
-- ; 
  SELECT @P_FROM_DATE		AS FROM_DATE
		,@P_END_DATE		AS TO_DATE	


END

go

