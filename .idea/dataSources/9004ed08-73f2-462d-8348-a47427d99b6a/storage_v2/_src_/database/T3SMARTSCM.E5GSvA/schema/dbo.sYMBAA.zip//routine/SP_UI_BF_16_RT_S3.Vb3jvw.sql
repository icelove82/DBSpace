CREATE PROCEDURE [dbo].[SP_UI_BF_16_RT_S3] 
(	 @P_VER_CD					NVARCHAR(50)
	,@P_USER_ID					NVARCHAR(100)
	,@P_SELECT_CRITERIA			NVARCHAR(30)
	,@P_BUKT_CD					NVARCHAR(30) = 'PW'
	,@P_PROCESS_NO				INT
	,@P_RT_ROLLBACK_FLAG		NVARCHAR(10)   = 'true'			OUTPUT
	,@P_RT_MSG					NVARCHAR(4000) = ''				OUTPUT		
)
AS
/*************************************************************************************************************
	Make Final BF Result
		  Generate data with the most accurate prediction results
	History (Date / Writer / Comment)
		- 2020.03.18 / Kim sohee / add a function of Partial week distribution
		- 2020.11.03 / Kim sohee / partition by engine type code 
		- 2021.07.28 / suchang.park / Close PROCESS_NO 변경 (1000 -> 1000000)
        - 2023.03.08 / yeunkyung nam / DP Dimension Data - 수요예측 선택 모델, 정확도 update

	To do
		- 소수점 처리 (설정으로)
*************************************************************************************************************/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
BEGIN TRY
/*************************************************************************************************************
	-- Get Config Data
*************************************************************************************************************/
	DECLARE @P_ERR_STATUS INT = 0
		   ,@P_ERR_MSG NVARCHAR(4000)=''

	DECLARE @P_TARGET_FROM_DATE DATE
		  , @P_TARGET_TO_DATE	DATE
		  , @P_STD_WK			NVARCHAR(30)
	;
	--	SELECT @P_TARGET_FROM_DATE  = MIN(TARGET_FROM_DATE) 
	--		 , @P_TARGET_TO_DATE	= MAX(TARGET_TO_DATE)   
	--	  FROM TB_BF_CONTROL_BOARD_VER_DTL
	--	 WHERE ENGINE_TP_CD IS NOT NULL
IF EXISTS ( SELECT *
			  FROM TB_BF_CONTROL_BOARD_VER_DTL
			 WHERE VER_CD = @P_VER_CD
			   AND PROCESS_NO < @P_PROCESS_NO
			   AND [STATUS] = 'Ready'
			   AND DESCRIP NOT LIKE '%Learning'
		 )
	BEGIN
	   SET @P_ERR_MSG = 'Please complete the previous process first.'
	   RAISERROR (@P_ERR_MSG,12, 1);  		
	END
IF EXISTS ( SELECT *
			  FROM TB_BF_CONTROL_BOARD_VER_DTL
			 WHERE VER_CD = @P_VER_CD
			   AND PROCESS_NO = 1000000
			   AND [STATUS] = 'Completed'
		 )
	BEGIN
	   SET @P_ERR_MSG = 'This version is aleady closed.'
	   RAISERROR (@P_ERR_MSG,12, 1);  		
	END	
		SELECT @P_TARGET_FROM_DATE  = MIN(BASE_DATE)
			  ,@P_TARGET_TO_DATE	= MAX(BASE_DATE)   
		  FROM TB_BF_RT
		 WHERE VER_cD = @P_VER_CD
		 ;
		
IF (@P_BUKT_CD IS NULL OR @P_BUKT_CD NOT IN ('M', 'PW'))
	BEGIN
		SELECT @P_BUKT_CD = m.POLICY_VAL from TB_DP_PLAN_POLICY m
			INNER JOIN TB_CM_COMM_CONFIG c ON c.CONF_GRP_CD = 'DP_PLAN_TYPE' AND CONF_CD = 'DP_PLAN_MONTHLY' and m.PLAN_TP_ID =  c.ID
			INNER JOIN TB_CM_COMM_CONFIG c2 ON c2.id = POLICY_ID AND c2.CONF_CD = 'B'
	END

	
	-- DOW 바뀔 경우 대비
	DECLARE @P_DOW_DEPT INT =0;
	 --SELECT @P_DOW_DEPT = DATEPART(DW, MIN(DAT)) 
	 -- FROM TB_CM_CALENDAR
	 --WHERE DP_WK = (SELECT DP_WK FROM TB_CM_CALENDAR WHERE DAT = @P_TARGET_FROM_DATE)
	 --;
	 --SELECT @P_DOW_DEPT = @P_DOW_DEPT - DATEPART(DW, @P_TARGET_FROM_DATE) 
	 --;
	 --SET @P_TARGET_FROM_DATE = DATEADD(DAY, @P_DOW_DEPT, @P_TARGET_FROM_DATE )
	 --SET @P_TARGET_TO_DATE =   DATEADD(DAY, @P_DOW_DEPT, @P_TARGET_TO_DATE );	
/*************************************************************************************************************
	-- Change Version Data
*************************************************************************************************************/
	UPDATE TB_BF_CONTROL_BOARD_VER_DTL
	   SET RUN_STRT_DATE = GETDATE()
	 WHERE VER_CD = @P_VER_CD
	   AND PROCESS_NO = @P_PROCESS_NO 
/*************************************************************************************************************
	-- Delete same version Data
*************************************************************************************************************/
	DELETE FROM TB_BF_RT_FINAL
	  WHERE VER_CD = @P_VER_CD
	  ;
/*************************************************************************************************************
	-- Get Forecast , Accuracy ...
*************************************************************************************************************/	
	WITH AC
	AS (
		SELECT ITEM_CD
			,  ACCOUNT_CD
			,  ENGINE_TP_CD 
			,  ROW_NUMBER () OVER (PARTITION BY ITEM_CD, ACCOUNT_CD ORDER BY SELECT_SEQ ASC) AS SELECT_SEQ
		  FROM TB_BF_RT_ACCRCY
		 WHERE VER_CD = @P_VER_CD
	),  CA
	AS (
	    SELECT MIN(DAT)				AS FROM_DATE
			 , MAX(DAT)				AS TO_DATE
			 , MIN(YYYYMM)			AS YYYYMM
			 , COUNT(DAT)			AS DAT_CNT
		  FROM TB_CM_CALENDAR	
	     WHERE DAT BETWEEN @P_TARGET_FROM_DATE AND @P_TARGET_TO_DATE 
	  GROUP BY YYYY
			 , CASE WHEN @P_BUKT_CD IN ('M', 'PW') THEN MM    ELSE 1 END
			 , CASE WHEN @P_BUKT_CD IN ('PW', 'W') THEN DP_WK ELSE 1 END 
	), RT
	AS (	SELECT ITEM_CD
				 , ACCOUNT_CD
				 , DATEADD(DAY, @P_DOW_DEPT, BASE_DATE)	AS FROM_DATE
				 , ISNULL(DATEADD(DAY, -1, LEAD(DATEADD(DAY, @P_DOW_DEPT, BASE_DATE),1) OVER (PARTITION BY ENGINE_TP_CD, ITEM_CD, ACCOUNT_CD ORDER BY BASE_DATE ASC)), @P_TARGET_TO_DATE)	AS TO_DATE
				 , case when ENGINE_TP_CD like 'ZAUTO%' then 'ZAUTO' else ENGINE_TP_CD end ENGINE_TP_CD  
				 , QTY 
			  FROM TB_BF_RT 
			 WHERE VER_CD = @P_VER_CD
	)
/*************************************************************************************************************
	-- Set Result
*************************************************************************************************************/
	INSERT INTO TB_BF_RT_FINAL
	(	 ID					
		,VER_CD				
		,ITEM_CD			
		,ACCOUNT_CD			
		,BASE_DATE			
		,BEST_ENGINE_TP_CD	
		,QTY				
		,CREATE_BY			
		,CREATE_DTTM		
		,MODIFY_BY			
		,MODIFY_DTTM			
	)
	SELECT REPLACE(NEWID(),'-','') AS ID					
		 , @P_VER_CD			   AS VER_CD				
		 , ITEM_CD				   AS ITEM_CD			
		 , ACCOUNT_CD			   AS ACCOUNT_CD			
		 , BASE_DATE			   AS BASE_DATE			
		 , ENGINE_TP_CD			   AS BEST_ENGINE_TP_CD	
		 , QTY 					   AS QTY				
		 , @P_USER_ID			   AS CREATE_BY			
		 , GETDATE()			   AS CREATE_DTTM		
		 , NULL					   AS MODIFY_BY			
		 , NULL 				   AS MODIFY_DTTM			
	  FROM (
		SELECT RT.ITEM_CD
			 , RT.ACCOUNT_CD
			 , CA.FROM_DATE		 BASE_DATE 
			 , RT.ENGINE_TP_CD
--			 , RT.QTY															  AS BF_QTY_ORG
			 , ROUND(RT.QTY * CA.DAT_CNT / (DATEDIFF(DAY, RT.FROM_DATE, RT.TO_DATE)+1),0)  AS QTY
			 , DENSE_RANK() OVER (PARTITION BY RT.ITEM_CD, RT.ACCOUNT_CD, RT.FROM_DATE ORDER BY AC.SELECT_SEQ)	AS RW
		  FROM RT
			   INNER JOIN
			   AC
			ON RT.ITEM_CD = AC.ITEM_CD
		   AND RT.ACCOUNT_CD = AC.ACCOUNT_CD
		   AND RT.ENGINE_TP_CD = AC.ENGINE_TP_CD
			   INNER JOIN
			   CA
			ON CA.FROM_DATE BETWEEN RT.FROM_DATE AND RT.TO_DATE
		) M
	WHERE RW = 1
--	ORDER BY ITEM_CD, ACCOUNT_CD, BASE_DATE, ENGINE_TP_CD, QTY 

/*************************************************************************************************************
	-- DP Measure Data - 수요예측 결과 Final
*************************************************************************************************************/
  IF EXISTS (   SELECT  COLUMN_NAME
				  FROM INFORMATION_SCHEMA.COLUMNS
				 WHERE TABLE_NAME = 'TB_DP_MEASURE_DATA' 
				   AND COLUMN_NAME = 'BF_MEAS_QTY'
				   AND TABLE_CATALOG =  DB_NAME()  
			)
	BEGIN
		MERGE INTO TB_DP_MEASURE_DATA TGT
		USING (
				SELECT IT.ID		ITEM_ID
					  ,AC.ID		ACCT_ID
					  ,BF.BASE_DATE
					  ,BF.QTY
				 FROM TB_BF_RT_FINAL BF 
					  INNER JOIN
					  TB_CM_ITEM_MST IT 
				   ON BF.ITEM_CD = IT.ITEM_CD
				   AND IT.DP_PLAN_YN = 'Y'
				   AND ISNULL(IT.DEL_YN, 'N') = 'N'
					  INNER JOIN 
					  TB_DP_ACCOUNT_MST AC
				   ON BF.ACCOUNT_CD = AC.ACCOUNT_CD
				  AND AC.ACTV_YN = 'Y'
				  AND ISNULL(AC.DEL_YN, 'N') = 'N'	  
				WHERE VER_CD = @P_VER_CD  				
			  ) SRC 
		  ON TGT.ITEM_MST_ID = SRC.ITEM_ID
		 AND TGT.ACCOUNT_ID = SRC.ACCT_ID
		 AND TGT.BASE_dATE = SRC.BASE_DATE
		 WHEN MATCHED THEN
		 UPDATE SET TGT.BF_MEAS_QTY = SRC.QTY 
			      , TGT.MODIFY_BY = @P_USER_ID
				  , TGT.MODIFY_DTTM = GETDATE()
		 WHEN NOT MATCHED THEN
		 INSERT (ID, ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, BF_MEAS_QTY, CREATE_BY, CREATE_DTTM)
		 VALUES ( REPLACE(NEWID(),'-','')
				 ,SRC.ITEM_ID
		 		 ,SRC.ACCT_ID
				 ,SRC.BASE_DATE
				 ,SRC.QTY 
				 ,@P_USER_ID
				 ,GETDATE()
				)
				;
	END

/*************************************************************************************************************
	-- DP Dimension Data - 수요예측 선택 모델, 정확도
*************************************************************************************************************/
  IF EXISTS (   SELECT  COLUMN_NAME
				  FROM INFORMATION_SCHEMA.COLUMNS
				 WHERE TABLE_NAME = 'TB_DP_DIMENSION_DATA' 
				   AND COLUMN_NAME = 'BF_MODEL'
				   AND TABLE_CATALOG =  DB_NAME()  
			)
	BEGIN
		MERGE INTO TB_DP_DIMENSION_DATA TGT
		USING	(
                SELECT ACC.ITEM_CD
                     , ACC.ACCOUNT_CD
                     , ACC.ENGINE_TP_CD AS BF_MODEL
                     , (100-ACC.WAPE) AS BF_ACCURACY
                     , I.ID AS ITEM_MST_ID
                     , A.ID AS ACCOUNT_ID
                  FROM TB_BF_RT_ACCRCY ACC WITH(NOLOCK)
                       INNER JOIN TB_CM_ITEM_MST I WITH(NOLOCK)
                    ON ACC.ITEM_CD = I.ITEM_CD
				   AND I.DP_PLAN_YN = 'Y'
				   AND ISNULL(I.DEL_YN, 'N') = 'N'
                       INNER JOIN TB_DP_ACCOUNT_MST A WITH(NOLOCK)
                    ON ACC.ACCOUNT_CD = A.ACCOUNT_CD
				   AND A.ACTV_YN = 'Y'
				   AND ISNULL(A.DEL_YN, 'N') = 'N'	
                 WHERE 1=1
                   AND ACC.VER_CD = @P_VER_CD
                   AND ACC.SELECT_SEQ = 1
				) SRC
		ON		(TGT.ITEM_MST_ID = SRC.ITEM_MST_ID AND TGT.ACCOUNT_ID = SRC.ACCOUNT_ID)
		WHEN	MATCHED THEN
		UPDATE
		SET		TGT.BF_MODEL	= SRC.BF_MODEL
			,	TGT.BF_ACCURACY = SRC.BF_ACCURACY
			,	TGT.CREATE_DTTM = GETDATE()
			,	TGT.CREATE_BY = @P_USER_ID
		WHEN	NOT MATCHED THEN
		INSERT (ID,ITEM_MST_ID,ACCOUNT_ID,BF_ACCURACY,BF_MODEL,CREATE_DTTM,CREATE_BY)
		VALUES (REPLACE(NEWID(),'-',''),SRC.ITEM_MST_ID,SRC.ACCOUNT_ID,SRC.BF_ACCURACY,SRC.BF_MODEL,GETDATE(),@P_USER_ID)
		;
	END

/*************************************************************************************************************
	-- Change Version Data
*************************************************************************************************************/
	UPDATE TB_BF_CONTROL_BOARD_VER_DTL
	   SET [STATUS] = 'Completed'
		 , RUN_END_DATE = GETDATE()
	 WHERE VER_CD = @P_VER_CD
	   AND PROCESS_NO = @P_PROCESS_NO 

/*************************************************************************************************************
	-- Result Message
*************************************************************************************************************/
	    SET @P_RT_MSG = 'MSG_0001'
	    SET @P_RT_ROLLBACK_FLAG = 'true'
END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END
	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR
END CATCH



go

