/*****************************************************************************
Title : SP_DP_12_Q1
최초 작성자 : 민희영
최초 생성일 : 2017.06.20
 
설명 
 - DP Sales Hierarchy Management
 
History (수정일자 / 수정자 / 수정내용)
- 2017.06.20 / 민희영 / 최초 작성
	- 2020.11.10 / Kim sohee / data type of CODE NVARCHAR(100) 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_12_Q1] (@p_SALES_LV    NVARCHAR(100) = ''
                                      , @p_SRP_LV_YN   NVARCHAR(1) = ''
								   ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN

SELECT SL.ID
      ,SL.SALES_LV_CD
      ,SL.SALES_LV_NM
      ,SL.LV_MGMT_ID
      ,SL.PARENT_SALES_LV_ID
	  ,SL2.SALES_LV_CD  AS PARENT_SALES_LV_CD
	  ,SL2.SALES_LV_NM  AS PARENT_SALES_LV_NM  
	  ,SL.CURCY_CD_ID
      ,SL.SEQ
      ,SL.ACTV_YN
      ,SL.CREATE_BY
      ,SL.CREATE_DTTM
      ,SL.MODIFY_BY
      ,SL.MODIFY_DTTM
  FROM TB_CM_CONFIGURATION A
	 , TB_CM_COMM_CONFIG B
	 , TB_CM_LEVEL_MGMT  LM
	 , TB_DP_SALES_LEVEL_MGMT SL 
	     LEFT OUTER JOIN  TB_DP_SALES_LEVEL_MGMT SL2 ON  SL.PARENT_SALES_LV_ID = SL2.ID AND ISNULL(SL2.DEL_YN,'N') = 'N' AND SL2.ACTV_YN = 'Y'
  WHERE A.MODULE_CD = 'DP'
	AND A.ID = B.CONF_ID
	AND B.CONF_GRP_CD = 'DP_LV_TP'
	AND B.CONF_CD = 'S'
	AND B.ID = LM.LV_TP_ID  -- S/C/I
	AND ISNULL(LM.DEL_YN,'N') = 'N'
	AND LM.ACTV_YN = 'Y'
	AND LM.ID = SL.LV_MGMT_ID 
	AND LM.SRP_LV_YN LIKE '%' + @p_SRP_LV_YN +'%'	
	AND ISNULL(SL.DEL_YN,'N') = 'N'
    AND SL.VIRTUAL_YN = 'N'
	AND SL.ACTV_YN = 'Y'
	AND SL.LV_MGMT_ID LIKE '%' + LTRIM(RTRIM(@p_SALES_LV)) +'%'	

  ORDER BY LM.SEQ, SL.SEQ
 ;




END








go

