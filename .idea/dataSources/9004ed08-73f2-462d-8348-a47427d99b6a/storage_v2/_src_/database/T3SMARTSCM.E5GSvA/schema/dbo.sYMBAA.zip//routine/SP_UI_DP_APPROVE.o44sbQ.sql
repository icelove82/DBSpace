CREATE PROCEDURE [dbo].[SP_UI_DP_APPROVE](
  @P_USER_CD		NVARCHAR(50)	
 ,@P_LOGIN_USER_CD		NVARCHAR(50)
-- ,@P_AUTH_TP_ID		CHAR(32)
 ,@P_AUTH_TP_CD		NVARCHAR(100)
-- ,@p_VER_ID			CHAR(32)
 ,@P_VER_CD			NVARCHAR(50)
 ,@P_AUTO_APPV_YN	CHAR(1)
)
AS 	 
/***************************************************************************************************************************************************
	 [ DP Approval]
	-- Parameter : User Code (inidividual Approval), Login ID(all Approval) Authority Type, Version Id

	History (date / writer / comment)
	- 2020.06.29 / kimsohee / draft
	- 2020.07.02 / kimsohee / add a function of all approval
	- 2020.11.10 / Kim sohee / data type of CODE NVARCHAR(100)
	- 2020.12.04 / kim sohee / level only setting control board version detail 
	- 2020.12.11 / kim sohee / actv yn , del yn check
	- 2021.01.14 / Kim sohee / modify submit target : add value type (qty_1, qty_2, qty_3) and remove amount value
	- 2022.01.18 / kim sohee / rollback seperate code about all apporve case , and add a level type
	- 2022.08.18 / kim sohee / add a auto approve flag 
    - 2023.02.02 / Kim sohee / NT, AN config code, bug fix : P_LOGIN_USER_CD => USER_CD 
**************************************************************************************************************************************************/
BEGIN 
DECLARE @P_AUTH_TP_ID	CHAR(32)
	 ,  @p_VER_ID		CHAR(32)
	 ;

-- Setting Values into parameters for Test 
--	SET @P_LOGIN_ID = 'SALES_02'
--	SET @P_AUTH_TP_CD = 'SALESMAN'
--	SET @P_VER_CD = 'DPM-20200624-001-00'	 
--	;
	IF(@P_USER_CD = '')
		BEGIN
			SET @P_USER_CD = NULL
			;
		END

   SELECT @P_VER_ID = ID 			
	 FROM TB_DP_CONTROL_BOARD_VER_MST
   WHERE VER_ID = @P_VER_CD 
	SELECT @P_AUTH_TP_ID = ID
	  FROM TB_CM_LEVEL_MGMT
	 WHERE LV_CD = @P_AUTH_TP_CD
	 AND LV_TP_ID = (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'DP_LV_TP' AND CONF_CD = 'S' )

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- 1. Approve Event Check
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
-- TB_DP_CONTROL_BOARD_VER_DTL 테이블에서 승인 이벤트 값을 확인해야 한다
	DECLARE @P_APPV_EVENT_CD	NVARCHAR(50)
	SELECT @P_APPV_EVENT_CD = CC.CONF_cD 
	  FROM TB_DP_CONTROL_BOARD_VER_DTL CB
		   INNER JOIN
		   TB_CM_COMM_CONFIG CC
		ON CB.APPV_EVENT_ID = CC.ID 
	 WHERE CONBD_VER_MST_ID = @p_VER_ID
	   AND LV_MGMT_ID = @P_AUTH_TP_ID 
	   ;	

	CREATE TABLE #TB_PRC_STA
	(	OPERATOR_ID	NVARCHAR(150)	COLLATE DATABASE_DEFAULT
	  , STA			NVARCHAR(10)	COLLATE DATABASE_DEFAULT
	)
	;
	/*	ANCS_ID			CHAR(32)
	   ,ANCS_CD			NVARCHAR(50)
	   ,*/
	CREATE TABLE #TB_USER_HIER	-- Hierarchy Info about Users who get the approved data
	(   ANCS_ROLE_ID	CHAR(32)		COLLATE DATABASE_DEFAULT
	   ,ANCS_ROLE_CD	NVARCHAR(100)	COLLATE DATABASE_DEFAULT
	   ,DESC_ID			CHAR(32)		COLLATE DATABASE_DEFAULT
	   ,DESC_CD			NVARCHAR(100)	COLLATE DATABASE_DEFAULT
	)	
	;
	CREATE TABLE #TEMP_DP_RT
	(	ITEM_MST_ID		CHAR(32)			COLLATE DATABASE_DEFAULT
	  , ACCOUNT_ID		CHAR(32)			COLLATE DATABASE_DEFAULT
	  , BASE_DATE		DATE
	  , QTY				DECIMAL(20,3)
	  , AUTH_TP_ID		CHAR(32)			COLLATE DATABASE_DEFAULT
	  , QTY_1			DECIMAL(20,3)
	  , QTY_2			DECIMAL(20,3)
	  , QTY_3			DECIMAL(20,3)
	)
--	SET @P_APPV_EVENT_CD = 'AA'
--   SELECT @P_VER_ID, @P_AUTH_TP_ID, @P_APPV_EVENT_CD
--   ;

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- 2. Get User Info to approve
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
IF @P_APPV_EVENT_CD = 'AN' 
-- (1) 내 상위 레벨에 속한 하위 level이 모두 승인하면, 상위 레벨 사용자들에게 업데이트		
	BEGIN
		INSERT INTO #TB_PRC_STA ( OPERATOR_ID, STA )
			SELECT OPERATOR_ID
				 , MAX([STATUS]) OVER (PARTITION BY OPERATOR_ID ORDER BY STATUS_DATE DESC) AS STA
			  FROM TB_DP_PROCESS_STATUS_LOG
			 WHERE VER_CD= @p_VER_CD
			   AND AUTH_TYPE = @P_AUTH_TP_CD 	
		;
		WITH ANCS_USER
		AS (SELECT ANCS_ID, ANCS_ROLE_ID
			  FROM TB_DPD_USER_HIER_CLOSURE
			 WHERE @P_USER_CD = CASE WHEN @P_AUTO_APPV_YN = 'Y' THEN @P_USER_CD ELSE DESC_CD END
			   AND DESC_ROLE_CD = @P_AUTH_TP_CD
		), USER_HIERARCHY
		AS (SELECT UH.ANCS_ROLE_ID, ANCS_ROLE_CD, ANCS_ID, DESC_ID, DESC_CD 
				 , ROW_NUMBER() OVER (PARTITION BY DESC_ID ORDER BY LV.SEQ  DESC) AS SEQ
			  FROM TB_DPD_USER_HIER_CLOSURE UH
				   INNER JOIN 
				   TB_CM_LEVEL_MGMT LV
			   ON UH.ANCS_ROLE_ID = LV.ID	
			  AND LV.ACTV_YN = 'Y'
			  AND COALESCE(LV.DEL_YN,'N') = 'N'
			       INNER JOIN 
				   TB_DP_CONTROL_BOARD_VER_DTL VD
			   ON UH.ANCS_ROLE_ID = VD.LV_MGMT_ID
			  AND VD.CONBD_VER_MST_ID = @P_VER_ID 
			WHERE DESC_ROLE_CD = @P_AUTH_TP_CD		  
			  AND UH.ANCS_ROLE_CD != UH.DESC_ROLE_CD
		)
		INSERT INTO #TB_USER_HIER
		(    ANCS_ROLE_ID	
		   , ANCS_ROLE_CD	
		   , DESC_ID			
		   , DESC_CD			
		)	
		SELECT UH.ANCS_ROLE_ID
			 , ANCS_ROLE_CD
			 , DESC_ID
			 , DESC_CD 
		  FROM USER_HIERARCHY UH 
			   INNER JOIN
			   ANCS_USER AU	-- User info of My parents level
			ON UH.ANCS_ID = AU.ANCS_ID
		   AND UH.ANCS_ROLE_ID = AU.ANCS_ROLE_ID	-- 내 매핑정보가 없는 상위 사용자가, 자신보다 상위인 사용자한테 값을 넘겨주는경우?
	     WHERE UH.SEQ = 1 


-- -- For Searching parents user (manager)
SELECT * 
  FROM (
	SELECT DESC_ID
		 , DESC_CD 
		 , ANCS_ROLE_ID
		 , ANCS_ROLE_CD
		 , ROW_NUMBER() OVER (PARTITION BY DESC_ID ORDER BY SEQ DESC) AS SEQ 
	 FROM #TB_USER_HIER UH 
	      INNER JOIN
		  TB_CM_LEVEL_MGMT LV
	   ON UH.ANCS_ROLE_ID = LV.ID
	  AND LV.ACTV_YN = 'Y'
	  AND COALESCE(LV.DEL_YN,'N') = 'N'
	   ) A
WHERE SEQ = 1 
	;
	END
ELSE IF @P_APPV_EVENT_CD = 'NT' 
-- (2) 나의 value를 상위 사용자에게 업데이트
	BEGIN
		INSERT INTO #TB_PRC_STA ( OPERATOR_ID, STA )
			SELECT OPERATOR_ID, MAX([STATUS]) OVER (PARTITION BY OPERATOR_ID ORDER BY STATUS_DATE DESC) AS STA
			  FROM TB_DP_PROCESS_STATUS_LOG
			 WHERE VER_CD= @p_VER_CD
			   AND AUTH_TYPE = @P_AUTH_TP_CD 	
			   AND OPERATOR_ID = ISNULL(@P_USER_CD,OPERATOR_ID)
		;
		WITH USER_HIERARCHY
		AS (
			SELECT UH.ANCS_ROLE_ID, ANCS_ROLE_CD, ANCS_ID, DESC_ID, DESC_CD
				 , ROW_NUMBER() OVER (PARTITION BY DESC_ID ORDER BY LV.SEQ  DESC) AS SEQ
			  FROM TB_DPD_USER_HIER_CLOSURE UH
				   INNER JOIN 
				   TB_CM_LEVEL_MGMT LV
			   ON UH.ANCS_ROLE_ID = LV.ID		
			  AND LV.ACTV_YN = 'Y'
			  AND COALESCE(LV.DEL_YN,'N') = 'N'
			       INNER JOIN 
				   TB_DP_CONTROL_BOARD_VER_DTL VD
			   ON UH.ANCS_ROLE_ID = VD.LV_MGMT_ID
			  AND VD.CONBD_VER_MST_ID = @P_VER_ID 
			WHERE DESC_ROLE_CD = @P_AUTH_TP_CD		  
			  AND UH.ANCS_ROLE_CD != UH.DESC_ROLE_CD
			  AND @P_USER_CD = CASE WHEN @P_AUTO_APPV_YN = 'Y' THEN @P_USER_CD ELSE DESC_CD END
		)
		INSERT INTO #TB_USER_HIER
		(   ANCS_ROLE_ID	
		   ,ANCS_ROLE_CD	
		   ,DESC_ID			
		   ,DESC_CD			
		)	
			SELECT ANCS_ROLE_ID, ANCS_ROLE_CD, DESC_ID, DESC_CD 
			  FROM USER_HIERARCHY
	         WHERE SEQ = 1 
			   
	;
	END
ELSE IF @P_APPV_EVENT_CD = 'AA'
-- (3) 같은 레벨의 모든 사용자가 승인하면, 해당 value를 다음 레벨의 사용자들에게 업데이트
	BEGIN
		INSERT INTO #TB_PRC_STA ( OPERATOR_ID, STA )
			SELECT OPERATOR_ID, MAX([STATUS]) OVER (PARTITION BY OPERATOR_ID ORDER BY STATUS_DATE DESC) AS STA
			  FROM TB_DP_PROCESS_STATUS_LOG
			 WHERE VER_CD= @p_VER_CD
			   AND AUTH_TYPE = @P_AUTH_TP_CD 	
		;
	  WITH USER_HIERARCHY
		AS (
			SELECT UH.ANCS_ROLE_ID, ANCS_ROLE_CD, ANCS_ID, DESC_ID, DESC_CD
				 , ROW_NUMBER() OVER (PARTITION BY DESC_ID ORDER BY LV.SEQ  DESC) AS SEQ
			  FROM TB_DPD_USER_HIER_CLOSURE UH
				   INNER JOIN 
				   TB_CM_LEVEL_MGMT LV
			   ON UH.ANCS_ROLE_ID = LV.ID		
			  AND LV.ACTV_YN = 'Y'
			  AND COALESCE(DEL_YN,'N') = 'N'
			       INNER JOIN 
				   TB_DP_CONTROL_BOARD_VER_DTL VD
			   ON UH.ANCS_ROLE_ID = VD.LV_MGMT_ID
			  AND VD.CONBD_VER_MST_ID = @P_VER_ID 
			WHERE DESC_ROLE_CD = @P_AUTH_TP_CD		  
			  AND UH.ANCS_ROLE_CD != UH.DESC_ROLE_CD
		)
		INSERT INTO #TB_USER_HIER
		(   ANCS_ROLE_ID	
		   ,ANCS_ROLE_CD	
		   ,DESC_ID			
		   ,DESC_CD			
		)	
		SELECT ANCS_ROLE_ID, ANCS_ROLE_CD, DESC_ID, DESC_CD 
		  FROM USER_HIERARCHY UH
		 WHERE SEQ = 1
		;
	END
-- ELSE IF @P_APPV_EVENT_CD = 'NN' (4) 이벤트 없음


--	SELECT *
--	 FROM #TB_PRC_STA
--	 ;  
--	SELECT US.ANCS_ROLE_ID, US.ANCS_ROLE_CD 
--		 , UH.DESC_ID, UH.DESC_CD, UH.DESC_ROLE_CD, UH.DESC_ROLE_ID 
--	  FROM TB_DPD_USER_HIER_CLOSURE UH
--		   INNER JOIN
--		   #TB_USER_HIER US
--		ON UH.ANCS_ID = US.DESC_ID
--	 WHERE MAPPING_SELF_YN = 'Y'	
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- 3. Check if this time is a momment to approve
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
 
IF EXISTS (		-- 코드 확인을 위해 주석처리
		SELECT UH.ANCS_ROLE_CD 
		  FROM #TB_USER_HIER UH
			   LEFT OUTER JOIN
			   #TB_PRC_STA PS
			ON UH.DESC_CD = PS.OPERATOR_ID
		   AND PS.STA = 'APPROVAL'
	  GROUP BY UH.ANCS_ROLE_CD
	    HAVING COUNT(PS.STA) = COUNT(UH.DESC_CD)
		)
    OR @P_USER_CD IS NULL 
	BEGIN
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- 4. Update Entry value
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
		-- Get Input data : Item, account, value (DESC of USER_HIER: 나 혹은 나와 같은 level 사용자들)
	WITH USER_HIER
	AS (-- User data For Getting item, account, model mapping 
		SELECT US.ANCS_ROLE_ID
			 , UH.DESC_ID, UH.DESC_CD, UH.DESC_ROLE_CD, UH.DESC_ROLE_ID 
		  FROM TB_DPD_USER_HIER_CLOSURE UH
			   INNER JOIN
			   #TB_USER_HIER US
			ON UH.ANCS_ID = US.DESC_ID
		 WHERE MAPPING_SELF_YN = 'Y'	
	), ITEM_HIER
	AS (
		SELECT ANCESTER_ID
			 , ANCESTER_CD
			 , DESCENDANT_ID
			 , DESCENDANT_CD 
		  FROM TB_DPD_ITEM_HIER_CLOSURE WHERE LEAF_YN = 'Y'		
	), SALES_HIER
	AS (
		SELECT ANCESTER_ID, ANCESTER_CD, DESCENDANT_ID, DESCENDANT_CD FROM TB_DPD_SALES_HIER_CLOSURE WHERE LEAF_YN = 'Y'
	), ITEM
	AS (  SELECT CASE WHEN CL.LEAF_YN = 'Y' 
					  THEN IM.ITEM_MST_ID 
					  ELSE IM.ITEM_LV_ID 
				  END	AS ID
			    , CL.LEAF_YN
			    , US.ANCS_ROLE_ID
			    , US.DESC_ID
			FROM TB_DP_USER_ITEM_MAP IM 
				  INNER JOIN
				  USER_HIER US 
			   ON IM.EMP_ID	    = US.DESC_ID 
			  AND IM.AUTH_TP_ID = US.DESC_ROLE_ID 
				  INNER JOIN 
				  TB_CM_LEVEL_MGMT CL 
			   ON IM.LV_MGMT_ID = CL.ID 
			  AND CL.ACTV_YN = 'Y'
			  AND COALESCE(CL.DEL_YN,'N') = 'N'
		    WHERE IM.ACTV_YN = 'Y'	    
	), ACCT
	AS (-- 내 매핑 ACCT 찾기
		SELECT CASE WHEN CL.LEAF_YN = 'Y' THEN AM.ACCOUNT_ID ELSE AM.SALES_LV_ID END	AS ID
			 , US.ANCS_ROLE_ID
			 , US.DESC_ID
			 , CL.LEAF_YN
		  FROM TB_DP_USER_ACCOUNT_MAP AM 
	           INNER JOIN
			   USER_HIER US
			ON AM.EMP_ID     = US.DESC_ID 
		   AND AM.AUTH_TP_ID = US.DESC_ROLE_ID
		       INNER JOIN
			   TB_CM_LEVEL_MGMT CL
			ON AM.LV_MGMT_ID = CL.ID 
		   AND CL.ACTV_YN = 'Y'
		   AND ISNULL(CL.DEL_YN, 'N') = 'N'
		 WHERE AM.ACTV_YN = 'Y'	 
	), EX
	AS (
	SELECT EX.ITEM_MST_ID 
		 , EX.ACCOUNT_ID
		 , US.ANCS_ROLE_ID
		 , US.DESC_ID
	  FROM TB_DP_USER_ITEM_ACCOUNT_EXCLUD EX
	           INNER JOIN
			   USER_HIER US
			ON EX.EMP_ID     = US.DESC_ID 
		   AND EX.AUTH_TP_ID = US.DESC_ROLE_ID
	) , IA 
	AS (	
	    SELECT ACCT.ANCS_ROLE_ID
	         , ACCT.DESC_ID
			 , CASE WHEN ITEM.LEAF_YN = 'Y' THEN ITEM.ID ELSE IH.DESCENDANT_ID END		AS ITEM_ID
			 , CASE WHEN ACCT.LEAF_YN = 'Y' THEN ACCT.ID ELSE SH.DESCENDANT_ID END		AS ACCT_ID
		  FROM ACCT		-- ACCT_SH
			   INNER JOIN
			   ITEM		-- ITEM_SH 
			ON ACCT.DESC_ID = ITEM.DESC_ID
			   INNER JOIN 
			   ITEM_HIER IH ON ( ITEM.ID = IH.ANCESTER_ID )
			   INNER JOIN
			   SALES_HIER SH
			ON ACCT.ID = SH.ANCESTER_ID
		 EXCEPT
		 SELECT ANCS_ROLE_ID 
			  , DESC_ID
			  , ITEM_MST_ID
			  , ACCOUNT_ID
		   FROM EX 	
	), M
	AS ( 
	   SELECT DISTINCT 
			  ITEM_ID
			 ,ACCT_ID 
			 ,ANCS_ROLE_ID
		 FROM IA
	    UNION
		SELECT DISTINCT 
			   ITEM_MST_ID
			 , ACCOUNT_ID
			 , ANCS_ROLE_ID
		  FROM TB_DP_USER_ITEM_ACCOUNT_MAP UIAM	-- item, account 각각의 매핑 정보가 있으면, 이 매핑 정보는 안본다.
			   INNER JOIN
			   USER_HIER USIF
		    ON UIAM.EMP_ID = USIF.DESC_ID
		   AND UIAM.AUTH_TP_ID = USIF.DESC_ROLE_ID
		), RT
		AS (
		SELECT ITEM_MST_ID
			 , ACCOUNT_ID
			 , BASE_DATE
			 , QTY 
			 , QTY_1
			 , QTY_2
			 , QTY_3
--			 , AMT 
--			 , AMT_1
--			 , AMT_2
--			 , AMT_3
--			 , AMT_A  
		  FROM TB_DP_ENTRY 
		 WHERE VER_ID = @P_VER_ID
		   AND AUTH_TP_ID = @P_AUTH_TP_ID		   
		)
		INSERT INTO #TEMP_DP_RT (ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, QTY, QTY_1, QTY_2, QTY_3, AUTH_TP_ID)
		SELECT M.ITEM_ID
			 , M.ACCT_ID
			 , RT.BASE_DATE
			 , RT.QTY
			 , RT.QTY_1
			 , RT.QTY_2
			 , RT.QTY_3
			 , M.ANCS_ROLE_ID 
		  FROM M
			   INNER JOIN 
			   RT 
			ON M.ITEM_ID = RT.ITEM_MST_ID
		   AND M.ACCT_ID = RT.ACCOUNT_ID			
		  ;
		
		UPDATE TB_DP_ENTRY
		   SET QTY	 = ET.QTY 
			  ,QTY_1 = ET.QTY_1
			  ,QTY_2 = ET.QTY_2
			  ,QTY_3 = ET.QTY_3
			  ,MODIFY_BY = ISNULL(@P_USER_CD, @P_LOGIN_USER_CD)
			  ,MODIFY_DTTM = GETDATE()
		  FROM #TEMP_DP_RT ET
		 WHERE TB_DP_ENTRY.VER_ID = @p_VER_ID
		   AND TB_DP_ENTRY.AUTH_TP_ID =ET.AUTH_TP_ID 
		   AND TB_DP_ENTRY.ITEM_MST_ID = ET.ITEM_MST_ID
		   AND TB_DP_ENTRY.ACCOUNT_ID = ET.ACCOUNT_ID
		   AND TB_DP_ENTRY.BASE_DATE = ET.BASE_DATE
--			SELECT * FROM ET 
		     ;
	END
	SELECT *
	 FROM #TEMP_DP_RT
	 ;
--
--	SELECT *
--	  FROM  #TB_PRC_STA
--	  SELECT *
--	   FROM #TB_USER_HIER

	-- Virtual Level 
	DECLARE @P_UPPER_AUTH_TP_ID CHAR(32);
	WITH CONBD
	 AS (
	   SELECT LV_MGMT_ID, WORK_CD, ROW_NUMBER() OVER (ORDER BY SEQ ASC) AS SEQ  
		 FROM TB_DP_CONTROL_BOARD_VER_DTL 
		WHERE CONBD_VER_MST_ID = @P_VER_ID 
		  AND LV_MGMT_ID IS NOT NULL 
		) 
	SELECT @P_UPPER_AUTH_TP_ID = LV_MGMT_ID 
	  FROM CONBD 
	 WHERE SEQ = (SELECT SEQ+1 FROM CONBD WHERE LV_MGMT_ID = @P_AUTH_TP_ID)
	;
	SELECT @P_UPPER_AUTH_TP_ID ;
     WITH VIRTUAL_SALES_LV
       AS ( 
         SELECT ID 
           FROM TB_DP_SALES_LEVEL_MGMT
          WHERE LV_MGMT_ID = @P_UPPER_AUTH_TP_ID
            AND VIRTUAL_YN = 'Y' 
          ), LEAF_SALES_LV
      AS ( 
         SELECT DESCENDANT_ID AS ACCT_ID	-- 가상 레벨의 최하단 Sales Level
           FROM VIRTUAL_SALES_LV	VL 
                INNER JOIN 
                TB_DPD_SALES_HIER_CLOSURE SH
             ON VL.ID = SH.ANCESTER_ID
          WHERE LV_TP_CD = 'S'
            AND USE_YN = 'Y'
            AND LEAF_YN = 'Y'
         )     
    MERGE INTO TB_DP_ENTRY TGT 
     USING (
            SELECT RT.ITEM_MST_ID
                 , RT.ACCOUNT_ID 
                 , RT.BASE_DATE
                 , RT.QTY
                 , RT.QTY_1
                 , RT.QTY_2
                 , RT.QTY_3
              FROM #TEMP_DP_RT RT  
                   INNER JOIN 
                   LEAF_SALES_LV SL
                ON RT.ACCOUNT_ID = SL.ACCT_ID      
            ) SRC
        ON (TGT.VER_ID = @P_VER_ID 
       AND TGT.AUTH_TP_ID = @P_UPPER_AUTH_TP_ID
       AND TGT.ITEM_MST_ID = SRC.ITEM_MST_ID 
	   AND TGT.ACCOUNT_ID  = SRC.ACCOUNT_ID
	   AND TGT.BASE_DATE = SRC.BASE_DATE ) 
    WHEN MATCHED THEN  
    UPDATE
       SET QTY	 = SRC.QTY 
		  ,QTY_1 = SRC.QTY_1
		  ,QTY_2 = SRC.QTY_2
		  ,QTY_3 = SRC.QTY_3
		  ,MODIFY_BY = COALESCE(@P_USER_CD, @P_LOGIN_USER_CD)
		  ,MODIFY_DTTM = GETDATE()
         ;


/***************************************************************************************************************************************************
	[ All Users Approval (Control Board) ]
-- Parameter : Rule to Approve Event, Authority Type, Version Id
-- 이 경우 가상레벨따라 다르게 auth type을 찾아서 값이 올라가야 함)
-- 예를 들어, 같은 salesman이더라도 A사용자는 상위로 Z매니저를, B사용자는 매니저 레벨은 가상레벨을 거쳐 상위로 GOC를 바라보고 있을 수 있다.
**************************************************************************************************************************************************/
-- 1. Find a Sales level except Virtual Level.
-- 2. Update Entry



DROP TABLE #TB_PRC_STA
DROP TABLE #TB_USER_HIER
DROP TABLE #TEMP_DP_RT

END 
go

