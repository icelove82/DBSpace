
CREATE PROCEDURE [dbo].[SP_UI_MP_17_Q1] (
	 @P_LOCAT_TP_NM			NVARCHAR (100) = ''
	,@P_LOCAT_LV			NVARCHAR (100) = ''
	,@P_LOCAT_CD			NVARCHAR (100) = ''
	,@P_LOCAT_NM			NVARCHAR (100) = ''
	,@P_ITEM_CD				NVARCHAR (100) = ''
	,@P_DESCRIP				NVARCHAR (100) = ''
	,@P_ITEM_TP_NM			NVARCHAR (100) = ''
	,@P_ROUTE_CD			NVARCHAR (100) = ''
	,@P_ROUTE_DESCRIP		NVARCHAR (100) = ''
	,@P_RES_CD				NVARCHAR (100) = ''
	,@P_RES_DESCRIP			NVARCHAR (100) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

    SELECT  A.ID
	        ,A.LOCAT_MST_ID
			,A.LOCAT_TP_NM
			,A.LOCAT_LV
			,A.LOCAT_LV_DESCRIP
			,A.DMND_INTG_YN
			,A.LOCAT_ID
			,A.LOCAT_CD
			,A.LOCAT_NM
            ,A.ITEM_CD
            ,A.ITEM_NM
            ,A.DESCRIP
            ,A.CONVN_NM  AS ITEM_TP
            ,A.ATTR_01
            ,A.ATTR_02
            ,A.ATTR_03
            ,A.ATTR_04
            ,A.ATTR_05
            ,A.ATTR_06
            ,A.ATTR_07
            ,A.ATTR_08
            ,A.ATTR_09
            ,A.ATTR_10
            ,A.ATTR_11
            ,A.ATTR_12
            ,A.ATTR_13
            ,A.ATTR_14
            ,A.ATTR_15
            ,A.ATTR_16
            ,A.ATTR_17 
            ,A.ATTR_18
            ,A.ATTR_19
            ,A.ATTR_20
            ,A.RES_CD 
            ,A.RES_DESCRIP
			,A.ITEM_RES_PREF_MST_ID
            ,A.YYYYMMDD
            ,A.CONST_YN
	FROM (
		    SELECT  B.ID                    AS LOCAT_MST_ID
			        ,A.COMN_CD_NM			AS LOCAT_TP_NM
					,A.SEQ                  AS LOCAT_DISP_SEQ
					,B.LOCAT_LV				AS LOCAT_LV
					,B.LOCAT_LV_DESCRIP		AS LOCAT_LV_DESCRIP
					,B.DMND_INTG_YN         AS DMND_INTG_YN
					,D.LOCAT_ID				AS LOCAT_ID
					,C.LOCAT_CD				AS LOCAT_CD
					,C.LOCAT_NM				AS LOCAT_NM
					,E.ITEM_MST_ID			AS ITEM_MST_ID
					,L.ROUTE_CD 			AS ROUTE_CD
					,L.ROUTE_DESCRIP 		AS ROUTE_DESCRIP
					,I.RES_CD               AS RES_CD 
					,I.RES_DESCRIP			AS RES_DESCRIP
					,H.ID					AS ID
					,H.ITEM_RES_PREF_MST_ID	AS ITEM_RES_PREF_MST_ID
					,H.STRT_DATE            AS YYYYMMDD
					,H.CONST_YN             AS CONST_YN
                    ,J.ITEM_CD
                    ,J.ITEM_NM
                    ,J.DESCRIP
                    ,K.CONVN_NM
                    ,J.ATTR_01
                    ,J.ATTR_02
                    ,J.ATTR_03
                    ,J.ATTR_04
                    ,J.ATTR_05
                    ,J.ATTR_06
                    ,J.ATTR_07
                    ,J.ATTR_08
                    ,J.ATTR_09
                    ,J.ATTR_10
                    ,J.ATTR_11
                    ,J.ATTR_12
                    ,J.ATTR_13
                    ,J.ATTR_14
                    ,J.ATTR_15
                    ,J.ATTR_16
                    ,J.ATTR_17 
                    ,J.ATTR_18
                    ,J.ATTR_19
                    ,J.ATTR_20
			FROM  TB_AD_COMN_CODE A
			        INNER JOIN 
				    TB_CM_LOC_MST B
				ON (A.ID = B.LOCAT_TP_ID)
				INNER JOIN 
				    TB_CM_LOC_DTL C
				ON (B.ID = C.LOCAT_MST_ID)
					INNER JOIN 
					TB_CM_LOC_MGMT D
                ON (C.ID = D.LOCAT_ID)
					INNER JOIN 
					TB_CM_SITE_ITEM E
					ON (D.ID = E.LOCAT_MGMT_ID)
					INNER JOIN 
	                TB_MP_ITEM_RES_PREFER_MST F
					ON (E.ID = F.LOCAT_ITEM_ID)
					INNER JOIN 
	                TB_MP_ITEM_MFG_OPERT_CALDR H
					ON (F.ID = H.ITEM_RES_PREF_MST_ID)
					INNER JOIN 
					TB_MP_RES_MGMT_DTL I
					ON (F.RES_ID = I.ID)
					INNER JOIN 
					TB_CM_ITEM_MST J
					ON (E.ITEM_MST_ID = J.ID)
					INNER JOIN 
					TB_CM_ITEM_TYPE K
					ON ( J.ITEM_TP_ID = K.ID)
					LEFT OUTER JOIN 
					TB_MP_ROUTE L
					ON (L.ID = F.ROUTE_ID)
			WHERE 1=1
            AND UPPER(A.COMN_CD_NM) LIKE '%'+UPPER(@P_LOCAT_TP_NM)+'%'
            AND B.LOCAT_LV LIKE '%'+@P_LOCAT_LV+'%'
            AND UPPER(C.LOCAT_CD) LIKE '%'+UPPER(@P_LOCAT_CD)+'%'
            AND UPPER(C.LOCAT_NM) LIKE '%'+UPPER(@P_LOCAT_NM)+'%'
            AND UPPER(J.ITEM_CD) LIKE '%'+UPPER(@P_ITEM_CD)+'%'
            AND K.CONVN_NM LIKE '%'+@P_ITEM_TP_NM+'%'
            AND ISNULL(L.ROUTE_CD, '') LIKE '%'  + @P_ROUTE_CD + '%'
			AND ISNULL(L.ROUTE_DESCRIP, '') LIKE '%'+@P_ROUTE_DESCRIP+'%'
			AND I.RES_CD LIKE '%'  + @P_RES_CD + '%'
			AND I.RES_DESCRIP LIKE '%'+@P_RES_DESCRIP+'%'
		    ) A

go

