/*****************************************************************************
Title : SP_UI_DP_41_S1_J
  - DP Measure Data Management
 
설명 
  - OPENJSON : https://docs.microsoft.com/ko-kr/sql/t-sql/functions/openjson-transact-sql?view=sql-server-ver15

 
History (수정일자 / 수정자 / 수정내용)
- 2022.01.11 / kim sohee / json bulk insert draft
*****************************************************************************/
CREATE PROCEDURE [dbo].[SP_UI_DP_41_S1_J] (		
			@P_JSON				  NVARCHAR(MAX)
		   ,@P_MEASURE			  NVARCHAR(20)
		   ,@P_USER_ID            NVARCHAR(100)     = ''
		   ,@P_RT_ROLLBACK_FLAG   NVARCHAR(10)      = 'true'  OUTPUT
		   ,@P_RT_MSG             NVARCHAR(4000)    = ''	   OUTPUT	
)AS

	DECLARE @P_ERR_MSG NVARCHAR(4000) 
		  , @P_SQL	   NVARCHAR(MAX)

BEGIN TRY
		SELECT TOP 1 @P_ERR_MSG = V.[key]	--R.key, R.value, V.key, V.value
		  FROM OPENJSON(@P_JSON) AS R
			   CROSS APPLY 
			   OPENJSON ( R.value) AS V
		 WHERE V.[value] IS NULL 
		   AND V.[key] IN ( 'ITEM_CD'	
		   				   ,'ACCOUNT_CD'
		   				   ,'BASE_DATE'	
						  ) ;
	IF @P_ERR_MSG IS NOT NULL 
	BEGIN
		SET @P_ERR_MSG = 'Check Empty Value : '+@P_ERR_MSG		
		RAISERROR (@P_ERR_MSG,12, 1);
	END
	;
		 
				SET @P_SQL = 'MERGE TB_DP_MEASURE_DATA TGT '
				+'USING ( SELECT   A.ID	AS  ACCOUNT_ID '    
								+',I.ID	AS  ITEM_MST_ID '     
								+',M.BASE_DATE '       
								+',M.QTY '					
								+',M.AMT '
					   +'FROM OPENJSON(@P_JSON) '
					   +'WITH ( ITEM_CD		NVARCHAR(100) ''$.ITEM_CD'' '
							 +',ACCOUNT_CD	NVARCHAR(100) ''$.ACCOUNT_CD'' '
							 +',BASE_DATE	DATETIME ''$.BASE_DATE'' '
							 +',QTY			DECIMAL(20,3) ''$.QTY'' '
							 +',AMT			DECIMAL(20,3) ''$.AMT'' '
							 +',ROW_STATUS	NVARCHAR(100) ''$.ROW_STATUS'' '
							 +') M '
						     +'INNER JOIN '
							 +'TB_CM_ITEM_MST I '
						  +'ON M.ITEM_CD = I.ITEM_CD '
						     +'INNER JOIN '
							 +'TB_DP_ACCOUNT_MST A '
						  +'ON M.ACCOUNT_CD = A.ACCOUNT_CD '
					  +') SRC '
					+'ON TGT.ACCOUNT_ID = SRC.ACCOUNT_ID '
				   +'AND TGT.ITEM_MST_ID = SRC.ITEM_MST_ID '
				   +'AND TGT.BASE_DATE = SRC.BASE_DATE '
				+'WHEN MATCHED THEN '
					 +'UPDATE '
					   +'SET   TGT.'+@P_MEASURE+'_QTY = SRC.QTY '
							+',TGT.'+@P_MEASURE+'_AMT = SRC.AMT '
							+',TGT.MODIFY_BY = '''+@P_USER_ID+''' '     
							+',TGT.MODIFY_DTTM = GETDATE() '      
				+'WHEN NOT MATCHED THEN '
					 +'INSERT (ID '         
							+',ACCOUNT_ID '
							+',ITEM_MST_ID '
							+',BASE_DATE ' 
							+','+@P_MEASURE+'_QTY '   
							+','+@P_MEASURE+'_AMT '
							+',CREATE_BY '
							+',CREATE_DTTM '
							+') '
					 +'VALUES ( '
							 +'REPLACE(NEWID(),''-'','''') '
							+',SRC.ACCOUNT_ID '   
							+',SRC.ITEM_MST_ID '  
							+',SRC.BASE_DATE '     
							+',SRC.QTY '   
							+',SRC.AMT '    
							+','''+@P_USER_ID+''' '
							+',GETDATE() '           
 							+');' 
							;  
--				SELECT @P_SQL ;
				EXEC SP_EXECUTESQL @P_SQL, N'@P_JSON AS NVARCHAR(MAX)', @P_JSON


	BEGIN
	    SET @P_RT_MSG = 'MSG_0001'
	END
	    SET @P_RT_ROLLBACK_FLAG = 'true'
END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() LIKE 'MSG_%')
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END
	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR
END CATCH

go

