/*****************************************************************************
Title : [SP_UI_BF_15_Q1]
최초 작성자 : 김소희
최초 생성일 : 2019.11.21
 
설명 
 - BF Control Board Master
 
History (수정일자 / 수정자 / 수정내용)
- 2019.11.21 / 김소희 / Draft
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_BF_15_D1] 
(
		 @P_ID					CHAR(32)			
		,@P_RT_ROLLBACK_FLAG		NVARCHAR(10)   = 'true'     OUTPUT
		,@P_RT_MSG				NVARCHAR(4000) = ''			OUTPUT		
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	DECLARE @P_ERR_STATUS INT = 0
		   ,@P_ERR_MSG NVARCHAR(4000)=''
BEGIN TRY
	DELETE FROM TB_BF_CONTROL_BOARD_MST
	WHERE ID = @P_ID 
 	 	 
	BEGIN
	    SET @P_RT_MSG = 'MSG_0002'
	END
	    SET @P_RT_ROLLBACK_FLAG = 'true'
END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE() = @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END
	   ELSE 
				THROW;
--				EXEC SP_COMM_RAISE_ERR
END CATCH


/*

SELECT *
 FROM  TB_CM_CONFIGURATION CF
		 INNER JOIN
		 TB_CM_COMM_CONFIG CC	
	  ON CF.ID = CC.CONF_ID 
	 AND CF.CONF_NM = 'BF_ENGINE_TP'
	 AND CF.MODULE_CD = 'BF'
	  -- lang_pack 문서에 반영하기!!!
	  SELECT *
	    FROM LANG_PACK
	  WHERE LANG_KEY LIKE '%ENGINE_TP%'
	    OR LANG_KEY = 'INPUT'
*/

go

