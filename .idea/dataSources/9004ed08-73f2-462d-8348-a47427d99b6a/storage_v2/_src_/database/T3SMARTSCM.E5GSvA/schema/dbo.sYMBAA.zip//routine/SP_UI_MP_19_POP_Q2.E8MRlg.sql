CREATE PROCEDURE [dbo].[SP_UI_MP_19_POP_Q2] (
    @P_DMND_OVW_ID    CHAR(32) = ''
)
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

BEGIN
    SELECT
            A.ID
            ,B.ID                AS DMND_OVERVIEW_ID
            ,E.ID                AS LOCAT_MGMT_ID
            ,C.ID                AS RES_PREFER_MST_ID
            ,H.COMN_CD_NM        AS LOCAT_TP_NM
            ,G.LOCAT_LV
            ,F.LOCAT_CD
            ,F.LOCAT_NM
            ,J.ITEM_CD
            ,J.ITEM_NM
            ,K.ROUTE_CD
            ,K.ROUTE_DESCRIP
            ,I.RES_CD
            ,I.RES_DESCRIP       AS RES_NM
            ,A.ASSIGN_YN
			,A.PRIORT
            ,A.ACTV_YN
    FROM
        TB_MP_DMND_OVW_RES_ASIGN A
        ,TB_CM_DEMAND_OVERVIEW B
        ,TB_MP_ITEM_RES_PREFER_MST C
         LEFT OUTER JOIN TB_MP_ROUTE K
         ON K.ID = C.ROUTE_ID
        ,TB_CM_SITE_ITEM D
        ,TB_CM_LOC_MGMT E
        ,TB_CM_LOC_DTL F
        ,TB_CM_LOC_MST G
        ,TB_AD_COMN_CODE H
        ,TB_MP_RES_MGMT_DTL I
        ,TB_CM_ITEM_MST J
    WHERE 1=1
    AND A.DMND_OVERVIEW_ID = B.ID
    AND A.ITEM_RES_PREF_MST_ID = C.ID
    AND D.ID = C.LOCAT_ITEM_ID
    AND D.LOCAT_MGMT_ID = E.ID
    AND E.LOCAT_ID = F.ID
    AND F.LOCAT_MST_ID = G.ID
    AND G.LOCAT_TP_ID = H.ID
    AND I.ID = C.RES_ID
    AND J.ID = D.ITEM_MST_ID
    AND B.ID = @P_DMND_OVW_ID;
END;

go

