/*****************************************************************************
Title : SP_DP_00_LV_CD
최초 작성자 : 민희영
최초 생성일 : 2017.06.23
 
설명 
 - DP 콤보(LEVEL Management) 조회 프로시저 
  
History (수정일자 / 수정자 / 수정내용)
- 2017.06.23 / 민희영 / 최초 작성
- 2017.08.07 / 이고은 / TABLE 수정
- 2019.04.23 / 김소희 / DEL_YN Null처리 
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_00_LV_CD_Q1] (
												@p_LV_TP                  NVARCHAR(32)	= '',
												@p_ACCOUNT_TP             NVARCHAR(32)	= '',
												@p_LEAF_YN                NVARCHAR(32)	= '',
												@p_LV_LEAF_YN             NVARCHAR(32)	= '',
											    @p_TYPE                   NVARCHAR(32)  = '',
												@p_ACCOUNT_LV_YN		  NVARCHAR(32)  = '',
												@p_PARENT_SEARCH          NVARCHAR(32)  = '',
												@p_NOW_LEVEL_SEARCH       NVARCHAR(32)  = ''
                                              )
											   AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
DECLARE   @V_LV_TP				NVARCHAR(32) = ''
		, @V_ACCOUNT_TP			NVARCHAR(32) = ''
		, @V_LEAF_YN			NVARCHAR(32) = ''
		, @V_LV_LEAF_YN			NVARCHAR(32) = ''
		, @V_TYPE 				NVARCHAR(32) = ''
		, @V_ACCOUNT_LV_YN		NVARCHAR(32) = ''
		, @V_PARENT_SEARCH		NVARCHAR(32) = ''
		, @V_NOW_LEVEL_SEARCH	NVARCHAR(32) = ''

SET @V_LV_TP			= COALESCE(@p_LV_TP				,'')
SET @V_ACCOUNT_TP		= COALESCE(@p_ACCOUNT_TP		,'')
SET @V_LEAF_YN			= COALESCE(@p_LEAF_YN			,'')
SET @V_LV_LEAF_YN		= COALESCE(@p_LV_LEAF_YN		,'')
SET @V_TYPE 			= COALESCE(@p_TYPE				,'')
SET @V_ACCOUNT_LV_YN	= COALESCE(@p_ACCOUNT_LV_YN		,'')
SET @V_PARENT_SEARCH	= COALESCE(@p_PARENT_SEARCH		,'')
SET @V_NOW_LEVEL_SEARCH = COALESCE(@p_NOW_LEVEL_SEARCH	,'')

BEGIN

 IF @V_ACCOUNT_TP = 'ACCOUNT'
    BEGIN 
		
	     SELECT	  A.LV_TP
				, A.ID
				, A.CD
				, A.CD_NM
		FROM	(

				SELECT 
					  '1'  AS LV_TP 
					, ''  AS ID
					, CASE WHEN @V_TYPE = 'All' THEN 'ALL' ELSE '' END  AS CD
					, CASE WHEN @V_TYPE = 'All' THEN 'ALL' ELSE '' END  AS CD_NM
					,  0  AS SEQ 

				UNION ALL 

				SELECT    B.CONF_CD AS LV_TP
				        , LM.ID  AS ID
				        , LM.LV_CD  AS CD
						, LM.LV_NM  AS CD_NM 
						, LM.SEQ 
				  FROM   TB_CM_CONFIGURATION A
					   , TB_CM_COMM_CONFIG B
					   , TB_CM_LEVEL_MGMT  LM
				 where A.MODULE_CD = 'DP'
				   AND A.ID = B.CONF_ID
				   AND B.CONF_GRP_CD = 'DP_LV_TP'
				   AND B.ACTV_YN = 'Y'
				   AND B.CONF_CD = @v_LV_TP    -- S/I/C
				   AND B.ID = LM.LV_TP_ID 
				   AND LM.ACCOUNT_LV_YN = 'Y'   -- ACCOUNT_YN 값이 Y 인 것만 
				   AND ISNULL(LM.DEL_YN,'N') = 'N'
				   AND LM.ACTV_YN = 'Y'
				   AND LM.LEAF_YN LIKE  '%'+ @V_LEAF_YN + '%'
				   AND LM.LV_LEAF_YN LIKE  '%'+ @V_LV_LEAF_YN + '%'
				) A
		ORDER BY A.LV_TP ASC,A.SEQ ASC
        ;

    END



 ELSE IF @V_ACCOUNT_TP = 'SALES'
    BEGIN 
	     SELECT	  A.LV_TP
				, A.ID
				, A.CD
				, A.CD_NM
		FROM	(

				SELECT 
					  '2'  AS LV_TP 
					, ''  AS ID
					, CASE WHEN @V_TYPE = 'All' THEN 'ALL' ELSE '' END  AS CD
					, CASE WHEN @V_TYPE = 'All' THEN 'ALL' ELSE '' END  AS CD_NM
					,  0  AS SEQ 
				WHERE COALESCE(@V_TYPE,'ALL') != 'NOT_ALL'
				UNION ALL 

				SELECT    B.CONF_CD AS LV_TP
				        , LM.ID  AS ID
				        , LM.LV_CD  AS CD
						, LM.LV_NM  AS CD_NM 
						, LM.SEQ 
				  FROM   TB_CM_CONFIGURATION A
					   , TB_CM_COMM_CONFIG B
					   , TB_CM_LEVEL_MGMT  LM
				 where A.MODULE_CD = 'DP'
				   AND A.ID = B.CONF_ID
				   AND B.CONF_GRP_CD = 'DP_LV_TP'
				   AND B.ACTV_YN = 'Y'
				   AND B.CONF_CD = @p_LV_TP
				   AND B.ID = LM.LV_TP_ID 
				   AND LM.SALES_LV_YN = 'Y'   -- SALES_LV_YN 값이 Y 인 것만 
				   AND ISNULL(LM.DEL_YN,'N') = 'N'
				   AND LM.ACTV_YN = 'Y'
				   AND LM.LEAF_YN LIKE  '%'+ @V_LEAF_YN + '%'
				   AND LM.LV_LEAF_YN LIKE  '%'+ @V_LV_LEAF_YN + '%'
				) A
		ORDER BY A.LV_TP ASC,A.SEQ ASC
        ;

    END

ELSE 
    BEGIN
	     SELECT	  A.LV_TP_CD
				, A.ID
				, A.CD
				, A.CD_NM
				, A.LEAF_YN
		FROM	(

				SELECT 
					  '3' AS LV_TP_CD 
					, ''  AS ID
					, CASE WHEN @V_TYPE = 'All' THEN 'ALL' ELSE '' END  AS CD
					, CASE WHEN @V_TYPE = 'All' THEN 'ALL' ELSE '' END  AS CD_NM
					,  0  AS SEQ 
					, ''  AS LEAF_YN
				WHERE UPPER(@V_TYPE) = 'ALL'
				UNION ALL 

				SELECT    B.CONF_CD AS LV_TP_CD
				        , LM.ID  AS ID
						, LM.LV_CD  AS CD
						, LM.LV_NM  AS CD_NM 
						, LM.SEQ 
						, LM.LEAF_YN
				  FROM   TB_CM_CONFIGURATION A
					   , TB_CM_COMM_CONFIG B
					   , TB_CM_LEVEL_MGMT  LM
				 WHERE  A.MODULE_CD = 'DP'
				   AND A.ID = B.CONF_ID
				   AND B.CONF_GRP_CD = 'DP_LV_TP'
				   AND B.ACTV_YN = 'Y'
				   AND B.CONF_CD = @v_LV_TP 
				   AND B.ID = LM.LV_TP_ID 
				   AND ISNULL(LM.DEL_YN,'N') = 'N'
				   AND LM.ACTV_YN = 'Y'
				   AND LM.LEAF_YN LIKE  '%'+ @V_LEAF_YN + '%'
				   AND LM.LV_LEAF_YN LIKE  '%'+ @V_LV_LEAF_YN + '%'
				   AND LM.ACCOUNT_LV_YN LIKE  '%'+ @V_ACCOUNT_LV_YN + '%'
				   -- 상위 레벨 조건 선택 여부 
				   AND (( '' <> ISNULL(@V_PARENT_SEARCH,'') AND  LM.SEQ = ( SELECT LM2.SEQ -1  FROM TB_CM_LEVEL_MGMT LM2 WHERE LM2.ID = @V_PARENT_SEARCH ))
						 OR
					    ( ''  =  ISNULL(@V_PARENT_SEARCH,'') AND ISNULL(LM.ID,'')  LIKE  '%'  )	                                        
					   )        
				   -- 현재 레벨 선택 여부 
				   AND (( '' <>  ISNULL(@V_NOW_LEVEL_SEARCH,'') AND  LM.ID = @V_NOW_LEVEL_SEARCH)
						 OR
					    ( ''  =  ISNULL(@V_NOW_LEVEL_SEARCH,'') AND ISNULL(LM.ID,'')  LIKE  '%'  )	                                        
					   )        

				) A
		ORDER BY A.LV_TP_CD ASC,A.SEQ ASC
        ;


	END 




END





go

