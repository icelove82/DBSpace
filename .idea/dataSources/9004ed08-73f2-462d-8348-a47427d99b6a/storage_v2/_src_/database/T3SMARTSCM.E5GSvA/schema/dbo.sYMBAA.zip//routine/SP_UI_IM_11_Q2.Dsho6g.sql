CREATE PROCEDURE [dbo].[SP_UI_IM_11_Q2] 
AS
/*****************************************************************************
Title : SP_UI_IM_11_Q2
최초 작성자 : 한영석
최초 생성일 : 2017.07.24
 
설명 
 -  
History (수정일자 / 수정자 / 수정내용)
- 2017.07.24 / 한영석 / 최초 작성
 
*****************************************************************************/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	SELECT ''	AS ID
		,''		AS WAREHOUSE_TP
		,''		AS WAREHOUSE_TP_NM
		,''		AS LOAD_CAPA_MGMT_BASE
	UNION ALL
	SELECT A.ID
			,A.WAREHOUSE_TP
			,A.WAREHOUSE_TP_NM	
			,A.LOAD_CAPA_MGMT_BASE
	FROM TB_CM_WAREHOUSE_TYPE A

go

