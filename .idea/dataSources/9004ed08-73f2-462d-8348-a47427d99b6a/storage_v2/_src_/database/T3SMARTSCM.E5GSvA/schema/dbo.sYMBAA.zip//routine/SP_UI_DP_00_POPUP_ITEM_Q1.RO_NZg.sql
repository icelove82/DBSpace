/*****************************************************************************
Title : [SP_DP_00_POPUP_ITEM_Q1]
최초 작성자 : 민희영
최초 생성일 : 2017.06.21
 
설명 
 - DP ITEM POPUP 조회 프로시저 
  
History (수정일자 / 수정자 / 수정내용)
- 2017.06.21 / 민희영 / 최초 작성
- 2019.03.14 / 김소희 / 상위 Item level 검색조건에 추가 
- 2019.05.07 / 김소희 / Item type 테이블 빼기
- 2020.03.12 / 김소희 / EMP_NO => USER_ID 
- 2020.06.05 / hanguls / USER_ID => USERNAME
- 2020.09.22 / hanguls / TB_DP_EMPLOYEE => TB_AD_USER
- 2021.10.01 / hanguls / like 개선
*****************************************************************************/

CREATE PROCEDURE [dbo].[SP_UI_DP_00_POPUP_ITEM_Q1]  (
											   @p_EMP_NO	   NVARCHAR(240)  = NULL	
											  ,@p_AUTH_TP_ID   CHAR(32)		  = NULL 
											  ,@p_ITEM_CD      NVARCHAR(30)  = NULL
                                              ,@p_ITEM_NM      NVARCHAR(240) = NULL
											  ,@p_ITEM_LV_CD   NVARCHAR(240)  = NULL
            								  ) AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
	DECLARE @P_EMP_ID	CHAR(32) = NULL;

BEGIN
	SELECT @P_EMP_ID = ID
     FROM TB_AD_USER
	WHERE USERNAME = @P_EMP_NO
IF NOT EXISTS (
							SELECT EMP_ID 
						     FROM TB_DP_USER_ITEM_MAP
							WHERE EMP_ID = @p_EMP_ID
							  AND AUTH_TP_ID = @p_AUTH_TP_ID
							  AND ACTV_YN = 'Y'
							UNION
						    SELECT EMP_ID
						      FROM TB_DP_USER_ITEM_ACCOUNT_MAP
						     WHERE EMP_ID = @p_EMP_ID
							   AND AUTH_TP_ID = @p_AUTH_TP_ID
							   AND ACTV_YN = 'Y'
				)
	BEGIN
		SET @P_EMP_ID = NULL;
	END
IF @P_EMP_ID IS NULL OR @p_AUTH_TP_ID IS NULL
	BEGIN
   SELECT  A.ID 
				, A.ITEM_CD
				, A.ITEM_NM
				, CONVERT(DATETIME, A.EOS,112)  AS EOS      
				, CONVERT(DATETIME, A.RTS,112)  AS RTS                                                                             
				, A.UOM_ID
				, C.UOM_NM
				, C.UOM_CD
				, A.DESCRIP
				, A.DP_PLAN_YN
				, A.DEL_YN
				, A.PARENT_ITEM_LV_ID 
				, D.ITEM_LV_CD   AS PARENT_ITEM_LV_CD
				, D.ITEM_LV_NM   AS PARENT_ITEM_LV_NM
				, A.ATTR_01
				, A.ATTR_02
				, A.ATTR_03                                                
				, A.ATTR_04
				, A.ATTR_05
				, A.ATTR_06
				, A.ATTR_07
				, A.ATTR_08
				, A.ATTR_09
				, A.ATTR_10
				, A.ATTR_11
				, A.ATTR_12
				, A.ATTR_13
				, A.ATTR_14
				, A.ATTR_15
				, A.ATTR_16
				, A.ATTR_17
				, A.ATTR_18
				, A.ATTR_19
				, A.ATTR_20
				, A.CREATE_BY
				, A.CREATE_DTTM
				, A.MODIFY_BY
				, A.MODIFY_DTTM
		  FROM    TB_CM_ITEM_MST A 
				   LEFT OUTER JOIN
				   TB_CM_UOM C
			    ON A.UOM_ID = C.ID	   AND C.ACTV_YN = 'Y'
				   INNER JOIN
				   TB_CM_ITEM_LEVEL_MGMT D
			    ON A.PARENT_ITEM_LV_ID = D.ID AND D.ACTV_YN = 'Y'
		 WHERE 1=1	
		   AND ISNULL(A.DEL_YN,'N') = 'N'
		   AND A.DP_PLAN_YN = 'Y'
           AND ('Y' = CASE WHEN @P_ITEM_CD = '' THEN 'Y'
                           ELSE ( case when UPPER(A.ITEM_CD)  LIKE '%' + UPPER(RTRIM(ISNULL(@P_ITEM_CD,''))) + '%'	then 'Y' else 'N' end) 
					  END)		
           AND ('Y' = CASE WHEN @P_ITEM_NM = '' THEN 'Y'
                           ELSE ( case when UPPER(A.ITEM_NM)  LIKE '%' + UPPER(RTRIM(ISNULL(@P_ITEM_NM,''))) + '%'	then 'Y' else 'N' end) 
					  END)
		   AND (D.ITEM_LV_CD = @p_ITEM_LV_CD	OR ISNULL(@p_ITEM_LV_CD,'') ='')
		  ORDER BY D.SEQ, D.ITEM_LV_CD,  A.ITEM_CD
		   ;
	END
ELSE
	BEGIN
 		SELECT IM.ID, IM.ITEM_CD, IM.ITEM_NM,UM.UOM_CD,UM.UOM_NM, IL.ITEM_LV_NM AS PARENT_ITEM_LV_NM
		  FROM FN_DP_TEMP_FIND_ITEM(@P_EMP_ID,@P_AUTH_TP_ID, @P_ITEM_LV_CD) FI
			   INNER JOIN
			   TB_CM_ITEM_MST IM
			ON IM.ID = FI.ITEM_ID
				LEFT OUTER JOIN
				TB_CM_UOM UM
			ON IM.UOM_ID = UM.ID
				LEFT OUTER JOIN
				TB_CM_ITEM_LEVEL_MGMT IL
			ON  IL.ID = IM.PARENT_ITEM_LV_ID
	     WHERE  ('Y' = CASE WHEN @P_ITEM_CD = '' THEN 'Y'
                            ELSE ( case when UPPER(FI.ITEM_CD)  LIKE '%' + UPPER(RTRIM(ISNULL(@P_ITEM_CD,''))) + '%'	then 'Y' else 'N' end) 
					   END)	 
		   AND ('Y' = CASE WHEN @P_ITEM_NM = '' THEN 'Y'
                           ELSE ( case when UPPER(FI.ITEM_NM)  LIKE '%' + UPPER(RTRIM(ISNULL(@P_ITEM_NM,''))) + '%'	then 'Y' else 'N' end) 
					  END) 
	END

END






go

