
CREATE PROCEDURE [dbo].[SP_DP_MAKE_ACTUAL_SALES] (
    @P_FROM_DATE		DATE
  , @P_TO_DATE			DATE
  , @P_BUKT				NVARCHAR(2)
  , @P_DATA_TP			 CHAR(4)		= 'EXAM'
  , @P_DEL_YN			CHAR(1) -- Y / N
  , @P_USER_ID			NVARCHAR(100)  = 'admin'
  , @P_UI_ID			NVARCHAR(100)
  , @P_RT_ROLLBACK_FLAG  NVARCHAR(10)   = 'true'    OUTPUT
  , @P_RT_MSG            NVARCHAR(4000) = ''		OUTPUT
)
AS 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON;
/*******************************************************************************************************************
	--
	-- HISTORY
	-- 2019.11.15 / Kimsohee / make Actual sales using only Mapping data
	-- 2019.11.21 / kimsohee / rewrite 
	-- 2020.02.06 / kimsohee / add a function of calculate
							 / 휴일일 때는 들어오지 않게 (temp test)
*******************************************************************************************************************/
DECLARE  
	     @P_ERR_STATUS INT = 0
        ,@P_ERR_MSG NVARCHAR(4000)=''
		,@p_TOTAL_RW	INT;
BEGIN try	 
IF(@P_DEL_YN = 'Y')
	BEGIN
		TRUNCATE TABLE TB_CM_ACTUAL_SALES
	END
ELSE 
	BEGIN
		DELETE 
		  FROM TB_CM_ACTUAL_SALES
		 WHERE BASE_DATE BETWEEN @P_FROM_DATE AND @P_TO_DATE	
		 ;
	END
/*******************************************************************************************************************
	-- 1. EXAM : Example
******************************************************************************************************************/
IF(@P_DATA_TP = 'EXAM')
	BEGIN
CREATE TABLE     #TMP_ACTUAL_SALES
(
      ID				INT
	, ITEM_MST_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
	, ACCOUNT_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
	, BASE_DATE			DATE
	, SO_STATUS_ID		CHAR(32)	COLLATE DATABASE_DEFAULT
	, QTY				DECIMAL(20,2)
) 

		INSERT INTO #TMP_ACTUAL_SALES
			SELECT ROW_NUMBER() OVER (ORDER BY NEWID()) AS ID
				 , ITEM_ID
				 , ACCT_ID
				 , DAT
				 , SO_STATUS.ID AS SO_STATUS_ID
				 , 10+ROUND( 15 * RAND(cast( NEWID() AS varbinary )) + 1 , 0, 1) AS QTY	 
			  FROM FN_DP_TEMP_ITEM_ACCOUNT_DATE(@P_FROM_DATE, @P_TO_DATE, @P_BUKT)
				   CROSS JOIN
				   (SELECT ID, CONF_CD
					  FROM TB_CM_COMM_CONFIG
					 WHERE CONF_GRP_CD = 'DP_SO_STATUS'		
					   AND ACTV_YN = 'Y'
				   ) SO_STATUS 

			-- 매달 들어있는 데이터 중 일부 삭제
			SELECT @p_TOTAL_RW = MAX(ID) FROM #TMP_ACTUAL_SALES

			DELETE 
			  FROM #TMP_ACTUAL_SALES			   				
			 WHERE ID < @p_TOTAL_RW / 5
			  
		
			-- 계절별 랜덤 가중치
			UPDATE #TMP_ACTUAL_SALES
			   SET QTY = ROUND(QTY * CASE ROUND( RAND(convert(varbinary, item_mst_id)), 2, 0) *  ROUND( RAND(convert(varbinary, item_mst_id)), 2, 0)  * 5 WHEN 1
										THEN 1 ELSE ROUND( RAND(convert(varbinary, item_mst_id)), 2, 0) *  ROUND( RAND(convert(varbinary, item_mst_id)), 2, 0)  * 5 END, 0, 0)
			 WHERE DATEPART(MONTH, BASE_DATE) BETWEEN 7 AND 8

 			UPDATE #TMP_ACTUAL_SALES
			   SET QTY = ROUND(QTY * CASE ROUND( RAND(convert(varbinary, item_mst_id)), 1, 0) * 3 WHEN 1
										THEN 1 ELSE ROUND( RAND(convert(varbinary, item_mst_id)), 1, 0) * 3 END, 0, 0)
			 WHERE DATEPART(MONTH, BASE_DATE) BETWEEN 1 AND 12

			-- 휴일 가중치
			UPDATE #TMP_ACTUAL_SALES
			   SET QTY = ROUND(  QTY* RAND(convert(varbinary, item_mst_id))* 3, 0, 0)+1
			  FROM #TMP_ACTUAL_SALES SA
				   INNER JOIN
				   TB_CM_CALENDAR CA
				ON SA.BASE_DATE = CA.DAT 
			 WHERE NX_HOLID IN (0, 1)
			   OR  PR_HOLID IN (0, 1)
			  
			-- 너무 큰 값은 삭제
			 DELETE 
			   FROM  #TMP_ACTUAL_SALES
			  WHERE QTY > 1000		 

			-- Insert 
			INSERT INTO TB_CM_ACTUAL_SALES (ID, ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, SO_STATUS_ID,QTY,  CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM)
			     SELECT   REPLACE(NEWID(),'-','') ID			
						, ITEM_MST_ID	
						, ACCOUNT_ID	
						, BASE_DATE		
						, SO_STATUS_ID	
						, QTY			
						, @P_USER_ID AS CREATE_BY	
						, GETDATE()  AS CREATE_DTTM	
						, NULL		 AS MODIFY_BY	
						, NULL		 AS MODIFY_DTTM	
			       FROM #TMP_ACTUAL_SALES
			 

	END
/*******************************************************************************************************************
	-- 2. CALC : Calculate wanted values based real data
	-- 1년 (12달) 데이터가 들어있다면 계산 가능
******************************************************************************************************************/
IF (@P_DATA_TP = 'CALC')
	BEGIN
		DECLARE @P_MM_CNT	 INT	 = 11
			  , @P_YYYY		 CHAR(4)
			  , @P_IP_ENDT   DATE    
			  , @P_IP_STDT   DATE	 
			  , @P_SA_SUM	 DECIMAL(20,2)

		SELECT TOP 1 @P_YYYY = DATEPART(YEAR,BASE_DATE) 
		  FROM TB_CM_ACTUAL_SALES 
	   GROUP BY DATEPART(YEAR,BASE_DATE)
	     HAVING  DATEDIFF(MONTH,MIN(BASE_DATE),MAX(BASE_DATE)) = @P_MM_CNT
	   ORDER BY DATEPART(YEAR,BASE_DATE) DESC
		;
		IF(@P_YYYY IS NULL)
		BEGIN
		   SET @P_ERR_MSG = 'MSG_5046' 
		   RAISERROR (@P_ERR_MSG,12, 1);						
		END
		SELECT @P_IP_STDT = CONVERT(DATE, @P_YYYY+'0101')
			 , @P_IP_ENDT = CONVERT(DATE, @P_YYYY+'1231')
			 ;
		SELECT @P_SA_SUM = AVG(QTY) 
		  FROM (
				SELECT ITEM_MST_ID, ACCOUNT_ID, SUM(QTY)	AS QTY
				  FROM TB_CM_ACTUAL_SALES
				 WHERE BASE_DATE BETWEEN @P_IP_STDT AND @P_IP_ENDT	   
			  GROUP BY ITEM_MST_ID, ACCOUNT_ID
			   ) A
		;

		-- 있는 실적 기반으로 달의 가중치를 구하여 계산	
		WITH MM
		AS (
				SELECT MM, AVG(QTY)	AS QTY 
				  FROM (
						SELECT ITEM_MST_ID, ACCOUNT_ID, DATEPART(MONTH, BASE_DATE) AS MM, SUM(QTY) AS QTY
						  FROM TB_CM_ACTUAL_SALES
						 WHERE BASE_DATE BETWEEN @P_IP_STDT AND @P_IP_ENDT	   
					  GROUP BY  ITEM_MST_ID, ACCOUNT_ID,  DATEPART(MONTH, BASE_DATE)
					  ) A
			 GROUP BY MM
		), DW
		AS ( SELECT DW, AVG(QTY) AS QTY
			   FROM (
			 			SELECT ITEM_MST_ID, ACCOUNT_ID, DATEPART(DW, BASE_DATE) AS DW, SUM(QTY) AS QTY
			 			  FROM TB_CM_ACTUAL_SALES 
			 			 WHERE BASE_DATE BETWEEN @P_IP_STDT AND @P_IP_ENDT	    --'2019-09-04' AND '2020-09-03' --
						   AND DATEPART(DW, BASE_DATE) BETWEEN 2 AND 6
			 		  GROUP BY ITEM_MST_ID, ACCOUNT_ID, DATEPART(DW, BASE_DATE) 
				   ) A
			GROUP BY DW
		), SA
		AS (-- 전체 QTY : 요일별 QTY = 전체 요일별 개수 : 1
			-- 전체 요일별 개수 * 요일별 QTY = 전체 QTY * 1
				SELECT ITEM_ID
					 , ACCT_ID
					 , DAT
					 , SO_STATUS.ID AS SO_STATUS_ID
					 , ROUND( DW.QTY * (45 * RAND(cast( NEWID() AS varbinary )) + 1)/@P_SA_SUM * 5 , 0, 1) AS QTY
				  FROM FN_DP_TEMP_ITEM_ACCOUNT_DATE(@P_FROM_DATE, @P_TO_DATE, @P_BUKT) M
					   CROSS JOIN
					   (SELECT ID, CONF_CD
						  FROM TB_CM_COMM_CONFIG
						 WHERE CONF_GRP_CD = 'DP_SO_STATUS'		
						   AND ACTV_YN = 'Y'
					   ) SO_STATUS 
					   LEFT OUTER JOIN
					   DW 
					ON DATEPART(dW, M.DAT) = DW.DW 
		 ) -- 전체 QTY : 월별 QTY = 전체 월별 갯수 : 1
		   -- 월별 QTY * 전체 월별 갯수 = 전체 QTY * 1
		   INSERT INTO TB_CM_ACTUAL_SALES (ID, ITEM_MST_ID, ACCOUNT_ID, BASE_DATE, SO_STATUS_ID,QTY,  CREATE_BY, CREATE_DTTM, MODIFY_BY, MODIFY_DTTM)		
				SELECT REPLACE(NEWID(),'-','')	AS ID
					 , SA.ITEM_ID
					 , SA.ACCT_ID
					 , SA.DAT 
					 , SO_STATUS_ID 
					 , ROUND(SA.QTY * MM.QTY / @P_SA_SUM * @P_MM_CNT,0,1)  AS QTY 	 	
					 , NULL		 AS CREATE_BY
					 , GETDATE() AS CREATE_DTTM
					 , NULL		 AS MODIFY_BY
					 , NULL		 AS MODIFY_DTTM
				  FROM SA
					   INNER JOIN
					   MM
				    ON DATEPART(MONTH,SA.DAT) = MM.MM
					;
	END	
/*******************************************************************************************************************
	-- amount
******************************************************************************************************************/ 
	UPDATE TB_CM_ACTUAL_SALES
       SET AMT = QTY * 1000
	 WHERE BASE_DATE BETWEEN  @P_FROM_DATE AND @P_TO_DATE
	;


/*******************************************************************************************************************
	-- Result Message
******************************************************************************************************************/
WITH  RESULT 
AS(
	SELECT 'UI_DP_41'		  AS UI_ID
		,  'TB_DP_MEASURE_DATA' AS TABLE_NM
		,  COUNT(*)			  AS CNT
	  FROM TB_DP_MEASURE_DATA
	UNION
	SELECT 'UI_DP_42'		  AS UI_ID
		,  'TB_CM_ACTUAL_SALES' AS TABLE_NM
		,  COUNT(*)			  AS CNT
	  FROM TB_CM_ACTUAL_SALES
	   )
SELECT *
  FROM RESULT 
WHERE UI_ID IN (SELECT VALUE FROM FN_SPLIT(@P_UI_ID, '|'))

	   SET @P_RT_ROLLBACK_FLAG = 'true'
	   SET @P_RT_MSG = 'MSG_0003'  --저장 되었습니다.

END TRY
BEGIN CATCH
	   IF (ERROR_MESSAGE()= @P_ERR_MSG)
		   BEGIN
			   SET @P_ERR_MSG = ERROR_MESSAGE()
			   SET @P_RT_ROLLBACK_FLAG = 'false'
			   SET @P_RT_MSG = @P_ERR_MSG
			END

	   ELSE 
--				THROW;
				EXEC SP_COMM_RAISE_ERR

END CATCH;

go

