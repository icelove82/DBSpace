CREATE PROCEDURE [dbo].[SP_UI_DP_93_CUTOFF] 
(
	 @P_VERSION_CD		NVARCHAR(50)	  = ''
	,@p_CUTOFF_VER_CD	NVARCHAR(50)  = ''
	,@p_USER_ID			NVARCHAR(255) = ''
	,@p_CL_LV_MGMT_ID	CHAR(32)	  = ''
	,@p_CL_TP_CD		NVARCHAR(50)  = ''
) AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

 
BEGIN
	SET NOCOUNT ON;
	DECLARE -- versrion param
		    @P_TO_DATE				DATE
		 ,  @P_PRICE_TP_ID			CHAR(32)
		 ,  @P_VERSION_ID			CHAR(32)
		 ,  @P_DMND_TP_ID			CHAR(32)
		;	 
/*************************************************************************************************
	-- Get Version Info
*************************************************************************************************/
	SELECT @P_TO_DATE			= TO_DATE
		  ,@P_PRICE_TP_ID		= PRICE_TP_ID		  
		  ,@P_VERSION_ID		= ID
	  FROM TB_DP_CONTROL_BOARD_VER_MST 
	 WHERE VER_ID = @P_VERSION_CD
	 ;

	WITH UNIT_PRICE
	AS (
	SELECT  ITEM_MST_ID
		   ,ACCOUNT_ID
		   ,BASE_DATE	AS STRT_DATE 
		   ,ISNULL(DATEADD(DAY,-1,LEAD(BASE_DATE) OVER (PARTITION BY ITEM_MST_ID, ACCOUNT_ID ORDER BY  BASE_DATE )),@P_TO_DATE)	AS END_DATE  
		   ,UTPIC
	  FROM TB_DP_UNIT_PRICE UP
	--	   INNER JOIN
	--	   IA	-- 가격에서 매핑돼있는 데이터만 가져오기
	--	ON UP.ITEM_MST_ID = IA.ITEM_ID
	--   AND UP.ACCOUNT_ID = IA.ACCT_ID	   
	 WHERE BASE_DATE <= @P_TO_DATE 
	   AND PRICE_TP_ID = @P_PRICE_TP_ID
	)	
	UPDATE TB_DP_ENTRY
	   SET AMT = QTY * UP.UTPIC 
	  FROM UNIT_PRICE UP
      WHERE TB_DP_ENTRY.ITEM_MST_ID = UP.ITEM_MST_ID  
	   AND TB_DP_ENTRY.ACCOUNT_ID = UP.ACCOUNT_ID
	   AND TB_DP_ENTRY.BASE_DATE BETWEEN UP.STRT_DATE  AND UP.END_DATE 
	;	   		   

	if (@p_CL_TP_CD != 'SRP' )
		begin
		 --TB_DP_ENTRY_CUTOFF
		 insert into TB_DP_ENTRY_CUTOFF  (ID,PLAN_TP_ID, VER_ID, CUTOFF_VER_CD, AUTH_TP_ID, ITEM_MST_ID, ACCOUNT_ID, EMP_ID, 
									BASE_DATE, QTY, QTY_1, QTY_2, QTY_3, AMT, AMT_1, AMT_2, AMT_3, CREATE_BY, CREATE_DTTM)
		 select (SELECT REPLACE(NEWID(),'-','')),PLAN_TP_ID, VER_ID,  @p_CUTOFF_VER_CD as CUTOFF_VER_CD, AUTH_TP_ID, ITEM_MST_ID, ACCOUNT_ID,EMP_ID,  
									BASE_DATE, QTY, QTY_1, QTY_2, QTY_3, AMT, AMT_1, AMT_2, AMT_3, @p_USER_ID as  CREATE_BY, GETDATE()
		 from TB_DP_ENTRY 
		 where AUTH_TP_ID = @p_CL_LV_MGMT_ID and VER_ID = @P_VERSION_ID;
	/*********************************************************************************************************
		-- Cutoff : Transfer a result for Demand Overview or Forecast of Sales RP
	*********************************************************************************************************/
			-- GET DMND_TP_ID
			SELECT @P_DMND_TP_ID = B.ID 
			  FROM TB_AD_COMN_GRP A
				  ,TB_AD_COMN_CODE B
			 WHERE 1=1
			   AND A.ID = B.SRC_ID
			   AND A.GRP_CD = 'DEMAND_TYPE'
			   AND COMN_CD_NM = 'Forecast'

		-- DELETE DEMAND_OVERVIEW
		DELETE FROM TB_CM_DEMAND_OVERVIEW
		  WHERE T3SERIES_VER_ID = @P_VERSION_CD
		-- INSERT DEMAND_OVERVIEW 
		INSERT INTO TB_CM_DEMAND_OVERVIEW
				   (   ID
					 , MODULE_VAL
--					 , YYYYMMDD
--					 , MAIN_VER
--					 , REVISION_VER
					 , T3SERIES_VER_ID
					 , CONFRM_YN
					 , FINAL_CONFRM_YN
					 , DMND_ID
					 , DMND_TP_ID
					 , DMND_CLASS_ID
					 , ITEM_MST_ID
--					 , URGENT_ORDER_TP_ID
					 , DMND_QTY
					 , UOM_ID
					 , DUE_DATE
--					 , REQUEST_SITE_ID
					 , ACCOUNT_ID
					 , SALES_UNIT_PRIC
--					 , MARGIN
					 , CURCY_CD_ID
--					 , BOD_LEADTIME
--					 , TIME_UOM_ID
--					 , PRDUCT_DELIVY_DATE
--					 , ASSIGN_SITE_CNT
--					 , ASSIGN_RES_CNT
					 , DELIVY_PLAN_POLICY_CD_ID
					 , MAT_CONST_CD_ID
					 , EFFICY
					 , PARTIAL_PLAN_YN
					 , COST_OPTIMIZ_YN
--					 , PST
					 , DUE_DATE_FNC
--					 , DELIVY_DATE
--					 , DAYS_LATE
--					 , PLAN_QTY
--					 , LATE_QTY
--					 , DELIVY_QTY
--					 , ON_TIME_QTY
--					 , SHRT_QTY
					 , ACTV_YN
					 , CREATE_BY
					 , CREATE_DTTM
--					 , MODIFY_BY
--					 , MODIFY_DTTM
--					 , DESCRIP
--					 , NETTING_QTY
--					 , FORECAST_ID
--					 , FORECAST_QTY
--					 , SRC_DMND_ID
--					 , DMND_LOCAT_ID
--					 , HEURISTIC_YN
--					 , STRATEGY_METHD_ID
--					 , DISPLAY_COLOR
					)
				SELECT REPLACE(NEWID(),'-','')													ID
					 , 'DP'																		MODULE_VAL
		--			 , NULL																		YYYYMMDD
		--			 , NULL																		MAIN_VER
		--			 , NULL																		REVISION_VER
					 , @P_VERSION_CD																T3SERIES_VER_ID
					 , 'Y'																		CONFRM_YN
					 , 'Y'																		FINAL_CONFRM_YN
					 , 'DMND_'
					 + REPLICATE('0', 15-LEN(CONVERT(NVARCHAR(15), ROW_NUMBER() OVER (ORDER BY DE.ID))))
					 + CONVERT(NVARCHAR(15), ROW_NUMBER() OVER (ORDER BY DE.ID))				DMND_ID
					 , @P_DMND_TP_ID					   									    DMND_TP_ID
					 , (SELECT B.ID 
						  FROM TB_AD_COMN_GRP A
						      ,TB_AD_COMN_CODE B
						 WHERE 1=1
						   AND A.ID = B.SRC_ID
						   AND A.GRP_CD = 'DEMAND_CLASS'
						   AND COMN_CD = 'NEW')													DMND_CLASS_ID
					 , ITEM_MST_ID
		--			 , NULL																		URGENT_ORDER_TP_ID
					 , QTY																		DMND_QTY
					 , IT.UOM_ID																UOM_ID
					 , BASE_DATE																DUE_DATE
		--			 , REQUEST_SITE_ID
					 , ACCOUNT_ID
					 , AMT/QTY																	SALES_UNIT_PRIC
		--			 , MARGIN
					 , AC.CURCY_CD_ID															CURCY_CD_ID
		--			 , BOD_LEADTIME
		--			 , TIME_UOM_ID
		--			 , PRDUCT_DELIVY_DATE
		--			 , ASSIGN_SITE_CNT
		--			 , ASSIGN_RES_CNT
					 , (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'CM_BASE_ORD_DELIV_POLICY'
						   AND DEFAT_VAL = 'Y'			 
					   )																		DELIVY_PLAN_POLICY_CD_ID
					 , (SELECT ID FROM TB_CM_COMM_CONFIG WHERE CONF_GRP_CD = 'MP_ORD_CAPA_MAT_COST'
						   AND DEFAT_VAL = 'Y')													MAT_CONST_CD_ID
					 , (SELECT CONF_CD  FROM TB_CM_COMM_CONFIG
					     WHERE CONF_GRP_CD = 'MP_BASE_EFFCIENCY')								EFFICY
					 , (SELECT CASE WHEN CONF_CD = 'TRUE' then 'Y' else 'N'  end FROM TB_CM_COMM_CONFIG
						 WHERE CONF_GRP_CD = 'MP_ORD_PARTIAL_PLN')								PARTIAL_PLAN_YN
					 , (SELECT (CASE WHEN CONF_CD = 'TRUE' then 'Y' else 'N'  end) FROM TB_CM_COMM_CONFIG
						 WHERE CONF_GRP_CD = 'CM_ORD_ROUT_COST_OPT')							COST_OPTIMIZ_YN
		--			 , PST
					 , ( SELECT CASE B.UOM_CD
									 WHEN 'DAY'   THEN DATEADD(DD, CAST(A.CATAGY_VAL AS NUMERIC), BASE_DATE)   
									 WHEN 'WEEK'  THEN DATEADD(WK, CAST(A.CATAGY_VAL AS NUMERIC), BASE_DATE)    
									 WHEN 'MONTH' THEN DATEADD(MM, CAST(A.CATAGY_VAL AS NUMERIC), BASE_DATE)   
									 WHEN 'YEAR'  THEN DATEADD(YY, CAST(A.CATAGY_VAL AS NUMERIC), BASE_DATE)    
								END			 
						  FROM TB_CM_BASE_ORDER A
							   INNER JOIN
						       TB_CM_UOM B
						    ON A.CATAGY_CD = 'BASE_ORDER_DUE_DATE_FENCE'
						   AND A.UOM_ID = B.ID AND  A.ACTV_YN = 'Y' )						    DUE_DATE_FNC
		--			 , DELIVY_DATE
		--			 , DAYS_LATE
		--			 , PLAN_QTY
		--			 , LATE_QTY
		--			 , DELIVY_QTY
		--			 , ON_TIME_QTY
		--			 , SHRT_QTY
					 , CASE WHEN @P_DMND_TP_ID IS NULL THEN 'N' ELSE 'Y' END					ACTV_YN
					 , @P_USER_ID																CREATE_BY
					 , GETDATE()																CREATE_DTTM
		--			 , NULL																		MODIFY_BY
		--			 , NULL																		MODIFY_DTTM
		--			 , DESCRIP
		--			 , NETTING_QTY
		--			 , FORECAST_ID
		--			 , FORECAST_QTY
		--			 , SRC_DMND_ID
		--			 , DMND_LOCAT_ID
		--			 , HEURISTIC_YN
		--			 , STRATEGY_METHD_ID
		--			 , DISPLAY_COLOR
			      FROM TB_DP_ENTRY  DE
					   INNER JOIN
					   TB_CM_ITEM_MST IT 
					ON DE.ITEM_MST_ID = IT.ID 
					   INNER JOIN
					   TB_DP_ACCOUNT_MST AC
					ON AC.id = DE.ACCOUNT_ID
				 WHERE VER_ID =  @P_VERSION_ID  
				   AND AUTH_TP_ID = @P_CL_LV_MGMT_ID
				   ;		    			   
		END

END

go

